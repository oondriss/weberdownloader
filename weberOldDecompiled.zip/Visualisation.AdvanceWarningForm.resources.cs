// Visualisation.AdvanceWarningForm.resources (Embedded, Public)

// Visualisation.BackupForm.resources (Embedded, Public)

// Visualisation.BrowserForm.resources (Embedded, Public)

// Visualisation.BrowserHelpForm.resources (Embedded, Public)

// Visualisation.ComponentForm.resources (Embedded, Public)

// Visualisation.ComponentNewEntryForm.resources (Embedded, Public)

// Visualisation.CurveDisplayForm.resources (Embedded, Public)

// Visualisation.CurvePreview.resources (Embedded, Public)

// Visualisation.CurvePrintForm.resources (Embedded, Public)

// Visualisation.CurveSelectionForm.resources (Embedded, Public)

// Visualisation.CycleCounterForm.resources (Embedded, Public)

// Visualisation.EditDrivingStepForm.resources (Embedded, Public)

// Visualisation.EditFinalizeStepForm.resources (Embedded, Public)

// Visualisation.EditOrganizeStepForm.resources (Embedded, Public)

// Visualisation.ErrorDisplayForm.resources (Embedded, Public)

// Visualisation.FileOperationForm.resources (Embedded, Public)

// Visualisation.FourStepEditForm.resources (Embedded, Public)

// Visualisation.FourStepOverviewForm.resources (Embedded, Public)

// Visualisation.FtpProgressForm.resources (Embedded, Public)

// Visualisation.HandStartForm.resources (Embedded, Public)

// Visualisation.CheckParamForm.resources (Embedded, Public)

// Visualisation.KeyPadForm.resources (Embedded, Public)

// Visualisation.LanguageText_cz.resources (Embedded, Public)



// Visualisation.LanguageText_de.resources (Embedded, Public)



// Visualisation.LanguageText_en.resources (Embedded, Public)



// Visualisation.LanguageText_es.resources (Embedded, Public)



// Visualisation.LanguageText_fr.resources (Embedded, Public)



// Visualisation.LanguageText_hu.resources (Embedded, Public)



// Visualisation.LanguageText_it.resources (Embedded, Public)



// Visualisation.LanguageText_sk.resources (Embedded, Public)



// Visualisation.LastNIOResultsForm.resources (Embedded, Public)

// Visualisation.LevelAssignmentForm.resources (Embedded, Public)

// Visualisation.LogBookForm.resources (Embedded, Public)

// Visualisation.LogChangesForm.resources (Embedded, Public)

// Visualisation.MainForm.resources (Embedded, Public)

// Visualisation.MaintenanceForm.resources (Embedded, Public)

// Visualisation.MaintenanceNewEntryForm.resources (Embedded, Public)

// Visualisation.MenuAnalysisForm.resources (Embedded, Public)

// Visualisation.MenuMaintenanceForm.resources (Embedded, Public)

// Visualisation.MenuParameterForm.resources (Embedded, Public)

// Visualisation.MenuStatisticsForm.resources (Embedded, Public)

// Visualisation.MenuTestForm.resources (Embedded, Public)

// Visualisation.NumberPadForm.resources (Embedded, Public)

// Visualisation.ParameterPrintForm.resources (Embedded, Public)

// Visualisation.PasscodeManagerForm.resources (Embedded, Public)

// Visualisation.PasswordInputForm.resources (Embedded, Public)

// Visualisation.PrgOptParameterForm.resources (Embedded, Public)

// Visualisation.ProgFileOperationForm.resources (Embedded, Public)

// Visualisation.ProgPreview.resources (Embedded, Public)

// Visualisation.ProgramOverviewForm.resources (Embedded, Public)

// Visualisation.Properties.Resources.resources (Embedded, Public)

// Visualisation.RestoreDataForm.resources (Embedded, Public)

// Visualisation.ResultDisplayForm.resources (Embedded, Public)

// Visualisation.ResultMiniDisplayForm.resources (Embedded, Public)

// Visualisation.SpindleConstantsForm.resources (Embedded, Public)

// Visualisation.StatisticsLastResForm.resources (Embedded, Public)

// Visualisation.StepKindChoiceForm.resources (Embedded, Public)

// Visualisation.StepOverviewForm.resources (Embedded, Public)

// Visualisation.StepResultForm.resources (Embedded, Public)

// Visualisation.SystemConstantsForm.resources (Embedded, Public)

// Visualisation.TestIOForm.resources (Embedded, Public)

// Visualisation.TestMotorSensorForm.resources (Embedded, Public)

// Visualisation.TestSPSIOForm.resources (Embedded, Public)

// Visualisation.TopTenForm.resources (Embedded, Public)

// Visualisation.USB_ChangePasswordForm.resources (Embedded, Public)

// Visualisation.USB_PasswordForm.resources (Embedded, Public)

// Visualisation.VisualisationParamForm.resources (Embedded, Public)

// WUSB_KeyVerwaltung.DetectorForm.resources (Embedded, Public)
