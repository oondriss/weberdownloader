using WSP1_VARCOMM1;

namespace test
{
    class Program
    {
        public void Main(string[] args)
        {
            WSP1_VARCOMM1 conn = new WSP1_VARCOMM1();
            conn.ConnectToServer("127.0.0.1");
        }
    }
}