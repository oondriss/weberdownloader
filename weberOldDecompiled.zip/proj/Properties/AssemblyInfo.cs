using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security.Permissions;

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyTitle("Visualisation")]
[assembly: AssemblyCopyright("Copyright © WEBER Schraubautomaten GmbH 1998 - 2014")]
[assembly: AssemblyKeyName("")]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: AssemblyDescription("Screwprocess")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("WEBER Schraubautomaten GmbH")]
[assembly: AssemblyProduct("WSP2_Visualisation_Screw")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, UnmanagedCode = true)]
[assembly: AssemblyVersion("2.4.0.329")]
