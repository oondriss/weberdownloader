using System;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace WeberKXML_OLD_Data
{
	[Serializable]
	public class XML_Data
	{
		public string XMLSafeFileName;

		public string Date;

		public string Time;

		public string File;

		public string Title;

		public string AxesXName;

		public string AxesXUnit;

		public string[] AxesYNames;

		public string[] AxesYUnits;

		public int NumberofYAxes;

		public int VectorLength;

		public bool IsAxisXTime;

		public float[] XVector;

		public float[] Y1;

		public float[] Y2;

		public float[] Y3;

		public float[] Y4;

		public float[] Y5;

		public float[] Y6;

		public float[] Y7;

		public float[] Y8;

		public float[] Y9;

		public float[] Y10;

		public void SaveXML(string path)
		{
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(XML_Data));
			StreamWriter streamWriter = new StreamWriter(path);
			try
			{
				xmlSerializer.Serialize(streamWriter, this);
			}
			finally
			{
				streamWriter.Close();
				streamWriter.Dispose();
			}
		}

		public void ReadXML(string path, ref XML_Data xmlData)
		{
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(XML_Data));
			FileStream fileStream = new FileStream(path, FileMode.Open);
			try
			{
				xmlData = (XML_Data)xmlSerializer.Deserialize(fileStream);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
			fileStream.Close();
			fileStream.Dispose();
		}
	}
}
