using System.Runtime.InteropServices;
using System.Text;

namespace System.Windows.Forms
{
	public class MessageBoxManager
	{
		private delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);

		private delegate bool EnumChildProc(IntPtr hWnd, IntPtr lParam);

		public struct CWPRETSTRUCT
		{
			public IntPtr lResult;

			public IntPtr lParam;

			public IntPtr wParam;

			public uint message;

			public IntPtr hwnd;
		}

		private const int WH_CALLWNDPROCRET = 12;

		private const int WM_DESTROY = 2;

		private const int WM_INITDIALOG = 272;

		private const int WM_TIMER = 275;

		private const int WM_USER = 1024;

		private const int DM_GETDEFID = 1024;

		private const int MBOK = 1;

		private const int MBCancel = 2;

		private const int MBAbort = 3;

		private const int MBRetry = 4;

		private const int MBIgnore = 5;

		private const int MBYes = 6;

		private const int MBNo = 7;

		private static HookProc hookProc;

		private static EnumChildProc enumProc;

		[ThreadStatic]
		private static IntPtr hHook;

		[ThreadStatic]
		private static int nButton;

		public static string OK;

		public static string Cancel;

		public static string Abort;

		public static string Retry;

		public static string Ignore;

		public static string Yes;

		public static string No;

		public static string Properties;

		public static string Store;

		public static string OutpuInFile;

		public static string Sorting;

		public static string All;

		public static string Marking;

		public static string Pages;

		public static string Copies;

		public static string PrintRange;

		public static string Printer;

		public static string NumberOfCopies;

		public static string CreateNewFolder;

		[DllImport("user32.dll")]
		private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

		[DllImport("user32.dll")]
		private static extern IntPtr SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hInstance, int threadId);

		[DllImport("user32.dll")]
		private static extern int UnhookWindowsHookEx(IntPtr idHook);

		[DllImport("user32.dll")]
		private static extern IntPtr CallNextHookEx(IntPtr idHook, int nCode, IntPtr wParam, IntPtr lParam);

		[DllImport("user32.dll", CharSet = CharSet.Unicode, EntryPoint = "GetWindowTextLengthW")]
		private static extern int GetWindowTextLength(IntPtr hWnd);

		[DllImport("user32.dll", CharSet = CharSet.Unicode, EntryPoint = "GetWindowTextW")]
		private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int maxLength);

		[DllImport("user32.dll")]
		private static extern int EndDialog(IntPtr hDlg, IntPtr nResult);

		[DllImport("user32.dll")]
		private static extern bool EnumChildWindows(IntPtr hWndParent, EnumChildProc lpEnumFunc, IntPtr lParam);

		[DllImport("user32.dll", CharSet = CharSet.Unicode, EntryPoint = "GetClassNameW")]
		private static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

		[DllImport("user32.dll")]
		private static extern int GetDlgCtrlID(IntPtr hwndCtl);

		[DllImport("user32.dll")]
		private static extern IntPtr GetDlgItem(IntPtr hDlg, int nIDDlgItem);

		[DllImport("user32.dll", CharSet = CharSet.Unicode, EntryPoint = "SetWindowTextW")]
		private static extern bool SetWindowText(IntPtr hWnd, string lpString);

		static MessageBoxManager()
		{
			MessageBoxManager.OK = "&OK";
			MessageBoxManager.Cancel = "&Cancel";
			MessageBoxManager.Abort = "&Abort";
			MessageBoxManager.Retry = "&Retry";
			MessageBoxManager.Ignore = "&Ignore";
			MessageBoxManager.Yes = "&Yes";
			MessageBoxManager.No = "&No";
			MessageBoxManager.Properties = "Properties";
			MessageBoxManager.Store = "Store";
			MessageBoxManager.OutpuInFile = "Output in file";
			MessageBoxManager.Sorting = "Sorting";
			MessageBoxManager.All = "All";
			MessageBoxManager.Marking = "Marking";
			MessageBoxManager.Pages = "Pages";
			MessageBoxManager.Copies = "Copies";
			MessageBoxManager.PrintRange = "Print range";
			MessageBoxManager.Printer = "Printer";
			MessageBoxManager.NumberOfCopies = "Number of copies";
			MessageBoxManager.CreateNewFolder = "Create new folder";
			MessageBoxManager.hookProc = MessageBoxManager.MessageBoxHookProc;
			MessageBoxManager.enumProc = MessageBoxManager.MessageBoxEnumProc;
			MessageBoxManager.hHook = IntPtr.Zero;
		}

		public static void Register()
		{
			if (MessageBoxManager.hHook != IntPtr.Zero)
			{
				throw new NotSupportedException("One hook per thread allowed.");
			}
			MessageBoxManager.hHook = MessageBoxManager.SetWindowsHookEx(12, MessageBoxManager.hookProc, IntPtr.Zero, AppDomain.GetCurrentThreadId());
		}

		public static bool IsRegistered()
		{
			if (MessageBoxManager.hHook != IntPtr.Zero)
			{
				return true;
			}
			return false;
		}

		public static void Unregister()
		{
			if (MessageBoxManager.hHook != IntPtr.Zero)
			{
				MessageBoxManager.UnhookWindowsHookEx(MessageBoxManager.hHook);
				MessageBoxManager.hHook = IntPtr.Zero;
			}
		}

		private static IntPtr MessageBoxHookProc(int nCode, IntPtr wParam, IntPtr lParam)
		{
			if (nCode < 0)
			{
				return MessageBoxManager.CallNextHookEx(MessageBoxManager.hHook, nCode, wParam, lParam);
			}
			CWPRETSTRUCT cWPRETSTRUCT = (CWPRETSTRUCT)Marshal.PtrToStructure(lParam, typeof(CWPRETSTRUCT));
			IntPtr idHook = MessageBoxManager.hHook;
			if (cWPRETSTRUCT.message == 272)
			{
				MessageBoxManager.GetWindowTextLength(cWPRETSTRUCT.hwnd);
				StringBuilder stringBuilder = new StringBuilder(10);
				MessageBoxManager.GetClassName(cWPRETSTRUCT.hwnd, stringBuilder, stringBuilder.Capacity);
				if (stringBuilder.ToString() == "#32770")
				{
					MessageBoxManager.nButton = 0;
					MessageBoxManager.EnumChildWindows(cWPRETSTRUCT.hwnd, MessageBoxManager.enumProc, IntPtr.Zero);
					if (MessageBoxManager.nButton == 1)
					{
						IntPtr dlgItem = MessageBoxManager.GetDlgItem(cWPRETSTRUCT.hwnd, 2);
						if (dlgItem != IntPtr.Zero)
						{
							MessageBoxManager.SetWindowText(dlgItem, MessageBoxManager.OK);
						}
					}
				}
			}
			return MessageBoxManager.CallNextHookEx(idHook, nCode, wParam, lParam);
		}

		private static bool MessageBoxEnumProc(IntPtr hWnd, IntPtr lParam)
		{
			StringBuilder stringBuilder = new StringBuilder(10);
			MessageBoxManager.GetClassName(hWnd, stringBuilder, stringBuilder.Capacity);
			string a = stringBuilder.ToString();
			if (a == "Button")
			{
				switch (MessageBoxManager.GetDlgCtrlID(hWnd))
				{
				case 1:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.OK);
					break;
				case 2:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.Cancel);
					break;
				case 3:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.Abort);
					break;
				case 4:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.Retry);
					break;
				case 5:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.Ignore);
					break;
				case 6:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.Yes);
					break;
				case 7:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.No);
					break;
				case 1025:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.Properties);
					break;
				case 1038:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.Store);
					break;
				case 1040:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.OutpuInFile);
					break;
				case 1041:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.Sorting);
					break;
				case 1056:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.All);
					break;
				case 1057:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.Marking);
					break;
				case 1058:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.Pages);
					break;
				case 1073:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.Copies);
					break;
				case 1072:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.PrintRange);
					break;
				case 1075:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.Printer);
					break;
				case 1092:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.NumberOfCopies);
					break;
				case 14150:
					MessageBoxManager.SetWindowText(hWnd, MessageBoxManager.CreateNewFolder);
					break;
				}
				MessageBoxManager.nButton++;
			}
			return true;
		}
	}
}
