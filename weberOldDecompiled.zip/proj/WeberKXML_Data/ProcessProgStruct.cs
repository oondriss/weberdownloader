using System;

namespace WeberKXML_Data
{
	[Serializable]
	public class ProcessProgStruct
	{
		public uint Number;

		public string Name = "";

		public string Type = "";
	}
}
