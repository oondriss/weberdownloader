using System;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace WeberKXML_Data
{
	[Serializable]
	public class XML_Data
	{
		public WSK3_HeaderStruct Wsk3Header = new WSK3_HeaderStruct();

		public Vectors_Class Wsk3Vectors = new Vectors_Class();

		public void SetNumberofYAxes(int numberOfYAxis)
		{
			this.Wsk3Header.NumberofYAxes = numberOfYAxis;
		}

		public int GetNumberofYAxes()
		{
			return this.Wsk3Header.NumberofYAxes;
		}

		public void SetVectorLength(int number)
		{
			this.Wsk3Header.NumberOfVectors = number;
		}

		public int GetVectorLength()
		{
			return this.Wsk3Header.NumberOfVectors;
		}

		public void SetCycle(uint cycle)
		{
			this.Wsk3Header.Result.Cycle = cycle;
		}

		public uint GetCycle()
		{
			return this.Wsk3Header.Result.Cycle;
		}

		public void SetVersion(string version)
		{
			if (version != null)
			{
				this.Wsk3Header.Version = version;
			}
		}

		public string GetVersion()
		{
			return this.Wsk3Header.Version;
		}

		public void SetDate(string date)
		{
			if (date != null)
			{
				this.Wsk3Header.Date = date;
			}
		}

		public string GetDate()
		{
			return this.Wsk3Header.Date;
		}

		public void SetTime(string time)
		{
			if (time != null)
			{
				this.Wsk3Header.Time = time;
			}
		}

		public string GetTime()
		{
			return this.Wsk3Header.Time;
		}

		public void SetTitle(string title)
		{
			if (title != null)
			{
				this.Wsk3Header.Title = title;
			}
		}

		public string GetTitle()
		{
			return this.Wsk3Header.Title;
		}

		public void SetPartID(string id)
		{
			if (id != null)
			{
				this.Wsk3Header.Result.PartID = id;
			}
		}

		public string GetPartID()
		{
			return this.Wsk3Header.Result.PartID;
		}

		public void GetProcessProg(out uint number, out string name, out string type)
		{
			number = this.Wsk3Header.ProcessProg.Number;
			name = this.Wsk3Header.ProcessProg.Name;
			type = this.Wsk3Header.ProcessProg.Type;
		}

		public void SetProcessProg(uint number, string name, string type)
		{
			this.Wsk3Header.ProcessProg.Number = number;
			this.Wsk3Header.ProcessProg.Name = name;
			this.Wsk3Header.ProcessProg.Type = type;
		}

		public void AddResult(string name, string unit, float value)
		{
			this.Wsk3Header.Result.AddResult(name, unit, value);
		}

		public bool GetResult(int index, out string name, out string unit, out float value)
		{
			return this.Wsk3Header.Result.GetResult(index, out name, out unit, out value);
		}

		public void SetController(string type, string id)
		{
			this.Wsk3Header.Controller.Type = type;
			this.Wsk3Header.Controller.Id = id;
		}

		public void GetController(out string type, out string id)
		{
			type = this.Wsk3Header.Controller.Type;
			id = this.Wsk3Header.Controller.Id;
		}

		public bool WriteXAxisData(float[] data, string name, string unit)
		{
			this.Wsk3Vectors.X_Axis.Header.Name = name;
			this.Wsk3Vectors.X_Axis.Header.Unit = unit;
			return this.Wsk3Vectors.X_Axis.storeData(data);
		}

		public bool ReadXAxisData(out float[] data, out string name, out string unit)
		{
			name = this.Wsk3Vectors.X_Axis.Header.Name;
			unit = this.Wsk3Vectors.X_Axis.Header.Unit;
			return this.Wsk3Vectors.X_Axis.GetData(out data);
		}

		public bool WriteYAxisData(float[] data, string name, string unit)
		{
			AxisData axisData = new AxisData();
			bool result = axisData.storeData(data);
			axisData.Header.Name = name;
			axisData.Header.Unit = unit;
			axisData._Index = this.Wsk3Vectors.Y_AxesList.Count;
			this.Wsk3Vectors.Y_AxesList.Add(axisData);
			return result;
		}

		public bool ReadYAxisData(int index, out float[] data, out string name, out string unit)
		{
			if (index < this.Wsk3Vectors.Y_AxesList.Count)
			{
				bool data2 = this.Wsk3Vectors.Y_AxesList[index].GetData(out data);
				name = this.Wsk3Vectors.Y_AxesList[index].Header.Name;
				unit = this.Wsk3Vectors.Y_AxesList[index].Header.Unit;
				return data2;
			}
			data = null;
			name = "";
			unit = "";
			return false;
		}

		public bool VerifyData()
		{
			if (this.Wsk3Vectors.X_Axis == null)
			{
				return false;
			}
			if (this.Wsk3Vectors.Y_AxesList.Count == 0)
			{
				return false;
			}
			if (this.Wsk3Header.NumberofYAxes != this.Wsk3Vectors.Y_AxesList.Count)
			{
				return false;
			}
			if (this.Wsk3Header.NumberOfVectors != this.Wsk3Vectors.Y_AxesList[0].GetNumberOfValues())
			{
				return false;
			}
			this.CorrectTimeVector();
			return true;
		}

		public void CorrectTimeVector()
		{
			if (this.Wsk3Vectors.X_Axis.Values.Length >= 11 && this.Wsk3Vectors.X_Axis.Values[1] == 0f && this.Wsk3Vectors.X_Axis.Values[10] == 0f)
			{
				this.Wsk3Vectors.X_Axis.Header.Unit = "ms";
				int num = this.Wsk3Vectors.X_Axis.Values.Length;
				for (int i = 0; i < num; i++)
				{
					this.Wsk3Vectors.X_Axis.Values[i] = (float)i * 1f;
				}
			}
		}

		public void SaveXML(string path)
		{
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(XML_Data));
			StreamWriter streamWriter = new StreamWriter(path);
			try
			{
				xmlSerializer.Serialize(streamWriter, this);
			}
			finally
			{
				streamWriter.Close();
				streamWriter.Dispose();
			}
		}

		public void ReadXML(string path, ref XML_Data xmlData)
		{
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(XML_Data));
			FileStream fileStream = new FileStream(path, FileMode.Open);
			try
			{
				xmlData = (XML_Data)xmlSerializer.Deserialize(fileStream);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error in file: '" + path + "'\n\n" + ex.ToString());
			}
			fileStream.Close();
			fileStream.Dispose();
		}
	}
}
