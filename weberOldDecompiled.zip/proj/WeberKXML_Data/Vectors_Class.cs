using System;
using System.Collections.Generic;

namespace WeberKXML_Data
{
	[Serializable]
	public class Vectors_Class
	{
		public AxisData X_Axis = new AxisData();

		public List<AxisData> Y_AxesList = new List<AxisData>();
	}
}
