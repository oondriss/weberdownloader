using System;

namespace WeberKXML_Data
{
	[Serializable]
	public class AxisData
	{
		public int _Index;

		public AxisHeader Header = new AxisHeader();

		public float[] Values;

		public bool storeData(float[] data)
		{
			int num = data.Length;
			this.Values = new float[num];
			for (int i = 0; i < num; i++)
			{
				this.Values[i] = data[i];
			}
			return true;
		}

		public bool GetData(out float[] data)
		{
			data = this.Values;
			if (this.Values != null)
			{
				return true;
			}
			return false;
		}

		public bool GetData(int index, out float data)
		{
			if (this.Values != null && index < this.Values.Length)
			{
				data = this.Values[index];
				return true;
			}
			data = 0f;
			return false;
		}

		public int GetNumberOfValues()
		{
			return this.Values.Length;
		}
	}
}
