using System;
using System.Collections.Generic;

namespace WeberKXML_Data
{
	[Serializable]
	public class Result
	{
		public uint Cycle;

		public string PartID = "";

		public string Kind = "";

		public List<NumericalResult> NumericalResultList = new List<NumericalResult>();

		public int Number => this.NumericalResultList.Count;

		public void AddResult(string name, string unit, float value)
		{
			NumericalResult numericalResult = new NumericalResult();
			numericalResult.Name = name;
			numericalResult.Unit = unit;
			numericalResult.Value = value;
			this.NumericalResultList.Add(numericalResult);
		}

		public bool GetResult(int index, out string name, out string unit, out float value)
		{
			if (index < this.NumericalResultList.Count)
			{
				name = this.NumericalResultList[index].Name;
				unit = this.NumericalResultList[index].Unit;
				value = this.NumericalResultList[index].Value;
				return true;
			}
			name = "";
			unit = "";
			value = 0f;
			return false;
		}
	}
}
