using System;

namespace WeberKXML_Data
{
	[Serializable]
	public class WSK3_HeaderStruct
	{
		private string version = "";

		private string date = "";

		private string time = "";

		private string title = "";

		private int numberofYAxes;

		private int numberOfVectors;

		public string Version
		{
			get
			{
				return this.version;
			}
			set
			{
				this.version = value;
			}
		}

		public string Date
		{
			get
			{
				return this.date;
			}
			set
			{
				this.date = value;
			}
		}

		public string Time
		{
			get
			{
				return this.time;
			}
			set
			{
				this.time = value;
			}
		}

		public string Title
		{
			get
			{
				return this.title;
			}
			set
			{
				this.title = value;
			}
		}

		public int NumberofYAxes
		{
			get
			{
				return this.numberofYAxes;
			}
			set
			{
				this.numberofYAxes = value;
			}
		}

		public int NumberOfVectors
		{
			get
			{
				return this.numberOfVectors;
			}
			set
			{
				this.numberOfVectors = value;
			}
		}

		public ControllerStruct Controller
		{
			get;
			set;
		}

		public ProcessProgStruct ProcessProg
		{
			get;
			set;
		}

		public Result Result
		{
			get;
			set;
		}

		public WSK3_HeaderStruct()
		{
			this.Controller = new ControllerStruct();
			this.ProcessProg = new ProcessProgStruct();
			this.Result = new Result();
		}
	}
}
