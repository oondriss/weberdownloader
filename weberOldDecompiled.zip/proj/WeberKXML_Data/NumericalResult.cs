using System;

namespace WeberKXML_Data
{
	[Serializable]
	public class NumericalResult
	{
		public string Name = "";

		public string Unit = "";

		public float Value;
	}
}
