using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;

namespace WUSB_KeyVerwaltung
{
	[Serializable]
	public class WUSB_Data_Class
	{
		public const string CONFIG_FILE_NAME = "wusb_configuration";

		private bool wasModified;

		public List<UserKeyfileStruct> UserKeyFileList = new List<UserKeyfileStruct>();

		private AccessAreasStruct globalAccessAreas = new AccessAreasStruct();

		public static bool XmlSerializerIsRunning;

		public string WUSB_Data_Verion
		{
			get;
			set;
		}

		public AccessAreasStruct GlobalAccessAreas
		{
			get
			{
				return this.globalAccessAreas;
			}
			set
			{
				this.globalAccessAreas = value;
			}
		}

		public bool WasModified()
		{
			if (this.wasModified)
			{
				return true;
			}
			foreach (UserKeyfileStruct userKeyFile in this.UserKeyFileList)
			{
				if (userKeyFile.WasModified())
				{
					return true;
				}
			}
			return this.globalAccessAreas.WasModified();
		}

		public void ResetModified()
		{
			this.wasModified = false;
			this.globalAccessAreas.ResetModified();
			foreach (UserKeyfileStruct userKeyFile in this.UserKeyFileList)
			{
				userKeyFile.ResetModified();
			}
		}

		public void SetModified()
		{
			this.wasModified = true;
		}

		public int GetCount()
		{
			return this.UserKeyFileList.Count();
		}

		public bool AddKey(UserKeyfileStruct userKey, int index)
		{
			if (this.existUser(userKey.GetDecryptedUserNumber(), false))
			{
				return false;
			}
			this.wasModified = true;
			if (index == -1 || index >= this.UserKeyFileList.Count)
			{
				this.UserKeyFileList.Add(userKey);
			}
			else
			{
				this.UserKeyFileList.Insert(index, userKey);
			}
			return true;
		}

		public bool ReplaceKey(UserKeyfileStruct userKey, int index)
		{
			if (this.existUser(userKey.GetDecryptedUserNumber(), true))
			{
				return false;
			}
			this.wasModified = true;
			if (index != -1 && index < this.UserKeyFileList.Count)
			{
				return true;
			}
			return false;
		}

		public bool RemoveKey(UserKeyfileStruct userKey)
		{
			if (this.existUser(userKey.GetDecryptedUserNumber(), true))
			{
				return false;
			}
			this.wasModified = true;
			this.UserKeyFileList.Remove(userKey);
			return true;
		}

		public bool DeleteKey(string userNumber)
		{
			foreach (UserKeyfileStruct userKeyFile in this.UserKeyFileList)
			{
				if (userKeyFile.GetDecryptedUserNumber() == userNumber)
				{
					this.wasModified = true;
					this.UserKeyFileList.Remove(userKeyFile);
					return true;
				}
			}
			return false;
		}

		private bool existUser(string userNumber, bool checkDouble)
		{
			foreach (UserKeyfileStruct userKeyFile in this.UserKeyFileList)
			{
				if (userKeyFile.GetDecryptedUserNumber() == userNumber.ToString())
				{
					if (!checkDouble)
					{
						return true;
					}
					checkDouble = false;
				}
			}
			return false;
		}

		public UserKeyfileStruct GetKey(string userNumber)
		{
			for (int i = 0; i < this.UserKeyFileList.Count; i++)
			{
				if (this.UserKeyFileList[i].GetDecryptedUserNumber() == userNumber)
				{
					return this.UserKeyFileList[i];
				}
			}
			return null;
		}

		public bool Read(string fileName, ref WUSB_Data_Class wusb_Data, bool filenameComplete)
		{
			bool result = true;
			FileStream fileStream = (!filenameComplete) ? new FileStream(fileName + ".bin", FileMode.OpenOrCreate) : new FileStream(fileName, FileMode.OpenOrCreate);
			if (fileStream.Length == 0)
			{
				fileStream.Close();
				fileStream.Dispose();
				return false;
			}
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			binaryFormatter.Binder = new myBinder();
			try
			{
				wusb_Data = (WUSB_Data_Class)binaryFormatter.Deserialize(fileStream);
				fileStream.Close();
				fileStream.Dispose();
				if (wusb_Data.globalAccessAreas == null)
				{
					wusb_Data.globalAccessAreas = new AccessAreasStruct();
					return result;
				}
				return result;
			}
			catch (Exception)
			{
				fileStream.Close();
				fileStream.Dispose();
				return false;
			}
		}

		public bool Write(string path, WUSB_Data_Class wusb_Data, bool filenameComplete)
		{
			bool flag = false;
			FileStream fileStream = null;
			fileStream = ((!filenameComplete) ? new FileStream(path + ".bin", FileMode.Create) : new FileStream(path, FileMode.Create));
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			binaryFormatter.AssemblyFormat = FormatterAssemblyStyle.Simple;
			try
			{
				binaryFormatter.Serialize(fileStream, wusb_Data);
				string name = fileStream.Name;
				fileStream.Close();
				fileStream.Dispose();
				flag = true;
				this.ResetModified();
				return flag;
			}
			catch (Exception)
			{
				if (fileStream != null)
				{
					fileStream.Close();
					fileStream.Dispose();
				}
				return false;
			}
		}
	}
}
