using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace WUSB_KeyVerwaltung
{
	internal class TheSecureStringClass
	{
		private const string initVector = "tu89geji340t89u2";

		private const string pPh = "a4S8P6Q";

		private const int keysize = 256;

		public static string Encrypt(string plainText)
		{
			return TheSecureStringClass.Encrypt(plainText + TheSecureStringClass.RandomString(10, false), "a4S8P6Q");
		}

		private static string Encrypt(string plainText, string passPhrase)
		{
			try
			{
				byte[] bytes = Encoding.UTF8.GetBytes("tu89geji340t89u2");
				byte[] bytes2 = Encoding.UTF8.GetBytes(plainText);
				PasswordDeriveBytes passwordDeriveBytes = new PasswordDeriveBytes(passPhrase, null);
				byte[] bytes3 = passwordDeriveBytes.GetBytes(32);
				RijndaelManaged rijndaelManaged = new RijndaelManaged();
				rijndaelManaged.Mode = CipherMode.CBC;
				ICryptoTransform transform = rijndaelManaged.CreateEncryptor(bytes3, bytes);
				MemoryStream memoryStream = new MemoryStream();
				CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write);
				cryptoStream.Write(bytes2, 0, bytes2.Length);
				cryptoStream.FlushFinalBlock();
				byte[] inArray = memoryStream.ToArray();
				memoryStream.Close();
				cryptoStream.Close();
				return Convert.ToBase64String(inArray);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Encrypt");
				return "";
			}
		}

		public static string Decrypt(string cipherText)
		{
			if (cipherText != null && cipherText.Length != 0)
			{
				string text = TheSecureStringClass.Decrypt(cipherText, "a4S8P6Q");
				return text.Remove(text.Length - 10);
			}
			return "";
		}

		private static string Decrypt(string cipherText, string passPhrase)
		{
			try
			{
				byte[] bytes = Encoding.ASCII.GetBytes("tu89geji340t89u2");
				byte[] array = Convert.FromBase64String(cipherText);
				PasswordDeriveBytes passwordDeriveBytes = new PasswordDeriveBytes(passPhrase, null);
				byte[] bytes2 = passwordDeriveBytes.GetBytes(32);
				RijndaelManaged rijndaelManaged = new RijndaelManaged();
				rijndaelManaged.Mode = CipherMode.CBC;
				ICryptoTransform transform = rijndaelManaged.CreateDecryptor(bytes2, bytes);
				MemoryStream memoryStream = new MemoryStream(array);
				CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Read);
				byte[] array2 = new byte[array.Length];
				int count = cryptoStream.Read(array2, 0, array2.Length);
				memoryStream.Close();
				cryptoStream.Close();
				return Encoding.UTF8.GetString(array2, 0, count);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Decrypt");
				return "0000000000";
			}
		}

		private static string RandomString(int size, bool lowerCase)
		{
			StringBuilder stringBuilder = new StringBuilder();
			Random random = new Random();
			for (int i = 0; i < size; i++)
			{
				char value = Convert.ToChar(Convert.ToInt32(Math.Floor(26.0 * random.NextDouble() + 65.0)));
				stringBuilder.Append(value);
			}
			if (lowerCase)
			{
				return stringBuilder.ToString().ToLower();
			}
			return stringBuilder.ToString();
		}
	}
}
