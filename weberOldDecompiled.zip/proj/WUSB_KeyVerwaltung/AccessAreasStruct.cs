using System;
using System.Collections.Generic;

namespace WUSB_KeyVerwaltung
{
	[Serializable]
	public class AccessAreasStruct
	{
		private List<string> accessAreas = new List<string>();

		private bool wasModified;

		public List<string> AccessAreas
		{
			get
			{
				return this.accessAreas;
			}
			set
			{
				this.accessAreas = value;
			}
		}

		public int Count => this.accessAreas.Count;

		public void Add(string area)
		{
			this.wasModified = true;
			this.accessAreas.Add(TheSecureStringClass.Encrypt(area));
		}

		public void DeleteAll()
		{
			if (this.accessAreas.Count > 0)
			{
				this.wasModified = true;
			}
			this.accessAreas.Clear();
		}

		public bool WasModified()
		{
			return this.wasModified;
		}

		public void ResetModified()
		{
			this.wasModified = false;
		}

		public string GetArea(int index)
		{
			if (index < this.Count)
			{
				return this.accessAreas[index];
			}
			return "";
		}

		public string GetDecryptedArea(int index)
		{
			return TheSecureStringClass.Decrypt(this.GetArea(index));
		}

		public void ReplaceAreas(AccessAreasStruct areas)
		{
			this.wasModified = true;
			this.accessAreas.Clear();
			for (int i = 0; i < areas.Count; i++)
			{
				this.accessAreas.Add(areas.GetArea(i));
			}
		}
	}
}
