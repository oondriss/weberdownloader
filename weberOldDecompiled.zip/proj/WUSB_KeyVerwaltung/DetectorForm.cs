using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace WUSB_KeyVerwaltung
{
	internal class DetectorForm : Form
	{
		private Label label1;

		private IContainer components;

		private Timer timer1;

		private Timer timerPollDrives;

		private DriveDetector mDetector;

		private DriveInformationClass recentDriveInformation = new DriveInformationClass();

		public DetectorForm(DriveDetector detector)
		{
			this.mDetector = detector;
			base.MinimizeBox = false;
			base.MaximizeBox = false;
			base.ShowInTaskbar = false;
			base.ShowIcon = false;
			base.FormBorderStyle = FormBorderStyle.None;
			base.Load += this.Load_Form;
			base.Activated += this.Form_Activated;
		}

		private void Load_Form(object sender, EventArgs e)
		{
			this.InitializeComponent();
			base.Size = new Size(5, 5);
		}

		private void Form_Activated(object sender, EventArgs e)
		{
			base.Visible = false;
		}

		protected override void WndProc(ref Message m)
		{
			base.WndProc(ref m);
			if (this.mDetector != null)
			{
				this.mDetector.WndProc(ref m);
			}
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			this.label1 = new Label();
			this.timer1 = new Timer(this.components);
			this.timerPollDrives = new Timer(this.components);
			base.SuspendLayout();
			this.label1.AutoSize = true;
			this.label1.Location = new Point(13, 30);
			this.label1.Name = "label1";
			this.label1.Size = new Size(314, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "This is invisible form. To see DriveDetector code click View Code";
			this.timer1.Enabled = true;
			this.timer1.Tick += this.timer1_Tick;
			this.timerPollDrives.Interval = 3000;
			this.timerPollDrives.Tick += this.timerPollDrives_Tick;
			base.ClientSize = new Size(360, 80);
			base.ControlBox = false;
			base.Controls.Add(this.label1);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "DetectorForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public void ResetDriveInformation()
		{
			if (this.recentDriveInformation != null)
			{
				this.recentDriveInformation.DeleteAll();
			}
		}

		public bool IsDriveConnected(string checkForDriveName)
		{
			DriveInfo[] drives = DriveInfo.GetDrives();
			string text = "";
			DriveInfo[] array = drives;
			foreach (DriveInfo driveInfo in array)
			{
				text = driveInfo.Name;
				switch (driveInfo.DriveType)
				{
				case DriveType.Removable:
					if (text.Length <= 0)
					{
						break;
					}
					if (!(text == checkForDriveName))
					{
						break;
					}
					return true;
				}
			}
			return false;
		}

		private string DetectRemovableDevice()
		{
			OperatingSystem oSVersion = Environment.OSVersion;
			if (oSVersion.Platform == PlatformID.Win32NT && oSVersion.Version.Major == 5)
			{
				return "";
			}
			DriveInformationClass driveInformationClass = new DriveInformationClass();
			string result = "";
			DriveInfo[] drives = DriveInfo.GetDrives();
			string text = "";
			DriveInfo[] array = drives;
			foreach (DriveInfo driveInfo in array)
			{
				text = driveInfo.Name;
				switch (driveInfo.DriveType)
				{
				case DriveType.Removable:
					driveInformationClass.Add(text, true);
					break;
				}
			}
			if (this.mDetector.DriveInformation.Count == driveInformationClass.Count)
			{
				bool flag = false;
				string device = "";
				for (int j = 0; j < this.recentDriveInformation.Count; j++)
				{
					string driveName = this.recentDriveInformation.GetDriveName(j);
					for (int k = 0; k < driveInformationClass.Count; k++)
					{
						string driveName2 = driveInformationClass.GetDriveName(k);
						if (driveName2 == driveName)
						{
							DateTime driveTimestamp = driveInformationClass.GetDriveTimestamp(k);
							DateTime driveTimestamp2 = this.recentDriveInformation.GetDriveTimestamp(j);
							if (driveTimestamp != driveTimestamp2)
							{
								flag = true;
								device = driveName2;
							}
							break;
						}
					}
				}
				if (flag)
				{
					this.mDetector.DriveInformation.DeleteAll();
					for (int l = 0; l < driveInformationClass.Count; l++)
					{
						this.mDetector.DriveInformation.Add(driveInformationClass.GetDriveList()[l]);
					}
					this.mDetector.TellDriveContentChanged(device);
				}
				this.recentDriveInformation.DeleteAll();
				DriveInfo[] array2 = drives;
				foreach (DriveInfo driveInfo2 in array2)
				{
					text = driveInfo2.Name;
					switch (driveInfo2.DriveType)
					{
					case DriveType.Removable:
						this.recentDriveInformation.Add(text, true);
						break;
					}
				}
			}
			else if (this.mDetector.DriveInformation.Count > driveInformationClass.Count)
			{
				for (int n = 0; n < this.mDetector.DriveInformation.Count; n++)
				{
					int num = 0;
					string driveName3 = this.mDetector.DriveInformation.GetDriveName(n);
					for (int num2 = 0; num2 < driveInformationClass.Count; num2++)
					{
						if (driveName3 == driveInformationClass.GetDriveName(num2))
						{
							num++;
						}
					}
					if (num != 1)
					{
						this.mDetector.DriveInformation.Delete(n);
						this.mDetector.TellDeviceRemoved(driveName3);
					}
				}
			}
			else
			{
				for (int num3 = 0; num3 < driveInformationClass.Count; num3++)
				{
					bool flag2 = false;
					string driveName4 = driveInformationClass.GetDriveName(num3);
					int num4 = 0;
					while (num4 < this.mDetector.DriveInformation.Count)
					{
						if (!(this.mDetector.DriveInformation.GetDriveName(num4) == driveName4))
						{
							num4++;
							continue;
						}
						flag2 = true;
						break;
					}
					if (!flag2)
					{
						this.mDetector.DriveInformation.Add(driveName4, true);
						this.mDetector.TellDeviceArrived(driveName4);
					}
				}
			}
			return result;
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			this.timer1.Stop();
			this.DetectRemovableDevice();
			this.timerPollDrives.Start();
		}

		private void timerPollDrives_Tick(object sender, EventArgs e)
		{
			this.timerPollDrives.Stop();
			this.DetectRemovableDevice();
			this.timerPollDrives.Start();
		}
	}
}
