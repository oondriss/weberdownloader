namespace WUSB_KeyVerwaltung
{
	public delegate void DriveDetectorEventHandler(object sender, DriveDetectorEventArgs e);
}
