using Microsoft.Win32.SafeHandles;
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace WUSB_KeyVerwaltung
{
	internal class DriveDetector : IDisposable
	{
		private class Native
		{
			private const uint GENERIC_READ = 2147483648u;

			private const uint OPEN_EXISTING = 3u;

			private const uint FILE_SHARE_READ = 1u;

			private const uint FILE_SHARE_WRITE = 2u;

			private const uint FILE_ATTRIBUTE_NORMAL = 128u;

			private const uint FILE_FLAG_BACKUP_SEMANTICS = 33554432u;

			private static readonly IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1);

			[DllImport("user32.dll", CharSet = CharSet.Auto)]
			public static extern IntPtr RegisterDeviceNotification(IntPtr hRecipient, IntPtr NotificationFilter, uint Flags);

			[DllImport("user32.dll", CharSet = CharSet.Auto)]
			public static extern uint UnregisterDeviceNotification(IntPtr hHandle);

			[DllImport("kernel32", SetLastError = true)]
			private static extern IntPtr CreateFile(string FileName, uint DesiredAccess, uint ShareMode, uint SecurityAttributes, uint CreationDisposition, uint FlagsAndAttributes, int hTemplateFile);

			[DllImport("kernel32", SetLastError = true)]
			private static extern bool CloseHandle(IntPtr hObject);

			public static IntPtr OpenDirectory(string dirPath)
			{
				IntPtr intPtr = IntPtr.Zero;
				if (Directory.Exists(dirPath))
				{
					intPtr = Native.CreateFile(dirPath, 2147483648u, 3u, 0u, 3u, 33554560u, 0);
				}
				if (intPtr == Native.INVALID_HANDLE_VALUE)
				{
					return IntPtr.Zero;
				}
				return intPtr;
			}

			public static bool CloseDirectoryHandle(IntPtr handle)
			{
				return Native.CloseHandle(handle);
			}
		}

		public struct DEV_BROADCAST_HANDLE
		{
			public int dbch_size;

			public int dbch_devicetype;

			public int dbch_reserved;

			public IntPtr dbch_handle;

			public IntPtr dbch_hdevnotify;

			public Guid dbch_eventguid;

			public long dbch_nameoffset;

			public byte dbch_data;

			public byte dbch_data1;
		}

		public struct DEV_BROADCAST_VOLUME
		{
			public int dbcv_size;

			public int dbcv_devicetype;

			public int dbcv_reserved;

			public int dbcv_unitmask;
		}

		private const int DBT_DEVTYP_DEVICEINTERFACE = 5;

		private const int DBT_DEVTYP_HANDLE = 6;

		private const int BROADCAST_QUERY_DENY = 1112363332;

		private const int WM_DEVICECHANGE = 537;

		private const int DBT_DEVICEARRIVAL = 32768;

		private const int DBT_DEVICEQUERYREMOVE = 32769;

		private const int DBT_DEVICEREMOVECOMPLETE = 32772;

		private const int DBT_DEVTYP_VOLUME = 2;

		private DriveInformationClass driveInformation = new DriveInformationClass();

		private DetectorForm frm;

		private IntPtr mDirHandle = IntPtr.Zero;

		private FileStream mFileOnFlash;

		private string mFileToOpen;

		private IntPtr mDeviceNotifyHandle;

		private IntPtr mRecipientHandle;

		private string mCurrentDrive;

		public DriveInformationClass DriveInformation => this.driveInformation;

		public bool IsQueryHooked
		{
			get
			{
				if (this.mDeviceNotifyHandle == IntPtr.Zero)
				{
					return false;
				}
				return true;
			}
		}

		public string HookedDrive => this.mCurrentDrive;

		public FileStream OpenedFile => this.mFileOnFlash;

		public event DriveDetectorEventHandler DeviceArrived;

		public event DriveDetectorEventHandler DeviceContentChanged;

		public event DriveDetectorEventHandler DeviceRemoved;

		public event DriveDetectorEventHandler QueryRemove;

		public DriveDetector()
		{
			this.frm = new DetectorForm(this);
			this.frm.Show();
			this.Init(this.frm, null);
		}

		public bool IsDriveConnected(string drive)
		{
			if (this.frm != null)
			{
				return this.frm.IsDriveConnected(drive);
			}
			return false;
		}

		public void Clear()
		{
			this.Dispose();
		}

		public DriveDetector(Control control)
		{
			this.Init(control, null);
		}

		public DriveDetector(Control control, string FileToOpen)
		{
			this.Init(control, FileToOpen);
		}

		private void Init(Control control, string fileToOpen)
		{
			this.mFileToOpen = fileToOpen;
			this.mFileOnFlash = null;
			this.mDeviceNotifyHandle = IntPtr.Zero;
			this.mRecipientHandle = control.Handle;
			this.mDirHandle = IntPtr.Zero;
			this.mCurrentDrive = "";
		}

		public void ResetDriveInformation()
		{
			if (this.driveInformation != null)
			{
				this.driveInformation.DeleteAll();
			}
		}

		public bool EnableQueryRemove(string fileOnDrive)
		{
			if (fileOnDrive != null && fileOnDrive.Length != 0)
			{
				if (fileOnDrive.Length == 2 && fileOnDrive[1] == ':')
				{
					fileOnDrive += '\\';
				}
				if (this.mDeviceNotifyHandle != IntPtr.Zero)
				{
					this.RegisterForDeviceChange(false, null);
				}
				if (Path.GetFileName(fileOnDrive).Length == 0 || !File.Exists(fileOnDrive))
				{
					this.mFileToOpen = null;
				}
				else
				{
					this.mFileToOpen = fileOnDrive;
				}
				this.RegisterQuery(Path.GetPathRoot(fileOnDrive));
				if (this.mDeviceNotifyHandle == IntPtr.Zero)
				{
					return false;
				}
				return true;
			}
			throw new ArgumentException("Drive path must be supplied to register for Query remove.");
		}

		public void DisableQueryRemove()
		{
			if (this.mDeviceNotifyHandle != IntPtr.Zero)
			{
				this.RegisterForDeviceChange(false, null);
			}
		}

		public void Dispose()
		{
			this.RegisterForDeviceChange(false, null);
		}

		public void WndProc(ref Message m)
		{
			if (m.Msg == 537)
			{
				switch (m.WParam.ToInt32())
				{
				case 32770:
				case 32771:
					break;
				case 32768:
				{
					int num = Marshal.ReadInt32(m.LParam, 4);
					if (num == 2)
					{
						DEV_BROADCAST_VOLUME dEV_BROADCAST_VOLUME2 = (DEV_BROADCAST_VOLUME)Marshal.PtrToStructure(m.LParam, typeof(DEV_BROADCAST_VOLUME));
						char c = DriveDetector.DriveMaskToLetter(dEV_BROADCAST_VOLUME2.dbcv_unitmask);
						DriveDetectorEventHandler deviceArrived = this.DeviceArrived;
						if (deviceArrived != null)
						{
							DriveDetectorEventArgs driveDetectorEventArgs2 = new DriveDetectorEventArgs();
							driveDetectorEventArgs2.Drive = c + ":\\";
							this.driveInformation.Add(driveDetectorEventArgs2.Drive, true);
							deviceArrived(this, driveDetectorEventArgs2);
							if (driveDetectorEventArgs2.HookQueryRemove)
							{
								if (this.mDeviceNotifyHandle != IntPtr.Zero)
								{
									this.RegisterForDeviceChange(false, null);
								}
								this.RegisterQuery(c + ":\\");
							}
						}
					}
					break;
				}
				case 32769:
				{
					int num = Marshal.ReadInt32(m.LParam, 4);
					if (num == 6)
					{
						DriveDetectorEventHandler queryRemove = this.QueryRemove;
						if (queryRemove != null)
						{
							DriveDetectorEventArgs driveDetectorEventArgs3 = new DriveDetectorEventArgs();
							driveDetectorEventArgs3.Drive = this.mCurrentDrive;
							queryRemove(this, driveDetectorEventArgs3);
							if (driveDetectorEventArgs3.Cancel)
							{
								m.Result = (IntPtr)1112363332;
							}
							else
							{
								this.RegisterForDeviceChange(false, null);
							}
						}
					}
					break;
				}
				case 32772:
				{
					int num = Marshal.ReadInt32(m.LParam, 4);
					if (num != 2 && num != 6)
					{
						break;
					}
					num = Marshal.ReadInt32(m.LParam, 4);
					if (num != 2 && num != 6)
					{
						break;
					}
					DEV_BROADCAST_VOLUME dEV_BROADCAST_VOLUME = (DEV_BROADCAST_VOLUME)Marshal.PtrToStructure(m.LParam, typeof(DEV_BROADCAST_VOLUME));
					char c = DriveDetector.DriveMaskToLetter(dEV_BROADCAST_VOLUME.dbcv_unitmask);
					DriveDetectorEventHandler deviceRemoved = this.DeviceRemoved;
					if (deviceRemoved != null)
					{
						DriveDetectorEventArgs driveDetectorEventArgs = new DriveDetectorEventArgs();
						driveDetectorEventArgs.Drive = c + ":\\";
						this.driveInformation.Delete(driveDetectorEventArgs.Drive);
						deviceRemoved(this, driveDetectorEventArgs);
					}
					break;
				}
				}
			}
		}

		public void TellDeviceArrived(string device)
		{
			DriveDetectorEventHandler deviceArrived = this.DeviceArrived;
			if (deviceArrived != null)
			{
				DriveDetectorEventArgs driveDetectorEventArgs = new DriveDetectorEventArgs();
				driveDetectorEventArgs.Drive = device;
				deviceArrived(this, driveDetectorEventArgs);
				if (driveDetectorEventArgs.HookQueryRemove)
				{
					if (this.mDeviceNotifyHandle != IntPtr.Zero)
					{
						this.RegisterForDeviceChange(false, null);
					}
					this.RegisterQuery(device);
				}
			}
		}

		public void TellDeviceRemoved(string device)
		{
			DriveDetectorEventHandler deviceRemoved = this.DeviceRemoved;
			if (deviceRemoved != null)
			{
				DriveDetectorEventArgs driveDetectorEventArgs = new DriveDetectorEventArgs();
				driveDetectorEventArgs.Drive = device;
				this.driveInformation.Delete(driveDetectorEventArgs.Drive);
				deviceRemoved(this, driveDetectorEventArgs);
			}
		}

		public void TellDriveContentChanged(string device)
		{
			DriveDetectorEventHandler deviceContentChanged = this.DeviceContentChanged;
			if (deviceContentChanged != null)
			{
				DriveDetectorEventArgs driveDetectorEventArgs = new DriveDetectorEventArgs();
				driveDetectorEventArgs.Drive = device;
				deviceContentChanged(this, driveDetectorEventArgs);
			}
		}

		private void RegisterQuery(string drive)
		{
			bool flag = true;
			if (this.mFileToOpen != null)
			{
				if (this.mFileToOpen.Contains(":"))
				{
					string path = this.mFileToOpen.Substring(3);
					string pathRoot = Path.GetPathRoot(drive);
					this.mFileToOpen = Path.Combine(pathRoot, path);
				}
				else
				{
					this.mFileToOpen = Path.Combine(drive, this.mFileToOpen);
				}
			}
			try
			{
				if (this.mFileToOpen == null)
				{
					this.mFileOnFlash = null;
				}
				else
				{
					this.mFileOnFlash = new FileStream(this.mFileToOpen, FileMode.Open);
				}
			}
			catch (Exception)
			{
				flag = false;
			}
			if (flag)
			{
				if (this.mFileOnFlash == null)
				{
					this.RegisterForDeviceChange(drive);
				}
				else
				{
					this.RegisterForDeviceChange(true, this.mFileOnFlash.SafeFileHandle);
				}
				this.mCurrentDrive = drive;
			}
		}

		private void RegisterForDeviceChange(string dirPath)
		{
			IntPtr intPtr = Native.OpenDirectory(dirPath);
			if (intPtr == IntPtr.Zero)
			{
				this.mDeviceNotifyHandle = IntPtr.Zero;
			}
			else
			{
				this.mDirHandle = intPtr;
				DEV_BROADCAST_HANDLE dEV_BROADCAST_HANDLE = default(DEV_BROADCAST_HANDLE);
				dEV_BROADCAST_HANDLE.dbch_devicetype = 6;
				dEV_BROADCAST_HANDLE.dbch_reserved = 0;
				dEV_BROADCAST_HANDLE.dbch_nameoffset = 0L;
				dEV_BROADCAST_HANDLE.dbch_handle = intPtr;
				dEV_BROADCAST_HANDLE.dbch_hdevnotify = (IntPtr)0;
				IntPtr intPtr2 = Marshal.AllocHGlobal(dEV_BROADCAST_HANDLE.dbch_size = Marshal.SizeOf((object)dEV_BROADCAST_HANDLE));
				Marshal.StructureToPtr((object)dEV_BROADCAST_HANDLE, intPtr2, true);
				this.mDeviceNotifyHandle = Native.RegisterDeviceNotification(this.mRecipientHandle, intPtr2, 0u);
			}
		}

		private void RegisterForDeviceChange(bool register, SafeFileHandle fileHandle)
		{
			if (register)
			{
				DEV_BROADCAST_HANDLE dEV_BROADCAST_HANDLE = default(DEV_BROADCAST_HANDLE);
				dEV_BROADCAST_HANDLE.dbch_devicetype = 6;
				dEV_BROADCAST_HANDLE.dbch_reserved = 0;
				dEV_BROADCAST_HANDLE.dbch_nameoffset = 0L;
				dEV_BROADCAST_HANDLE.dbch_handle = fileHandle.DangerousGetHandle();
				dEV_BROADCAST_HANDLE.dbch_hdevnotify = (IntPtr)0;
				IntPtr intPtr = Marshal.AllocHGlobal(dEV_BROADCAST_HANDLE.dbch_size = Marshal.SizeOf((object)dEV_BROADCAST_HANDLE));
				Marshal.StructureToPtr((object)dEV_BROADCAST_HANDLE, intPtr, true);
				this.mDeviceNotifyHandle = Native.RegisterDeviceNotification(this.mRecipientHandle, intPtr, 0u);
			}
			else
			{
				if (this.mDirHandle != IntPtr.Zero)
				{
					Native.CloseDirectoryHandle(this.mDirHandle);
				}
				if (this.mDeviceNotifyHandle != IntPtr.Zero)
				{
					Native.UnregisterDeviceNotification(this.mDeviceNotifyHandle);
				}
				this.mDeviceNotifyHandle = IntPtr.Zero;
				this.mDirHandle = IntPtr.Zero;
				this.mCurrentDrive = "";
				if (this.mFileOnFlash != null)
				{
					this.mFileOnFlash.Close();
					this.mFileOnFlash = null;
				}
			}
		}

		private static char DriveMaskToLetter(int mask)
		{
			string text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			int num = 0;
			int num2 = mask / 2;
			while (num2 != 0)
			{
				num2 /= 2;
				num++;
			}
			if (num < text.Length)
			{
				return text[num];
			}
			return '?';
		}
	}
}
