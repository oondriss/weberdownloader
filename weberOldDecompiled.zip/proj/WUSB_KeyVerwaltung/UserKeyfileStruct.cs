using System;
using System.IO;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;

namespace WUSB_KeyVerwaltung
{
	[Serializable]
	public class UserKeyfileStruct
	{
		private bool wasModified;

		private string userPrivateName = "";

		private string userNumber = "";

		private string accessLevel = "";

		private string password = "";

		private bool passwordChanged;

		private string timeLimitation = "";

		private string hw_ID_of_stick = "";

		private bool hw_ID_of_stickStored;

		private string usedDongleName = "";

		private AccessAreasStruct accessAreas = new AccessAreasStruct();

		private UserPrivateInformationSturct userPrivateInformation = new UserPrivateInformationSturct();

		public string UserPrivateName
		{
			get
			{
				return this.userPrivateName;
			}
			set
			{
				if (this.userPrivateName != value)
				{
					this.wasModified = true;
				}
				if (!WUSB_Data_Class.XmlSerializerIsRunning)
				{
					this.userPrivateName = TheSecureStringClass.Encrypt(value);
				}
				else
				{
					this.userPrivateName = value;
				}
			}
		}

		public string UserNumber
		{
			get
			{
				return this.userNumber;
			}
			set
			{
				if (this.userNumber != value)
				{
					this.wasModified = true;
				}
				if (!WUSB_Data_Class.XmlSerializerIsRunning)
				{
					this.userNumber = TheSecureStringClass.Encrypt(value);
				}
				else
				{
					this.userNumber = value;
				}
			}
		}

		public string AccessLevel
		{
			get
			{
				return this.accessLevel;
			}
			set
			{
				if (this.accessLevel != value)
				{
					this.wasModified = true;
				}
				if (!WUSB_Data_Class.XmlSerializerIsRunning)
				{
					this.accessLevel = TheSecureStringClass.Encrypt(value);
				}
				else
				{
					this.accessLevel = value;
				}
			}
		}

		public string Password
		{
			get
			{
				return this.password;
			}
			set
			{
				if (this.password != value)
				{
					this.wasModified = true;
				}
				this.passwordChanged = true;
				if (!WUSB_Data_Class.XmlSerializerIsRunning)
				{
					this.password = MD5HashClass.MD5Hash(value);
				}
				else
				{
					this.password = value;
				}
			}
		}

		public string TimeLimitation
		{
			get
			{
				return this.timeLimitation;
			}
			set
			{
				if (this.timeLimitation != value)
				{
					this.wasModified = true;
				}
				if (!WUSB_Data_Class.XmlSerializerIsRunning)
				{
					this.timeLimitation = TheSecureStringClass.Encrypt(value);
				}
				else
				{
					this.timeLimitation = value;
				}
			}
		}

		public string HW_ID_of_stick
		{
			get
			{
				return this.hw_ID_of_stick;
			}
			set
			{
				if (this.hw_ID_of_stick != value)
				{
					this.wasModified = true;
				}
				if (!WUSB_Data_Class.XmlSerializerIsRunning)
				{
					this.hw_ID_of_stick = TheSecureStringClass.Encrypt(value);
				}
				else
				{
					this.hw_ID_of_stick = value;
				}
			}
		}

		public bool HW_ID_of_stickStored
		{
			get
			{
				return this.hw_ID_of_stickStored;
			}
			set
			{
				if (this.hw_ID_of_stickStored != value)
				{
					this.wasModified = true;
				}
				this.hw_ID_of_stickStored = value;
			}
		}

		public string UsedDongleName
		{
			get
			{
				return this.usedDongleName;
			}
			set
			{
				if (!WUSB_Data_Class.XmlSerializerIsRunning)
				{
					this.usedDongleName = TheSecureStringClass.Encrypt(value);
				}
				else
				{
					this.usedDongleName = value;
				}
			}
		}

		public AccessAreasStruct AccessAreas => this.accessAreas;

		public UserPrivateInformationSturct UserPrivateInformation => this.userPrivateInformation;

		public bool WasModified()
		{
			return this.wasModified;
		}

		public void ResetModified()
		{
			this.wasModified = false;
		}

		public string GetDecryptedUserPrivateName()
		{
			return TheSecureStringClass.Decrypt(this.userPrivateName);
		}

		public string GetDecryptedUserNumber()
		{
			return TheSecureStringClass.Decrypt(this.userNumber);
		}

		private string GetDecryptedAccessLevel()
		{
			return TheSecureStringClass.Decrypt(this.accessLevel);
		}

		public int GetAccessLevel()
		{
			string decryptedAccessLevel = this.GetDecryptedAccessLevel();
			if (decryptedAccessLevel.Length > 0)
			{
				try
				{
					return int.Parse(decryptedAccessLevel);
				}
				catch (Exception)
				{
				}
			}
			return -1;
		}

		public void SetAccessLevel(int level)
		{
			this.AccessLevel = level.ToString();
		}

		public bool PasswordChanged()
		{
			return this.passwordChanged;
		}

		public string GetDecryptedTimeLimitation()
		{
			return TheSecureStringClass.Decrypt(this.timeLimitation);
		}

		public string GetDecryptedHW_ID_of_stick()
		{
			return TheSecureStringClass.Decrypt(this.hw_ID_of_stick);
		}

		public string GetUsedDongleName()
		{
			return TheSecureStringClass.Decrypt(this.usedDongleName);
		}

		public void AddAccessArea(string area)
		{
			this.accessAreas.Add(area);
		}

		public void ReplaceAreas(AccessAreasStruct areas)
		{
			this.accessAreas.ReplaceAreas(areas);
		}

		public string GetDecryptedArea(int index)
		{
			return this.accessAreas.GetDecryptedArea(index);
		}

		public bool Read(string fileName, ref UserKeyfileStruct wusb_Data)
		{
			bool result = true;
			FileStream fileStream = null;
			BinaryFormatter binaryFormatter = null;
			try
			{
				fileStream = new FileStream(fileName + ".bin", FileMode.Open);
				binaryFormatter = new BinaryFormatter();
				binaryFormatter.Binder = new myBinder();
				wusb_Data = (UserKeyfileStruct)binaryFormatter.Deserialize(fileStream);
				fileStream.Close();
				fileStream.Dispose();
				return result;
			}
			catch (Exception)
			{
				fileStream?.Close();
				return false;
			}
		}

		public bool Write(string path, UserKeyfileStruct wusb_Data)
		{
			bool flag = false;
			FileStream fileStream = null;
			fileStream = new FileStream(path + ".bin", FileMode.Create);
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			binaryFormatter.AssemblyFormat = FormatterAssemblyStyle.Simple;
			try
			{
				binaryFormatter.Serialize(fileStream, wusb_Data);
				string name = fileStream.Name;
				fileStream.Close();
				fileStream.Dispose();
				flag = true;
				this.wasModified = false;
				return flag;
			}
			catch (Exception)
			{
				fileStream?.Close();
				return false;
			}
		}
	}
}
