using Program.getHardwareId;
using System;
using System.IO;

namespace WUSB_KeyVerwaltung
{
	internal class UsbFileSystemClass
	{
		public const int LENGTH_OF_USER_NAME = 4;

		public const int LENGTH_OF_PASSWORD = 4;

		public const string USB_FILE_NAME = "Keyfiles_WEBER\\keyfile.xml";

		private string usb_Drive = "";

		private HardwareHelperClass hardwareHelper = new HardwareHelperClass();

		private bool recentlyReadUsbKeyFileValid = true;

		private bool recentlyReadUsbKeyFileEmpty = true;

		public string UsbDrive
		{
			get
			{
				return this.usb_Drive;
			}
			set
			{
				this.usb_Drive = value;
			}
		}

		public bool RecentlyReadUsbKeyFileValid => this.recentlyReadUsbKeyFileValid;

		public bool RecentlyReadUsbKeyFileEmpty => this.recentlyReadUsbKeyFileEmpty;

		private bool weberUsbSettingsValid(string usbDrive, ref UserKeyfileStruct userKey)
		{
			if (userKey == null)
			{
				return false;
			}
			string decryptedHW_ID_of_stick = userKey.GetDecryptedHW_ID_of_stick();
			string volumeSerialID = this.hardwareHelper.GetVolumeSerialID(usbDrive);
			if (decryptedHW_ID_of_stick == volumeSerialID)
			{
				return true;
			}
			return false;
		}

		public bool KeyFilePresent(string usbDrive)
		{
			string str = usbDrive + "Keyfiles_WEBER\\keyfile.xml";
			return File.Exists(str + ".bin");
		}

		public bool WriteUsbKeyFile(string usbDrive, UserKeyfileStruct userKey, out DateTime timestamp)
		{
			timestamp = DateTime.MinValue;
			if (usbDrive != null)
			{
				this.usb_Drive = usbDrive;
			}
			if (this.usb_Drive.Length == 0)
			{
				return false;
			}
			string text = this.usb_Drive + "Keyfiles_WEBER\\keyfile.xml";
			if (!Directory.Exists(Path.GetDirectoryName(text)))
			{
				try
				{
					Directory.CreateDirectory(Path.GetDirectoryName(text));
				}
				catch (Exception)
				{
					return false;
				}
			}
			userKey.HW_ID_of_stick = this.hardwareHelper.GetVolumeSerialID(usbDrive);
			timestamp = File.GetLastWriteTime(text + ".bin");
			return userKey.Write(text, userKey);
		}

		public bool ReadUsbKeyFile(string usbDrive, ref UserKeyfileStruct userKey, out DateTime timestamp)
		{
			this.recentlyReadUsbKeyFileValid = false;
			this.recentlyReadUsbKeyFileEmpty = false;
			timestamp = DateTime.MinValue;
			if (usbDrive != null)
			{
				this.usb_Drive = usbDrive;
			}
			if (this.usb_Drive.Length == 0)
			{
				return false;
			}
			string text = this.usb_Drive + "Keyfiles_WEBER\\keyfile.xml";
			if (!File.Exists(text + ".bin"))
			{
				this.recentlyReadUsbKeyFileEmpty = true;
				return false;
			}
			timestamp = File.GetLastWriteTime(text + ".bin");
			if (!userKey.Read(text, ref userKey))
			{
				return false;
			}
			this.recentlyReadUsbKeyFileValid = this.weberUsbSettingsValid(usbDrive, ref userKey);
			return true;
		}
	}
}
