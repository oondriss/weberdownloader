using System;

namespace WUSB_KeyVerwaltung
{
	internal class DriveContentClass
	{
		private string removableDriveName = "";

		private bool isValidUsbKey;

		private bool isEmpty;

		private DateTime timestamp_usb_key_file = DateTime.MinValue;

		private UserKeyfileStruct userKeyfileContent;

		public string RemovableDriveName
		{
			get
			{
				return this.removableDriveName;
			}
			set
			{
				this.removableDriveName = value;
			}
		}

		public bool IsValidUsbKey
		{
			get
			{
				return this.isValidUsbKey;
			}
			set
			{
				this.isValidUsbKey = value;
			}
		}

		public bool IsEmpty
		{
			get
			{
				return this.isEmpty;
			}
			set
			{
				this.isEmpty = value;
			}
		}

		public DateTime Timestamp_usb_key_file
		{
			get
			{
				return this.timestamp_usb_key_file;
			}
			set
			{
				this.timestamp_usb_key_file = value;
			}
		}

		public UserKeyfileStruct UserKeyfileContent
		{
			get
			{
				return this.userKeyfileContent;
			}
			set
			{
				this.userKeyfileContent = value;
			}
		}

		public DriveContentClass()
		{
		}

		public DriveContentClass(string driveName)
		{
			this.removableDriveName = driveName;
		}
	}
}
