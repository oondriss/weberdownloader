using System;

namespace WUSB_KeyVerwaltung
{
	[Serializable]
	public class UserPrivateInformationSturct
	{
		public string Name;
	}
}
