using System.Security.Cryptography;
using System.Text;

namespace WUSB_KeyVerwaltung
{
	public static class MD5HashClass
	{
		public static string MD5Hash(string text)
		{
			MD5 mD = new MD5CryptoServiceProvider();
			mD.ComputeHash(Encoding.ASCII.GetBytes(text));
			byte[] hash = mD.Hash;
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < hash.Length; i++)
			{
				stringBuilder.Append(hash[i].ToString("x2"));
			}
			return stringBuilder.ToString();
		}
	}
}
