using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace WUSB_KeyVerwaltung
{
	public class _DataEncryptor
	{
		private TripleDESCryptoServiceProvider symm;

		public TripleDESCryptoServiceProvider Algorithm
		{
			get
			{
				return this.symm;
			}
			set
			{
				this.symm = value;
			}
		}

		public byte[] Key
		{
			get
			{
				return this.symm.Key;
			}
			set
			{
				this.symm.Key = value;
			}
		}

		public byte[] IV
		{
			get
			{
				return this.symm.IV;
			}
			set
			{
				this.symm.IV = value;
			}
		}

		public _DataEncryptor()
		{
			this.symm = new TripleDESCryptoServiceProvider();
			this.symm.Padding = PaddingMode.PKCS7;
		}

		public _DataEncryptor(TripleDESCryptoServiceProvider keys)
		{
			this.symm = keys;
		}

		public _DataEncryptor(byte[] key, byte[] iv)
		{
			this.symm = new TripleDESCryptoServiceProvider();
			this.symm.Padding = PaddingMode.PKCS7;
			this.symm.Key = key;
			this.symm.IV = iv;
		}

		public byte[] Encrypt(byte[] data)
		{
			return this.Encrypt(data, data.Length);
		}

		public byte[] Encrypt(byte[] data, int length)
		{
			try
			{
				MemoryStream memoryStream = new MemoryStream();
				CryptoStream cryptoStream = new CryptoStream(memoryStream, this.symm.CreateEncryptor(this.symm.Key, this.symm.IV), CryptoStreamMode.Write);
				cryptoStream.Write(data, 0, length);
				cryptoStream.FlushFinalBlock();
				byte[] result = memoryStream.ToArray();
				cryptoStream.Close();
				memoryStream.Close();
				return result;
			}
			catch (CryptographicException ex)
			{
				Console.WriteLine("A cryptographic error occured: {0}", ex.Message);
			}
			return null;
		}

		public string EncryptString(string text)
		{
			return Convert.ToBase64String(this.Encrypt(Encoding.UTF8.GetBytes(text)));
		}

		public byte[] Decrypt(byte[] data)
		{
			return this.Decrypt(data, data.Length);
		}

		public byte[] Decrypt(byte[] data, int length)
		{
			try
			{
				MemoryStream stream = new MemoryStream(data);
				CryptoStream cryptoStream = new CryptoStream(stream, this.symm.CreateDecryptor(this.symm.Key, this.symm.IV), CryptoStreamMode.Read);
				byte[] array = new byte[length];
				cryptoStream.Read(array, 0, array.Length);
				return array;
			}
			catch (CryptographicException ex)
			{
				Console.WriteLine("A cryptographic error occured: {0}", ex.Message);
			}
			return null;
		}

		public string DecryptString(string data)
		{
			string @string = Encoding.UTF8.GetString(this.Decrypt(Convert.FromBase64String(data)));
			char[] trimChars = new char[1];
			return @string.TrimEnd(trimChars);
		}
	}
}
