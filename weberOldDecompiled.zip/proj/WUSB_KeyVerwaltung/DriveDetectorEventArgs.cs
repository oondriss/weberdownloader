using System;

namespace WUSB_KeyVerwaltung
{
	public class DriveDetectorEventArgs : EventArgs
	{
		public bool Cancel;

		public string Drive;

		public bool HookQueryRemove;

		public DriveDetectorEventArgs()
		{
			this.Cancel = false;
			this.Drive = "";
			this.HookQueryRemove = false;
		}
	}
}
