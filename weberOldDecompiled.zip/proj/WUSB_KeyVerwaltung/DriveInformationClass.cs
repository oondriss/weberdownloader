using System;
using System.Collections.Generic;

namespace WUSB_KeyVerwaltung
{
	internal class DriveInformationClass
	{
		private List<DriveContentClass> removableDriveList = new List<DriveContentClass>();

		public int Count => this.removableDriveList.Count;

		public bool SetDriveChangedTime(string driveName, DateTime dateTime)
		{
			foreach (DriveContentClass removableDrive in this.removableDriveList)
			{
				if (removableDrive.RemovableDriveName == driveName)
				{
					removableDrive.Timestamp_usb_key_file = dateTime;
					return true;
				}
			}
			return false;
		}

		public bool Add(DriveContentClass driveInformation)
		{
			this.removableDriveList.Add(driveInformation);
			return true;
		}

		public bool Add(string drive, bool checkAndStoreKeyDirectory)
		{
			string text = "";
			if (!this.convertDriveString(ref text, drive))
			{
				return false;
			}
			for (int i = 0; i < this.removableDriveList.Count; i++)
			{
				if (this.removableDriveList[i].RemovableDriveName == drive)
				{
					return false;
				}
			}
			DriveContentClass driveContentClass = new DriveContentClass(text);
			if (checkAndStoreKeyDirectory)
			{
				UsbFileSystemClass usbFileSystemClass = new UsbFileSystemClass();
				UserKeyfileStruct userKeyfileContent = new UserKeyfileStruct();
				if (usbFileSystemClass.ReadUsbKeyFile(text, ref userKeyfileContent, out DateTime timestamp_usb_key_file))
				{
					driveContentClass.IsValidUsbKey = usbFileSystemClass.RecentlyReadUsbKeyFileValid;
					driveContentClass.IsEmpty = usbFileSystemClass.RecentlyReadUsbKeyFileEmpty;
					driveContentClass.UserKeyfileContent = userKeyfileContent;
				}
				else
				{
					driveContentClass.IsValidUsbKey = false;
					driveContentClass.IsEmpty = usbFileSystemClass.RecentlyReadUsbKeyFileEmpty;
				}
				driveContentClass.Timestamp_usb_key_file = timestamp_usb_key_file;
			}
			this.removableDriveList.Add(driveContentClass);
			return true;
		}

		public bool Delete(int index)
		{
			if (index < this.removableDriveList.Count)
			{
				this.removableDriveList.RemoveAt(index);
				return true;
			}
			return false;
		}

		public bool DeleteAll()
		{
			int count = this.Count;
			for (int i = 0; i < count; i++)
			{
				this.Delete(0);
			}
			return true;
		}

		public bool Delete(string drive)
		{
			string text = "";
			if (!this.convertDriveString(ref text, drive))
			{
				return false;
			}
			foreach (DriveContentClass removableDrive in this.removableDriveList)
			{
				if (removableDrive.RemovableDriveName == drive)
				{
					this.removableDriveList.Remove(removableDrive);
					return true;
				}
			}
			return false;
		}

		public List<DriveContentClass> GetDriveList()
		{
			return this.removableDriveList;
		}

		public bool IsValidUsbKey(int index)
		{
			if (index < this.removableDriveList.Count)
			{
				return this.removableDriveList[index].IsValidUsbKey;
			}
			return false;
		}

		public bool IsEmptyUsbKey(int index)
		{
			if (index < this.removableDriveList.Count)
			{
				return this.removableDriveList[index].IsEmpty;
			}
			return false;
		}

		public string GetDriveName(int index)
		{
			if (index < this.removableDriveList.Count)
			{
				return this.removableDriveList[index].RemovableDriveName;
			}
			return "";
		}

		public DateTime GetDriveTimestamp(int index)
		{
			if (index < this.removableDriveList.Count)
			{
				return this.removableDriveList[index].Timestamp_usb_key_file;
			}
			return DateTime.MinValue;
		}

		public UserKeyfileStruct GetUserKeyfileContent(int index)
		{
			if (index < this.removableDriveList.Count)
			{
				return this.removableDriveList[index].UserKeyfileContent;
			}
			return null;
		}

		public DriveContentClass GetDriveContent(string driveName)
		{
			for (int i = 0; i < this.removableDriveList.Count; i++)
			{
				string removableDriveName = this.removableDriveList[i].RemovableDriveName;
				if (removableDriveName != null && removableDriveName == driveName)
				{
					return this.removableDriveList[i];
				}
			}
			return null;
		}

		public bool IsDriveConnected(string drive)
		{
			string b = "";
			if (!this.convertDriveString(ref b, drive))
			{
				return false;
			}
			foreach (DriveContentClass removableDrive in this.removableDriveList)
			{
				if (removableDrive.RemovableDriveName == b)
				{
					return true;
				}
			}
			return false;
		}

		private bool convertDriveString(ref string convertedDrive, string drive)
		{
			if (drive.EndsWith(":\\"))
			{
				if (drive.Length != 3)
				{
					return false;
				}
				convertedDrive = drive;
			}
			else
			{
				if (drive.Length != 1)
				{
					return false;
				}
				convertedDrive = drive + ":\\";
			}
			return true;
		}
	}
}
