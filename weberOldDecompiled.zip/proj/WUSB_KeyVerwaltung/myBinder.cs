using System;
using System.Runtime.Serialization;

namespace WUSB_KeyVerwaltung
{
	internal sealed class myBinder : SerializationBinder
	{
		public override Type BindToType(string assemblyName, string typeName)
		{
			return Type.GetType(typeName);
		}
	}
}
