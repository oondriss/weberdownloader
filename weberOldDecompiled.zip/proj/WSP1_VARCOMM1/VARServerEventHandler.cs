namespace WSP1_VARCOMM1
{
	public delegate void VARServerEventHandler(object sender, VARServerEventArgs arg);
}
