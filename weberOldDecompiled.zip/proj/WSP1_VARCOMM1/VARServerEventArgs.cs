using System;

namespace WSP1_VARCOMM1
{
	public class VARServerEventArgs : EventArgs
	{
		private ushort Block;

		public ushort GetBlockNo => this.Block;

		public VARServerEventArgs(ushort bl)
		{
			this.Block = bl;
		}
	}
}
