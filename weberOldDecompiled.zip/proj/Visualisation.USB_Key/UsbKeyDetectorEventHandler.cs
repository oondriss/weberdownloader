namespace Visualisation.USB_Key
{
	public delegate void UsbKeyDetectorEventHandler(object sender, UsbDetectorEventArgs e);
}
