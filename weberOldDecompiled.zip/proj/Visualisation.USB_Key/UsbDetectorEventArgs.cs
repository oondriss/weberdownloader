using System;
using System.Collections.Generic;

namespace Visualisation.USB_Key
{
	public class UsbDetectorEventArgs : EventArgs
	{
		public string StatusMessage = "";

		public string UserId = "";

		public byte UserLevel;

		public string Area = "";

		public List<string> Areas;

		public string TimeLimitation = "";

		public string Password_MD5 = "";

		public string UsedDongleName = "";

		public string Drive;

		public bool UsbKeyValid;

		public UsbDetectorEventArgs()
		{
			this.StatusMessage = "";
			this.Drive = "";
			this.UsbKeyValid = false;
		}
	}
}
