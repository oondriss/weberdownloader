using Program.getHardwareId;
using System;
using System.Collections.Generic;
using System.Threading;
using WUSB_KeyVerwaltung;

namespace Visualisation.USB_Key
{
	public class USB_Class
	{
		private MainForm Main;

		private DriveDetector driveDetector;

		private WUSB_Data_Class wusb_Data = new WUSB_Data_Class();

		private HardwareHelperClass hh = new HardwareHelperClass();

		private UsbFileSystemClass usbFileSystem = new UsbFileSystemClass();

		private bool suspendRecognition;

		public WUSB_Data_Class Wusb_Data => this.wusb_Data;

		public bool SuspendRecognition
		{
			get
			{
				return this.suspendRecognition;
			}
			set
			{
				this.suspendRecognition = value;
			}
		}

		public event UsbKeyDetectorEventHandler UsbKeyArrived;

		public event UsbKeyDetectorEventHandler UsbKeyRemoved;

		public event UsbKeyDetectorEventHandler UsbKeyChanged;

		public void ResetDriveInformation()
		{
		}

		public USB_Class(MainForm main)
		{
			this.Main = main;
			this.driveDetector = new DriveDetector();
			this.driveDetector.DeviceArrived += this.OnDriveArrived;
			this.driveDetector.DeviceRemoved += this.OnDriveRemoved;
			this.driveDetector.DeviceContentChanged += this.OnDeviceContentChanged;
			this.driveDetector.QueryRemove += this.OnQueryRemove;
		}

		public void Clear()
		{
			if (this.driveDetector != null)
			{
				this.driveDetector.Clear();
			}
			this.driveDetector = null;
		}

		public bool IsDriveConnected(string drive)
		{
			if (this.driveDetector == null)
			{
				return false;
			}
			return this.driveDetector.IsDriveConnected(drive);
		}

		private void waitForSuspendRecognition()
		{
			if (this.suspendRecognition)
			{
				for (int i = 0; i < 100; i++)
				{
					if (!this.suspendRecognition)
					{
						break;
					}
					Thread.Sleep(50);
				}
				this.suspendRecognition = false;
			}
		}

		private void OnDriveArrived(object sender, DriveDetectorEventArgs e)
		{
			try
			{
				this.waitForSuspendRecognition();
				string statusMessage = this.Main.Rm.GetString("DriveIdentified") + " " + e.Drive;
				UsbKeyDetectorEventHandler usbKeyArrived = this.UsbKeyArrived;
				if (usbKeyArrived != null)
				{
					UsbDetectorEventArgs usbDetectorEventArgs = new UsbDetectorEventArgs();
					usbDetectorEventArgs.Drive = e.Drive;
					usbDetectorEventArgs.StatusMessage = statusMessage;
					DriveContentClass driveContent = this.driveDetector.DriveInformation.GetDriveContent(e.Drive);
					if (driveContent != null && !driveContent.IsEmpty)
					{
						usbDetectorEventArgs.UsbKeyValid = driveContent.IsValidUsbKey;
						if (driveContent.UserKeyfileContent != null)
						{
							usbDetectorEventArgs.UserLevel = (byte)driveContent.UserKeyfileContent.GetAccessLevel();
							usbDetectorEventArgs.UserId = driveContent.UserKeyfileContent.GetDecryptedUserNumber();
							usbDetectorEventArgs.Areas = new List<string>();
							for (int i = 0; i < 10; i++)
							{
								usbDetectorEventArgs.Area = driveContent.UserKeyfileContent.GetDecryptedArea(i);
								if (usbDetectorEventArgs.Area.Length == 0)
								{
									break;
								}
								usbDetectorEventArgs.Areas.Add(usbDetectorEventArgs.Area);
							}
							usbDetectorEventArgs.TimeLimitation = driveContent.UserKeyfileContent.GetDecryptedTimeLimitation();
							usbDetectorEventArgs.Password_MD5 = driveContent.UserKeyfileContent.Password;
							usbDetectorEventArgs.UsedDongleName = driveContent.UserKeyfileContent.GetUsedDongleName();
						}
						usbKeyArrived(this, usbDetectorEventArgs);
					}
				}
			}
			catch (Exception)
			{
			}
		}

		private void OnDriveRemoved(object sender, DriveDetectorEventArgs e)
		{
			this.waitForSuspendRecognition();
			string statusMessage = this.Main.Rm.GetString("DriveRemoved") + " " + e.Drive;
			UsbKeyDetectorEventHandler usbKeyRemoved = this.UsbKeyRemoved;
			if (usbKeyRemoved != null)
			{
				UsbDetectorEventArgs usbDetectorEventArgs = new UsbDetectorEventArgs();
				usbDetectorEventArgs.Drive = e.Drive;
				usbDetectorEventArgs.StatusMessage = statusMessage;
				usbKeyRemoved(this, usbDetectorEventArgs);
			}
		}

		private void OnDeviceContentChanged(object sender, DriveDetectorEventArgs e)
		{
			try
			{
				this.waitForSuspendRecognition();
				string statusMessage = this.Main.Rm.GetString("DriveContentChanged") + " " + e.Drive;
				UsbKeyDetectorEventHandler usbKeyChanged = this.UsbKeyChanged;
				if (this.UsbKeyChanged != null)
				{
					UsbDetectorEventArgs usbDetectorEventArgs = new UsbDetectorEventArgs();
					usbDetectorEventArgs.Drive = e.Drive;
					usbDetectorEventArgs.StatusMessage = statusMessage;
					DriveContentClass driveContent = this.driveDetector.DriveInformation.GetDriveContent(e.Drive);
					if (driveContent != null && !driveContent.IsEmpty)
					{
						usbDetectorEventArgs.UsbKeyValid = driveContent.IsValidUsbKey;
						if (driveContent.UserKeyfileContent != null)
						{
							usbDetectorEventArgs.UserLevel = (byte)driveContent.UserKeyfileContent.GetAccessLevel();
							usbDetectorEventArgs.UserId = driveContent.UserKeyfileContent.GetDecryptedUserNumber();
							usbDetectorEventArgs.Areas = new List<string>();
							for (int i = 0; i < 10; i++)
							{
								usbDetectorEventArgs.Area = driveContent.UserKeyfileContent.GetDecryptedArea(i);
								if (usbDetectorEventArgs.Area.Length == 0)
								{
									break;
								}
								usbDetectorEventArgs.Areas.Add(usbDetectorEventArgs.Area);
							}
							usbDetectorEventArgs.TimeLimitation = driveContent.UserKeyfileContent.GetDecryptedTimeLimitation();
							usbDetectorEventArgs.Password_MD5 = driveContent.UserKeyfileContent.Password;
						}
						usbKeyChanged(this, usbDetectorEventArgs);
					}
					else if (driveContent != null && driveContent.IsEmpty)
					{
						usbKeyChanged(this, usbDetectorEventArgs);
					}
				}
			}
			catch (Exception)
			{
			}
		}

		private void OnQueryRemove(object sender, DriveDetectorEventArgs e)
		{
			e.Cancel = false;
		}
	}
}
