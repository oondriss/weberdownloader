using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class CurveSelectionForm : Form
	{
		private MainForm Main;

		private GroupBox gBCurveSelection;

		private Button btOK;

		private Button btCancel;

		private ComboBox cBXaxis;

		private Label lbXaxis;

		private CheckBox chBC0;

		private CheckBox chBC7;

		private CheckBox chBC4;

		private CheckBox chBC3;

		private CheckBox chBC2;

		private CheckBox chBC1;

		private CheckBox chBC9;

		private CheckBox chBC5;

		private CheckBox chBC10;

		private CheckBox chBC8;

		private CheckBox chBC6;

		private Container components;

		private bool canceled;

		public bool Canceled => this.canceled;

		public CurveSelectionForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.InitializeValues();
		}

		private void CurveSelectionForm_Shown(object sender, EventArgs e)
		{
			this.canceled = false;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.gBCurveSelection = new GroupBox();
			this.chBC9 = new CheckBox();
			this.chBC0 = new CheckBox();
			this.chBC5 = new CheckBox();
			this.chBC10 = new CheckBox();
			this.chBC7 = new CheckBox();
			this.chBC8 = new CheckBox();
			this.chBC6 = new CheckBox();
			this.chBC4 = new CheckBox();
			this.chBC3 = new CheckBox();
			this.chBC2 = new CheckBox();
			this.chBC1 = new CheckBox();
			this.btOK = new Button();
			this.btCancel = new Button();
			this.cBXaxis = new ComboBox();
			this.lbXaxis = new Label();
			this.gBCurveSelection.SuspendLayout();
			base.SuspendLayout();
			this.gBCurveSelection.Controls.Add(this.chBC9);
			this.gBCurveSelection.Controls.Add(this.chBC0);
			this.gBCurveSelection.Controls.Add(this.chBC5);
			this.gBCurveSelection.Controls.Add(this.chBC10);
			this.gBCurveSelection.Controls.Add(this.chBC7);
			this.gBCurveSelection.Controls.Add(this.chBC8);
			this.gBCurveSelection.Controls.Add(this.chBC6);
			this.gBCurveSelection.Controls.Add(this.chBC4);
			this.gBCurveSelection.Controls.Add(this.chBC3);
			this.gBCurveSelection.Controls.Add(this.chBC2);
			this.gBCurveSelection.Controls.Add(this.chBC1);
			this.gBCurveSelection.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBCurveSelection.Location = new Point(0, 70);
			this.gBCurveSelection.Name = "gBCurveSelection";
			this.gBCurveSelection.Size = new Size(186, 378);
			this.gBCurveSelection.TabIndex = 1;
			this.gBCurveSelection.TabStop = false;
			this.gBCurveSelection.Text = "Angezeigte Kurven";
			this.chBC9.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBC9.Location = new Point(8, 312);
			this.chBC9.Name = "chBC9";
			this.chBC9.Size = new Size(170, 24);
			this.chBC9.TabIndex = 9;
			this.chBC9.Text = "Tiefengradient";
			this.chBC0.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBC0.Location = new Point(8, 24);
			this.chBC0.Name = "chBC0";
			this.chBC0.Size = new Size(170, 24);
			this.chBC0.TabIndex = 0;
			this.chBC0.Text = "Zeit";
			this.chBC5.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBC5.Location = new Point(8, 184);
			this.chBC5.Name = "chBC5";
			this.chBC5.Size = new Size(170, 24);
			this.chBC5.TabIndex = 5;
			this.chBC5.Text = "Gradient";
			this.chBC10.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBC10.Location = new Point(8, 344);
			this.chBC10.Name = "chBC10";
			this.chBC10.Size = new Size(170, 24);
			this.chBC10.TabIndex = 10;
			this.chBC10.Text = "ext. anal. Sig.";
			this.chBC7.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBC7.Location = new Point(8, 248);
			this.chBC7.Name = "chBC7";
			this.chBC7.Size = new Size(170, 24);
			this.chBC7.TabIndex = 7;
			this.chBC7.Text = "Analogtiefe";
			this.chBC8.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBC8.Location = new Point(8, 280);
			this.chBC8.Name = "chBC8";
			this.chBC8.Size = new Size(170, 24);
			this.chBC8.TabIndex = 8;
			this.chBC8.Text = "TM";
			this.chBC6.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBC6.Location = new Point(8, 216);
			this.chBC6.Name = "chBC6";
			this.chBC6.Size = new Size(170, 24);
			this.chBC6.TabIndex = 6;
			this.chBC6.Text = "Winkel";
			this.chBC4.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBC4.Location = new Point(8, 152);
			this.chBC4.Name = "chBC4";
			this.chBC4.Size = new Size(170, 24);
			this.chBC4.TabIndex = 4;
			this.chBC4.Text = "gefilt. Moment";
			this.chBC3.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBC3.Location = new Point(8, 120);
			this.chBC3.Name = "chBC3";
			this.chBC3.Size = new Size(170, 24);
			this.chBC3.TabIndex = 3;
			this.chBC3.Text = "Moment";
			this.chBC2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBC2.Location = new Point(8, 88);
			this.chBC2.Name = "chBC2";
			this.chBC2.Size = new Size(170, 24);
			this.chBC2.TabIndex = 2;
			this.chBC2.Text = "Istdrehzahl";
			this.chBC1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBC1.Location = new Point(8, 56);
			this.chBC1.Name = "chBC1";
			this.chBC1.Size = new Size(170, 24);
			this.chBC1.TabIndex = 1;
			this.chBC1.Text = "Solldrehzahl";
			this.btOK.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btOK.Location = new Point(4, 456);
			this.btOK.Name = "btOK";
			this.btOK.Size = new Size(85, 33);
			this.btOK.TabIndex = 2;
			this.btOK.Text = "OK";
			this.btOK.Click += this.btOK_Click;
			this.btCancel.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCancel.Location = new Point(98, 456);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(85, 33);
			this.btCancel.TabIndex = 3;
			this.btCancel.Text = "Abbrechen";
			this.btCancel.Click += this.btCancel_Click;
			this.cBXaxis.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBXaxis.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBXaxis.Items.AddRange(new object[11]
			{
				"Zeit",
				"Solldrehzahl",
				"Istdrehzahl",
				"Drehmoment",
				"gefiltertes Moment",
				"Winkel",
				"dig. Signal",
				"Analoge Tiefe",
				"Ext. analoges Signal",
				"Momentgradient",
				"Tiefengradient"
			});
			this.cBXaxis.Location = new Point(8, 32);
			this.cBXaxis.MaxDropDownItems = 11;
			this.cBXaxis.Name = "cBXaxis";
			this.cBXaxis.Size = new Size(172, 28);
			this.cBXaxis.TabIndex = 0;
			this.lbXaxis.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbXaxis.Location = new Point(8, 8);
			this.lbXaxis.Name = "lbXaxis";
			this.lbXaxis.Size = new Size(168, 16);
			this.lbXaxis.TabIndex = 11;
			this.lbXaxis.Text = "Ausgewählte x-Achse:";
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(186, 494);
			base.ControlBox = false;
			base.Controls.Add(this.lbXaxis);
			base.Controls.Add(this.cBXaxis);
			base.Controls.Add(this.btCancel);
			base.Controls.Add(this.btOK);
			base.Controls.Add(this.gBCurveSelection);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.FixedSingle;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "CurveSelectionForm";
			base.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "Kurvenauswahl";
			base.Shown += this.CurveSelectionForm_Shown;
			this.gBCurveSelection.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public void SetLanguageTexts()
		{
			int selectedIndex = this.cBXaxis.SelectedIndex;
			this.Text = this.Main.Rm.GetString("MCurveSelection");
			this.lbXaxis.Text = this.Main.Rm.GetString("SelectedXAxis");
			this.btCancel.Text = this.Main.Rm.GetString("Cancel");
			this.btOK.Text = this.Main.Rm.GetString("Apply");
			this.gBCurveSelection.Text = this.Main.Rm.GetString("SelectedYAxis");
			this.chBC0.Text = this.Main.Rm.GetString("Time");
			this.chBC1.Text = this.Main.Rm.GetString("SetRpm");
			this.chBC2.Text = this.Main.Rm.GetString("GetRpm");
			this.chBC3.Text = this.Main.Rm.GetString("Torque");
			this.chBC4.Text = this.Main.Rm.GetString("FilteredTorque");
			this.chBC5.Text = this.Main.Rm.GetString("Gradient");
			this.chBC6.Text = this.Main.Rm.GetString("Angle");
			this.chBC7.Text = this.Main.Rm.GetString("AnaDepth");
			this.chBC8.Text = this.Main.Rm.GetString("JawOpen");
			this.chBC9.Text = this.Main.Rm.GetString("DepthGrad");
			this.chBC10.Text = this.Main.Rm.GetString("AnaSignal");
			this.cBXaxis.Items.Clear();
			this.cBXaxis.Items.Add(this.Main.Rm.GetString("Time"));
			this.cBXaxis.Items.Add(this.Main.Rm.GetString("SetRpm"));
			this.cBXaxis.Items.Add(this.Main.Rm.GetString("GetRpm"));
			this.cBXaxis.Items.Add(this.Main.Rm.GetString("Torque"));
			this.cBXaxis.Items.Add(this.Main.Rm.GetString("FilteredTorque"));
			this.cBXaxis.Items.Add(this.Main.Rm.GetString("Gradient"));
			this.cBXaxis.Items.Add(this.Main.Rm.GetString("Angle"));
			this.cBXaxis.Items.Add(this.Main.Rm.GetString("AnaDepth"));
			this.cBXaxis.Items.Add(this.Main.Rm.GetString("JawOpen"));
			this.cBXaxis.Items.Add(this.Main.Rm.GetString("DepthGrad"));
			this.cBXaxis.Items.Add(this.Main.Rm.GetString("AnaSignal"));
			this.cBXaxis.SelectedIndex = selectedIndex;
		}

		private void InitializeValues()
		{
			this.cBXaxis.SelectedIndex = Settings.Default.SelectedXaxis;
			this.chBC0.Checked = Settings.Default.Time;
			this.chBC1.Checked = Settings.Default.SetRpm;
			this.chBC2.Checked = Settings.Default.GetRpm;
			this.chBC3.Checked = Settings.Default.Torque;
			this.chBC4.Checked = Settings.Default.FilteredTorque;
			this.chBC5.Checked = Settings.Default.TorqueGradient;
			this.chBC6.Checked = Settings.Default.Angle;
			this.chBC7.Checked = Settings.Default.AnalogDepth;
			this.chBC8.Checked = Settings.Default.DigitalDepth;
			this.chBC9.Checked = Settings.Default.DepthGradient;
			this.chBC10.Checked = Settings.Default.AnalogSignal;
		}

		private void SetCurves()
		{
			Settings.Default.SelectedXaxis = this.cBXaxis.SelectedIndex;
			Settings.Default.Time = this.chBC0.Checked;
			Settings.Default.SetRpm = this.chBC1.Checked;
			Settings.Default.GetRpm = this.chBC2.Checked;
			Settings.Default.Torque = this.chBC3.Checked;
			Settings.Default.FilteredTorque = this.chBC4.Checked;
			Settings.Default.TorqueGradient = this.chBC5.Checked;
			Settings.Default.Angle = this.chBC6.Checked;
			Settings.Default.AnalogDepth = this.chBC7.Checked;
			Settings.Default.DigitalDepth = this.chBC8.Checked;
			Settings.Default.DepthGradient = this.chBC9.Checked;
			Settings.Default.AnalogSignal = this.chBC10.Checked;
			Settings.Default.Save();
		}

		private void btOK_Click(object sender, EventArgs e)
		{
			this.SetCurves();
			base.Close();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.canceled = true;
			base.Close();
		}

		public void Cancel()
		{
			if (base.Visible)
			{
				this.canceled = true;
				base.Close();
			}
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (msg.WParam.ToInt32() == 27)
			{
				base.Close();
			}
			else if (keyData == Keys.Return && this.btOK.Enabled)
			{
				this.btOK_Click(null, null);
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}
	}
}
