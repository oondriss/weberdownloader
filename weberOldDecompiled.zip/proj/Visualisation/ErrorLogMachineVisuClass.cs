using EnterpriseDT.Net.Ftp;
using System;
using System.Collections.Generic;
using System.Deployment.Application;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace Visualisation
{
	public class ErrorLogMachineVisuClass
	{
		public List<ErrorTextClass> ErrorTextList = new List<ErrorTextClass>();

		private MainForm Main;

		private Ping_Class DetectIP;

		private FTPConnection ftpConnection1;

		private int currentErrorIndex = -1;

		public ErrorLogMachineVisuClass(MainForm main)
		{
			this.Main = main;
			this.DetectIP = new Ping_Class();
			this.ftpConnection1 = new FTPConnection();
			this.ftpConnection1.AutoLogin = true;
			this.ftpConnection1.ConnectMode = FTPConnectMode.PASV;
			this.ftpConnection1.DeleteOnFailure = true;
			this.ftpConnection1.EventsEnabled = true;
			this.ftpConnection1.ParsingCulture = new CultureInfo("");
			this.ftpConnection1.Password = null;
			this.ftpConnection1.ServerAddress = null;
			this.ftpConnection1.ServerPort = 21;
			this.ftpConnection1.StrictReturnCodes = true;
			this.ftpConnection1.Timeout = 0;
			this.ftpConnection1.TransferBufferSize = 4096;
			this.ftpConnection1.TransferNotifyInterval = 4096L;
			this.ftpConnection1.TransferType = FTPTransferType.BINARY;
			this.ftpConnection1.UserName = null;
		}

		public byte[] GetFileViaHttp(string filename)
		{
			new WebClient();
			try
			{
				string uriString = (!ApplicationDeployment.IsNetworkDeployed) ? "http://172.20.15.98/Visualisation/Visualisation.application" : ApplicationDeployment.CurrentDeployment.ActivationUri.ToString();
				Uri uri = new Uri(uriString);
				string authority = uri.Authority;
				string requestUriString = "ftp://" + authority + "/3S/PLC/ProjectFiles/" + filename;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadProcessInfo"));
				if (!this.DetectIP.DoPingController())
				{
					this.ftpConnection1.UserName = "powerto";
					this.ftpConnection1.Password = "the$people";
					this.ftpConnection1.ServerAddress = authority;
					this.ftpConnection1.ConnectMode = FTPConnectMode.ACTIVE;
					this.ftpConnection1.Connect();
					this.ftpConnection1.ChangeWorkingDirectory("\\3S\\PLC\\ProjectFiles");
					this.ftpConnection1.DownloadFile(Application.CommonAppDataPath + "\\" + filename, filename);
					FileStream stream = new FileStream(Application.CommonAppDataPath + "\\" + filename, FileMode.Open);
					StreamReader streamReader = new StreamReader(stream, Encoding.Unicode);
					this.Main.StatusBarText("");
					return streamReader.CurrentEncoding.GetBytes(streamReader.ReadToEnd());
				}
				FtpWebRequest ftpWebRequest = (FtpWebRequest)WebRequest.Create(requestUriString);
				ftpWebRequest.Method = "RETR";
				ftpWebRequest.Credentials = new NetworkCredential("powerto", "the$people");
				FtpWebResponse ftpWebResponse = (FtpWebResponse)ftpWebRequest.GetResponse();
				Stream responseStream = ftpWebResponse.GetResponseStream();
				StreamReader streamReader2 = new StreamReader(responseStream, Encoding.Unicode);
				this.Main.StatusBarText("");
				return streamReader2.CurrentEncoding.GetBytes(streamReader2.ReadToEnd());
			}
			catch (Exception)
			{
				return null;
			}
		}

		public bool ReadErrorText(string name)
		{
			string text = (!ApplicationDeployment.IsNetworkDeployed) ? "http://172.20.15.98/Visualisation/Visualisation.application" : ApplicationDeployment.CurrentDeployment.ActivationUri.ToString();
			text = text.Remove(text.IndexOf("/Visu"));
			text = text + "/Data/" + name;
			byte[] fileViaHttp = this.GetFileViaHttp(name);
			if (fileViaHttp == null)
			{
				return false;
			}
			MemoryStream input = new MemoryStream(fileViaHttp);
			bool result = true;
			XmlReader xmlReader = XmlReader.Create(input);
			bool flag = false;
			try
			{
				while (true)
				{
					if (!xmlReader.Read())
					{
						break;
					}
					if (!flag)
					{
						if (xmlReader.Name.Length != 0 && xmlReader.NodeType == XmlNodeType.Element && xmlReader.Name == "text-list")
						{
							while (xmlReader.Read() && !flag)
							{
								switch (xmlReader.NodeType)
								{
								case XmlNodeType.EndElement:
									if (xmlReader.Name == "text-list")
									{
										flag = true;
									}
									break;
								case XmlNodeType.Element:
									if (xmlReader.Name == "text")
									{
										ErrorTextClass errorTextClass = new ErrorTextClass();
										if (xmlReader.AttributeCount >= 2)
										{
											int.TryParse(xmlReader.GetAttribute(1), out errorTextClass.Id);
										}
										this.parseText(xmlReader, errorTextClass, xmlReader.Name);
										this.ErrorTextList.Add(errorTextClass);
									}
									break;
								}
							}
							flag = false;
						}
						continue;
					}
					return result;
				}
				return result;
			}
			catch (Exception ex)
			{
				string message = ex.Message;
				this.ErrorTextList = null;
				return false;
			}
		}

		private bool parseText(XmlReader reader, ErrorTextClass fi, string endElement)
		{
			bool flag = false;
			while (reader.Read() && !flag)
			{
				try
				{
					switch (reader.NodeType)
					{
					case XmlNodeType.EndElement:
						if (reader.Name == endElement)
						{
							flag = true;
						}
						break;
					case XmlNodeType.Element:
						switch (reader.Name.ToLower())
						{
						case "deutsch":
							reader.Read();
							fi.German = reader.Value;
							break;
						case "english":
							reader.Read();
							fi.English = reader.Value;
							break;
						case "franzoesisch":
							reader.Read();
							fi.French = reader.Value;
							break;
						case "italienisch":
							reader.Read();
							fi.Italian = reader.Value;
							break;
						case "spanisch":
							reader.Read();
							fi.Spanish = reader.Value;
							break;
						case "portugisisch":
							reader.Read();
							fi.Portuguese = reader.Value;
							break;
						case "rumaenisch":
							reader.Read();
							fi.Romanian = reader.Value;
							break;
						case "polnisch":
							reader.Read();
							fi.Polish = reader.Value;
							break;
						case "tschechisch":
							reader.Read();
							fi.Czech = reader.Value;
							break;
						case "ungarisch":
							reader.Read();
							fi.Hungarian = reader.Value;
							break;
						case "slowakisch":
							reader.Read();
							fi.Slowak = reader.Value;
							break;
						case "chinesisch":
							reader.Read();
							fi.Chinese = reader.Value;
							break;
						}
						break;
					}
				}
				catch (Exception)
				{
					return false;
				}
			}
			return true;
		}

		public string TextOf(int id)
		{
			foreach (ErrorTextClass errorText in this.ErrorTextList)
			{
				if (errorText.Id == id)
				{
					return errorText.TextOf();
				}
			}
			return "";
		}

		public int GetNextErrorId(bool first)
		{
			if (first)
			{
				this.currentErrorIndex = 0;
			}
			else
			{
				this.currentErrorIndex++;
			}
			if (this.currentErrorIndex >= this.ErrorTextList.Count)
			{
				return -1;
			}
			return this.ErrorTextList[this.currentErrorIndex].Id;
		}
	}
}
