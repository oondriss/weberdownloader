using System;
using System.ComponentModel;
using System.Deployment.Application;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace Visualisation
{
	public class BrowserHelpForm : Form
	{
		private MainForm Main;

		private Container components;

		private Panel pnMenu;

		private WebBrowser browser;

		private bool helpActive;

		private string controllerUri;

		private GroupBox gBVersionInfo;

		private Label lbShowVersionVisualisation;

		private Label lbShowVersionController;

		private Label lbVersionController;

		private Label lbVersionVisualisation;

		private Button button1;

		private Uri siteUri;

		public bool HelpActive => this.helpActive;

		public void HideHelp()
		{
			this.helpActive = false;
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		public BrowserHelpForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			try
			{
				if (ApplicationDeployment.IsNetworkDeployed)
				{
					this.controllerUri = ApplicationDeployment.CurrentDeployment.ActivationUri.ToString();
				}
				else
				{
					this.controllerUri = "http://172.20.15.98/Visualisation/Visualisation.application";
				}
				this.siteUri = new Uri(this.controllerUri);
				string authority = this.siteUri.Authority;
			}
			catch (Exception)
			{
			}
			this.browser.ScriptErrorsSuppressed = true;
			this.browser.ScrollBarsEnabled = true;
		}

		public void PrepareForShutDown()
		{
			OperatingSystem oSVersion = Environment.OSVersion;
			if (oSVersion.Platform == PlatformID.Win32NT && oSVersion.Version.Major == 5)
			{
				this.browser.Stop();
			}
		}

		public void Navigate(string manualKap)
		{
			string helpFileName = this.Main.HelpFileName;
			string urlString;
			if (this.Main.IsOfflineVersion)
			{
				urlString = this.Main.LocalizedHelpFile;
			}
			else
			{
				string authority = this.siteUri.Authority;
				urlString = "http://" + authority + "/Manual/" + helpFileName + manualKap;
			}
			try
			{
				this.browser.Navigate(urlString, false);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			this.helpActive = true;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
				this.components = null;
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.browser = new WebBrowser();
			this.gBVersionInfo = new GroupBox();
			this.button1 = new Button();
			this.lbShowVersionVisualisation = new Label();
			this.lbShowVersionController = new Label();
			this.lbVersionController = new Label();
			this.lbVersionVisualisation = new Label();
			this.gBVersionInfo.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.browser.AllowWebBrowserDrop = false;
			this.browser.CausesValidation = false;
			this.browser.IsWebBrowserContextMenuEnabled = false;
			this.browser.Location = new Point(0, 3);
			this.browser.MinimumSize = new Size(20, 20);
			this.browser.Name = "browser";
			this.browser.ScrollBarsEnabled = false;
			this.browser.Size = new Size(786, 520);
			this.browser.TabIndex = 1;
			this.browser.WebBrowserShortcutsEnabled = false;
			this.gBVersionInfo.BackColor = Color.Transparent;
			this.gBVersionInfo.BackgroundImageLayout = ImageLayout.None;
			this.gBVersionInfo.Controls.Add(this.button1);
			this.gBVersionInfo.Controls.Add(this.lbShowVersionVisualisation);
			this.gBVersionInfo.Controls.Add(this.lbShowVersionController);
			this.gBVersionInfo.Controls.Add(this.lbVersionController);
			this.gBVersionInfo.Controls.Add(this.lbVersionVisualisation);
			this.gBVersionInfo.FlatStyle = FlatStyle.Flat;
			this.gBVersionInfo.Location = new Point(133, 476);
			this.gBVersionInfo.Name = "gBVersionInfo";
			this.gBVersionInfo.Size = new Size(481, 47);
			this.gBVersionInfo.TabIndex = 7;
			this.gBVersionInfo.TabStop = false;
			this.gBVersionInfo.Text = "Versionsinformationen";
			this.button1.Location = new Point(453, 15);
			this.button1.Margin = new Padding(0);
			this.button1.Name = "button1";
			this.button1.Size = new Size(28, 29);
			this.button1.TabIndex = 8;
			this.button1.Text = "X";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += this.button1_Click_1;
			this.lbShowVersionVisualisation.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowVersionVisualisation.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowVersionVisualisation.Location = new Point(349, 17);
			this.lbShowVersionVisualisation.Name = "lbShowVersionVisualisation";
			this.lbShowVersionVisualisation.Size = new Size(101, 23);
			this.lbShowVersionVisualisation.TabIndex = 38;
			this.lbShowVersionVisualisation.Text = "Version";
			this.lbShowVersionVisualisation.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowVersionController.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowVersionController.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowVersionController.Location = new Point(125, 18);
			this.lbShowVersionController.Name = "lbShowVersionController";
			this.lbShowVersionController.Size = new Size(109, 23);
			this.lbShowVersionController.TabIndex = 37;
			this.lbShowVersionController.Text = "Version";
			this.lbShowVersionController.TextAlign = ContentAlignment.MiddleLeft;
			this.lbVersionController.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbVersionController.Location = new Point(13, 18);
			this.lbVersionController.Name = "lbVersionController";
			this.lbVersionController.Size = new Size(104, 23);
			this.lbVersionController.TabIndex = 34;
			this.lbVersionController.Text = "Steuerung";
			this.lbVersionController.TextAlign = ContentAlignment.MiddleRight;
			this.lbVersionVisualisation.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbVersionVisualisation.Location = new Point(240, 18);
			this.lbVersionVisualisation.Name = "lbVersionVisualisation";
			this.lbVersionVisualisation.Size = new Size(104, 23);
			this.lbVersionVisualisation.TabIndex = 36;
			this.lbVersionVisualisation.Text = "Visualisierung";
			this.lbVersionVisualisation.TextAlign = ContentAlignment.MiddleRight;
			base.AutoScaleMode = AutoScaleMode.None;
			this.AutoScroll = true;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.gBVersionInfo);
			base.Controls.Add(this.browser);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.Name = "BrowserHelpForm";
			base.StartPosition = FormStartPosition.Manual;
			this.gBVersionInfo.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public void ShowWindow()
		{
			this.gBVersionInfo.Visible = true;
			if (this.Main.IsOfflineVersion)
			{
				this.lbShowVersionController.Text = string.Empty;
				this.lbShowVersionVisualisation.Text = Assembly.GetExecutingAssembly().GetName().Version.ToString();
			}
			else if (!this.Main.IsOnlineMode)
			{
				this.lbShowVersionController.Text = string.Empty;
				this.lbShowVersionVisualisation.Text = Assembly.GetExecutingAssembly().GetName().Version.ToString();
			}
			else
			{
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadSystemConst"));
				if (!this.Main.VC.ReceiveVarBlock(12))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not receive SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				this.lbShowVersionController.Text = this.Main.CommonFunctions.UShortToString(this.Main.VC.Status0.Version);
				this.lbShowVersionVisualisation.Text = Assembly.GetExecutingAssembly().GetName().Version.ToString();
				this.Main.StatusBarText("");
			}
			this.MenEna();
			base.Left = 0;
			this.Main.WeberLogoImage(3);
			base.Show();
		}

		public void SetLanguageTexts()
		{
			this.lbVersionController.Text = this.Main.Rm.GetString("VersionController");
			this.lbVersionVisualisation.Text = this.Main.Rm.GetString("VersionVisu");
			this.gBVersionInfo.Text = this.Main.Rm.GetString("VersionInfo");
		}

		private void MenEna()
		{
			bool isOnlineMode = this.Main.IsOnlineMode;
		}

		private void MenuAnalysisForm_Activated(object sender, EventArgs e)
		{
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			msg.WParam.ToInt32();
			return base.ProcessCmdKey(ref msg, keyData);
		}

		public void KeyArrived()
		{
			base.Hide();
		}

		public void KeyRemoved()
		{
			base.Hide();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.gBVersionInfo.Visible = false;
		}

		private void button1_Click_1(object sender, EventArgs e)
		{
			this.gBVersionInfo.Visible = false;
		}
	}
}
