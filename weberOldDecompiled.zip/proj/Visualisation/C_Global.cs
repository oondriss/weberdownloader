using System.Collections.Generic;
using System.Resources;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class C_Global
	{
		public const bool NO_INIFILECHECK = false;

		public const bool PASSCODECHECK = true;

		public const bool FIXED_TARGET_LOCATION = false;

		public const int CONTROLLER_OFFLINE_TIMER_INTERVAL = 1000;

		public const int CONTROLLER_OFFLINE_TIME = 10;

		public const int CONTROLLER_LIVING_SIGN_TIME = 5000;

		public const int TEST_UPDATE_TIME = 500;

		public const string TARGET_LOCATION = "http://172.20.15.98/Visualisation/Visualisation.application";

		public const string MANUAL_PATH = "Manual/";

		public const string INIFILESTRING = "Settings.ini";

		public const int PASSCODE_LENGTH = 5;

		public const int SUPERPASSWORD = 14142;

		public const string SUPERUSER_IDENTITY = "XX";

		public const string DEFAULTUSER_IDENTITY = "--";

		public const int ERROR_THREAD_SLEEP_TIME = 100;

		public const int PRINTMARGIN = 50;

		public const float NORMAL_FONT_SIZE = 11f;

		public const int STEP_RESULT_SAVE_NUM = 50;

		public const int TIMEOUT_SAVE_BLOCK = 550;

		public const int TIMEOUT_DELETE_BLOCK = 400;

		public const int TIMEOUT_GET_BLOCK_ACCESS = 20;

		public const int LOGBOOKCODE_DELETE_PROG = 201000;

		public const int LOGBOOKCODE_INSERT_PROG = 201001;

		public const int LOGBOOKCODE_STEP_CHANGE = 201002;

		public const int LOGBOOKCODE_PROGNAME_CHANGE = 201003;

		public const int LOGBOOKCODE_RESULT_CHANGE = 201004;

		public const int LOGBOOKCODE_INSERT_STEP = 201005;

		public const int LOGBOOKCODE_DELETE_STEP = 201006;

		public const int LOGBOOKCODE_PROG_PARAM_CHANGE = 201007;

		public const int LOGBOOKCODE_ONE_PROG_RESTORED_FROM_FILE = 201008;

		public const int LOGBOOKCODE_ALL_PROGS_RESTORED_FROM_FILE = 201009;

		public const int LOGBOOKCODE_ANALOG_MAX_CHANGE = 201100;

		public const int LOGBOOKCODE_ANALOG_MIN_CHANGE = 201101;

		public const int LOGBOOKCODE_ANALOG_P_CHANGE = 201102;

		public const int LOGBOOKCODE_COUNTPASSMAX_CHANGE = 201103;

		public const int LOGBOOKCODE_DIG_MAX_CHANGE = 201104;

		public const int LOGBOOKCODE_DIG_MIN_CHANGE = 201105;

		public const int LOGBOOKCODE_DIG_P_CHANGE = 201106;

		public const int LOGBOOKCODE_ENA_ANALOG_DEPTH_CHANGE = 201107;

		public const int LOGBOOKCODE_ENA_ADEPTH_GRAD_MAX_CHANGE = 201108;

		public const int LOGBOOKCODE_ENA_ADEPTH_GRAD_MIN_CHANGE = 201109;

		public const int LOGBOOKCODE_ENA_ANALOG_CHANGE = 201110;

		public const int LOGBOOKCODE_ENA_ANGLE_CHANGE = 201111;

		public const int LOGBOOKCODE_ENA_FTORQUE_CHANGE = 201112;

		public const int LOGBOOKCODE_ENA_GRADIENT_MIN_CHANGE = 201113;

		public const int LOGBOOKCODE_ENA_GRADIENT_MAX_CHANGE = 201114;

		public const int LOGBOOKCODE_ENA_RELEASE_CHANGE = 201115;

		public const int LOGBOOKCODE_ENA_SNUG_CHANGE = 201116;

		public const int LOGBOOKCODE_ENA_TIME_CHANGE = 201117;

		public const int LOGBOOKCODE_ENA_TORQUE_CHANGE = 201118;

		public const int LOGBOOKCODE_ISRESULT1_CHANGE = 201119;

		public const int LOGBOOKCODE_ISRESULT2_CHANGE = 201120;

		public const int LOGBOOKCODE_ISRESULT3_CHANGE = 201121;

		public const int LOGBOOKCODE_JUMPTO_CHANGE = 201122;

		public const int LOGBOOKCODE_DEPTH_GRAD_MAX_CHANGE = 201123;

		public const int LOGBOOKCODE_DEPTH_GRAD_MIN_CHANGE = 201124;

		public const int LOGBOOKCODE_DEPTH_GRAD_P_CHANGE = 201125;

		public const int LOGBOOKCODE_DEPTH_MAX_CHANGE = 201126;

		public const int LOGBOOKCODE_DEPTH_MIN_CHANGE = 201127;

		public const int LOGBOOKCODE_DEPTH_P_CHANGE = 201128;

		public const int LOGBOOKCODE_MDELAY_TIME_CHANGE = 201129;

		public const int LOGBOOKCODE_MF_MAX_CHANGE = 201130;

		public const int LOGBOOKCODE_MF_MIN_CHANGE = 201131;

		public const int LOGBOOKCODE_MF_P_CHANGE = 201132;

		public const int LOGBOOKCODE_MG_MAX_CHANGE = 201133;

		public const int LOGBOOKCODE_MG_MIN_CHANGE = 201134;

		public const int LOGBOOKCODE_MG_P_CHANGE = 201135;

		public const int LOGBOOKCODE_M_MAX_CHANGE = 201136;

		public const int LOGBOOKCODE_M_MIN_CHANGE = 201137;

		public const int LOGBOOKCODE_MOD_DIG_OUT_CHANGE = 201138;

		public const int LOGBOOKCODE_M_P_CHANGE = 201140;

		public const int LOGBOOKCODE_MR_P_CHANGE = 201141;

		public const int LOGBOOKCODE_MR_STEP_CHANGE = 201142;

		public const int LOGBOOKCODE_MR_TYPE_CHANGE = 201143;

		public const int LOGBOOKCODE_MS_CHANGE = 201144;

		public const int LOGBOOKCODE_NA_CHANGE = 201145;

		public const int LOGBOOKCODE_SWITCH_CHANGE = 201146;

		public const int LOGBOOKCODE_TM_CHANGE = 201147;

		public const int LOGBOOKCODE_T_MAX_CHANGE = 201148;

		public const int LOGBOOKCODE_T_MIN_CHANGE = 201149;

		public const int LOGBOOKCODE_TN_CHANGE = 201150;

		public const int LOGBOOKCODE_T_P_CHANGE = 201151;

		public const int LOGBOOKCODE_TYPE_CHANGE = 201152;

		public const int LOGBOOKCODE_USER_RIGHTS_CHANGE = 201153;

		public const int LOGBOOKCODE_W_MAX_CHANGE = 201154;

		public const int LOGBOOKCODE_W_MIN_CHANGE = 201155;

		public const int LOGBOOKCODE_WN_CHANGE = 201156;

		public const int LOGBOOKCODE_W_P_CHANGE = 201157;

		public const int LOGBOOKCODE_PRESSURE_SPINDLE_CHANGE = 201158;

		public const int LOGBOOKCODE_PRESSURE_SPINDLE_AUTO_CONVERSION = 201159;

		public const int LOGBOOKCODE_RESULTPARAM1_CHANGE = 201200;

		public const int LOGBOOKCODE_RESULTPARAM2_CHANGE = 201201;

		public const int LOGBOOKCODE_RESULTPARAM3_CHANGE = 201202;

		public const int LOGBOOKCODE_GRADIENTFILTER_CHANGE = 201203;

		public const int LOGBOOKCODE_GRADIENTLENGTH_CHANGE = 201204;

		public const int LOGBOOKCODE_M1_FILTERTIME_CHANGE = 201205;

		public const int LOGBOOKCODE_MAX_TIME_CHANGE = 201206;

		public const int LOGBOOKCODE_ENDSET_ANA_EXT_CHANGE = 201207;

		public const int LOGBOOKCODE_ENDSET_DIG_OUT1_CHANGE = 201208;

		public const int LOGBOOKCODE_ENDSET_DIG_OUT2_CHANGE = 201209;

		public const int LOGBOOKCODE_ENDSET_SYNC1_CHANGE = 201210;

		public const int LOGBOOKCODE_ENDSET_SYNC2_CHANGE = 201211;

		public const int LOGBOOKCODE_ENDVALUE_ANA_EXT_CHANGE = 201212;

		public const int LOGBOOKCODE_ENDVALUE_DIG_OUT1_CHANGE = 201213;

		public const int LOGBOOKCODE_ENDVALUE_DIG_OUT2_CHANGE = 201214;

		public const int LOGBOOKCODE_ENDVALUE_SYNC1_CHANGE = 201215;

		public const int LOGBOOKCODE_ENDVALUE_SYNC2_CHANGE = 201216;

		public const int LOGBOOKCODE_DEPTH_GRADIENTLENGTH_CHANGE = 201223;

		public const int LOGBOOKCODE_DEPTH_FILTERTIME_CHANGE = 201224;

		public const int LOGBOOKCODE_PRESSURE_HOLDER = 201225;

		public const int LOGBOOKCODE_SAVE_NOT_VERIFIED_DATA = 200000;

		public const int LOGBOOKCODE_IP1_CHANGE = 202000;

		public const int LOGBOOKCODE_IP2_CHANGE = 202001;

		public const int LOGBOOKCODE_IP3_CHANGE = 202002;

		public const int LOGBOOKCODE_SUBNET1_CHANGE = 202003;

		public const int LOGBOOKCODE_SUBNET2_CHANGE = 202004;

		public const int LOGBOOKCODE_SUBNET3_CHANGE = 202005;

		public const int LOGBOOKCODE_SUBNET4_CHANGE = 202006;

		public const int LOGBOOKCODE_DG1_CHANGE = 202007;

		public const int LOGBOOKCODE_DG2_CHANGE = 202008;

		public const int LOGBOOKCODE_DG3_CHANGE = 202009;

		public const int LOGBOOKCODE_DG4_CHANGE = 202010;

		public const int LOGBOOKCODE_DHCP_CHANGE = 202011;

		public const int LOGBOOKCODE_ID_CHANGE = 202012;

		public const int LOGBOOKCODE_IDENTSERVER_CHANGE = 202013;

		public const int LOGBOOKCODE_TORQUE_UNIT_CHANGE = 202014;

		public const int LOGBOOKCODE_TIME_CHANGE = 202015;

		public const int LOGBOOKCODE_BAUDRATE_CHANGE = 202016;

		public const int LOGBOOKCODE_PARITY_CHANGE = 202017;

		public const int LOGBOOKCODE_PASSCODE_CHANGE = 202018;

		public const int LOGBOOKCODE_AREACODE_CHANGE = 202019;

		public const int LOGBOOKCODE_USB_ACCESS_CHANGE = 202020;

		public const int LOGBOOKCODE_LEVEL_ASSIGNMENT_CHANGE = 202050;

		public const int LOGBOOKCODE_ADVANCEWARNING_LIMIT1_CHANGE = 202101;

		public const int LOGBOOKCODE_ADVANCEWARNING_LIMIT2_CHANGE = 202102;

		public const int LOGBOOKCODE_ADVANCEWARNING_LIMIT3_CHANGE = 202103;

		public const int LOGBOOKCODE_ADVANCEWARNING_LIMIT4_CHANGE = 202104;

		public const int LOGBOOKCODE_ADVANCEWARNING_LIMIT5_CHANGE = 202105;

		public const int LOGBOOKCODE_ADVANCEWARNING_NAME1_CHANGE = 202111;

		public const int LOGBOOKCODE_ADVANCEWARNING_NAME2_CHANGE = 202112;

		public const int LOGBOOKCODE_ADVANCEWARNING_NAME3_CHANGE = 202113;

		public const int LOGBOOKCODE_ADVANCEWARNING_NAME4_CHANGE = 202114;

		public const int LOGBOOKCODE_ADVANCEWARNING_NAME5_CHANGE = 202115;

		public const int LOGBOOKCODE_ADVANCEWARNING_ADVANCE1_CHANGE = 202121;

		public const int LOGBOOKCODE_ADVANCEWARNING_ADVANCE2_CHANGE = 202122;

		public const int LOGBOOKCODE_ADVANCEWARNING_ADVANCE3_CHANGE = 202123;

		public const int LOGBOOKCODE_ADVANCEWARNING_ADVANCE4_CHANGE = 202124;

		public const int LOGBOOKCODE_ADVANCEWARNING_ADVANCE5_CHANGE = 202125;

		public const int LOGBOOKCODE_ADVANCEWARNING_TIME5_CHANGE = 202135;

		public const int LOGBOOKCODE_ADVANCEWARNING_TIME5_ENABLE_CHANGE = 202145;

		public const int LOGBOOKCODE_ADVANCEWARNING_TIME5_ADVANCE_CHANGE = 202155;

		public const int LOGBOOKCODE_TORQUE_SENSOR_SCALE = 203000;

		public const int LOGBOOKCODE_TORQUE_SENSOR_TOLERANCE = 203001;

		public const int LOGBOOKCODE_ANGLE_SENSOR_SCALE = 203002;

		public const int LOGBOOKCODE_TORQUE_SENSOR_INVERS = 203003;

		public const int LOGBOOKCODE_ANGLE_SENSOR_INVERS = 203004;

		public const int LOGBOOKCODE_REDUNDANT_SENSOR_ACTIVE = 203005;

		public const int LOGBOOKCODE_TORQUE_REDUNDANT_TIME = 203006;

		public const int LOGBOOKCODE_TORQUE_REDUNDANT_TOLERANCE = 203007;

		public const int LOGBOOKCODE_DRIVE_UNIT_RPM = 203008;

		public const int LOGBOOKCODE_DRIVE_UNIT_INVERS = 203009;

		public const int LOGBOOKCODE_DEPTH_SENSOR_SCALE = 203010;

		public const int LOGBOOKCODE_DEPTH_SENSOR_OFFSET = 203011;

		public const int LOGBOOKCODE_DEPTH_SENSOR_INVERS = 203012;

		public const int LOGBOOKCODE_ANA_SIG_SCALE = 203013;

		public const int LOGBOOKCODE_ANA_SIG_OFFSET = 203014;

		public const int LOGBOOKCODE_SPINDLE_TORQUE = 203015;

		public const int LOGBOOKCODE_SPINDLE_GEAR_FACTOR = 203016;

		public const int LOGBOOKCODE_RELEASE_SPEED = 203017;

		public const int LOGBOOKCODE_FRICTION_TORQUE = 203018;

		public const int LOGBOOKCODE_FRICTION_SPEED = 203019;

		public const int LOGBOOKCODE_FRICTION_TEST_STARTUP = 203020;

		public const int LOGBOOKCODE_FRICTION_TEST_EMG = 203021;

		public const int LOGBOOKCODE_OFFSET_VOLTAGE_MIN = 203024;

		public const int LOGBOOKCODE_OFFSET_VOLTAGE_MAX = 203025;

		public const int LOGBOOKCODE_OFFSET_PRESET = 203026;

		public const int LOGBOOKCODE_ANGLE_REDUNDANT_TOLERANCE = 203027;

		public const int LOGBOOKCODE_PRESSURE_SCALE_SPINDLE = 203028;

		public const int LOGBOOKCODE_PRESSURE_SCALE_HOLDER = 203029;

		public const int LOGBOOKCODE_SPINDLE_CONFIGURATION_RESTORED_FROM_FILE = 203030;

		public const int LOGBOOKCODE_SCALE_KN_V = 203031;

		public const int LOGBOOKCODE_SCALE_1_V = 203032;

		public const int LOGBOOKCODE_TEACH_OFFSET = 100010;

		public const int LOGBOOKCODE_STAT_SAMPLE_DELETE = 204001;

		public const int LOGBOOKCODE_STAT_CYCLE_DELETE = 204002;

		public const int LOGBOOKCODE_STAT_CYCLE_NIO_DELETE = 204003;

		public const int LOGBOOKCODE_STAT_CYCLE_TOTAL_NIO_DELETE = 204004;

		public const int LOGBOOKCODE_STAT_COUNTER1_DELETE = 204011;

		public const int LOGBOOKCODE_STAT_COUNTER2_DELETE = 204012;

		public const int LOGBOOKCODE_STAT_COUNTER3_DELETE = 204013;

		public const int LOGBOOKCODE_STAT_COUNTER4_DELETE = 204014;

		public const int LOGBOOKCODE_STAT_COUNTER5_DELETE = 204015;

		public const int LOGBOOKCODE_BACKUP_CUST_SET = 205000;

		public const int LOGBOOKCODE_BACKUP_WEBER_SET = 205001;

		public const int LOGBOOKCODE_BACKUP_CUST_GET = 205002;

		public const int LOGBOOKCODE_BACKUP_WEBER_GET = 205003;

		public const int LOGBOOKCODE_BACKUP_FTP_DOWNLOAD = 205004;

		public const int LOGBOOKCODE_BACKUP_FTP_DOWNLOAD_ABORTED = 205005;

		public const int LOGBOOKCODE_BACKUP_FTP_UPLOAD = 205006;

		public const int LOGBOOKCODE_BACKUP_FTP_UPLOAD_ABORTED = 205007;

		public const int LOGBOOKCODE_BACKUP_FTP_DOWNLOAD_FAILED = 205008;

		public const int LOGBOOKCODE_BACKUP_FTP_UPLOAD_FAILED = 205009;

		public const int LOGBOOKCODE_USER_LOGGED_IN = 206001;

		public const int LOGBOOKCODE_USER_LOGGED_OUT = 206002;

		public const int LOGBOOKCODE_JAW_LOCAL_SETTINGS = 207000;

		public const int LOGBOOKCODE_JAW_DEPTH_GRAD_MIN = 207001;

		public const int LOGBOOKCODE_JAW_DEPTH_GRAD_MAX = 207002;

		public const int LOGBOOKCODE_JAW_OPEN_DISTANCE = 207003;

		public const int TORQUE_DIGITS = 2;

		public const int GRADIENT_DIGITS = 4;

		public const int DEPTH_GRADIENT_DIGITS = 4;

		public const int TIME_DIGITS = 2;

		public const int ANGLE_DIGITS = 1;

		public const int DEPTH_DIGITS = 1;

		public const int ANALOG_DIGITS = 2;

		public const int STATISTIC_DIGITS = 2;

		public const int PRESSURE_DIGITS = 2;

		public const float DEPTH_SENSOR_MAX = 10f;

		public const float ANA_SIGNAL_MAX = 10f;

		public const float ANGLE_MAX = 30000f;

		public const float GRADIENT_MAX = 100f;

		public const float DEPTH_GRADIENT_MAX = 1000f;

		public const float DEPTH_MAX = 999f;

		public const float TIME_STEP_MAX = 60f;

		public const float MAX_GLOBAL_SCREWTIME = 120f;

		public const float MAX_COUNT_PASS = 10f;

		public const float MAX_GRADIENT_LENGTH = 100f;

		public const float MAX_M1FILTER_TIME = 999f;

		public const float MAX_DEPTH_GRADIENT_LENGTH = 500f;

		public const float MAX_DEPTH_FILTER_TIME = 500f;

		public const float MAX_SPINDLE_PRESSURE_AT_6_BAR = 5f;

		public const float MAX_HOLDER_PRESSURE_AT_6_BAR = 2f;

		public const float TORQUE_NCM = 100f;

		public const float TORQUE_INLB = 8.850745f;

		public const float TORQUE_FTLB = 0.7375621f;

		public const float TORQUE_INOZ = 141.6119f;

		public const float TORQUE_KGM = 0.1019716f;

		public const float TORQUE_KGCM = 10.19716f;

		public const string TIME_FORMAT_EUROPEAN = "dd'.'MM'.'yyyy HH':'mm':'ss";

		public const string TIME_FORMAT_US = "MM'/'dd'/'yyyy HH':'mm':'ss";

		public const int LANGUAGE_ENGLISH = 0;

		public const int LANGUAGE_GERMAN = 1;

		public const int LANGUAGE_FRENCH = 2;

		public const int LANGUAGE_ITALIAN = 3;

		public const int LANGUAGE_SPANISH = 4;

		public const int LANGUAGE_CZECH = 5;

		public const int LANGUAGE_SLOVAK = 6;

		public const int LANGUAGE_HUNGARIAN = 7;

		public const int TIMESET_EUROPEAN = 0;

		public const int TIMESET_US = 1;

		public const byte UNIT_NOT_APPLICABLE = byte.MaxValue;

		public const byte UNIT_TORQUE = 0;

		public const byte UNIT_FILTEREDTORQUE = 1;

		public const byte UNIT_RELATIVETORQUE = 2;

		public const byte UNIT_M360FOLLOW = 3;

		public const byte UNIT_GRADIENT = 4;

		public const byte UNIT_ANGLE = 5;

		public const byte UNIT_TIME = 6;

		public const byte UNIT_ANADEPTH = 7;

		public const byte UNIT_DEPTHGRAD = 8;

		public const byte UNIT_ANASIGNAL = 9;

		public const byte UNIT_DIGITALSIGNAL = 10;

		public const byte UNIT_TORQUE_FROMABOVE = 11;

		public const byte UNIT_FILTEREDTORQUE_FROMABOVE = 12;

		public const byte UNIT_GRADIENT_FROMABOVE = 13;

		public const byte UNIT_ANADEPTH_FROMABOVE = 14;

		public const byte UNIT_DEPTHGRAD_FROMABOVE = 15;

		public const byte UNIT_ANASIGNAL_FROMABOVE = 16;

		public const byte UNIT_KILONEWTON = 17;

		public const byte UNIT_NUMBER_OF_FILES = 18;

		public const byte LOG_UNIT_DEGREE = 20;

		public const byte LOG_UNIT_SECOND = 21;

		public const byte LOG_UNIT_MILLIMETER = 22;

		public const byte LOG_UNIT_RPM = 23;

		public const byte LOG_UNIT_VOLTAGE = 24;

		public const byte LOG_UNIT_RERCENT = 25;

		public const byte LOG_UNIT_MILLISECOND = 26;

		public const byte LOG_UNIT_INCREMENT = 27;

		public const byte LOG_UNIT_ANGLE_INCREMENT = 28;

		public const byte LOG_UNIT_TORQUE_NM = 29;

		public const byte LOG_UNIT_TORQUE_NCM = 30;

		public const byte LOG_UNIT_TORQUEINLB = 31;

		public const byte LOG_UNIT_TORQUEFTLB = 32;

		public const byte LOG_UNIT_TORQUEKGM = 33;

		public const byte LOG_UNIT_TORQUEINOZ = 34;

		public const byte LOG_UNIT_TORQUEKGCM = 36;

		public const byte LOG_UNIT_BAR = 37;

		public const byte LOG_UNIT_MMPERVOLT = 38;

		public const byte LOG_UNIT_1PERVOLT = 39;

		public const byte LOG_UNIT_MM_PER_SECOND = 40;

		public const byte JAW_OPENING_RESERVE_6 = 64;

		public const byte JAW_OPENING_RESERVE_5 = 32;

		public const byte JAW_OPENING_RESERVE_4 = 16;

		public const byte JAW_OPENING_RESERVE_3 = 8;

		public const byte JAW_OPENING_RESERVE_2 = 4;

		public const byte JAW_OPENING_RESERVE_1 = 2;

		public const byte JAW_OPENING_ENABLE_LOCAL = 1;

		public const byte SP_CONST_RESERVE_6 = 64;

		public const byte SP_CONST_RESERVE_5 = 32;

		public const byte SP_CONST_RESERVE_4 = 16;

		public const byte SP_CONST_RESERVE_3 = 8;

		public const byte SP_CONST_RESERVE_2 = 4;

		public const byte SP_CONST_RESERVE_1 = 2;

		public const byte DISPLAY_SPINDLEPRESSURE_AS_KN = 1;

		public const byte LOG_LEVEL_I = 1;

		public const byte LOG_LEVEL_II = 2;

		public const byte LOG_LEVEL_III = 4;

		public const byte LOG_LEVEL_IV = 8;

		public const byte LOG_LEVEL_INVALIDATED = byte.MaxValue;

		public const byte MAINTENANCE_NO_ACTION = 0;

		public const byte MAINTENANCE_REMINDER = 1;

		public const byte MAINTENANCE_WARNING = 2;

		public const byte MAINTENANCE_FAULT = 3;

		public const byte PWLEVEL0 = 0;

		public const byte PWLEVEL1 = 1;

		public const byte PWLEVEL2 = 2;

		public const byte PWLEVEL3 = 3;

		public const byte PWLEVEL4 = 4;

		public const byte PWLEVEL5 = 5;

		public const byte PWLEVEL7 = 7;

		public const string AccessLevel0String = "ViewOnly";

		public const string AccessLevel1String = "Anagenbediener";

		public const string AccessLevel2String = "Straßenführer";

		public const string AccessLevel3String = "Instandhaltung";

		public const string AccessLevel4String = "Expertenebene";

		public const string AccessLevel5String = "Weber";

		public const string AccessLevel6String = "Weber";

		public const string AccessLevel7String = "Weber";

		public const string AccessLevelXString = "FreeAccess";

		public const int SHOW_WEBER_LOGO = 1;

		public const int SHOW_MVISU_ENTRY_LOGO = 2;

		public const int SHOW_EXIT_LOGO = 3;

		public const int FOUR_STEP_FIND_STEP_TYPE = 0;

		public const int FOUR_STEP_FLOW_DRILL_STEP_TYPE = 1;

		public const int FOUR_STEP_SCREW_STEP_TYPE = 2;

		public const int FOUR_STEP_TIGHTEN_STEP_TYPE = 3;

		public const int FOUR_STEP_RPM_TYPE = 0;

		public const int FOUR_STEP_PRESSURE_TYPE = 1;

		public const int FOUR_STEP_DEPTHGRAD_TYPE = 2;

		public const int FOUR_STEP_STEPTIME_TYPE = 3;

		public const int FOUR_STEP_DEPTH_TYPE = 4;

		public const int FOUR_STEP_MINTORQUE_TYPE = 5;

		public const int FOUR_STEP_MAXTORQUE_TYPE = 6;

		public const int FOUR_STEP_RAMPTIME_TYPE = 7;

		public const int FOUR_STEP_DELAYTORQUETIME_TYPE = 8;

		public const int FOUR_STEP_TARGETTIME_TYPE = 9;

		public const int FOUR_STEP_TARGETANGLE_TYPE = 10;

		public const int FOUR_STEP_TARGETTORQUE_TYPE = 11;

		public const int FOUR_STEP_MAXDEPTHGRADIENT_TYPE = 12;

		public const int FOUR_STEP_TORQUEGRADIENTMAX_TYPE = 13;

		public const int FOUR_STEP_TORQUEGRADIENTMIN_TYPE = 14;

		private List<string> accessLevelList = new List<string>();

		public C_Global()
		{
			this.accessLevelList.Add("Anagenbediener");
			this.accessLevelList.Add("Straßenführer");
			this.accessLevelList.Add("Instandhaltung");
			this.accessLevelList.Add("Expertenebene");
			this.accessLevelList.Add("Weber");
			this.accessLevelList.Add("Weber");
			this.accessLevelList.Add("Weber");
		}

		public string GetAccessLevelDefinition(int index)
		{
			if (index >= 0 && index < this.accessLevelList.Count)
			{
				return this.accessLevelList[index];
			}
			return this.accessLevelList[this.accessLevelList.Count - 1];
		}

		public string GetFourStepTypeDescription(int index, WSP1_VarComm.SpConst_Struct SP, ResourceManager Rm, float torqueConvert, string torqueUnitName, out string unit)
		{
			float num;
			return this.GetFourStepTypeDescription(index, SP, Rm, torqueConvert, torqueUnitName, out unit, out num, out num, out num);
		}

		public string GetFourStepTypeDescription(int index, WSP1_VarComm.SpConst_Struct SP, ResourceManager Rm, float torqueConvert, string torqueUnitName, out string unit, out float maxValue, out float minValue, out float decimalNum)
		{
			string result = null;
			unit = "";
			minValue = 0f;
			maxValue = 10000f;
			decimalNum = 0f;
			switch (index)
			{
			case 0:
				result = Rm.GetString("RoundsPerMinute");
				unit = Rm.GetString("RpmUnit");
				maxValue = SP.DriveUnitRpm / SP.SpindleGearFactor;
				minValue = -1f * SP.DriveUnitRpm / SP.SpindleGearFactor;
				break;
			case 1:
				result = Rm.GetString("PressureCylinder");
				unit = Rm.GetString("KiloNewton");
				decimalNum = 2f;
				maxValue = SP.PressureScaleSpindle * 6f;
				break;
			case 2:
				result = Rm.GetString("DepthGrad");
				unit = Rm.GetString("MillimeterPerSec");
				maxValue = 1000f * torqueConvert;
				minValue = -1000f * torqueConvert;
				decimalNum = 4f;
				decimalNum = 2f;
				break;
			case 3:
				result = Rm.GetString("StepTplus");
				unit = Rm.GetString("Second");
				decimalNum = 2f;
				maxValue = 60f;
				break;
			case 4:
				result = Rm.GetString("AnaDepth");
				unit = Rm.GetString("Milimeter");
				maxValue = 999f;
				minValue = -999f;
				decimalNum = 1f;
				break;
			case 5:
				result = Rm.GetString("Torque") + " " + Rm.GetString("Min") + "(" + Rm.GetString("M-") + ")";
				unit = torqueUnitName;
				maxValue = torqueConvert * SP.SpindleTorque;
				minValue = -1f * torqueConvert * SP.SpindleTorque;
				decimalNum = 2f;
				break;
			case 6:
				result = Rm.GetString("Torque") + " " + Rm.GetString("Max") + "(" + Rm.GetString("M+") + ")";
				unit = torqueUnitName;
				maxValue = torqueConvert * SP.SpindleTorque;
				minValue = -1f * torqueConvert * SP.SpindleTorque;
				decimalNum = 2f;
				break;
			case 7:
				result = Rm.GetString("Ramp");
				unit = Rm.GetString("Second");
				maxValue = 60f;
				decimalNum = 2f;
				break;
			case 8:
				result = Rm.GetString("MDelay");
				unit = Rm.GetString("Second");
				maxValue = 500f;
				decimalNum = 0f;
				break;
			case 9:
				result = Rm.GetString("Time");
				unit = Rm.GetString("Second");
				decimalNum = 2f;
				maxValue = 60f;
				break;
			case 10:
				result = Rm.GetString("Angle");
				unit = Rm.GetString("Degree");
				decimalNum = 1f;
				maxValue = 30000f;
				minValue = -30000f;
				break;
			case 11:
				result = Rm.GetString("Torque");
				unit = torqueUnitName;
				decimalNum = 2f;
				maxValue = torqueConvert * SP.SpindleTorque;
				minValue = -1f * torqueConvert * SP.SpindleTorque;
				break;
			case 12:
				result = Rm.GetString("DepthGrad") + " " + Rm.GetString("Max") + "(" + Rm.GetString("LG+") + ")";
				unit = Rm.GetString("Milimeter") + "/" + Rm.GetString("Second");
				decimalNum = 4f;
				maxValue = 1000f * torqueConvert;
				minValue = -1000f * torqueConvert;
				break;
			case 13:
				result = Rm.GetString("Gradient") + " " + Rm.GetString("Max") + "(" + Rm.GetString("MG+") + ")";
				unit = torqueUnitName + "/" + Rm.GetString("Degree");
				decimalNum = 4f;
				maxValue = 100f * torqueConvert;
				minValue = -100f * torqueConvert;
				break;
			case 14:
				result = Rm.GetString("Gradient") + " " + Rm.GetString("Min") + "(" + Rm.GetString("MG-") + ")";
				unit = torqueUnitName + "/" + Rm.GetString("Degree");
				decimalNum = 4f;
				maxValue = 100f * torqueConvert;
				minValue = -100f * torqueConvert;
				break;
			}
			return result;
		}

		public static byte GetCurrentLogUnitTorque(byte SysConstUnitTorque)
		{
			switch (SysConstUnitTorque)
			{
			case 0:
				return 29;
			case 1:
				return 30;
			case 2:
				return 31;
			case 3:
				return 32;
			case 4:
				return 34;
			case 5:
				return 33;
			case 6:
				return 36;
			default:
				return 29;
			}
		}
	}
}
