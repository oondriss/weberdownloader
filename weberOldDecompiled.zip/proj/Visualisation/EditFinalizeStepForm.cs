using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class EditFinalizeStepForm : Form
	{
		private MainForm Main;

		private WSP1_VarComm.StepStruct SD;

		private int PNum;

		private int SNum;

		private bool IsInitializeMode;

		private Panel pnMenu;

		private Button btDiscard;

		private Button btApply;

		private Button btNext;

		private Button btHelp;

		private Button btBack;

		private Container components;

		private Button btCheckPar;

		private Label lbUnitWN;

		private Label lbUnitTN;

		private NumberEdit1 nEWN;

		private NumberEdit1 nETN;

		private Label lbTN;

		private Label lbWN;

		private GroupBox gBHeader;

		private Label lbProgNum;

		private Label lbProgName;

		private Label lbStepType;

		private Label lbStepNum;

		private GroupBox gBTarget;

		private NumberEdit1 nETargetValue;

		private Label lbTargetUnit;

		private Label lbTarget;

		private ComboBox cBTargetName;

		private GroupBox gBDwell;

		private GroupBox gBRelease;

		private CheckBox chBRelease;

		private GroupBox gBDriveUnit;

		private Label lbUnitRamp;

		private Label lbUnitRpm;

		private NumberEdit1 nERamp;

		private NumberEdit1 nErpm;

		private Label lbRamp;

		private Label lbRpm;

		private Panel pnNormalTarget;

		private Panel pnMRTarget;

		private Label lbMRType;

		private ComboBox cBMRType;

		private Label lbMRStep;

		private NumberEdit1 nEMRStep;

		private Label lbUnitDwellCheck;

		private NumberEdit1 nEDwellCheck;

		private Label lbDwellCheck;

		private Panel pnMRCheck;

		private Panel pnTreshM;

		private Label lbUnitTreshM;

		private NumberEdit1 nETreshM;

		private CheckBox chBTreshM;

		private Label lbCheckpar;

		private Label lbMRmaxCheck;

		private Label lbUnitMRmaxCheck;

		private NumberEdit1 nEMRmaxCheck;

		private Panel pnMaxTime;

		private Label lbTplus;

		private Label lbUnitTplus;

		private NumberEdit1 nETplus;

		private GroupBox gBResult;

		private CheckBox chBRes1;

		private CheckBox chBRes2;

		private CheckBox chBRes3;

		private GroupBox gBRights;

		private CheckBox chBCheckRight;

		private CheckBox chBTargetRight;

		private CheckBox chBSetRight;

		private NumberEdit1 nEPressureSpindle;

		private Label lbPressureSpindle;

		private Button btCancel;

		private Label lbUnitSpindlePressureKN;

		private Button btPrevious;

		private bool bCanceled;

		private bool bInitializing;

		public bool WasCanceled
		{
			get
			{
				bool result = this.bCanceled;
				this.bCanceled = false;
				return result;
			}
		}

		public EditFinalizeStepForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.PNum = 0;
			this.SNum = 0;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btPrevious = new Button();
			this.btCancel = new Button();
			this.btDiscard = new Button();
			this.btApply = new Button();
			this.btNext = new Button();
			this.btCheckPar = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.gBDwell = new GroupBox();
			this.lbUnitTN = new Label();
			this.nETN = new NumberEdit1();
			this.lbTN = new Label();
			this.lbUnitWN = new Label();
			this.nEWN = new NumberEdit1();
			this.lbWN = new Label();
			this.gBHeader = new GroupBox();
			this.lbProgNum = new Label();
			this.lbProgName = new Label();
			this.lbStepType = new Label();
			this.lbStepNum = new Label();
			this.gBTarget = new GroupBox();
			this.pnMaxTime = new Panel();
			this.lbTplus = new Label();
			this.lbUnitTplus = new Label();
			this.nETplus = new NumberEdit1();
			this.lbCheckpar = new Label();
			this.pnTreshM = new Panel();
			this.chBTreshM = new CheckBox();
			this.lbUnitTreshM = new Label();
			this.nETreshM = new NumberEdit1();
			this.pnMRCheck = new Panel();
			this.lbMRmaxCheck = new Label();
			this.lbUnitMRmaxCheck = new Label();
			this.nEMRmaxCheck = new NumberEdit1();
			this.pnMRTarget = new Panel();
			this.nEMRStep = new NumberEdit1();
			this.lbMRStep = new Label();
			this.cBMRType = new ComboBox();
			this.lbMRType = new Label();
			this.pnNormalTarget = new Panel();
			this.lbTargetUnit = new Label();
			this.nETargetValue = new NumberEdit1();
			this.lbUnitDwellCheck = new Label();
			this.nEDwellCheck = new NumberEdit1();
			this.lbDwellCheck = new Label();
			this.lbTarget = new Label();
			this.cBTargetName = new ComboBox();
			this.gBRelease = new GroupBox();
			this.chBRelease = new CheckBox();
			this.gBDriveUnit = new GroupBox();
			this.lbUnitSpindlePressureKN = new Label();
			this.nEPressureSpindle = new NumberEdit1();
			this.lbPressureSpindle = new Label();
			this.lbUnitRamp = new Label();
			this.lbUnitRpm = new Label();
			this.nERamp = new NumberEdit1();
			this.nErpm = new NumberEdit1();
			this.lbRamp = new Label();
			this.lbRpm = new Label();
			this.gBResult = new GroupBox();
			this.chBRes3 = new CheckBox();
			this.chBRes2 = new CheckBox();
			this.chBRes1 = new CheckBox();
			this.gBRights = new GroupBox();
			this.chBCheckRight = new CheckBox();
			this.chBTargetRight = new CheckBox();
			this.chBSetRight = new CheckBox();
			this.pnMenu.SuspendLayout();
			this.gBDwell.SuspendLayout();
			this.gBHeader.SuspendLayout();
			this.gBTarget.SuspendLayout();
			this.pnMaxTime.SuspendLayout();
			this.pnTreshM.SuspendLayout();
			this.pnMRCheck.SuspendLayout();
			this.pnMRTarget.SuspendLayout();
			this.pnNormalTarget.SuspendLayout();
			this.gBRelease.SuspendLayout();
			this.gBDriveUnit.SuspendLayout();
			this.gBResult.SuspendLayout();
			this.gBRights.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btPrevious);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.btDiscard);
			this.pnMenu.Controls.Add(this.btApply);
			this.pnMenu.Controls.Add(this.btNext);
			this.pnMenu.Controls.Add(this.btCheckPar);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btPrevious.Location = new Point(3, 259);
			this.btPrevious.Name = "btPrevious";
			this.btPrevious.Size = new Size(74, 62);
			this.btPrevious.TabIndex = 4;
			this.btPrevious.Text = "Vorherige";
			this.btPrevious.Click += this.btPrevious_Click;
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 7;
			this.btCancel.Text = "Abbruch";
			this.btCancel.Click += this.btCancel_Click;
			this.btDiscard.Enabled = false;
			this.btDiscard.Location = new Point(3, 387);
			this.btDiscard.Name = "btDiscard";
			this.btDiscard.Size = new Size(74, 62);
			this.btDiscard.TabIndex = 6;
			this.btApply.Enabled = false;
			this.btApply.Location = new Point(3, 323);
			this.btApply.Name = "btApply";
			this.btApply.Size = new Size(74, 62);
			this.btApply.TabIndex = 5;
			this.btNext.Enabled = false;
			this.btNext.Location = new Point(3, 195);
			this.btNext.Name = "btNext";
			this.btNext.Size = new Size(74, 62);
			this.btNext.TabIndex = 3;
			this.btNext.Text = "Nächste";
			this.btNext.Click += this.btNext_Click;
			this.btCheckPar.Location = new Point(3, 131);
			this.btCheckPar.Name = "btCheckPar";
			this.btCheckPar.Size = new Size(74, 62);
			this.btCheckPar.TabIndex = 2;
			this.btCheckPar.Text = "Überwachungsparameter";
			this.btCheckPar.Click += this.btCheckPar_Click;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Fertig";
			this.btBack.Click += this.btBack_Click;
			this.gBDwell.Controls.Add(this.lbUnitTN);
			this.gBDwell.Controls.Add(this.nETN);
			this.gBDwell.Controls.Add(this.lbTN);
			this.gBDwell.Location = new Point(204, 365);
			this.gBDwell.Name = "gBDwell";
			this.gBDwell.Size = new Size(285, 59);
			this.gBDwell.TabIndex = 4;
			this.gBDwell.TabStop = false;
			this.lbUnitTN.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitTN.Location = new Point(242, 24);
			this.lbUnitTN.Name = "lbUnitTN";
			this.lbUnitTN.Size = new Size(37, 23);
			this.lbUnitTN.TabIndex = 34;
			this.lbUnitTN.Text = "s";
			this.lbUnitTN.TextAlign = ContentAlignment.MiddleLeft;
			this.nETN.BackColor = Color.White;
			this.nETN.DecimalNum = 2;
			this.nETN.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETN.ForeColor = SystemColors.ControlText;
			this.nETN.Location = new Point(162, 20);
			this.nETN.MaxValue = 10f;
			this.nETN.MinValue = 0f;
			this.nETN.Name = "nETN";
			this.nETN.Size = new Size(74, 28);
			this.nETN.TabIndex = 0;
			this.nETN.Text = "0,00";
			this.nETN.TextAlign = HorizontalAlignment.Right;
			this.nETN.Value = 0f;
			this.nETN.TextChanged += this.settingsChanged;
			this.nETN.Enter += this.Start_Input;
			this.nETN.MouseDown += this.StartInput;
			this.lbTN.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTN.Location = new Point(8, 24);
			this.lbTN.Name = "lbTN";
			this.lbTN.Size = new Size(148, 23);
			this.lbTN.TabIndex = 32;
			this.lbTN.Text = "Nachlaufzeit";
			this.lbTN.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitWN.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitWN.Location = new Point(242, 45);
			this.lbUnitWN.Name = "lbUnitWN";
			this.lbUnitWN.Size = new Size(37, 23);
			this.lbUnitWN.TabIndex = 35;
			this.lbUnitWN.Text = "°";
			this.lbUnitWN.TextAlign = ContentAlignment.MiddleLeft;
			this.nEWN.BackColor = Color.White;
			this.nEWN.DecimalNum = 0;
			this.nEWN.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEWN.ForeColor = SystemColors.ControlText;
			this.nEWN.Location = new Point(162, 45);
			this.nEWN.MaxValue = 30000f;
			this.nEWN.MinValue = 0f;
			this.nEWN.Name = "nEWN";
			this.nEWN.Size = new Size(74, 28);
			this.nEWN.TabIndex = 1;
			this.nEWN.Text = "0";
			this.nEWN.TextAlign = HorizontalAlignment.Right;
			this.nEWN.Value = 0f;
			this.nEWN.TextChanged += this.settingsChanged;
			this.nEWN.Enter += this.Start_Input;
			this.nEWN.MouseDown += this.StartInput;
			this.lbWN.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbWN.Location = new Point(5, 50);
			this.lbWN.Name = "lbWN";
			this.lbWN.Size = new Size(151, 23);
			this.lbWN.TabIndex = 31;
			this.lbWN.Text = "Entspannwinkel";
			this.lbWN.TextAlign = ContentAlignment.MiddleLeft;
			this.gBHeader.Controls.Add(this.lbProgNum);
			this.gBHeader.Controls.Add(this.lbProgName);
			this.gBHeader.Controls.Add(this.lbStepType);
			this.gBHeader.Controls.Add(this.lbStepNum);
			this.gBHeader.Location = new Point(6, 8);
			this.gBHeader.Name = "gBHeader";
			this.gBHeader.Size = new Size(696, 64);
			this.gBHeader.TabIndex = 1;
			this.gBHeader.TabStop = false;
			this.lbProgNum.BorderStyle = BorderStyle.Fixed3D;
			this.lbProgNum.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgNum.Location = new Point(8, 24);
			this.lbProgNum.Name = "lbProgNum";
			this.lbProgNum.Size = new Size(95, 23);
			this.lbProgNum.TabIndex = 17;
			this.lbProgNum.Text = "Prog. 1023";
			this.lbProgNum.TextAlign = ContentAlignment.MiddleLeft;
			this.lbProgName.BorderStyle = BorderStyle.Fixed3D;
			this.lbProgName.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgName.Location = new Point(109, 24);
			this.lbProgName.Name = "lbProgName";
			this.lbProgName.Size = new Size(232, 23);
			this.lbProgName.TabIndex = 16;
			this.lbProgName.Text = "Name";
			this.lbProgName.TextAlign = ContentAlignment.MiddleLeft;
			this.lbStepType.BorderStyle = BorderStyle.Fixed3D;
			this.lbStepType.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbStepType.Location = new Point(472, 24);
			this.lbStepType.Name = "lbStepType";
			this.lbStepType.Size = new Size(192, 23);
			this.lbStepType.TabIndex = 15;
			this.lbStepType.Text = "Typ";
			this.lbStepType.TextAlign = ContentAlignment.MiddleLeft;
			this.lbStepNum.BorderStyle = BorderStyle.Fixed3D;
			this.lbStepNum.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbStepNum.Location = new Point(392, 24);
			this.lbStepNum.Name = "lbStepNum";
			this.lbStepNum.Size = new Size(72, 23);
			this.lbStepNum.TabIndex = 14;
			this.lbStepNum.Text = "Stufe 25";
			this.lbStepNum.TextAlign = ContentAlignment.MiddleLeft;
			this.gBTarget.Controls.Add(this.pnMaxTime);
			this.gBTarget.Controls.Add(this.lbCheckpar);
			this.gBTarget.Controls.Add(this.pnTreshM);
			this.gBTarget.Controls.Add(this.pnMRCheck);
			this.gBTarget.Controls.Add(this.pnMRTarget);
			this.gBTarget.Controls.Add(this.pnNormalTarget);
			this.gBTarget.Controls.Add(this.lbUnitDwellCheck);
			this.gBTarget.Controls.Add(this.nEDwellCheck);
			this.gBTarget.Controls.Add(this.lbDwellCheck);
			this.gBTarget.Controls.Add(this.lbTarget);
			this.gBTarget.Controls.Add(this.cBTargetName);
			this.gBTarget.Location = new Point(6, 173);
			this.gBTarget.Name = "gBTarget";
			this.gBTarget.Size = new Size(696, 184);
			this.gBTarget.TabIndex = 3;
			this.gBTarget.TabStop = false;
			this.pnMaxTime.Controls.Add(this.lbTplus);
			this.pnMaxTime.Controls.Add(this.lbUnitTplus);
			this.pnMaxTime.Controls.Add(this.nETplus);
			this.pnMaxTime.Location = new Point(8, 104);
			this.pnMaxTime.Name = "pnMaxTime";
			this.pnMaxTime.Size = new Size(336, 28);
			this.pnMaxTime.TabIndex = 62;
			this.lbTplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTplus.Location = new Point(0, 3);
			this.lbTplus.Name = "lbTplus";
			this.lbTplus.Size = new Size(152, 23);
			this.lbTplus.TabIndex = 43;
			this.lbTplus.Text = "Maximale Zeit";
			this.lbTplus.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitTplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitTplus.Location = new Point(272, 3);
			this.lbUnitTplus.Name = "lbUnitTplus";
			this.lbUnitTplus.Size = new Size(56, 23);
			this.lbUnitTplus.TabIndex = 44;
			this.lbUnitTplus.Text = "s";
			this.lbUnitTplus.TextAlign = ContentAlignment.MiddleLeft;
			this.nETplus.BackColor = Color.White;
			this.nETplus.DecimalNum = 2;
			this.nETplus.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETplus.ForeColor = Color.Red;
			this.nETplus.Location = new Point(160, 0);
			this.nETplus.MaxValue = 60f;
			this.nETplus.MinValue = 0.1f;
			this.nETplus.Name = "nETplus";
			this.nETplus.Size = new Size(104, 28);
			this.nETplus.TabIndex = 4;
			this.nETplus.Text = "0,00";
			this.nETplus.TextAlign = HorizontalAlignment.Right;
			this.nETplus.Value = 0f;
			this.nETplus.TextChanged += this.settingsChanged;
			this.nETplus.Enter += this.Start_Input;
			this.nETplus.MouseDown += this.StartInput;
			this.lbCheckpar.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbCheckpar.Location = new Point(8, 141);
			this.lbCheckpar.Name = "lbCheckpar";
			this.lbCheckpar.Size = new Size(152, 23);
			this.lbCheckpar.TabIndex = 61;
			this.lbCheckpar.Text = "Checkparameter";
			this.lbCheckpar.TextAlign = ContentAlignment.MiddleLeft;
			this.pnTreshM.Controls.Add(this.chBTreshM);
			this.pnTreshM.Controls.Add(this.lbUnitTreshM);
			this.pnTreshM.Controls.Add(this.nETreshM);
			this.pnTreshM.Location = new Point(168, 61);
			this.pnTreshM.Name = "pnTreshM";
			this.pnTreshM.Size = new Size(520, 28);
			this.pnTreshM.TabIndex = 60;
			this.chBTreshM.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBTreshM.Location = new Point(0, 3);
			this.chBTreshM.Name = "chBTreshM";
			this.chBTreshM.Size = new Size(160, 24);
			this.chBTreshM.TabIndex = 108;
			this.chBTreshM.Text = "Schwellmoment";
			this.chBTreshM.CheckedChanged += this.chBxx_CheckedChanged;
			this.chBTreshM.Enter += this.Start_Input;
			this.lbUnitTreshM.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitTreshM.Location = new Point(280, 3);
			this.lbUnitTreshM.Name = "lbUnitTreshM";
			this.lbUnitTreshM.RightToLeft = RightToLeft.No;
			this.lbUnitTreshM.Size = new Size(72, 23);
			this.lbUnitTreshM.TabIndex = 87;
			this.lbUnitTreshM.Text = "Nm";
			this.lbUnitTreshM.TextAlign = ContentAlignment.MiddleLeft;
			this.nETreshM.BackColor = Color.White;
			this.nETreshM.DecimalNum = 2;
			this.nETreshM.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETreshM.ForeColor = SystemColors.ControlText;
			this.nETreshM.Location = new Point(168, 0);
			this.nETreshM.MaxValue = 50000f;
			this.nETreshM.MinValue = -50000f;
			this.nETreshM.Name = "nETreshM";
			this.nETreshM.Size = new Size(104, 28);
			this.nETreshM.TabIndex = 85;
			this.nETreshM.Text = "0,00";
			this.nETreshM.TextAlign = HorizontalAlignment.Right;
			this.nETreshM.Value = 0f;
			this.nETreshM.TextChanged += this.settingsChanged;
			this.nETreshM.Enter += this.Start_Input;
			this.nETreshM.MouseDown += this.StartInput;
			this.pnMRCheck.Controls.Add(this.lbMRmaxCheck);
			this.pnMRCheck.Controls.Add(this.lbUnitMRmaxCheck);
			this.pnMRCheck.Controls.Add(this.nEMRmaxCheck);
			this.pnMRCheck.Location = new Point(428, 141);
			this.pnMRCheck.Name = "pnMRCheck";
			this.pnMRCheck.Size = new Size(260, 28);
			this.pnMRCheck.TabIndex = 52;
			this.lbMRmaxCheck.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMRmaxCheck.Location = new Point(0, 3);
			this.lbMRmaxCheck.Name = "lbMRmaxCheck";
			this.lbMRmaxCheck.Size = new Size(72, 23);
			this.lbMRmaxCheck.TabIndex = 50;
			this.lbMRmaxCheck.Text = "M+";
			this.lbMRmaxCheck.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitMRmaxCheck.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitMRmaxCheck.Location = new Point(192, 3);
			this.lbUnitMRmaxCheck.Name = "lbUnitMRmaxCheck";
			this.lbUnitMRmaxCheck.Size = new Size(56, 23);
			this.lbUnitMRmaxCheck.TabIndex = 51;
			this.lbUnitMRmaxCheck.Text = "s";
			this.lbUnitMRmaxCheck.TextAlign = ContentAlignment.MiddleLeft;
			this.nEMRmaxCheck.BackColor = Color.White;
			this.nEMRmaxCheck.DecimalNum = 2;
			this.nEMRmaxCheck.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMRmaxCheck.ForeColor = SystemColors.ControlText;
			this.nEMRmaxCheck.Location = new Point(80, 0);
			this.nEMRmaxCheck.MaxValue = 10f;
			this.nEMRmaxCheck.MinValue = 0f;
			this.nEMRmaxCheck.Name = "nEMRmaxCheck";
			this.nEMRmaxCheck.Size = new Size(104, 28);
			this.nEMRmaxCheck.TabIndex = 49;
			this.nEMRmaxCheck.Text = "0,00";
			this.nEMRmaxCheck.TextAlign = HorizontalAlignment.Right;
			this.nEMRmaxCheck.Value = 0f;
			this.nEMRmaxCheck.TextChanged += this.settingsChanged;
			this.nEMRmaxCheck.Enter += this.Start_Input;
			this.nEMRmaxCheck.MouseDown += this.StartInput;
			this.pnMRTarget.Controls.Add(this.nEMRStep);
			this.pnMRTarget.Controls.Add(this.lbMRStep);
			this.pnMRTarget.Controls.Add(this.cBMRType);
			this.pnMRTarget.Controls.Add(this.lbMRType);
			this.pnMRTarget.Location = new Point(168, 61);
			this.pnMRTarget.Name = "pnMRTarget";
			this.pnMRTarget.Size = new Size(520, 28);
			this.pnMRTarget.TabIndex = 2;
			this.nEMRStep.BackColor = Color.White;
			this.nEMRStep.DecimalNum = 0;
			this.nEMRStep.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMRStep.ForeColor = SystemColors.ControlText;
			this.nEMRStep.Location = new Point(400, 0);
			this.nEMRStep.MaxValue = 25f;
			this.nEMRStep.MinValue = 1f;
			this.nEMRStep.Name = "nEMRStep";
			this.nEMRStep.Size = new Size(40, 28);
			this.nEMRStep.TabIndex = 1;
			this.nEMRStep.Text = "1";
			this.nEMRStep.TextAlign = HorizontalAlignment.Right;
			this.nEMRStep.Value = 1f;
			this.nEMRStep.TextChanged += this.settingsChanged;
			this.nEMRStep.Enter += this.Start_Input;
			this.nEMRStep.MouseDown += this.StartInput;
			this.lbMRStep.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMRStep.Location = new Point(312, 3);
			this.lbMRStep.Name = "lbMRStep";
			this.lbMRStep.Size = new Size(80, 23);
			this.lbMRStep.TabIndex = 46;
			this.lbMRStep.Text = "Stufe";
			this.lbMRStep.TextAlign = ContentAlignment.MiddleLeft;
			this.cBMRType.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBMRType.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBMRType.Items.AddRange(new object[3]
			{
				"Moment",
				"gef. M.",
				"max. M."
			});
			this.cBMRType.Location = new Point(120, 0);
			this.cBMRType.MaxDropDownItems = 7;
			this.cBMRType.Name = "cBMRType";
			this.cBMRType.Size = new Size(168, 28);
			this.cBMRType.TabIndex = 0;
			this.cBMRType.SelectedIndexChanged += this.settingsChanged;
			this.lbMRType.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMRType.Location = new Point(0, 3);
			this.lbMRType.Name = "lbMRType";
			this.lbMRType.Size = new Size(120, 23);
			this.lbMRType.TabIndex = 44;
			this.lbMRType.Text = "bezogen auf";
			this.lbMRType.TextAlign = ContentAlignment.MiddleLeft;
			this.pnNormalTarget.Controls.Add(this.lbTargetUnit);
			this.pnNormalTarget.Controls.Add(this.nETargetValue);
			this.pnNormalTarget.Location = new Point(368, 21);
			this.pnNormalTarget.Name = "pnNormalTarget";
			this.pnNormalTarget.Size = new Size(320, 28);
			this.pnNormalTarget.TabIndex = 1;
			this.lbTargetUnit.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTargetUnit.Location = new Point(104, 3);
			this.lbTargetUnit.Name = "lbTargetUnit";
			this.lbTargetUnit.Size = new Size(104, 23);
			this.lbTargetUnit.TabIndex = 39;
			this.lbTargetUnit.Text = "Einheit";
			this.lbTargetUnit.TextAlign = ContentAlignment.MiddleLeft;
			this.nETargetValue.BackColor = Color.White;
			this.nETargetValue.DecimalNum = 2;
			this.nETargetValue.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETargetValue.ForeColor = SystemColors.ControlText;
			this.nETargetValue.Location = new Point(0, 0);
			this.nETargetValue.MaxValue = 30000f;
			this.nETargetValue.MinValue = -30000f;
			this.nETargetValue.Name = "nETargetValue";
			this.nETargetValue.Size = new Size(96, 28);
			this.nETargetValue.TabIndex = 1;
			this.nETargetValue.Text = "0,00";
			this.nETargetValue.TextAlign = HorizontalAlignment.Right;
			this.nETargetValue.Value = 0f;
			this.nETargetValue.TextChanged += this.settingsChanged;
			this.nETargetValue.Enter += this.Start_Input;
			this.nETargetValue.MouseDown += this.StartInput;
			this.lbUnitDwellCheck.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitDwellCheck.Location = new Point(360, 144);
			this.lbUnitDwellCheck.Name = "lbUnitDwellCheck";
			this.lbUnitDwellCheck.Size = new Size(56, 23);
			this.lbUnitDwellCheck.TabIndex = 48;
			this.lbUnitDwellCheck.Text = "s";
			this.lbUnitDwellCheck.TextAlign = ContentAlignment.MiddleLeft;
			this.nEDwellCheck.BackColor = Color.White;
			this.nEDwellCheck.DecimalNum = 2;
			this.nEDwellCheck.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDwellCheck.ForeColor = SystemColors.ControlText;
			this.nEDwellCheck.Location = new Point(248, 141);
			this.nEDwellCheck.MaxValue = 10f;
			this.nEDwellCheck.MinValue = 0f;
			this.nEDwellCheck.Name = "nEDwellCheck";
			this.nEDwellCheck.Size = new Size(104, 28);
			this.nEDwellCheck.TabIndex = 4;
			this.nEDwellCheck.Text = "0,00";
			this.nEDwellCheck.TextAlign = HorizontalAlignment.Right;
			this.nEDwellCheck.Value = 0f;
			this.nEDwellCheck.TextChanged += this.settingsChanged;
			this.nEDwellCheck.Enter += this.Start_Input;
			this.nEDwellCheck.MouseDown += this.StartInput;
			this.lbDwellCheck.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDwellCheck.Location = new Point(168, 144);
			this.lbDwellCheck.Name = "lbDwellCheck";
			this.lbDwellCheck.Size = new Size(72, 23);
			this.lbDwellCheck.TabIndex = 47;
			this.lbDwellCheck.Text = "M+";
			this.lbDwellCheck.TextAlign = ContentAlignment.MiddleLeft;
			this.lbTarget.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTarget.Location = new Point(8, 24);
			this.lbTarget.Name = "lbTarget";
			this.lbTarget.Size = new Size(152, 23);
			this.lbTarget.TabIndex = 38;
			this.lbTarget.Text = "Zielparameter:";
			this.lbTarget.TextAlign = ContentAlignment.MiddleLeft;
			this.cBTargetName.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBTargetName.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBTargetName.Items.AddRange(new object[7]
			{
				"Moment",
				"gefiltertes Moment",
				"relatives Moment",
				"Gradient",
				"Winkel",
				"Analogtiefe",
				"Ext. Analogsignal"
			});
			this.cBTargetName.Location = new Point(168, 21);
			this.cBTargetName.Name = "cBTargetName";
			this.cBTargetName.Size = new Size(192, 28);
			this.cBTargetName.TabIndex = 0;
			this.cBTargetName.SelectedIndexChanged += this.cBTargetName_SelectedIndexChanged;
			this.gBRelease.Controls.Add(this.chBRelease);
			this.gBRelease.Controls.Add(this.lbWN);
			this.gBRelease.Controls.Add(this.lbUnitWN);
			this.gBRelease.Controls.Add(this.nEWN);
			this.gBRelease.Location = new Point(204, 430);
			this.gBRelease.Name = "gBRelease";
			this.gBRelease.Size = new Size(285, 83);
			this.gBRelease.TabIndex = 5;
			this.gBRelease.TabStop = false;
			this.chBRelease.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBRelease.Location = new Point(8, 19);
			this.chBRelease.Name = "chBRelease";
			this.chBRelease.Size = new Size(152, 24);
			this.chBRelease.TabIndex = 0;
			this.chBRelease.Text = "Entspannen";
			this.chBRelease.CheckedChanged += this.chBxx_CheckedChanged;
			this.gBDriveUnit.Controls.Add(this.lbUnitSpindlePressureKN);
			this.gBDriveUnit.Controls.Add(this.nEPressureSpindle);
			this.gBDriveUnit.Controls.Add(this.lbPressureSpindle);
			this.gBDriveUnit.Controls.Add(this.lbUnitRamp);
			this.gBDriveUnit.Controls.Add(this.lbUnitRpm);
			this.gBDriveUnit.Controls.Add(this.nERamp);
			this.gBDriveUnit.Controls.Add(this.nErpm);
			this.gBDriveUnit.Controls.Add(this.lbRamp);
			this.gBDriveUnit.Controls.Add(this.lbRpm);
			this.gBDriveUnit.Location = new Point(6, 77);
			this.gBDriveUnit.Name = "gBDriveUnit";
			this.gBDriveUnit.Size = new Size(696, 90);
			this.gBDriveUnit.TabIndex = 2;
			this.gBDriveUnit.TabStop = false;
			this.lbUnitSpindlePressureKN.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitSpindlePressureKN.Location = new Point(280, 57);
			this.lbUnitSpindlePressureKN.Name = "lbUnitSpindlePressureKN";
			this.lbUnitSpindlePressureKN.Size = new Size(56, 23);
			this.lbUnitSpindlePressureKN.TabIndex = 51;
			this.lbUnitSpindlePressureKN.Text = "kN";
			this.lbUnitSpindlePressureKN.TextAlign = ContentAlignment.MiddleLeft;
			this.nEPressureSpindle.BackColor = Color.White;
			this.nEPressureSpindle.DecimalNum = 2;
			this.nEPressureSpindle.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEPressureSpindle.ForeColor = SystemColors.ControlText;
			this.nEPressureSpindle.Location = new Point(168, 54);
			this.nEPressureSpindle.MaxValue = 10000f;
			this.nEPressureSpindle.MinValue = 0f;
			this.nEPressureSpindle.Name = "nEPressureSpindle";
			this.nEPressureSpindle.Size = new Size(104, 28);
			this.nEPressureSpindle.TabIndex = 48;
			this.nEPressureSpindle.Text = "0,00";
			this.nEPressureSpindle.TextAlign = HorizontalAlignment.Right;
			this.nEPressureSpindle.Value = 0f;
			this.nEPressureSpindle.TextChanged += this.settingsChanged;
			this.nEPressureSpindle.Enter += this.Start_Input;
			this.nEPressureSpindle.MouseDown += this.StartInput;
			this.lbPressureSpindle.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbPressureSpindle.Location = new Point(8, 57);
			this.lbPressureSpindle.Name = "lbPressureSpindle";
			this.lbPressureSpindle.Size = new Size(152, 23);
			this.lbPressureSpindle.TabIndex = 49;
			this.lbPressureSpindle.Text = "Spindeldruck";
			this.lbPressureSpindle.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitRamp.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitRamp.Location = new Point(632, 24);
			this.lbUnitRamp.Name = "lbUnitRamp";
			this.lbUnitRamp.Size = new Size(56, 23);
			this.lbUnitRamp.TabIndex = 47;
			this.lbUnitRamp.Text = "s";
			this.lbUnitRamp.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitRpm.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitRpm.Location = new Point(280, 24);
			this.lbUnitRpm.Name = "lbUnitRpm";
			this.lbUnitRpm.Size = new Size(56, 23);
			this.lbUnitRpm.TabIndex = 46;
			this.lbUnitRpm.Text = "1/min";
			this.lbUnitRpm.TextAlign = ContentAlignment.MiddleLeft;
			this.nERamp.BackColor = Color.White;
			this.nERamp.DecimalNum = 2;
			this.nERamp.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nERamp.ForeColor = SystemColors.ControlText;
			this.nERamp.Location = new Point(520, 21);
			this.nERamp.MaxValue = 10f;
			this.nERamp.MinValue = 0f;
			this.nERamp.Name = "nERamp";
			this.nERamp.Size = new Size(104, 28);
			this.nERamp.TabIndex = 1;
			this.nERamp.Text = "0,00";
			this.nERamp.TextAlign = HorizontalAlignment.Right;
			this.nERamp.Value = 0f;
			this.nERamp.TextChanged += this.settingsChanged;
			this.nERamp.Enter += this.Start_Input;
			this.nERamp.MouseDown += this.StartInput;
			this.nErpm.BackColor = Color.White;
			this.nErpm.DecimalNum = 0;
			this.nErpm.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nErpm.ForeColor = SystemColors.ControlText;
			this.nErpm.Location = new Point(168, 21);
			this.nErpm.MaxValue = 10000f;
			this.nErpm.MinValue = -10000f;
			this.nErpm.Name = "nErpm";
			this.nErpm.Size = new Size(104, 28);
			this.nErpm.TabIndex = 0;
			this.nErpm.Text = "0";
			this.nErpm.TextAlign = HorizontalAlignment.Right;
			this.nErpm.Value = 0f;
			this.nErpm.TextChanged += this.settingsChanged;
			this.nErpm.Enter += this.Start_Input;
			this.nErpm.MouseDown += this.StartInput;
			this.lbRamp.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbRamp.Location = new Point(362, 15);
			this.lbRamp.Name = "lbRamp";
			this.lbRamp.Size = new Size(152, 40);
			this.lbRamp.TabIndex = 45;
			this.lbRamp.Text = "Rampe:";
			this.lbRamp.TextAlign = ContentAlignment.MiddleLeft;
			this.lbRpm.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbRpm.Location = new Point(8, 24);
			this.lbRpm.Name = "lbRpm";
			this.lbRpm.Size = new Size(152, 23);
			this.lbRpm.TabIndex = 44;
			this.lbRpm.Text = "Drehzahl:";
			this.lbRpm.TextAlign = ContentAlignment.MiddleLeft;
			this.gBResult.Controls.Add(this.chBRes3);
			this.gBResult.Controls.Add(this.chBRes2);
			this.gBResult.Controls.Add(this.chBRes1);
			this.gBResult.Location = new Point(6, 365);
			this.gBResult.Name = "gBResult";
			this.gBResult.Size = new Size(192, 136);
			this.gBResult.TabIndex = 6;
			this.gBResult.TabStop = false;
			this.gBResult.Text = "Auswertung";
			this.chBRes3.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBRes3.Location = new Point(16, 88);
			this.chBRes3.Name = "chBRes3";
			this.chBRes3.Size = new Size(160, 24);
			this.chBRes3.TabIndex = 111;
			this.chBRes3.Text = "Ergebnis 3";
			this.chBRes3.CheckedChanged += this.settingsChanged;
			this.chBRes2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBRes2.Location = new Point(16, 56);
			this.chBRes2.Name = "chBRes2";
			this.chBRes2.Size = new Size(160, 24);
			this.chBRes2.TabIndex = 110;
			this.chBRes2.Text = "Ergebnis 2";
			this.chBRes2.CheckedChanged += this.settingsChanged;
			this.chBRes1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBRes1.Location = new Point(16, 24);
			this.chBRes1.Name = "chBRes1";
			this.chBRes1.Size = new Size(160, 24);
			this.chBRes1.TabIndex = 109;
			this.chBRes1.Text = "Ergebnis 1";
			this.chBRes1.CheckedChanged += this.settingsChanged;
			this.gBRights.Controls.Add(this.chBCheckRight);
			this.gBRights.Controls.Add(this.chBTargetRight);
			this.gBRights.Controls.Add(this.chBSetRight);
			this.gBRights.Location = new Point(495, 365);
			this.gBRights.Name = "gBRights";
			this.gBRights.Size = new Size(207, 136);
			this.gBRights.TabIndex = 50;
			this.gBRights.TabStop = false;
			this.gBRights.Text = "Berechtigung Bediener";
			this.chBCheckRight.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBCheckRight.Location = new Point(16, 88);
			this.chBCheckRight.Name = "chBCheckRight";
			this.chBCheckRight.Size = new Size(185, 24);
			this.chBCheckRight.TabIndex = 111;
			this.chBCheckRight.Text = "Überwachung";
			this.chBCheckRight.CheckedChanged += this.settingsChanged;
			this.chBTargetRight.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBTargetRight.Location = new Point(16, 56);
			this.chBTargetRight.Name = "chBTargetRight";
			this.chBTargetRight.Size = new Size(185, 24);
			this.chBTargetRight.TabIndex = 110;
			this.chBTargetRight.Text = "Zielwerte";
			this.chBTargetRight.CheckedChanged += this.settingsChanged;
			this.chBSetRight.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBSetRight.Location = new Point(16, 24);
			this.chBSetRight.Name = "chBSetRight";
			this.chBSetRight.Size = new Size(185, 24);
			this.chBSetRight.TabIndex = 109;
			this.chBSetRight.Text = "Sollwerte";
			this.chBSetRight.CheckedChanged += this.settingsChanged;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.gBRights);
			base.Controls.Add(this.gBResult);
			base.Controls.Add(this.gBDriveUnit);
			base.Controls.Add(this.gBRelease);
			base.Controls.Add(this.gBDwell);
			base.Controls.Add(this.gBHeader);
			base.Controls.Add(this.gBTarget);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "EditFinalizeStepForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen/Programme/Stufen/Stufe bearbeiten";
			base.Activated += this.EditFinalizeStepForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBDwell.ResumeLayout(false);
			this.gBDwell.PerformLayout();
			this.gBHeader.ResumeLayout(false);
			this.gBTarget.ResumeLayout(false);
			this.gBTarget.PerformLayout();
			this.pnMaxTime.ResumeLayout(false);
			this.pnMaxTime.PerformLayout();
			this.pnTreshM.ResumeLayout(false);
			this.pnTreshM.PerformLayout();
			this.pnMRCheck.ResumeLayout(false);
			this.pnMRCheck.PerformLayout();
			this.pnMRTarget.ResumeLayout(false);
			this.pnMRTarget.PerformLayout();
			this.pnNormalTarget.ResumeLayout(false);
			this.pnNormalTarget.PerformLayout();
			this.gBRelease.ResumeLayout(false);
			this.gBRelease.PerformLayout();
			this.gBDriveUnit.ResumeLayout(false);
			this.gBDriveUnit.PerformLayout();
			this.gBResult.ResumeLayout(false);
			this.gBRights.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public bool ShowWindow(int progNum, int stepNum)
		{
			if (stepNum >= 0 && stepNum <= 24)
			{
				this.Main.ResetBrowserGrantedBy();
				this.IsInitializeMode = true;
				this.SNum = stepNum;
				this.PNum = progNum;
				this.SD = this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Step[this.SNum];
				this.InitializeValues();
				this.MenEna();
				base.Show();
				this.IsInitializeMode = false;
				return true;
			}
			return false;
		}

		public void SetLanguageTexts()
		{
			bool isInitializeMode = this.IsInitializeMode;
			this.bInitializing = true;
			string[] array = new string[8];
			string[] array2 = new string[4];
			array[0] = this.Main.Rm.GetString("Torque") + string.Empty;
			array[1] = this.Main.Rm.GetString("FilteredTorque") + string.Empty;
			array[2] = this.Main.Rm.GetString("RelativeTorque") + string.Empty;
			array[3] = this.Main.Rm.GetString("M360Follow") + string.Empty;
			array[4] = this.Main.Rm.GetString("Gradient") + string.Empty;
			array[5] = this.Main.Rm.GetString("Angle") + string.Empty;
			array[6] = this.Main.Rm.GetString("AnaDepth") + string.Empty;
			array[7] = this.Main.Rm.GetString("AnaSignal") + string.Empty;
			array2[0] = this.Main.Rm.GetString("Torque") + string.Empty;
			array2[1] = this.Main.Rm.GetString("FilteredTorque") + string.Empty;
			array2[2] = this.Main.Rm.GetString("MaxTorque") + string.Empty;
			array2[3] = this.Main.Rm.GetString("DelayTorque") + string.Empty;
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MProgramOverview") + "/" + this.Main.Rm.GetString("MStepOverview") + "/" + this.Main.Rm.GetString("MEditStep");
			this.btBack.Text = this.Main.Rm.GetString("Done");
			this.btCheckPar.Text = this.Main.Rm.GetString("CheckParameter");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btCancel.Text = this.Main.Rm.GetString("btCancel");
			this.btNext.Text = this.Main.Rm.GetString("btNext");
			this.btPrevious.Text = this.Main.Rm.GetString("btPrevious");
			this.lbRamp.Text = this.Main.Rm.GetString("Ramp");
			this.lbRpm.Text = this.Main.Rm.GetString("RoundsPerMinute");
			this.lbUnitRpm.Text = this.Main.Rm.GetString("RpmUnit");
			this.lbTarget.Text = this.Main.Rm.GetString("Target");
			this.lbTN.Text = this.Main.Rm.GetString("TN");
			this.lbTplus.Text = this.Main.Rm.GetString("StepTplus");
			this.lbWN.Text = this.Main.Rm.GetString("WN");
			this.lbUnitRamp.Text = this.Main.Rm.GetString("Second");
			this.lbUnitTplus.Text = this.Main.Rm.GetString("Second");
			this.lbUnitTN.Text = this.Main.Rm.GetString("Second");
			this.lbUnitWN.Text = this.Main.Rm.GetString("Degree");
			this.lbMRStep.Text = this.Main.Rm.GetString("OfStep");
			this.lbMRType.Text = this.Main.Rm.GetString("relatedTo");
			this.lbUnitMRmaxCheck.Text = this.Main.TorqueUnitName;
			this.lbMRmaxCheck.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("M+") + ")";
			this.chBRelease.Text = this.Main.Rm.GetString("Release");
			this.cBTargetName.Items.Clear();
			this.cBTargetName.Items.AddRange(array);
			this.cBMRType.Items.Clear();
			this.cBMRType.Items.AddRange(array2);
			this.cBMRType.SelectedIndex = 0;
			this.gBResult.Text = this.Main.Rm.GetString("gBResultDisplay");
			this.chBRes1.Text = this.Main.Rm.GetString("Result") + " 1";
			this.chBRes2.Text = this.Main.Rm.GetString("Result") + " 2";
			this.chBRes3.Text = this.Main.Rm.GetString("Result") + " 3";
			this.chBTreshM.Text = this.Main.Rm.GetString("TreshTorque");
			this.chBCheckRight.Text = this.Main.Rm.GetString("CheckRight");
			this.chBSetRight.Text = this.Main.Rm.GetString("SetRight");
			this.chBTargetRight.Text = this.Main.Rm.GetString("TargetRight");
			this.gBRights.Text = this.Main.Rm.GetString("UserRights");
			this.lbPressureSpindle.Text = this.Main.Rm.GetString("PressureCylinder");
			this.lbUnitSpindlePressureKN.Text = this.Main.Rm.GetString("KiloNewton");
			this.bInitializing = isInitializeMode;
		}

		private void MenEna()
		{
			if ((this.SD.UserRights & 1) == 1 && this.Main.PassCodeLevel > 0)
			{
				goto IL_0035;
			}
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_EditSteps)
			{
				goto IL_0035;
			}
			bool flag = false;
			goto IL_003b;
			IL_0070:
			bool flag2 = true;
			goto IL_0076;
			IL_0076:
			if ((this.SD.UserRights & 4) == 4 && this.Main.PassCodeLevel > 0)
			{
				goto IL_00ab;
			}
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_EditSteps)
			{
				goto IL_00ab;
			}
			bool enabled = false;
			goto IL_00b1;
			IL_0035:
			flag = true;
			goto IL_003b;
			IL_00ab:
			enabled = true;
			goto IL_00b1;
			IL_003b:
			if ((this.SD.UserRights & 2) == 2 && this.Main.PassCodeLevel > 0)
			{
				goto IL_0070;
			}
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_EditSteps)
			{
				goto IL_0070;
			}
			flag2 = false;
			goto IL_0076;
			IL_00b1:
			bool enabled2 = false;
			bool enabled3 = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_EditSteps)
			{
				enabled3 = true;
			}
			if (this.Main.PassCodeLevel >= 1)
			{
				enabled2 = true;
			}
			if (this.Main.ViewOnlyMode)
			{
				enabled2 = false;
				enabled3 = false;
				flag = false;
				flag2 = false;
				enabled = false;
			}
			if (this.Main.IsOfflineVersion)
			{
				enabled2 = true;
				enabled3 = true;
				flag = true;
				flag2 = true;
				enabled = true;
			}
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_EditSteps, this.Main.ViewOnlyMode);
			this.chBRelease.Enabled = enabled3;
			this.cBTargetName.Enabled = enabled3;
			this.nETplus.Enabled = enabled;
			this.nErpm.Enabled = flag2;
			this.nERamp.Enabled = flag2;
			this.nEPressureSpindle.Enabled = flag2;
			this.nETN.Enabled = enabled;
			this.nEWN.Enabled = (flag2 && this.chBRelease.Checked);
			this.nETargetValue.Enabled = flag;
			this.cBMRType.Enabled = enabled3;
			this.nEMRStep.Enabled = enabled3;
			this.nEDwellCheck.Enabled = enabled;
			this.nEMRmaxCheck.Enabled = enabled;
			this.nETreshM.Enabled = (flag && this.chBTreshM.Checked);
			this.chBTreshM.Enabled = enabled3;
			this.chBRes1.Enabled = enabled3;
			this.chBRes2.Enabled = enabled3;
			this.chBRes3.Enabled = enabled3;
			this.chBCheckRight.Enabled = enabled3;
			this.chBSetRight.Enabled = enabled3;
			this.chBTargetRight.Enabled = enabled3;
			this.btBack.Enabled = enabled2;
			this.nETplus.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nErpm.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEPressureSpindle.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nERamp.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nETN.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEWN.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nETargetValue.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMRStep.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDwellCheck.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMRmaxCheck.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nETreshM.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			if (this.SNum == 0)
			{
				this.btPrevious.Enabled = false;
			}
			else
			{
				this.btPrevious.Enabled = true;
			}
			if (this.SNum >= this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Info.Steps - 1)
			{
				this.btNext.Enabled = false;
			}
			else
			{
				this.btNext.Enabled = true;
			}
		}

		private bool ApplyValues()
		{
			string text = string.Empty;
			if (!this.nErpm.IsOK)
			{
				text = text + this.lbRpm.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nErpm.MinValue.ToString() + " - " + this.nErpm.MaxValue.ToString() + "\n";
			}
			if (!this.nERamp.IsOK)
			{
				text = text + this.lbRamp.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nERamp.MinValue.ToString() + " - " + this.nERamp.MaxValue.ToString() + "\n";
			}
			if (!this.nEPressureSpindle.IsOK)
			{
				text = text + this.lbPressureSpindle.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEPressureSpindle.MinValue.ToString() + " - " + this.nEPressureSpindle.MaxValue.ToString() + "\n";
			}
			if (!this.nETargetValue.IsOK)
			{
				text = text + this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nETargetValue.MinValue.ToString() + " - " + this.nETargetValue.MaxValue.ToString() + "\n";
			}
			if (this.cBTargetName.SelectedIndex == 2 && !this.nEMRStep.IsOK)
			{
				text = text + this.Main.Rm.GetString("RelTorqueStep") + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMRStep.MinValue.ToString() + " - " + this.nEMRStep.MaxValue.ToString() + "\n";
			}
			if (this.cBTargetName.SelectedIndex == 4 && !this.nETreshM.IsOK)
			{
				text = text + this.chBTreshM.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nETreshM.MinValue.ToString() + " - " + this.nETreshM.MaxValue.ToString() + "\n";
			}
			if (!this.nETplus.IsOK)
			{
				text = text + this.lbTplus.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nETplus.MinValue.ToString() + " - " + this.nETplus.MaxValue.ToString() + "\n";
			}
			if (!this.nEDwellCheck.IsOK)
			{
				text = text + this.lbDwellCheck.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEDwellCheck.MinValue.ToString() + " - " + this.nEDwellCheck.MaxValue.ToString() + "\n";
			}
			if (this.cBTargetName.SelectedIndex == 2 && !this.nEMRmaxCheck.IsOK)
			{
				text = text + this.lbMRmaxCheck.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMRmaxCheck.MinValue.ToString() + " - " + this.nEMRmaxCheck.MaxValue.ToString() + "\n";
			}
			if (this.cBTargetName.SelectedIndex == 2 && this.nErpm.Value > 0f && this.nEMRmaxCheck.Value < this.nEDwellCheck.Value)
			{
				text = text + this.lbMRmaxCheck.Text + " " + this.Main.Rm.GetString("PosOverload") + " " + this.lbDwellCheck.Text + "\n";
			}
			if (this.cBTargetName.SelectedIndex == 2 && this.nErpm.Value < 0f && this.nEMRmaxCheck.Value > this.nEDwellCheck.Value)
			{
				text = text + this.lbMRmaxCheck.Text + " " + this.Main.Rm.GetString("NegOverload") + " " + this.lbDwellCheck.Text + "\n";
			}
			if (!this.nETN.IsOK)
			{
				text = text + this.lbTN.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nETN.MinValue.ToString() + " - " + this.nETN.MaxValue.ToString() + "\n";
			}
			if (this.chBRelease.Checked && !this.nEWN.IsOK)
			{
				text = text + this.lbWN.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEWN.MinValue.ToString() + " - " + this.nEWN.MaxValue.ToString() + "\n";
			}
			if (this.Main.CheckParamAllowed && text != string.Empty)
			{
				MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + text, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.SD.NA = this.nErpm.Value;
			this.SD.PressureSpindle = this.nEPressureSpindle.Value;
			this.SD.Tmax = this.nETplus.Value;
			this.SD.TM = this.nERamp.Value;
			this.SD.TN = this.nETN.Value;
			if (this.chBRelease.Checked)
			{
				this.SD.Enable.Release = 1;
			}
			else
			{
				this.SD.Enable.Release = 0;
			}
			this.SD.WN = this.nEWN.Value;
			if (this.chBRes1.Checked)
			{
				this.SD.IsResult1 = 1;
			}
			else
			{
				this.SD.IsResult1 = 0;
			}
			if (this.chBRes2.Checked)
			{
				this.SD.IsResult2 = 1;
			}
			else
			{
				this.SD.IsResult2 = 0;
			}
			if (this.chBRes3.Checked)
			{
				this.SD.IsResult3 = 1;
			}
			else
			{
				this.SD.IsResult3 = 0;
			}
			byte b = 0;
			if (this.chBTargetRight.Checked)
			{
				b = (byte)(b + 1);
			}
			if (this.chBSetRight.Checked)
			{
				b = (byte)(b + 2);
			}
			if (this.chBCheckRight.Checked)
			{
				b = (byte)(b + 4);
			}
			this.SD.UserRights = b;
			switch (this.cBTargetName.SelectedIndex)
			{
			case 0:
				this.SD.Switch = 1;
				this.SD.MP = this.nETargetValue.Value / this.Main.TorqueConvert;
				this.SD.Enable.Torque = 1;
				this.SD.Mmax = this.nEDwellCheck.Value / this.Main.TorqueConvert;
				break;
			case 1:
				this.SD.Switch = 3;
				this.SD.MFP = this.nETargetValue.Value / this.Main.TorqueConvert;
				this.SD.Enable.FTorque = 1;
				this.SD.MFmax = this.nEDwellCheck.Value / this.Main.TorqueConvert;
				break;
			case 2:
				this.SD.Switch = 2;
				this.SD.MRP = this.nETargetValue.Value / this.Main.TorqueConvert;
				this.SD.Enable.Torque = 1;
				this.SD.Mmin = this.nEDwellCheck.Value / this.Main.TorqueConvert;
				switch (this.cBMRType.SelectedIndex)
				{
				case 0:
					this.SD.MRType = 1;
					break;
				case 1:
					this.SD.MRType = 3;
					break;
				case 2:
					this.SD.MRType = 2;
					break;
				case 3:
					this.SD.MRType = 10;
					break;
				default:
					MessageBox.Show("Wrong selected index 1 in ApplyValues() of EditFinalizeStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					this.SD.MRType = 1;
					break;
				}
				this.SD.MRStep = (byte)(this.nEMRStep.Value - 1f);
				this.SD.Enable.Torque = 1;
				this.SD.Mmax = this.nEMRmaxCheck.Value / this.Main.TorqueConvert;
				break;
			case 3:
				this.SD.Switch = 11;
				this.SD.MRP = this.nETargetValue.Value / this.Main.TorqueConvert;
				this.SD.Enable.Torque = 1;
				this.SD.Mmin = this.nEDwellCheck.Value / this.Main.TorqueConvert;
				this.SD.Mmax = this.nEMRmaxCheck.Value / this.Main.TorqueConvert;
				break;
			case 4:
				this.SD.Switch = 4;
				this.SD.MGP = this.nETargetValue.Value / this.Main.TorqueConvert;
				this.SD.Enable.GradientMax = 1;
				this.SD.MGmax = this.nEDwellCheck.Value / this.Main.TorqueConvert;
				break;
			case 5:
				this.SD.Switch = 5;
				this.SD.WP = this.nETargetValue.Value;
				this.SD.Enable.Angle = 1;
				this.SD.Wmax = this.nEDwellCheck.Value;
				if (this.chBTreshM.Checked)
				{
					this.SD.Enable.Snug = 1;
					this.SD.MS = this.nETreshM.Value / this.Main.TorqueConvert;
				}
				else
				{
					this.SD.Enable.Snug = 0;
				}
				break;
			case 6:
				this.SD.Switch = 7;
				this.SD.LP = this.nETargetValue.Value;
				this.SD.Enable.ADepth = 1;
				this.SD.Lmax = this.nEDwellCheck.Value;
				this.SD.Lmin = this.nETargetValue.Value;
				break;
			case 7:
				this.SD.Switch = 8;
				this.SD.AnaP = this.nETargetValue.Value;
				this.SD.Enable.Ana = 1;
				this.SD.AnaMax = this.nEDwellCheck.Value;
				this.SD.AnaMin = this.nETargetValue.Value;
				break;
			default:
				MessageBox.Show("Wrong selected index 2 in ApplyValues() of EditFinalizeStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				break;
			}
			return true;
		}

		private void InitializeValues()
		{
			this.bInitializing = true;
			this.lbUnitTreshM.Text = this.Main.TorqueUnitName;
			this.lbUnitMRmaxCheck.Text = this.Main.TorqueUnitName;
			this.nErpm.MaxValue = this.Main.VC.SpConst.DriveUnitRpm / this.Main.VC.SpConst.SpindleGearFactor;
			this.nErpm.MinValue = -1f * this.Main.VC.SpConst.DriveUnitRpm / this.Main.VC.SpConst.SpindleGearFactor;
			this.nERamp.MaxValue = 60f;
			this.nEPressureSpindle.MaxValue = this.Main.VC.SpConst.PressureScaleSpindle * 6f;
			this.nEPressureSpindle.MinValue = 0f;
			this.nEMRStep.MaxValue = (float)(int)this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Info.Steps;
			this.nETplus.MaxValue = 60f;
			this.nETN.MaxValue = 60f;
			this.nEWN.MaxValue = 30000f;
			this.nEMRmaxCheck.MaxValue = this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMRmaxCheck.MinValue = (0f - this.Main.TorqueConvert) * this.Main.VC.SpConst.SpindleTorque;
			this.nETreshM.MaxValue = this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nETreshM.MinValue = (0f - this.Main.TorqueConvert) * this.Main.VC.SpConst.SpindleTorque;
			this.nERamp.DecimalNum = 2;
			this.nEPressureSpindle.DecimalNum = 2;
			this.nETplus.DecimalNum = 2;
			this.nEMRmaxCheck.DecimalNum = 2;
			this.nETreshM.DecimalNum = 2;
			this.nETN.DecimalNum = 2;
			this.nEWN.DecimalNum = 1;
			this.lbProgNum.Text = this.Main.Rm.GetString("Abr_Program") + " " + this.PNum.ToString();
			this.lbProgName.Text = this.Main.CommonFunctions.UShortToString(this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Info.Name);
			this.lbStepNum.Text = this.Main.Rm.GetString("Step") + " " + (this.SNum + 1).ToString();
			this.lbStepType.Text = this.Main.Rm.GetString("FinalizingStep");
			switch (this.SD.Switch)
			{
			case 0:
				this.cBTargetName.SelectedIndex = 0;
				break;
			case 1:
				this.cBTargetName.SelectedIndex = 0;
				break;
			case 3:
				this.cBTargetName.SelectedIndex = 1;
				break;
			case 2:
				this.cBTargetName.SelectedIndex = 2;
				break;
			case 11:
				this.cBTargetName.SelectedIndex = 3;
				break;
			case 4:
				this.cBTargetName.SelectedIndex = 4;
				break;
			case 5:
				this.cBTargetName.SelectedIndex = 5;
				break;
			case 7:
				this.cBTargetName.SelectedIndex = 6;
				break;
			case 8:
				this.cBTargetName.SelectedIndex = 7;
				break;
			default:
				MessageBox.Show("Wrong switch type in InitializeValues() of EditFinalizeStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.cBTargetName.SelectedIndex = 0;
				break;
			}
			this.SetTargetParameter();
			switch (this.SD.MRType)
			{
			case 0:
				this.cBMRType.SelectedIndex = 0;
				break;
			case 1:
				this.cBMRType.SelectedIndex = 0;
				break;
			case 3:
				this.cBMRType.SelectedIndex = 1;
				break;
			case 2:
				this.cBMRType.SelectedIndex = 2;
				break;
			case 10:
				this.cBMRType.SelectedIndex = 3;
				break;
			default:
				MessageBox.Show("Wrong relative type in InitializeValues() of EditFinalizeStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.cBMRType.SelectedIndex = 0;
				break;
			}
			this.nEMRStep.Value = (float)(int)this.SD.MRStep + 1f;
			this.nErpm.Value = this.SD.NA;
			this.nERamp.Value = this.SD.TM;
			this.nEPressureSpindle.Value = this.SD.PressureSpindle;
			this.nETplus.Value = this.SD.Tmax;
			this.nEMRmaxCheck.Value = this.SD.Mmax * this.Main.TorqueConvert;
			this.nETN.Value = this.SD.TN;
			if (this.SD.IsResult1 == 1)
			{
				this.chBRes1.Checked = true;
			}
			else
			{
				this.chBRes1.Checked = false;
			}
			if (this.SD.IsResult2 == 1)
			{
				this.chBRes2.Checked = true;
			}
			else
			{
				this.chBRes2.Checked = false;
			}
			if (this.SD.IsResult3 == 1)
			{
				this.chBRes3.Checked = true;
			}
			else
			{
				this.chBRes3.Checked = false;
			}
			if (this.SD.Enable.Snug == 1)
			{
				this.chBTreshM.Checked = true;
			}
			else
			{
				this.chBTreshM.Checked = false;
			}
			if (this.SD.Enable.Release == 1)
			{
				this.chBRelease.Checked = true;
			}
			else
			{
				this.chBRelease.Checked = false;
			}
			this.nEWN.Value = this.SD.WN;
			this.nETreshM.Value = this.SD.MS * this.Main.TorqueConvert;
			if ((this.SD.UserRights & 1) == 1)
			{
				this.chBTargetRight.Checked = true;
			}
			else
			{
				this.chBTargetRight.Checked = false;
			}
			if ((this.SD.UserRights & 2) == 2)
			{
				this.chBSetRight.Checked = true;
			}
			else
			{
				this.chBSetRight.Checked = false;
			}
			if ((this.SD.UserRights & 4) == 4)
			{
				this.chBCheckRight.Checked = true;
			}
			else
			{
				this.chBCheckRight.Checked = false;
			}
			this.bInitializing = false;
		}

		private void cBTargetName_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (!this.bInitializing && !this.IsInitializeMode)
			{
				this.Main.SettingsChanged();
				this.SD.Enable.ADepth = 0;
				this.SD.Enable.Ana = 0;
				this.SD.Enable.Angle = 0;
				this.SD.Enable.FTorque = 0;
				this.SD.Enable.GradientMin = 0;
				this.SD.Enable.GradientMax = 0;
				this.SD.Enable.ADepthGradMax = 0;
				this.SD.Enable.ADepthGradMin = 0;
				this.SD.Enable.Time = 0;
				this.SD.Enable.Torque = 0;
				this.SD.Enable.Snug = 0;
				this.SD.DigMax = 0;
				this.SD.DigMin = 0;
				this.chBTreshM.Checked = false;
				this.SetTargetParameter();
			}
		}

		private void SetTargetParameter()
		{
			switch (this.cBTargetName.SelectedIndex)
			{
			case 0:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.MP * this.Main.TorqueConvert;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName;
				this.nEDwellCheck.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nEDwellCheck.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nEDwellCheck.DecimalNum = 2;
				this.nEDwellCheck.Value = this.SD.Mmax * this.Main.TorqueConvert;
				this.lbUnitDwellCheck.Text = this.Main.TorqueUnitName;
				this.lbCheckpar.Text = this.Main.Rm.GetString("Torque");
				this.lbDwellCheck.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("M+") + ")";
				this.pnMRTarget.Visible = false;
				this.pnMRCheck.Visible = false;
				this.pnTreshM.Visible = false;
				break;
			case 1:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.MFP * this.Main.TorqueConvert;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName;
				this.nEDwellCheck.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nEDwellCheck.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nEDwellCheck.DecimalNum = 2;
				this.nEDwellCheck.Value = this.SD.MFmax * this.Main.TorqueConvert;
				this.lbUnitDwellCheck.Text = this.Main.TorqueUnitName;
				this.lbCheckpar.Text = this.Main.Rm.GetString("FilteredTorque");
				this.lbDwellCheck.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("MF+") + ")";
				this.pnMRTarget.Visible = false;
				this.pnMRCheck.Visible = false;
				this.pnTreshM.Visible = false;
				break;
			case 2:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.MRP * this.Main.TorqueConvert;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName;
				this.nEDwellCheck.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nEDwellCheck.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nEDwellCheck.DecimalNum = 2;
				this.nEDwellCheck.Value = this.SD.Mmin * this.Main.TorqueConvert;
				this.lbUnitDwellCheck.Text = this.Main.TorqueUnitName;
				this.lbCheckpar.Text = this.Main.Rm.GetString("Torque");
				this.lbDwellCheck.Text = this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("M-") + ")";
				this.pnMRTarget.Visible = true;
				this.pnMRCheck.Visible = true;
				this.pnTreshM.Visible = false;
				break;
			case 3:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.MRP * this.Main.TorqueConvert;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName;
				this.nEDwellCheck.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nEDwellCheck.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nEDwellCheck.DecimalNum = 2;
				this.nEDwellCheck.Value = this.SD.Mmin * this.Main.TorqueConvert;
				this.lbUnitDwellCheck.Text = this.Main.TorqueUnitName;
				this.lbCheckpar.Text = this.Main.Rm.GetString("Torque");
				this.lbDwellCheck.Text = this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("M-") + ")";
				this.pnMRTarget.Visible = false;
				this.pnMRCheck.Visible = true;
				this.pnTreshM.Visible = false;
				break;
			case 4:
				this.nETargetValue.MaxValue = 100f * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -100f * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 4;
				this.nETargetValue.Value = this.SD.MGP * this.Main.TorqueConvert;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName + "/" + this.Main.Rm.GetString("Degree");
				this.nEDwellCheck.MaxValue = 100f * this.Main.TorqueConvert;
				this.nEDwellCheck.MinValue = -100f * this.Main.TorqueConvert;
				this.nEDwellCheck.DecimalNum = 4;
				this.nEDwellCheck.Value = this.SD.MGmax * this.Main.TorqueConvert;
				this.lbUnitDwellCheck.Text = this.Main.TorqueUnitName + "/" + this.Main.Rm.GetString("Degree");
				this.lbCheckpar.Text = this.Main.Rm.GetString("Gradient");
				this.lbDwellCheck.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("MG+") + ")";
				this.pnMRTarget.Visible = false;
				this.pnMRCheck.Visible = false;
				this.pnTreshM.Visible = false;
				break;
			case 5:
				this.nETargetValue.MaxValue = 30000f;
				this.nETargetValue.MinValue = -30000f;
				this.nETargetValue.DecimalNum = 1;
				this.nETargetValue.Value = this.SD.WP;
				this.lbTargetUnit.Text = this.Main.Rm.GetString("Degree");
				this.nEDwellCheck.MaxValue = 30000f;
				this.nEDwellCheck.MinValue = -30000f;
				this.nEDwellCheck.DecimalNum = 1;
				this.nEDwellCheck.Value = this.SD.Wmax;
				this.lbUnitDwellCheck.Text = this.Main.Rm.GetString("Degree");
				this.lbCheckpar.Text = this.Main.Rm.GetString("Angle");
				this.lbDwellCheck.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("W+") + ")";
				this.pnMRTarget.Visible = false;
				this.pnMRCheck.Visible = false;
				this.pnTreshM.Visible = true;
				break;
			case 6:
				this.nETargetValue.MaxValue = 999f;
				this.nETargetValue.MinValue = -999f;
				this.nETargetValue.DecimalNum = 1;
				this.nETargetValue.Value = this.SD.LP;
				this.lbTargetUnit.Text = this.Main.Rm.GetString("Milimeter");
				this.nEDwellCheck.MaxValue = 999f;
				this.nEDwellCheck.MinValue = -999f;
				this.nEDwellCheck.DecimalNum = 1;
				this.nEDwellCheck.Value = this.SD.Lmax;
				this.lbUnitDwellCheck.Text = this.Main.Rm.GetString("Milimeter");
				this.lbCheckpar.Text = this.Main.Rm.GetString("AnaDepth");
				this.lbDwellCheck.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("L+") + ")";
				this.pnMRTarget.Visible = false;
				this.pnMRCheck.Visible = false;
				this.pnTreshM.Visible = false;
				break;
			case 7:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.AnaSigScale * (10f + this.Main.VC.SpConst.AnaSigOffset);
				this.nETargetValue.MinValue = this.Main.VC.SpConst.AnaSigScale * (-10f + this.Main.VC.SpConst.AnaSigOffset);
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.AnaP;
				this.lbTargetUnit.Text = string.Empty;
				this.nEDwellCheck.MaxValue = this.Main.VC.SpConst.AnaSigScale * 10f;
				this.nEDwellCheck.MinValue = -10f * this.Main.VC.SpConst.AnaSigScale;
				this.nEDwellCheck.DecimalNum = 2;
				this.nEDwellCheck.Value = this.SD.AnaMax;
				this.lbUnitDwellCheck.Text = string.Empty;
				this.lbCheckpar.Text = this.Main.Rm.GetString("AnaSignal");
				this.lbDwellCheck.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("AS+") + ")";
				this.pnMRTarget.Visible = false;
				this.pnMRCheck.Visible = false;
				this.pnTreshM.Visible = false;
				break;
			default:
				MessageBox.Show("Wrong selected index in SetTargetParameter() of EditFinalizeStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				break;
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.gBHeader.Select();
				this.pnMenu.Enabled = false;
				this.Main.ProcessProgram.CompareStepStruct(this.SD, this.Main.VC.PProg.Num[this.PNum].Step[this.SNum], this.PNum, this.SNum, 4);
				this.Main.StatusBarText(string.Empty);
				this.Main.StepOverview1.StepButtonShow();
				base.Hide();
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap6_4_2_StufentypAbschluss";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap6_4_2_StufentypAbschluss");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btCheckPar_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.gBHeader.Select();
				this.pnMenu.Enabled = false;
				this.Main.CheckParam1.ShowWindow(this.PNum, this.SNum);
			}
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void chBxx_CheckedChanged(object sender, EventArgs e)
		{
			this.settingsChanged(sender, e);
			this.MenEna();
		}

		private void EditFinalizeStepForm_Activated(object sender, EventArgs e)
		{
			this.MenEna();
			this.bCanceled = false;
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.Main.DeleteLogEntries(4, this.PNum);
			this.bCanceled = true;
			this.gBHeader.Select();
			this.pnMenu.Enabled = false;
			this.Main.StatusBarText(string.Empty);
			base.Hide();
		}

		public void KeyArrived()
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else if (this.Main.PassCodeLevel > 0)
			{
				if (this.Main.GetExclusiveBlock1())
				{
					if (this.Main.ProcessProgram.UploadAllProgDataFromController())
					{
						this.Main.CheckParamAllowed = true;
						base.Hide();
						this.Main.StepOverview1.Hide();
					}
				}
				else
				{
					this.Main.CheckParamAllowed = false;
				}
			}
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void btPrevious_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.gBHeader.Select();
				this.pnMenu.Enabled = false;
				this.Main.ProcessProgram.CompareStepStruct(this.SD, this.Main.VC.PProg.Num[this.PNum].Step[this.SNum], this.PNum, this.SNum, 4);
				this.Main.StatusBarText(string.Empty);
				base.Hide();
				this.Main.StepOverview1.EditPreviousStep();
			}
		}

		private void btNext_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.gBHeader.Select();
				this.pnMenu.Enabled = false;
				this.Main.ProcessProgram.CompareStepStruct(this.SD, this.Main.VC.PProg.Num[this.PNum].Step[this.SNum], this.PNum, this.SNum, 4);
				this.Main.StatusBarText(string.Empty);
				base.Hide();
				this.Main.StepOverview1.EditPreviousStep();
			}
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.bInitializing)
			{
				this.Main.SettingsChanged();
			}
		}
	}
}
