using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class CheckParamForm : Form
	{
		private MainForm Main;

		private WSP1_VarComm.StepStruct SD;

		private int PNum;

		private int SNum;

		private Panel pnMenu;

		private Button bt2;

		private Button bt1;

		private Button btHelp;

		private Button btBack;

		private Panel pnCheckPar;

		private Container components;

		private CheckBox chBTorque;

		private CheckBox chBAngle;

		private CheckBox chBFiltTorque;

		private CheckBox chBAnaDepth;

		private CheckBox chBExtAnaSignal;

		private Label lbUnitWplus;

		private Label lbUnitLplus;

		private Label lbUnitMplus;

		private Label lbUnitMFplus;

		private NumberEdit1 nEASplus;

		private NumberEdit1 nELplus;

		private NumberEdit1 nEMFplus;

		private NumberEdit1 nEMplus;

		private NumberEdit1 nEWplus;

		private Label lbWplus;

		private Label lbLplus;

		private Label lbMplus;

		private Label lbMFplus;

		private Label lbASplus;

		private Label lbUnitWmin;

		private Label lbUnitLmin;

		private Label lbUnitMmin;

		private Label lbUnitMFmin;

		private NumberEdit1 nEASmin;

		private NumberEdit1 nELmin;

		private NumberEdit1 nEMFmin;

		private NumberEdit1 nEMmin;

		private NumberEdit1 nEWmin;

		private Label lbWmin;

		private Label lbLmin;

		private Label lbMmin;

		private Label lbMFmin;

		private Label lbASmin;

		private Label lbUnitTreshM;

		private NumberEdit1 nETreshM;

		private Label lbUnitMGmin;

		private NumberEdit1 nEMGmin;

		private Label lbMGmin;

		private Label lbUnitMGplus;

		private NumberEdit1 nEMGplus;

		private Label lbMGplus;

		private Button bt5;

		private Button bt4;

		private Button bt3;

		private CheckBox chBTime;

		private Label lbUnitTmin;

		private NumberEdit1 nETmin;

		private Label lbTmin;

		private NumberEdit1 nECountPassMax;

		private ComboBox cBDigSigAtEnd;

		private ComboBox cBDigSigRunning;

		private ComboBox cBDigSigRunType;

		private ComboBox cBDigSigEndType;

		private CheckBox chBDigSignalDuringStep;

		private CheckBox chBDigSignalAtEnd;

		private CheckBox chBTreshM;

		private ComboBox cBMGmin;

		private ComboBox cBMGmax;

		private CheckBox chBMGmin;

		private CheckBox chBMGmax;

		private CheckBox chBADepthGradMax;

		private ComboBox cBLGmax;

		private ComboBox cBLGmin;

		private Label lbUnitLGmax;

		private NumberEdit1 nELGmin;

		private Label lbLGmin;

		private Label lbUnitLGmin;

		private NumberEdit1 nELGmax;

		private Label lbLGmax;

		private CheckBox chBADepthGradMin;

		private Button btCancel;

		private Label lbCountPassMax;

		private bool bCanceled;

		private bool bInitialize;

		private bool showWindow;

		public bool WasCanceled
		{
			get
			{
				bool result = this.bCanceled;
				this.bCanceled = false;
				return result;
			}
		}

		public CheckParamForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btCancel = new Button();
			this.bt5 = new Button();
			this.bt4 = new Button();
			this.bt3 = new Button();
			this.bt2 = new Button();
			this.bt1 = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.pnCheckPar = new Panel();
			this.chBADepthGradMax = new CheckBox();
			this.cBLGmax = new ComboBox();
			this.cBLGmin = new ComboBox();
			this.lbUnitLGmax = new Label();
			this.nELGmin = new NumberEdit1();
			this.lbLGmin = new Label();
			this.lbUnitLGmin = new Label();
			this.nELGmax = new NumberEdit1();
			this.lbLGmax = new Label();
			this.chBADepthGradMin = new CheckBox();
			this.chBMGmax = new CheckBox();
			this.cBMGmax = new ComboBox();
			this.cBMGmin = new ComboBox();
			this.chBTreshM = new CheckBox();
			this.chBDigSignalAtEnd = new CheckBox();
			this.cBDigSigEndType = new ComboBox();
			this.cBDigSigRunType = new ComboBox();
			this.nECountPassMax = new NumberEdit1();
			this.lbCountPassMax = new Label();
			this.lbUnitTmin = new Label();
			this.nETmin = new NumberEdit1();
			this.lbTmin = new Label();
			this.chBTime = new CheckBox();
			this.lbUnitMGmin = new Label();
			this.nEMGmin = new NumberEdit1();
			this.lbMGmin = new Label();
			this.lbUnitMGplus = new Label();
			this.nEMGplus = new NumberEdit1();
			this.lbMGplus = new Label();
			this.chBMGmin = new CheckBox();
			this.cBDigSigAtEnd = new ComboBox();
			this.lbUnitTreshM = new Label();
			this.nETreshM = new NumberEdit1();
			this.lbUnitWmin = new Label();
			this.lbUnitLmin = new Label();
			this.lbUnitMmin = new Label();
			this.lbUnitMFmin = new Label();
			this.nEASmin = new NumberEdit1();
			this.nELmin = new NumberEdit1();
			this.nEMFmin = new NumberEdit1();
			this.nEMmin = new NumberEdit1();
			this.nEWmin = new NumberEdit1();
			this.lbWmin = new Label();
			this.lbLmin = new Label();
			this.lbMmin = new Label();
			this.lbMFmin = new Label();
			this.lbASmin = new Label();
			this.lbUnitWplus = new Label();
			this.lbUnitLplus = new Label();
			this.lbUnitMplus = new Label();
			this.lbUnitMFplus = new Label();
			this.nEASplus = new NumberEdit1();
			this.nELplus = new NumberEdit1();
			this.nEMFplus = new NumberEdit1();
			this.nEMplus = new NumberEdit1();
			this.nEWplus = new NumberEdit1();
			this.lbWplus = new Label();
			this.lbLplus = new Label();
			this.lbMplus = new Label();
			this.lbMFplus = new Label();
			this.lbASplus = new Label();
			this.chBDigSignalDuringStep = new CheckBox();
			this.chBTorque = new CheckBox();
			this.chBAngle = new CheckBox();
			this.chBFiltTorque = new CheckBox();
			this.chBAnaDepth = new CheckBox();
			this.chBExtAnaSignal = new CheckBox();
			this.cBDigSigRunning = new ComboBox();
			this.pnMenu.SuspendLayout();
			this.pnCheckPar.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.bt5);
			this.pnMenu.Controls.Add(this.bt4);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.bt1);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btCancel.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 8;
			this.btCancel.Text = "Abbruch";
			this.btCancel.Click += this.btCancel_Click;
			this.bt5.Enabled = false;
			this.bt5.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt5.Location = new Point(3, 387);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(74, 62);
			this.bt5.TabIndex = 6;
			this.bt4.Enabled = false;
			this.bt4.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt4.Location = new Point(3, 323);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(74, 62);
			this.bt4.TabIndex = 5;
			this.bt3.Enabled = false;
			this.bt3.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt3.Location = new Point(3, 259);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 4;
			this.bt2.Enabled = false;
			this.bt2.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt2.Location = new Point(3, 195);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 3;
			this.bt1.Enabled = false;
			this.bt1.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt1.Location = new Point(3, 131);
			this.bt1.Name = "bt1";
			this.bt1.Size = new Size(74, 62);
			this.bt1.TabIndex = 2;
			this.btHelp.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btHelp.Enter += this.Start_Input;
			this.btBack.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Fertig";
			this.btBack.Click += this.btBack_Click;
			this.btBack.Enter += this.Start_Input;
			this.pnCheckPar.Controls.Add(this.chBADepthGradMax);
			this.pnCheckPar.Controls.Add(this.cBLGmax);
			this.pnCheckPar.Controls.Add(this.cBLGmin);
			this.pnCheckPar.Controls.Add(this.lbUnitLGmax);
			this.pnCheckPar.Controls.Add(this.nELGmin);
			this.pnCheckPar.Controls.Add(this.lbLGmin);
			this.pnCheckPar.Controls.Add(this.lbUnitLGmin);
			this.pnCheckPar.Controls.Add(this.nELGmax);
			this.pnCheckPar.Controls.Add(this.lbLGmax);
			this.pnCheckPar.Controls.Add(this.chBADepthGradMin);
			this.pnCheckPar.Controls.Add(this.chBMGmax);
			this.pnCheckPar.Controls.Add(this.cBMGmax);
			this.pnCheckPar.Controls.Add(this.cBMGmin);
			this.pnCheckPar.Controls.Add(this.chBTreshM);
			this.pnCheckPar.Controls.Add(this.chBDigSignalAtEnd);
			this.pnCheckPar.Controls.Add(this.cBDigSigEndType);
			this.pnCheckPar.Controls.Add(this.cBDigSigRunType);
			this.pnCheckPar.Controls.Add(this.nECountPassMax);
			this.pnCheckPar.Controls.Add(this.lbCountPassMax);
			this.pnCheckPar.Controls.Add(this.lbUnitTmin);
			this.pnCheckPar.Controls.Add(this.nETmin);
			this.pnCheckPar.Controls.Add(this.lbTmin);
			this.pnCheckPar.Controls.Add(this.chBTime);
			this.pnCheckPar.Controls.Add(this.lbUnitMGmin);
			this.pnCheckPar.Controls.Add(this.nEMGmin);
			this.pnCheckPar.Controls.Add(this.lbMGmin);
			this.pnCheckPar.Controls.Add(this.lbUnitMGplus);
			this.pnCheckPar.Controls.Add(this.nEMGplus);
			this.pnCheckPar.Controls.Add(this.lbMGplus);
			this.pnCheckPar.Controls.Add(this.chBMGmin);
			this.pnCheckPar.Controls.Add(this.cBDigSigAtEnd);
			this.pnCheckPar.Controls.Add(this.lbUnitTreshM);
			this.pnCheckPar.Controls.Add(this.nETreshM);
			this.pnCheckPar.Controls.Add(this.lbUnitWmin);
			this.pnCheckPar.Controls.Add(this.lbUnitLmin);
			this.pnCheckPar.Controls.Add(this.lbUnitMmin);
			this.pnCheckPar.Controls.Add(this.lbUnitMFmin);
			this.pnCheckPar.Controls.Add(this.nEASmin);
			this.pnCheckPar.Controls.Add(this.nELmin);
			this.pnCheckPar.Controls.Add(this.nEMFmin);
			this.pnCheckPar.Controls.Add(this.nEMmin);
			this.pnCheckPar.Controls.Add(this.nEWmin);
			this.pnCheckPar.Controls.Add(this.lbWmin);
			this.pnCheckPar.Controls.Add(this.lbLmin);
			this.pnCheckPar.Controls.Add(this.lbMmin);
			this.pnCheckPar.Controls.Add(this.lbMFmin);
			this.pnCheckPar.Controls.Add(this.lbASmin);
			this.pnCheckPar.Controls.Add(this.lbUnitWplus);
			this.pnCheckPar.Controls.Add(this.lbUnitLplus);
			this.pnCheckPar.Controls.Add(this.lbUnitMplus);
			this.pnCheckPar.Controls.Add(this.lbUnitMFplus);
			this.pnCheckPar.Controls.Add(this.nEASplus);
			this.pnCheckPar.Controls.Add(this.nELplus);
			this.pnCheckPar.Controls.Add(this.nEMFplus);
			this.pnCheckPar.Controls.Add(this.nEMplus);
			this.pnCheckPar.Controls.Add(this.nEWplus);
			this.pnCheckPar.Controls.Add(this.lbWplus);
			this.pnCheckPar.Controls.Add(this.lbLplus);
			this.pnCheckPar.Controls.Add(this.lbMplus);
			this.pnCheckPar.Controls.Add(this.lbMFplus);
			this.pnCheckPar.Controls.Add(this.lbASplus);
			this.pnCheckPar.Controls.Add(this.chBDigSignalDuringStep);
			this.pnCheckPar.Controls.Add(this.chBTorque);
			this.pnCheckPar.Controls.Add(this.chBAngle);
			this.pnCheckPar.Controls.Add(this.chBFiltTorque);
			this.pnCheckPar.Controls.Add(this.chBAnaDepth);
			this.pnCheckPar.Controls.Add(this.chBExtAnaSignal);
			this.pnCheckPar.Controls.Add(this.cBDigSigRunning);
			this.pnCheckPar.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnCheckPar.Location = new Point(0, 0);
			this.pnCheckPar.Name = "pnCheckPar";
			this.pnCheckPar.Size = new Size(709, 522);
			this.pnCheckPar.TabIndex = 1;
			this.chBADepthGradMax.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBADepthGradMax.Location = new Point(16, 328);
			this.chBADepthGradMax.Name = "chBADepthGradMax";
			this.chBADepthGradMax.Size = new Size(176, 24);
			this.chBADepthGradMax.TabIndex = 25;
			this.chBADepthGradMax.Text = "Tiefengradient";
			this.chBADepthGradMax.CheckedChanged += this.chBTMx_CheckedChanged;
			this.cBLGmax.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBLGmax.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBLGmax.Items.AddRange(new object[2]
			{
				"An",
				"Aus"
			});
			this.cBLGmax.Location = new Point(456, 326);
			this.cBLGmax.MaxDropDownItems = 2;
			this.cBLGmax.Name = "cBLGmax";
			this.cBLGmax.Size = new Size(192, 28);
			this.cBLGmax.TabIndex = 27;
			this.cBLGmax.SelectedIndexChanged += this.settingsChanged;
			this.cBLGmin.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBLGmin.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBLGmin.Items.AddRange(new object[2]
			{
				"An",
				"Aus"
			});
			this.cBLGmin.Location = new Point(456, 294);
			this.cBLGmin.MaxDropDownItems = 2;
			this.cBLGmin.Name = "cBLGmin";
			this.cBLGmin.Size = new Size(192, 28);
			this.cBLGmin.TabIndex = 24;
			this.cBLGmin.SelectedIndexChanged += this.settingsChanged;
			this.lbUnitLGmax.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitLGmax.Location = new Point(376, 329);
			this.lbUnitLGmax.Name = "lbUnitLGmax";
			this.lbUnitLGmax.RightToLeft = RightToLeft.No;
			this.lbUnitLGmax.Size = new Size(72, 23);
			this.lbUnitLGmax.TabIndex = 117;
			this.lbUnitLGmax.Text = "mm/s";
			this.lbUnitLGmax.TextAlign = ContentAlignment.MiddleLeft;
			this.nELGmin.BackColor = Color.White;
			this.nELGmin.DecimalNum = 2;
			this.nELGmin.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nELGmin.ForeColor = SystemColors.ControlText;
			this.nELGmin.Location = new Point(288, 294);
			this.nELGmin.MaxValue = 100f;
			this.nELGmin.MinValue = -100f;
			this.nELGmin.Name = "nELGmin";
			this.nELGmin.Size = new Size(80, 28);
			this.nELGmin.TabIndex = 23;
			this.nELGmin.Text = "0,00";
			this.nELGmin.TextAlign = HorizontalAlignment.Right;
			this.nELGmin.Value = 0f;
			this.nELGmin.TextChanged += this.textChanged;
			this.nELGmin.Enter += this.Start_Input;
			this.nELGmin.MouseDown += this.StartInput;
			this.lbLGmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbLGmin.Location = new Point(200, 297);
			this.lbLGmin.Name = "lbLGmin";
			this.lbLGmin.RightToLeft = RightToLeft.No;
			this.lbLGmin.Size = new Size(80, 23);
			this.lbLGmin.TabIndex = 116;
			this.lbLGmin.Text = "min(LG-)";
			this.lbLGmin.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitLGmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitLGmin.Location = new Point(376, 297);
			this.lbUnitLGmin.Name = "lbUnitLGmin";
			this.lbUnitLGmin.RightToLeft = RightToLeft.No;
			this.lbUnitLGmin.Size = new Size(72, 23);
			this.lbUnitLGmin.TabIndex = 115;
			this.lbUnitLGmin.Text = "mm/s";
			this.lbUnitLGmin.TextAlign = ContentAlignment.MiddleLeft;
			this.nELGmax.BackColor = Color.White;
			this.nELGmax.DecimalNum = 2;
			this.nELGmax.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nELGmax.ForeColor = SystemColors.ControlText;
			this.nELGmax.Location = new Point(288, 326);
			this.nELGmax.MaxValue = 100f;
			this.nELGmax.MinValue = -100f;
			this.nELGmax.Name = "nELGmax";
			this.nELGmax.Size = new Size(80, 28);
			this.nELGmax.TabIndex = 26;
			this.nELGmax.Text = "0,00";
			this.nELGmax.TextAlign = HorizontalAlignment.Right;
			this.nELGmax.Value = 0f;
			this.nELGmax.TextChanged += this.textChanged;
			this.nELGmax.Enter += this.Start_Input;
			this.nELGmax.MouseDown += this.StartInput;
			this.lbLGmax.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbLGmax.Location = new Point(200, 329);
			this.lbLGmax.Name = "lbLGmax";
			this.lbLGmax.RightToLeft = RightToLeft.No;
			this.lbLGmax.Size = new Size(80, 23);
			this.lbLGmax.TabIndex = 114;
			this.lbLGmax.Text = "max(LG+)";
			this.lbLGmax.TextAlign = ContentAlignment.MiddleLeft;
			this.chBADepthGradMin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBADepthGradMin.Location = new Point(16, 296);
			this.chBADepthGradMin.Name = "chBADepthGradMin";
			this.chBADepthGradMin.Size = new Size(176, 24);
			this.chBADepthGradMin.TabIndex = 22;
			this.chBADepthGradMin.Text = "Tiefengradient";
			this.chBADepthGradMin.CheckedChanged += this.chBTMx_CheckedChanged;
			this.chBMGmax.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBMGmax.Location = new Point(16, 224);
			this.chBMGmax.Name = "chBMGmax";
			this.chBMGmax.Size = new Size(176, 24);
			this.chBMGmax.TabIndex = 16;
			this.chBMGmax.Text = "Gradient";
			this.chBMGmax.CheckedChanged += this.chBTMx_CheckedChanged;
			this.cBMGmax.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBMGmax.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBMGmax.Items.AddRange(new object[2]
			{
				"An",
				"Aus"
			});
			this.cBMGmax.Location = new Point(456, 222);
			this.cBMGmax.MaxDropDownItems = 2;
			this.cBMGmax.Name = "cBMGmax";
			this.cBMGmax.Size = new Size(192, 28);
			this.cBMGmax.TabIndex = 18;
			this.cBMGmax.SelectedIndexChanged += this.settingsChanged;
			this.cBMGmin.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBMGmin.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBMGmin.Items.AddRange(new object[2]
			{
				"An",
				"Aus"
			});
			this.cBMGmin.Location = new Point(456, 190);
			this.cBMGmin.MaxDropDownItems = 2;
			this.cBMGmin.Name = "cBMGmin";
			this.cBMGmin.Size = new Size(192, 28);
			this.cBMGmin.TabIndex = 15;
			this.cBMGmin.SelectedIndexChanged += this.settingsChanged;
			this.chBTreshM.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBTreshM.Location = new Point(344, 88);
			this.chBTreshM.Name = "chBTreshM";
			this.chBTreshM.Size = new Size(160, 24);
			this.chBTreshM.TabIndex = 5;
			this.chBTreshM.Text = "Schwellmoment";
			this.chBTreshM.CheckedChanged += this.chBTMx_CheckedChanged;
			this.chBTreshM.Enter += this.Start_Input;
			this.chBDigSignalAtEnd.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBDigSignalAtEnd.Location = new Point(16, 440);
			this.chBDigSignalAtEnd.Name = "chBDigSignalAtEnd";
			this.chBDigSignalAtEnd.Size = new Size(328, 24);
			this.chBDigSignalAtEnd.TabIndex = 34;
			this.chBDigSignalAtEnd.Text = "Digit. Signal (am Ende überwacht)";
			this.chBDigSignalAtEnd.CheckedChanged += this.chBTMx_CheckedChanged;
			this.chBDigSignalAtEnd.Enter += this.Start_Input;
			this.cBDigSigEndType.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBDigSigEndType.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBDigSigEndType.Items.AddRange(new object[2]
			{
				"An",
				"Aus"
			});
			this.cBDigSigEndType.Location = new Point(544, 438);
			this.cBDigSigEndType.MaxDropDownItems = 2;
			this.cBDigSigEndType.Name = "cBDigSigEndType";
			this.cBDigSigEndType.Size = new Size(128, 28);
			this.cBDigSigEndType.TabIndex = 36;
			this.cBDigSigEndType.SelectedIndexChanged += this.settingsChanged;
			this.cBDigSigRunType.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBDigSigRunType.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBDigSigRunType.Items.AddRange(new object[2]
			{
				"An",
				"Aus"
			});
			this.cBDigSigRunType.Location = new Point(544, 406);
			this.cBDigSigRunType.MaxDropDownItems = 2;
			this.cBDigSigRunType.Name = "cBDigSigRunType";
			this.cBDigSigRunType.Size = new Size(128, 28);
			this.cBDigSigRunType.TabIndex = 33;
			this.cBDigSigRunType.SelectedIndexChanged += this.settingsChanged;
			this.nECountPassMax.BackColor = Color.White;
			this.nECountPassMax.DecimalNum = 0;
			this.nECountPassMax.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nECountPassMax.ForeColor = SystemColors.ControlText;
			this.nECountPassMax.Location = new Point(264, 477);
			this.nECountPassMax.MaxValue = 10f;
			this.nECountPassMax.MinValue = 0f;
			this.nECountPassMax.Name = "nECountPassMax";
			this.nECountPassMax.Size = new Size(64, 28);
			this.nECountPassMax.TabIndex = 38;
			this.nECountPassMax.Text = "0";
			this.nECountPassMax.TextAlign = HorizontalAlignment.Right;
			this.nECountPassMax.Value = 0f;
			this.nECountPassMax.TextChanged += this.textChanged;
			this.nECountPassMax.Enter += this.Start_Input;
			this.nECountPassMax.MouseDown += this.StartInput;
			this.lbCountPassMax.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbCountPassMax.Location = new Point(16, 480);
			this.lbCountPassMax.Name = "lbCountPassMax";
			this.lbCountPassMax.RightToLeft = RightToLeft.No;
			this.lbCountPassMax.Size = new Size(240, 23);
			this.lbCountPassMax.TabIndex = 37;
			this.lbCountPassMax.Text = "Max. Stufenwiederholungen";
			this.lbCountPassMax.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitTmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitTmin.Location = new Point(376, 17);
			this.lbUnitTmin.Name = "lbUnitTmin";
			this.lbUnitTmin.RightToLeft = RightToLeft.No;
			this.lbUnitTmin.Size = new Size(72, 23);
			this.lbUnitTmin.TabIndex = 104;
			this.lbUnitTmin.Text = "s";
			this.lbUnitTmin.TextAlign = ContentAlignment.MiddleLeft;
			this.nETmin.BackColor = Color.White;
			this.nETmin.DecimalNum = 1;
			this.nETmin.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETmin.ForeColor = SystemColors.ControlText;
			this.nETmin.Location = new Point(288, 14);
			this.nETmin.MaxValue = 10f;
			this.nETmin.MinValue = 0f;
			this.nETmin.Name = "nETmin";
			this.nETmin.Size = new Size(80, 28);
			this.nETmin.TabIndex = 1;
			this.nETmin.Text = "0,0";
			this.nETmin.TextAlign = HorizontalAlignment.Right;
			this.nETmin.Value = 0f;
			this.nETmin.TextChanged += this.textChanged;
			this.nETmin.Enter += this.Start_Input;
			this.nETmin.MouseDown += this.StartInput;
			this.lbTmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTmin.Location = new Point(200, 17);
			this.lbTmin.Name = "lbTmin";
			this.lbTmin.RightToLeft = RightToLeft.No;
			this.lbTmin.Size = new Size(80, 23);
			this.lbTmin.TabIndex = 103;
			this.lbTmin.Text = "T-";
			this.lbTmin.TextAlign = ContentAlignment.MiddleLeft;
			this.chBTime.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBTime.Location = new Point(16, 16);
			this.chBTime.Name = "chBTime";
			this.chBTime.Size = new Size(176, 24);
			this.chBTime.TabIndex = 0;
			this.chBTime.Text = "Zeitunterschreitung";
			this.chBTime.CheckedChanged += this.chBTMx_CheckedChanged;
			this.chBTime.Enter += this.Start_Input;
			this.lbUnitMGmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitMGmin.Location = new Point(376, 225);
			this.lbUnitMGmin.Name = "lbUnitMGmin";
			this.lbUnitMGmin.RightToLeft = RightToLeft.No;
			this.lbUnitMGmin.Size = new Size(72, 23);
			this.lbUnitMGmin.TabIndex = 100;
			this.lbUnitMGmin.Text = "Nm/°";
			this.lbUnitMGmin.TextAlign = ContentAlignment.MiddleLeft;
			this.nEMGmin.BackColor = Color.White;
			this.nEMGmin.DecimalNum = 2;
			this.nEMGmin.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMGmin.ForeColor = SystemColors.ControlText;
			this.nEMGmin.Location = new Point(288, 190);
			this.nEMGmin.MaxValue = 100f;
			this.nEMGmin.MinValue = -100f;
			this.nEMGmin.Name = "nEMGmin";
			this.nEMGmin.Size = new Size(80, 28);
			this.nEMGmin.TabIndex = 14;
			this.nEMGmin.Text = "0,00";
			this.nEMGmin.TextAlign = HorizontalAlignment.Right;
			this.nEMGmin.Value = 0f;
			this.nEMGmin.TextChanged += this.textChanged;
			this.nEMGmin.Enter += this.Start_Input;
			this.nEMGmin.MouseDown += this.StartInput;
			this.lbMGmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMGmin.Location = new Point(200, 193);
			this.lbMGmin.Name = "lbMGmin";
			this.lbMGmin.RightToLeft = RightToLeft.No;
			this.lbMGmin.Size = new Size(80, 23);
			this.lbMGmin.TabIndex = 99;
			this.lbMGmin.Text = "min(MG-)";
			this.lbMGmin.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitMGplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitMGplus.Location = new Point(376, 193);
			this.lbUnitMGplus.Name = "lbUnitMGplus";
			this.lbUnitMGplus.RightToLeft = RightToLeft.No;
			this.lbUnitMGplus.Size = new Size(72, 23);
			this.lbUnitMGplus.TabIndex = 98;
			this.lbUnitMGplus.Text = "Nm/°";
			this.lbUnitMGplus.TextAlign = ContentAlignment.MiddleLeft;
			this.nEMGplus.BackColor = Color.White;
			this.nEMGplus.DecimalNum = 2;
			this.nEMGplus.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMGplus.ForeColor = SystemColors.ControlText;
			this.nEMGplus.Location = new Point(288, 222);
			this.nEMGplus.MaxValue = 100f;
			this.nEMGplus.MinValue = -100f;
			this.nEMGplus.Name = "nEMGplus";
			this.nEMGplus.Size = new Size(80, 28);
			this.nEMGplus.TabIndex = 17;
			this.nEMGplus.Text = "0,00";
			this.nEMGplus.TextAlign = HorizontalAlignment.Right;
			this.nEMGplus.Value = 0f;
			this.nEMGplus.TextChanged += this.textChanged;
			this.nEMGplus.Enter += this.Start_Input;
			this.nEMGplus.MouseDown += this.StartInput;
			this.lbMGplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMGplus.Location = new Point(200, 225);
			this.lbMGplus.Name = "lbMGplus";
			this.lbMGplus.RightToLeft = RightToLeft.No;
			this.lbMGplus.Size = new Size(80, 23);
			this.lbMGplus.TabIndex = 97;
			this.lbMGplus.Text = "max(MG+)";
			this.lbMGplus.TextAlign = ContentAlignment.MiddleLeft;
			this.chBMGmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBMGmin.Location = new Point(16, 192);
			this.chBMGmin.Name = "chBMGmin";
			this.chBMGmin.Size = new Size(176, 24);
			this.chBMGmin.TabIndex = 13;
			this.chBMGmin.Text = "Gradient";
			this.chBMGmin.CheckedChanged += this.chBTMx_CheckedChanged;
			this.chBMGmin.Enter += this.Start_Input;
			this.cBDigSigAtEnd.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBDigSigAtEnd.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBDigSigAtEnd.Items.AddRange(new object[2]
			{
				"An",
				"Aus"
			});
			this.cBDigSigAtEnd.Location = new Point(352, 438);
			this.cBDigSigAtEnd.MaxDropDownItems = 5;
			this.cBDigSigAtEnd.Name = "cBDigSigAtEnd";
			this.cBDigSigAtEnd.Size = new Size(136, 28);
			this.cBDigSigAtEnd.TabIndex = 35;
			this.cBDigSigAtEnd.SelectedIndexChanged += this.settingsChanged;
			this.lbUnitTreshM.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitTreshM.Location = new Point(632, 89);
			this.lbUnitTreshM.Name = "lbUnitTreshM";
			this.lbUnitTreshM.RightToLeft = RightToLeft.No;
			this.lbUnitTreshM.Size = new Size(72, 23);
			this.lbUnitTreshM.TabIndex = 84;
			this.lbUnitTreshM.Text = "Nm";
			this.lbUnitTreshM.TextAlign = ContentAlignment.MiddleLeft;
			this.nETreshM.BackColor = Color.White;
			this.nETreshM.DecimalNum = 2;
			this.nETreshM.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETreshM.ForeColor = SystemColors.ControlText;
			this.nETreshM.Location = new Point(544, 86);
			this.nETreshM.MaxValue = 50000f;
			this.nETreshM.MinValue = -50000f;
			this.nETreshM.Name = "nETreshM";
			this.nETreshM.Size = new Size(80, 28);
			this.nETreshM.TabIndex = 6;
			this.nETreshM.Text = "0,00";
			this.nETreshM.TextAlign = HorizontalAlignment.Right;
			this.nETreshM.Value = 0f;
			this.nETreshM.TextChanged += this.textChanged;
			this.nETreshM.Enter += this.Start_Input;
			this.nETreshM.MouseDown += this.StartInput;
			this.lbUnitWmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitWmin.Location = new Point(632, 57);
			this.lbUnitWmin.Name = "lbUnitWmin";
			this.lbUnitWmin.RightToLeft = RightToLeft.No;
			this.lbUnitWmin.Size = new Size(72, 23);
			this.lbUnitWmin.TabIndex = 76;
			this.lbUnitWmin.Text = "°";
			this.lbUnitWmin.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitLmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitLmin.Location = new Point(632, 265);
			this.lbUnitLmin.Name = "lbUnitLmin";
			this.lbUnitLmin.RightToLeft = RightToLeft.No;
			this.lbUnitLmin.Size = new Size(72, 23);
			this.lbUnitLmin.TabIndex = 80;
			this.lbUnitLmin.Text = "mm";
			this.lbUnitLmin.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitMmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitMmin.Location = new Point(632, 129);
			this.lbUnitMmin.Name = "lbUnitMmin";
			this.lbUnitMmin.RightToLeft = RightToLeft.No;
			this.lbUnitMmin.Size = new Size(72, 23);
			this.lbUnitMmin.TabIndex = 77;
			this.lbUnitMmin.Text = "Nm";
			this.lbUnitMmin.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitMFmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitMFmin.Location = new Point(632, 161);
			this.lbUnitMFmin.Name = "lbUnitMFmin";
			this.lbUnitMFmin.RightToLeft = RightToLeft.No;
			this.lbUnitMFmin.Size = new Size(72, 23);
			this.lbUnitMFmin.TabIndex = 78;
			this.lbUnitMFmin.Text = "Nm";
			this.lbUnitMFmin.TextAlign = ContentAlignment.MiddleLeft;
			this.nEASmin.BackColor = Color.White;
			this.nEASmin.DecimalNum = 2;
			this.nEASmin.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEASmin.ForeColor = SystemColors.ControlText;
			this.nEASmin.Location = new Point(288, 366);
			this.nEASmin.MaxValue = 10f;
			this.nEASmin.MinValue = -10f;
			this.nEASmin.Name = "nEASmin";
			this.nEASmin.Size = new Size(80, 28);
			this.nEASmin.TabIndex = 29;
			this.nEASmin.Text = "0,00";
			this.nEASmin.TextAlign = HorizontalAlignment.Right;
			this.nEASmin.Value = 0f;
			this.nEASmin.TextChanged += this.textChanged;
			this.nEASmin.Enter += this.Start_Input;
			this.nEASmin.MouseDown += this.StartInput;
			this.nELmin.BackColor = Color.White;
			this.nELmin.DecimalNum = 1;
			this.nELmin.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nELmin.ForeColor = SystemColors.ControlText;
			this.nELmin.Location = new Point(288, 262);
			this.nELmin.MaxValue = 999f;
			this.nELmin.MinValue = -999f;
			this.nELmin.Name = "nELmin";
			this.nELmin.Size = new Size(80, 28);
			this.nELmin.TabIndex = 20;
			this.nELmin.Text = "0,0";
			this.nELmin.TextAlign = HorizontalAlignment.Right;
			this.nELmin.Value = 0f;
			this.nELmin.TextChanged += this.textChanged;
			this.nELmin.Enter += this.Start_Input;
			this.nELmin.MouseDown += this.StartInput;
			this.nEMFmin.BackColor = Color.White;
			this.nEMFmin.DecimalNum = 2;
			this.nEMFmin.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMFmin.ForeColor = SystemColors.ControlText;
			this.nEMFmin.Location = new Point(288, 158);
			this.nEMFmin.MaxValue = 50000f;
			this.nEMFmin.MinValue = -50000f;
			this.nEMFmin.Name = "nEMFmin";
			this.nEMFmin.Size = new Size(80, 28);
			this.nEMFmin.TabIndex = 11;
			this.nEMFmin.Text = "0,00";
			this.nEMFmin.TextAlign = HorizontalAlignment.Right;
			this.nEMFmin.Value = 0f;
			this.nEMFmin.TextChanged += this.textChanged;
			this.nEMFmin.Enter += this.Start_Input;
			this.nEMFmin.MouseDown += this.StartInput;
			this.nEMmin.BackColor = Color.White;
			this.nEMmin.DecimalNum = 2;
			this.nEMmin.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMmin.ForeColor = SystemColors.ControlText;
			this.nEMmin.Location = new Point(288, 126);
			this.nEMmin.MaxValue = 50000f;
			this.nEMmin.MinValue = -50000f;
			this.nEMmin.Name = "nEMmin";
			this.nEMmin.Size = new Size(80, 28);
			this.nEMmin.TabIndex = 8;
			this.nEMmin.Text = "0,00";
			this.nEMmin.TextAlign = HorizontalAlignment.Right;
			this.nEMmin.Value = 0f;
			this.nEMmin.TextChanged += this.textChanged;
			this.nEMmin.Enter += this.Start_Input;
			this.nEMmin.MouseDown += this.StartInput;
			this.nEWmin.BackColor = Color.White;
			this.nEWmin.DecimalNum = 1;
			this.nEWmin.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEWmin.ForeColor = SystemColors.ControlText;
			this.nEWmin.Location = new Point(288, 54);
			this.nEWmin.MaxValue = 30000f;
			this.nEWmin.MinValue = -30000f;
			this.nEWmin.Name = "nEWmin";
			this.nEWmin.Size = new Size(80, 28);
			this.nEWmin.TabIndex = 3;
			this.nEWmin.Text = "0,0";
			this.nEWmin.TextAlign = HorizontalAlignment.Right;
			this.nEWmin.Value = 0f;
			this.nEWmin.TextChanged += this.textChanged;
			this.nEWmin.Enter += this.Start_Input;
			this.nEWmin.MouseDown += this.StartInput;
			this.lbWmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbWmin.ForeColor = SystemColors.ControlText;
			this.lbWmin.Location = new Point(200, 57);
			this.lbWmin.Name = "lbWmin";
			this.lbWmin.RightToLeft = RightToLeft.No;
			this.lbWmin.Size = new Size(80, 23);
			this.lbWmin.TabIndex = 68;
			this.lbWmin.Text = "W-";
			this.lbWmin.TextAlign = ContentAlignment.MiddleLeft;
			this.lbLmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbLmin.ForeColor = SystemColors.ControlText;
			this.lbLmin.Location = new Point(200, 265);
			this.lbLmin.Name = "lbLmin";
			this.lbLmin.RightToLeft = RightToLeft.No;
			this.lbLmin.Size = new Size(80, 23);
			this.lbLmin.TabIndex = 73;
			this.lbLmin.Text = "L-";
			this.lbLmin.TextAlign = ContentAlignment.MiddleLeft;
			this.lbMmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMmin.ForeColor = SystemColors.ControlText;
			this.lbMmin.Location = new Point(200, 129);
			this.lbMmin.Name = "lbMmin";
			this.lbMmin.RightToLeft = RightToLeft.No;
			this.lbMmin.Size = new Size(80, 23);
			this.lbMmin.TabIndex = 69;
			this.lbMmin.Text = "M-";
			this.lbMmin.TextAlign = ContentAlignment.MiddleLeft;
			this.lbMFmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMFmin.Location = new Point(200, 161);
			this.lbMFmin.Name = "lbMFmin";
			this.lbMFmin.RightToLeft = RightToLeft.No;
			this.lbMFmin.Size = new Size(80, 23);
			this.lbMFmin.TabIndex = 71;
			this.lbMFmin.Text = "min(MF-)";
			this.lbMFmin.TextAlign = ContentAlignment.MiddleLeft;
			this.lbASmin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbASmin.Location = new Point(200, 369);
			this.lbASmin.Name = "lbASmin";
			this.lbASmin.RightToLeft = RightToLeft.No;
			this.lbASmin.Size = new Size(80, 23);
			this.lbASmin.TabIndex = 74;
			this.lbASmin.Text = "AS-";
			this.lbASmin.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitWplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitWplus.Location = new Point(376, 57);
			this.lbUnitWplus.Name = "lbUnitWplus";
			this.lbUnitWplus.RightToLeft = RightToLeft.No;
			this.lbUnitWplus.Size = new Size(72, 23);
			this.lbUnitWplus.TabIndex = 55;
			this.lbUnitWplus.Text = "°";
			this.lbUnitWplus.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitLplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitLplus.Location = new Point(376, 265);
			this.lbUnitLplus.Name = "lbUnitLplus";
			this.lbUnitLplus.RightToLeft = RightToLeft.No;
			this.lbUnitLplus.Size = new Size(72, 23);
			this.lbUnitLplus.TabIndex = 59;
			this.lbUnitLplus.Text = "mm";
			this.lbUnitLplus.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitMplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitMplus.Location = new Point(376, 129);
			this.lbUnitMplus.Name = "lbUnitMplus";
			this.lbUnitMplus.RightToLeft = RightToLeft.No;
			this.lbUnitMplus.Size = new Size(72, 23);
			this.lbUnitMplus.TabIndex = 56;
			this.lbUnitMplus.Text = "Nm";
			this.lbUnitMplus.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitMFplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitMFplus.Location = new Point(376, 161);
			this.lbUnitMFplus.Name = "lbUnitMFplus";
			this.lbUnitMFplus.RightToLeft = RightToLeft.No;
			this.lbUnitMFplus.Size = new Size(72, 23);
			this.lbUnitMFplus.TabIndex = 57;
			this.lbUnitMFplus.Text = "Nm";
			this.lbUnitMFplus.TextAlign = ContentAlignment.MiddleLeft;
			this.nEASplus.BackColor = Color.White;
			this.nEASplus.DecimalNum = 2;
			this.nEASplus.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEASplus.ForeColor = SystemColors.ControlText;
			this.nEASplus.Location = new Point(544, 366);
			this.nEASplus.MaxValue = 10f;
			this.nEASplus.MinValue = -10f;
			this.nEASplus.Name = "nEASplus";
			this.nEASplus.Size = new Size(80, 28);
			this.nEASplus.TabIndex = 30;
			this.nEASplus.Text = "0,00";
			this.nEASplus.TextAlign = HorizontalAlignment.Right;
			this.nEASplus.Value = 0f;
			this.nEASplus.TextChanged += this.textChanged;
			this.nEASplus.Enter += this.Start_Input;
			this.nEASplus.MouseDown += this.StartInput;
			this.nELplus.BackColor = Color.White;
			this.nELplus.DecimalNum = 1;
			this.nELplus.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nELplus.ForeColor = SystemColors.ControlText;
			this.nELplus.Location = new Point(544, 262);
			this.nELplus.MaxValue = 999f;
			this.nELplus.MinValue = -999f;
			this.nELplus.Name = "nELplus";
			this.nELplus.Size = new Size(80, 28);
			this.nELplus.TabIndex = 21;
			this.nELplus.Text = "0,0";
			this.nELplus.TextAlign = HorizontalAlignment.Right;
			this.nELplus.Value = 0f;
			this.nELplus.TextChanged += this.textChanged;
			this.nELplus.Enter += this.Start_Input;
			this.nELplus.MouseDown += this.StartInput;
			this.nEMFplus.BackColor = Color.White;
			this.nEMFplus.DecimalNum = 2;
			this.nEMFplus.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMFplus.ForeColor = SystemColors.ControlText;
			this.nEMFplus.Location = new Point(544, 158);
			this.nEMFplus.MaxValue = 50000f;
			this.nEMFplus.MinValue = -50000f;
			this.nEMFplus.Name = "nEMFplus";
			this.nEMFplus.Size = new Size(80, 28);
			this.nEMFplus.TabIndex = 12;
			this.nEMFplus.Text = "0,00";
			this.nEMFplus.TextAlign = HorizontalAlignment.Right;
			this.nEMFplus.Value = 0f;
			this.nEMFplus.TextChanged += this.textChanged;
			this.nEMFplus.Enter += this.Start_Input;
			this.nEMFplus.MouseDown += this.StartInput;
			this.nEMplus.BackColor = Color.White;
			this.nEMplus.DecimalNum = 2;
			this.nEMplus.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMplus.ForeColor = SystemColors.ControlText;
			this.nEMplus.Location = new Point(544, 126);
			this.nEMplus.MaxValue = 50000f;
			this.nEMplus.MinValue = -50000f;
			this.nEMplus.Name = "nEMplus";
			this.nEMplus.Size = new Size(80, 28);
			this.nEMplus.TabIndex = 9;
			this.nEMplus.Text = "0,00";
			this.nEMplus.TextAlign = HorizontalAlignment.Right;
			this.nEMplus.Value = 0f;
			this.nEMplus.TextChanged += this.textChanged;
			this.nEMplus.Enter += this.Start_Input;
			this.nEMplus.MouseDown += this.StartInput;
			this.nEWplus.BackColor = Color.White;
			this.nEWplus.DecimalNum = 1;
			this.nEWplus.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEWplus.ForeColor = SystemColors.ControlText;
			this.nEWplus.Location = new Point(544, 54);
			this.nEWplus.MaxValue = 30000f;
			this.nEWplus.MinValue = -30000f;
			this.nEWplus.Name = "nEWplus";
			this.nEWplus.Size = new Size(80, 28);
			this.nEWplus.TabIndex = 4;
			this.nEWplus.Text = "0,0";
			this.nEWplus.TextAlign = HorizontalAlignment.Right;
			this.nEWplus.Value = 0f;
			this.nEWplus.TextChanged += this.textChanged;
			this.nEWplus.Enter += this.Start_Input;
			this.nEWplus.MouseDown += this.StartInput;
			this.lbWplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbWplus.Location = new Point(456, 57);
			this.lbWplus.Name = "lbWplus";
			this.lbWplus.RightToLeft = RightToLeft.No;
			this.lbWplus.Size = new Size(80, 23);
			this.lbWplus.TabIndex = 48;
			this.lbWplus.Text = "W+";
			this.lbWplus.TextAlign = ContentAlignment.MiddleLeft;
			this.lbLplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbLplus.ForeColor = SystemColors.ControlText;
			this.lbLplus.Location = new Point(456, 265);
			this.lbLplus.Name = "lbLplus";
			this.lbLplus.RightToLeft = RightToLeft.No;
			this.lbLplus.Size = new Size(80, 23);
			this.lbLplus.TabIndex = 52;
			this.lbLplus.Text = "L+";
			this.lbLplus.TextAlign = ContentAlignment.MiddleLeft;
			this.lbMplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMplus.Location = new Point(456, 129);
			this.lbMplus.Name = "lbMplus";
			this.lbMplus.RightToLeft = RightToLeft.No;
			this.lbMplus.Size = new Size(80, 23);
			this.lbMplus.TabIndex = 49;
			this.lbMplus.Text = "M+";
			this.lbMplus.TextAlign = ContentAlignment.MiddleLeft;
			this.lbMFplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMFplus.Location = new Point(456, 161);
			this.lbMFplus.Name = "lbMFplus";
			this.lbMFplus.RightToLeft = RightToLeft.No;
			this.lbMFplus.Size = new Size(80, 23);
			this.lbMFplus.TabIndex = 50;
			this.lbMFplus.Text = "max(MF+)";
			this.lbMFplus.TextAlign = ContentAlignment.MiddleLeft;
			this.lbASplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbASplus.Location = new Point(456, 369);
			this.lbASplus.Name = "lbASplus";
			this.lbASplus.RightToLeft = RightToLeft.No;
			this.lbASplus.Size = new Size(80, 23);
			this.lbASplus.TabIndex = 53;
			this.lbASplus.Text = "AS+";
			this.lbASplus.TextAlign = ContentAlignment.MiddleLeft;
			this.chBDigSignalDuringStep.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBDigSignalDuringStep.Location = new Point(16, 408);
			this.chBDigSignalDuringStep.Name = "chBDigSignalDuringStep";
			this.chBDigSignalDuringStep.Size = new Size(328, 24);
			this.chBDigSignalDuringStep.TabIndex = 31;
			this.chBDigSignalDuringStep.Text = "Digit. Signal (laufend überwacht)";
			this.chBDigSignalDuringStep.CheckedChanged += this.chBTMx_CheckedChanged;
			this.chBDigSignalDuringStep.Enter += this.Start_Input;
			this.chBTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBTorque.ForeColor = SystemColors.ControlText;
			this.chBTorque.Location = new Point(16, 128);
			this.chBTorque.Name = "chBTorque";
			this.chBTorque.Size = new Size(176, 24);
			this.chBTorque.TabIndex = 7;
			this.chBTorque.Text = "Moment";
			this.chBTorque.CheckedChanged += this.chBTMx_CheckedChanged;
			this.chBTorque.Enter += this.Start_Input;
			this.chBAngle.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBAngle.Location = new Point(16, 56);
			this.chBAngle.Name = "chBAngle";
			this.chBAngle.Size = new Size(176, 24);
			this.chBAngle.TabIndex = 2;
			this.chBAngle.Text = "Winkel";
			this.chBAngle.CheckedChanged += this.chBTMx_CheckedChanged;
			this.chBAngle.Enter += this.Start_Input;
			this.chBFiltTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBFiltTorque.Location = new Point(16, 160);
			this.chBFiltTorque.Name = "chBFiltTorque";
			this.chBFiltTorque.Size = new Size(176, 24);
			this.chBFiltTorque.TabIndex = 10;
			this.chBFiltTorque.Text = "gefilt. Moment";
			this.chBFiltTorque.CheckedChanged += this.chBTMx_CheckedChanged;
			this.chBFiltTorque.Enter += this.Start_Input;
			this.chBAnaDepth.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBAnaDepth.ForeColor = SystemColors.ControlText;
			this.chBAnaDepth.Location = new Point(16, 264);
			this.chBAnaDepth.Name = "chBAnaDepth";
			this.chBAnaDepth.Size = new Size(176, 24);
			this.chBAnaDepth.TabIndex = 19;
			this.chBAnaDepth.Text = "ana. Tiefe";
			this.chBAnaDepth.CheckedChanged += this.chBTMx_CheckedChanged;
			this.chBAnaDepth.Enter += this.Start_Input;
			this.chBExtAnaSignal.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBExtAnaSignal.Location = new Point(16, 368);
			this.chBExtAnaSignal.Name = "chBExtAnaSignal";
			this.chBExtAnaSignal.Size = new Size(176, 24);
			this.chBExtAnaSignal.TabIndex = 28;
			this.chBExtAnaSignal.Text = "Ex. an. Signal";
			this.chBExtAnaSignal.CheckedChanged += this.chBTMx_CheckedChanged;
			this.chBExtAnaSignal.Enter += this.Start_Input;
			this.cBDigSigRunning.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBDigSigRunning.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBDigSigRunning.Items.AddRange(new object[2]
			{
				"An",
				"Aus"
			});
			this.cBDigSigRunning.Location = new Point(352, 406);
			this.cBDigSigRunning.MaxDropDownItems = 5;
			this.cBDigSigRunning.Name = "cBDigSigRunning";
			this.cBDigSigRunning.Size = new Size(136, 28);
			this.cBDigSigRunning.TabIndex = 32;
			this.cBDigSigRunning.SelectedIndexChanged += this.settingsChanged;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.pnCheckPar);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "CheckParamForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen/Programme/Stufen/Stufe bearbeiten/Überwacungsparameter";
			base.Activated += this.CheckParamForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.pnCheckPar.ResumeLayout(false);
			this.pnCheckPar.PerformLayout();
			base.ResumeLayout(false);
		}

		public void ShowWindow(int progNum, int stepNum)
		{
			this.Main.ResetBrowserGrantedBy();
			this.showWindow = true;
			this.PNum = progNum;
			this.SNum = stepNum;
			this.SD = this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Step[this.SNum];
			this.InitializeValues();
			this.MenEna();
			base.Show();
			this.showWindow = false;
		}

		public void SetLanguageTexts()
		{
			this.showWindow = true;
			string[] array = new string[5];
			string[] array2 = new string[2];
			array[0] = this.Main.Rm.GetString("TM1") + string.Empty;
			array[1] = this.Main.Rm.GetString("TM2") + string.Empty;
			array[2] = this.Main.Rm.GetString("DigitalSignal") + string.Empty;
			array[3] = this.Main.Rm.GetString("SyncSignal") + "1";
			array[4] = this.Main.Rm.GetString("SyncSignal") + "2";
			array2[0] = this.Main.Rm.GetString("Positive") + string.Empty;
			array2[1] = this.Main.Rm.GetString("Negative") + string.Empty;
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MProgramOverview") + "/" + this.Main.Rm.GetString("MStepOverview") + "/" + this.Main.Rm.GetString("MEditStep") + "/" + this.Main.Rm.GetString("MCheckParameter");
			this.btBack.Text = this.Main.Rm.GetString("Done");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btCancel.Text = this.Main.Rm.GetString("btCancel");
			this.lbCountPassMax.Text = this.Main.Rm.GetString("CountPassMax");
			this.chBAnaDepth.Text = this.Main.Rm.GetString("AnaDepth");
			this.chBAngle.Text = this.Main.Rm.GetString("Angle");
			this.chBExtAnaSignal.Text = this.Main.Rm.GetString("AnaSignal");
			this.chBFiltTorque.Text = this.Main.Rm.GetString("FilteredTorque");
			this.chBMGmin.Text = this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("Min") + ")";
			this.chBMGmax.Text = this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("Max") + ")";
			this.chBTime.Text = this.Main.Rm.GetString("StepTmin");
			this.chBDigSignalDuringStep.Text = this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("DigSigRunning") + ")";
			this.chBDigSignalAtEnd.Text = this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("DigSigAtEnd") + ")";
			this.chBTorque.Text = this.Main.Rm.GetString("Torque");
			this.chBTreshM.Text = this.Main.Rm.GetString("TreshTorque");
			this.chBADepthGradMin.Text = this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("Min") + ")";
			this.chBADepthGradMax.Text = this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("Max") + ")";
			this.lbTmin.Text = this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("T-") + ")";
			this.lbWmin.Text = this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("W-") + ")";
			this.lbWplus.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("W+") + ")";
			this.lbMmin.Text = this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("M-") + ")";
			this.lbMplus.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("M+") + ")";
			this.lbMFmin.Text = this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("MF-") + ")";
			this.lbMFplus.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("MF+") + ")";
			this.lbMGmin.Text = this.Main.Rm.GetString("MG-");
			this.lbMGplus.Text = this.Main.Rm.GetString("MG+");
			this.lbLmin.Text = this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("L-") + ")";
			this.lbLplus.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("L+") + ")";
			this.lbLGmin.Text = this.Main.Rm.GetString("LG-");
			this.lbLGmax.Text = this.Main.Rm.GetString("LG+");
			this.lbASmin.Text = this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("AS-") + ")";
			this.lbASplus.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("AS+") + ")";
			this.lbUnitTmin.Text = this.Main.Rm.GetString("Second");
			this.lbUnitWplus.Text = this.Main.Rm.GetString("Degree");
			this.lbUnitWmin.Text = this.Main.Rm.GetString("Degree");
			this.lbUnitLplus.Text = this.Main.Rm.GetString("Milimeter");
			this.lbUnitLmin.Text = this.Main.Rm.GetString("Milimeter");
			this.lbUnitMGplus.Text = this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second");
			this.lbUnitMGmin.Text = this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second");
			this.cBDigSigAtEnd.Items.Clear();
			this.cBDigSigRunning.Items.Clear();
			this.cBDigSigEndType.Items.Clear();
			this.cBDigSigRunType.Items.Clear();
			this.cBDigSigAtEnd.Items.AddRange(array);
			this.cBDigSigRunning.Items.AddRange(array);
			this.cBDigSigEndType.Items.AddRange(array2);
			this.cBDigSigRunType.Items.AddRange(array2);
			this.cBDigSigAtEnd.SelectedIndex = 0;
			this.cBDigSigRunning.SelectedIndex = 0;
			this.cBDigSigEndType.SelectedIndex = 0;
			this.cBDigSigRunType.SelectedIndex = 0;
			this.cBMGmin.Items.Clear();
			this.cBMGmin.Items.Add(this.Main.Rm.GetString("DigSigAtEnd"));
			this.cBMGmin.Items.Add(this.Main.Rm.GetString("DigSigRunning"));
			this.cBMGmin.SelectedIndex = 0;
			this.cBMGmax.Items.Clear();
			this.cBMGmax.Items.Add(this.Main.Rm.GetString("DigSigAtEnd"));
			this.cBMGmax.Items.Add(this.Main.Rm.GetString("DigSigRunning"));
			this.cBMGmax.SelectedIndex = 0;
			this.cBLGmin.Items.Clear();
			this.cBLGmin.Items.Add(this.Main.Rm.GetString("DigSigAtEnd"));
			this.cBLGmin.Items.Add(this.Main.Rm.GetString("DigSigRunning"));
			this.cBLGmin.SelectedIndex = 0;
			this.cBLGmax.Items.Clear();
			this.cBLGmax.Items.Add(this.Main.Rm.GetString("DigSigAtEnd"));
			this.cBLGmax.Items.Add(this.Main.Rm.GetString("DigSigRunning"));
			this.cBLGmax.SelectedIndex = 0;
			this.showWindow = false;
		}

		private void MenEna()
		{
			if ((this.SD.UserRights & 1) != 1 || this.Main.PassCodeLevel < 0)
			{
				byte passCodeLevel = this.Main.PassCodeLevel;
				int userLevel_CheckParamForm = Settings.Default.UserLevel_CheckParamForm;
			}
			if ((this.SD.UserRights & 2) != 2 || this.Main.PassCodeLevel < 0)
			{
				byte passCodeLevel2 = this.Main.PassCodeLevel;
				int userLevel_CheckParamForm2 = Settings.Default.UserLevel_CheckParamForm;
			}
			if ((this.SD.UserRights & 4) == 4 && this.Main.PassCodeLevel >= 0)
			{
				goto IL_009f;
			}
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_CheckParamForm)
			{
				goto IL_009f;
			}
			bool flag = false;
			goto IL_00a5;
			IL_00a5:
			bool enabled = false;
			bool enabled2 = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_CheckParamForm)
			{
				enabled2 = true;
			}
			if (this.Main.PassCodeLevel >= 1)
			{
				enabled = true;
			}
			if (this.Main.ViewOnlyMode)
			{
				enabled = false;
				enabled2 = false;
				flag = false;
			}
			if (this.Main.IsOfflineVersion)
			{
				enabled = true;
				enabled2 = true;
				flag = true;
			}
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_CheckParamForm, this.Main.ViewOnlyMode);
			this.btBack.Enabled = enabled;
			this.chBTime.Enabled = enabled2;
			this.chBAngle.Enabled = enabled2;
			this.chBTorque.Enabled = enabled2;
			this.chBFiltTorque.Enabled = enabled2;
			this.chBMGmin.Enabled = enabled2;
			this.chBMGmax.Enabled = enabled2;
			this.chBAnaDepth.Enabled = enabled2;
			this.chBExtAnaSignal.Enabled = enabled2;
			this.chBDigSignalDuringStep.Enabled = enabled2;
			this.chBDigSignalAtEnd.Enabled = enabled2;
			this.chBADepthGradMin.Enabled = enabled2;
			this.chBADepthGradMax.Enabled = enabled2;
			this.nECountPassMax.Enabled = enabled2;
			this.nETmin.Enabled = (this.chBTime.Checked && this.chBTime.Enabled && flag);
			this.nEWplus.Enabled = (this.chBAngle.Checked && this.chBAngle.Enabled && flag);
			this.nEWmin.Enabled = (this.chBAngle.Checked && this.chBAngle.Enabled && flag);
			this.nETreshM.Enabled = (this.chBTreshM.Checked && this.chBTreshM.Enabled && this.chBAngle.Checked && flag);
			this.nEMplus.Enabled = (this.chBTorque.Checked && this.chBTorque.Enabled && flag);
			this.nEMmin.Enabled = (this.chBTorque.Checked && this.chBTorque.Enabled && flag);
			this.nEMFplus.Enabled = (this.chBFiltTorque.Checked && this.chBFiltTorque.Enabled && flag);
			this.nEMFmin.Enabled = (this.chBFiltTorque.Checked && this.chBFiltTorque.Enabled && flag);
			this.nEMGplus.Enabled = (this.chBMGmax.Checked && this.chBMGmax.Enabled && flag);
			this.nEMGmin.Enabled = (this.chBMGmin.Checked && this.chBMGmin.Enabled && flag);
			this.nELGmax.Enabled = (this.chBADepthGradMax.Checked && this.chBADepthGradMax.Enabled && flag);
			this.nELGmin.Enabled = (this.chBADepthGradMin.Checked && this.chBADepthGradMin.Enabled && flag);
			this.nELplus.Enabled = (this.chBAnaDepth.Checked && this.chBAnaDepth.Enabled && flag);
			this.nELmin.Enabled = (this.chBAnaDepth.Checked && this.chBAnaDepth.Enabled && flag);
			this.nEASplus.Enabled = (this.chBExtAnaSignal.Checked && this.chBExtAnaSignal.Enabled && flag);
			this.nEASmin.Enabled = (this.chBExtAnaSignal.Checked && this.chBExtAnaSignal.Enabled && flag);
			this.cBDigSigAtEnd.Enabled = (this.chBDigSignalAtEnd.Checked && this.chBDigSignalAtEnd.Enabled && flag);
			this.cBDigSigEndType.Enabled = (this.chBDigSignalAtEnd.Checked && this.chBDigSignalAtEnd.Enabled && flag);
			this.cBDigSigRunning.Enabled = (this.chBDigSignalDuringStep.Checked && this.chBDigSignalDuringStep.Enabled && flag);
			this.cBDigSigRunType.Enabled = (this.chBDigSignalDuringStep.Checked && this.chBDigSignalDuringStep.Enabled && flag);
			this.cBMGmin.Enabled = (this.chBMGmin.Checked && this.chBMGmin.Enabled && flag);
			this.cBMGmax.Enabled = (this.chBMGmax.Checked && this.chBMGmax.Enabled && flag);
			this.cBLGmin.Enabled = (this.chBADepthGradMin.Checked && this.chBADepthGradMin.Enabled && flag);
			this.cBLGmax.Enabled = (this.chBADepthGradMax.Checked && this.chBADepthGradMax.Enabled && flag);
			this.chBTreshM.Enabled = (this.chBAngle.Checked && this.chBAngle.Enabled && flag);
			this.nECountPassMax.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nETmin.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEWplus.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEWmin.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nETreshM.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMplus.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMmin.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMFplus.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMFmin.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMGplus.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMGmin.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nELGmax.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nELGmin.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nELplus.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nELmin.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEASplus.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEASmin.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			int num;
			switch (this.SD.Type)
			{
			case 2:
				num = 0;
				break;
			case 3:
				num = 1;
				break;
			default:
				MessageBox.Show("Wrong step type in MenEna() of CheckParameterForm", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				num = 1;
				break;
			}
			int num2;
			switch (this.SD.Switch)
			{
			case 1:
				num2 = 0;
				break;
			case 50:
				num2 = 1;
				break;
			case 3:
				num2 = 2;
				break;
			case 51:
				num2 = 3;
				break;
			case 2:
				num2 = 4;
				break;
			case 4:
				num2 = 5;
				break;
			case 52:
				num2 = 6;
				break;
			case 5:
				num2 = 7;
				break;
			case 6:
				num2 = 8;
				break;
			case 7:
				num2 = 9;
				break;
			case 53:
				num2 = 10;
				break;
			case 8:
				num2 = 11;
				break;
			case 54:
				num2 = 12;
				break;
			case 9:
				num2 = 13;
				break;
			case 55:
				num2 = 14;
				break;
			case 10:
				num2 = 15;
				break;
			case 11:
				num2 = 16;
				break;
			default:
				MessageBox.Show("Wrong switch type in MenEna() of CheckParameterForm", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				num2 = 0;
				break;
			}
			this.chBExtAnaSignal.Visible = this.Main.VisibleParameters.EnaAS[num2, num];
			this.lbASmin.Visible = this.Main.VisibleParameters.ASmin[num2, num];
			this.nEASmin.Visible = this.Main.VisibleParameters.ASmin[num2, num];
			this.lbASplus.Visible = this.Main.VisibleParameters.ASmax[num2, num];
			this.nEASplus.Visible = this.Main.VisibleParameters.ASmax[num2, num];
			this.chBAnaDepth.Visible = this.Main.VisibleParameters.EnaL[num2, num];
			this.lbLmin.Visible = this.Main.VisibleParameters.Lmin[num2, num];
			this.nELmin.Visible = this.Main.VisibleParameters.Lmin[num2, num];
			this.lbUnitLmin.Visible = this.Main.VisibleParameters.Lmin[num2, num];
			this.lbLplus.Visible = this.Main.VisibleParameters.Lmax[num2, num];
			this.nELplus.Visible = this.Main.VisibleParameters.Lmax[num2, num];
			this.lbUnitLplus.Visible = this.Main.VisibleParameters.Lmax[num2, num];
			this.chBFiltTorque.Visible = this.Main.VisibleParameters.EnaMF[num2, num];
			this.lbMFmin.Visible = this.Main.VisibleParameters.MFmin[num2, num];
			this.nEMFmin.Visible = this.Main.VisibleParameters.MFmin[num2, num];
			this.lbUnitMFmin.Visible = this.Main.VisibleParameters.MFmin[num2, num];
			this.lbMFplus.Visible = this.Main.VisibleParameters.MFmax[num2, num];
			this.nEMFplus.Visible = this.Main.VisibleParameters.MFmax[num2, num];
			this.lbUnitMFplus.Visible = this.Main.VisibleParameters.MFmax[num2, num];
			this.chBTorque.Visible = this.Main.VisibleParameters.EnaM[num2, num];
			this.lbMmin.Visible = this.Main.VisibleParameters.Mmin[num2, num];
			this.nEMmin.Visible = this.Main.VisibleParameters.Mmin[num2, num];
			this.lbUnitMmin.Visible = this.Main.VisibleParameters.Mmin[num2, num];
			this.lbMplus.Visible = this.Main.VisibleParameters.Mmax[num2, num];
			this.nEMplus.Visible = this.Main.VisibleParameters.Mmax[num2, num];
			this.lbUnitMplus.Visible = this.Main.VisibleParameters.Mmax[num2, num];
			this.chBMGmin.Visible = this.Main.VisibleParameters.MGmin[num2, num];
			this.lbMGmin.Visible = this.Main.VisibleParameters.MGmin[num2, num];
			this.nEMGmin.Visible = this.Main.VisibleParameters.MGmin[num2, num];
			this.lbUnitMGmin.Visible = this.Main.VisibleParameters.MGmin[num2, num];
			this.chBMGmax.Visible = this.Main.VisibleParameters.MGmax[num2, num];
			this.lbMGplus.Visible = this.Main.VisibleParameters.MGmax[num2, num];
			this.nEMGplus.Visible = this.Main.VisibleParameters.MGmax[num2, num];
			this.lbUnitMGplus.Visible = this.Main.VisibleParameters.MGmax[num2, num];
			this.chBADepthGradMin.Visible = this.Main.VisibleParameters.LGmin[num2, num];
			this.lbLGmin.Visible = this.Main.VisibleParameters.LGmin[num2, num];
			this.nELGmin.Visible = this.Main.VisibleParameters.LGmin[num2, num];
			this.lbUnitLGmin.Visible = this.Main.VisibleParameters.LGmin[num2, num];
			this.chBADepthGradMax.Visible = this.Main.VisibleParameters.LGmax[num2, num];
			this.lbLGmax.Visible = this.Main.VisibleParameters.LGmax[num2, num];
			this.nELGmax.Visible = this.Main.VisibleParameters.LGmax[num2, num];
			this.lbUnitLGmax.Visible = this.Main.VisibleParameters.LGmax[num2, num];
			this.chBAngle.Visible = this.Main.VisibleParameters.EnaW[num2, num];
			this.lbWmin.Visible = this.Main.VisibleParameters.Wmin[num2, num];
			this.nEWmin.Visible = this.Main.VisibleParameters.Wmin[num2, num];
			this.lbUnitWmin.Visible = this.Main.VisibleParameters.Wmin[num2, num];
			this.lbWplus.Visible = this.Main.VisibleParameters.Wmax[num2, num];
			this.nEWplus.Visible = this.Main.VisibleParameters.Wmax[num2, num];
			this.lbUnitWplus.Visible = this.Main.VisibleParameters.Wmax[num2, num];
			this.chBTreshM.Visible = this.Main.VisibleParameters.MS[num2, num];
			this.nETreshM.Visible = this.Main.VisibleParameters.MS[num2, num];
			this.lbUnitTreshM.Visible = this.Main.VisibleParameters.MS[num2, num];
			this.chBTime.Visible = this.Main.VisibleParameters.EnaT[num2, num];
			this.lbTmin.Visible = this.Main.VisibleParameters.Tmin[num2, num];
			this.nETmin.Visible = this.Main.VisibleParameters.Tmin[num2, num];
			this.lbUnitTmin.Visible = this.Main.VisibleParameters.Tmin[num2, num];
			this.chBDigSignalDuringStep.Visible = this.Main.VisibleParameters.DSmax[num2, num];
			this.cBDigSigRunning.Visible = this.Main.VisibleParameters.DSmax[num2, num];
			this.cBDigSigRunType.Visible = this.Main.VisibleParameters.DSmax[num2, num];
			this.chBDigSignalAtEnd.Visible = this.Main.VisibleParameters.DSmin[num2, num];
			this.cBDigSigAtEnd.Visible = this.Main.VisibleParameters.DSmin[num2, num];
			this.cBDigSigEndType.Visible = this.Main.VisibleParameters.DSmin[num2, num];
			this.cBMGmin.Visible = this.Main.VisibleParameters.MGmin[num2, num];
			this.cBMGmax.Visible = this.Main.VisibleParameters.MGmax[num2, num];
			this.cBLGmin.Visible = this.Main.VisibleParameters.LGmin[num2, num];
			this.cBLGmax.Visible = this.Main.VisibleParameters.LGmax[num2, num];
			return;
			IL_009f:
			flag = true;
			goto IL_00a5;
		}

		private void InitializeValues()
		{
			this.bInitialize = true;
			this.nETmin.MaxValue = 60f;
			this.nEWplus.MaxValue = 30000f;
			this.nEWmin.MaxValue = 30000f;
			this.nETreshM.MaxValue = this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMplus.MaxValue = this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMmin.MaxValue = this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMFplus.MaxValue = this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMFmin.MaxValue = this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMGplus.MaxValue = this.Main.TorqueConvert * 100f;
			this.nEMGmin.MaxValue = this.Main.TorqueConvert * 100f;
			this.nELGmax.MaxValue = 1000f;
			this.nELGmin.MaxValue = 1000f;
			this.nELplus.MaxValue = 999f;
			this.nELmin.MaxValue = 999f;
			this.nEASplus.MaxValue = this.Main.VC.SpConst.AnaSigScale * (10f + this.Main.VC.SpConst.AnaSigOffset);
			this.nEASmin.MaxValue = this.Main.VC.SpConst.AnaSigScale * (10f + this.Main.VC.SpConst.AnaSigOffset);
			this.nECountPassMax.MaxValue = 10f;
			this.nEWplus.MinValue = -30000f;
			this.nEWmin.MinValue = -30000f;
			this.nETreshM.MinValue = -1f * this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMplus.MinValue = -1f * this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMmin.MinValue = -1f * this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMFplus.MinValue = -1f * this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMFmin.MinValue = -1f * this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMGplus.MinValue = -1f * this.Main.TorqueConvert * 100f;
			this.nEMGmin.MinValue = -1f * this.Main.TorqueConvert * 100f;
			this.nELGmax.MinValue = -1000f;
			this.nELGmin.MinValue = -1000f;
			this.nELplus.MinValue = -999f;
			this.nELmin.MinValue = -999f;
			this.nEASplus.MinValue = this.Main.VC.SpConst.AnaSigScale * (-10f + this.Main.VC.SpConst.AnaSigOffset);
			this.nEASmin.MinValue = this.Main.VC.SpConst.AnaSigScale * (-10f + this.Main.VC.SpConst.AnaSigOffset);
			this.nETmin.DecimalNum = 2;
			this.nEWplus.DecimalNum = 1;
			this.nEWmin.DecimalNum = 1;
			this.nETreshM.DecimalNum = 2;
			this.nEMplus.DecimalNum = 2;
			this.nEMmin.DecimalNum = 2;
			this.nEMFplus.DecimalNum = 2;
			this.nEMFmin.DecimalNum = 2;
			this.nEMGplus.DecimalNum = 4;
			this.nEMGmin.DecimalNum = 4;
			this.nELGmax.DecimalNum = 4;
			this.nELGmin.DecimalNum = 4;
			this.nELplus.DecimalNum = 1;
			this.nELmin.DecimalNum = 1;
			this.nEASplus.DecimalNum = 2;
			this.nEASmin.DecimalNum = 2;
			this.lbUnitTreshM.Text = this.Main.TorqueUnitName;
			this.lbUnitMplus.Text = this.Main.TorqueUnitName;
			this.lbUnitMmin.Text = this.Main.TorqueUnitName;
			this.lbUnitMFplus.Text = this.Main.TorqueUnitName;
			this.lbUnitMFmin.Text = this.Main.TorqueUnitName;
			this.lbUnitMGplus.Text = this.Main.TorqueUnitName + "/" + this.Main.Rm.GetString("Degree");
			this.lbUnitMGmin.Text = this.Main.TorqueUnitName + "/" + this.Main.Rm.GetString("Degree");
			if (this.SD.Enable.Time == 1)
			{
				this.chBTime.Checked = true;
			}
			else
			{
				this.chBTime.Checked = false;
			}
			if (this.SD.Enable.Angle == 1)
			{
				this.chBAngle.Checked = true;
			}
			else
			{
				this.chBAngle.Checked = false;
			}
			if (this.SD.Enable.Snug == 1)
			{
				this.chBTreshM.Checked = true;
			}
			else
			{
				this.chBTreshM.Checked = false;
			}
			if (this.SD.Enable.Torque == 1)
			{
				this.chBTorque.Checked = true;
			}
			else
			{
				this.chBTorque.Checked = false;
			}
			if (this.SD.Enable.FTorque == 1)
			{
				this.chBFiltTorque.Checked = true;
			}
			else
			{
				this.chBFiltTorque.Checked = false;
			}
			switch (this.SD.Enable.GradientMin)
			{
			case 1:
				this.chBMGmin.Checked = true;
				this.cBMGmin.SelectedIndex = 0;
				break;
			case 2:
				this.chBMGmin.Checked = true;
				this.cBMGmin.SelectedIndex = 1;
				break;
			default:
				this.chBMGmin.Checked = false;
				this.cBMGmin.SelectedIndex = 0;
				break;
			}
			switch (this.SD.Enable.GradientMax)
			{
			case 1:
				this.chBMGmax.Checked = true;
				this.cBMGmax.SelectedIndex = 0;
				break;
			case 2:
				this.chBMGmax.Checked = true;
				this.cBMGmax.SelectedIndex = 1;
				break;
			default:
				this.chBMGmax.Checked = false;
				this.cBMGmax.SelectedIndex = 0;
				break;
			}
			if (this.SD.Enable.ADepth == 1)
			{
				this.chBAnaDepth.Checked = true;
			}
			else
			{
				this.chBAnaDepth.Checked = false;
			}
			switch (this.SD.Enable.ADepthGradMin)
			{
			case 1:
				this.chBADepthGradMin.Checked = true;
				this.cBLGmin.SelectedIndex = 0;
				break;
			case 2:
				this.chBADepthGradMin.Checked = true;
				this.cBLGmin.SelectedIndex = 1;
				break;
			default:
				this.chBADepthGradMin.Checked = false;
				this.cBLGmin.SelectedIndex = 0;
				break;
			}
			switch (this.SD.Enable.ADepthGradMax)
			{
			case 1:
				this.chBADepthGradMax.Checked = true;
				this.cBLGmax.SelectedIndex = 0;
				break;
			case 2:
				this.chBADepthGradMax.Checked = true;
				this.cBLGmax.SelectedIndex = 1;
				break;
			default:
				this.chBADepthGradMax.Checked = false;
				this.cBLGmax.SelectedIndex = 0;
				break;
			}
			if (this.SD.Enable.Ana == 1)
			{
				this.chBExtAnaSignal.Checked = true;
			}
			else
			{
				this.chBExtAnaSignal.Checked = false;
			}
			if (this.SD.DigMax != 0)
			{
				this.chBDigSignalDuringStep.Checked = true;
			}
			else
			{
				this.chBDigSignalDuringStep.Checked = false;
			}
			if (this.SD.DigMin != 0)
			{
				this.chBDigSignalAtEnd.Checked = true;
			}
			else
			{
				this.chBDigSignalAtEnd.Checked = false;
			}
			this.nETmin.Value = this.SD.Tmin;
			this.nEWplus.Value = this.SD.Wmax;
			this.nEWmin.Value = this.SD.Wmin;
			this.nEMplus.Value = this.Main.TorqueConvert * this.SD.Mmax;
			this.nEMmin.Value = this.Main.TorqueConvert * this.SD.Mmin;
			this.nEMFplus.Value = this.Main.TorqueConvert * this.SD.MFmax;
			this.nEMFmin.Value = this.Main.TorqueConvert * this.SD.MFmin;
			this.nEMGplus.Value = this.Main.TorqueConvert * this.SD.MGmax;
			this.nEMGmin.Value = this.Main.TorqueConvert * this.SD.MGmin;
			this.nELplus.Value = this.SD.Lmax;
			this.nELGmin.Value = this.SD.LGmin;
			this.nELGmax.Value = this.SD.LGmax;
			this.nELmin.Value = this.SD.Lmin;
			this.nEASplus.Value = this.SD.AnaMax;
			this.nEASmin.Value = this.SD.AnaMin;
			this.nETreshM.Value = this.Main.TorqueConvert * this.SD.MS;
			this.nECountPassMax.Value = (float)(int)this.SD.CountPassMax;
			if (this.SD.DigMin < 0)
			{
				this.cBDigSigAtEnd.SelectedIndex = -this.SD.DigMin - 1;
				this.cBDigSigEndType.SelectedIndex = 1;
			}
			if (this.SD.DigMin == 0)
			{
				this.cBDigSigAtEnd.SelectedIndex = 0;
				this.cBDigSigEndType.SelectedIndex = 0;
			}
			if (this.SD.DigMin > 0)
			{
				this.cBDigSigAtEnd.SelectedIndex = this.SD.DigMin - 1;
				this.cBDigSigEndType.SelectedIndex = 0;
			}
			if (this.SD.DigMax < 0)
			{
				this.cBDigSigRunning.SelectedIndex = -this.SD.DigMax - 1;
				this.cBDigSigRunType.SelectedIndex = 1;
			}
			if (this.SD.DigMax == 0)
			{
				this.cBDigSigRunning.SelectedIndex = 0;
				this.cBDigSigRunType.SelectedIndex = 0;
			}
			if (this.SD.DigMax > 0)
			{
				this.cBDigSigRunning.SelectedIndex = this.SD.DigMax - 1;
				this.cBDigSigRunType.SelectedIndex = 0;
			}
			this.bInitialize = false;
		}

		private bool ApplyValues()
		{
			bool flag = (this.SD.Switch == 53 || this.SD.Switch == 54 || this.SD.Switch == 51 || this.SD.Switch == 52 || this.SD.Switch == 50) && true;
			string text = string.Empty;
			float num;
			if (this.chBTime.Visible && this.chBTime.Checked)
			{
				if (!this.nETmin.IsOK)
				{
					string[] array = new string[9]
					{
						text,
						this.lbTmin.Text,
						" ",
						this.Main.Rm.GetString("OutOfRange"),
						": ",
						null,
						null,
						null,
						null
					};
					string[] array2 = array;
					num = this.nETmin.MinValue;
					array2[5] = num.ToString();
					array[6] = " - ";
					array[7] = this.nETmin.MaxValue.ToString();
					array[8] = "\n";
					text = string.Concat(array);
				}
				if (this.nETmin.Value > this.SD.Tmax)
				{
					text = text + this.chBTime.Text + ": " + this.lbTmin.Text + " > T+\n";
				}
			}
			if (this.chBAngle.Visible && this.chBAngle.Checked)
			{
				if (!this.nEWplus.IsOK)
				{
					text = text + this.lbWplus.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEWplus.MinValue.ToString() + " - " + this.nEWplus.MaxValue.ToString() + "\n";
				}
				if (!this.nEWmin.IsOK)
				{
					text = text + this.lbWmin.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEWmin.MinValue.ToString() + " - " + this.nEWmin.MaxValue.ToString() + "\n";
				}
				if (flag)
				{
					if (this.nEWplus.Value < this.nEWmin.Value)
					{
						text = text + this.chBAngle.Text + ": " + this.lbWplus.Text + " " + this.Main.Rm.GetString("FromAboveOverload") + " " + this.lbWmin.Text + "\n";
					}
				}
				else
				{
					if (this.SD.NA >= 0f && this.nEWplus.Value < this.nEWmin.Value)
					{
						text = text + this.chBAngle.Text + ": " + this.lbWplus.Text + " " + this.Main.Rm.GetString("PosOverload") + " " + this.lbWmin.Text + "\n";
					}
					if (this.SD.NA < 0f && this.nEWplus.Value > this.nEWmin.Value)
					{
						text = text + this.chBAngle.Text + ": " + this.lbWplus.Text + " " + this.Main.Rm.GetString("NegOverload") + " " + this.lbWmin.Text + "\n";
					}
				}
				if (this.chBTreshM.Checked && !this.nETreshM.IsOK)
				{
					text = text + this.chBTreshM.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nETreshM.MinValue.ToString() + " - " + this.nETreshM.MaxValue.ToString() + "\n";
				}
			}
			if (this.chBTorque.Visible && this.chBTorque.Checked)
			{
				if (!this.nEMplus.IsOK)
				{
					text = text + this.lbMplus.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMplus.MinValue.ToString() + " - " + this.nEMplus.MaxValue.ToString() + "\n";
				}
				if (!this.nEMmin.IsOK)
				{
					text = text + this.lbMmin.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMmin.MinValue.ToString() + " - " + this.nEMmin.MaxValue.ToString() + "\n";
				}
				if (flag)
				{
					if (this.nEMplus.Value < this.nEMmin.Value)
					{
						text = text + this.chBTorque.Text + ": " + this.lbMplus.Text + " " + this.Main.Rm.GetString("FromAboveOverload") + " " + this.lbMmin.Text + "\n";
					}
				}
				else
				{
					if (this.SD.NA >= 0f && this.nEMplus.Value < this.nEMmin.Value)
					{
						text = text + this.chBTorque.Text + ": " + this.lbMplus.Text + " " + this.Main.Rm.GetString("PosOverload") + " " + this.lbMmin.Text + "\n";
					}
					if (this.SD.NA < 0f && this.nEMplus.Value > this.nEMmin.Value)
					{
						text = text + this.chBTorque.Text + ": " + this.lbMplus.Text + " " + this.Main.Rm.GetString("NegOverload") + " " + this.lbMmin.Text + "\n";
					}
				}
			}
			if (this.chBFiltTorque.Visible && this.chBFiltTorque.Checked)
			{
				if (!this.nEMFplus.IsOK)
				{
					text = text + this.lbMFplus.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMFplus.MinValue.ToString() + " - " + this.nEMFplus.MaxValue.ToString() + "\n";
				}
				if (!this.nEMFmin.IsOK)
				{
					text = text + this.lbMFmin.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMFmin.MinValue.ToString() + " - " + this.nEMFmin.MaxValue.ToString() + "\n";
				}
				if (flag)
				{
					if (this.nEMFplus.Value < this.nEMFmin.Value)
					{
						text = text + this.chBFiltTorque.Text + ": " + this.lbMFplus.Text + " " + this.Main.Rm.GetString("FromAboveOverload") + " " + this.lbMFmin.Text + "\n";
					}
				}
				else
				{
					if (this.SD.NA >= 0f && this.nEMFplus.Value < this.nEMFmin.Value)
					{
						text = text + this.chBFiltTorque.Text + ": " + this.lbMFplus.Text + " " + this.Main.Rm.GetString("PosOverload") + " " + this.lbMFmin.Text + "\n";
					}
					if (this.SD.NA < 0f && this.nEMFplus.Value > this.nEMFmin.Value)
					{
						text = text + this.chBFiltTorque.Text + ": " + this.lbMFplus.Text + " " + this.Main.Rm.GetString("NegOverload") + " " + this.lbMFmin.Text + "\n";
					}
				}
			}
			if (this.chBMGmin.Visible && this.chBMGmin.Checked && !this.nEMGmin.IsOK)
			{
				text = text + this.lbMGmin.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMGmin.MinValue.ToString() + " - " + this.nEMGmin.MaxValue.ToString() + "\n";
			}
			if (this.chBMGmax.Visible && this.chBMGmax.Checked)
			{
				if (!this.nEMGplus.IsOK)
				{
					text = text + this.lbMGplus.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMGplus.MinValue.ToString() + " - " + this.nEMGplus.MaxValue.ToString() + "\n";
				}
				if (this.chBMGmin.Visible && this.chBMGmin.Checked && this.nEMGplus.Value < this.nEMGmin.Value)
				{
					text = text + this.lbMGplus.Text + " < " + this.lbMGmin.Text + "\n";
				}
			}
			if (this.chBAnaDepth.Visible && this.chBAnaDepth.Checked)
			{
				if (!this.nELplus.IsOK)
				{
					text = text + this.lbLplus.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nELplus.MinValue.ToString() + " - " + this.nELplus.MaxValue.ToString() + "\n";
				}
				if (!this.nELmin.IsOK)
				{
					text = text + this.lbLmin.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nELmin.MinValue.ToString() + " - " + this.nELmin.MaxValue.ToString() + "\n";
				}
			}
			if (this.chBADepthGradMin.Visible && this.chBADepthGradMin.Checked && !this.nELGmin.IsOK)
			{
				text = text + this.lbLGmin.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nELGmin.MinValue.ToString() + " - " + this.nELGmin.MaxValue.ToString() + "\n";
			}
			if (this.chBADepthGradMax.Visible && this.chBADepthGradMax.Checked)
			{
				if (!this.nELGmax.IsOK)
				{
					text = text + this.lbLGmax.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nELGmax.MinValue.ToString() + " - " + this.nELGmax.MaxValue.ToString() + "\n";
				}
				if (this.chBADepthGradMin.Visible && this.chBADepthGradMin.Checked && this.nELGmax.Value < this.nELGmin.Value)
				{
					text = text + this.lbLGmax.Text + " < " + this.lbLGmin.Text + "\n";
				}
			}
			if (this.chBExtAnaSignal.Visible && this.chBExtAnaSignal.Checked)
			{
				if (!this.nEASplus.IsOK)
				{
					text = text + this.lbASplus.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEASplus.MinValue.ToString() + " - " + this.nEASplus.MaxValue.ToString() + "\n";
				}
				if (!this.nEASmin.IsOK)
				{
					string[] array3 = new string[9]
					{
						text,
						this.lbASmin.Text,
						" ",
						this.Main.Rm.GetString("OutOfRange"),
						": ",
						this.nEASmin.MinValue.ToString(),
						" - ",
						null,
						null
					};
					string[] array4 = array3;
					num = this.nEASmin.MaxValue;
					array4[7] = num.ToString();
					array3[8] = "\n";
					text = string.Concat(array3);
				}
			}
			if (!this.nECountPassMax.IsOK)
			{
				string[] array = new string[9]
				{
					text,
					this.lbCountPassMax.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array5 = array;
				num = this.nECountPassMax.MinValue;
				array5[5] = num.ToString();
				array[6] = " - ";
				string[] array6 = array;
				num = this.nECountPassMax.MaxValue;
				array6[7] = num.ToString();
				array[8] = "\n";
				text = string.Concat(array);
			}
			if (this.Main.CheckParamAllowed && text != string.Empty)
			{
				MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + text, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.SD.Tmin = this.nETmin.Value;
			this.SD.Wmax = this.nEWplus.Value;
			this.SD.Wmin = this.nEWmin.Value;
			this.SD.MS = this.nETreshM.Value / this.Main.TorqueConvert;
			this.SD.Mmax = this.nEMplus.Value / this.Main.TorqueConvert;
			this.SD.Mmin = this.nEMmin.Value / this.Main.TorqueConvert;
			this.SD.MFmax = this.nEMFplus.Value / this.Main.TorqueConvert;
			this.SD.MFmin = this.nEMFmin.Value / this.Main.TorqueConvert;
			this.SD.MGmax = this.nEMGplus.Value / this.Main.TorqueConvert;
			this.SD.MGmin = this.nEMGmin.Value / this.Main.TorqueConvert;
			this.SD.Lmax = this.nELplus.Value;
			this.SD.Lmin = this.nELmin.Value;
			this.SD.LGmax = this.nELGmax.Value;
			this.SD.LGmin = this.nELGmin.Value;
			this.SD.AnaMax = this.nEASplus.Value;
			this.SD.AnaMin = this.nEASmin.Value;
			this.SD.CountPassMax = (byte)this.nECountPassMax.Value;
			if (this.chBTime.Checked)
			{
				this.SD.Enable.Time = 1;
			}
			else
			{
				this.SD.Enable.Time = 0;
			}
			if (this.chBAngle.Checked)
			{
				this.SD.Enable.Angle = 1;
			}
			else
			{
				this.SD.Enable.Angle = 0;
			}
			if (this.chBTreshM.Checked)
			{
				this.SD.Enable.Snug = 1;
			}
			else
			{
				this.SD.Enable.Snug = 0;
			}
			if (this.chBTorque.Checked)
			{
				this.SD.Enable.Torque = 1;
			}
			else
			{
				this.SD.Enable.Torque = 0;
			}
			if (this.chBFiltTorque.Checked)
			{
				this.SD.Enable.FTorque = 1;
			}
			else
			{
				this.SD.Enable.FTorque = 0;
			}
			if (this.chBMGmin.Checked)
			{
				if (this.cBMGmin.SelectedIndex == 0)
				{
					this.SD.Enable.GradientMin = 1;
				}
				else
				{
					this.SD.Enable.GradientMin = 2;
				}
			}
			else
			{
				this.SD.Enable.GradientMin = 0;
			}
			if (this.chBMGmax.Checked)
			{
				if (this.cBMGmax.SelectedIndex == 0)
				{
					this.SD.Enable.GradientMax = 1;
				}
				else
				{
					this.SD.Enable.GradientMax = 2;
				}
			}
			else
			{
				this.SD.Enable.GradientMax = 0;
			}
			if (this.chBADepthGradMin.Checked)
			{
				if (this.cBLGmin.SelectedIndex == 0)
				{
					this.SD.Enable.ADepthGradMin = 1;
				}
				else
				{
					this.SD.Enable.ADepthGradMin = 2;
				}
			}
			else
			{
				this.SD.Enable.ADepthGradMin = 0;
			}
			if (this.chBADepthGradMax.Checked)
			{
				if (this.cBLGmax.SelectedIndex == 0)
				{
					this.SD.Enable.ADepthGradMax = 1;
				}
				else
				{
					this.SD.Enable.ADepthGradMax = 2;
				}
			}
			else
			{
				this.SD.Enable.ADepthGradMax = 0;
			}
			if (this.chBAnaDepth.Checked)
			{
				this.SD.Enable.ADepth = 1;
			}
			else
			{
				this.SD.Enable.ADepth = 0;
			}
			if (this.chBExtAnaSignal.Checked)
			{
				this.SD.Enable.Ana = 1;
			}
			else
			{
				this.SD.Enable.Ana = 0;
			}
			if (this.chBDigSignalAtEnd.Checked)
			{
				if (this.cBDigSigEndType.SelectedIndex == 0)
				{
					this.SD.DigMin = (sbyte)(this.cBDigSigAtEnd.SelectedIndex + 1);
				}
				else
				{
					this.SD.DigMin = (sbyte)(-this.cBDigSigAtEnd.SelectedIndex - 1);
				}
			}
			else
			{
				this.SD.DigMin = 0;
			}
			if (this.chBDigSignalDuringStep.Checked)
			{
				if (this.cBDigSigRunType.SelectedIndex == 0)
				{
					this.SD.DigMax = (sbyte)(this.cBDigSigRunning.SelectedIndex + 1);
				}
				else
				{
					this.SD.DigMax = (sbyte)(-this.cBDigSigRunning.SelectedIndex - 1);
				}
			}
			else
			{
				this.SD.DigMax = 0;
			}
			return true;
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.chBTime.Select();
				this.pnMenu.Enabled = false;
				this.Main.StatusBarText(string.Empty);
				base.Hide();
			}
		}

		private void chBTMx_CheckedChanged(object sender, EventArgs e)
		{
			if (!this.bInitialize)
			{
				this.Main.SettingsChanged();
			}
			this.MenEna();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_1_1_1_1_Ueberwachungsparameter";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_1_1_1_1_Ueberwachungsparameter");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.Main.PassCodeLevel != 0)
			{
				if (this.pnMenu.Enabled && !this.showWindow)
				{
					this.Main.TextInput(sender);
				}
				else
				{
					this.Main.StatusBarText(string.Empty);
				}
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void CheckParamForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.bCanceled = true;
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		public void KeyArrived()
		{
			base.Hide();
			this.Main.EditDrivingStep1.KeyArrived();
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.showWindow)
			{
				this.Main.SettingsChanged();
			}
		}

		private void textChanged(object sender, EventArgs e)
		{
			if (!this.bInitialize)
			{
				this.Main.SettingsChanged();
			}
		}
	}
}
