using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class MenuAnalysisForm : Form
	{
		private MainForm Main;

		private Button btResults;

		private Button btCurveDisplay;

		private Button btLogBookFehler;

		private Button btBack;

		private Button btHelp;

		private Panel pnMenu;

		private Button btLast5NIO;

		private Button btChangesLogBook;

		private Button btLastResults;

		private GroupBox gBOverview;

		private Label lbCurveCurrent;

		private Label lbStepResults;

		private GroupBox groupBox6;

		private GroupBox groupBox5;

		private GroupBox groupBox4;

		private Label lbChangesLogbook;

		private GroupBox groupBox3;

		private Label lbLastResults;

		private GroupBox groupBox2;

		private GroupBox groupBox1;

		private Label lbLastNIO;

		private Label lbLogBookFehler;

		private Container components;

		public MenuAnalysisForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.btBack = new System.Windows.Forms.Button();
			this.btResults = new System.Windows.Forms.Button();
			this.btCurveDisplay = new System.Windows.Forms.Button();
			this.btLogBookFehler = new System.Windows.Forms.Button();
			this.btHelp = new System.Windows.Forms.Button();
			this.btLast5NIO = new System.Windows.Forms.Button();
			this.pnMenu = new System.Windows.Forms.Panel();
			this.btLastResults = new System.Windows.Forms.Button();
			this.btChangesLogBook = new System.Windows.Forms.Button();
			this.gBOverview = new System.Windows.Forms.GroupBox();
			this.groupBox6 = new System.Windows.Forms.GroupBox();
			this.lbLastNIO = new System.Windows.Forms.Label();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.lbLogBookFehler = new System.Windows.Forms.Label();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.lbChangesLogbook = new System.Windows.Forms.Label();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.lbLastResults = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.lbStepResults = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.lbCurveCurrent = new System.Windows.Forms.Label();
			this.pnMenu.SuspendLayout();
			this.gBOverview.SuspendLayout();
			this.groupBox6.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// btBack
			// 
			this.btBack.Location = new System.Drawing.Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new System.Drawing.Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			// 
			// btResults
			// 
			this.btResults.Location = new System.Drawing.Point(3, 195);
			this.btResults.Name = "btResults";
			this.btResults.Size = new System.Drawing.Size(74, 62);
			this.btResults.TabIndex = 3;
			this.btResults.Text = "Ergebnisse";
			this.btResults.Click += new System.EventHandler(this.btResults_Click);
			// 
			// btCurveDisplay
			// 
			this.btCurveDisplay.Location = new System.Drawing.Point(3, 131);
			this.btCurveDisplay.Name = "btCurveDisplay";
			this.btCurveDisplay.Size = new System.Drawing.Size(74, 62);
			this.btCurveDisplay.TabIndex = 2;
			this.btCurveDisplay.Text = "Kurven";
			// 
			// btLogBookFehler
			// 
			this.btLogBookFehler.Location = new System.Drawing.Point(3, 387);
			this.btLogBookFehler.Name = "btLogBookFehler";
			this.btLogBookFehler.Size = new System.Drawing.Size(74, 62);
			this.btLogBookFehler.TabIndex = 6;
			this.btLogBookFehler.Text = "Fehler Log";
			// 
			// btHelp
			// 
			this.btHelp.Location = new System.Drawing.Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new System.Drawing.Size(74, 62);
			this.btHelp.TabIndex = 1;
			// 
			// btLast5NIO
			// 
			this.btLast5NIO.Enabled = false;
			this.btLast5NIO.Location = new System.Drawing.Point(3, 451);
			this.btLast5NIO.Name = "btLast5NIO";
			this.btLast5NIO.Size = new System.Drawing.Size(74, 62);
			this.btLast5NIO.TabIndex = 7;
			// 
			// pnMenu
			// 
			this.pnMenu.Controls.Add(this.btLastResults);
			this.pnMenu.Controls.Add(this.btChangesLogBook);
			this.pnMenu.Controls.Add(this.btLast5NIO);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btLogBookFehler);
			this.pnMenu.Controls.Add(this.btCurveDisplay);
			this.pnMenu.Controls.Add(this.btResults);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new System.Drawing.Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new System.Drawing.Size(80, 516);
			this.pnMenu.TabIndex = 0;
			// 
			// btLastResults
			// 
			this.btLastResults.Enabled = false;
			this.btLastResults.Location = new System.Drawing.Point(3, 259);
			this.btLastResults.Name = "btLastResults";
			this.btLastResults.Size = new System.Drawing.Size(74, 62);
			this.btLastResults.TabIndex = 4;
			// 
			// btChangesLogBook
			// 
			this.btChangesLogBook.Location = new System.Drawing.Point(3, 323);
			this.btChangesLogBook.Name = "btChangesLogBook";
			this.btChangesLogBook.Size = new System.Drawing.Size(74, 62);
			this.btChangesLogBook.TabIndex = 5;
			this.btChangesLogBook.Text = "Änderungen Log";
			// 
			// gBOverview
			// 
			this.gBOverview.Controls.Add(this.groupBox6);
			this.gBOverview.Controls.Add(this.groupBox5);
			this.gBOverview.Controls.Add(this.groupBox4);
			this.gBOverview.Controls.Add(this.groupBox3);
			this.gBOverview.Controls.Add(this.groupBox2);
			this.gBOverview.Controls.Add(this.groupBox1);
			this.gBOverview.Location = new System.Drawing.Point(420, 106);
			this.gBOverview.Name = "gBOverview";
			this.gBOverview.Size = new System.Drawing.Size(274, 407);
			this.gBOverview.TabIndex = 1;
			this.gBOverview.TabStop = false;
			this.gBOverview.Text = "Übersicht";
			// 
			// groupBox6
			// 
			this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox6.Controls.Add(this.lbLastNIO);
			this.groupBox6.Location = new System.Drawing.Point(9, 341);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new System.Drawing.Size(260, 62);
			this.groupBox6.TabIndex = 9;
			this.groupBox6.TabStop = false;
			this.groupBox6.Visible = false;
			// 
			// lbLastNIO
			// 
			this.lbLastNIO.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbLastNIO.Location = new System.Drawing.Point(22, 15);
			this.lbLastNIO.Name = "lbLastNIO";
			this.lbLastNIO.Size = new System.Drawing.Size(229, 41);
			this.lbLastNIO.TabIndex = 6;
			this.lbLastNIO.Text = "Anzahl in der Liste:";
			this.lbLastNIO.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbLastNIO.Visible = false;
			// 
			// groupBox5
			// 
			this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox5.Controls.Add(this.lbLogBookFehler);
			this.groupBox5.Location = new System.Drawing.Point(9, 277);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(260, 62);
			this.groupBox5.TabIndex = 8;
			this.groupBox5.TabStop = false;
			// 
			// lbLogBookFehler
			// 
			this.lbLogBookFehler.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbLogBookFehler.Location = new System.Drawing.Point(22, 15);
			this.lbLogBookFehler.Name = "lbLogBookFehler";
			this.lbLogBookFehler.Size = new System.Drawing.Size(229, 41);
			this.lbLogBookFehler.TabIndex = 5;
			this.lbLogBookFehler.Text = "Anzahl in der Liste:";
			this.lbLogBookFehler.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// groupBox4
			// 
			this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox4.Controls.Add(this.lbChangesLogbook);
			this.groupBox4.Location = new System.Drawing.Point(9, 214);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(260, 62);
			this.groupBox4.TabIndex = 7;
			this.groupBox4.TabStop = false;
			// 
			// lbChangesLogbook
			// 
			this.lbChangesLogbook.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbChangesLogbook.Location = new System.Drawing.Point(22, 15);
			this.lbChangesLogbook.Name = "lbChangesLogbook";
			this.lbChangesLogbook.Size = new System.Drawing.Size(229, 41);
			this.lbChangesLogbook.TabIndex = 4;
			this.lbChangesLogbook.Text = "Anzahl in der Liste:";
			this.lbChangesLogbook.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// groupBox3
			// 
			this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox3.Controls.Add(this.lbLastResults);
			this.groupBox3.Location = new System.Drawing.Point(9, 149);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(260, 62);
			this.groupBox3.TabIndex = 6;
			this.groupBox3.TabStop = false;
			this.groupBox3.Visible = false;
			// 
			// lbLastResults
			// 
			this.lbLastResults.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbLastResults.Location = new System.Drawing.Point(22, 14);
			this.lbLastResults.Name = "lbLastResults";
			this.lbLastResults.Size = new System.Drawing.Size(229, 41);
			this.lbLastResults.TabIndex = 3;
			this.lbLastResults.Text = "Anzahl in der Liste:";
			this.lbLastResults.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbLastResults.Visible = false;
			// 
			// groupBox2
			// 
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox2.Controls.Add(this.lbStepResults);
			this.groupBox2.Location = new System.Drawing.Point(9, 85);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(260, 62);
			this.groupBox2.TabIndex = 5;
			this.groupBox2.TabStop = false;
			// 
			// lbStepResults
			// 
			this.lbStepResults.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbStepResults.Location = new System.Drawing.Point(22, 11);
			this.lbStepResults.Name = "lbStepResults";
			this.lbStepResults.Size = new System.Drawing.Size(229, 48);
			this.lbStepResults.TabIndex = 2;
			this.lbStepResults.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.Controls.Add(this.lbCurveCurrent);
			this.groupBox1.Location = new System.Drawing.Point(9, 21);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(260, 62);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			// 
			// lbCurveCurrent
			// 
			this.lbCurveCurrent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbCurveCurrent.Location = new System.Drawing.Point(22, 15);
			this.lbCurveCurrent.Name = "lbCurveCurrent";
			this.lbCurveCurrent.Size = new System.Drawing.Size(232, 44);
			this.lbCurveCurrent.TabIndex = 0;
			this.lbCurveCurrent.Text = "Aktuelle Kurve (Name)  Status Kurvenspeicherung";
			this.lbCurveCurrent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// MenuAnalysisForm
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(789, 544);
			this.ControlBox = false;
			this.Controls.Add(this.gBOverview);
			this.Controls.Add(this.pnMenu);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "MenuAnalysisForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "Auswertung";
			this.pnMenu.ResumeLayout(false);
			this.gBOverview.ResumeLayout(false);
			this.groupBox6.ResumeLayout(false);
			this.groupBox5.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		public void ShowWindow()
		{
			this.Main.ActivationBrowserGrantedBy = this;
			this.MenEna();
			base.Show();
		}

		public void SetLanguageTexts()
		{
			this.Main.ActivationBrowserGrantedBy = this;
			this.Text = this.Main.Rm.GetString("MenuAnalysis");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btCurveDisplay.Text = this.Main.Rm.GetString("CurveDisplay");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btLogBookFehler.Text = this.Main.Rm.GetString("ErrorLog");
			this.btResults.Text = this.Main.Rm.GetString("btResults");
			this.btChangesLogBook.Text = this.Main.Rm.GetString("ChangesLog");
			this.btChangesLogBook.Enabled = true;
			this.gBOverview.Text = this.Main.Rm.GetString("gbOverview");
		}

		private void MenEna()
		{
			if (!this.Main.IsOnlineMode)
			{
				this.btLogBookFehler.Enabled = false;
				this.btResults.Enabled = false;
			}
			else
			{
				this.btLogBookFehler.Enabled = true;
				this.btResults.Enabled = true;
			}
		}

		public void Overview(bool exclusiveForCurve)
		{
			if (!this.Main.IsOnlineMode)
			{
				this.lbStepResults.Text = this.Main.Rm.GetString("LastResults") + " (" + this.Main.Rm.GetString("OfflineMode") + ")\n" + this.Main.Rm.GetString("LastNIO") + "\n" + this.Main.Rm.GetString("StepResults_");
			}
			else
			{
				if (!exclusiveForCurve)
				{
					Label label = this.lbLogBookFehler;
					Label label2 = this.lbLastResults;
					Label label3 = this.lbLastNIO;
					Label label4 = this.lbChangesLogbook;
					Label label5 = this.lbStepResults;
					string text2 = label5.Text = this.Main.Rm.GetString("lbNumberInList") + " ";
					string text4 = label4.Text = text2;
					string text6 = label3.Text = text4;
					string text9 = label.Text = (label2.Text = text6);
					Cursor.Current = Cursors.WaitCursor;
					this.Main.StatusBarText(this.Main.Rm.GetString("LoadLastResults"));
					if (!this.Main.VC.ReceiveVarBlock(32))
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
					}
					Cursor.Current = Cursors.Default;
					this.lbStepResults.Text = this.Main.Rm.GetString("LastResults") + " (" + this.Main.VC.StatSample.Info.Length.ToString() + ")\n" + this.Main.Rm.GetString("LastNIO") + " (" + this.Main.LastNIOResults1.Count(true) + ")\n" + this.Main.Rm.GetString("StepResults_") + " (" + this.Main.StepResult1.Count() + ")";
					Label label6 = this.lbLogBookFehler;
					object text10 = label6.Text;
					label6.Text = text10 + " " + this.Main.Rm.GetString("ErrorLog_") + ": " + this.Main.LogBookForm1.Count(true);
					Label label7 = this.lbChangesLogbook;
					object text11 = label7.Text;
					label7.Text = text11 + " " + this.Main.Rm.GetString("ChangesLog_") + ": " + this.Main.LogChangesForm1.Count(true);
				}
				if (this.Main.CurveDisplay1.IsAutomaticCurveModeActive())
				{
					this.Main.CurveDisplay1.AutoModeAttributes(out int num, out string text12, out string text13);
					this.lbCurveCurrent.Text = this.Main.Rm.GetString("CycleSave") + "\n" + text12 + ": " + text13 + "(" + num.ToString() + ")";
				}
				else if (this.Main.CurveDisplay1.IsFifoCurveBufferActive())
				{
					this.lbCurveCurrent.Text = this.Main.Rm.GetString("RemainedCurvesFIFO") + ": ";
					Label label8 = this.lbCurveCurrent;
					label8.Text += this.Main.CurveFifo.CurveFiles.Count().ToString();
				}
				else
				{
					this.lbCurveCurrent.Text = this.Main.Rm.GetString("lbNoAutoCurve");
				}
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_2_Auswertung";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_2_Auswertung");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btCurveDisplay_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.Main.CurveDisplay1.ShowWindow();
		}

		private void btStepResults_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.StatisticsLastRes1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void btStatistics_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			int num = 0;
			if (!this.Main.Usb_Key_Access())
			{
				this.Main.PasswordInput1.ShowWindow(false);
				num = this.Main.PasswordInput1.AccessMode;
				if (num == 2)
				{
					this.pnMenu.Enabled = true;
					this.MenEna();
					return;
				}
			}
			this.Main.DisplayCurrentUser();
			if (!this.Main.MenuStatistics1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
				this.MenEna();
			}
		}

		private void btLogBookFehler_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.LogBookForm1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
				this.MenEna();
			}
		}

		private void btLast5NIO_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.LastNIOResults1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
				this.MenEna();
			}
		}

		private void btChangesLogBook_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.LogChangesForm1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
				this.MenEna();
			}
		}

		private void btLastResults_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.StatisticsLastRes1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void MenuAnalysisForm_Activated(object sender, EventArgs e)
		{
			this.Overview(false);
			this.Main.ActivationBrowserGrantedBy = this;
			this.MenEna();
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else
			{
				this.MenEna();
			}
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void lbX_MouseDown(object sender, MouseEventArgs e)
		{
			Label label = sender as Label;
			if (label == this.lbCurveCurrent)
			{
				this.lbCurveCurrent.BackColor = SystemColors.ControlLight;
			}
			else if (label == this.lbStepResults)
			{
				this.lbStepResults.BackColor = SystemColors.ControlLight;
			}
			else if (label == this.lbLastResults)
			{
				this.lbLastResults.BackColor = SystemColors.ControlLight;
			}
			else if (label == this.lbChangesLogbook)
			{
				this.lbChangesLogbook.BackColor = SystemColors.ControlLight;
			}
			else if (label == this.lbLogBookFehler)
			{
				this.lbLogBookFehler.BackColor = SystemColors.ControlLight;
			}
			else if (label == this.lbLastNIO)
			{
				this.lbLastNIO.BackColor = SystemColors.ControlLight;
			}
		}

		private void lbX_MouseUp(object sender, MouseEventArgs e)
		{
			this.lbCurveCurrent.BackColor = SystemColors.Control;
			this.lbStepResults.BackColor = SystemColors.Control;
			this.lbLastResults.BackColor = SystemColors.Control;
			this.lbChangesLogbook.BackColor = SystemColors.Control;
			this.lbLogBookFehler.BackColor = SystemColors.Control;
			this.lbLastNIO.BackColor = SystemColors.Control;
		}

		private void lbX_MouseLeave(object sender, EventArgs e)
		{
			this.lbCurveCurrent.BackColor = SystemColors.Control;
			this.lbStepResults.BackColor = SystemColors.Control;
			this.lbLastResults.BackColor = SystemColors.Control;
			this.lbChangesLogbook.BackColor = SystemColors.Control;
			this.lbLogBookFehler.BackColor = SystemColors.Control;
			this.lbLastNIO.BackColor = SystemColors.Control;
		}

		private void btResults_Click(object sender, EventArgs e)
		{

		}
	}
}
