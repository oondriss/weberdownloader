using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class StepResultForm : Form
	{
		private MainForm Main;

		private int PrintPos;

		private DataTable ResData;

		private DataGridTableStyle Ts;

		private string[] ColumnName;

		private bool Hold;

		private bool UpdateEnable;

		private int SaveNum;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private DataGridView ResultGrid;

		private Button btPrint;

		private PrintDocument printDocument;

		private PrintDialog printDialog;

		private Button btActualize;

		private Button btHold;

		private Timer timerUpdate;

		private SaveFileDialog SFD;

		private Button btStartExport;

		private Button btStopExport;

		private Label lbHeader;

		private Button btLastResults;

		private Button btLast5NIO;

		private IContainer components;

		public StepResultForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.PrintPos = 0;
			this.Hold = true;
			this.UpdateEnable = false;
			this.SaveNum = 0;
			this.ResData = new DataTable("StepResults");
			this.ColumnName = new string[15];
			this.ColumnName[0] = "Step";
			this.ColumnName[1] = "IONIO";
			this.ColumnName[2] = "Torque";
			this.ColumnName[3] = "MaxTorque";
			this.ColumnName[4] = "FiltTorque";
			this.ColumnName[5] = "Gradient";
			this.ColumnName[6] = "Angel";
			this.ColumnName[7] = "DateTime";
			this.ColumnName[8] = "AnaDepth";
			this.ColumnName[9] = "TM1";
			this.ColumnName[10] = "TM2";
			this.ColumnName[11] = "DepthGrad";
			this.ColumnName[12] = "DelayTorque";
			this.ColumnName[13] = "M360Follow";
			this.ColumnName[14] = "AnaSignal";
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[0], typeof(int)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[1], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[2], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[3], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[4], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[5], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[6], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[7], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[8], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[9], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[10], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[11], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[12], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[13], typeof(string)));
			this.ResData.Columns.Add(new DataColumn(this.ColumnName[14], typeof(string)));
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
			this.pnMenu = new Panel();
			this.btLast5NIO = new Button();
			this.btLastResults = new Button();
			this.btPrint = new Button();
			this.btStopExport = new Button();
			this.btStartExport = new Button();
			this.btActualize = new Button();
			this.btHold = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.ResultGrid = new DataGridView();
			this.printDocument = new PrintDocument();
			this.printDialog = new PrintDialog();
			this.timerUpdate = new Timer(this.components);
			this.SFD = new SaveFileDialog();
			this.lbHeader = new Label();
			this.pnMenu.SuspendLayout();
			((ISupportInitialize)this.ResultGrid).BeginInit();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btLast5NIO);
			this.pnMenu.Controls.Add(this.btLastResults);
			this.pnMenu.Controls.Add(this.btPrint);
			this.pnMenu.Controls.Add(this.btStopExport);
			this.pnMenu.Controls.Add(this.btStartExport);
			this.pnMenu.Controls.Add(this.btActualize);
			this.pnMenu.Controls.Add(this.btHold);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btLast5NIO.Location = new Point(3, 196);
			this.btLast5NIO.Name = "btLast5NIO";
			this.btLast5NIO.Size = new Size(74, 62);
			this.btLast5NIO.TabIndex = 9;
			this.btLast5NIO.Text = "Letzten 5 NIO";
			this.btLast5NIO.Click += this.btLast5NIO_Click;
			this.btLastResults.Location = new Point(3, 132);
			this.btLastResults.Name = "btLastResults";
			this.btLastResults.Size = new Size(74, 62);
			this.btLastResults.TabIndex = 8;
			this.btLastResults.Text = "Die letzten Ergebnisse";
			this.btLastResults.Click += this.btLastResults_Click;
			this.btPrint.Location = new Point(3, 451);
			this.btPrint.Name = "btPrint";
			this.btPrint.Size = new Size(74, 62);
			this.btPrint.TabIndex = 7;
			this.btPrint.Text = "Print";
			this.btPrint.Click += this.btPrint_Click;
			this.btStopExport.Location = new Point(3, 387);
			this.btStopExport.Name = "btStopExport";
			this.btStopExport.Size = new Size(74, 62);
			this.btStopExport.TabIndex = 6;
			this.btStopExport.Text = "Stop export";
			this.btStopExport.Click += this.btStopExport_Click;
			this.btStartExport.Location = new Point(3, 387);
			this.btStartExport.Name = "btStartExport";
			this.btStartExport.Size = new Size(74, 62);
			this.btStartExport.TabIndex = 5;
			this.btStartExport.Text = "Start export";
			this.btStartExport.Click += this.btStartExport_Click;
			this.btActualize.Location = new Point(3, 324);
			this.btActualize.Name = "btActualize";
			this.btActualize.Size = new Size(74, 62);
			this.btActualize.TabIndex = 3;
			this.btActualize.Text = "Ergebnis laufend erneuern";
			this.btActualize.Click += this.btActualize_Click;
			this.btHold.Location = new Point(3, 260);
			this.btHold.Name = "btHold";
			this.btHold.Size = new Size(74, 62);
			this.btHold.TabIndex = 2;
			this.btHold.Text = "Ergebnis halten";
			this.btHold.Click += this.btHold_Click;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = SystemColors.Window;
			dataGridViewCellStyle.Font = new Font("Arial Unicode MS", 10f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			dataGridViewCellStyle.ForeColor = SystemColors.ControlText;
			dataGridViewCellStyle.SelectionBackColor = SystemColors.Highlight;
			dataGridViewCellStyle.SelectionForeColor = SystemColors.HighlightText;
			this.ResultGrid.DefaultCellStyle = dataGridViewCellStyle;
			this.ResultGrid.Font = new Font("Arial Unicode MS", 10f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.ResultGrid.Location = new Point(0, 16);
			this.ResultGrid.Name = "ResultGrid";
			this.ResultGrid.ReadOnly = true;
			this.ResultGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			this.ResultGrid.Size = new Size(709, 497);
			this.ResultGrid.TabIndex = 1;
			this.printDocument.PrintPage += this.printDocument_PrintPage;
			this.printDialog.Document = this.printDocument;
			this.timerUpdate.Tick += this.timerUpdate_Tick;
			this.SFD.Filter = "StepRes|*.txt|All Files|*.*";
			this.SFD.OverwritePrompt = false;
			this.lbHeader.BackColor = SystemColors.ActiveCaption;
			this.lbHeader.Location = new Point(0, 0);
			this.lbHeader.Name = "lbHeader";
			this.lbHeader.Size = new Size(709, 15);
			this.lbHeader.TabIndex = 2;
			this.lbHeader.Text = "label1";
			this.lbHeader.TextAlign = ContentAlignment.MiddleCenter;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.lbHeader);
			base.Controls.Add(this.ResultGrid);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "StepResultForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Auswertung/Stufenergebnisse";
			base.Activated += this.StepResultForm_Activated;
			this.pnMenu.ResumeLayout(false);
			((ISupportInitialize)this.ResultGrid).EndInit();
			base.ResumeLayout(false);
		}

		public void ShowWindow()
		{
			this.Main.ActivationBrowserGrantedBy = this;
			this.btStartExport.Visible = true;
			this.btStopExport.Visible = false;
			this.Hold = false;
			this.btHold.Enabled = true;
			this.btActualize.Enabled = false;
			this.UpdateTable();
			this.timerUpdate.Enabled = true;
			base.Show();
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuAnalysis") + "/" + this.Main.Rm.GetString("MStepResults");
			this.btLast5NIO.Text = this.Main.Rm.GetString("LastNIO");
			this.btLastResults.Text = this.Main.Rm.GetString("LastResults");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btPrint.Text = this.Main.Rm.GetString("Print");
			this.btHold.Text = this.Main.Rm.GetString("Hold");
			this.btActualize.Text = this.Main.Rm.GetString("Actualize");
			this.btStartExport.Text = this.Main.Rm.GetString("StartStepResExport");
			this.btStopExport.Text = this.Main.Rm.GetString("StopStepResExport");
			this.printDocument.DocumentName = this.Main.Rm.GetString("MStepResults");
			this.SFD.Filter = this.Main.Rm.GetString("MStepResults") + "|*.txt|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
		}

		public int Count()
		{
			int num = 0;
			for (int i = 0; i < 250; i++)
			{
				if (this.Main.VC.Result.StepResult[i].IONIO != 0)
				{
					num++;
				}
			}
			return num;
		}

		private void FillTable()
		{
			int num = 0;
			int num2 = this.ColumnName.Length;
			int[] array = new int[num2];
			for (int i = 0; i < num2; i++)
			{
				array[i] = 0;
			}
			Graphics graphics = this.ResultGrid.CreateGraphics();
			this.ResData.Clear();
			string text;
			for (int i = 0; i < 250; i++)
			{
				DataRow row;
				string @string;
				string string2;
				int num3;
				switch (this.Main.VC.Result.StepResult[i].IONIO)
				{
				case 1:
					text = this.Main.Rm.GetString("OK");
					goto IL_00e8;
				default:
					text = this.Main.Rm.GetString("NOK") + ": " + this.Main.Rm.GetString("NIO" + this.Main.VC.Result.StepResult[i].IONIO.ToString());
					goto IL_00e8;
				case 0:
					break;
					IL_00e8:
					row = this.ResData.NewRow();
					this.ResData.Rows.Add(row);
					this.ResData.Rows[num][this.ColumnName[0]] = (this.Main.VC.Result.StepResult[i].Step + 1).ToString();
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[0]].ToString() + "a", this.ResultGrid.Font).Width);
					if (num3 > array[0])
					{
						array[0] = num3;
					}
					this.ResData.Rows[num][this.ColumnName[1]] = text;
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(text + "a", this.ResultGrid.Font).Width);
					if (num3 > array[1])
					{
						array[1] = num3;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[2]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[2]] = (this.Main.VC.Result.StepResult[i].Torque * this.Main.TorqueConvert).ToString("f" + 2.ToString());
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[2]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[2])
					{
						array[2] = num3;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[3]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[3]] = (this.Main.VC.Result.StepResult[i].MaxTorque * this.Main.TorqueConvert).ToString("f" + 2.ToString());
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[3]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[3])
					{
						array[3] = num3;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[4]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[4]] = (this.Main.VC.Result.StepResult[i].FTorque * this.Main.TorqueConvert).ToString("f" + 2.ToString());
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[4]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[4])
					{
						array[4] = num3;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[5]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[5]] = (this.Main.VC.Result.StepResult[i].Gradient * this.Main.TorqueConvert).ToString("f" + 4.ToString());
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[5]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[5])
					{
						array[5] = num3;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[6]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[6]] = this.Main.VC.Result.StepResult[i].Angle.ToString("f" + 1.ToString());
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[6]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[6])
					{
						array[6] = num3;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[7]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[7]] = this.Main.VC.Result.StepResult[i].Time.ToString("f" + 2.ToString());
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[7]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[7])
					{
						array[7] = num3;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[8]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[8]] = this.Main.VC.Result.StepResult[i].ADepth.ToString("f" + 1.ToString());
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[8]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[8])
					{
						array[8] = num3;
					}
					switch (this.Main.VC.Result.StepResult[i].Dig)
					{
					case 0:
						@string = this.Main.Rm.GetString("Off");
						string2 = this.Main.Rm.GetString("Off");
						break;
					case 1:
						@string = this.Main.Rm.GetString("On");
						string2 = this.Main.Rm.GetString("Off");
						break;
					case 2:
						@string = this.Main.Rm.GetString("Off");
						string2 = this.Main.Rm.GetString("On");
						break;
					case 3:
						@string = this.Main.Rm.GetString("On");
						string2 = this.Main.Rm.GetString("On");
						break;
					default:
						MessageBox.Show("Wrong dig signal type in FillTable() of StepResult", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						@string = this.Main.Rm.GetString("Err");
						string2 = this.Main.Rm.GetString("Err");
						break;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[9]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[9]] = @string;
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[9]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[9])
					{
						array[9] = num3;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[10]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[10]] = string2;
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[10]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[10])
					{
						array[10] = num3;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[11]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[11]] = this.Main.VC.Result.StepResult[i].ADepthGrad.ToString("f" + 4.ToString());
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[11]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[11])
					{
						array[11] = num3;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[12]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[12]] = (this.Main.VC.Result.StepResult[i].DelayTorque * this.Main.TorqueConvert).ToString("f" + 2.ToString());
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[12]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[12])
					{
						array[12] = num3;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[13]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[13]] = this.Main.VC.Result.StepResult[i].M360Follow.ToString("f" + 2.ToString());
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[13]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[13])
					{
						array[13] = num3;
					}
					if (this.Main.VC.Result.StepResult[i].OrgStep != 0)
					{
						this.ResData.Rows[num][this.ColumnName[14]] = this.Main.Rm.GetString("NotValid");
					}
					else
					{
						this.ResData.Rows[num][this.ColumnName[14]] = this.Main.VC.Result.StepResult[i].Ana.ToString("f" + 2.ToString());
					}
					num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResData.Rows[num][this.ColumnName[14]] + "a", this.ResultGrid.Font).Width);
					if (num3 > array[14])
					{
						array[14] = num3;
					}
					num++;
					break;
				}
			}
			short iONIO = this.Main.VC.Result.IONIO;
			DateTime dateTime;
			try
			{
				dateTime = new DateTime(this.Main.VC.Result.Time.Year, this.Main.VC.Result.Time.Month, this.Main.VC.Result.Time.Day, this.Main.VC.Result.Time.Hour, this.Main.VC.Result.Time.Minute, this.Main.VC.Result.Time.Second);
			}
			catch
			{
				dateTime = new DateTime(1, 1, 1, 0, 0, 0);
			}
			text = ((this.Main.VC.Result.IONIO != 1) ? (this.Main.Rm.GetString("NOK") + ": " + this.Main.Rm.GetString("NIO" + this.Main.VC.Result.IONIO.ToString()) + "(" + this.Main.Rm.GetString("Step") + " " + (this.Main.VC.Result.LastStep + 1).ToString() + ")") : this.Main.Rm.GetString("OK"));
			this.ResultGrid.DataSource = this.ResData;
			this.ResultGrid.Columns[0].HeaderText = this.Main.Rm.GetString("Step");
			this.ResultGrid.Columns[1].HeaderText = this.Main.Rm.GetString("OKNOK");
			this.ResultGrid.Columns[2].HeaderText = this.Main.Rm.GetString("AbrTorque") + "(" + this.Main.TorqueUnitName + ")";
			this.ResultGrid.Columns[3].HeaderText = this.Main.Rm.GetString("AbrMaxTorque") + "(" + this.Main.TorqueUnitName + ")";
			this.ResultGrid.Columns[4].HeaderText = this.Main.Rm.GetString("AbrFilteredTorque") + "(" + this.Main.TorqueUnitName + ")";
			this.ResultGrid.Columns[5].HeaderText = this.Main.Rm.GetString("AbrGradient") + "(" + this.Main.TorqueUnitName + "/" + this.Main.Rm.GetString("Degree") + ")";
			this.ResultGrid.Columns[6].HeaderText = this.Main.Rm.GetString("AbrAngle") + "(" + this.Main.Rm.GetString("Degree") + ")";
			this.ResultGrid.Columns[7].HeaderText = this.Main.Rm.GetString("AbrTime") + "(" + this.Main.Rm.GetString("Second") + ")";
			this.ResultGrid.Columns[8].HeaderText = this.Main.Rm.GetString("AbrAnaDepth") + "(" + this.Main.Rm.GetString("Milimeter") + ")";
			this.ResultGrid.Columns[9].HeaderText = this.Main.Rm.GetString("TM1");
			this.ResultGrid.Columns[10].HeaderText = this.Main.Rm.GetString("TM2");
			this.ResultGrid.Columns[11].HeaderText = this.Main.Rm.GetString("AbrDepthGrad") + "(" + this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second") + ")";
			this.ResultGrid.Columns[12].HeaderText = this.Main.Rm.GetString("AbrDelayTorque") + "(" + this.Main.TorqueUnitName + ")";
			this.ResultGrid.Columns[13].HeaderText = this.Main.Rm.GetString("AbrM360Follow") + "(" + this.Main.TorqueUnitName + ")";
			this.ResultGrid.Columns[14].HeaderText = this.Main.Rm.GetString("AbrAnaSignal") + "(" + this.Main.Rm.GetString("Voltage") + ")";
			for (int i = 0; i < num2; i++)
			{
				int num3 = (int)Math.Ceiling((double)graphics.MeasureString(this.ResultGrid.Columns[i].HeaderText + "AA", this.ResultGrid.Font).Width);
				if (num3 > array[i])
				{
					array[i] = num3;
				}
				this.ResultGrid.Columns[i].Width = array[i];
			}
			this.lbHeader.Text = this.Main.Rm.GetString("Program") + " " + this.Main.VC.Result.Prog.Info.ProgNum.ToString() + ": " + this.Main.CommonFunctions.UShortToString(this.Main.VC.Result.Prog.Info.Name) + "   " + text + "   " + this.Main.Rm.GetString("Cycle") + ": " + this.Main.VC.Result.Cycle + "   " + this.Main.Rm.GetString("Time") + ": " + dateTime.ToString(Settings.Default.TimeSet) + "   " + this.Main.Rm.GetString("LastDoneStep") + ": " + (this.Main.VC.Result.LastStep + 1).ToString();
		}

		private void btPrint_Click(object sender, EventArgs e)
		{
			if (this.printDialog.ShowDialog() == DialogResult.OK)
			{
				this.printDocument.DefaultPageSettings.Margins.Bottom = 50;
				this.printDocument.DefaultPageSettings.Margins.Left = 50;
				this.printDocument.DefaultPageSettings.Margins.Right = 50;
				this.printDocument.DefaultPageSettings.Margins.Top = 50;
				this.printDocument.Print();
			}
		}

		private void printDocument_PrintPage(object sender, PrintPageEventArgs e)
		{
			float num = 0f;
			float num2 = 0f;
			float num3 = 0f;
			float num4 = 0f;
			int count = this.ResData.Columns.Count;
			float[] array = new float[count + 1];
			string empty = string.Empty;
			DateTime now = DateTime.Now;
			Graphics graphics = e.Graphics;
			float num5 = (float)e.MarginBounds.Left;
			float x = (float)e.MarginBounds.Right;
			float num6 = (float)e.MarginBounds.Bottom;
			float num7 = (float)e.MarginBounds.Top;
			Font font = new Font("Arial", 10f, FontStyle.Bold);
			Pen pen = new Pen(Brushes.Black);
			for (int i = 0; i < count; i++)
			{
				array[i] = (float)this.ResultGrid.Columns[i].Width;
				num += array[i];
			}
			num3 = (float)e.MarginBounds.Width / num;
			Font font2 = new Font("Arial Unicode MS", 11f * num3, GraphicsUnit.Pixel);
			num = num5;
			for (int i = 0; i <= count; i++)
			{
				num4 = num;
				num += array[i] * num3;
				array[i] = num4;
			}
			num2 = num7;
			if (this.PrintPos <= 0)
			{
				empty = this.Main.Rm.GetString("MStepResults") + " (" + now.ToString(Settings.Default.TimeSet) + "):";
				graphics.DrawString(empty, font, Brushes.Black, new RectangleF((float)e.MarginBounds.Left, num2, (float)e.MarginBounds.Width, (float)e.MarginBounds.Bottom - num2));
				num2 += font.GetHeight();
				this.PrintPos = -1;
			}
			num7 = num2;
			num = num5;
			graphics.DrawLine(pen, num5, num2, x, num2);
			for (int i = this.PrintPos; i < this.ResData.Rows.Count; i++)
			{
				if (i == -1)
				{
					for (int j = 0; j < count; j++)
					{
						string headerText = this.ResultGrid.Columns[j].HeaderText;
						graphics.DrawString(headerText, font2, Brushes.Black, array[j], num2);
					}
				}
				else
				{
					for (int j = 0; j < count; j++)
					{
						string headerText = this.ResData.Rows[i][this.ColumnName[j]].ToString();
						graphics.DrawString(headerText, font2, Brushes.Black, array[j], num2);
					}
				}
				num2 += font2.GetHeight();
				graphics.DrawLine(pen, num5, num2, x, num2);
				if (num2 > num6)
				{
					if (this.ResData.Rows.Count - i > 1)
					{
						this.PrintPos = i + 1;
					}
					break;
				}
				this.PrintPos = 0;
			}
			graphics.DrawLine(pen, num, num7, num, num2);
			for (int i = 0; i <= count; i++)
			{
				graphics.DrawLine(pen, array[i], num7, array[i], num2);
			}
			empty = "\n" + this.Main.Rm.GetString("MachineCounter") + ": " + this.Main.VC.CycleCount.Machine.ToString() + "\n";
			font2.Dispose();
			font.Dispose();
			if (this.PrintPos > 0)
			{
				e.HasMorePages = true;
			}
		}

		public void SetUpdateEnable()
		{
			this.UpdateEnable = true;
		}

		public void UpdateTable()
		{
			if (!this.Hold)
			{
				this.Main.StatusBarText(this.Main.Rm.GetString("WriteStepResults"));
				this.FillTable();
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StepResExport()
		{
			string empty = string.Empty;
			string empty2 = string.Empty;
			string empty3 = string.Empty;
			string empty4 = string.Empty;
			try
			{
				StreamWriter streamWriter = new StreamWriter(this.SFD.FileName, true);
				DateTime dateTime;
				try
				{
					dateTime = new DateTime(this.Main.VC.Result.Time.Year, this.Main.VC.Result.Time.Month, this.Main.VC.Result.Time.Day, this.Main.VC.Result.Time.Hour, this.Main.VC.Result.Time.Minute, this.Main.VC.Result.Time.Second);
				}
				catch
				{
					dateTime = new DateTime(1, 1, 1, 0, 0, 0);
				}
				empty = ((this.Main.VC.Result.IONIO != 1) ? (this.Main.Rm.GetString("NOK") + ": " + this.Main.Rm.GetString("NIO" + this.Main.VC.Result.IONIO.ToString()) + "(" + this.Main.Rm.GetString("Step") + " " + (this.Main.VC.Result.LastStep + 1).ToString() + ")") : this.Main.Rm.GetString("OK"));
				empty2 = this.Main.Rm.GetString("Program") + " " + this.Main.VC.Result.Prog.Info.ProgNum.ToString() + ": " + this.Main.CommonFunctions.UShortToString(this.Main.VC.Result.Prog.Info.Name) + "   " + empty + "   " + this.Main.Rm.GetString("Cycle") + ": " + this.Main.VC.Result.Cycle + "   " + this.Main.Rm.GetString("Time") + ": " + dateTime.ToString(Settings.Default.TimeSet) + "   " + this.Main.Rm.GetString("LastDoneStep") + ": " + (this.Main.VC.Result.LastStep + 1).ToString() + ":";
				streamWriter.WriteLine(empty2);
				empty2 = this.ResultGrid.Columns[0].HeaderText;
				for (int i = 1; i < this.ColumnName.GetLength(0); i++)
				{
					empty2 = empty2 + ";" + this.ResultGrid.Columns[i].HeaderText;
				}
				streamWriter.WriteLine(empty2);
				for (int j = 0; j < 250; j++)
				{
					switch (this.Main.VC.Result.StepResult[j].IONIO)
					{
					case 1:
						empty = this.Main.Rm.GetString("OK");
						goto IL_0471;
					default:
						empty = this.Main.Rm.GetString("NOK") + ": " + this.Main.Rm.GetString("NIO" + this.Main.VC.Result.StepResult[j].IONIO.ToString());
						goto IL_0471;
					case 0:
						break;
						IL_0471:
						empty2 = (this.Main.VC.Result.StepResult[j].Step + 1).ToString();
						empty2 = empty2 + ";" + empty;
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + (this.Main.VC.Result.StepResult[j].Torque * this.Main.TorqueConvert).ToString("f" + 2.ToString())) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + (this.Main.VC.Result.StepResult[j].MaxTorque * this.Main.TorqueConvert).ToString("f" + 2.ToString())) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + (this.Main.VC.Result.StepResult[j].FTorque * this.Main.TorqueConvert).ToString("f" + 2.ToString())) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + (this.Main.VC.Result.StepResult[j].Gradient * this.Main.TorqueConvert).ToString("f" + 4.ToString())) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + this.Main.VC.Result.StepResult[j].Angle.ToString("f" + 1.ToString())) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + this.Main.VC.Result.StepResult[j].Time.ToString("f" + 2.ToString())) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + this.Main.VC.Result.StepResult[j].ADepth.ToString("f" + 1.ToString())) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						switch (this.Main.VC.Result.StepResult[j].Dig)
						{
						case 0:
							empty3 = this.Main.Rm.GetString("Off");
							empty4 = this.Main.Rm.GetString("Off");
							break;
						case 1:
							empty3 = this.Main.Rm.GetString("On");
							empty4 = this.Main.Rm.GetString("Off");
							break;
						case 2:
							empty3 = this.Main.Rm.GetString("Off");
							empty4 = this.Main.Rm.GetString("On");
							break;
						case 3:
							empty3 = this.Main.Rm.GetString("On");
							empty4 = this.Main.Rm.GetString("On");
							break;
						default:
							MessageBox.Show("Wrong dig signal type in FillTable() of StepResult", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							empty3 = this.Main.Rm.GetString("Err");
							empty4 = this.Main.Rm.GetString("Err");
							break;
						}
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + empty3) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + empty4) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + this.Main.VC.Result.StepResult[j].ADepthGrad.ToString("f" + 4.ToString())) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + (this.Main.VC.Result.StepResult[j].DelayTorque * this.Main.TorqueConvert).ToString("f" + 2.ToString())) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + this.Main.VC.Result.StepResult[j].M360Follow.ToString("f" + 2.ToString())) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						empty2 = ((this.Main.VC.Result.StepResult[j].OrgStep == 0) ? (empty2 + ";" + this.Main.VC.Result.StepResult[j].Ana.ToString("f" + 2.ToString())) : (empty2 + ";" + this.Main.Rm.GetString("NotValid")));
						streamWriter.WriteLine(empty2);
						break;
					}
				}
				streamWriter.WriteLine(string.Empty);
				streamWriter.Close();
				streamWriter.Dispose();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Could not open file! " + ex.Message, "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.SaveNum = 0;
			}
		}

		private void btHold_Click(object sender, EventArgs e)
		{
			this.Hold = true;
			this.btHold.Enabled = false;
			this.btActualize.Enabled = true;
		}

		private void btActualize_Click(object sender, EventArgs e)
		{
			this.Hold = false;
			this.btHold.Enabled = true;
			this.btActualize.Enabled = false;
			this.timerUpdate.Enabled = true;
		}

		private void timerUpdate_Tick(object sender, EventArgs e)
		{
			if (this.UpdateEnable)
			{
				this.UpdateEnable = false;
				this.UpdateTable();
				if (this.SaveNum > 0)
				{
					this.StepResExport();
					this.SaveNum--;
				}
			}
			if (this.SaveNum > 0)
			{
				this.btStartExport.Enabled = false;
				this.btStopExport.Enabled = true;
				this.btStartExport.Visible = false;
				this.btStopExport.Visible = true;
			}
			else
			{
				this.btStartExport.Enabled = true;
				this.btStopExport.Enabled = false;
				this.btStartExport.Visible = true;
				this.btStopExport.Visible = false;
				if (this.Hold)
				{
					this.timerUpdate.Enabled = false;
				}
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.Hold = true;
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_2_2_Stufenergebnisse";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_2_2_Stufenergebnisse");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void StepResultForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void btStartExport_Click(object sender, EventArgs e)
		{
			if (this.SaveNum <= 0)
			{
				this.btStartExport.Visible = false;
				this.btStopExport.Visible = true;
				DialogResult dialogResult = this.SFD.ShowDialog();
				if (dialogResult == DialogResult.OK)
				{
					this.SaveNum = 50;
					this.timerUpdate.Enabled = true;
				}
			}
		}

		private void btStopExport_Click(object sender, EventArgs e)
		{
			this.SaveNum = 0;
			this.btStartExport.Visible = true;
			this.btStopExport.Visible = false;
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void btLast5NIO_Click(object sender, EventArgs e)
		{
			this.btBack_Click(null, EventArgs.Empty);
			this.pnMenu.Enabled = false;
			if (!this.Main.LastNIOResults1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void btLastResults_Click(object sender, EventArgs e)
		{
			this.btBack_Click(null, EventArgs.Empty);
			this.pnMenu.Enabled = false;
			if (!this.Main.StatisticsLastRes1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}
	}
}
