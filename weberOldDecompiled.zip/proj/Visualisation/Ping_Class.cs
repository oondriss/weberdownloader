using System;
using System.Deployment.Application;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;

namespace Visualisation
{
	public class Ping_Class
	{
		private string controlerIpAddress;

		public Ping_Class()
		{
			try
			{
				string uriString = ApplicationDeployment.CurrentDeployment.ActivationUri.ToString();
				Uri uri = new Uri(uriString);
				this.controlerIpAddress = uri.Authority;
			}
			catch (Exception)
			{
			}
		}

		public bool DoPingController()
		{
			if (this.controlerIpAddress != null && this.controlerIpAddress.Length != 0)
			{
				try
				{
					Ping ping = new Ping();
					PingOptions pingOptions = new PingOptions();
					pingOptions.DontFragment = true;
					string s = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
					byte[] bytes = Encoding.ASCII.GetBytes(s);
					int timeout = 500;
					PingReply pingReply = ping.Send(this.controlerIpAddress, timeout, bytes, pingOptions);
					if (pingReply.Status == IPStatus.Success)
					{
						return true;
					}
					return false;
				}
				catch (Exception)
				{
					return false;
				}
			}
			return false;
		}

		public bool DoCheckSocketController()
		{
			if (this.controlerIpAddress != null && this.controlerIpAddress.Length != 0)
			{
				Socket socket = null;
				bool flag = true;
				try
				{
					IPAddress iPAddress = null;
					iPAddress = IPAddress.Parse(this.controlerIpAddress);
					new IPEndPoint(iPAddress, 23);
					socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
					IAsyncResult asyncResult = socket.BeginConnect(this.controlerIpAddress, 23, null, null);
					flag = asyncResult.AsyncWaitHandle.WaitOne(1000, true);
					socket.Close();
					return flag;
				}
				catch (Exception)
				{
					return false;
				}
			}
			return false;
		}
	}
}
