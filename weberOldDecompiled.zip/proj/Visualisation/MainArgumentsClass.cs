using System;
using System.Collections;
using System.Deployment.Application;
using System.Web;
using System.Windows.Forms;

namespace Visualisation
{
	internal class MainArgumentsClass
	{
		public static string[] GetParameters()
		{
			new Hashtable();
			string[] array = null;
			try
			{
				array = MainArgumentsClass.GetQueryStringParameters();
			}
			catch (Exception)
			{
			}
			if (array != null)
			{
				MainArgumentsClass._decodeParams(array);
			}
			return array;
		}

		private static string[] GetQueryStringParameters()
		{
			string text = string.Empty;
			if (ApplicationDeployment.IsNetworkDeployed)
			{
				if (ApplicationDeployment.CurrentDeployment.ActivationUri != (Uri)null)
				{
					text = HttpUtility.UrlDecode(ApplicationDeployment.CurrentDeployment.ActivationUri.Query);
				}
			}
			else
			{
				string[] commandLineArgs = Environment.GetCommandLineArgs();
				if (commandLineArgs.Length > 1)
				{
					text = HttpUtility.UrlDecode(commandLineArgs[1]);
				}
			}
			string[] array = null;
			if (!string.IsNullOrWhiteSpace(text) && text.StartsWith("?"))
			{
				array = text.Substring(1).Split('&');
			}
			if (!string.IsNullOrWhiteSpace(text) && (array == null || array.Length == 0))
			{
				throw new Exception($"exception while decoding params: \"{text}\" ");
			}
			return array;
		}

		private static Hashtable _decodeParams(string[] pParams)
		{
			if (pParams == null)
			{
				return null;
			}
			Hashtable hashtable = new Hashtable(pParams.Length);
			try
			{
				foreach (string text in pParams)
				{
					string[] array = text.Split('=');
					if (array.Length > 1)
					{
						hashtable.Add(array[0], array[1]);
					}
				}
				return hashtable;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "MainArgumentsClass._decodeParams");
				return hashtable;
			}
		}
	}
}
