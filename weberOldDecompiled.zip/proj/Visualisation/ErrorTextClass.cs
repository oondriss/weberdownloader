using Visualisation.Properties;

namespace Visualisation
{
	public class ErrorTextClass
	{
		public int Id;

		public string German = "";

		public string English = "";

		public string French = "";

		public string Italian = "";

		public string Spanish = "";

		public string Portuguese = "";

		public string Romanian = "";

		public string Polish = "";

		public string Czech = "";

		public string Hungarian = "";

		public string Slowak = "";

		public string Chinese = "";

		public string TextOf()
		{
			switch (Settings.Default.Language)
			{
			case 0:
				return this.English;
			case 1:
				return this.German;
			case 2:
				return this.French;
			case 3:
				return this.Italian;
			case 4:
				return this.Spanish;
			case 5:
				return this.Czech;
			case 6:
				return this.Slowak;
			case 7:
				return this.Hungarian;
			default:
				return "";
			}
		}
	}
}
