using System;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class FourStepClass
	{
		public WSP1_VarComm.FourProgStruct _4Prog;

		public bool Read(string path, ref WSP1_VarComm.FourProgStruct data)
		{
			bool result = true;
			FileStream fileStream = null;
			try
			{
				XmlSerializer xmlSerializer = new XmlSerializer(typeof(WSP1_VarComm.FourProgStruct));
				fileStream = new FileStream(path, FileMode.Open);
				data = (WSP1_VarComm.FourProgStruct)xmlSerializer.Deserialize(fileStream);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + "\n   " + path, "");
			}
			if (fileStream != null)
			{
				fileStream.Close();
				fileStream.Dispose();
			}
			return result;
		}

		public bool Write(string path, WSP1_VarComm.FourProgStruct data)
		{
			bool flag = false;
			StreamWriter streamWriter = null;
			try
			{
				XmlSerializer xmlSerializer = new XmlSerializer(typeof(WSP1_VarComm.FourProgStruct));
				streamWriter = new StreamWriter(path);
				xmlSerializer.Serialize(streamWriter, data);
				flag = true;
			}
			catch (Exception)
			{
				flag = false;
			}
			if (streamWriter != null)
			{
				streamWriter.Close();
				streamWriter.Dispose();
			}
			return flag;
		}
	}
}
