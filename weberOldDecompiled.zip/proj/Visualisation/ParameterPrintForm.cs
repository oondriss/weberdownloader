using System;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class ParameterPrintForm : Form
	{
		private MainForm Main;

		private Button btPrint;

		private CheckBox chBSysConst;

		private CheckBox chBSpConst;

		private GroupBox gBGeneral;

		private Button btCancel;

		private CheckBox chBPrograms;

		private ComboBox cBProgramms;

		private Container components;

		public ParameterPrintForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.btPrint = new Button();
			this.chBSysConst = new CheckBox();
			this.chBSpConst = new CheckBox();
			this.gBGeneral = new GroupBox();
			this.cBProgramms = new ComboBox();
			this.chBPrograms = new CheckBox();
			this.btCancel = new Button();
			this.gBGeneral.SuspendLayout();
			base.SuspendLayout();
			this.btPrint.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btPrint.Location = new Point(123, 213);
			this.btPrint.Name = "btPrint";
			this.btPrint.Size = new Size(96, 72);
			this.btPrint.TabIndex = 0;
			this.btPrint.Text = "Drucken";
			this.btPrint.Click += this.btPrint_Click;
			this.chBSysConst.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBSysConst.Location = new Point(16, 24);
			this.chBSysConst.Name = "chBSysConst";
			this.chBSysConst.Size = new Size(168, 24);
			this.chBSysConst.TabIndex = 1;
			this.chBSysConst.Text = "Systemkonstanten";
			this.chBSpConst.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBSpConst.Location = new Point(16, 54);
			this.chBSpConst.Name = "chBSpConst";
			this.chBSpConst.Size = new Size(168, 24);
			this.chBSpConst.TabIndex = 2;
			this.chBSpConst.Text = "Spindelkonstanten";
			this.gBGeneral.Controls.Add(this.cBProgramms);
			this.gBGeneral.Controls.Add(this.chBPrograms);
			this.gBGeneral.Controls.Add(this.chBSysConst);
			this.gBGeneral.Controls.Add(this.chBSpConst);
			this.gBGeneral.Location = new Point(8, 8);
			this.gBGeneral.Name = "gBGeneral";
			this.gBGeneral.Size = new Size(211, 188);
			this.gBGeneral.TabIndex = 4;
			this.gBGeneral.TabStop = false;
			this.cBProgramms.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBProgramms.FormattingEnabled = true;
			this.cBProgramms.Location = new Point(16, 114);
			this.cBProgramms.Name = "cBProgramms";
			this.cBProgramms.Size = new Size(168, 24);
			this.cBProgramms.TabIndex = 4;
			this.chBPrograms.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBPrograms.Location = new Point(16, 84);
			this.chBPrograms.Name = "chBPrograms";
			this.chBPrograms.Size = new Size(168, 24);
			this.chBPrograms.TabIndex = 3;
			this.chBPrograms.Text = "Schraubprogramme";
			this.chBPrograms.CheckedChanged += this.chBPrograms_CheckedChanged;
			this.btCancel.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCancel.Location = new Point(8, 213);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(96, 72);
			this.btCancel.TabIndex = 6;
			this.btCancel.Text = "Abbrechen";
			this.btCancel.Click += this.btCancel_Click;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(227, 297);
			base.ControlBox = false;
			base.Controls.Add(this.btCancel);
			base.Controls.Add(this.gBGeneral);
			base.Controls.Add(this.btPrint);
			this.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "ParameterPrintForm";
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "Druckauswahl";
			base.Shown += this.ParameterPrintForm_Shown;
			this.gBGeneral.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public void Cancel()
		{
			if (base.Visible)
			{
				base.Close();
			}
		}

		public void ShowWindow()
		{
			if (this.Main.IsOnlineMode)
			{
				this.chBSysConst.Checked = true;
				this.chBSysConst.Enabled = true;
			}
			else
			{
				this.chBSysConst.Enabled = false;
				this.chBSysConst.Checked = false;
			}
			this.chBSpConst.Checked = true;
			this.chBPrograms.Checked = true;
			base.ShowDialog();
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MPrintSelection");
			this.btCancel.Text = this.Main.Rm.GetString("Cancel");
			this.btPrint.Text = this.Main.Rm.GetString("Print");
			this.chBSpConst.Text = this.Main.Rm.GetString("MSpindleConstants");
			this.chBSysConst.Text = this.Main.Rm.GetString("MSystemConstants");
			this.chBPrograms.Text = this.Main.Rm.GetString("Programs");
		}

		private void btPrint_Click(object sender, EventArgs e)
		{
			this.PreparePrint(0u);
			this.Main.SimplePrint.DocName = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) + "_" + this.Main.Rm.GetString("MenuParameter");
			this.Main.SimplePrint.Print();
			base.Close();
		}

		public void PreparePrint(uint pnum)
		{
			DateTime dateTime = DateTime.Now;
			if (this.chBSysConst.Checked)
			{
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.SetStyleBold();
				this.Main.SimplePrint.SetSizeXL();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("MSystemConstants") + " (" + dateTime.ToString("dd'.'MM'.'yyyy HH':'mm':'ss") + "):");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("gBDateTime") + ":");
				this.Main.SimplePrint.SetNewLine();
				try
				{
					dateTime = new DateTime(this.Main.VC.SysConst.ActualTime.Year, this.Main.VC.SysConst.ActualTime.Month, this.Main.VC.SysConst.ActualTime.Day, this.Main.VC.SysConst.ActualTime.Hour, this.Main.VC.SysConst.ActualTime.Minute, this.Main.VC.SysConst.ActualTime.Second);
				}
				catch
				{
					dateTime = new DateTime(1, 1, 1, 0, 0, 0);
				}
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("ControllerTime") + ": " + dateTime.ToString());
				this.Main.SimplePrint.SetNewLine();
				dateTime = DateTime.Now;
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("LocalTime") + ": " + dateTime.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TorqueUnitChoose") + ": " + this.Main.TorqueUnitName);
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("gBIdentity") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("SystemID") + ": " + this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.SystemID));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("IdentServer") + ": " + this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("gBIP") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("IPAddress") + ": " + this.Main.VC.SysConst.IPAddress.Byte1.ToString() + "." + this.Main.VC.SysConst.IPAddress.Byte2.ToString() + "." + this.Main.VC.SysConst.IPAddress.Byte3.ToString() + "." + this.Main.VC.SysConst.IPAddress.Byte4.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("SubnetMask") + ": " + this.Main.VC.SysConst.SubNetMask.Byte1.ToString() + "." + this.Main.VC.SysConst.SubNetMask.Byte2.ToString() + "." + this.Main.VC.SysConst.SubNetMask.Byte3.ToString() + "." + this.Main.VC.SysConst.SubNetMask.Byte4.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DGAddress") + ": " + this.Main.VC.SysConst.DefaultGateway.Byte1.ToString() + "." + this.Main.VC.SysConst.DefaultGateway.Byte2.ToString() + "." + this.Main.VC.SysConst.DefaultGateway.Byte3.ToString() + "." + this.Main.VC.SysConst.DefaultGateway.Byte4.ToString());
				this.Main.SimplePrint.SetNewLine();
				string str = (this.Main.VC.SysConst.DHCP != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes");
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DHCP") + ": " + str);
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("gBRs232") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Baudrate") + ": " + this.Main.VC.SysConst.Com1.BaudRate.ToString());
				this.Main.SimplePrint.SetNewLine();
				switch (this.Main.VC.SysConst.Com1.Parity)
				{
				case 0:
					str = this.Main.Rm.GetString("None");
					break;
				case 1:
					str = this.Main.Rm.GetString("Odd");
					break;
				case 2:
					str = this.Main.Rm.GetString("Even");
					break;
				default:
					str = "Internal Error";
					break;
				}
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Parity") + ": " + str);
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("VersionInfo") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("VersionController") + ": " + this.Main.CommonFunctions.UShortToString(this.Main.VC.Status0.Version));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("VersionVisu") + ": " + Assembly.GetExecutingAssembly().GetName().Version.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetNewPage();
			}
			if (this.chBSpConst.Checked)
			{
				this.Main.SimplePrint.SetTab(0);
				this.Main.SimplePrint.SetStyleBold();
				this.Main.SimplePrint.SetSizeXL();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("MSpindleConstants") + " (" + dateTime.ToString("dd'.'MM'.'yyyy HH':'mm':'ss") + "):");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AngleTorqueSensor") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TorqueSensorScale") + ": " + this.Main.VC.SpConst.TorqueSensorScale.ToString() + this.Main.Rm.GetString("TorqueNm"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TorqueSensorTolerance") + ": " + this.Main.VC.SpConst.TorqueSensorTolerance.ToString() + this.Main.Rm.GetString("Percent"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AngleSensorScale") + ": " + this.Main.VC.SpConst.AngleSensorScale.ToString() + this.Main.Rm.GetString("Degree") + "/" + this.Main.Rm.GetString("Increment"));
				this.Main.SimplePrint.SetNewLine();
				string str = (this.Main.VC.SpConst.TorqueSensorInvers != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes");
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TorqueSensorInvers") + ": " + str);
				this.Main.SimplePrint.SetNewLine();
				str = ((this.Main.VC.SpConst.AngleSensorInvers != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AngleSensorInvers") + ": " + str);
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("gBRedundantSensor") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				str = ((this.Main.VC.SpConst.RedundantSensorActive != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("RedundantSensorActive") + ": " + str);
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TorqueRedundantTime") + ": " + this.Main.VC.SpConst.TorqueRedundantTime.ToString() + this.Main.Rm.GetString("Second"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TorqueRedundantTolerance") + ": " + this.Main.VC.SpConst.TorqueRedundantTolerance.ToString() + this.Main.Rm.GetString("Percent"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AngleRedundantTolerance") + ": " + this.Main.VC.SpConst.AngleRedundantTolerance.ToString() + this.Main.Rm.GetString("Increment"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DepthSensor") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AnaSigScale") + ": " + this.Main.VC.SpConst.DepthSensorScale.ToString() + this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Voltage"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AnaSigOffset") + ": " + this.Main.VC.SpConst.DepthSensorOffset.ToString() + this.Main.Rm.GetString("Milimeter"));
				this.Main.SimplePrint.SetNewLine();
				str = ((this.Main.VC.SpConst.DepthSensorInvers != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DepthSensorInvers") + ": " + str);
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("OffsetVoltageMin") + ": " + this.Main.VC.SpConst.DepthSensorOffsetMin.ToString() + this.Main.Rm.GetString("Voltage"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("OffsetVoltageMax") + ": " + this.Main.VC.SpConst.DepthSensorOffsetMax.ToString() + this.Main.Rm.GetString("Voltage"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("OffsetTeachValue") + ": " + this.Main.VC.SpConst.DepthSensorOffsetPreset.ToString() + this.Main.Rm.GetString("Milimeter"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DriveUnit") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("MaxRpm") + ": " + this.Main.VC.SpConst.DriveUnitRpm.ToString() + this.Main.Rm.GetString("RpmUnit"));
				this.Main.SimplePrint.SetNewLine();
				str = ((this.Main.VC.SpConst.DriveUnitInvers != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DriveUnitInvers") + ": " + str);
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("gBPressure") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("CylinderPressureScale6") + ": " + (this.Main.VC.SpConst.PressureScaleSpindle * 6f).ToString() + this.Main.Rm.GetString("KiloNewton"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("HolderPressureScale") + ": " + this.Main.VC.SpConst.PressureScaleHolder.ToString() + " 1/" + this.Main.Rm.GetString("Voltage"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("gBSpindle") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("SpindleTorque") + ": " + this.Main.VC.SpConst.SpindleTorque.ToString() + this.Main.Rm.GetString("TorqueNm"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("GearFactor") + ": " + this.Main.VC.SpConst.SpindleGearFactor.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("ReleaseSpeed") + ": " + this.Main.VC.SpConst.ReleaseSpeed.ToString() + this.Main.Rm.GetString("RpmUnit"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("FrictionTest") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("MaxFrictionTorque") + ": " + this.Main.VC.SpConst.FrictionTorque.ToString() + this.Main.Rm.GetString("Percent"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("FrictionSpeed") + ": " + this.Main.VC.SpConst.FrictionSpeed.ToString() + this.Main.Rm.GetString("Percent"));
				this.Main.SimplePrint.SetNewLine();
				str = ((this.Main.VC.SpConst.FrictionTestStartup != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("FrictionTestStartup") + ": " + str);
				this.Main.SimplePrint.SetNewLine();
				str = ((this.Main.VC.SpConst.FrictionTestEMG != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("FrictionTestEMG") + ": " + str);
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("gBAnaSignal") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AnaSigScale") + ": " + this.Main.VC.SpConst.AnaSigScale.ToString() + " 1/" + this.Main.Rm.GetString("Voltage"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AnaSigOffset") + ": " + this.Main.VC.SpConst.AnaSigOffset.ToString() + this.Main.Rm.GetString("Voltage"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetSizeLarge();
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("gBJawOpenAutomatic") + ":");
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.ResetStyle();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("lbJawOpenDistance") + ": " + this.Main.VC.SpConst.JawOpenDistance.ToString() + this.Main.Rm.GetString("Milimeter"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("lbJawOpenDepthGradMax") + ": " + this.Main.VC.SpConst.JawOpenDepthGradMax.ToString() + this.Main.Rm.GetString("MillimeterPerSec"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("lbJawOpenDepthGradMin") + ": " + this.Main.VC.SpConst.JawOpenDepthGradMin.ToString() + this.Main.Rm.GetString("MillimeterPerSec"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetNewPage();
			}
			if (this.chBPrograms.Checked)
			{
				string text = this.cBProgramms.SelectedItem.ToString();
				if (text == this.Main.Rm.GetString("All"))
				{
					pnum = 0u;
				}
				else
				{
					string[] separator = new string[1]
					{
						": "
					};
					string[] array = text.Split(separator, 2, StringSplitOptions.None);
					if (array.Length > 1)
					{
						text = array[1];
					}
					uint num = 1u;
					while (num < 1024)
					{
						if (this.Main.VC.PProg.Num[num].Info.Steps < 1 || !(text == this.Main.CommonFunctions.UShortToString(this.Main.VC.PProg.Num[num].Info.Name)))
						{
							num++;
							continue;
						}
						pnum = num;
						break;
					}
				}
				if (pnum == 0)
				{
					for (uint num2 = 1u; num2 < 1024; num2++)
					{
						if (this.Main.VC.PProg.Num[num2].Info.Steps >= 1)
						{
							this.GetPrintProgData(num2, false);
						}
					}
				}
				else if (this.Main.VC.PProg.Num[pnum].Info.Steps >= 1)
				{
					this.GetPrintProgData(pnum, false);
				}
			}
		}

		public void PrepareResultParamPrint()
		{
			this.GetPrintProgData(0u, true);
		}

		private void GetPrintProgData(uint spNum, bool isResult)
		{
			string empty = string.Empty;
			DateTime now = DateTime.Now;
			WSP1_VarComm.ProgStruct progStruct = isResult ? this.Main.VC.Result.Prog : this.Main.VC.PProg.Num[spNum];
			this.Main.SimplePrint.SetStyleBold();
			this.Main.SimplePrint.SetSizeXL();
			this.Main.SimplePrint.SetLeft();
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Program") + " " + progStruct.Info.ProgNum.ToString() + ": " + this.Main.CommonFunctions.UShortToString(progStruct.Info.Name) + " (" + now.ToString("dd'.'MM'.'yyyy HH':'mm':'ss") + ")");
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.ResetStyle();
			int num = progStruct.Info.ResultParam1;
			string value;
			switch (num)
			{
			case 1:
				value = this.Main.Rm.GetString("Torque");
				break;
			case 2:
				value = this.Main.Rm.GetString("MaxTorque");
				break;
			case 3:
				value = this.Main.Rm.GetString("FilteredTorque");
				break;
			case 4:
				value = this.Main.Rm.GetString("Gradient");
				break;
			case 5:
				value = this.Main.Rm.GetString("Angle");
				break;
			case 6:
				value = this.Main.Rm.GetString("Time");
				break;
			case 7:
				value = this.Main.Rm.GetString("AnaDepth");
				break;
			case 9:
				value = this.Main.Rm.GetString("DigitalSignal");
				break;
			case 12:
				value = this.Main.Rm.GetString("DepthGrad");
				break;
			case 10:
				value = this.Main.Rm.GetString("DelayTorque");
				break;
			case 11:
				value = this.Main.Rm.GetString("M360Follow");
				break;
			case 8:
				value = this.Main.Rm.GetString("AnaSignal");
				break;
			default:
				value = "Internal Error";
				break;
			}
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Result") + " 1: ");
			this.Main.SimplePrint.SetTab(2);
			this.Main.SimplePrint.Sb.Append(value);
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.SetLeft();
			switch (progStruct.Info.ResultParam2)
			{
			case 1:
				value = this.Main.Rm.GetString("Torque");
				break;
			case 2:
				value = this.Main.Rm.GetString("MaxTorque");
				break;
			case 3:
				value = this.Main.Rm.GetString("FilteredTorque");
				break;
			case 4:
				value = this.Main.Rm.GetString("Gradient");
				break;
			case 5:
				value = this.Main.Rm.GetString("Angle");
				break;
			case 6:
				value = this.Main.Rm.GetString("Time");
				break;
			case 7:
				value = this.Main.Rm.GetString("AnaDepth");
				break;
			case 9:
				value = this.Main.Rm.GetString("DigitalSignal");
				break;
			case 12:
				value = this.Main.Rm.GetString("DepthGrad");
				break;
			case 10:
				value = this.Main.Rm.GetString("DelayTorque");
				break;
			case 11:
				value = this.Main.Rm.GetString("M360Follow");
				break;
			case 8:
				value = this.Main.Rm.GetString("AnaSignal");
				break;
			default:
				value = "Internal Error";
				break;
			}
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Result") + " 2: ");
			this.Main.SimplePrint.SetTab(2);
			this.Main.SimplePrint.Sb.Append(value);
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.SetLeft();
			switch (progStruct.Info.ResultParam3)
			{
			case 1:
				value = this.Main.Rm.GetString("Torque");
				break;
			case 2:
				value = this.Main.Rm.GetString("MaxTorque");
				break;
			case 3:
				value = this.Main.Rm.GetString("FilteredTorque");
				break;
			case 4:
				value = this.Main.Rm.GetString("Gradient");
				break;
			case 5:
				value = this.Main.Rm.GetString("Angle");
				break;
			case 6:
				value = this.Main.Rm.GetString("Time");
				break;
			case 7:
				value = this.Main.Rm.GetString("AnaDepth");
				break;
			case 9:
				value = this.Main.Rm.GetString("DigitalSignal");
				break;
			case 12:
				value = this.Main.Rm.GetString("DepthGrad");
				break;
			case 10:
				value = this.Main.Rm.GetString("DelayTorque");
				break;
			case 11:
				value = this.Main.Rm.GetString("M360Follow");
				break;
			case 8:
				value = this.Main.Rm.GetString("AnaSignal");
				break;
			default:
				value = "Internal Error";
				break;
			}
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Result") + " 3: ");
			this.Main.SimplePrint.SetTab(2);
			this.Main.SimplePrint.Sb.Append(value);
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.SetLeft();
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("MaxScrewTime") + ": " + progStruct.MaxTime.ToString() + this.Main.Rm.GetString("Second"));
			this.Main.SimplePrint.SetNewLine();
			if (progStruct.UseLocalJawSettings != 0)
			{
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("lbJawOpenDistance") + ": " + progStruct.MaxTime.ToString() + this.Main.Rm.GetString("Milimeter"));
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("lbJawOpenDepthGradMin") + ": " + progStruct.MaxTime.ToString() + this.Main.Rm.GetString("MillimeterPerSec"));
				this.Main.SimplePrint.SetNewLine();
			}
			this.Main.SimplePrint.SetLeft();
			this.Main.SimplePrint.SetSizeLarge();
			this.Main.SimplePrint.SetStyleBold();
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("MOptPrgParam") + ":");
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.SetTab(1);
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Torque") + ":");
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.ResetStyle();
			this.Main.SimplePrint.SetTab(2);
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("M1FilterTime") + ": " + progStruct.M1FilterTime.ToString() + this.Main.Rm.GetString("Milisecond"));
			this.Main.SimplePrint.SetTab(7);
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("GradientLength") + ": " + progStruct.GradientLength.ToString() + this.Main.Rm.GetString("Increment"));
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.SetTab(2);
			value = ((progStruct.GradientFilter != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("GradFilter") + ": " + value);
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.SetTab(1);
			this.Main.SimplePrint.SetSizeLarge();
			this.Main.SimplePrint.SetStyleBold();
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AnaDepth") + ":");
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.ResetStyle();
			this.Main.SimplePrint.SetTab(2);
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DepthFilterTime") + ": " + progStruct.ADepthFilterTime.ToString() + this.Main.Rm.GetString("Milisecond"));
			this.Main.SimplePrint.SetTab(7);
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DepthGradLength") + ": " + progStruct.ADepthGradientLength.ToString() + this.Main.Rm.GetString("Milisecond"));
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.SetTab(1);
			this.Main.SimplePrint.SetSizeLarge();
			this.Main.SimplePrint.SetStyleBold();
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Holder") + ":");
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.ResetStyle();
			this.Main.SimplePrint.SetTab(2);
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("PressureCylinder") + ": " + progStruct.PressureHolder.ToString() + this.Main.Rm.GetString("KiloNewton"));
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.SetTab(1);
			this.Main.SimplePrint.SetSizeLarge();
			this.Main.SimplePrint.SetStyleBold();
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("ForceSignals") + ":");
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.ResetStyle();
			if (progStruct.EndSetDigOut1 == 1)
			{
				value = "(" + this.Main.Rm.GetString("Yes") + "): ";
				value = ((progStruct.EndValueDigOut1 != 1) ? (value + this.Main.Rm.GetString("SetOff")) : (value + this.Main.Rm.GetString("SetOn")));
			}
			else
			{
				value = "(" + this.Main.Rm.GetString("No") + ")";
			}
			this.Main.SimplePrint.SetTab(2);
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigitalSignal") + "1" + value);
			if (progStruct.EndSetDigOut2 == 1)
			{
				value = "(" + this.Main.Rm.GetString("Yes") + "): ";
				value = ((progStruct.EndValueDigOut2 != 1) ? (value + this.Main.Rm.GetString("SetOff")) : (value + this.Main.Rm.GetString("SetOn")));
			}
			else
			{
				value = "(" + this.Main.Rm.GetString("No") + ")";
			}
			this.Main.SimplePrint.SetTab(7);
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigitalSignal") + "2" + value);
			this.Main.SimplePrint.SetNewLine();
			if (progStruct.EndSetSync1 == 1)
			{
				value = "(" + this.Main.Rm.GetString("Yes") + "): ";
				value = ((progStruct.EndValueSync1 != 1) ? (value + this.Main.Rm.GetString("SetOff")) : (value + this.Main.Rm.GetString("SetOn")));
			}
			else
			{
				value = "(" + this.Main.Rm.GetString("No") + ")";
			}
			this.Main.SimplePrint.SetTab(2);
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("JawOpen") + value);
			if (progStruct.EndSetSync2 == 1)
			{
				value = "(" + this.Main.Rm.GetString("Yes") + "): ";
				value = ((progStruct.EndValueSync2 != 1) ? (value + this.Main.Rm.GetString("SetOff")) : (value + this.Main.Rm.GetString("SetOn")));
			}
			else
			{
				value = "(" + this.Main.Rm.GetString("No") + ")";
			}
			this.Main.SimplePrint.SetTab(7);
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("SyncSignal") + "2" + value);
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.SetLeft();
			for (int i = 0; i < progStruct.Info.Steps; i++)
			{
				float num2;
				switch (progStruct.Step[i].Type)
				{
				case 2:
					switch (progStruct.Step[i].Switch)
					{
					case 1:
						value = this.Main.Rm.GetString("Torque");
						break;
					case 3:
						value = this.Main.Rm.GetString("FilteredTorque");
						break;
					case 2:
						value = this.Main.Rm.GetString("RelativeTorque");
						break;
					case 11:
						value = this.Main.Rm.GetString("M360Follow");
						break;
					case 4:
						value = this.Main.Rm.GetString("Gradient");
						break;
					case 5:
						value = this.Main.Rm.GetString("Angle");
						break;
					case 6:
						value = this.Main.Rm.GetString("Time");
						break;
					case 7:
						value = this.Main.Rm.GetString("AnaDepth");
						break;
					case 10:
						value = this.Main.Rm.GetString("DepthGrad");
						break;
					case 8:
						value = this.Main.Rm.GetString("AnaSignal");
						break;
					case 9:
						value = this.Main.Rm.GetString("DigitalSignal");
						break;
					case 50:
						value = this.Main.Rm.GetString("Torque") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
						break;
					case 51:
						value = this.Main.Rm.GetString("FilteredTorque") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
						break;
					case 52:
						value = this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
						break;
					case 53:
						value = this.Main.Rm.GetString("AnaDepth") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
						break;
					case 55:
						value = this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
						break;
					case 54:
						value = this.Main.Rm.GetString("AnaSignal") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
						break;
					default:
						value = "Internal Error";
						break;
					}
					this.Main.SimplePrint.SetLeft();
					this.Main.SimplePrint.SetSizeLarge();
					this.Main.SimplePrint.SetStyleBold();
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Step") + " " + (i + 1).ToString() + ": ");
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DrivingStep") + " (" + value + ")");
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.ResetStyle();
					this.Main.SimplePrint.SetTab(1);
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("RoundsPerMinute") + ": " + progStruct.Step[i].NA.ToString() + this.Main.Rm.GetString("RpmUnit"));
					this.Main.SimplePrint.SetTab(7);
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Ramp") + ": " + progStruct.Step[i].TM.ToString() + this.Main.Rm.GetString("Second"));
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.SetTab(1);
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("PressureCylinder") + ": " + progStruct.Step[i].PressureSpindle.ToString() + this.Main.Rm.GetString("KiloNewton"));
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.SetTab(1);
					switch (progStruct.Step[i].Switch)
					{
					case 1:
					{
						StringBuilder sb21 = this.Main.SimplePrint.Sb;
						string[] array23 = new string[6]
						{
							this.Main.Rm.GetString("Target"),
							" ",
							this.Main.Rm.GetString("Torque"),
							": ",
							null,
							null
						};
						string[] array24 = array23;
						num2 = progStruct.Step[i].MP * this.Main.TorqueConvert;
						array24[4] = num2.ToString("f" + 2.ToString());
						array23[5] = this.Main.TorqueUnitName;
						sb21.Append(string.Concat(array23));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					case 3:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("FilteredTorque") + ": " + (progStruct.Step[i].MFP * this.Main.TorqueConvert).ToString("f" + 2.ToString()) + this.Main.TorqueUnitName);
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						break;
					case 2:
					{
						string text;
						switch (progStruct.Step[i].MRType)
						{
						case 1:
							text = this.Main.Rm.GetString("Torque");
							break;
						case 3:
							text = this.Main.Rm.GetString("FilteredTorque");
							break;
						case 2:
							text = this.Main.Rm.GetString("MaxTorque");
							break;
						case 10:
							text = this.Main.Rm.GetString("DelayTorque");
							break;
						default:
							text = "Internal Error";
							break;
						}
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("RelativeTorque") + ": " + (progStruct.Step[i].MRP * this.Main.TorqueConvert).ToString("f" + 2.ToString()) + this.Main.TorqueUnitName + " " + this.Main.Rm.GetString("relatedTo") + " " + text + "(" + this.Main.Rm.GetString("Step") + " " + (progStruct.Step[i].MRStep + 1).ToString() + ")");
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Torque") + ": ");
						this.Main.SimplePrint.SetTab(4);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("M-") + "): " + (progStruct.Step[i].Mmin * this.Main.TorqueConvert).ToString() + this.Main.TorqueUnitName);
						this.Main.SimplePrint.SetTab(7);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("M+") + "): " + (progStruct.Step[i].Mmax * this.Main.TorqueConvert).ToString() + this.Main.TorqueUnitName);
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					case 11:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("M360Follow") + ": " + (progStruct.Step[i].MRP * this.Main.TorqueConvert).ToString("f" + 2.ToString()) + this.Main.TorqueUnitName);
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Torque") + ": ");
						this.Main.SimplePrint.SetTab(4);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("M-") + "): " + (progStruct.Step[i].Mmin * this.Main.TorqueConvert).ToString() + this.Main.TorqueUnitName);
						this.Main.SimplePrint.SetTab(7);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("M+") + "): " + (progStruct.Step[i].Mmax * this.Main.TorqueConvert).ToString() + this.Main.TorqueUnitName);
						this.Main.SimplePrint.SetNewLine();
						break;
					case 4:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("Gradient") + ": " + (progStruct.Step[i].MGP * this.Main.TorqueConvert).ToString("f" + 4.ToString()) + this.Main.TorqueUnitName + "/" + this.Main.Rm.GetString("Degree"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						break;
					case 5:
					{
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("Angle") + ": " + progStruct.Step[i].WP.ToString() + this.Main.Rm.GetString("Degree"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						string text = (progStruct.Step[i].Enable.Snug != 1) ? (this.Main.Rm.GetString("TreshTorque") + "(" + this.Main.Rm.GetString("No") + ")") : (this.Main.Rm.GetString("TreshTorque") + "(" + this.Main.Rm.GetString("Yes") + "): " + (progStruct.Step[i].MS * this.Main.TorqueConvert).ToString() + this.Main.TorqueUnitName);
						this.Main.SimplePrint.Sb.Append(text);
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					case 6:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("Time") + ": " + progStruct.Step[i].TP.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						break;
					case 7:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("AnaDepth") + ": " + progStruct.Step[i].LP.ToString() + this.Main.Rm.GetString("Milimeter"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						break;
					case 10:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("DepthGrad") + ": " + progStruct.Step[i].LGP.ToString() + this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						break;
					case 8:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("AnaSignal") + ": " + progStruct.Step[i].AnaP.ToString());
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						break;
					case 9:
					{
						string text;
						switch (progStruct.Step[i].DigP)
						{
						case 1:
							text = this.Main.Rm.GetString("TM1") + " (" + this.Main.Rm.GetString("Positive") + ")";
							break;
						case -1:
							text = this.Main.Rm.GetString("TM1") + " (" + this.Main.Rm.GetString("Negative") + ")";
							break;
						case 2:
							text = this.Main.Rm.GetString("TM2") + " (" + this.Main.Rm.GetString("Positive") + ")";
							break;
						case -2:
							text = this.Main.Rm.GetString("TM2") + " (" + this.Main.Rm.GetString("Negative") + ")";
							break;
						case 3:
							text = this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("Positive") + ")";
							break;
						case -3:
							text = this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("Negative") + ")";
							break;
						case 4:
							text = this.Main.Rm.GetString("JawOpen") + " (" + this.Main.Rm.GetString("Positive") + ")";
							break;
						case -4:
							text = this.Main.Rm.GetString("JawOpen") + " (" + this.Main.Rm.GetString("Negative") + ")";
							break;
						case 5:
							text = this.Main.Rm.GetString("SyncSignal") + "2 (" + this.Main.Rm.GetString("Positive") + ")";
							break;
						case -5:
							text = this.Main.Rm.GetString("SyncSignal") + "2 (" + this.Main.Rm.GetString("Negative") + ")";
							break;
						default:
							text = "Internal Error";
							break;
						}
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("DigitalSignal") + ": " + text);
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					case 50:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("Torque") + " (" + this.Main.Rm.GetString("FromAbove") + "): " + (progStruct.Step[i].MP * this.Main.TorqueConvert).ToString("f" + 2.ToString()) + this.Main.TorqueUnitName);
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Torque") + ": ");
						this.Main.SimplePrint.SetTab(4);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("M+") + "): " + (progStruct.Step[i].Mmax * this.Main.TorqueConvert).ToString() + this.Main.TorqueUnitName);
						this.Main.SimplePrint.SetNewLine();
						break;
					case 51:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("FilteredTorque") + " (" + this.Main.Rm.GetString("FromAbove") + "): " + (progStruct.Step[i].MFP * this.Main.TorqueConvert).ToString("f" + 2.ToString()) + this.Main.TorqueUnitName);
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Torque") + ": ");
						this.Main.SimplePrint.SetTab(4);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("M+") + "): " + (progStruct.Step[i].Mmax * this.Main.TorqueConvert).ToString() + this.Main.TorqueUnitName);
						this.Main.SimplePrint.SetNewLine();
						break;
					case 52:
					{
						StringBuilder sb18 = this.Main.SimplePrint.Sb;
						string[] array19 = new string[10]
						{
							this.Main.Rm.GetString("Target"),
							" ",
							this.Main.Rm.GetString("Gradient"),
							" (",
							this.Main.Rm.GetString("FromAbove"),
							"): ",
							null,
							null,
							null,
							null
						};
						string[] array20 = array19;
						num2 = progStruct.Step[i].MGP * this.Main.TorqueConvert;
						num = 4;
						array20[6] = num2.ToString("f" + num.ToString());
						array19[7] = this.Main.TorqueUnitName;
						array19[8] = "/";
						array19[9] = this.Main.Rm.GetString("Degree");
						sb18.Append(string.Concat(array19));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Torque") + ": ");
						this.Main.SimplePrint.SetTab(4);
						StringBuilder sb19 = this.Main.SimplePrint.Sb;
						string[] array = new string[6]
						{
							this.Main.Rm.GetString("Min"),
							"(",
							this.Main.Rm.GetString("M-"),
							"): ",
							null,
							null
						};
						string[] array21 = array;
						num2 = progStruct.Step[i].Mmin * this.Main.TorqueConvert;
						array21[4] = num2.ToString();
						array[5] = this.Main.TorqueUnitName;
						sb19.Append(string.Concat(array));
						this.Main.SimplePrint.SetTab(7);
						StringBuilder sb20 = this.Main.SimplePrint.Sb;
						array = new string[6]
						{
							this.Main.Rm.GetString("Max"),
							"(",
							this.Main.Rm.GetString("M+"),
							"): ",
							null,
							null
						};
						string[] array22 = array;
						num2 = progStruct.Step[i].Mmax * this.Main.TorqueConvert;
						array22[4] = num2.ToString();
						array[5] = this.Main.TorqueUnitName;
						sb20.Append(string.Concat(array));
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					case 53:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("AnaDepth") + " (" + this.Main.Rm.GetString("FromAbove") + "): " + progStruct.Step[i].LP.ToString() + this.Main.Rm.GetString("Milimeter"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						break;
					case 55:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("FromAbove") + "): " + progStruct.Step[i].LGP.ToString() + this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						break;
					case 54:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("AnaSignal") + " (" + this.Main.Rm.GetString("FromAbove") + "): " + progStruct.Step[i].AnaP.ToString());
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						break;
					default:
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.Sb.Append("Internal Error");
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					this.Main.SimplePrint.SetTab(1);
					value = ((progStruct.Step[i].IsResult1 != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Result") + " 1: " + value + "   ");
					value = ((progStruct.Step[i].IsResult2 != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Result") + " 2: " + value + "   ");
					value = ((progStruct.Step[i].IsResult3 != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Result") + " 3: " + value + "   ");
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.SetTab(1);
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("MDelay") + ": " + progStruct.Step[i].MDelayTime.ToString() + this.Main.Rm.GetString("Milisecond"));
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.SetTab(1);
					value = (((progStruct.Step[i].UserRights & 1) != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TargetRight") + ": " + value + "   ");
					value = (((progStruct.Step[i].UserRights & 2) != 2) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("SetRight") + ": " + value + "   ");
					value = (((progStruct.Step[i].UserRights & 4) != 4) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("CheckRight") + ": " + value + "   ");
					this.Main.SimplePrint.SetNewLine();
					break;
				case 3:
				{
					num = progStruct.Step[i].Switch;
					switch (num)
					{
					case 1:
						value = this.Main.Rm.GetString("Torque");
						break;
					case 3:
						value = this.Main.Rm.GetString("FilteredTorque");
						break;
					case 2:
						value = this.Main.Rm.GetString("RelativeTorque");
						break;
					case 11:
						value = this.Main.Rm.GetString("M360Follow");
						break;
					case 4:
						value = this.Main.Rm.GetString("Gradient");
						break;
					case 5:
						value = this.Main.Rm.GetString("Angle");
						break;
					case 7:
						value = this.Main.Rm.GetString("AnaDepth");
						break;
					case 8:
						value = this.Main.Rm.GetString("AnaSignal");
						break;
					default:
						value = "Internal Error";
						break;
					}
					this.Main.SimplePrint.SetLeft();
					this.Main.SimplePrint.SetSizeLarge();
					this.Main.SimplePrint.SetStyleBold();
					StringBuilder sb5 = this.Main.SimplePrint.Sb;
					string string2 = this.Main.Rm.GetString("Step");
					num = i + 1;
					sb5.Append(string2 + " " + num.ToString() + ": ");
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("FinalizingStep") + " (" + value + ")");
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.ResetStyle();
					this.Main.SimplePrint.SetTab(1);
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("RoundsPerMinute") + ": " + progStruct.Step[i].NA.ToString() + this.Main.Rm.GetString("RpmUnit"));
					this.Main.SimplePrint.SetTab(7);
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Ramp") + ": " + progStruct.Step[i].TM.ToString() + this.Main.Rm.GetString("Second"));
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.SetTab(1);
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("PressureCylinder") + ": " + progStruct.Step[i].PressureSpindle.ToString() + this.Main.Rm.GetString("KiloNewton"));
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.SetTab(1);
					num = progStruct.Step[i].Switch;
					switch (num)
					{
					case 1:
					{
						StringBuilder sb8 = this.Main.SimplePrint.Sb;
						string[] array = new string[6]
						{
							this.Main.Rm.GetString("Target"),
							" ",
							this.Main.Rm.GetString("Torque"),
							": ",
							null,
							null
						};
						string[] array8 = array;
						num2 = progStruct.Step[i].MP * this.Main.TorqueConvert;
						num = 2;
						array8[4] = num2.ToString("f" + num.ToString());
						array[5] = this.Main.TorqueUnitName;
						sb8.Append(string.Concat(array));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Torque") + ": ");
						this.Main.SimplePrint.SetTab(4);
						StringBuilder sb9 = this.Main.SimplePrint.Sb;
						array = new string[6]
						{
							this.Main.Rm.GetString("Max"),
							"(",
							this.Main.Rm.GetString("M+"),
							"): ",
							null,
							null
						};
						string[] array9 = array;
						num2 = progStruct.Step[i].Mmax * this.Main.TorqueConvert;
						array9[4] = num2.ToString();
						array[5] = this.Main.TorqueUnitName;
						sb9.Append(string.Concat(array));
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					case 3:
					{
						StringBuilder sb6 = this.Main.SimplePrint.Sb;
						string[] array = new string[6]
						{
							this.Main.Rm.GetString("Target"),
							" ",
							this.Main.Rm.GetString("FilteredTorque"),
							": ",
							null,
							null
						};
						string[] array6 = array;
						num2 = progStruct.Step[i].MFP * this.Main.TorqueConvert;
						num = 2;
						array6[4] = num2.ToString("f" + num.ToString());
						array[5] = this.Main.TorqueUnitName;
						sb6.Append(string.Concat(array));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("FilteredTorque") + ": ");
						this.Main.SimplePrint.SetTab(4);
						StringBuilder sb7 = this.Main.SimplePrint.Sb;
						array = new string[6]
						{
							this.Main.Rm.GetString("Max"),
							"(",
							this.Main.Rm.GetString("MF+"),
							"): ",
							null,
							null
						};
						string[] array7 = array;
						num2 = progStruct.Step[i].MFmax * this.Main.TorqueConvert;
						array7[4] = num2.ToString();
						array[5] = this.Main.TorqueUnitName;
						sb7.Append(string.Concat(array));
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					case 2:
					{
						num = progStruct.Step[i].MRType;
						string text;
						switch (num)
						{
						case 1:
							text = this.Main.Rm.GetString("Torque");
							break;
						case 3:
							text = this.Main.Rm.GetString("FilteredTorque");
							break;
						case 2:
							text = this.Main.Rm.GetString("MaxTorque");
							break;
						case 10:
							text = this.Main.Rm.GetString("DelayTorque");
							break;
						default:
							text = "Internal Error";
							break;
						}
						StringBuilder sb10 = this.Main.SimplePrint.Sb;
						string[] array = new string[15]
						{
							this.Main.Rm.GetString("Target"),
							" ",
							this.Main.Rm.GetString("RelativeTorque"),
							": ",
							null,
							null,
							null,
							null,
							null,
							null,
							null,
							null,
							null,
							null,
							null
						};
						string[] array10 = array;
						num2 = progStruct.Step[i].MRP * this.Main.TorqueConvert;
						num = 2;
						array10[4] = num2.ToString("f" + num.ToString());
						array[5] = this.Main.TorqueUnitName;
						array[6] = " ";
						array[7] = this.Main.Rm.GetString("relatedTo");
						array[8] = " ";
						array[9] = text;
						array[10] = "(";
						array[11] = this.Main.Rm.GetString("Step");
						array[12] = " ";
						string[] array11 = array;
						num = progStruct.Step[i].MRStep + 1;
						array11[13] = num.ToString();
						array[14] = ")";
						sb10.Append(string.Concat(array));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Torque") + ": ");
						this.Main.SimplePrint.SetTab(4);
						StringBuilder sb11 = this.Main.SimplePrint.Sb;
						array = new string[6]
						{
							this.Main.Rm.GetString("Min"),
							"(",
							this.Main.Rm.GetString("M-"),
							"): ",
							null,
							null
						};
						string[] array12 = array;
						num2 = progStruct.Step[i].Mmin * this.Main.TorqueConvert;
						array12[4] = num2.ToString();
						array[5] = this.Main.TorqueUnitName;
						sb11.Append(string.Concat(array));
						this.Main.SimplePrint.SetTab(7);
						StringBuilder sb12 = this.Main.SimplePrint.Sb;
						array = new string[6]
						{
							this.Main.Rm.GetString("Max"),
							"(",
							this.Main.Rm.GetString("M+"),
							"): ",
							null,
							null
						};
						string[] array13 = array;
						num2 = progStruct.Step[i].Mmax * this.Main.TorqueConvert;
						array13[4] = num2.ToString();
						array[5] = this.Main.TorqueUnitName;
						sb12.Append(string.Concat(array));
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					case 11:
					{
						StringBuilder sb15 = this.Main.SimplePrint.Sb;
						string[] array = new string[6]
						{
							this.Main.Rm.GetString("Target"),
							" ",
							this.Main.Rm.GetString("M360Follow"),
							": ",
							null,
							null
						};
						string[] array16 = array;
						num2 = progStruct.Step[i].MRP * this.Main.TorqueConvert;
						num = 2;
						array16[4] = num2.ToString("f" + num.ToString());
						array[5] = this.Main.TorqueUnitName;
						sb15.Append(string.Concat(array));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Torque") + ": ");
						this.Main.SimplePrint.SetTab(4);
						StringBuilder sb16 = this.Main.SimplePrint.Sb;
						array = new string[6]
						{
							this.Main.Rm.GetString("Min"),
							"(",
							this.Main.Rm.GetString("M-"),
							"): ",
							null,
							null
						};
						string[] array17 = array;
						num2 = progStruct.Step[i].Mmin * this.Main.TorqueConvert;
						array17[4] = num2.ToString();
						array[5] = this.Main.TorqueUnitName;
						sb16.Append(string.Concat(array));
						this.Main.SimplePrint.SetTab(7);
						StringBuilder sb17 = this.Main.SimplePrint.Sb;
						array = new string[6]
						{
							this.Main.Rm.GetString("Max"),
							"(",
							this.Main.Rm.GetString("M+"),
							"): ",
							null,
							null
						};
						string[] array18 = array;
						num2 = progStruct.Step[i].Mmax * this.Main.TorqueConvert;
						array18[4] = num2.ToString();
						array[5] = this.Main.TorqueUnitName;
						sb17.Append(string.Concat(array));
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					case 4:
					{
						StringBuilder sb13 = this.Main.SimplePrint.Sb;
						string[] array = new string[8]
						{
							this.Main.Rm.GetString("Target"),
							" ",
							this.Main.Rm.GetString("Gradient"),
							": ",
							null,
							null,
							null,
							null
						};
						string[] array14 = array;
						num2 = progStruct.Step[i].MGP * this.Main.TorqueConvert;
						num = 4;
						array14[4] = num2.ToString("f" + num.ToString());
						array[5] = this.Main.TorqueUnitName;
						array[6] = "/";
						array[7] = this.Main.Rm.GetString("Degree");
						sb13.Append(string.Concat(array));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Gradient") + ": ");
						this.Main.SimplePrint.SetTab(4);
						StringBuilder sb14 = this.Main.SimplePrint.Sb;
						array = new string[8]
						{
							this.Main.Rm.GetString("Max"),
							"(",
							this.Main.Rm.GetString("MG+"),
							"): ",
							null,
							null,
							null,
							null
						};
						string[] array15 = array;
						num2 = progStruct.Step[i].MGmax * this.Main.TorqueConvert;
						array15[4] = num2.ToString();
						array[5] = this.Main.TorqueUnitName;
						array[6] = "/";
						array[7] = this.Main.Rm.GetString("Degree");
						sb14.Append(string.Concat(array));
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					case 5:
					{
						string text;
						if (progStruct.Step[i].Enable.Snug == 1)
						{
							string[] array = new string[6]
							{
								this.Main.Rm.GetString("TreshTorque"),
								"(",
								this.Main.Rm.GetString("Yes"),
								"): ",
								null,
								null
							};
							string[] array5 = array;
							num2 = progStruct.Step[i].MS * this.Main.TorqueConvert;
							array5[4] = num2.ToString();
							array[5] = this.Main.TorqueUnitName;
							text = string.Concat(array);
						}
						else
						{
							text = this.Main.Rm.GetString("TreshTorque") + "(" + this.Main.Rm.GetString("No") + ")";
						}
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("Angle") + ": " + progStruct.Step[i].WP.ToString() + this.Main.Rm.GetString("Degree"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(text + "\n" + this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Angle") + ": ");
						this.Main.SimplePrint.SetTab(4);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("W+") + "): " + progStruct.Step[i].Wmax.ToString() + this.Main.Rm.GetString("Degree"));
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					case 7:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("AnaDepth") + ": " + progStruct.Step[i].LP.ToString() + this.Main.Rm.GetString("Milimeter"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AnaDepth") + ": ");
						this.Main.SimplePrint.SetTab(4);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("L+") + "): " + progStruct.Step[i].Lmax.ToString() + this.Main.Rm.GetString("Milimeter"));
						this.Main.SimplePrint.SetNewLine();
						break;
					case 8:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("AnaSignal") + ": " + progStruct.Step[i].AnaP.ToString());
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTplus") + ": " + progStruct.Step[i].Tmax.ToString() + this.Main.Rm.GetString("Second"));
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AnaSignal") + ": ");
						this.Main.SimplePrint.SetTab(4);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("AS+") + "): " + progStruct.Step[i].AnaMax.ToString());
						this.Main.SimplePrint.SetNewLine();
						break;
					default:
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.Sb.Append("Internal Error");
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					this.Main.SimplePrint.SetTab(1);
					value = ((progStruct.Step[i].IsResult1 != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Result") + " 1: " + value + "   ");
					value = ((progStruct.Step[i].IsResult2 != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Result") + " 2: " + value + "   ");
					value = ((progStruct.Step[i].IsResult3 != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Result") + " 3: " + value + "   ");
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TN") + ": " + progStruct.Step[i].TN.ToString() + this.Main.Rm.GetString("Second"));
					this.Main.SimplePrint.SetNewLine();
					if (progStruct.Step[i].Enable.Release == 1)
					{
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Release") + "(" + this.Main.Rm.GetString("Yes") + ")");
						this.Main.SimplePrint.SetTab(7);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("WN") + ": " + progStruct.Step[i].WN.ToString() + this.Main.Rm.GetString("Degree"));
						this.Main.SimplePrint.SetNewLine();
					}
					else
					{
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Release") + "(" + this.Main.Rm.GetString("No") + ")");
						this.Main.SimplePrint.SetNewLine();
					}
					value = (((progStruct.Step[i].UserRights & 1) != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TargetRight") + ": " + value + "   ");
					value = (((progStruct.Step[i].UserRights & 2) != 2) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("SetRight") + ": " + value + "   ");
					value = (((progStruct.Step[i].UserRights & 4) != 4) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("CheckRight") + ": " + value + "   ");
					this.Main.SimplePrint.SetNewLine();
					break;
				}
				case 1:
				{
					this.Main.SimplePrint.SetLeft();
					this.Main.SimplePrint.SetSizeLarge();
					this.Main.SimplePrint.SetStyleBold();
					StringBuilder sb = this.Main.SimplePrint.Sb;
					string @string = this.Main.Rm.GetString("Step");
					num = i + 1;
					sb.Append(@string + " " + num.ToString() + ": ");
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("OrganizingStep"));
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.ResetStyle();
					this.Main.SimplePrint.SetTab(1);
					num = progStruct.Step[i].Switch;
					switch (num)
					{
					case 1000:
					{
						StringBuilder sb2 = this.Main.SimplePrint.Sb;
						string[] array = new string[5]
						{
							this.Main.Rm.GetString("JumpOkTo"),
							" ",
							this.Main.Rm.GetString("Step"),
							" ",
							null
						};
						string[] array2 = array;
						num = progStruct.Step[i].JumpTo + 1;
						array2[4] = num.ToString();
						sb2.Append(string.Concat(array));
						this.Main.SimplePrint.SetTab(8);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("CountPassMax") + ": " + progStruct.Step[i].CountPassMax.ToString());
						break;
					}
					case 1001:
					{
						StringBuilder sb4 = this.Main.SimplePrint.Sb;
						string[] array = new string[5]
						{
							this.Main.Rm.GetString("JumpNokTo"),
							" ",
							this.Main.Rm.GetString("Step"),
							" ",
							null
						};
						string[] array4 = array;
						num = progStruct.Step[i].JumpTo + 1;
						array4[4] = num.ToString();
						sb4.Append(string.Concat(array));
						this.Main.SimplePrint.SetTab(8);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("CountPassMax") + ": " + progStruct.Step[i].CountPassMax.ToString());
						break;
					}
					case 1002:
					{
						StringBuilder sb3 = this.Main.SimplePrint.Sb;
						string[] array = new string[5]
						{
							this.Main.Rm.GetString("JumpAlwaysTo"),
							" ",
							this.Main.Rm.GetString("Step"),
							" ",
							null
						};
						string[] array3 = array;
						num = progStruct.Step[i].JumpTo + 1;
						array3[4] = num.ToString();
						sb3.Append(string.Concat(array));
						this.Main.SimplePrint.SetTab(8);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("CountPassMax") + ": " + progStruct.Step[i].CountPassMax.ToString());
						break;
					}
					case 1010:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Stop"));
						break;
					case 1011:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StopOk"));
						break;
					case 1012:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StopNok"));
						break;
					case 1020:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("ResetAngle"));
						this.Main.SimplePrint.SetTab(8);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("CountPassMax") + ": " + progStruct.Step[i].CountPassMax.ToString());
						break;
					case 1030:
						num = progStruct.Step[i].ModDigOut;
						switch (num)
						{
						case 1:
							empty = this.Main.Rm.GetString("DigitOut") + "1: " + this.Main.Rm.GetString("SetOn");
							break;
						case -1:
							empty = this.Main.Rm.GetString("DigitOut") + "1: " + this.Main.Rm.GetString("SetOff");
							break;
						case 2:
							empty = this.Main.Rm.GetString("DigitOut") + "2: " + this.Main.Rm.GetString("SetOn");
							break;
						case -2:
							empty = this.Main.Rm.GetString("DigitOut") + "2: " + this.Main.Rm.GetString("SetOff");
							break;
						case 3:
							empty = this.Main.Rm.GetString("JawOpen") + ": " + this.Main.Rm.GetString("SetOn");
							break;
						case -3:
							empty = this.Main.Rm.GetString("JawOpen") + ": " + this.Main.Rm.GetString("SetOff");
							break;
						case 4:
							empty = this.Main.Rm.GetString("SyncOut") + "2: " + this.Main.Rm.GetString("SetOn");
							break;
						case -4:
							empty = this.Main.Rm.GetString("SyncOut") + "2: " + this.Main.Rm.GetString("SetOff");
							break;
						default:
							empty = "Internal Error";
							break;
						}
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("SetDigOut") + ": " + empty);
						this.Main.SimplePrint.SetTab(8);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("CountPassMax") + ": " + progStruct.Step[i].CountPassMax.ToString());
						break;
					case 1040:
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("ResetADepth"));
						this.Main.SimplePrint.SetTab(8);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("CountPassMax") + ": " + progStruct.Step[i].CountPassMax.ToString());
						break;
					default:
						this.Main.SimplePrint.Sb.Append("Internal Error");
						break;
					}
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.SetTab(1);
					value = (((progStruct.Step[i].UserRights & 1) != 1) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TargetRight") + ": " + value + "   ");
					value = (((progStruct.Step[i].UserRights & 2) != 2) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("SetRight") + ": " + value + "   ");
					value = (((progStruct.Step[i].UserRights & 4) != 4) ? this.Main.Rm.GetString("No") : this.Main.Rm.GetString("Yes"));
					this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("CheckRight") + ": " + value + "   ");
					this.Main.SimplePrint.SetNewLine();
					break;
				}
				default:
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.Sb.Append("Internal Error");
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.SetNewLine();
					break;
				}
				int num3;
				int num4;
				switch (progStruct.Step[i].Type)
				{
				case 2:
					num3 = 0;
					goto IL_65f5;
				case 3:
					{
						num3 = 1;
						goto IL_65f5;
					}
					IL_65f5:
					switch (progStruct.Step[i].Switch)
					{
					case 1:
						num4 = 0;
						goto IL_66ab;
					case 50:
						num4 = 1;
						goto IL_66ab;
					case 3:
						num4 = 2;
						goto IL_66ab;
					case 51:
						num4 = 3;
						goto IL_66ab;
					case 2:
						num4 = 4;
						goto IL_66ab;
					case 4:
						num4 = 5;
						goto IL_66ab;
					case 52:
						num4 = 6;
						goto IL_66ab;
					case 5:
						num4 = 7;
						goto IL_66ab;
					case 6:
						num4 = 8;
						goto IL_66ab;
					case 7:
						num4 = 9;
						goto IL_66ab;
					case 53:
						num4 = 10;
						goto IL_66ab;
					case 8:
						num4 = 11;
						goto IL_66ab;
					case 54:
						num4 = 12;
						goto IL_66ab;
					case 9:
						num4 = 13;
						goto IL_66ab;
					case 55:
						num4 = 14;
						goto IL_66ab;
					case 10:
						num4 = 15;
						goto IL_66ab;
					case 11:
						{
							num4 = 16;
							goto IL_66ab;
						}
						IL_66ab:
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.ResetStyle();
						this.Main.SimplePrint.SetStyleBold();
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("MCheckParameter") + ":");
						this.Main.SimplePrint.SetNewLine();
						this.Main.SimplePrint.ResetStyle();
						if (this.Main.VisibleParameters.EnaT[num4, num3] && progStruct.Step[i].Enable.Time == 1)
						{
							this.Main.SimplePrint.SetTab(1);
							this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("StepTmin"));
							if (this.Main.VisibleParameters.Tmin[num4, num3])
							{
								this.Main.SimplePrint.SetTab(4);
								StringBuilder sb22 = this.Main.SimplePrint.Sb;
								string[] array = new string[6]
								{
									this.Main.Rm.GetString("Min"),
									"(",
									this.Main.Rm.GetString("T-"),
									"): ",
									null,
									null
								};
								string[] array25 = array;
								ref float tmin = ref progStruct.Step[i].Tmin;
								num = 2;
								array25[4] = tmin.ToString("f" + num.ToString());
								array[5] = this.Main.Rm.GetString("Second");
								sb22.Append(string.Concat(array));
								this.Main.SimplePrint.SetNewLine();
							}
						}
						if (this.Main.VisibleParameters.EnaW[num4, num3] && progStruct.Step[i].Enable.Angle == 1)
						{
							this.Main.SimplePrint.SetTab(1);
							this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Angle"));
							if (this.Main.VisibleParameters.Wmin[num4, num3])
							{
								this.Main.SimplePrint.SetTab(4);
								StringBuilder sb23 = this.Main.SimplePrint.Sb;
								string[] array = new string[6]
								{
									this.Main.Rm.GetString("Min"),
									"(",
									this.Main.Rm.GetString("W-"),
									"): ",
									null,
									null
								};
								string[] array26 = array;
								ref float wmin = ref progStruct.Step[i].Wmin;
								num = 1;
								array26[4] = wmin.ToString("f" + num.ToString());
								array[5] = this.Main.Rm.GetString("Degree");
								sb23.Append(string.Concat(array));
							}
							if (this.Main.VisibleParameters.Wmax[num4, num3])
							{
								this.Main.SimplePrint.SetTab(7);
								StringBuilder sb24 = this.Main.SimplePrint.Sb;
								string[] array = new string[6]
								{
									this.Main.Rm.GetString("Max"),
									"(",
									this.Main.Rm.GetString("W+"),
									"): ",
									null,
									null
								};
								string[] array27 = array;
								ref float wmax = ref progStruct.Step[i].Wmax;
								num = 1;
								array27[4] = wmax.ToString("f" + num.ToString());
								array[5] = this.Main.Rm.GetString("Degree");
								sb24.Append(string.Concat(array));
							}
							this.Main.SimplePrint.SetNewLine();
							this.Main.SimplePrint.SetTab(1);
							if (this.Main.VisibleParameters.MS[num4, num3])
							{
								if (progStruct.Step[i].Enable.Snug == 1)
								{
									StringBuilder sb25 = this.Main.SimplePrint.Sb;
									string[] array = new string[6]
									{
										this.Main.Rm.GetString("TreshTorque"),
										"(",
										this.Main.Rm.GetString("Yes"),
										"): ",
										null,
										null
									};
									string[] array28 = array;
									num2 = progStruct.Step[i].MS * this.Main.TorqueConvert;
									num = 2;
									array28[4] = num2.ToString("f" + num.ToString());
									array[5] = this.Main.TorqueUnitName;
									sb25.Append(string.Concat(array));
								}
								else
								{
									this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TreshTorque") + "(" + this.Main.Rm.GetString("No") + ")");
								}
								this.Main.SimplePrint.SetNewLine();
							}
						}
						if (this.Main.VisibleParameters.EnaM[num4, num3] && progStruct.Step[i].Enable.Torque == 1)
						{
							this.Main.SimplePrint.SetTab(1);
							this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Torque"));
							if (this.Main.VisibleParameters.Mmin[num4, num3])
							{
								this.Main.SimplePrint.SetTab(4);
								StringBuilder sb26 = this.Main.SimplePrint.Sb;
								string[] array = new string[6]
								{
									this.Main.Rm.GetString("Min"),
									"(",
									this.Main.Rm.GetString("M-"),
									"): ",
									null,
									null
								};
								string[] array29 = array;
								num2 = progStruct.Step[i].Mmin * this.Main.TorqueConvert;
								num = 2;
								array29[4] = num2.ToString("f" + num.ToString());
								array[5] = this.Main.TorqueUnitName;
								sb26.Append(string.Concat(array));
							}
							if (this.Main.VisibleParameters.Mmax[num4, num3])
							{
								this.Main.SimplePrint.SetTab(7);
								StringBuilder sb27 = this.Main.SimplePrint.Sb;
								string[] array = new string[6]
								{
									this.Main.Rm.GetString("Max"),
									"(",
									this.Main.Rm.GetString("M+"),
									"): ",
									null,
									null
								};
								string[] array30 = array;
								num2 = progStruct.Step[i].Mmax * this.Main.TorqueConvert;
								num = 2;
								array30[4] = num2.ToString("f" + num.ToString());
								array[5] = this.Main.TorqueUnitName;
								sb27.Append(string.Concat(array));
								this.Main.SimplePrint.SetNewLine();
							}
						}
						if (this.Main.VisibleParameters.EnaMF[num4, num3] && progStruct.Step[i].Enable.FTorque == 1)
						{
							this.Main.SimplePrint.SetTab(1);
							this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("FilteredTorque"));
							if (this.Main.VisibleParameters.MFmin[num4, num3])
							{
								this.Main.SimplePrint.SetTab(4);
								StringBuilder sb28 = this.Main.SimplePrint.Sb;
								string[] array = new string[6]
								{
									this.Main.Rm.GetString("Min"),
									"(",
									this.Main.Rm.GetString("MF-"),
									"): ",
									null,
									null
								};
								string[] array31 = array;
								num2 = progStruct.Step[i].MFmin * this.Main.TorqueConvert;
								num = 2;
								array31[4] = num2.ToString("f" + num.ToString());
								array[5] = this.Main.TorqueUnitName;
								sb28.Append(string.Concat(array));
							}
							if (this.Main.VisibleParameters.MFmax[num4, num3])
							{
								this.Main.SimplePrint.SetTab(7);
								StringBuilder sb29 = this.Main.SimplePrint.Sb;
								string[] array = new string[6]
								{
									this.Main.Rm.GetString("Max"),
									"(",
									this.Main.Rm.GetString("MF+"),
									"): ",
									null,
									null
								};
								string[] array32 = array;
								num2 = progStruct.Step[i].MFmax * this.Main.TorqueConvert;
								num = 2;
								array32[4] = num2.ToString("f" + num.ToString());
								array[5] = this.Main.TorqueUnitName;
								sb29.Append(string.Concat(array));
								this.Main.SimplePrint.SetNewLine();
							}
						}
						if (this.Main.VisibleParameters.MGmin[num4, num3] && progStruct.Step[i].Enable.GradientMin > 0)
						{
							this.Main.SimplePrint.SetTab(1);
							this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("Min") + ")");
							this.Main.SimplePrint.SetTab(4);
							StringBuilder sb30 = this.Main.SimplePrint.Sb;
							string[] array = new string[6]
							{
								this.Main.Rm.GetString("MG-"),
								": ",
								null,
								null,
								null,
								null
							};
							string[] array33 = array;
							num2 = progStruct.Step[i].MGmin * this.Main.TorqueConvert;
							num = 4;
							array33[2] = num2.ToString("f" + num.ToString());
							array[3] = this.Main.TorqueUnitName;
							array[4] = "/";
							array[5] = this.Main.Rm.GetString("Degree");
							sb30.Append(string.Concat(array));
							this.Main.SimplePrint.SetTab(7);
							if (progStruct.Step[i].Enable.GradientMin == 1)
							{
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigSigAtEnd"));
							}
							else
							{
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigSigRunning"));
							}
							this.Main.SimplePrint.SetNewLine();
						}
						if (this.Main.VisibleParameters.MGmax[num4, num3] && progStruct.Step[i].Enable.GradientMax > 0)
						{
							this.Main.SimplePrint.SetTab(1);
							this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("Max") + ")");
							this.Main.SimplePrint.SetTab(4);
							StringBuilder sb31 = this.Main.SimplePrint.Sb;
							string[] array = new string[6]
							{
								this.Main.Rm.GetString("MG+"),
								": ",
								null,
								null,
								null,
								null
							};
							string[] array34 = array;
							num2 = progStruct.Step[i].MGmax * this.Main.TorqueConvert;
							num = 4;
							array34[2] = num2.ToString("f" + num.ToString());
							array[3] = this.Main.TorqueUnitName;
							array[4] = "/";
							array[5] = this.Main.Rm.GetString("Degree");
							sb31.Append(string.Concat(array));
							this.Main.SimplePrint.SetTab(7);
							if (progStruct.Step[i].Enable.GradientMax == 1)
							{
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigSigAtEnd"));
							}
							else
							{
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigSigRunning"));
							}
							this.Main.SimplePrint.SetNewLine();
						}
						if (this.Main.VisibleParameters.EnaL[num4, num3] && progStruct.Step[i].Enable.ADepth == 1)
						{
							this.Main.SimplePrint.SetTab(1);
							this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AnaDepth"));
							if (this.Main.VisibleParameters.Lmin[num4, num3])
							{
								this.Main.SimplePrint.SetTab(4);
								StringBuilder sb32 = this.Main.SimplePrint.Sb;
								string[] array = new string[6]
								{
									this.Main.Rm.GetString("Min"),
									"(",
									this.Main.Rm.GetString("L-"),
									"): ",
									null,
									null
								};
								string[] array35 = array;
								ref float lmin = ref progStruct.Step[i].Lmin;
								num = 1;
								array35[4] = lmin.ToString("f" + num.ToString());
								array[5] = this.Main.Rm.GetString("Milimeter");
								sb32.Append(string.Concat(array));
							}
							if (this.Main.VisibleParameters.Lmax[num4, num3])
							{
								this.Main.SimplePrint.SetTab(7);
								StringBuilder sb33 = this.Main.SimplePrint.Sb;
								string[] array = new string[6]
								{
									this.Main.Rm.GetString("Max"),
									"(",
									this.Main.Rm.GetString("L+"),
									"): ",
									null,
									null
								};
								string[] array36 = array;
								ref float lmax = ref progStruct.Step[i].Lmax;
								num = 1;
								array36[4] = lmax.ToString("f" + num.ToString());
								array[5] = this.Main.Rm.GetString("Milimeter");
								sb33.Append(string.Concat(array));
								this.Main.SimplePrint.SetNewLine();
							}
						}
						if (this.Main.VisibleParameters.LGmin[num4, num3] && progStruct.Step[i].Enable.ADepthGradMin > 0)
						{
							this.Main.SimplePrint.SetTab(1);
							this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("Min") + ")");
							this.Main.SimplePrint.SetTab(4);
							StringBuilder sb34 = this.Main.SimplePrint.Sb;
							string[] array = new string[6]
							{
								this.Main.Rm.GetString("LG-"),
								": ",
								null,
								null,
								null,
								null
							};
							string[] array37 = array;
							ref float lGmin = ref progStruct.Step[i].LGmin;
							num = 4;
							array37[2] = lGmin.ToString("f" + num.ToString());
							array[3] = this.Main.Rm.GetString("Milimeter");
							array[4] = "/";
							array[5] = this.Main.Rm.GetString("Second");
							sb34.Append(string.Concat(array));
							this.Main.SimplePrint.SetTab(7);
							if (progStruct.Step[i].Enable.ADepthGradMin == 1)
							{
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigSigAtEnd"));
							}
							else
							{
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigSigRunning"));
							}
							this.Main.SimplePrint.SetNewLine();
						}
						if (this.Main.VisibleParameters.LGmax[num4, num3] && progStruct.Step[i].Enable.ADepthGradMax > 0)
						{
							this.Main.SimplePrint.SetTab(1);
							this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("Max") + ")");
							this.Main.SimplePrint.SetTab(4);
							StringBuilder sb35 = this.Main.SimplePrint.Sb;
							string[] array = new string[6]
							{
								this.Main.Rm.GetString("LG+"),
								": ",
								null,
								null,
								null,
								null
							};
							string[] array38 = array;
							ref float lGmax = ref progStruct.Step[i].LGmax;
							num = 4;
							array38[2] = lGmax.ToString("f" + num.ToString());
							array[3] = this.Main.Rm.GetString("Milimeter");
							array[4] = "/";
							array[5] = this.Main.Rm.GetString("Second");
							sb35.Append(string.Concat(array));
							this.Main.SimplePrint.SetTab(7);
							if (progStruct.Step[i].Enable.ADepthGradMax == 1)
							{
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigSigAtEnd"));
							}
							else
							{
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigSigRunning"));
							}
							this.Main.SimplePrint.SetNewLine();
						}
						if (this.Main.VisibleParameters.EnaAS[num4, num3] && progStruct.Step[i].Enable.Ana == 1)
						{
							this.Main.SimplePrint.SetTab(1);
							this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("AnaSignal"));
							if (this.Main.VisibleParameters.ASmin[num4, num3])
							{
								this.Main.SimplePrint.SetTab(4);
								StringBuilder sb36 = this.Main.SimplePrint.Sb;
								string[] array = new string[5]
								{
									this.Main.Rm.GetString("Min"),
									"(",
									this.Main.Rm.GetString("AS-"),
									"): ",
									null
								};
								string[] array39 = array;
								ref float anaMin = ref progStruct.Step[i].AnaMin;
								num = 2;
								array39[4] = anaMin.ToString("f" + num.ToString());
								sb36.Append(string.Concat(array));
							}
							if (this.Main.VisibleParameters.ASmax[num4, num3])
							{
								this.Main.SimplePrint.SetTab(7);
								StringBuilder sb37 = this.Main.SimplePrint.Sb;
								string[] array = new string[5]
								{
									this.Main.Rm.GetString("Max"),
									"(",
									this.Main.Rm.GetString("AS+"),
									"): ",
									null
								};
								string[] array40 = array;
								ref float anaMax = ref progStruct.Step[i].AnaMax;
								num = 2;
								array40[4] = anaMax.ToString("f" + num.ToString());
								sb37.Append(string.Concat(array));
								this.Main.SimplePrint.SetNewLine();
							}
						}
						if (this.Main.VisibleParameters.DSmax[num4, num3] && progStruct.Step[i].DigMax != 0)
						{
							this.Main.SimplePrint.SetTab(1);
							this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("DigSigRunning") + "): ");
							switch (progStruct.Step[i].DigMax)
							{
							case 1:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TM1") + " " + this.Main.Rm.GetString("Positive"));
								break;
							case 2:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TM2") + " " + this.Main.Rm.GetString("Positive"));
								break;
							case 3:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigitalSignal") + " " + this.Main.Rm.GetString("Positive"));
								break;
							case 4:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("JawOpen") + " " + this.Main.Rm.GetString("Positive"));
								break;
							case 5:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("SyncSignal") + "2 " + this.Main.Rm.GetString("Positive"));
								break;
							case -1:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TM1") + " " + this.Main.Rm.GetString("Negative"));
								break;
							case -2:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TM2") + " " + this.Main.Rm.GetString("Negative"));
								break;
							case -3:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigitalSignal") + " " + this.Main.Rm.GetString("Negative"));
								break;
							case -4:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("JawOpen") + " " + this.Main.Rm.GetString("Negative"));
								break;
							case -5:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("SyncSignal") + "2 " + this.Main.Rm.GetString("Negative"));
								break;
							default:
								this.Main.SimplePrint.Sb.Append("Internal Error");
								break;
							}
							this.Main.SimplePrint.SetNewLine();
						}
						if (this.Main.VisibleParameters.DSmin[num4, num3] && progStruct.Step[i].DigMin != 0)
						{
							this.Main.SimplePrint.SetTab(1);
							this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("DigSigAtEnd") + "): ");
							switch (progStruct.Step[i].DigMin)
							{
							case 1:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TM1") + " " + this.Main.Rm.GetString("Positive"));
								break;
							case 2:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TM2") + " " + this.Main.Rm.GetString("Positive"));
								break;
							case 3:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigitalSignal") + " " + this.Main.Rm.GetString("Positive"));
								break;
							case 4:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("JawOpen") + " " + this.Main.Rm.GetString("Positive"));
								break;
							case 5:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("SyncSignal") + "2 " + this.Main.Rm.GetString("Positive"));
								break;
							case -1:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TM1") + " " + this.Main.Rm.GetString("Negative"));
								break;
							case -2:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("TM2") + " " + this.Main.Rm.GetString("Negative"));
								break;
							case -3:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("DigitalSignal") + " " + this.Main.Rm.GetString("Negative"));
								break;
							case -4:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("JawOpen") + " " + this.Main.Rm.GetString("Negative"));
								break;
							case -5:
								this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("SyncSignal") + "2 " + this.Main.Rm.GetString("Negative"));
								break;
							default:
								this.Main.SimplePrint.Sb.Append("Internal Error");
								break;
							}
							this.Main.SimplePrint.SetNewLine();
						}
						this.Main.SimplePrint.SetTab(1);
						this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("CountPassMax") + ": " + progStruct.Step[i].CountPassMax.ToString());
						this.Main.SimplePrint.SetNewLine();
						break;
					}
					break;
				}
			}
			this.Main.SimplePrint.SetNewPage();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private string WrapText(string s, int maxCol)
		{
			StringBuilder stringBuilder = new StringBuilder();
			int num = 0;
			if (s.Length <= maxCol)
			{
				return s;
			}
			while (!s.Equals(string.Empty))
			{
				if (s.Length > maxCol)
				{
					num = maxCol;
					while (s[num] != ' ')
					{
						num--;
						if (num <= 0)
						{
							num = maxCol;
							break;
						}
					}
				}
				else
				{
					num = s.Length;
				}
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append("\n   " + s.Substring(0, num));
				}
				else
				{
					stringBuilder.Append(s.Substring(0, num));
				}
				s = s.Remove(0, num);
			}
			return stringBuilder.ToString();
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
		}

		private void chBPrograms_CheckedChanged(object sender, EventArgs e)
		{
			this.cBProgramms.Enabled = this.chBPrograms.Checked;
		}

		private void ParameterPrintForm_Shown(object sender, EventArgs e)
		{
			this.cBProgramms.Items.Add(this.Main.Rm.GetString("All"));
			this.cBProgramms.SelectedIndex = 0;
			for (uint num = 1u; num < 1024; num++)
			{
				if (this.Main.VC.PProg.Num[num].Info.Steps >= 1)
				{
					this.cBProgramms.Items.Add(num.ToString("0000") + ": " + this.Main.CommonFunctions.UShortToString(this.Main.VC.PProg.Num[num].Info.Name));
				}
			}
		}
	}
}
