using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class TestMotorSensorForm : Form
	{
		private const int ANALOGMAX = 10;

		private MainForm Main;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private System.Windows.Forms.Timer timerUpdate;

		private IContainer components;

		private Button bt6;

		private Button bt5;

		private GroupBox gBSensorTest;

		private Label lbUnitSensorAngle;

		private Label lbUnitSensorTorque;

		private CheckBox chBCalibrate;

		private Button btResetSensorAngle;

		private Label lbShowSensorAngle;

		private Label lbSensorAngle;

		private Label lbShowSensorTorque;

		private Label lbSensorTorque;

		private GroupBox gBDriveUnitTest;

		private Label lbUnitRpm;

		private Button btApplyRpm;

		private NumberEdit1 nESetRpm;

		private Button btMotorOff;

		private Label lbMotor;

		private Label lbShowRpm;

		private Label lbRpm;

		private Label lbSetRpm;

		private Button btTeach;

		private Label lbUnitDepthSensor;

		private Label lbDepthSensor;

		private Label lbShowDepthSensor;

		private GroupBox gBDepthSensor;

		private Label lbShowDepthSensorVoltage;

		private Label lbUnitDepthSensorVoltage;

		private Label lbUnitRedAngle;

		private Label lbUnitRedTorque;

		private Label lbShowRedAngle;

		private Label lbRedAngle;

		private Label lbShowRedTorque;

		private Label lbRedTorque;

		private Button btPLCInterface;

		private Button btMotorSensor;

		private Button btIOTest;

		private Button btBrowser;

		public TestMotorSensorForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.timerUpdate.Interval = 500;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			this.pnMenu = new Panel();
			this.btBrowser = new Button();
			this.bt6 = new Button();
			this.bt5 = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.timerUpdate = new System.Windows.Forms.Timer(this.components);
			this.gBSensorTest = new GroupBox();
			this.lbUnitRedAngle = new Label();
			this.lbUnitRedTorque = new Label();
			this.lbShowRedAngle = new Label();
			this.lbRedAngle = new Label();
			this.lbShowRedTorque = new Label();
			this.lbRedTorque = new Label();
			this.lbUnitSensorAngle = new Label();
			this.lbUnitSensorTorque = new Label();
			this.chBCalibrate = new CheckBox();
			this.btResetSensorAngle = new Button();
			this.lbShowSensorAngle = new Label();
			this.lbSensorAngle = new Label();
			this.lbShowSensorTorque = new Label();
			this.lbSensorTorque = new Label();
			this.gBDriveUnitTest = new GroupBox();
			this.lbUnitRpm = new Label();
			this.btApplyRpm = new Button();
			this.nESetRpm = new NumberEdit1();
			this.btMotorOff = new Button();
			this.lbMotor = new Label();
			this.lbShowRpm = new Label();
			this.lbRpm = new Label();
			this.lbSetRpm = new Label();
			this.gBDepthSensor = new GroupBox();
			this.lbShowDepthSensorVoltage = new Label();
			this.lbUnitDepthSensorVoltage = new Label();
			this.lbShowDepthSensor = new Label();
			this.lbUnitDepthSensor = new Label();
			this.btTeach = new Button();
			this.lbDepthSensor = new Label();
			this.btPLCInterface = new Button();
			this.btMotorSensor = new Button();
			this.btIOTest = new Button();
			this.pnMenu.SuspendLayout();
			this.gBSensorTest.SuspendLayout();
			this.gBDriveUnitTest.SuspendLayout();
			this.gBDepthSensor.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btPLCInterface);
			this.pnMenu.Controls.Add(this.btMotorSensor);
			this.pnMenu.Controls.Add(this.btIOTest);
			this.pnMenu.Controls.Add(this.btBrowser);
			this.pnMenu.Controls.Add(this.bt6);
			this.pnMenu.Controls.Add(this.bt5);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btBrowser.Enabled = false;
			this.btBrowser.Location = new Point(3, 323);
			this.btBrowser.Name = "btBrowser";
			this.btBrowser.Size = new Size(74, 62);
			this.btBrowser.TabIndex = 5;
			this.btBrowser.Click += this.btBrowser_Click;
			this.bt6.Enabled = false;
			this.bt6.Location = new Point(3, 451);
			this.bt6.Name = "bt6";
			this.bt6.Size = new Size(74, 62);
			this.bt6.TabIndex = 7;
			this.bt5.Enabled = false;
			this.bt5.Location = new Point(3, 387);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(74, 62);
			this.bt5.TabIndex = 6;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btHelp.Enter += this.Start_Input;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.btBack.Enter += this.Start_Input;
			this.timerUpdate.Interval = 500;
			this.timerUpdate.Tick += this.timerUpdate_Tick;
			this.gBSensorTest.Controls.Add(this.lbUnitRedAngle);
			this.gBSensorTest.Controls.Add(this.lbUnitRedTorque);
			this.gBSensorTest.Controls.Add(this.lbShowRedAngle);
			this.gBSensorTest.Controls.Add(this.lbRedAngle);
			this.gBSensorTest.Controls.Add(this.lbShowRedTorque);
			this.gBSensorTest.Controls.Add(this.lbRedTorque);
			this.gBSensorTest.Controls.Add(this.lbUnitSensorAngle);
			this.gBSensorTest.Controls.Add(this.lbUnitSensorTorque);
			this.gBSensorTest.Controls.Add(this.chBCalibrate);
			this.gBSensorTest.Controls.Add(this.btResetSensorAngle);
			this.gBSensorTest.Controls.Add(this.lbShowSensorAngle);
			this.gBSensorTest.Controls.Add(this.lbSensorAngle);
			this.gBSensorTest.Controls.Add(this.lbShowSensorTorque);
			this.gBSensorTest.Controls.Add(this.lbSensorTorque);
			this.gBSensorTest.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBSensorTest.Location = new Point(16, 16);
			this.gBSensorTest.Name = "gBSensorTest";
			this.gBSensorTest.Size = new Size(680, 168);
			this.gBSensorTest.TabIndex = 1;
			this.gBSensorTest.TabStop = false;
			this.gBSensorTest.Text = "Sensortest";
			this.lbUnitRedAngle.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitRedAngle.Location = new Point(592, 80);
			this.lbUnitRedAngle.Name = "lbUnitRedAngle";
			this.lbUnitRedAngle.Size = new Size(64, 23);
			this.lbUnitRedAngle.TabIndex = 21;
			this.lbUnitRedAngle.Text = "°";
			this.lbUnitRedAngle.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitRedTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitRedTorque.Location = new Point(592, 40);
			this.lbUnitRedTorque.Name = "lbUnitRedTorque";
			this.lbUnitRedTorque.Size = new Size(64, 23);
			this.lbUnitRedTorque.TabIndex = 20;
			this.lbUnitRedTorque.Text = "Nm";
			this.lbUnitRedTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowRedAngle.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowRedAngle.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowRedAngle.Location = new Point(480, 80);
			this.lbShowRedAngle.Name = "lbShowRedAngle";
			this.lbShowRedAngle.Size = new Size(104, 23);
			this.lbShowRedAngle.TabIndex = 19;
			this.lbShowRedAngle.Text = "0";
			this.lbShowRedAngle.TextAlign = ContentAlignment.MiddleRight;
			this.lbRedAngle.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbRedAngle.Location = new Point(344, 80);
			this.lbRedAngle.Name = "lbRedAngle";
			this.lbRedAngle.Size = new Size(128, 23);
			this.lbRedAngle.TabIndex = 18;
			this.lbRedAngle.Text = "Winkel";
			this.lbRedAngle.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowRedTorque.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowRedTorque.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowRedTorque.Location = new Point(480, 40);
			this.lbShowRedTorque.Name = "lbShowRedTorque";
			this.lbShowRedTorque.Size = new Size(104, 23);
			this.lbShowRedTorque.TabIndex = 17;
			this.lbShowRedTorque.Text = "0";
			this.lbShowRedTorque.TextAlign = ContentAlignment.MiddleRight;
			this.lbRedTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbRedTorque.Location = new Point(344, 40);
			this.lbRedTorque.Name = "lbRedTorque";
			this.lbRedTorque.Size = new Size(128, 23);
			this.lbRedTorque.TabIndex = 16;
			this.lbRedTorque.Text = "Moment";
			this.lbRedTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitSensorAngle.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitSensorAngle.Location = new Point(264, 80);
			this.lbUnitSensorAngle.Name = "lbUnitSensorAngle";
			this.lbUnitSensorAngle.Size = new Size(64, 23);
			this.lbUnitSensorAngle.TabIndex = 15;
			this.lbUnitSensorAngle.Text = "°";
			this.lbUnitSensorAngle.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitSensorTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitSensorTorque.Location = new Point(264, 40);
			this.lbUnitSensorTorque.Name = "lbUnitSensorTorque";
			this.lbUnitSensorTorque.Size = new Size(64, 23);
			this.lbUnitSensorTorque.TabIndex = 14;
			this.lbUnitSensorTorque.Text = "Nm";
			this.lbUnitSensorTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.chBCalibrate.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBCalibrate.Location = new Point(136, 120);
			this.chBCalibrate.Name = "chBCalibrate";
			this.chBCalibrate.Size = new Size(136, 24);
			this.chBCalibrate.TabIndex = 0;
			this.chBCalibrate.Text = "Kalibriersignal";
			this.chBCalibrate.CheckedChanged += this.chBCalibrate_CheckedChanged;
			this.chBCalibrate.Enter += this.Start_Input;
			this.btResetSensorAngle.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btResetSensorAngle.Location = new Point(344, 120);
			this.btResetSensorAngle.Name = "btResetSensorAngle";
			this.btResetSensorAngle.Size = new Size(75, 23);
			this.btResetSensorAngle.TabIndex = 1;
			this.btResetSensorAngle.Text = "Reset";
			this.btResetSensorAngle.Click += this.btResetSensorAngle_Click;
			this.btResetSensorAngle.Enter += this.Start_Input;
			this.lbShowSensorAngle.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowSensorAngle.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowSensorAngle.Location = new Point(152, 80);
			this.lbShowSensorAngle.Name = "lbShowSensorAngle";
			this.lbShowSensorAngle.Size = new Size(104, 23);
			this.lbShowSensorAngle.TabIndex = 13;
			this.lbShowSensorAngle.Text = "0";
			this.lbShowSensorAngle.TextAlign = ContentAlignment.MiddleRight;
			this.lbSensorAngle.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbSensorAngle.Location = new Point(16, 80);
			this.lbSensorAngle.Name = "lbSensorAngle";
			this.lbSensorAngle.Size = new Size(128, 23);
			this.lbSensorAngle.TabIndex = 12;
			this.lbSensorAngle.Text = "Winkel";
			this.lbSensorAngle.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowSensorTorque.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowSensorTorque.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowSensorTorque.Location = new Point(152, 40);
			this.lbShowSensorTorque.Name = "lbShowSensorTorque";
			this.lbShowSensorTorque.Size = new Size(104, 23);
			this.lbShowSensorTorque.TabIndex = 11;
			this.lbShowSensorTorque.Text = "0";
			this.lbShowSensorTorque.TextAlign = ContentAlignment.MiddleRight;
			this.lbSensorTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbSensorTorque.Location = new Point(16, 40);
			this.lbSensorTorque.Name = "lbSensorTorque";
			this.lbSensorTorque.Size = new Size(128, 23);
			this.lbSensorTorque.TabIndex = 10;
			this.lbSensorTorque.Text = "Moment";
			this.lbSensorTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.gBDriveUnitTest.Controls.Add(this.lbUnitRpm);
			this.gBDriveUnitTest.Controls.Add(this.btApplyRpm);
			this.gBDriveUnitTest.Controls.Add(this.nESetRpm);
			this.gBDriveUnitTest.Controls.Add(this.btMotorOff);
			this.gBDriveUnitTest.Controls.Add(this.lbMotor);
			this.gBDriveUnitTest.Controls.Add(this.lbShowRpm);
			this.gBDriveUnitTest.Controls.Add(this.lbRpm);
			this.gBDriveUnitTest.Controls.Add(this.lbSetRpm);
			this.gBDriveUnitTest.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBDriveUnitTest.Location = new Point(16, 192);
			this.gBDriveUnitTest.Name = "gBDriveUnitTest";
			this.gBDriveUnitTest.Size = new Size(680, 168);
			this.gBDriveUnitTest.TabIndex = 2;
			this.gBDriveUnitTest.TabStop = false;
			this.gBDriveUnitTest.Text = "Drehzahltest";
			this.lbUnitRpm.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitRpm.Location = new Point(312, 80);
			this.lbUnitRpm.Name = "lbUnitRpm";
			this.lbUnitRpm.Size = new Size(56, 23);
			this.lbUnitRpm.TabIndex = 16;
			this.lbUnitRpm.Text = "U/min";
			this.lbUnitRpm.TextAlign = ContentAlignment.MiddleLeft;
			this.btApplyRpm.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btApplyRpm.Location = new Point(200, 120);
			this.btApplyRpm.Name = "btApplyRpm";
			this.btApplyRpm.Size = new Size(96, 23);
			this.btApplyRpm.TabIndex = 1;
			this.btApplyRpm.Text = "Übernehmen";
			this.btApplyRpm.Click += this.btApplyRpm_Click;
			this.btApplyRpm.Enter += this.Start_Input;
			this.nESetRpm.BackColor = Color.White;
			this.nESetRpm.DecimalNum = 1;
			this.nESetRpm.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nESetRpm.ForeColor = SystemColors.ControlText;
			this.nESetRpm.Location = new Point(200, 37);
			this.nESetRpm.MaxValue = 100f;
			this.nESetRpm.MinValue = -100f;
			this.nESetRpm.Name = "nESetRpm";
			this.nESetRpm.Size = new Size(104, 28);
			this.nESetRpm.TabIndex = 0;
			this.nESetRpm.Text = "0,0";
			this.nESetRpm.TextAlign = HorizontalAlignment.Right;
			this.nESetRpm.Value = 0f;
			this.nESetRpm.TextChanged += this.nESetRpm_TextChanged;
			this.nESetRpm.Enter += this.Start_Input;
			this.nESetRpm.MouseDown += this.StartInput;
			this.btMotorOff.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btMotorOff.Location = new Point(320, 120);
			this.btMotorOff.Name = "btMotorOff";
			this.btMotorOff.Size = new Size(96, 23);
			this.btMotorOff.TabIndex = 2;
			this.btMotorOff.Text = "Aus";
			this.btMotorOff.Click += this.btMotorOff_Click;
			this.btMotorOff.Enter += this.Start_Input;
			this.lbMotor.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMotor.Location = new Point(16, 120);
			this.lbMotor.Name = "lbMotor";
			this.lbMotor.Size = new Size(176, 23);
			this.lbMotor.TabIndex = 15;
			this.lbMotor.Text = "Motor";
			this.lbMotor.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowRpm.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowRpm.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowRpm.Location = new Point(200, 80);
			this.lbShowRpm.Name = "lbShowRpm";
			this.lbShowRpm.Size = new Size(104, 23);
			this.lbShowRpm.TabIndex = 14;
			this.lbShowRpm.Text = "0";
			this.lbShowRpm.TextAlign = ContentAlignment.MiddleRight;
			this.lbRpm.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbRpm.Location = new Point(16, 80);
			this.lbRpm.Name = "lbRpm";
			this.lbRpm.Size = new Size(176, 23);
			this.lbRpm.TabIndex = 12;
			this.lbRpm.Text = "Istdrehzahl";
			this.lbRpm.TextAlign = ContentAlignment.MiddleLeft;
			this.lbSetRpm.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbSetRpm.Location = new Point(16, 40);
			this.lbSetRpm.Name = "lbSetRpm";
			this.lbSetRpm.Size = new Size(176, 23);
			this.lbSetRpm.TabIndex = 9;
			this.lbSetRpm.Text = "Solldrehzahl (in %)";
			this.lbSetRpm.TextAlign = ContentAlignment.MiddleLeft;
			this.gBDepthSensor.Controls.Add(this.lbShowDepthSensorVoltage);
			this.gBDepthSensor.Controls.Add(this.lbUnitDepthSensorVoltage);
			this.gBDepthSensor.Controls.Add(this.lbShowDepthSensor);
			this.gBDepthSensor.Controls.Add(this.lbUnitDepthSensor);
			this.gBDepthSensor.Controls.Add(this.btTeach);
			this.gBDepthSensor.Controls.Add(this.lbDepthSensor);
			this.gBDepthSensor.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBDepthSensor.Location = new Point(16, 368);
			this.gBDepthSensor.Name = "gBDepthSensor";
			this.gBDepthSensor.Size = new Size(680, 120);
			this.gBDepthSensor.TabIndex = 3;
			this.gBDepthSensor.TabStop = false;
			this.gBDepthSensor.Text = "Drehzahltest";
			this.lbShowDepthSensorVoltage.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowDepthSensorVoltage.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowDepthSensorVoltage.Location = new Point(384, 40);
			this.lbShowDepthSensorVoltage.Name = "lbShowDepthSensorVoltage";
			this.lbShowDepthSensorVoltage.Size = new Size(104, 23);
			this.lbShowDepthSensorVoltage.TabIndex = 19;
			this.lbShowDepthSensorVoltage.Text = "0";
			this.lbShowDepthSensorVoltage.TextAlign = ContentAlignment.MiddleRight;
			this.lbUnitDepthSensorVoltage.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitDepthSensorVoltage.Location = new Point(496, 40);
			this.lbUnitDepthSensorVoltage.Name = "lbUnitDepthSensorVoltage";
			this.lbUnitDepthSensorVoltage.Size = new Size(56, 23);
			this.lbUnitDepthSensorVoltage.TabIndex = 18;
			this.lbUnitDepthSensorVoltage.Text = "mm";
			this.lbUnitDepthSensorVoltage.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowDepthSensor.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowDepthSensor.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowDepthSensor.Location = new Point(200, 40);
			this.lbShowDepthSensor.Name = "lbShowDepthSensor";
			this.lbShowDepthSensor.Size = new Size(104, 23);
			this.lbShowDepthSensor.TabIndex = 17;
			this.lbShowDepthSensor.Text = "0";
			this.lbShowDepthSensor.TextAlign = ContentAlignment.MiddleRight;
			this.lbUnitDepthSensor.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitDepthSensor.Location = new Point(312, 40);
			this.lbUnitDepthSensor.Name = "lbUnitDepthSensor";
			this.lbUnitDepthSensor.Size = new Size(56, 23);
			this.lbUnitDepthSensor.TabIndex = 16;
			this.lbUnitDepthSensor.Text = "mm";
			this.lbUnitDepthSensor.TextAlign = ContentAlignment.MiddleLeft;
			this.btTeach.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btTeach.Location = new Point(200, 80);
			this.btTeach.Name = "btTeach";
			this.btTeach.Size = new Size(96, 23);
			this.btTeach.TabIndex = 0;
			this.btTeach.Text = "Teach";
			this.btTeach.Click += this.btTeach_Click;
			this.lbDepthSensor.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDepthSensor.Location = new Point(16, 40);
			this.lbDepthSensor.Name = "lbDepthSensor";
			this.lbDepthSensor.Size = new Size(176, 23);
			this.lbDepthSensor.TabIndex = 9;
			this.lbDepthSensor.Text = "Analoge Tiefe";
			this.lbDepthSensor.TextAlign = ContentAlignment.MiddleLeft;
			this.btPLCInterface.Location = new Point(3, 259);
			this.btPLCInterface.Name = "btPLCInterface";
			this.btPLCInterface.Size = new Size(74, 62);
			this.btPLCInterface.TabIndex = 10;
			this.btPLCInterface.Text = "SPS I/O";
			this.btPLCInterface.Click += this.btPLCInterface_Click;
			this.btMotorSensor.Enabled = false;
			this.btMotorSensor.Location = new Point(3, 131);
			this.btMotorSensor.Name = "btMotorSensor";
			this.btMotorSensor.Size = new Size(74, 62);
			this.btMotorSensor.TabIndex = 8;
			this.btMotorSensor.Text = "Motor Reibwert Sensor";
			this.btIOTest.Location = new Point(3, 195);
			this.btIOTest.Name = "btIOTest";
			this.btIOTest.Size = new Size(74, 62);
			this.btIOTest.TabIndex = 9;
			this.btIOTest.Text = "I/O";
			this.btIOTest.Click += this.btIOTest_Click;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.gBDepthSensor);
			base.Controls.Add(this.gBDriveUnitTest);
			base.Controls.Add(this.gBSensorTest);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "TestMotorSensorForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Test/Motor-Reibwert-Sensor";
			base.Activated += this.TestMotorSensorForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBSensorTest.ResumeLayout(false);
			this.gBDriveUnitTest.ResumeLayout(false);
			this.gBDriveUnitTest.PerformLayout();
			this.gBDepthSensor.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public bool ShowWindow()
		{
			this.Main.ActivationBrowserGrantedBy = this;
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadIO"));
			if (!this.Main.VC.ReceiveVarBlock(40))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive TestDataRawInBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.chBCalibrate.Checked = false;
			this.MenEna();
			Cursor.Current = Cursors.Default;
			this.Main.VC.TestDataRawOut.Command = 1;
			this.Main.VC.TestDataRawOut.DO16 = 0;
			this.SendTestBlock();
			this.Main.VC.TestDataRawOut.Command = 5;
			this.Main.VC.TestDataRawOut.STSpeed = 0f;
			this.nESetRpm.Value = 0f;
			this.lbUnitSensorTorque.Text = this.Main.TorqueUnitName;
			this.lbUnitRedTorque.Text = this.Main.TorqueUnitName;
			this.SendTestBlock();
			this.btApplyRpm.Text = this.Main.Rm.GetString("SetOn");
			this.timerUpdate.Enabled = true;
			this.Main.StatusBarText(string.Empty);
			base.Show();
			Application.DoEvents();
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuTest") + "/" + this.Main.Rm.GetString("TestMFS");
			this.lbMotor.Text = this.Main.Rm.GetString("Motor");
			this.lbRpm.Text = this.Main.Rm.GetString("GetRpm");
			this.gBDriveUnitTest.Text = this.Main.Rm.GetString("RpmTest");
			this.lbSensorAngle.Text = this.Main.Rm.GetString("Angle");
			this.lbRedAngle.Text = this.Main.Rm.GetString("RedAngle");
			this.gBSensorTest.Text = this.Main.Rm.GetString("SensorTest");
			this.gBDepthSensor.Text = this.Main.Rm.GetString("AnaDepth");
			this.lbSensorTorque.Text = this.Main.Rm.GetString("Torque");
			this.lbRedTorque.Text = this.Main.Rm.GetString("RedTorque");
			this.lbSetRpm.Text = this.Main.Rm.GetString("SetRpm") + "(%)";
			this.lbDepthSensor.Text = this.Main.Rm.GetString("AnaDepth");
			this.lbUnitRpm.Text = this.Main.Rm.GetString("RpmUnit");
			this.lbUnitDepthSensor.Text = this.Main.Rm.GetString("Milimeter");
			this.lbUnitDepthSensorVoltage.Text = this.Main.Rm.GetString("Voltage");
			this.chBCalibrate.Text = this.Main.Rm.GetString("CalibrationSignal");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btIOTest.Text = this.Main.Rm.GetString("IOTest");
			this.btMotorSensor.Text = this.Main.Rm.GetString("IntegratedTests");
			this.btPLCInterface.Text = this.Main.Rm.GetString("PLC_IO");
			this.btMotorOff.Text = this.Main.Rm.GetString("SetOff");
			this.btApplyRpm.Text = this.Main.Rm.GetString("SetOn");
			this.btResetSensorAngle.Text = this.Main.Rm.GetString("Reset");
			this.btTeach.Text = this.Main.Rm.GetString("btTeach");
			this.lbUnitSensorAngle.Text = this.Main.Rm.GetString("Degree");
			this.lbUnitRedAngle.Text = this.Main.Rm.GetString("Degree");
		}

		private void MenEna()
		{
			bool enabled = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_TestMotorSensorForm)
			{
				enabled = true;
			}
			if (!this.Main.Usb_Key_Access())
			{
				enabled = true;
			}
			else
			{
				this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_TestMotorSensorForm, false);
			}
			if (!this.Main.MenuTest1.WritePermission)
			{
				enabled = false;
			}
			this.nESetRpm.Enabled = enabled;
			this.btResetSensorAngle.Enabled = enabled;
			this.chBCalibrate.Enabled = enabled;
			this.btApplyRpm.Enabled = enabled;
			this.btMotorOff.Enabled = enabled;
			this.btTeach.Enabled = enabled;
			this.nESetRpm.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
		}

		private void UpdateValues()
		{
			this.lbShowSensorAngle.Text = this.Main.VC.TestDataRawIn.Angle1.ToString();
			this.lbShowRedAngle.Text = this.Main.VC.TestDataRawIn.Angle2.ToString();
			this.lbShowSensorTorque.Text = (this.Main.VC.TestDataRawIn.Torque1 * this.Main.TorqueConvert).ToString();
			this.lbShowRedTorque.Text = (this.Main.VC.TestDataRawIn.Torque2 * this.Main.TorqueConvert).ToString();
			this.lbShowRpm.Text = this.Main.VC.TestDataRawIn.Nact.ToString();
			this.lbShowDepthSensor.Text = this.Main.VC.TestDataRawIn.ADepth.ToString();
			this.lbShowDepthSensorVoltage.Text = this.Main.VC.TestDataRawIn.Ui2.ToString();
		}

		private void timerUpdate_Tick(object sender, EventArgs e)
		{
			this.timerUpdate.Enabled = false;
			if (this.Main.IsOnlineMode)
			{
				if (!this.Main.VC.ReceiveVarBlock(40))
				{
					MessageBox.Show("Could not receive TestDataRawInBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				this.UpdateValues();
				this.timerUpdate.Enabled = true;
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.timerUpdate.Enabled = false;
			this.Main.VC.TestDataRawOut.Command = 5;
			this.Main.VC.TestDataRawOut.STEnable = 0;
			this.Main.VC.TestDataRawOut.STSpeed = 0f;
			this.SendTestBlock();
			this.btApplyRpm.Text = this.Main.Rm.GetString("SetOn");
			base.Hide();
			if (sender != null)
			{
				this.Main.MenuTest1.Back();
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.SettingsChangedReset();
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_3_1_Baugruppen_Test";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_3_1_Baugruppen_Test");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btResetSensorAngle_Click(object sender, EventArgs e)
		{
			this.Main.VC.TestDataRawOut.Command = 4;
			this.Main.VC.TestDataRawOut.ResetAngle = 1;
			this.Main.VC.TestDataRawOut.ResetEnc0 = 0;
			this.Main.VC.TestDataRawOut.ResetEnc1 = 0;
			this.Main.VC.TestDataRawOut.ResetEnc2 = 0;
			this.Main.VC.TestDataRawOut.ResetEncErr = 0;
			this.SendTestBlock();
		}

		private void chBCalibrate_CheckedChanged(object sender, EventArgs e)
		{
			this.Main.VC.TestDataRawOut.Command = 7;
			if (this.chBCalibrate.Checked)
			{
				this.Main.VC.TestDataRawOut.DOState = 1;
			}
			else
			{
				this.Main.VC.TestDataRawOut.DOState = 0;
			}
			this.SendTestBlock();
		}

		private void btApplyRpm_Click(object sender, EventArgs e)
		{
			if (this.nESetRpm.Value > this.nESetRpm.MaxValue)
			{
				this.nESetRpm.Value = this.nESetRpm.MaxValue;
			}
			if (this.nESetRpm.Value < this.nESetRpm.MinValue)
			{
				this.nESetRpm.Value = this.nESetRpm.MinValue;
			}
			this.Main.VC.TestDataRawOut.Command = 5;
			this.Main.VC.TestDataRawOut.STSpeed = this.nESetRpm.Value / 100f * 10f;
			this.Main.VC.TestDataRawOut.STEnable = 1;
			this.SendTestBlock();
			this.btApplyRpm.Text = this.Main.Rm.GetString("Set");
		}

		private void btMotorOff_Click(object sender, EventArgs e)
		{
			this.Main.VC.TestDataRawOut.Command = 5;
			this.Main.VC.TestDataRawOut.STEnable = 0;
			this.SendTestBlock();
			this.btApplyRpm.Text = this.Main.Rm.GetString("SetOn");
		}

		private void SendTestBlock()
		{
			int num = 0;
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("SendIO"));
				if (!this.Main.VC.SendVarBlock(41))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not send TestDataRawOutBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.Main.StatusBarText(this.Main.Rm.GetString("WaitForAck"));
					while (this.Main.VC.TestDataRawOut.Command != 0)
					{
						if (num <= 5 && this.Main.VC.ReceiveVarBlock(41))
						{
							Thread.Sleep(50);
							num++;
							continue;
						}
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						break;
					}
				}
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void btTeach_Click(object sender, EventArgs e)
		{
			this.Main.VC.TestDataRawOut.Command = 6;
			this.SendTestBlock();
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
			this.BrowserShow();
		}

		private void btIOTest_Click(object sender, EventArgs e)
		{
			this.btBack_Click(null, EventArgs.Empty);
			this.Main.MenuTest1.ShowIOTest();
		}

		private void btPLCInterface_Click(object sender, EventArgs e)
		{
			this.btBack_Click(null, EventArgs.Empty);
			this.Main.MenuTest1.ShowPLCInterface();
		}

		private void nESetRpm_TextChanged(object sender, EventArgs e)
		{
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
				this.Main.SettingsChangedReset();
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
				this.Main.SettingsChangedReset();
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void TestMotorSensorForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
			this.MenEna();
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}
	}
}
