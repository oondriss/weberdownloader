using System;
using System.IO;
using System.Xml.Serialization;

namespace Visualisation
{
	[Serializable]
	public class LevelAssignmentClass
	{
		public int UserLevel_Backup = 1;

		public int UserLevel_BrowserForm = 1;

		public int UserLevel_CheckParam = 1;

		public int UserLevel_CycleCounter = 1;

		public int UserLevel_EditSteps = 1;

		public int UserLevel_HandStartForm = 1;

		public int UserLevel_Maintenance = 1;

		public int UserLevel_PrgOptParameter = 1;

		public int UserLevel_ProgramOverview = 1;

		public int UserLevel_FourStepEditForm = 1;

		public int UserLevel_SpindleConstants = 1;

		public int UserLevel_StatisticsLastRes = 1;

		public int UserLevel_StepOverview = 1;

		public int UserLevel_SystemConstants = 1;

		public int UserLevel_TestIO = 1;

		public int UserLevel_TestMotorSensor = 1;

		public int UserLevel_VisualisationParam = 1;

		public bool Read(string path, ref LevelAssignmentClass data)
		{
			bool result = true;
			FileStream fileStream = null;
			try
			{
				XmlSerializer xmlSerializer = new XmlSerializer(typeof(LevelAssignmentClass));
				fileStream = new FileStream(path, FileMode.Open);
				data = (LevelAssignmentClass)xmlSerializer.Deserialize(fileStream);
			}
			catch (Exception)
			{
				result = false;
			}
			if (fileStream != null)
			{
				fileStream.Close();
				fileStream.Dispose();
			}
			return result;
		}

		public bool Write(string path, LevelAssignmentClass data)
		{
			bool flag = false;
			StreamWriter streamWriter = null;
			try
			{
				XmlSerializer xmlSerializer = new XmlSerializer(typeof(LevelAssignmentClass));
				streamWriter = new StreamWriter(path);
				xmlSerializer.Serialize(streamWriter, this);
				flag = true;
			}
			catch (Exception)
			{
				flag = false;
			}
			if (streamWriter != null)
			{
				streamWriter.Close();
				streamWriter.Dispose();
			}
			return flag;
		}
	}
}
