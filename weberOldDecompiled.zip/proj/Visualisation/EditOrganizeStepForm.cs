using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class EditOrganizeStepForm : Form
	{
		private MainForm Main;

		private WSP1_VarComm.StepStruct SD;

		private int PNum;

		private int SNum;

		private byte NumberOfSteps;

		private Panel pnMenu;

		private Button bt1;

		private Button btHelp;

		private Button btBack;

		private Button btCancel;

		private Button bt5;

		private Button bt4;

		private NumberEdit1 nEJumpToStep;

		private Label lbJumpToStep;

		private ComboBox cBModDigOut;

		private ComboBox cBDigOutKind;

		private NumberEdit1 nECountPassMax;

		private Label lbCountPassMax;

		private GroupBox gBHeader;

		private Label lbProgNum;

		private Label lbProgName;

		private Label lbStepNum;

		private ComboBox cBOrganizeType;

		private Label lbOrganizeType;

		private Label lbStepType;

		private GroupBox gBCountPassMax;

		private GroupBox gBOrganizeType;

		private Panel pnJump;

		private Panel pnModDigOut;

		private GroupBox gBRights;

		private CheckBox chBCheckRight;

		private CheckBox chBTargetRight;

		private CheckBox chBSetRight;

		private Container components;

		private bool IsNewStep;

		private Button btNext;

		private Button btPrevious;

		private bool bCanceled;

		private bool bInitializing;

		private Font myFont = new Font("Arial Unicode MS", 11f, FontStyle.Regular);

		private int recentSelectedModDigOut;

		private readonly int _DISABLED_DIG_OUT = 2;

		public bool WasCanceled
		{
			get
			{
				bool result = this.bCanceled;
				this.bCanceled = false;
				return result;
			}
		}

		public EditOrganizeStepForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.PNum = 0;
			this.SNum = 0;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btPrevious = new Button();
			this.btNext = new Button();
			this.btCancel = new Button();
			this.bt5 = new Button();
			this.bt4 = new Button();
			this.bt1 = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.cBOrganizeType = new ComboBox();
			this.nEJumpToStep = new NumberEdit1();
			this.lbJumpToStep = new Label();
			this.lbOrganizeType = new Label();
			this.cBModDigOut = new ComboBox();
			this.cBDigOutKind = new ComboBox();
			this.nECountPassMax = new NumberEdit1();
			this.lbCountPassMax = new Label();
			this.gBHeader = new GroupBox();
			this.lbProgNum = new Label();
			this.lbProgName = new Label();
			this.lbStepType = new Label();
			this.lbStepNum = new Label();
			this.gBCountPassMax = new GroupBox();
			this.gBOrganizeType = new GroupBox();
			this.pnJump = new Panel();
			this.pnModDigOut = new Panel();
			this.gBRights = new GroupBox();
			this.chBCheckRight = new CheckBox();
			this.chBTargetRight = new CheckBox();
			this.chBSetRight = new CheckBox();
			this.pnMenu.SuspendLayout();
			this.gBHeader.SuspendLayout();
			this.gBCountPassMax.SuspendLayout();
			this.gBOrganizeType.SuspendLayout();
			this.pnJump.SuspendLayout();
			this.pnModDigOut.SuspendLayout();
			this.gBRights.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btPrevious);
			this.pnMenu.Controls.Add(this.btNext);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.bt5);
			this.pnMenu.Controls.Add(this.bt4);
			this.pnMenu.Controls.Add(this.bt1);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 16;
			this.btPrevious.Location = new Point(3, 259);
			this.btPrevious.Name = "btPrevious";
			this.btPrevious.Size = new Size(74, 62);
			this.btPrevious.TabIndex = 4;
			this.btPrevious.Text = "Vorherige";
			this.btPrevious.Click += this.btPrevious_Click;
			this.btNext.Location = new Point(3, 196);
			this.btNext.Name = "btNext";
			this.btNext.Size = new Size(74, 62);
			this.btNext.TabIndex = 3;
			this.btNext.Text = "Nächste";
			this.btNext.Click += this.btNext_Click;
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 7;
			this.btCancel.Text = "Abbruch";
			this.btCancel.Click += this.btCancel_Click;
			this.bt5.Enabled = false;
			this.bt5.Location = new Point(3, 387);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(74, 62);
			this.bt5.TabIndex = 6;
			this.bt4.Enabled = false;
			this.bt4.Location = new Point(3, 323);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(74, 62);
			this.bt4.TabIndex = 5;
			this.bt1.Enabled = false;
			this.bt1.Location = new Point(3, 131);
			this.bt1.Name = "bt1";
			this.bt1.Size = new Size(74, 62);
			this.bt1.TabIndex = 2;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Fertig";
			this.btBack.Click += this.btBack_Click;
			this.cBOrganizeType.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBOrganizeType.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBOrganizeType.Items.AddRange(new object[8]
			{
				"Sprung(IO)",
				"Sprung(NIO)",
				"Sprung(Immer)",
				"Stop",
				"Stop(IO)",
				"Stop(NIO)",
				"Winkel rücksetzen",
				"Setze Digitalausgang"
			});
			this.cBOrganizeType.Location = new Point(120, 21);
			this.cBOrganizeType.MaxDropDownItems = 9;
			this.cBOrganizeType.Name = "cBOrganizeType";
			this.cBOrganizeType.Size = new Size(208, 28);
			this.cBOrganizeType.TabIndex = 17;
			this.cBOrganizeType.SelectedValueChanged += this.cBOrganizeType_SelectedValueChanged;
			this.nEJumpToStep.BackColor = Color.White;
			this.nEJumpToStep.DecimalNum = 0;
			this.nEJumpToStep.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEJumpToStep.ForeColor = Color.Red;
			this.nEJumpToStep.Location = new Point(112, 0);
			this.nEJumpToStep.MaxValue = 25f;
			this.nEJumpToStep.MinValue = 1f;
			this.nEJumpToStep.Name = "nEJumpToStep";
			this.nEJumpToStep.Size = new Size(104, 28);
			this.nEJumpToStep.TabIndex = 18;
			this.nEJumpToStep.Text = "0";
			this.nEJumpToStep.TextAlign = HorizontalAlignment.Right;
			this.nEJumpToStep.Value = 0f;
			this.nEJumpToStep.TextChanged += this.settingsChanged;
			this.nEJumpToStep.Enter += this.Start_Input;
			this.nEJumpToStep.MouseDown += this.StartInput;
			this.lbJumpToStep.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbJumpToStep.Location = new Point(0, 3);
			this.lbJumpToStep.Name = "lbJumpToStep";
			this.lbJumpToStep.Size = new Size(104, 23);
			this.lbJumpToStep.TabIndex = 19;
			this.lbJumpToStep.Text = "zu Stufe";
			this.lbJumpToStep.TextAlign = ContentAlignment.MiddleLeft;
			this.lbOrganizeType.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbOrganizeType.Location = new Point(8, 24);
			this.lbOrganizeType.Name = "lbOrganizeType";
			this.lbOrganizeType.Size = new Size(104, 23);
			this.lbOrganizeType.TabIndex = 20;
			this.lbOrganizeType.Text = "Typ";
			this.lbOrganizeType.TextAlign = ContentAlignment.MiddleLeft;
			this.cBModDigOut.DrawMode = DrawMode.OwnerDrawFixed;
			this.cBModDigOut.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBModDigOut.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBModDigOut.Items.AddRange(new object[4]
			{
				"Digital 1",
				"Digital 2",
				"Sync 1",
				"Sync 2"
			});
			this.cBModDigOut.Location = new Point(0, 0);
			this.cBModDigOut.MaxDropDownItems = 4;
			this.cBModDigOut.Name = "cBModDigOut";
			this.cBModDigOut.Size = new Size(168, 29);
			this.cBModDigOut.TabIndex = 21;
			this.cBModDigOut.DrawItem += this.cBModDigOut_DrawItem;
			this.cBModDigOut.SelectedIndexChanged += this.cBModDigOut_SelectedIndexChanged;
			this.cBDigOutKind.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBDigOutKind.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBDigOutKind.Items.AddRange(new object[2]
			{
				"Aus",
				"Ein"
			});
			this.cBDigOutKind.Location = new Point(176, 0);
			this.cBDigOutKind.MaxDropDownItems = 2;
			this.cBDigOutKind.Name = "cBDigOutKind";
			this.cBDigOutKind.Size = new Size(112, 28);
			this.cBDigOutKind.TabIndex = 22;
			this.nECountPassMax.BackColor = Color.White;
			this.nECountPassMax.DecimalNum = 0;
			this.nECountPassMax.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nECountPassMax.ForeColor = SystemColors.ControlText;
			this.nECountPassMax.Location = new Point(256, 21);
			this.nECountPassMax.MaxValue = 10f;
			this.nECountPassMax.MinValue = 0f;
			this.nECountPassMax.Name = "nECountPassMax";
			this.nECountPassMax.Size = new Size(104, 28);
			this.nECountPassMax.TabIndex = 25;
			this.nECountPassMax.Text = "0";
			this.nECountPassMax.TextAlign = HorizontalAlignment.Right;
			this.nECountPassMax.Value = 0f;
			this.nECountPassMax.TextChanged += this.settingsChanged;
			this.nECountPassMax.Enter += this.Start_Input;
			this.nECountPassMax.MouseDown += this.StartInput;
			this.lbCountPassMax.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbCountPassMax.Location = new Point(8, 24);
			this.lbCountPassMax.Name = "lbCountPassMax";
			this.lbCountPassMax.Size = new Size(240, 23);
			this.lbCountPassMax.TabIndex = 26;
			this.lbCountPassMax.Text = "Max. Stufenwiederholungen";
			this.lbCountPassMax.TextAlign = ContentAlignment.MiddleLeft;
			this.gBHeader.Controls.Add(this.lbProgNum);
			this.gBHeader.Controls.Add(this.lbProgName);
			this.gBHeader.Controls.Add(this.lbStepType);
			this.gBHeader.Controls.Add(this.lbStepNum);
			this.gBHeader.Location = new Point(6, 8);
			this.gBHeader.Name = "gBHeader";
			this.gBHeader.Size = new Size(696, 64);
			this.gBHeader.TabIndex = 27;
			this.gBHeader.TabStop = false;
			this.lbProgNum.BorderStyle = BorderStyle.Fixed3D;
			this.lbProgNum.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgNum.Location = new Point(8, 24);
			this.lbProgNum.Name = "lbProgNum";
			this.lbProgNum.Size = new Size(95, 23);
			this.lbProgNum.TabIndex = 17;
			this.lbProgNum.Text = "Prog. 1023";
			this.lbProgNum.TextAlign = ContentAlignment.MiddleLeft;
			this.lbProgName.BorderStyle = BorderStyle.Fixed3D;
			this.lbProgName.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgName.Location = new Point(109, 24);
			this.lbProgName.Name = "lbProgName";
			this.lbProgName.Size = new Size(233, 23);
			this.lbProgName.TabIndex = 16;
			this.lbProgName.Text = "Name";
			this.lbProgName.TextAlign = ContentAlignment.MiddleLeft;
			this.lbStepType.BorderStyle = BorderStyle.Fixed3D;
			this.lbStepType.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbStepType.Location = new Point(472, 24);
			this.lbStepType.Name = "lbStepType";
			this.lbStepType.Size = new Size(192, 23);
			this.lbStepType.TabIndex = 15;
			this.lbStepType.Text = "Typ";
			this.lbStepType.TextAlign = ContentAlignment.MiddleLeft;
			this.lbStepNum.BorderStyle = BorderStyle.Fixed3D;
			this.lbStepNum.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbStepNum.Location = new Point(392, 24);
			this.lbStepNum.Name = "lbStepNum";
			this.lbStepNum.Size = new Size(72, 23);
			this.lbStepNum.TabIndex = 14;
			this.lbStepNum.Text = "Stufe 25";
			this.lbStepNum.TextAlign = ContentAlignment.MiddleLeft;
			this.gBCountPassMax.Controls.Add(this.nECountPassMax);
			this.gBCountPassMax.Controls.Add(this.lbCountPassMax);
			this.gBCountPassMax.Location = new Point(6, 152);
			this.gBCountPassMax.Name = "gBCountPassMax";
			this.gBCountPassMax.Size = new Size(696, 64);
			this.gBCountPassMax.TabIndex = 28;
			this.gBCountPassMax.TabStop = false;
			this.gBOrganizeType.Controls.Add(this.lbOrganizeType);
			this.gBOrganizeType.Controls.Add(this.cBOrganizeType);
			this.gBOrganizeType.Controls.Add(this.pnJump);
			this.gBOrganizeType.Controls.Add(this.pnModDigOut);
			this.gBOrganizeType.Location = new Point(6, 80);
			this.gBOrganizeType.Name = "gBOrganizeType";
			this.gBOrganizeType.Size = new Size(696, 64);
			this.gBOrganizeType.TabIndex = 29;
			this.gBOrganizeType.TabStop = false;
			this.pnJump.Controls.Add(this.lbJumpToStep);
			this.pnJump.Controls.Add(this.nEJumpToStep);
			this.pnJump.Location = new Point(344, 21);
			this.pnJump.Name = "pnJump";
			this.pnJump.Size = new Size(336, 28);
			this.pnJump.TabIndex = 30;
			this.pnModDigOut.Controls.Add(this.cBModDigOut);
			this.pnModDigOut.Controls.Add(this.cBDigOutKind);
			this.pnModDigOut.Location = new Point(344, 21);
			this.pnModDigOut.Name = "pnModDigOut";
			this.pnModDigOut.Size = new Size(328, 28);
			this.pnModDigOut.TabIndex = 31;
			this.gBRights.Controls.Add(this.chBCheckRight);
			this.gBRights.Controls.Add(this.chBTargetRight);
			this.gBRights.Controls.Add(this.chBSetRight);
			this.gBRights.Location = new Point(495, 344);
			this.gBRights.Name = "gBRights";
			this.gBRights.Size = new Size(207, 136);
			this.gBRights.TabIndex = 50;
			this.gBRights.TabStop = false;
			this.gBRights.Text = "Berechtigung Bediener";
			this.chBCheckRight.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBCheckRight.Location = new Point(16, 88);
			this.chBCheckRight.Name = "chBCheckRight";
			this.chBCheckRight.Size = new Size(185, 24);
			this.chBCheckRight.TabIndex = 111;
			this.chBCheckRight.Text = "Überwachung";
			this.chBCheckRight.CheckedChanged += this.settingsChanged;
			this.chBTargetRight.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBTargetRight.Location = new Point(16, 56);
			this.chBTargetRight.Name = "chBTargetRight";
			this.chBTargetRight.Size = new Size(185, 24);
			this.chBTargetRight.TabIndex = 110;
			this.chBTargetRight.Text = "Zielwerte";
			this.chBTargetRight.CheckedChanged += this.settingsChanged;
			this.chBSetRight.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBSetRight.Location = new Point(16, 24);
			this.chBSetRight.Name = "chBSetRight";
			this.chBSetRight.Size = new Size(185, 24);
			this.chBSetRight.TabIndex = 109;
			this.chBSetRight.Text = "Sollwerte";
			this.chBSetRight.CheckedChanged += this.settingsChanged;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.gBRights);
			base.Controls.Add(this.gBOrganizeType);
			base.Controls.Add(this.gBCountPassMax);
			base.Controls.Add(this.gBHeader);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "EditOrganizeStepForm";
			base.StartPosition = FormStartPosition.Manual;
			base.Activated += this.EditOrganizeStepForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBHeader.ResumeLayout(false);
			this.gBCountPassMax.ResumeLayout(false);
			this.gBCountPassMax.PerformLayout();
			this.gBOrganizeType.ResumeLayout(false);
			this.pnJump.ResumeLayout(false);
			this.pnJump.PerformLayout();
			this.pnModDigOut.ResumeLayout(false);
			this.gBRights.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public bool ShowWindow(int progNum, int stepNum, byte numberOfSteps, bool bNewStep)
		{
			if (stepNum >= 0 && stepNum <= 24)
			{
				this.bInitializing = true;
				this.Main.ResetBrowserGrantedBy();
				this.SNum = stepNum;
				this.PNum = progNum;
				this.NumberOfSteps = numberOfSteps;
				this.IsNewStep = bNewStep;
				this.SD = this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Step[this.SNum];
				this.InitializeValues();
				this.MenEna();
				base.Show();
				this.bInitializing = false;
				return true;
			}
			return false;
		}

		public void SetLanguageTexts()
		{
			bool flag = this.bInitializing;
			this.bInitializing = true;
			string[] array = new string[9];
			string[] array2 = new string[4];
			string[] array3 = new string[2];
			array[0] = this.Main.Rm.GetString("JumpOkTo") + string.Empty;
			array[1] = this.Main.Rm.GetString("JumpNokTo") + string.Empty;
			array[2] = this.Main.Rm.GetString("JumpAlwaysTo") + string.Empty;
			array[3] = this.Main.Rm.GetString("Stop") + string.Empty;
			array[4] = this.Main.Rm.GetString("StopOk") + string.Empty;
			array[5] = this.Main.Rm.GetString("StopNok") + string.Empty;
			array[6] = this.Main.Rm.GetString("ResetAngle") + string.Empty;
			array[7] = this.Main.Rm.GetString("SetDigOut") + string.Empty;
			array[8] = this.Main.Rm.GetString("ResetADepth") + string.Empty;
			array2[0] = this.Main.Rm.GetString("DigitOut") + "1";
			array2[1] = this.Main.Rm.GetString("DigitOut") + "2";
			array2[2] = (this.Main.Rm.GetString("JawOpen") ?? "");
			array2[3] = this.Main.Rm.GetString("SyncOut") + "2";
			array3[0] = this.Main.Rm.GetString("SetOn") + string.Empty;
			array3[1] = this.Main.Rm.GetString("SetOff") + string.Empty;
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MProgramOverview") + "/" + this.Main.Rm.GetString("MStepOverview") + "/" + this.Main.Rm.GetString("MEditStep");
			this.btBack.Text = this.Main.Rm.GetString("Done");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btCancel.Text = this.Main.Rm.GetString("btCancel");
			this.btNext.Text = this.Main.Rm.GetString("btNext");
			this.btPrevious.Text = this.Main.Rm.GetString("btPrevious");
			this.lbCountPassMax.Text = this.Main.Rm.GetString("CountPassMax");
			this.lbJumpToStep.Text = this.Main.Rm.GetString("Step");
			this.lbOrganizeType.Text = this.Main.Rm.GetString("Type");
			this.cBOrganizeType.Items.Clear();
			this.cBOrganizeType.Items.AddRange(array);
			this.cBOrganizeType.SelectedIndex = 0;
			this.cBModDigOut.Items.Clear();
			this.cBModDigOut.Items.AddRange(array2);
			this.cBModDigOut.SelectedIndex = 0;
			this.cBDigOutKind.Items.Clear();
			this.cBDigOutKind.Items.AddRange(array3);
			this.cBDigOutKind.SelectedIndex = 0;
			this.chBCheckRight.Text = this.Main.Rm.GetString("CheckRight");
			this.chBSetRight.Text = this.Main.Rm.GetString("SetRight");
			this.chBTargetRight.Text = this.Main.Rm.GetString("TargetRight");
			this.gBRights.Text = this.Main.Rm.GetString("UserRights");
			this.bInitializing = flag;
		}

		private void MenEna()
		{
			if ((this.SD.UserRights & 1) != 1 || this.Main.PassCodeLevel <= 0)
			{
				byte passCodeLevel = this.Main.PassCodeLevel;
				int userLevel_EditStep = Settings.Default.UserLevel_EditSteps;
			}
			if ((this.SD.UserRights & 2) != 2 || this.Main.PassCodeLevel <= 0)
			{
				byte passCodeLevel2 = this.Main.PassCodeLevel;
				int userLevel_EditStep2 = Settings.Default.UserLevel_EditSteps;
			}
			if ((this.SD.UserRights & 4) != 4 || this.Main.PassCodeLevel <= 0)
			{
				byte passCodeLevel3 = this.Main.PassCodeLevel;
				int userLevel_EditStep3 = Settings.Default.UserLevel_EditSteps;
			}
			bool enabled = false;
			bool enabled2 = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_EditSteps)
			{
				enabled2 = true;
			}
			if (this.Main.PassCodeLevel >= 1)
			{
				enabled = true;
			}
			if (this.Main.ViewOnlyMode)
			{
				enabled = false;
				enabled2 = false;
			}
			if (this.Main.IsOfflineVersion)
			{
				enabled = true;
				enabled2 = true;
			}
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_EditSteps, this.Main.ViewOnlyMode);
			this.cBOrganizeType.Enabled = enabled2;
			this.cBModDigOut.Enabled = enabled2;
			this.cBDigOutKind.Enabled = enabled2;
			this.nEJumpToStep.Enabled = enabled2;
			this.nECountPassMax.Enabled = enabled2;
			this.chBCheckRight.Enabled = enabled2;
			this.chBSetRight.Enabled = enabled2;
			this.chBTargetRight.Enabled = enabled2;
			this.btBack.Enabled = enabled;
			this.nEJumpToStep.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nECountPassMax.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			if (this.SNum == 0)
			{
				this.btPrevious.Enabled = false;
			}
			else
			{
				this.btPrevious.Enabled = true;
			}
			if (this.SNum >= this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Info.Steps - 1)
			{
				this.btNext.Enabled = false;
			}
			else
			{
				this.btNext.Enabled = true;
			}
		}

		private void InitializeValues()
		{
			this.lbProgNum.Text = this.Main.Rm.GetString("Abr_Program") + " " + this.PNum.ToString();
			this.lbProgName.Text = this.Main.CommonFunctions.UShortToString(this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Info.Name);
			this.lbStepNum.Text = this.Main.Rm.GetString("Step") + " " + (this.SNum + 1).ToString();
			this.lbStepType.Text = this.Main.Rm.GetString("OrganizingStep");
			switch (this.SD.Switch)
			{
			case 0:
				this.cBOrganizeType.SelectedIndex = 0;
				break;
			case 1000:
				this.cBOrganizeType.SelectedIndex = 0;
				break;
			case 1001:
				this.cBOrganizeType.SelectedIndex = 1;
				break;
			case 1002:
				this.cBOrganizeType.SelectedIndex = 2;
				break;
			case 1010:
				this.cBOrganizeType.SelectedIndex = 3;
				break;
			case 1011:
				this.cBOrganizeType.SelectedIndex = 4;
				break;
			case 1012:
				this.cBOrganizeType.SelectedIndex = 5;
				break;
			case 1020:
				this.cBOrganizeType.SelectedIndex = 6;
				break;
			case 1030:
				this.cBOrganizeType.SelectedIndex = 7;
				break;
			case 1040:
				this.cBOrganizeType.SelectedIndex = 8;
				break;
			default:
				MessageBox.Show("Wrong switch type in InitializeValues() of EditOrganizeStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.cBOrganizeType.SelectedIndex = 0;
				break;
			}
			this.SetOrganizeMenu();
			switch (this.SD.ModDigOut)
			{
			case 0:
				this.cBModDigOut.SelectedIndex = 0;
				this.cBDigOutKind.SelectedIndex = 0;
				break;
			case 1:
				this.cBModDigOut.SelectedIndex = 0;
				this.cBDigOutKind.SelectedIndex = 0;
				break;
			case -1:
				this.cBModDigOut.SelectedIndex = 0;
				this.cBDigOutKind.SelectedIndex = 1;
				break;
			case 2:
				this.cBModDigOut.SelectedIndex = 1;
				this.cBDigOutKind.SelectedIndex = 0;
				break;
			case -2:
				this.cBModDigOut.SelectedIndex = 1;
				this.cBDigOutKind.SelectedIndex = 1;
				break;
			case 3:
				this.cBModDigOut.SelectedIndex = 2;
				this.cBDigOutKind.SelectedIndex = 0;
				break;
			case -3:
				this.cBModDigOut.SelectedIndex = 2;
				this.cBDigOutKind.SelectedIndex = 1;
				break;
			case 4:
				this.cBModDigOut.SelectedIndex = 3;
				this.cBDigOutKind.SelectedIndex = 0;
				break;
			case -4:
				this.cBModDigOut.SelectedIndex = 3;
				this.cBDigOutKind.SelectedIndex = 1;
				break;
			default:
				MessageBox.Show("Wrong ModDigOut type in InitializeValues() of EditOrganizeStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				break;
			}
			this.recentSelectedModDigOut = this.cBModDigOut.SelectedIndex;
			this.nECountPassMax.Value = (float)(int)this.SD.CountPassMax;
			this.nEJumpToStep.MaxValue = (float)(int)this.NumberOfSteps;
			if (this.IsNewStep)
			{
				this.nEJumpToStep.Value = (float)(int)this.NumberOfSteps;
			}
			else
			{
				this.nEJumpToStep.Value = (float)(int)this.SD.JumpTo + 1f;
			}
			if ((this.SD.UserRights & 1) == 1)
			{
				this.chBTargetRight.Checked = true;
			}
			else
			{
				this.chBTargetRight.Checked = false;
			}
			if ((this.SD.UserRights & 2) == 2)
			{
				this.chBSetRight.Checked = true;
			}
			else
			{
				this.chBSetRight.Checked = false;
			}
			if ((this.SD.UserRights & 4) == 4)
			{
				this.chBCheckRight.Checked = true;
			}
			else
			{
				this.chBCheckRight.Checked = false;
			}
		}

		private bool ApplyValues()
		{
			string text = string.Empty;
			if (this.cBOrganizeType.SelectedIndex <= 2 && !this.nEJumpToStep.IsOK)
			{
				text = text + this.Main.Rm.GetString("Step") + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEJumpToStep.MinValue.ToString() + " - " + this.nEJumpToStep.MaxValue.ToString() + "\n";
			}
			if (!this.nECountPassMax.IsOK)
			{
				text = text + this.lbCountPassMax.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nECountPassMax.MinValue.ToString() + " - " + this.nECountPassMax.MaxValue.ToString() + "\n";
			}
			if (this.Main.CheckParamAllowed && text != string.Empty)
			{
				MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + text, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			switch (this.cBOrganizeType.SelectedIndex)
			{
			case 0:
				this.SD.Switch = 1000;
				break;
			case 1:
				this.SD.Switch = 1001;
				break;
			case 2:
				this.SD.Switch = 1002;
				break;
			case 3:
				this.SD.Switch = 1010;
				break;
			case 4:
				this.SD.Switch = 1011;
				break;
			case 5:
				this.SD.Switch = 1012;
				break;
			case 6:
				this.SD.Switch = 1020;
				break;
			case 7:
				this.SD.Switch = 1030;
				break;
			case 8:
				this.SD.Switch = 1040;
				break;
			default:
				MessageBox.Show("Wrong selected index 1 in ApplyValues() of EditOrganizeStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				break;
			}
			int num;
			switch (this.cBDigOutKind.SelectedIndex)
			{
			case 0:
				num = 1;
				break;
			case 1:
				num = -1;
				break;
			default:
				MessageBox.Show("Wrong selected index 2 in ApplyValues() of EditOrganizeStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				num = 1;
				break;
			}
			int num2;
			switch (this.cBModDigOut.SelectedIndex)
			{
			case 0:
				num2 = 1;
				break;
			case 1:
				num2 = 2;
				break;
			case 2:
				num2 = 3;
				break;
			case 3:
				num2 = 4;
				break;
			default:
				MessageBox.Show("Wrong selected index 3 in ApplyValues() of EditOrganizeStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				num2 = 1;
				break;
			}
			this.SD.ModDigOut = (sbyte)(num * num2);
			this.SD.CountPassMax = (byte)this.nECountPassMax.Value;
			this.SD.JumpTo = (byte)(this.nEJumpToStep.Value - 1f);
			byte b = 0;
			if (this.chBTargetRight.Checked)
			{
				b = (byte)(b + 1);
			}
			if (this.chBSetRight.Checked)
			{
				b = (byte)(b + 2);
			}
			if (this.chBCheckRight.Checked)
			{
				b = (byte)(b + 4);
			}
			this.SD.UserRights = b;
			return true;
		}

		private void SetOrganizeMenu()
		{
			switch (this.cBOrganizeType.SelectedIndex)
			{
			case 0:
				this.pnJump.Visible = true;
				this.pnModDigOut.Visible = false;
				this.gBCountPassMax.Visible = true;
				break;
			case 1:
				this.pnJump.Visible = true;
				this.pnModDigOut.Visible = false;
				this.gBCountPassMax.Visible = true;
				break;
			case 2:
				this.pnJump.Visible = true;
				this.pnModDigOut.Visible = false;
				this.gBCountPassMax.Visible = true;
				break;
			case 3:
				this.pnJump.Visible = false;
				this.pnModDigOut.Visible = false;
				this.gBCountPassMax.Visible = false;
				break;
			case 4:
				this.pnJump.Visible = false;
				this.pnModDigOut.Visible = false;
				this.gBCountPassMax.Visible = false;
				break;
			case 5:
				this.pnJump.Visible = false;
				this.pnModDigOut.Visible = false;
				this.gBCountPassMax.Visible = false;
				break;
			case 6:
				this.pnJump.Visible = false;
				this.pnModDigOut.Visible = false;
				this.gBCountPassMax.Visible = true;
				break;
			case 7:
				this.pnJump.Visible = false;
				this.pnModDigOut.Visible = true;
				this.gBCountPassMax.Visible = true;
				break;
			case 8:
				this.pnJump.Visible = false;
				this.pnModDigOut.Visible = false;
				this.gBCountPassMax.Visible = true;
				break;
			default:
				MessageBox.Show("Wrong selected index in SetOrganizeMenu() of EditOrganizeStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				break;
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.gBHeader.Select();
				this.pnMenu.Enabled = false;
				this.Main.ProcessProgram.CompareStepStruct(this.SD, this.Main.VC.PProg.Num[this.PNum].Step[this.SNum], this.PNum, this.SNum, 4);
				this.Main.StatusBarText(string.Empty);
				this.Main.StepOverview1.StepButtonShow();
				base.Hide();
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap6_4_3_StufentypOrganisation";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap6_4_3_StufentypOrganisation");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void cBOrganizeType_SelectedValueChanged(object sender, EventArgs e)
		{
			if (!this.bInitializing)
			{
				this.Main.SettingsChanged();
			}
			this.SetOrganizeMenu();
		}

		private void EditOrganizeStepForm_Activated(object sender, EventArgs e)
		{
			this.MenEna();
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.Main.DeleteLogEntries(4, this.PNum);
			this.bCanceled = true;
			this.gBHeader.Select();
			this.pnMenu.Enabled = false;
			this.Main.StatusBarText(string.Empty);
			base.Hide();
		}

		private void cBModDigOut_DrawItem(object sender, DrawItemEventArgs e)
		{
			if (Settings.Default.JawOpeningViaDigitalOutSync1)
			{
				e.DrawBackground();
				e.Graphics.DrawString(this.cBModDigOut.Items[e.Index].ToString(), this.myFont, Brushes.Black, e.Bounds);
				e.DrawFocusRectangle();
			}
			else if (e.Index == this._DISABLED_DIG_OUT)
			{
				e.Graphics.DrawString(this.cBModDigOut.Items[e.Index].ToString(), this.myFont, Brushes.LightGray, e.Bounds);
			}
			else
			{
				e.DrawBackground();
				e.Graphics.DrawString(this.cBModDigOut.Items[e.Index].ToString(), this.myFont, Brushes.Black, e.Bounds);
				e.DrawFocusRectangle();
			}
		}

		private void cBModDigOut_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (!Settings.Default.JawOpeningViaDigitalOutSync1)
			{
				if (this.cBModDigOut.SelectedIndex == this._DISABLED_DIG_OUT)
				{
					this.cBModDigOut.SelectedIndex = this.recentSelectedModDigOut;
				}
				else
				{
					this.recentSelectedModDigOut = this.cBModDigOut.SelectedIndex;
				}
			}
		}

		public void KeyArrived()
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else if (this.Main.PassCodeLevel > 0)
			{
				if (this.Main.GetExclusiveBlock1())
				{
					if (this.Main.ProcessProgram.UploadAllProgDataFromController())
					{
						this.Main.CheckParamAllowed = true;
						base.Hide();
						this.Main.StepOverview1.Hide();
					}
				}
				else
				{
					this.Main.CheckParamAllowed = false;
				}
			}
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void btPrevious_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.gBHeader.Select();
				this.pnMenu.Enabled = false;
				this.Main.ProcessProgram.CompareStepStruct(this.SD, this.Main.VC.PProg.Num[this.PNum].Step[this.SNum], this.PNum, this.SNum, 4);
				this.Main.StatusBarText(string.Empty);
				base.Hide();
				this.Main.StepOverview1.EditPreviousStep();
			}
		}

		private void btNext_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.gBHeader.Select();
				this.pnMenu.Enabled = false;
				this.Main.ProcessProgram.CompareStepStruct(this.SD, this.Main.VC.PProg.Num[this.PNum].Step[this.SNum], this.PNum, this.SNum, 4);
				this.Main.StatusBarText(string.Empty);
				base.Hide();
				this.Main.StepOverview1.EditNextStep();
			}
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.bInitializing)
			{
				this.Main.SettingsChanged();
			}
		}
	}
}
