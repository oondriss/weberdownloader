using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class FourStepOverviewForm : Form
	{
		private MainForm Main;

		private WSP1_VarComm.ProgStruct PD;

		private WSP1_VarComm.ProgStruct PD_save = new WSP1_VarComm.ProgStruct();

		private int PNum;

		private bool IsInitializeMode;

		private OpenFileDialog openFileDialog;

		private SaveFileDialog saveFileDialog;

		private Panel pnMenu;

		private Button button5;

		private Button bt2;

		private Button btHelp;

		private Button btBack;

		private Container components;

		private Button bt3;

		private Label lbProgNum;

		private Button btCancel;

		private GroupBox gBFind;

		private Label lbDescriptionFind1;

		private Button btEditFind;

		private NumberEdit1 nEFind1;

		private Label lbUnitFind1;

		private Label lbUnitFind7;

		private NumberEdit1 nEFind7;

		private Label lbDescriptionFind7;

		private Label lbUnitFind6;

		private NumberEdit1 nEFind6;

		private Label lbDescriptionFind6;

		private Label lbUnitFind5;

		private NumberEdit1 nEFind5;

		private Label lbDescriptionFind5;

		private Label lbUnitFind4;

		private NumberEdit1 nEFind4;

		private Label lbDescriptionFind4;

		private Label lbUnitFind3;

		private NumberEdit1 nEFind3;

		private Label lbDescriptionFind3;

		private Label lbUnitFind2;

		private NumberEdit1 nEFind2;

		private Label lbDescriptionFind2;

		private GroupBox gBFlowDrill;

		private Label lbUnitFlowDrill7;

		private NumberEdit1 nEFlowDrill7;

		private Label lbDescriptionFlowDrill7;

		private Button btEditFlowDrill;

		private Label lbUnitFlowDrill6;

		private NumberEdit1 nEFlowDrill6;

		private Label lbDescriptionFlowDrill6;

		private Label lbUnitFlowDrill5;

		private NumberEdit1 nEFlowDrill5;

		private Label lbDescriptionFlowDrill5;

		private Label lbUnitFlowDrill4;

		private NumberEdit1 nEFlowDrill4;

		private Label lbDescriptionFlowDrill4;

		private Label lbUnitFlowDrill3;

		private NumberEdit1 nEFlowDrill3;

		private Label lbDescriptionFlowDrill3;

		private Label lbUnitFlowDrill2;

		private NumberEdit1 nEFlowDrill2;

		private Label lbDescriptionFlowDrill2;

		private Label lbUnitFlowDrill1;

		private NumberEdit1 nEFlowDrill1;

		private Label lbDescriptionFlowDrill1;

		private GroupBox gBScrew;

		private Label lbUnitScrew7;

		private NumberEdit1 nEScrew7;

		private Label lbDescriptionScrew7;

		private Button btEditScrew;

		private Label lbUnitScrew6;

		private NumberEdit1 nEScrew6;

		private Label lbDescriptionScrew6;

		private Label lbUnitScrew5;

		private NumberEdit1 nEScrew5;

		private Label lbDescriptionScrew5;

		private Label lbUnitScrew4;

		private NumberEdit1 nEScrew4;

		private Label lbDescriptionScrew4;

		private Label lbUnitScrew3;

		private NumberEdit1 nEScrew3;

		private Label lbDescriptionScrew3;

		private Label lbUnitScrew2;

		private NumberEdit1 nEScrew2;

		private Label lbDescriptionScrew2;

		private Label lbUnitScrew1;

		private NumberEdit1 nEScrew1;

		private Label lbDescriptionScrew1;

		private GroupBox gBTighten;

		private Label lbUnitTighten7;

		private NumberEdit1 nETighten7;

		private Label lbDescriptionTighten7;

		private Button btEditTighten;

		private Label lbUnitTighten6;

		private NumberEdit1 nETighten6;

		private Label lbDescriptionTighten6;

		private Label lbUnitTighten5;

		private NumberEdit1 nETighten5;

		private Label lbDescriptionTighten5;

		private Label lbUnitTighten4;

		private NumberEdit1 nETighten4;

		private Label lbDescriptionTighten4;

		private Label lbUnitTighten3;

		private NumberEdit1 nETighten3;

		private Label lbDescriptionTighten3;

		private Label lbUnitTighten2;

		private NumberEdit1 nETighten2;

		private Label lbDescriptionTighten2;

		private Label lbUnitTighten1;

		private NumberEdit1 nETighten1;

		private Label lbDescriptionTighten1;

		private bool bCanceled;

		private Button btStoreSettings;

		private Button btLoadSettings;

		private Label lbProgName;

		private PictureBox pBoxScrew;

		private PictureBox pictureBox1;

		private PictureBox pictureBox2;

		private PictureBox pictureBox3;

		private string[] fourStepNames = new string[4];

		private bool errorReading4StepData;

		public bool WasCanceled
		{
			get
			{
				bool result = this.bCanceled;
				this.bCanceled = false;
				return result;
			}
		}

		public int GetFourStepCount()
		{
			return this.fourStepNames.Length;
		}

		public string GetFourStepName(int index)
		{
			if (index >= this.fourStepNames.Length)
			{
				return null;
			}
			return this.fourStepNames[index];
		}

		public FourStepOverviewForm(MainForm main)
		{
			this.Main = main;
			this.openFileDialog = new OpenFileDialog();
			this.openFileDialog.Filter = "4-Step|*.w4xml|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.saveFileDialog = new SaveFileDialog();
			this.saveFileDialog.Filter = "4-Step|*.w4xml|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.InitializeComponent();
			this.PNum = 0;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(FourStepOverviewForm));
			this.pnMenu = new Panel();
			this.btStoreSettings = new Button();
			this.btLoadSettings = new Button();
			this.btCancel = new Button();
			this.button5 = new Button();
			this.bt2 = new Button();
			this.bt3 = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.lbProgNum = new Label();
			this.gBFind = new GroupBox();
			this.lbUnitFind7 = new Label();
			this.nEFind7 = new NumberEdit1();
			this.lbDescriptionFind7 = new Label();
			this.btEditFind = new Button();
			this.lbUnitFind6 = new Label();
			this.nEFind6 = new NumberEdit1();
			this.lbDescriptionFind6 = new Label();
			this.lbUnitFind5 = new Label();
			this.nEFind5 = new NumberEdit1();
			this.lbDescriptionFind5 = new Label();
			this.lbUnitFind4 = new Label();
			this.nEFind4 = new NumberEdit1();
			this.lbDescriptionFind4 = new Label();
			this.lbUnitFind3 = new Label();
			this.nEFind3 = new NumberEdit1();
			this.lbDescriptionFind3 = new Label();
			this.lbUnitFind2 = new Label();
			this.nEFind2 = new NumberEdit1();
			this.lbDescriptionFind2 = new Label();
			this.lbUnitFind1 = new Label();
			this.nEFind1 = new NumberEdit1();
			this.lbDescriptionFind1 = new Label();
			this.gBFlowDrill = new GroupBox();
			this.lbUnitFlowDrill7 = new Label();
			this.nEFlowDrill7 = new NumberEdit1();
			this.lbDescriptionFlowDrill7 = new Label();
			this.btEditFlowDrill = new Button();
			this.lbUnitFlowDrill6 = new Label();
			this.nEFlowDrill6 = new NumberEdit1();
			this.lbDescriptionFlowDrill6 = new Label();
			this.lbUnitFlowDrill5 = new Label();
			this.nEFlowDrill5 = new NumberEdit1();
			this.lbDescriptionFlowDrill5 = new Label();
			this.lbUnitFlowDrill4 = new Label();
			this.nEFlowDrill4 = new NumberEdit1();
			this.lbDescriptionFlowDrill4 = new Label();
			this.lbUnitFlowDrill3 = new Label();
			this.nEFlowDrill3 = new NumberEdit1();
			this.lbDescriptionFlowDrill3 = new Label();
			this.lbUnitFlowDrill2 = new Label();
			this.nEFlowDrill2 = new NumberEdit1();
			this.lbDescriptionFlowDrill2 = new Label();
			this.lbUnitFlowDrill1 = new Label();
			this.nEFlowDrill1 = new NumberEdit1();
			this.lbDescriptionFlowDrill1 = new Label();
			this.gBScrew = new GroupBox();
			this.lbUnitScrew7 = new Label();
			this.nEScrew7 = new NumberEdit1();
			this.lbDescriptionScrew7 = new Label();
			this.btEditScrew = new Button();
			this.lbUnitScrew6 = new Label();
			this.nEScrew6 = new NumberEdit1();
			this.lbDescriptionScrew6 = new Label();
			this.lbUnitScrew5 = new Label();
			this.nEScrew5 = new NumberEdit1();
			this.lbDescriptionScrew5 = new Label();
			this.lbUnitScrew4 = new Label();
			this.nEScrew4 = new NumberEdit1();
			this.lbDescriptionScrew4 = new Label();
			this.lbUnitScrew3 = new Label();
			this.nEScrew3 = new NumberEdit1();
			this.lbDescriptionScrew3 = new Label();
			this.lbUnitScrew2 = new Label();
			this.nEScrew2 = new NumberEdit1();
			this.lbDescriptionScrew2 = new Label();
			this.lbUnitScrew1 = new Label();
			this.nEScrew1 = new NumberEdit1();
			this.lbDescriptionScrew1 = new Label();
			this.gBTighten = new GroupBox();
			this.lbUnitTighten7 = new Label();
			this.nETighten7 = new NumberEdit1();
			this.lbDescriptionTighten7 = new Label();
			this.btEditTighten = new Button();
			this.lbUnitTighten6 = new Label();
			this.nETighten6 = new NumberEdit1();
			this.lbDescriptionTighten6 = new Label();
			this.lbUnitTighten5 = new Label();
			this.nETighten5 = new NumberEdit1();
			this.lbDescriptionTighten5 = new Label();
			this.lbUnitTighten4 = new Label();
			this.nETighten4 = new NumberEdit1();
			this.lbDescriptionTighten4 = new Label();
			this.lbUnitTighten3 = new Label();
			this.nETighten3 = new NumberEdit1();
			this.lbDescriptionTighten3 = new Label();
			this.lbUnitTighten2 = new Label();
			this.nETighten2 = new NumberEdit1();
			this.lbDescriptionTighten2 = new Label();
			this.lbUnitTighten1 = new Label();
			this.nETighten1 = new NumberEdit1();
			this.lbDescriptionTighten1 = new Label();
			this.lbProgName = new Label();
			this.pictureBox3 = new PictureBox();
			this.pictureBox2 = new PictureBox();
			this.pictureBox1 = new PictureBox();
			this.pBoxScrew = new PictureBox();
			this.pnMenu.SuspendLayout();
			this.gBFind.SuspendLayout();
			this.gBFlowDrill.SuspendLayout();
			this.gBScrew.SuspendLayout();
			this.gBTighten.SuspendLayout();
			((ISupportInitialize)this.pictureBox3).BeginInit();
			((ISupportInitialize)this.pictureBox2).BeginInit();
			((ISupportInitialize)this.pictureBox1).BeginInit();
			((ISupportInitialize)this.pBoxScrew).BeginInit();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btStoreSettings);
			this.pnMenu.Controls.Add(this.btLoadSettings);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.button5);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btStoreSettings.Location = new Point(3, 322);
			this.btStoreSettings.Name = "btStoreSettings";
			this.btStoreSettings.Size = new Size(74, 62);
			this.btStoreSettings.TabIndex = 5;
			this.btStoreSettings.Text = "Store settings";
			this.btStoreSettings.Click += this.btStoreSettings_Click;
			this.btLoadSettings.Location = new Point(3, 386);
			this.btLoadSettings.Name = "btLoadSettings";
			this.btLoadSettings.Size = new Size(74, 62);
			this.btLoadSettings.TabIndex = 6;
			this.btLoadSettings.Text = "Load Settings";
			this.btLoadSettings.Click += this.btLoadSettings_Click;
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 7;
			this.btCancel.Text = "Abbruch";
			this.btCancel.Click += this.btCancel_Click;
			this.button5.Enabled = false;
			this.button5.Location = new Point(3, 259);
			this.button5.Name = "button5";
			this.button5.Size = new Size(74, 62);
			this.button5.TabIndex = 4;
			this.bt2.Enabled = false;
			this.bt2.Location = new Point(3, 195);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 3;
			this.bt3.Location = new Point(3, 131);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 2;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btHelp.Enter += this.Start_Input;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Fertig";
			this.btBack.Click += this.btBack_Click;
			this.btBack.Enter += this.Start_Input;
			this.lbProgNum.BackColor = Color.Transparent;
			this.lbProgNum.BorderStyle = BorderStyle.Fixed3D;
			this.lbProgNum.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgNum.Location = new Point(14, 22);
			this.lbProgNum.Name = "lbProgNum";
			this.lbProgNum.Size = new Size(89, 23);
			this.lbProgNum.TabIndex = 17;
			this.lbProgNum.Text = "Prog. 1023";
			this.lbProgNum.TextAlign = ContentAlignment.MiddleLeft;
			this.lbProgNum.Visible = false;
			this.gBFind.Controls.Add(this.lbUnitFind7);
			this.gBFind.Controls.Add(this.nEFind7);
			this.gBFind.Controls.Add(this.lbDescriptionFind7);
			this.gBFind.Controls.Add(this.btEditFind);
			this.gBFind.Controls.Add(this.lbUnitFind6);
			this.gBFind.Controls.Add(this.nEFind6);
			this.gBFind.Controls.Add(this.lbDescriptionFind6);
			this.gBFind.Controls.Add(this.lbUnitFind5);
			this.gBFind.Controls.Add(this.nEFind5);
			this.gBFind.Controls.Add(this.lbDescriptionFind5);
			this.gBFind.Controls.Add(this.lbUnitFind4);
			this.gBFind.Controls.Add(this.nEFind4);
			this.gBFind.Controls.Add(this.lbDescriptionFind4);
			this.gBFind.Controls.Add(this.lbUnitFind3);
			this.gBFind.Controls.Add(this.nEFind3);
			this.gBFind.Controls.Add(this.lbDescriptionFind3);
			this.gBFind.Controls.Add(this.lbUnitFind2);
			this.gBFind.Controls.Add(this.nEFind2);
			this.gBFind.Controls.Add(this.lbDescriptionFind2);
			this.gBFind.Controls.Add(this.lbUnitFind1);
			this.gBFind.Controls.Add(this.nEFind1);
			this.gBFind.Controls.Add(this.lbDescriptionFind1);
			this.gBFind.FlatStyle = FlatStyle.Popup;
			this.gBFind.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.gBFind.Location = new Point(14, 92);
			this.gBFind.Name = "gBFind";
			this.gBFind.Size = new Size(170, 424);
			this.gBFind.TabIndex = 2;
			this.gBFind.TabStop = false;
			this.gBFind.Text = "Finden";
			this.lbUnitFind7.AutoSize = true;
			this.lbUnitFind7.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFind7.Location = new Point(121, 363);
			this.lbUnitFind7.Name = "lbUnitFind7";
			this.lbUnitFind7.Size = new Size(46, 16);
			this.lbUnitFind7.TabIndex = 45;
			this.lbUnitFind7.Text = "Einheit";
			this.nEFind7.BackColor = Color.White;
			this.nEFind7.DecimalNum = 0;
			this.nEFind7.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFind7.ForeColor = SystemColors.ControlText;
			this.nEFind7.Location = new Point(9, 356);
			this.nEFind7.MaxValue = 10f;
			this.nEFind7.MinValue = 0f;
			this.nEFind7.Name = "nEFind7";
			this.nEFind7.Size = new Size(104, 28);
			this.nEFind7.TabIndex = 6;
			this.nEFind7.Text = "0";
			this.nEFind7.TextAlign = HorizontalAlignment.Right;
			this.nEFind7.Value = 0f;
			this.nEFind7.TextChanged += this.settingsChanged;
			this.nEFind7.Enter += this.Start_Input;
			this.nEFind7.MouseDown += this.StartInput;
			this.lbDescriptionFind7.AutoSize = true;
			this.lbDescriptionFind7.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFind7.Location = new Point(6, 335);
			this.lbDescriptionFind7.Name = "lbDescriptionFind7";
			this.lbDescriptionFind7.Size = new Size(56, 16);
			this.lbDescriptionFind7.TabIndex = 43;
			this.lbDescriptionFind7.Text = "Finden 7";
			this.btEditFind.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.btEditFind.Location = new Point(9, 395);
			this.btEditFind.Name = "btEditFind";
			this.btEditFind.Size = new Size(151, 23);
			this.btEditFind.TabIndex = 7;
			this.btEditFind.Text = "Bearbeiten";
			this.btEditFind.UseVisualStyleBackColor = true;
			this.btEditFind.Click += this.btEditFind_Click;
			this.lbUnitFind6.AutoSize = true;
			this.lbUnitFind6.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFind6.Location = new Point(121, 311);
			this.lbUnitFind6.Name = "lbUnitFind6";
			this.lbUnitFind6.Size = new Size(46, 16);
			this.lbUnitFind6.TabIndex = 42;
			this.lbUnitFind6.Text = "Einheit";
			this.nEFind6.BackColor = Color.White;
			this.nEFind6.DecimalNum = 0;
			this.nEFind6.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFind6.ForeColor = SystemColors.ControlText;
			this.nEFind6.Location = new Point(9, 304);
			this.nEFind6.MaxValue = 10f;
			this.nEFind6.MinValue = 0f;
			this.nEFind6.Name = "nEFind6";
			this.nEFind6.Size = new Size(104, 28);
			this.nEFind6.TabIndex = 5;
			this.nEFind6.Text = "0";
			this.nEFind6.TextAlign = HorizontalAlignment.Right;
			this.nEFind6.Value = 0f;
			this.nEFind6.TextChanged += this.settingsChanged;
			this.nEFind6.Enter += this.Start_Input;
			this.nEFind6.MouseDown += this.StartInput;
			this.lbDescriptionFind6.AutoSize = true;
			this.lbDescriptionFind6.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFind6.Location = new Point(6, 283);
			this.lbDescriptionFind6.Name = "lbDescriptionFind6";
			this.lbDescriptionFind6.Size = new Size(56, 16);
			this.lbDescriptionFind6.TabIndex = 40;
			this.lbDescriptionFind6.Text = "Finden 6";
			this.lbUnitFind5.AutoSize = true;
			this.lbUnitFind5.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFind5.Location = new Point(121, 258);
			this.lbUnitFind5.Name = "lbUnitFind5";
			this.lbUnitFind5.Size = new Size(46, 16);
			this.lbUnitFind5.TabIndex = 39;
			this.lbUnitFind5.Text = "Einheit";
			this.nEFind5.BackColor = Color.White;
			this.nEFind5.DecimalNum = 0;
			this.nEFind5.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFind5.ForeColor = SystemColors.ControlText;
			this.nEFind5.Location = new Point(9, 251);
			this.nEFind5.MaxValue = 10f;
			this.nEFind5.MinValue = 0f;
			this.nEFind5.Name = "nEFind5";
			this.nEFind5.Size = new Size(104, 28);
			this.nEFind5.TabIndex = 4;
			this.nEFind5.Text = "0";
			this.nEFind5.TextAlign = HorizontalAlignment.Right;
			this.nEFind5.Value = 0f;
			this.nEFind5.TextChanged += this.settingsChanged;
			this.nEFind5.Enter += this.Start_Input;
			this.nEFind5.MouseDown += this.StartInput;
			this.lbDescriptionFind5.AutoSize = true;
			this.lbDescriptionFind5.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFind5.Location = new Point(6, 230);
			this.lbDescriptionFind5.Name = "lbDescriptionFind5";
			this.lbDescriptionFind5.Size = new Size(56, 16);
			this.lbDescriptionFind5.TabIndex = 37;
			this.lbDescriptionFind5.Text = "Finden 5";
			this.lbUnitFind4.AutoSize = true;
			this.lbUnitFind4.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFind4.Location = new Point(121, 205);
			this.lbUnitFind4.Name = "lbUnitFind4";
			this.lbUnitFind4.Size = new Size(46, 16);
			this.lbUnitFind4.TabIndex = 36;
			this.lbUnitFind4.Text = "Einheit";
			this.nEFind4.BackColor = Color.White;
			this.nEFind4.DecimalNum = 0;
			this.nEFind4.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFind4.ForeColor = SystemColors.ControlText;
			this.nEFind4.Location = new Point(9, 198);
			this.nEFind4.MaxValue = 10f;
			this.nEFind4.MinValue = 0f;
			this.nEFind4.Name = "nEFind4";
			this.nEFind4.Size = new Size(104, 28);
			this.nEFind4.TabIndex = 3;
			this.nEFind4.Text = "0";
			this.nEFind4.TextAlign = HorizontalAlignment.Right;
			this.nEFind4.Value = 0f;
			this.nEFind4.TextChanged += this.settingsChanged;
			this.nEFind4.Enter += this.Start_Input;
			this.nEFind4.MouseDown += this.StartInput;
			this.lbDescriptionFind4.AutoSize = true;
			this.lbDescriptionFind4.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFind4.Location = new Point(6, 177);
			this.lbDescriptionFind4.Name = "lbDescriptionFind4";
			this.lbDescriptionFind4.Size = new Size(56, 16);
			this.lbDescriptionFind4.TabIndex = 34;
			this.lbDescriptionFind4.Text = "Finden 4";
			this.lbUnitFind3.AutoSize = true;
			this.lbUnitFind3.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFind3.Location = new Point(121, 153);
			this.lbUnitFind3.Name = "lbUnitFind3";
			this.lbUnitFind3.Size = new Size(46, 16);
			this.lbUnitFind3.TabIndex = 33;
			this.lbUnitFind3.Text = "Einheit";
			this.nEFind3.BackColor = Color.White;
			this.nEFind3.DecimalNum = 0;
			this.nEFind3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFind3.ForeColor = SystemColors.ControlText;
			this.nEFind3.Location = new Point(9, 146);
			this.nEFind3.MaxValue = 10f;
			this.nEFind3.MinValue = 0f;
			this.nEFind3.Name = "nEFind3";
			this.nEFind3.Size = new Size(104, 28);
			this.nEFind3.TabIndex = 2;
			this.nEFind3.Text = "0";
			this.nEFind3.TextAlign = HorizontalAlignment.Right;
			this.nEFind3.Value = 0f;
			this.nEFind3.TextChanged += this.settingsChanged;
			this.nEFind3.Enter += this.Start_Input;
			this.nEFind3.MouseDown += this.StartInput;
			this.lbDescriptionFind3.AutoSize = true;
			this.lbDescriptionFind3.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFind3.Location = new Point(6, 125);
			this.lbDescriptionFind3.Name = "lbDescriptionFind3";
			this.lbDescriptionFind3.Size = new Size(56, 16);
			this.lbDescriptionFind3.TabIndex = 31;
			this.lbDescriptionFind3.Text = "Finden 3";
			this.lbUnitFind2.AutoSize = true;
			this.lbUnitFind2.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFind2.Location = new Point(121, 100);
			this.lbUnitFind2.Name = "lbUnitFind2";
			this.lbUnitFind2.Size = new Size(46, 16);
			this.lbUnitFind2.TabIndex = 30;
			this.lbUnitFind2.Text = "Einheit";
			this.nEFind2.BackColor = Color.White;
			this.nEFind2.DecimalNum = 0;
			this.nEFind2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFind2.ForeColor = SystemColors.ControlText;
			this.nEFind2.Location = new Point(9, 93);
			this.nEFind2.MaxValue = 10f;
			this.nEFind2.MinValue = 0f;
			this.nEFind2.Name = "nEFind2";
			this.nEFind2.Size = new Size(104, 28);
			this.nEFind2.TabIndex = 1;
			this.nEFind2.Text = "0";
			this.nEFind2.TextAlign = HorizontalAlignment.Right;
			this.nEFind2.Value = 0f;
			this.nEFind2.TextChanged += this.settingsChanged;
			this.nEFind2.Enter += this.Start_Input;
			this.nEFind2.MouseDown += this.StartInput;
			this.lbDescriptionFind2.AutoSize = true;
			this.lbDescriptionFind2.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFind2.Location = new Point(6, 72);
			this.lbDescriptionFind2.Name = "lbDescriptionFind2";
			this.lbDescriptionFind2.Size = new Size(56, 16);
			this.lbDescriptionFind2.TabIndex = 28;
			this.lbDescriptionFind2.Text = "Finden 2";
			this.lbUnitFind1.AutoSize = true;
			this.lbUnitFind1.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFind1.Location = new Point(121, 50);
			this.lbUnitFind1.Name = "lbUnitFind1";
			this.lbUnitFind1.Size = new Size(46, 16);
			this.lbUnitFind1.TabIndex = 27;
			this.lbUnitFind1.Text = "Einheit";
			this.nEFind1.BackColor = Color.White;
			this.nEFind1.DecimalNum = 3;
			this.nEFind1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFind1.ForeColor = SystemColors.ControlText;
			this.nEFind1.Location = new Point(9, 43);
			this.nEFind1.MaxValue = 10f;
			this.nEFind1.MinValue = 0f;
			this.nEFind1.Name = "nEFind1";
			this.nEFind1.Size = new Size(104, 28);
			this.nEFind1.TabIndex = 0;
			this.nEFind1.Text = "2,000";
			this.nEFind1.TextAlign = HorizontalAlignment.Right;
			this.nEFind1.Value = 2f;
			this.nEFind1.TextChanged += this.settingsChanged;
			this.nEFind1.Enter += this.Start_Input;
			this.nEFind1.MouseDown += this.StartInput;
			this.lbDescriptionFind1.AutoSize = true;
			this.lbDescriptionFind1.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFind1.Location = new Point(6, 22);
			this.lbDescriptionFind1.Name = "lbDescriptionFind1";
			this.lbDescriptionFind1.Size = new Size(75, 16);
			this.lbDescriptionFind1.TabIndex = 3;
			this.lbDescriptionFind1.Text = "Zylinderkraft";
			this.gBFlowDrill.Controls.Add(this.lbUnitFlowDrill7);
			this.gBFlowDrill.Controls.Add(this.nEFlowDrill7);
			this.gBFlowDrill.Controls.Add(this.lbDescriptionFlowDrill7);
			this.gBFlowDrill.Controls.Add(this.btEditFlowDrill);
			this.gBFlowDrill.Controls.Add(this.lbUnitFlowDrill6);
			this.gBFlowDrill.Controls.Add(this.nEFlowDrill6);
			this.gBFlowDrill.Controls.Add(this.lbDescriptionFlowDrill6);
			this.gBFlowDrill.Controls.Add(this.lbUnitFlowDrill5);
			this.gBFlowDrill.Controls.Add(this.nEFlowDrill5);
			this.gBFlowDrill.Controls.Add(this.lbDescriptionFlowDrill5);
			this.gBFlowDrill.Controls.Add(this.lbUnitFlowDrill4);
			this.gBFlowDrill.Controls.Add(this.nEFlowDrill4);
			this.gBFlowDrill.Controls.Add(this.lbDescriptionFlowDrill4);
			this.gBFlowDrill.Controls.Add(this.lbUnitFlowDrill3);
			this.gBFlowDrill.Controls.Add(this.nEFlowDrill3);
			this.gBFlowDrill.Controls.Add(this.lbDescriptionFlowDrill3);
			this.gBFlowDrill.Controls.Add(this.lbUnitFlowDrill2);
			this.gBFlowDrill.Controls.Add(this.nEFlowDrill2);
			this.gBFlowDrill.Controls.Add(this.lbDescriptionFlowDrill2);
			this.gBFlowDrill.Controls.Add(this.lbUnitFlowDrill1);
			this.gBFlowDrill.Controls.Add(this.nEFlowDrill1);
			this.gBFlowDrill.Controls.Add(this.lbDescriptionFlowDrill1);
			this.gBFlowDrill.FlatStyle = FlatStyle.Popup;
			this.gBFlowDrill.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.gBFlowDrill.Location = new Point(188, 92);
			this.gBFlowDrill.Name = "gBFlowDrill";
			this.gBFlowDrill.Size = new Size(170, 424);
			this.gBFlowDrill.TabIndex = 3;
			this.gBFlowDrill.TabStop = false;
			this.gBFlowDrill.Text = "Flow Drill";
			this.lbUnitFlowDrill7.AutoSize = true;
			this.lbUnitFlowDrill7.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFlowDrill7.Location = new Point(121, 363);
			this.lbUnitFlowDrill7.Name = "lbUnitFlowDrill7";
			this.lbUnitFlowDrill7.Size = new Size(46, 16);
			this.lbUnitFlowDrill7.TabIndex = 45;
			this.lbUnitFlowDrill7.Text = "Einheit";
			this.nEFlowDrill7.BackColor = Color.White;
			this.nEFlowDrill7.DecimalNum = 0;
			this.nEFlowDrill7.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFlowDrill7.ForeColor = SystemColors.ControlText;
			this.nEFlowDrill7.Location = new Point(9, 356);
			this.nEFlowDrill7.MaxValue = 10f;
			this.nEFlowDrill7.MinValue = 0f;
			this.nEFlowDrill7.Name = "nEFlowDrill7";
			this.nEFlowDrill7.Size = new Size(104, 28);
			this.nEFlowDrill7.TabIndex = 6;
			this.nEFlowDrill7.Text = "0";
			this.nEFlowDrill7.TextAlign = HorizontalAlignment.Right;
			this.nEFlowDrill7.Value = 0f;
			this.nEFlowDrill7.TextChanged += this.settingsChanged;
			this.nEFlowDrill7.Enter += this.Start_Input;
			this.nEFlowDrill7.MouseDown += this.StartInput;
			this.lbDescriptionFlowDrill7.AutoSize = true;
			this.lbDescriptionFlowDrill7.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFlowDrill7.Location = new Point(6, 335);
			this.lbDescriptionFlowDrill7.Name = "lbDescriptionFlowDrill7";
			this.lbDescriptionFlowDrill7.Size = new Size(69, 16);
			this.lbDescriptionFlowDrill7.TabIndex = 43;
			this.lbDescriptionFlowDrill7.Text = "Flow Drill 7";
			this.btEditFlowDrill.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.btEditFlowDrill.Location = new Point(9, 395);
			this.btEditFlowDrill.Name = "btEditFlowDrill";
			this.btEditFlowDrill.Size = new Size(151, 23);
			this.btEditFlowDrill.TabIndex = 7;
			this.btEditFlowDrill.Text = "Bearbeiten";
			this.btEditFlowDrill.UseVisualStyleBackColor = true;
			this.btEditFlowDrill.Click += this.btEditFlowDrill_Click;
			this.lbUnitFlowDrill6.AutoSize = true;
			this.lbUnitFlowDrill6.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFlowDrill6.Location = new Point(121, 311);
			this.lbUnitFlowDrill6.Name = "lbUnitFlowDrill6";
			this.lbUnitFlowDrill6.Size = new Size(46, 16);
			this.lbUnitFlowDrill6.TabIndex = 42;
			this.lbUnitFlowDrill6.Text = "Einheit";
			this.nEFlowDrill6.BackColor = Color.White;
			this.nEFlowDrill6.DecimalNum = 0;
			this.nEFlowDrill6.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFlowDrill6.ForeColor = SystemColors.ControlText;
			this.nEFlowDrill6.Location = new Point(9, 304);
			this.nEFlowDrill6.MaxValue = 10f;
			this.nEFlowDrill6.MinValue = 0f;
			this.nEFlowDrill6.Name = "nEFlowDrill6";
			this.nEFlowDrill6.Size = new Size(104, 28);
			this.nEFlowDrill6.TabIndex = 5;
			this.nEFlowDrill6.Text = "0";
			this.nEFlowDrill6.TextAlign = HorizontalAlignment.Right;
			this.nEFlowDrill6.Value = 0f;
			this.nEFlowDrill6.TextChanged += this.settingsChanged;
			this.nEFlowDrill6.Enter += this.Start_Input;
			this.nEFlowDrill6.MouseDown += this.StartInput;
			this.lbDescriptionFlowDrill6.AutoSize = true;
			this.lbDescriptionFlowDrill6.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFlowDrill6.Location = new Point(6, 283);
			this.lbDescriptionFlowDrill6.Name = "lbDescriptionFlowDrill6";
			this.lbDescriptionFlowDrill6.Size = new Size(69, 16);
			this.lbDescriptionFlowDrill6.TabIndex = 40;
			this.lbDescriptionFlowDrill6.Text = "Flow Drill 6";
			this.lbUnitFlowDrill5.AutoSize = true;
			this.lbUnitFlowDrill5.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFlowDrill5.Location = new Point(121, 258);
			this.lbUnitFlowDrill5.Name = "lbUnitFlowDrill5";
			this.lbUnitFlowDrill5.Size = new Size(46, 16);
			this.lbUnitFlowDrill5.TabIndex = 39;
			this.lbUnitFlowDrill5.Text = "Einheit";
			this.nEFlowDrill5.BackColor = Color.White;
			this.nEFlowDrill5.DecimalNum = 0;
			this.nEFlowDrill5.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFlowDrill5.ForeColor = SystemColors.ControlText;
			this.nEFlowDrill5.Location = new Point(9, 251);
			this.nEFlowDrill5.MaxValue = 10f;
			this.nEFlowDrill5.MinValue = 0f;
			this.nEFlowDrill5.Name = "nEFlowDrill5";
			this.nEFlowDrill5.Size = new Size(104, 28);
			this.nEFlowDrill5.TabIndex = 4;
			this.nEFlowDrill5.Text = "0";
			this.nEFlowDrill5.TextAlign = HorizontalAlignment.Right;
			this.nEFlowDrill5.Value = 0f;
			this.nEFlowDrill5.TextChanged += this.settingsChanged;
			this.nEFlowDrill5.Enter += this.Start_Input;
			this.nEFlowDrill5.MouseDown += this.StartInput;
			this.lbDescriptionFlowDrill5.AutoSize = true;
			this.lbDescriptionFlowDrill5.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFlowDrill5.Location = new Point(6, 230);
			this.lbDescriptionFlowDrill5.Name = "lbDescriptionFlowDrill5";
			this.lbDescriptionFlowDrill5.Size = new Size(69, 16);
			this.lbDescriptionFlowDrill5.TabIndex = 37;
			this.lbDescriptionFlowDrill5.Text = "Flow Drill 5";
			this.lbUnitFlowDrill4.AutoSize = true;
			this.lbUnitFlowDrill4.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFlowDrill4.Location = new Point(121, 205);
			this.lbUnitFlowDrill4.Name = "lbUnitFlowDrill4";
			this.lbUnitFlowDrill4.Size = new Size(46, 16);
			this.lbUnitFlowDrill4.TabIndex = 36;
			this.lbUnitFlowDrill4.Text = "Einheit";
			this.nEFlowDrill4.BackColor = Color.White;
			this.nEFlowDrill4.DecimalNum = 0;
			this.nEFlowDrill4.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFlowDrill4.ForeColor = SystemColors.ControlText;
			this.nEFlowDrill4.Location = new Point(9, 198);
			this.nEFlowDrill4.MaxValue = 10f;
			this.nEFlowDrill4.MinValue = 0f;
			this.nEFlowDrill4.Name = "nEFlowDrill4";
			this.nEFlowDrill4.Size = new Size(104, 28);
			this.nEFlowDrill4.TabIndex = 3;
			this.nEFlowDrill4.Text = "0";
			this.nEFlowDrill4.TextAlign = HorizontalAlignment.Right;
			this.nEFlowDrill4.Value = 0f;
			this.nEFlowDrill4.TextChanged += this.settingsChanged;
			this.nEFlowDrill4.Enter += this.Start_Input;
			this.nEFlowDrill4.MouseDown += this.StartInput;
			this.lbDescriptionFlowDrill4.AutoSize = true;
			this.lbDescriptionFlowDrill4.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFlowDrill4.Location = new Point(6, 177);
			this.lbDescriptionFlowDrill4.Name = "lbDescriptionFlowDrill4";
			this.lbDescriptionFlowDrill4.Size = new Size(69, 16);
			this.lbDescriptionFlowDrill4.TabIndex = 34;
			this.lbDescriptionFlowDrill4.Text = "Flow Drill 4";
			this.lbUnitFlowDrill3.AutoSize = true;
			this.lbUnitFlowDrill3.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFlowDrill3.Location = new Point(121, 153);
			this.lbUnitFlowDrill3.Name = "lbUnitFlowDrill3";
			this.lbUnitFlowDrill3.Size = new Size(46, 16);
			this.lbUnitFlowDrill3.TabIndex = 33;
			this.lbUnitFlowDrill3.Text = "Einheit";
			this.nEFlowDrill3.BackColor = Color.White;
			this.nEFlowDrill3.DecimalNum = 0;
			this.nEFlowDrill3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFlowDrill3.ForeColor = SystemColors.ControlText;
			this.nEFlowDrill3.Location = new Point(9, 146);
			this.nEFlowDrill3.MaxValue = 10f;
			this.nEFlowDrill3.MinValue = 0f;
			this.nEFlowDrill3.Name = "nEFlowDrill3";
			this.nEFlowDrill3.Size = new Size(104, 28);
			this.nEFlowDrill3.TabIndex = 2;
			this.nEFlowDrill3.Text = "0";
			this.nEFlowDrill3.TextAlign = HorizontalAlignment.Right;
			this.nEFlowDrill3.Value = 0f;
			this.nEFlowDrill3.TextChanged += this.settingsChanged;
			this.nEFlowDrill3.Enter += this.Start_Input;
			this.nEFlowDrill3.MouseDown += this.StartInput;
			this.lbDescriptionFlowDrill3.AutoSize = true;
			this.lbDescriptionFlowDrill3.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFlowDrill3.Location = new Point(6, 125);
			this.lbDescriptionFlowDrill3.Name = "lbDescriptionFlowDrill3";
			this.lbDescriptionFlowDrill3.Size = new Size(69, 16);
			this.lbDescriptionFlowDrill3.TabIndex = 31;
			this.lbDescriptionFlowDrill3.Text = "Flow Drill 3";
			this.lbUnitFlowDrill2.AutoSize = true;
			this.lbUnitFlowDrill2.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFlowDrill2.Location = new Point(121, 100);
			this.lbUnitFlowDrill2.Name = "lbUnitFlowDrill2";
			this.lbUnitFlowDrill2.Size = new Size(46, 16);
			this.lbUnitFlowDrill2.TabIndex = 30;
			this.lbUnitFlowDrill2.Text = "Einheit";
			this.nEFlowDrill2.BackColor = Color.White;
			this.nEFlowDrill2.DecimalNum = 0;
			this.nEFlowDrill2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFlowDrill2.ForeColor = SystemColors.ControlText;
			this.nEFlowDrill2.Location = new Point(9, 93);
			this.nEFlowDrill2.MaxValue = 10f;
			this.nEFlowDrill2.MinValue = 0f;
			this.nEFlowDrill2.Name = "nEFlowDrill2";
			this.nEFlowDrill2.Size = new Size(104, 28);
			this.nEFlowDrill2.TabIndex = 1;
			this.nEFlowDrill2.Text = "0";
			this.nEFlowDrill2.TextAlign = HorizontalAlignment.Right;
			this.nEFlowDrill2.Value = 0f;
			this.nEFlowDrill2.TextChanged += this.settingsChanged;
			this.nEFlowDrill2.Enter += this.Start_Input;
			this.nEFlowDrill2.MouseDown += this.StartInput;
			this.lbDescriptionFlowDrill2.AutoSize = true;
			this.lbDescriptionFlowDrill2.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFlowDrill2.Location = new Point(6, 72);
			this.lbDescriptionFlowDrill2.Name = "lbDescriptionFlowDrill2";
			this.lbDescriptionFlowDrill2.Size = new Size(69, 16);
			this.lbDescriptionFlowDrill2.TabIndex = 28;
			this.lbDescriptionFlowDrill2.Text = "Flow Drill 2";
			this.lbUnitFlowDrill1.AutoSize = true;
			this.lbUnitFlowDrill1.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitFlowDrill1.Location = new Point(121, 50);
			this.lbUnitFlowDrill1.Name = "lbUnitFlowDrill1";
			this.lbUnitFlowDrill1.Size = new Size(46, 16);
			this.lbUnitFlowDrill1.TabIndex = 27;
			this.lbUnitFlowDrill1.Text = "Einheit";
			this.nEFlowDrill1.BackColor = Color.White;
			this.nEFlowDrill1.DecimalNum = 3;
			this.nEFlowDrill1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFlowDrill1.ForeColor = SystemColors.ControlText;
			this.nEFlowDrill1.Location = new Point(9, 43);
			this.nEFlowDrill1.MaxValue = 10f;
			this.nEFlowDrill1.MinValue = 0f;
			this.nEFlowDrill1.Name = "nEFlowDrill1";
			this.nEFlowDrill1.Size = new Size(104, 28);
			this.nEFlowDrill1.TabIndex = 0;
			this.nEFlowDrill1.Text = "2,000";
			this.nEFlowDrill1.TextAlign = HorizontalAlignment.Right;
			this.nEFlowDrill1.Value = 2f;
			this.nEFlowDrill1.TextChanged += this.settingsChanged;
			this.nEFlowDrill1.Enter += this.Start_Input;
			this.nEFlowDrill1.MouseDown += this.StartInput;
			this.lbDescriptionFlowDrill1.AutoSize = true;
			this.lbDescriptionFlowDrill1.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionFlowDrill1.Location = new Point(6, 22);
			this.lbDescriptionFlowDrill1.Name = "lbDescriptionFlowDrill1";
			this.lbDescriptionFlowDrill1.Size = new Size(75, 16);
			this.lbDescriptionFlowDrill1.TabIndex = 3;
			this.lbDescriptionFlowDrill1.Text = "Zylinderkraft";
			this.gBScrew.Controls.Add(this.lbUnitScrew7);
			this.gBScrew.Controls.Add(this.nEScrew7);
			this.gBScrew.Controls.Add(this.lbDescriptionScrew7);
			this.gBScrew.Controls.Add(this.btEditScrew);
			this.gBScrew.Controls.Add(this.lbUnitScrew6);
			this.gBScrew.Controls.Add(this.nEScrew6);
			this.gBScrew.Controls.Add(this.lbDescriptionScrew6);
			this.gBScrew.Controls.Add(this.lbUnitScrew5);
			this.gBScrew.Controls.Add(this.nEScrew5);
			this.gBScrew.Controls.Add(this.lbDescriptionScrew5);
			this.gBScrew.Controls.Add(this.lbUnitScrew4);
			this.gBScrew.Controls.Add(this.nEScrew4);
			this.gBScrew.Controls.Add(this.lbDescriptionScrew4);
			this.gBScrew.Controls.Add(this.lbUnitScrew3);
			this.gBScrew.Controls.Add(this.nEScrew3);
			this.gBScrew.Controls.Add(this.lbDescriptionScrew3);
			this.gBScrew.Controls.Add(this.lbUnitScrew2);
			this.gBScrew.Controls.Add(this.nEScrew2);
			this.gBScrew.Controls.Add(this.lbDescriptionScrew2);
			this.gBScrew.Controls.Add(this.lbUnitScrew1);
			this.gBScrew.Controls.Add(this.nEScrew1);
			this.gBScrew.Controls.Add(this.lbDescriptionScrew1);
			this.gBScrew.FlatStyle = FlatStyle.Popup;
			this.gBScrew.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.gBScrew.Location = new Point(362, 92);
			this.gBScrew.Name = "gBScrew";
			this.gBScrew.Size = new Size(170, 424);
			this.gBScrew.TabIndex = 4;
			this.gBScrew.TabStop = false;
			this.gBScrew.Text = "Schrauben";
			this.lbUnitScrew7.AutoSize = true;
			this.lbUnitScrew7.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitScrew7.Location = new Point(121, 363);
			this.lbUnitScrew7.Name = "lbUnitScrew7";
			this.lbUnitScrew7.Size = new Size(46, 16);
			this.lbUnitScrew7.TabIndex = 45;
			this.lbUnitScrew7.Text = "Einheit";
			this.nEScrew7.BackColor = Color.White;
			this.nEScrew7.DecimalNum = 0;
			this.nEScrew7.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEScrew7.ForeColor = SystemColors.ControlText;
			this.nEScrew7.Location = new Point(9, 356);
			this.nEScrew7.MaxValue = 10f;
			this.nEScrew7.MinValue = 0f;
			this.nEScrew7.Name = "nEScrew7";
			this.nEScrew7.Size = new Size(104, 28);
			this.nEScrew7.TabIndex = 6;
			this.nEScrew7.Text = "0";
			this.nEScrew7.TextAlign = HorizontalAlignment.Right;
			this.nEScrew7.Value = 0f;
			this.nEScrew7.TextChanged += this.settingsChanged;
			this.nEScrew7.Enter += this.Start_Input;
			this.nEScrew7.MouseDown += this.StartInput;
			this.lbDescriptionScrew7.AutoSize = true;
			this.lbDescriptionScrew7.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionScrew7.Location = new Point(6, 335);
			this.lbDescriptionScrew7.Name = "lbDescriptionScrew7";
			this.lbDescriptionScrew7.Size = new Size(78, 16);
			this.lbDescriptionScrew7.TabIndex = 43;
			this.lbDescriptionScrew7.Text = "Schrauben 7";
			this.btEditScrew.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.btEditScrew.Location = new Point(9, 395);
			this.btEditScrew.Name = "btEditScrew";
			this.btEditScrew.Size = new Size(151, 23);
			this.btEditScrew.TabIndex = 7;
			this.btEditScrew.Text = "Bearbeiten";
			this.btEditScrew.UseVisualStyleBackColor = true;
			this.btEditScrew.Click += this.btEditScrew_Click;
			this.lbUnitScrew6.AutoSize = true;
			this.lbUnitScrew6.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitScrew6.Location = new Point(121, 311);
			this.lbUnitScrew6.Name = "lbUnitScrew6";
			this.lbUnitScrew6.Size = new Size(46, 16);
			this.lbUnitScrew6.TabIndex = 42;
			this.lbUnitScrew6.Text = "Einheit";
			this.nEScrew6.BackColor = Color.White;
			this.nEScrew6.DecimalNum = 0;
			this.nEScrew6.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEScrew6.ForeColor = SystemColors.ControlText;
			this.nEScrew6.Location = new Point(9, 304);
			this.nEScrew6.MaxValue = 10f;
			this.nEScrew6.MinValue = 0f;
			this.nEScrew6.Name = "nEScrew6";
			this.nEScrew6.Size = new Size(104, 28);
			this.nEScrew6.TabIndex = 5;
			this.nEScrew6.Text = "0";
			this.nEScrew6.TextAlign = HorizontalAlignment.Right;
			this.nEScrew6.Value = 0f;
			this.nEScrew6.TextChanged += this.settingsChanged;
			this.nEScrew6.Enter += this.Start_Input;
			this.nEScrew6.MouseDown += this.StartInput;
			this.lbDescriptionScrew6.AutoSize = true;
			this.lbDescriptionScrew6.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionScrew6.Location = new Point(6, 283);
			this.lbDescriptionScrew6.Name = "lbDescriptionScrew6";
			this.lbDescriptionScrew6.Size = new Size(78, 16);
			this.lbDescriptionScrew6.TabIndex = 40;
			this.lbDescriptionScrew6.Text = "Schrauben 6";
			this.lbUnitScrew5.AutoSize = true;
			this.lbUnitScrew5.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitScrew5.Location = new Point(121, 258);
			this.lbUnitScrew5.Name = "lbUnitScrew5";
			this.lbUnitScrew5.Size = new Size(46, 16);
			this.lbUnitScrew5.TabIndex = 39;
			this.lbUnitScrew5.Text = "Einheit";
			this.nEScrew5.BackColor = Color.White;
			this.nEScrew5.DecimalNum = 0;
			this.nEScrew5.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEScrew5.ForeColor = SystemColors.ControlText;
			this.nEScrew5.Location = new Point(9, 251);
			this.nEScrew5.MaxValue = 10f;
			this.nEScrew5.MinValue = 0f;
			this.nEScrew5.Name = "nEScrew5";
			this.nEScrew5.Size = new Size(104, 28);
			this.nEScrew5.TabIndex = 4;
			this.nEScrew5.Text = "0";
			this.nEScrew5.TextAlign = HorizontalAlignment.Right;
			this.nEScrew5.Value = 0f;
			this.nEScrew5.TextChanged += this.settingsChanged;
			this.nEScrew5.Enter += this.Start_Input;
			this.nEScrew5.MouseDown += this.StartInput;
			this.lbDescriptionScrew5.AutoSize = true;
			this.lbDescriptionScrew5.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionScrew5.Location = new Point(6, 230);
			this.lbDescriptionScrew5.Name = "lbDescriptionScrew5";
			this.lbDescriptionScrew5.Size = new Size(78, 16);
			this.lbDescriptionScrew5.TabIndex = 37;
			this.lbDescriptionScrew5.Text = "Schrauben 5";
			this.lbUnitScrew4.AutoSize = true;
			this.lbUnitScrew4.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitScrew4.Location = new Point(121, 205);
			this.lbUnitScrew4.Name = "lbUnitScrew4";
			this.lbUnitScrew4.Size = new Size(46, 16);
			this.lbUnitScrew4.TabIndex = 36;
			this.lbUnitScrew4.Text = "Einheit";
			this.nEScrew4.BackColor = Color.White;
			this.nEScrew4.DecimalNum = 0;
			this.nEScrew4.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEScrew4.ForeColor = SystemColors.ControlText;
			this.nEScrew4.Location = new Point(9, 198);
			this.nEScrew4.MaxValue = 10f;
			this.nEScrew4.MinValue = 0f;
			this.nEScrew4.Name = "nEScrew4";
			this.nEScrew4.Size = new Size(104, 28);
			this.nEScrew4.TabIndex = 3;
			this.nEScrew4.Text = "0";
			this.nEScrew4.TextAlign = HorizontalAlignment.Right;
			this.nEScrew4.Value = 0f;
			this.nEScrew4.TextChanged += this.settingsChanged;
			this.nEScrew4.Enter += this.Start_Input;
			this.nEScrew4.MouseDown += this.StartInput;
			this.lbDescriptionScrew4.AutoSize = true;
			this.lbDescriptionScrew4.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionScrew4.Location = new Point(6, 177);
			this.lbDescriptionScrew4.Name = "lbDescriptionScrew4";
			this.lbDescriptionScrew4.Size = new Size(78, 16);
			this.lbDescriptionScrew4.TabIndex = 34;
			this.lbDescriptionScrew4.Text = "Schrauben 4";
			this.lbUnitScrew3.AutoSize = true;
			this.lbUnitScrew3.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitScrew3.Location = new Point(121, 153);
			this.lbUnitScrew3.Name = "lbUnitScrew3";
			this.lbUnitScrew3.Size = new Size(46, 16);
			this.lbUnitScrew3.TabIndex = 33;
			this.lbUnitScrew3.Text = "Einheit";
			this.nEScrew3.BackColor = Color.White;
			this.nEScrew3.DecimalNum = 0;
			this.nEScrew3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEScrew3.ForeColor = SystemColors.ControlText;
			this.nEScrew3.Location = new Point(9, 146);
			this.nEScrew3.MaxValue = 10f;
			this.nEScrew3.MinValue = 0f;
			this.nEScrew3.Name = "nEScrew3";
			this.nEScrew3.Size = new Size(104, 28);
			this.nEScrew3.TabIndex = 2;
			this.nEScrew3.Text = "0";
			this.nEScrew3.TextAlign = HorizontalAlignment.Right;
			this.nEScrew3.Value = 0f;
			this.nEScrew3.TextChanged += this.settingsChanged;
			this.nEScrew3.Enter += this.Start_Input;
			this.nEScrew3.MouseDown += this.StartInput;
			this.lbDescriptionScrew3.AutoSize = true;
			this.lbDescriptionScrew3.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionScrew3.Location = new Point(6, 125);
			this.lbDescriptionScrew3.Name = "lbDescriptionScrew3";
			this.lbDescriptionScrew3.Size = new Size(78, 16);
			this.lbDescriptionScrew3.TabIndex = 31;
			this.lbDescriptionScrew3.Text = "Schrauben 3";
			this.lbUnitScrew2.AutoSize = true;
			this.lbUnitScrew2.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitScrew2.Location = new Point(121, 100);
			this.lbUnitScrew2.Name = "lbUnitScrew2";
			this.lbUnitScrew2.Size = new Size(46, 16);
			this.lbUnitScrew2.TabIndex = 30;
			this.lbUnitScrew2.Text = "Einheit";
			this.nEScrew2.BackColor = Color.White;
			this.nEScrew2.DecimalNum = 0;
			this.nEScrew2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEScrew2.ForeColor = SystemColors.ControlText;
			this.nEScrew2.Location = new Point(9, 93);
			this.nEScrew2.MaxValue = 10f;
			this.nEScrew2.MinValue = 0f;
			this.nEScrew2.Name = "nEScrew2";
			this.nEScrew2.Size = new Size(104, 28);
			this.nEScrew2.TabIndex = 1;
			this.nEScrew2.Text = "0";
			this.nEScrew2.TextAlign = HorizontalAlignment.Right;
			this.nEScrew2.Value = 0f;
			this.nEScrew2.TextChanged += this.settingsChanged;
			this.nEScrew2.Enter += this.Start_Input;
			this.nEScrew2.MouseDown += this.StartInput;
			this.lbDescriptionScrew2.AutoSize = true;
			this.lbDescriptionScrew2.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionScrew2.Location = new Point(6, 72);
			this.lbDescriptionScrew2.Name = "lbDescriptionScrew2";
			this.lbDescriptionScrew2.Size = new Size(78, 16);
			this.lbDescriptionScrew2.TabIndex = 28;
			this.lbDescriptionScrew2.Text = "Schrauben 2";
			this.lbUnitScrew1.AutoSize = true;
			this.lbUnitScrew1.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitScrew1.Location = new Point(121, 50);
			this.lbUnitScrew1.Name = "lbUnitScrew1";
			this.lbUnitScrew1.Size = new Size(46, 16);
			this.lbUnitScrew1.TabIndex = 27;
			this.lbUnitScrew1.Text = "Einheit";
			this.nEScrew1.BackColor = Color.White;
			this.nEScrew1.DecimalNum = 3;
			this.nEScrew1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEScrew1.ForeColor = SystemColors.ControlText;
			this.nEScrew1.Location = new Point(9, 43);
			this.nEScrew1.MaxValue = 10f;
			this.nEScrew1.MinValue = 0f;
			this.nEScrew1.Name = "nEScrew1";
			this.nEScrew1.Size = new Size(104, 28);
			this.nEScrew1.TabIndex = 0;
			this.nEScrew1.Text = "2,000";
			this.nEScrew1.TextAlign = HorizontalAlignment.Right;
			this.nEScrew1.Value = 2f;
			this.nEScrew1.TextChanged += this.settingsChanged;
			this.nEScrew1.Enter += this.Start_Input;
			this.nEScrew1.MouseDown += this.StartInput;
			this.lbDescriptionScrew1.AutoSize = true;
			this.lbDescriptionScrew1.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionScrew1.Location = new Point(6, 22);
			this.lbDescriptionScrew1.Name = "lbDescriptionScrew1";
			this.lbDescriptionScrew1.Size = new Size(75, 16);
			this.lbDescriptionScrew1.TabIndex = 3;
			this.lbDescriptionScrew1.Text = "Zylinderkraft";
			this.gBTighten.Controls.Add(this.lbUnitTighten7);
			this.gBTighten.Controls.Add(this.nETighten7);
			this.gBTighten.Controls.Add(this.lbDescriptionTighten7);
			this.gBTighten.Controls.Add(this.btEditTighten);
			this.gBTighten.Controls.Add(this.lbUnitTighten6);
			this.gBTighten.Controls.Add(this.nETighten6);
			this.gBTighten.Controls.Add(this.lbDescriptionTighten6);
			this.gBTighten.Controls.Add(this.lbUnitTighten5);
			this.gBTighten.Controls.Add(this.nETighten5);
			this.gBTighten.Controls.Add(this.lbDescriptionTighten5);
			this.gBTighten.Controls.Add(this.lbUnitTighten4);
			this.gBTighten.Controls.Add(this.nETighten4);
			this.gBTighten.Controls.Add(this.lbDescriptionTighten4);
			this.gBTighten.Controls.Add(this.lbUnitTighten3);
			this.gBTighten.Controls.Add(this.nETighten3);
			this.gBTighten.Controls.Add(this.lbDescriptionTighten3);
			this.gBTighten.Controls.Add(this.lbUnitTighten2);
			this.gBTighten.Controls.Add(this.nETighten2);
			this.gBTighten.Controls.Add(this.lbDescriptionTighten2);
			this.gBTighten.Controls.Add(this.lbUnitTighten1);
			this.gBTighten.Controls.Add(this.nETighten1);
			this.gBTighten.Controls.Add(this.lbDescriptionTighten1);
			this.gBTighten.FlatStyle = FlatStyle.Popup;
			this.gBTighten.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.gBTighten.Location = new Point(536, 92);
			this.gBTighten.Name = "gBTighten";
			this.gBTighten.Size = new Size(170, 424);
			this.gBTighten.TabIndex = 5;
			this.gBTighten.TabStop = false;
			this.gBTighten.Text = "Anziehen";
			this.lbUnitTighten7.AutoSize = true;
			this.lbUnitTighten7.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitTighten7.Location = new Point(121, 363);
			this.lbUnitTighten7.Name = "lbUnitTighten7";
			this.lbUnitTighten7.Size = new Size(46, 16);
			this.lbUnitTighten7.TabIndex = 45;
			this.lbUnitTighten7.Text = "Einheit";
			this.nETighten7.BackColor = Color.White;
			this.nETighten7.DecimalNum = 0;
			this.nETighten7.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETighten7.ForeColor = SystemColors.ControlText;
			this.nETighten7.Location = new Point(9, 356);
			this.nETighten7.MaxValue = 10f;
			this.nETighten7.MinValue = 0f;
			this.nETighten7.Name = "nETighten7";
			this.nETighten7.Size = new Size(104, 28);
			this.nETighten7.TabIndex = 6;
			this.nETighten7.Text = "0";
			this.nETighten7.TextAlign = HorizontalAlignment.Right;
			this.nETighten7.Value = 0f;
			this.nETighten7.TextChanged += this.settingsChanged;
			this.nETighten7.Enter += this.Start_Input;
			this.nETighten7.MouseDown += this.StartInput;
			this.lbDescriptionTighten7.AutoSize = true;
			this.lbDescriptionTighten7.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionTighten7.Location = new Point(6, 335);
			this.lbDescriptionTighten7.Name = "lbDescriptionTighten7";
			this.lbDescriptionTighten7.Size = new Size(70, 16);
			this.lbDescriptionTighten7.TabIndex = 43;
			this.lbDescriptionTighten7.Text = "Anziehen 7";
			this.btEditTighten.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.btEditTighten.Location = new Point(9, 395);
			this.btEditTighten.Name = "btEditTighten";
			this.btEditTighten.Size = new Size(151, 23);
			this.btEditTighten.TabIndex = 7;
			this.btEditTighten.Text = "Bearbeiten";
			this.btEditTighten.UseVisualStyleBackColor = true;
			this.btEditTighten.Click += this.btEditTighten_Click;
			this.lbUnitTighten6.AutoSize = true;
			this.lbUnitTighten6.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitTighten6.Location = new Point(121, 311);
			this.lbUnitTighten6.Name = "lbUnitTighten6";
			this.lbUnitTighten6.Size = new Size(46, 16);
			this.lbUnitTighten6.TabIndex = 42;
			this.lbUnitTighten6.Text = "Einheit";
			this.nETighten6.BackColor = Color.White;
			this.nETighten6.DecimalNum = 0;
			this.nETighten6.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETighten6.ForeColor = SystemColors.ControlText;
			this.nETighten6.Location = new Point(9, 304);
			this.nETighten6.MaxValue = 10f;
			this.nETighten6.MinValue = 0f;
			this.nETighten6.Name = "nETighten6";
			this.nETighten6.Size = new Size(104, 28);
			this.nETighten6.TabIndex = 5;
			this.nETighten6.Text = "0";
			this.nETighten6.TextAlign = HorizontalAlignment.Right;
			this.nETighten6.Value = 0f;
			this.nETighten6.TextChanged += this.settingsChanged;
			this.nETighten6.Enter += this.Start_Input;
			this.nETighten6.MouseDown += this.StartInput;
			this.lbDescriptionTighten6.AutoSize = true;
			this.lbDescriptionTighten6.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionTighten6.Location = new Point(6, 283);
			this.lbDescriptionTighten6.Name = "lbDescriptionTighten6";
			this.lbDescriptionTighten6.Size = new Size(70, 16);
			this.lbDescriptionTighten6.TabIndex = 40;
			this.lbDescriptionTighten6.Text = "Anziehen 6";
			this.lbUnitTighten5.AutoSize = true;
			this.lbUnitTighten5.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitTighten5.Location = new Point(121, 258);
			this.lbUnitTighten5.Name = "lbUnitTighten5";
			this.lbUnitTighten5.Size = new Size(46, 16);
			this.lbUnitTighten5.TabIndex = 39;
			this.lbUnitTighten5.Text = "Einheit";
			this.nETighten5.BackColor = Color.White;
			this.nETighten5.DecimalNum = 0;
			this.nETighten5.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETighten5.ForeColor = SystemColors.ControlText;
			this.nETighten5.Location = new Point(9, 251);
			this.nETighten5.MaxValue = 10f;
			this.nETighten5.MinValue = 0f;
			this.nETighten5.Name = "nETighten5";
			this.nETighten5.Size = new Size(104, 28);
			this.nETighten5.TabIndex = 4;
			this.nETighten5.Text = "0";
			this.nETighten5.TextAlign = HorizontalAlignment.Right;
			this.nETighten5.Value = 0f;
			this.nETighten5.TextChanged += this.settingsChanged;
			this.nETighten5.Enter += this.Start_Input;
			this.nETighten5.MouseDown += this.StartInput;
			this.lbDescriptionTighten5.AutoSize = true;
			this.lbDescriptionTighten5.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionTighten5.Location = new Point(6, 230);
			this.lbDescriptionTighten5.Name = "lbDescriptionTighten5";
			this.lbDescriptionTighten5.Size = new Size(70, 16);
			this.lbDescriptionTighten5.TabIndex = 37;
			this.lbDescriptionTighten5.Text = "Anziehen 5";
			this.lbUnitTighten4.AutoSize = true;
			this.lbUnitTighten4.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitTighten4.Location = new Point(121, 205);
			this.lbUnitTighten4.Name = "lbUnitTighten4";
			this.lbUnitTighten4.Size = new Size(46, 16);
			this.lbUnitTighten4.TabIndex = 36;
			this.lbUnitTighten4.Text = "Einheit";
			this.nETighten4.BackColor = Color.White;
			this.nETighten4.DecimalNum = 0;
			this.nETighten4.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETighten4.ForeColor = SystemColors.ControlText;
			this.nETighten4.Location = new Point(9, 198);
			this.nETighten4.MaxValue = 10f;
			this.nETighten4.MinValue = 0f;
			this.nETighten4.Name = "nETighten4";
			this.nETighten4.Size = new Size(104, 28);
			this.nETighten4.TabIndex = 3;
			this.nETighten4.Text = "0";
			this.nETighten4.TextAlign = HorizontalAlignment.Right;
			this.nETighten4.Value = 0f;
			this.nETighten4.TextChanged += this.settingsChanged;
			this.nETighten4.Enter += this.Start_Input;
			this.nETighten4.MouseDown += this.StartInput;
			this.lbDescriptionTighten4.AutoSize = true;
			this.lbDescriptionTighten4.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionTighten4.Location = new Point(6, 177);
			this.lbDescriptionTighten4.Name = "lbDescriptionTighten4";
			this.lbDescriptionTighten4.Size = new Size(70, 16);
			this.lbDescriptionTighten4.TabIndex = 34;
			this.lbDescriptionTighten4.Text = "Anziehen 4";
			this.lbUnitTighten3.AutoSize = true;
			this.lbUnitTighten3.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitTighten3.Location = new Point(121, 153);
			this.lbUnitTighten3.Name = "lbUnitTighten3";
			this.lbUnitTighten3.Size = new Size(46, 16);
			this.lbUnitTighten3.TabIndex = 33;
			this.lbUnitTighten3.Text = "Einheit";
			this.nETighten3.BackColor = Color.White;
			this.nETighten3.DecimalNum = 0;
			this.nETighten3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETighten3.ForeColor = SystemColors.ControlText;
			this.nETighten3.Location = new Point(9, 146);
			this.nETighten3.MaxValue = 10f;
			this.nETighten3.MinValue = 0f;
			this.nETighten3.Name = "nETighten3";
			this.nETighten3.Size = new Size(104, 28);
			this.nETighten3.TabIndex = 2;
			this.nETighten3.Text = "0";
			this.nETighten3.TextAlign = HorizontalAlignment.Right;
			this.nETighten3.Value = 0f;
			this.nETighten3.TextChanged += this.settingsChanged;
			this.nETighten3.Enter += this.Start_Input;
			this.nETighten3.MouseDown += this.StartInput;
			this.lbDescriptionTighten3.AutoSize = true;
			this.lbDescriptionTighten3.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionTighten3.Location = new Point(6, 125);
			this.lbDescriptionTighten3.Name = "lbDescriptionTighten3";
			this.lbDescriptionTighten3.Size = new Size(70, 16);
			this.lbDescriptionTighten3.TabIndex = 31;
			this.lbDescriptionTighten3.Text = "Anziehen 3";
			this.lbUnitTighten2.AutoSize = true;
			this.lbUnitTighten2.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitTighten2.Location = new Point(121, 100);
			this.lbUnitTighten2.Name = "lbUnitTighten2";
			this.lbUnitTighten2.Size = new Size(46, 16);
			this.lbUnitTighten2.TabIndex = 30;
			this.lbUnitTighten2.Text = "Einheit";
			this.nETighten2.BackColor = Color.White;
			this.nETighten2.DecimalNum = 0;
			this.nETighten2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETighten2.ForeColor = SystemColors.ControlText;
			this.nETighten2.Location = new Point(9, 93);
			this.nETighten2.MaxValue = 10f;
			this.nETighten2.MinValue = 0f;
			this.nETighten2.Name = "nETighten2";
			this.nETighten2.Size = new Size(104, 28);
			this.nETighten2.TabIndex = 1;
			this.nETighten2.Text = "0";
			this.nETighten2.TextAlign = HorizontalAlignment.Right;
			this.nETighten2.Value = 0f;
			this.nETighten2.TextChanged += this.settingsChanged;
			this.nETighten2.Enter += this.Start_Input;
			this.nETighten2.MouseDown += this.StartInput;
			this.lbDescriptionTighten2.AutoSize = true;
			this.lbDescriptionTighten2.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionTighten2.Location = new Point(6, 72);
			this.lbDescriptionTighten2.Name = "lbDescriptionTighten2";
			this.lbDescriptionTighten2.Size = new Size(70, 16);
			this.lbDescriptionTighten2.TabIndex = 28;
			this.lbDescriptionTighten2.Text = "Anziehen 2";
			this.lbUnitTighten1.AutoSize = true;
			this.lbUnitTighten1.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnitTighten1.Location = new Point(121, 50);
			this.lbUnitTighten1.Name = "lbUnitTighten1";
			this.lbUnitTighten1.Size = new Size(46, 16);
			this.lbUnitTighten1.TabIndex = 27;
			this.lbUnitTighten1.Text = "Einheit";
			this.nETighten1.BackColor = Color.White;
			this.nETighten1.DecimalNum = 3;
			this.nETighten1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETighten1.ForeColor = SystemColors.ControlText;
			this.nETighten1.Location = new Point(9, 43);
			this.nETighten1.MaxValue = 10f;
			this.nETighten1.MinValue = 0f;
			this.nETighten1.Name = "nETighten1";
			this.nETighten1.Size = new Size(104, 28);
			this.nETighten1.TabIndex = 0;
			this.nETighten1.Text = "2,000";
			this.nETighten1.TextAlign = HorizontalAlignment.Right;
			this.nETighten1.Value = 2f;
			this.nETighten1.TextChanged += this.settingsChanged;
			this.nETighten1.Enter += this.Start_Input;
			this.nETighten1.MouseDown += this.StartInput;
			this.lbDescriptionTighten1.AutoSize = true;
			this.lbDescriptionTighten1.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDescriptionTighten1.Location = new Point(6, 22);
			this.lbDescriptionTighten1.Name = "lbDescriptionTighten1";
			this.lbDescriptionTighten1.Size = new Size(75, 16);
			this.lbDescriptionTighten1.TabIndex = 3;
			this.lbDescriptionTighten1.Text = "Zylinderkraft";
			this.lbProgName.BackColor = Color.Transparent;
			this.lbProgName.BorderStyle = BorderStyle.Fixed3D;
			this.lbProgName.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgName.Location = new Point(118, 22);
			this.lbProgName.Name = "lbProgName";
			this.lbProgName.Size = new Size(151, 23);
			this.lbProgName.TabIndex = 16;
			this.lbProgName.Text = "Name";
			this.lbProgName.TextAlign = ContentAlignment.MiddleLeft;
			this.lbProgName.Visible = false;
			this.pictureBox3.BackgroundImageLayout = ImageLayout.Center;
			//this.pictureBox3.Image = Resources.Fasten_;
			this.pictureBox3.InitialImage = null;
			this.pictureBox3.Location = new Point(536, 3);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new Size(170, 88);
			this.pictureBox3.TabIndex = 21;
			this.pictureBox3.TabStop = false;
			//this.pictureBox2.Image = (Image)componentResourceManager.GetObject("pictureBox2.Image");
			this.pictureBox2.Location = new Point(188, 3);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new Size(170, 88);
			this.pictureBox2.TabIndex = 20;
			this.pictureBox2.TabStop = false;
			//this.pictureBox1.Image = Resources.Find;
			this.pictureBox1.Location = new Point(14, 3);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new Size(170, 88);
			this.pictureBox1.TabIndex = 19;
			this.pictureBox1.TabStop = false;
			//this.pBoxScrew.Image = Resources.Screw_;
			this.pBoxScrew.Location = new Point(362, 3);
			this.pBoxScrew.Name = "pBoxScrew";
			this.pBoxScrew.Size = new Size(170, 88);
			this.pBoxScrew.TabIndex = 18;
			this.pBoxScrew.TabStop = false;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.pictureBox3);
			base.Controls.Add(this.pictureBox2);
			base.Controls.Add(this.pictureBox1);
			base.Controls.Add(this.pBoxScrew);
			base.Controls.Add(this.lbProgNum);
			base.Controls.Add(this.gBTighten);
			base.Controls.Add(this.lbProgName);
			base.Controls.Add(this.gBScrew);
			base.Controls.Add(this.gBFlowDrill);
			base.Controls.Add(this.gBFind);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "FourStepOverviewForm";
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen/Programme/Stufen/Stufe bearbeiten";
			base.Activated += this.FourStepOverviewForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBFind.ResumeLayout(false);
			this.gBFind.PerformLayout();
			this.gBFlowDrill.ResumeLayout(false);
			this.gBFlowDrill.PerformLayout();
			this.gBScrew.ResumeLayout(false);
			this.gBScrew.PerformLayout();
			this.gBTighten.ResumeLayout(false);
			this.gBTighten.PerformLayout();
			((ISupportInitialize)this.pictureBox3).EndInit();
			((ISupportInitialize)this.pictureBox2).EndInit();
			((ISupportInitialize)this.pictureBox1).EndInit();
			((ISupportInitialize)this.pBoxScrew).EndInit();
			base.ResumeLayout(false);
		}

		public bool ShowWindow(int progNum)
		{
			this.Main.ResetBrowserGrantedBy();
			this.IsInitializeMode = true;
			this.PNum = progNum;
			this.PD = this.Main.ProcessProgram.TempProgStruct.Num[this.PNum];
			this.MenEna();
			base.Show();
			if (this.PD.Info.Steps == 0)
			{
				this.btBack.Enabled = false;
				this.btEditFind.Visible = false;
				this.btEditFlowDrill.Visible = false;
				this.btEditScrew.Visible = false;
				this.btEditTighten.Visible = false;
				this.btLoadSettings.Enabled = false;
				this.btStoreSettings.Enabled = false;
				MessageBox.Show(this.Main.Rm.GetString("4StepEmptyProgram"), this.Main.Rm.GetString("ProgramDisplay4Step"), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				this.initializeValues(false);
			}
			this.Main.VC.makeCopyProgStruct(ref this.PD_save, this.PD);
			this.IsInitializeMode = false;
			return true;
		}

		public void SetLanguageTexts()
		{
			this.fourStepNames.Initialize();
			string[] array = this.fourStepNames;
			GroupBox groupBox = this.gBFind;
			string text = array[0] = (groupBox.Text = this.Main.Rm.GetString("StepFind"));
			string[] array2 = this.fourStepNames;
			GroupBox groupBox2 = this.gBFlowDrill;
			string text2 = array2[1] = (groupBox2.Text = this.Main.Rm.GetString("StepFlowDrill"));
			string[] array3 = this.fourStepNames;
			GroupBox groupBox3 = this.gBScrew;
			string text3 = array3[2] = (groupBox3.Text = this.Main.Rm.GetString("StepScrew"));
			string[] array4 = this.fourStepNames;
			GroupBox groupBox4 = this.gBTighten;
			string text4 = array4[3] = (groupBox4.Text = this.Main.Rm.GetString("StepTighten"));
			this.openFileDialog.Filter = this.Main.Rm.GetString("4StepSettings") + "|*.w4xml|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.saveFileDialog.Filter = this.Main.Rm.GetString("4StepSettings") + "|*.w4xml|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			string[] array5 = new string[8];
			string[] array6 = new string[4];
			array5[0] = this.Main.Rm.GetString("Torque") + string.Empty;
			array5[1] = this.Main.Rm.GetString("FilteredTorque") + string.Empty;
			array5[2] = this.Main.Rm.GetString("RelativeTorque") + string.Empty;
			array5[3] = this.Main.Rm.GetString("M360Follow") + string.Empty;
			array5[4] = this.Main.Rm.GetString("Gradient") + string.Empty;
			array5[5] = this.Main.Rm.GetString("Angle") + string.Empty;
			array5[6] = this.Main.Rm.GetString("AnaDepth") + string.Empty;
			array5[7] = this.Main.Rm.GetString("AnaSignal") + string.Empty;
			array6[0] = this.Main.Rm.GetString("Torque") + string.Empty;
			array6[1] = this.Main.Rm.GetString("FilteredTorque") + string.Empty;
			array6[2] = this.Main.Rm.GetString("MaxTorque") + string.Empty;
			array6[3] = this.Main.Rm.GetString("DelayTorque") + string.Empty;
			this.writeCaption(false);
			this.btBack.Text = this.Main.Rm.GetString("Done");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btCancel.Text = this.Main.Rm.GetString("btCancel");
			this.btStoreSettings.Text = this.Main.Rm.GetString("SaveToFile");
			this.btLoadSettings.Text = this.Main.Rm.GetString("LoadFromFile");
			this.btEditFind.Text = this.Main.Rm.GetString("ChangeConfiguration");
			this.btEditFlowDrill.Text = this.Main.Rm.GetString("ChangeConfiguration");
			this.btEditScrew.Text = this.Main.Rm.GetString("ChangeConfiguration");
			this.btEditTighten.Text = this.Main.Rm.GetString("ChangeConfiguration");
		}

		private void writeCaption(bool withProgramInformation)
		{
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MProgramOverview") + "/" + this.Main.Rm.GetString("ProgramDisplay4Step");
			if (withProgramInformation)
			{
				this.Text += ": ";
				this.Text = this.Text + this.Main.Rm.GetString("Abr_Program") + " " + this.PNum.ToString();
				this.Text += " ";
				this.Text += this.Main.CommonFunctions.UShortToString(this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Info.Name);
			}
		}

		private void MenEna()
		{
			this.writeCaption(true);
			bool enabled = false;
			bool flag = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_FourStepEditForm)
			{
				flag = true;
			}
			if (this.Main.PassCodeLevel >= 1)
			{
				enabled = true;
			}
			if (this.Main.ViewOnlyMode)
			{
				enabled = false;
				flag = false;
			}
			if (this.Main.IsOfflineVersion)
			{
				enabled = true;
				flag = true;
			}
			this.Main.ShowCurrentUserAccessState(1, false);
			this.getProgramValues();
			this.checkAtomsWeedOutUninitializedStepIndex();
			this.initializeValues(true);
			this.btBack.Enabled = enabled;
			this.btEditFind.Visible = flag;
			this.btEditFlowDrill.Visible = flag;
			this.btEditScrew.Visible = flag;
			this.btEditTighten.Visible = flag;
			this.btLoadSettings.Enabled = flag;
			this.btStoreSettings.Enabled = flag;
			this.nEFind1.Enabled = enabled;
			this.nEFind2.Enabled = enabled;
			this.nEFind3.Enabled = enabled;
			this.nEFind4.Enabled = enabled;
			this.nEFind5.Enabled = enabled;
			this.nEFind6.Enabled = enabled;
			this.nEFind7.Enabled = enabled;
			this.nEFlowDrill1.Enabled = enabled;
			this.nEFlowDrill2.Enabled = enabled;
			this.nEFlowDrill3.Enabled = enabled;
			this.nEFlowDrill4.Enabled = enabled;
			this.nEFlowDrill5.Enabled = enabled;
			this.nEFlowDrill6.Enabled = enabled;
			this.nEFlowDrill7.Enabled = enabled;
			this.nEScrew1.Enabled = enabled;
			this.nEScrew2.Enabled = enabled;
			this.nEScrew3.Enabled = enabled;
			this.nEScrew4.Enabled = enabled;
			this.nEScrew5.Enabled = enabled;
			this.nEScrew6.Enabled = enabled;
			this.nEScrew7.Enabled = enabled;
			this.nETighten1.Enabled = enabled;
			this.nETighten2.Enabled = enabled;
			this.nETighten3.Enabled = enabled;
			this.nETighten4.Enabled = enabled;
			this.nETighten5.Enabled = enabled;
			this.nETighten6.Enabled = enabled;
			this.nETighten7.Enabled = enabled;
		}

		private bool ApplyValues()
		{
			string text = string.Empty;
			float num;
			if (this.nEFind1.Visible && !this.nEFind1.IsOK)
			{
				string[] array = new string[11]
				{
					text,
					this.gBFind.Text,
					" - ",
					this.lbDescriptionFind1.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array2 = array;
				num = this.nEFind1.MinValue;
				array2[7] = num.ToString();
				array[8] = " - ";
				array[9] = this.nEFind1.MaxValue.ToString();
				array[10] = "\n";
				text = string.Concat(array);
			}
			if (this.nEFind2.Visible && !this.nEFind2.IsOK)
			{
				text = text + this.gBFind.Text + " - " + this.lbDescriptionFind2.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFind2.MinValue.ToString() + " - " + this.nEFind2.MaxValue.ToString() + "\n";
			}
			if (this.nEFind3.Visible && !this.nEFind3.IsOK)
			{
				text = text + this.gBFind.Text + " - " + this.lbDescriptionFind3.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFind3.MinValue.ToString() + " - " + this.nEFind3.MaxValue.ToString() + "\n";
			}
			if (this.nEFind4.Visible && !this.nEFind4.IsOK)
			{
				text = text + this.gBFind.Text + " - " + this.lbDescriptionFind4.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFind4.MinValue.ToString() + " - " + this.nEFind4.MaxValue.ToString() + "\n";
			}
			if (this.nEFind5.Visible && !this.nEFind5.IsOK)
			{
				text = text + this.gBFind.Text + " - " + this.lbDescriptionFind5.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFind5.MinValue.ToString() + " - " + this.nEFind5.MaxValue.ToString() + "\n";
			}
			if (this.nEFind6.Visible && !this.nEFind6.IsOK)
			{
				text = text + this.gBFind.Text + " - " + this.lbDescriptionFind6.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFind6.MinValue.ToString() + " - " + this.nEFind6.MaxValue.ToString() + "\n";
			}
			if (this.nEFind7.Visible && !this.nEFind7.IsOK)
			{
				text = text + this.gBFind.Text + " - " + this.lbDescriptionFind7.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFind7.MinValue.ToString() + " - " + this.nEFind7.MaxValue.ToString() + "\n";
			}
			if (this.nEFlowDrill1.Visible && !this.nEFlowDrill1.IsOK)
			{
				text = text + this.gBFlowDrill.Text + " - " + this.lbDescriptionFlowDrill1.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFlowDrill1.MinValue.ToString() + " - " + this.nEFlowDrill1.MaxValue.ToString() + "\n";
			}
			if (this.nEFlowDrill2.Visible && !this.nEFlowDrill2.IsOK)
			{
				text = text + this.gBFlowDrill.Text + " - " + this.lbDescriptionFlowDrill2.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFlowDrill2.MinValue.ToString() + " - " + this.nEFlowDrill2.MaxValue.ToString() + "\n";
			}
			if (this.nEFlowDrill3.Visible && !this.nEFlowDrill3.IsOK)
			{
				text = text + this.gBFlowDrill.Text + " - " + this.lbDescriptionFlowDrill3.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFlowDrill3.MinValue.ToString() + " - " + this.nEFlowDrill3.MaxValue.ToString() + "\n";
			}
			if (this.nEFlowDrill4.Visible && !this.nEFlowDrill4.IsOK)
			{
				text = text + this.gBFlowDrill.Text + " - " + this.lbDescriptionFlowDrill4.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFlowDrill4.MinValue.ToString() + " - " + this.nEFlowDrill4.MaxValue.ToString() + "\n";
			}
			if (this.nEFlowDrill5.Visible && !this.nEFlowDrill5.IsOK)
			{
				text = text + this.gBFlowDrill.Text + " - " + this.lbDescriptionFlowDrill5.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFlowDrill5.MinValue.ToString() + " - " + this.nEFlowDrill5.MaxValue.ToString() + "\n";
			}
			if (this.nEFlowDrill6.Visible && !this.nEFlowDrill6.IsOK)
			{
				text = text + this.gBFlowDrill.Text + " - " + this.lbDescriptionFlowDrill6.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFlowDrill6.MinValue.ToString() + " - " + this.nEFlowDrill6.MaxValue.ToString() + "\n";
			}
			if (this.nEFlowDrill7.Visible && !this.nEFlowDrill7.IsOK)
			{
				text = text + this.gBFlowDrill.Text + " - " + this.lbDescriptionFlowDrill7.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEFlowDrill7.MinValue.ToString() + " - " + this.nEFlowDrill7.MaxValue.ToString() + "\n";
			}
			if (this.nEScrew1.Visible && !this.nEScrew1.IsOK)
			{
				text = text + this.gBScrew.Text + " - " + this.lbDescriptionScrew1.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEScrew1.MinValue.ToString() + " - " + this.nEScrew1.MaxValue.ToString() + "\n";
			}
			if (this.nEScrew2.Visible && !this.nEScrew2.IsOK)
			{
				text = text + this.gBScrew.Text + " - " + this.lbDescriptionScrew2.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEScrew2.MinValue.ToString() + " - " + this.nEScrew2.MaxValue.ToString() + "\n";
			}
			if (this.nEScrew3.Visible && !this.nEScrew3.IsOK)
			{
				text = text + this.gBScrew.Text + " - " + this.lbDescriptionScrew3.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEScrew3.MinValue.ToString() + " - " + this.nEScrew3.MaxValue.ToString() + "\n";
			}
			if (this.nEScrew4.Visible && !this.nEScrew4.IsOK)
			{
				text = text + this.gBScrew.Text + " - " + this.lbDescriptionScrew4.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEScrew4.MinValue.ToString() + " - " + this.nEScrew4.MaxValue.ToString() + "\n";
			}
			if (this.nEScrew5.Visible && !this.nEScrew5.IsOK)
			{
				text = text + this.gBScrew.Text + " - " + this.lbDescriptionScrew5.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEScrew5.MinValue.ToString() + " - " + this.nEScrew5.MaxValue.ToString() + "\n";
			}
			if (this.nEScrew6.Visible && !this.nEScrew6.IsOK)
			{
				string[] array3 = new string[11]
				{
					text,
					this.gBScrew.Text,
					" - ",
					this.lbDescriptionScrew6.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array4 = array3;
				num = this.nEScrew6.MinValue;
				array4[7] = num.ToString();
				array3[8] = " - ";
				string[] array5 = array3;
				num = this.nEScrew6.MaxValue;
				array5[9] = num.ToString();
				array3[10] = "\n";
				text = string.Concat(array3);
			}
			if (this.nEScrew7.Visible && !this.nEScrew7.IsOK)
			{
				string[] array = new string[11]
				{
					text,
					this.gBScrew.Text,
					" - ",
					this.lbDescriptionScrew7.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array6 = array;
				num = this.nEScrew7.MinValue;
				array6[7] = num.ToString();
				array[8] = " - ";
				string[] array7 = array;
				num = this.nEScrew7.MaxValue;
				array7[9] = num.ToString();
				array[10] = "\n";
				text = string.Concat(array);
			}
			if (this.nETighten1.Visible && !this.nETighten1.IsOK)
			{
				string[] array = new string[11]
				{
					text,
					this.gBTighten.Text,
					" - ",
					this.lbDescriptionTighten1.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array8 = array;
				num = this.nETighten1.MinValue;
				array8[7] = num.ToString();
				array[8] = " - ";
				string[] array9 = array;
				num = this.nETighten1.MaxValue;
				array9[9] = num.ToString();
				array[10] = "\n";
				text = string.Concat(array);
			}
			if (this.nETighten2.Visible && !this.nETighten2.IsOK)
			{
				string[] array = new string[11]
				{
					text,
					this.gBTighten.Text,
					" - ",
					this.lbDescriptionTighten2.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array10 = array;
				num = this.nETighten2.MinValue;
				array10[7] = num.ToString();
				array[8] = " - ";
				string[] array11 = array;
				num = this.nETighten2.MaxValue;
				array11[9] = num.ToString();
				array[10] = "\n";
				text = string.Concat(array);
			}
			if (this.nETighten3.Visible && !this.nETighten3.IsOK)
			{
				string[] array = new string[11]
				{
					text,
					this.gBTighten.Text,
					" - ",
					this.lbDescriptionTighten3.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array12 = array;
				num = this.nETighten3.MinValue;
				array12[7] = num.ToString();
				array[8] = " - ";
				string[] array13 = array;
				num = this.nETighten3.MaxValue;
				array13[9] = num.ToString();
				array[10] = "\n";
				text = string.Concat(array);
			}
			if (this.nETighten4.Visible && !this.nETighten4.IsOK)
			{
				string[] array = new string[11]
				{
					text,
					this.gBTighten.Text,
					" - ",
					this.lbDescriptionTighten4.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array14 = array;
				num = this.nETighten4.MinValue;
				array14[7] = num.ToString();
				array[8] = " - ";
				string[] array15 = array;
				num = this.nETighten4.MaxValue;
				array15[9] = num.ToString();
				array[10] = "\n";
				text = string.Concat(array);
			}
			if (this.nETighten5.Visible && !this.nETighten5.IsOK)
			{
				string[] array = new string[11]
				{
					text,
					this.gBTighten.Text,
					" - ",
					this.lbDescriptionTighten5.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array16 = array;
				num = this.nETighten5.MinValue;
				array16[7] = num.ToString();
				array[8] = " - ";
				string[] array17 = array;
				num = this.nETighten5.MaxValue;
				array17[9] = num.ToString();
				array[10] = "\n";
				text = string.Concat(array);
			}
			if (this.nETighten6.Visible && !this.nETighten6.IsOK)
			{
				string[] array = new string[11]
				{
					text,
					this.gBTighten.Text,
					" - ",
					this.lbDescriptionTighten6.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array18 = array;
				num = this.nETighten6.MinValue;
				array18[7] = num.ToString();
				array[8] = " - ";
				string[] array19 = array;
				num = this.nETighten6.MaxValue;
				array19[9] = num.ToString();
				array[10] = "\n";
				text = string.Concat(array);
			}
			if (this.nETighten7.Visible && !this.nETighten7.IsOK)
			{
				string[] array = new string[11]
				{
					text,
					this.gBTighten.Text,
					" - ",
					this.lbDescriptionTighten7.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array20 = array;
				num = this.nETighten7.MinValue;
				array20[7] = num.ToString();
				array[8] = " - ";
				string[] array21 = array;
				num = this.nETighten7.MaxValue;
				array21[9] = num.ToString();
				array[10] = "\n";
				text = string.Concat(array);
			}
			if (this.Main.CheckParamAllowed && text != string.Empty)
			{
				MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + text, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 7; j++)
				{
					if (this.PD.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex >= 128)
					{
						this.getValueProperty(i, j);
					}
				}
			}
			return true;
		}

		public string CheckProgramValues()
		{
			string result = null;
			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 7; j++)
				{
					int num = this.PD.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex & 0x7F;
					float value = this.PD.FourProg.FourthStep[i].FourStepAtoms[j].Value;
					byte typeOfDatum = this.PD.FourProg.FourthStep[i].FourStepAtoms[j].TypeOfData;
					if (num < 25)
					{
						byte stepIndex = this.PD.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex;
					}
				}
			}
			return result;
		}

		private string selectionChanged(int stepIndex, int stepNum, int fourthStepNum)
		{
			return "Selection of target value was changed for step: " + (stepIndex + 1).ToString() + "(" + (stepNum + 1).ToString() + "/" + (fourthStepNum + 1).ToString() + ")\n";
		}

		private string settingIsDisabled(int stepIndex, int stepNum, int fourthStepNum, string settingText)
		{
			return "- Setting in check parameters is disabled for step " + (stepIndex + 1).ToString() + ": " + settingText + " (" + this.GetFourStepName(stepNum) + "/" + (fourthStepNum + 1).ToString() + ")\n";
		}

		private string setProgramValues(bool verifyOnly)
		{
			float torqueConvert = 0f;
			string torqueUnitName = "";
			string text = null;
			bool flag = false;
			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 7; j++)
				{
					int num = this.PD.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex & 0x7F;
					float value = this.PD.FourProg.FourthStep[i].FourStepAtoms[j].Value;
					int typeOfData = this.PD.FourProg.FourthStep[i].FourStepAtoms[j].TypeOfData;
					if (num < 25 && this.PD.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex >= 128)
					{
						WSP1_VarComm.StepStruct stepStruct = this.PD.Step[num];
						int num2;
						switch (stepStruct.Type)
						{
						case 2:
							num2 = 0;
							break;
						case 3:
							num2 = 1;
							break;
						default:
							flag = true;
							num2 = 1;
							break;
						}
						int num3;
						switch (stepStruct.Switch)
						{
						case 1:
							num3 = 0;
							break;
						case 50:
							num3 = 1;
							break;
						case 3:
							num3 = 2;
							break;
						case 51:
							num3 = 3;
							break;
						case 2:
							num3 = 4;
							break;
						case 4:
							num3 = 5;
							break;
						case 52:
							num3 = 6;
							break;
						case 5:
							num3 = 7;
							break;
						case 6:
							num3 = 8;
							break;
						case 7:
							num3 = 9;
							break;
						case 53:
							num3 = 10;
							break;
						case 8:
							num3 = 11;
							break;
						case 54:
							num3 = 12;
							break;
						case 9:
							num3 = 13;
							break;
						case 55:
							num3 = 14;
							break;
						case 10:
							num3 = 15;
							break;
						case 11:
							num3 = 16;
							break;
						default:
							flag = true;
							num3 = 0;
							break;
						}
						switch (typeOfData)
						{
						case 4:
							if (stepStruct.Switch != 7 && !verifyOnly)
							{
								stepStruct.Switch = 7;
							}
							if (!verifyOnly)
							{
								stepStruct.LP = value;
							}
							break;
						case 2:
							if (stepStruct.Switch != 10 && !verifyOnly)
							{
								stepStruct.Switch = 10;
							}
							if (!verifyOnly)
							{
								stepStruct.LGP = value;
							}
							break;
						case 6:
							if (this.Main.VisibleParameters.EnaM[num3, num2] && this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Step[num].Enable.Torque == 0)
							{
								string fourStepTypeDescription2 = this.Main.C_global.GetFourStepTypeDescription(6, this.Main.VC.SpConst, this.Main.Rm, torqueConvert, torqueUnitName, out torqueUnitName);
								text += this.settingIsDisabled(num, i, j, fourStepTypeDescription2);
							}
							if (!verifyOnly)
							{
								stepStruct.Mmax = value;
							}
							break;
						case 5:
							if (this.Main.VisibleParameters.EnaM[num3, num2] && this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Step[num].Enable.Torque == 0)
							{
								string fourStepTypeDescription4 = this.Main.C_global.GetFourStepTypeDescription(5, this.Main.VC.SpConst, this.Main.Rm, torqueConvert, torqueUnitName, out torqueUnitName);
								text += this.settingIsDisabled(num, i, j, fourStepTypeDescription4);
							}
							if (!verifyOnly)
							{
								stepStruct.Mmin = value;
							}
							break;
						case 1:
							if (!verifyOnly)
							{
								stepStruct.PressureSpindle = value;
							}
							break;
						case 0:
							if (!verifyOnly)
							{
								stepStruct.NA = value;
							}
							break;
						case 3:
							if (!verifyOnly)
							{
								stepStruct.Tmax = value;
							}
							break;
						case 7:
							if (!verifyOnly)
							{
								stepStruct.TM = value;
							}
							break;
						case 8:
							if (!verifyOnly)
							{
								stepStruct.MDelayTime = value;
							}
							break;
						case 9:
							if (stepStruct.Switch != 6 && !verifyOnly)
							{
								stepStruct.Switch = 6;
							}
							if (!verifyOnly)
							{
								stepStruct.TP = value;
							}
							break;
						case 10:
							if (stepStruct.Switch != 5 && !verifyOnly)
							{
								stepStruct.Switch = 5;
							}
							if (!verifyOnly)
							{
								stepStruct.WP = value;
							}
							break;
						case 11:
							if (stepStruct.Switch != 1 && !verifyOnly)
							{
								stepStruct.Switch = 1;
							}
							if (!verifyOnly)
							{
								stepStruct.MP = value / this.Main.TorqueConvert;
							}
							break;
						case 12:
							if (this.Main.VisibleParameters.LGmax[num3, num2] && this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Step[num].Enable.ADepthGradMin == 0)
							{
								string fourStepTypeDescription5 = this.Main.C_global.GetFourStepTypeDescription(12, this.Main.VC.SpConst, this.Main.Rm, torqueConvert, torqueUnitName, out torqueUnitName);
								text += this.settingIsDisabled(num, i, j, fourStepTypeDescription5);
							}
							if (!verifyOnly)
							{
								stepStruct.LGmax = value;
							}
							break;
						case 13:
							if (this.Main.VisibleParameters.MGmax[num3, num2] && this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Step[num].Enable.GradientMax == 0)
							{
								string fourStepTypeDescription3 = this.Main.C_global.GetFourStepTypeDescription(13, this.Main.VC.SpConst, this.Main.Rm, torqueConvert, torqueUnitName, out torqueUnitName);
								text += this.settingIsDisabled(num, i, j, fourStepTypeDescription3);
							}
							if (!verifyOnly)
							{
								stepStruct.MGmax = value;
							}
							break;
						case 14:
							if (this.Main.VisibleParameters.MGmin[num3, num2] && this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Step[num].Enable.GradientMin == 0)
							{
								string fourStepTypeDescription = this.Main.C_global.GetFourStepTypeDescription(14, this.Main.VC.SpConst, this.Main.Rm, torqueConvert, torqueUnitName, out torqueUnitName);
								text += this.settingIsDisabled(num, i, j, fourStepTypeDescription);
							}
							if (!verifyOnly)
							{
								stepStruct.MGmin = value;
							}
							break;
						}
					}
				}
			}
			if (flag)
			{
				string text2 = this.Main.Rm.GetString("Mb4StepWrongDefinition1") + "\n" + this.Main.Rm.GetString("Mb4StepWrongDefinition2") + "\n" + this.Main.Rm.GetString("Mb4StepWrongDefinition3") + "\n";
				MessageBox.Show(text2, "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			return text;
		}

		public string VerifyStepSettings()
		{
			return this.setProgramValues(true);
		}

		public void Accept25_StepValues(int progNum)
		{
			this.PNum = progNum;
			this.PD = this.Main.ProcessProgram.TempProgStruct.Num[this.PNum];
			this.getProgramValues();
		}

		private void getProgramValues()
		{
			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 7; j++)
				{
					int num = this.PD.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex & 0x7F;
					int typeOfData = this.PD.FourProg.FourthStep[i].FourStepAtoms[j].TypeOfData;
					WSP1_VarComm.FourStepAtomStruct fourStepAtomStruct = this.PD.FourProg.FourthStep[i].FourStepAtoms[j];
					if (num < 25 && this.PD.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex >= 128)
					{
						switch (typeOfData)
						{
						case 4:
							fourStepAtomStruct.Value = this.PD.Step[num].LP;
							break;
						case 2:
							fourStepAtomStruct.Value = this.PD.Step[num].LGP;
							break;
						case 6:
							fourStepAtomStruct.Value = this.PD.Step[num].Mmax;
							break;
						case 5:
							fourStepAtomStruct.Value = this.PD.Step[num].Mmin;
							break;
						case 1:
							fourStepAtomStruct.Value = this.PD.Step[num].PressureSpindle;
							break;
						case 0:
							fourStepAtomStruct.Value = this.PD.Step[num].NA;
							break;
						case 3:
							fourStepAtomStruct.Value = this.PD.Step[num].Tmax;
							break;
						case 7:
							fourStepAtomStruct.Value = this.PD.Step[num].TM;
							break;
						case 8:
							fourStepAtomStruct.Value = this.PD.Step[num].MDelayTime;
							break;
						case 9:
							fourStepAtomStruct.Value = this.PD.Step[num].TP;
							break;
						case 10:
							fourStepAtomStruct.Value = this.PD.Step[num].WP;
							break;
						case 11:
							fourStepAtomStruct.Value = this.PD.Step[num].MP;
							break;
						case 12:
							fourStepAtomStruct.Value = this.PD.Step[num].LGmax;
							break;
						case 13:
							fourStepAtomStruct.Value = this.PD.Step[num].MGmax;
							break;
						case 14:
							fourStepAtomStruct.Value = this.PD.Step[num].MGmin;
							break;
						}
					}
				}
			}
		}

		private bool setValueProperty(int indexFourStep, int index, int maxNumberRealProgramSteps)
		{
			bool flag = false;
			Label label = null;
			Label label2 = null;
			Label label3 = null;
			Label label4 = null;
			Label label5 = null;
			Label label6 = null;
			Label label7 = null;
			Label label8 = null;
			Label label9 = null;
			Label label10 = null;
			Label label11 = null;
			Label label12 = null;
			Label label13 = null;
			Label label14 = null;
			NumberEdit1 numberEdit = null;
			NumberEdit1 numberEdit2 = null;
			NumberEdit1 numberEdit3 = null;
			NumberEdit1 numberEdit4 = null;
			NumberEdit1 numberEdit5 = null;
			NumberEdit1 numberEdit6 = null;
			NumberEdit1 numberEdit7 = null;
			switch (indexFourStep)
			{
			case 0:
				label = this.lbDescriptionFind1;
				label2 = this.lbDescriptionFind2;
				label3 = this.lbDescriptionFind3;
				label4 = this.lbDescriptionFind4;
				label5 = this.lbDescriptionFind5;
				label6 = this.lbDescriptionFind6;
				label7 = this.lbDescriptionFind7;
				label8 = this.lbUnitFind1;
				label9 = this.lbUnitFind2;
				label10 = this.lbUnitFind3;
				label11 = this.lbUnitFind4;
				label12 = this.lbUnitFind5;
				label13 = this.lbUnitFind6;
				label14 = this.lbUnitFind7;
				numberEdit = this.nEFind1;
				numberEdit2 = this.nEFind2;
				numberEdit3 = this.nEFind3;
				numberEdit4 = this.nEFind4;
				numberEdit5 = this.nEFind5;
				numberEdit6 = this.nEFind6;
				numberEdit7 = this.nEFind7;
				break;
			case 1:
				label = this.lbDescriptionFlowDrill1;
				label2 = this.lbDescriptionFlowDrill2;
				label3 = this.lbDescriptionFlowDrill3;
				label4 = this.lbDescriptionFlowDrill4;
				label5 = this.lbDescriptionFlowDrill5;
				label6 = this.lbDescriptionFlowDrill6;
				label7 = this.lbDescriptionFlowDrill7;
				label8 = this.lbUnitFlowDrill1;
				label9 = this.lbUnitFlowDrill2;
				label10 = this.lbUnitFlowDrill3;
				label11 = this.lbUnitFlowDrill4;
				label12 = this.lbUnitFlowDrill5;
				label13 = this.lbUnitFlowDrill6;
				label14 = this.lbUnitFlowDrill7;
				numberEdit = this.nEFlowDrill1;
				numberEdit2 = this.nEFlowDrill2;
				numberEdit3 = this.nEFlowDrill3;
				numberEdit4 = this.nEFlowDrill4;
				numberEdit5 = this.nEFlowDrill5;
				numberEdit6 = this.nEFlowDrill6;
				numberEdit7 = this.nEFlowDrill7;
				break;
			case 2:
				label = this.lbDescriptionScrew1;
				label2 = this.lbDescriptionScrew2;
				label3 = this.lbDescriptionScrew3;
				label4 = this.lbDescriptionScrew4;
				label5 = this.lbDescriptionScrew5;
				label6 = this.lbDescriptionScrew6;
				label7 = this.lbDescriptionScrew7;
				label8 = this.lbUnitScrew1;
				label9 = this.lbUnitScrew2;
				label10 = this.lbUnitScrew3;
				label11 = this.lbUnitScrew4;
				label12 = this.lbUnitScrew5;
				label13 = this.lbUnitScrew6;
				label14 = this.lbUnitScrew7;
				numberEdit = this.nEScrew1;
				numberEdit2 = this.nEScrew2;
				numberEdit3 = this.nEScrew3;
				numberEdit4 = this.nEScrew4;
				numberEdit5 = this.nEScrew5;
				numberEdit6 = this.nEScrew6;
				numberEdit7 = this.nEScrew7;
				break;
			case 3:
				label = this.lbDescriptionTighten1;
				label2 = this.lbDescriptionTighten2;
				label3 = this.lbDescriptionTighten3;
				label4 = this.lbDescriptionTighten4;
				label5 = this.lbDescriptionTighten5;
				label6 = this.lbDescriptionTighten6;
				label7 = this.lbDescriptionTighten7;
				label8 = this.lbUnitTighten1;
				label9 = this.lbUnitTighten2;
				label10 = this.lbUnitTighten3;
				label11 = this.lbUnitTighten4;
				label12 = this.lbUnitTighten5;
				label13 = this.lbUnitTighten6;
				label14 = this.lbUnitTighten7;
				numberEdit = this.nETighten1;
				numberEdit2 = this.nETighten2;
				numberEdit3 = this.nETighten3;
				numberEdit4 = this.nETighten4;
				numberEdit5 = this.nETighten5;
				numberEdit6 = this.nETighten6;
				numberEdit7 = this.nETighten7;
				break;
			default:
				return true;
			}
			WSP1_VarComm.FourStepAtomStruct fourStepAtomStruct = this.PD.FourProg.FourthStep[indexFourStep].FourStepAtoms[index];
			string text = "";
			int num = fourStepAtomStruct.StepIndex & 0x7F;
			bool visible = true;
			Color foreColor;
			if (num < maxNumberRealProgramSteps)
			{
				flag = false;
				foreColor = Color.Black;
			}
			else
			{
				flag = true;
				foreColor = Color.Red;
				if (this.Main.PassCodeLevel < Settings.Default.UserLevel_FourStepEditForm)
				{
					visible = false;
				}
			}
			text = ((num >= 25) ? "(--)" : ("(" + ((fourStepAtomStruct.StepIndex & 0x7F) + 1).ToString() + ")"));
			string text2;
			float num2;
			float num3;
			float num4;
			switch (index)
			{
			case 0:
				label.Text = this.Main.C_global.GetFourStepTypeDescription((int)fourStepAtomStruct.TypeOfData, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text2, out num2, out num3, out num4) + text;
				label.ForeColor = foreColor;
				label8.Text = text2;
				numberEdit.MaxValue = fourStepAtomStruct.MaxValue;
				numberEdit.MinValue = fourStepAtomStruct.MinValue;
				numberEdit.DecimalNum = (int)num4;
				numberEdit.Value = fourStepAtomStruct.Value;
				label.Visible = visible;
				label8.Visible = visible;
				numberEdit.Visible = visible;
				if (!numberEdit.IsOK)
				{
					flag = true;
				}
				break;
			case 1:
				label2.Text = this.Main.C_global.GetFourStepTypeDescription((int)fourStepAtomStruct.TypeOfData, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text2, out num2, out num3, out num4) + text;
				label2.ForeColor = foreColor;
				label9.Text = text2;
				numberEdit2.MaxValue = fourStepAtomStruct.MaxValue;
				numberEdit2.MinValue = fourStepAtomStruct.MinValue;
				numberEdit2.DecimalNum = (int)num4;
				numberEdit2.Value = fourStepAtomStruct.Value;
				label2.Visible = visible;
				label9.Visible = visible;
				numberEdit2.Visible = visible;
				if (!numberEdit2.IsOK)
				{
					flag = true;
				}
				break;
			case 2:
				label3.Text = this.Main.C_global.GetFourStepTypeDescription((int)fourStepAtomStruct.TypeOfData, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text2, out num2, out num3, out num4) + text;
				label3.ForeColor = foreColor;
				label10.Text = text2;
				numberEdit3.MaxValue = fourStepAtomStruct.MaxValue;
				numberEdit3.MinValue = fourStepAtomStruct.MinValue;
				numberEdit3.DecimalNum = (int)num4;
				numberEdit3.Value = fourStepAtomStruct.Value;
				label3.Visible = visible;
				label10.Visible = visible;
				numberEdit3.Visible = visible;
				if (!numberEdit3.IsOK)
				{
					flag = true;
				}
				break;
			case 3:
				label4.Text = this.Main.C_global.GetFourStepTypeDescription((int)fourStepAtomStruct.TypeOfData, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text2, out num2, out num3, out num4) + text;
				label4.ForeColor = foreColor;
				label11.Text = text2;
				numberEdit4.MaxValue = fourStepAtomStruct.MaxValue;
				numberEdit4.MinValue = fourStepAtomStruct.MinValue;
				numberEdit4.DecimalNum = (int)num4;
				numberEdit4.Value = fourStepAtomStruct.Value;
				label4.Visible = visible;
				label11.Visible = visible;
				numberEdit4.Visible = visible;
				if (!numberEdit4.IsOK)
				{
					flag = true;
				}
				break;
			case 4:
				label5.Text = this.Main.C_global.GetFourStepTypeDescription((int)fourStepAtomStruct.TypeOfData, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text2, out num2, out num3, out num4) + text;
				label5.ForeColor = foreColor;
				label12.Text = text2;
				numberEdit5.MaxValue = fourStepAtomStruct.MaxValue;
				numberEdit5.MinValue = fourStepAtomStruct.MinValue;
				numberEdit5.DecimalNum = (int)num4;
				numberEdit5.Value = fourStepAtomStruct.Value;
				label5.Visible = visible;
				label12.Visible = visible;
				numberEdit5.Visible = visible;
				if (!numberEdit5.IsOK)
				{
					flag = true;
				}
				break;
			case 5:
				label6.Text = this.Main.C_global.GetFourStepTypeDescription((int)fourStepAtomStruct.TypeOfData, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text2, out num2, out num3, out num4) + text;
				label6.ForeColor = foreColor;
				label13.Text = text2;
				numberEdit6.MaxValue = fourStepAtomStruct.MaxValue;
				numberEdit6.MinValue = fourStepAtomStruct.MinValue;
				numberEdit6.DecimalNum = (int)num4;
				numberEdit6.Value = fourStepAtomStruct.Value;
				label6.Visible = visible;
				label13.Visible = visible;
				numberEdit6.Visible = visible;
				if (!numberEdit6.IsOK)
				{
					flag = true;
				}
				break;
			case 6:
				label7.Text = this.Main.C_global.GetFourStepTypeDescription((int)fourStepAtomStruct.TypeOfData, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text2, out num2, out num3, out num4) + text;
				label7.ForeColor = foreColor;
				label14.Text = text2;
				numberEdit7.MaxValue = fourStepAtomStruct.MaxValue;
				numberEdit7.MinValue = fourStepAtomStruct.MinValue;
				numberEdit7.DecimalNum = (int)num4;
				numberEdit7.Value = fourStepAtomStruct.Value;
				label7.Visible = visible;
				label14.Visible = visible;
				numberEdit7.Visible = visible;
				if (!numberEdit7.IsOK)
				{
					flag = true;
				}
				break;
			}
			return flag;
		}

		private bool getValueProperty(int indexFourStep, int index)
		{
			bool result = false;
			NumberEdit1 numberEdit = null;
			NumberEdit1 numberEdit2 = null;
			NumberEdit1 numberEdit3 = null;
			NumberEdit1 numberEdit4 = null;
			NumberEdit1 numberEdit5 = null;
			NumberEdit1 numberEdit6 = null;
			NumberEdit1 numberEdit7 = null;
			switch (indexFourStep)
			{
			case 0:
				numberEdit = this.nEFind1;
				numberEdit2 = this.nEFind2;
				numberEdit3 = this.nEFind3;
				numberEdit4 = this.nEFind4;
				numberEdit5 = this.nEFind5;
				numberEdit6 = this.nEFind6;
				numberEdit7 = this.nEFind7;
				break;
			case 1:
				numberEdit = this.nEFlowDrill1;
				numberEdit2 = this.nEFlowDrill2;
				numberEdit3 = this.nEFlowDrill3;
				numberEdit4 = this.nEFlowDrill4;
				numberEdit5 = this.nEFlowDrill5;
				numberEdit6 = this.nEFlowDrill6;
				numberEdit7 = this.nEFlowDrill7;
				break;
			case 2:
				numberEdit = this.nEScrew1;
				numberEdit2 = this.nEScrew2;
				numberEdit3 = this.nEScrew3;
				numberEdit4 = this.nEScrew4;
				numberEdit5 = this.nEScrew5;
				numberEdit6 = this.nEScrew6;
				numberEdit7 = this.nEScrew7;
				break;
			case 3:
				numberEdit = this.nETighten1;
				numberEdit2 = this.nETighten2;
				numberEdit3 = this.nETighten3;
				numberEdit4 = this.nETighten4;
				numberEdit5 = this.nETighten5;
				numberEdit6 = this.nETighten6;
				numberEdit7 = this.nETighten7;
				break;
			default:
				return true;
			}
			WSP1_VarComm.FourStepAtomStruct fourStepAtomStruct = this.PD.FourProg.FourthStep[indexFourStep].FourStepAtoms[index];
			switch (index)
			{
			case 0:
				if (!numberEdit.IsOK)
				{
					result = true;
				}
				fourStepAtomStruct.Value = numberEdit.Value;
				break;
			case 1:
				if (!numberEdit2.IsOK)
				{
					result = true;
				}
				fourStepAtomStruct.Value = numberEdit2.Value;
				break;
			case 2:
				if (!numberEdit3.IsOK)
				{
					result = true;
				}
				fourStepAtomStruct.Value = numberEdit3.Value;
				break;
			case 3:
				if (!numberEdit4.IsOK)
				{
					result = true;
				}
				fourStepAtomStruct.Value = numberEdit4.Value;
				break;
			case 4:
				if (!numberEdit5.IsOK)
				{
					result = true;
				}
				fourStepAtomStruct.Value = numberEdit5.Value;
				break;
			case 5:
				if (!numberEdit6.IsOK)
				{
					result = true;
				}
				fourStepAtomStruct.Value = numberEdit6.Value;
				break;
			case 6:
				if (!numberEdit7.IsOK)
				{
					result = true;
				}
				fourStepAtomStruct.Value = numberEdit7.Value;
				break;
			}
			return result;
		}

		private void enableFourControl(bool visible, int fourthElement, int valueElement)
		{
			switch (fourthElement)
			{
			case 0:
				switch (valueElement)
				{
				case 0:
					this.lbDescriptionFind1.Visible = visible;
					this.nEFind1.Visible = visible;
					this.lbUnitFind1.Visible = visible;
					break;
				case 1:
					this.lbDescriptionFind2.Visible = visible;
					this.nEFind2.Visible = visible;
					this.lbUnitFind2.Visible = visible;
					break;
				case 2:
					this.lbDescriptionFind3.Visible = visible;
					this.nEFind3.Visible = visible;
					this.lbUnitFind3.Visible = visible;
					break;
				case 3:
					this.lbDescriptionFind4.Visible = visible;
					this.nEFind4.Visible = visible;
					this.lbUnitFind4.Visible = visible;
					break;
				case 4:
					this.lbDescriptionFind5.Visible = visible;
					this.nEFind5.Visible = visible;
					this.lbUnitFind5.Visible = visible;
					break;
				case 5:
					this.lbDescriptionFind6.Visible = visible;
					this.nEFind6.Visible = visible;
					this.lbUnitFind6.Visible = visible;
					break;
				case 6:
					this.lbDescriptionFind7.Visible = visible;
					this.nEFind7.Visible = visible;
					this.lbUnitFind7.Visible = visible;
					break;
				}
				break;
			case 1:
				switch (valueElement)
				{
				case 0:
					this.lbDescriptionFlowDrill1.Visible = visible;
					this.nEFlowDrill1.Visible = visible;
					this.lbUnitFlowDrill1.Visible = visible;
					break;
				case 1:
					this.lbDescriptionFlowDrill2.Visible = visible;
					this.nEFlowDrill2.Visible = visible;
					this.lbUnitFlowDrill2.Visible = visible;
					break;
				case 2:
					this.lbDescriptionFlowDrill3.Visible = visible;
					this.nEFlowDrill3.Visible = visible;
					this.lbUnitFlowDrill3.Visible = visible;
					break;
				case 3:
					this.lbDescriptionFlowDrill4.Visible = visible;
					this.nEFlowDrill4.Visible = visible;
					this.lbUnitFlowDrill4.Visible = visible;
					break;
				case 4:
					this.lbDescriptionFlowDrill5.Visible = visible;
					this.nEFlowDrill5.Visible = visible;
					this.lbUnitFlowDrill5.Visible = visible;
					break;
				case 5:
					this.lbDescriptionFlowDrill6.Visible = visible;
					this.nEFlowDrill6.Visible = visible;
					this.lbUnitFlowDrill6.Visible = visible;
					break;
				case 6:
					this.lbDescriptionFlowDrill7.Visible = visible;
					this.nEFlowDrill7.Visible = visible;
					this.lbUnitFlowDrill7.Visible = visible;
					break;
				}
				break;
			case 2:
				switch (valueElement)
				{
				case 0:
					this.lbDescriptionScrew1.Visible = visible;
					this.nEScrew1.Visible = visible;
					this.lbUnitScrew1.Visible = visible;
					break;
				case 1:
					this.lbDescriptionScrew2.Visible = visible;
					this.nEScrew2.Visible = visible;
					this.lbUnitScrew2.Visible = visible;
					break;
				case 2:
					this.lbDescriptionScrew3.Visible = visible;
					this.nEScrew3.Visible = visible;
					this.lbUnitScrew3.Visible = visible;
					break;
				case 3:
					this.lbDescriptionScrew4.Visible = visible;
					this.nEScrew4.Visible = visible;
					this.lbUnitScrew4.Visible = visible;
					break;
				case 4:
					this.lbDescriptionScrew5.Visible = visible;
					this.nEScrew5.Visible = visible;
					this.lbUnitScrew5.Visible = visible;
					break;
				case 5:
					this.lbDescriptionScrew6.Visible = visible;
					this.nEScrew6.Visible = visible;
					this.lbUnitScrew6.Visible = visible;
					break;
				case 6:
					this.lbDescriptionScrew7.Visible = visible;
					this.nEScrew7.Visible = visible;
					this.lbUnitScrew7.Visible = visible;
					break;
				}
				break;
			case 3:
				switch (valueElement)
				{
				case 0:
					this.lbDescriptionTighten1.Visible = visible;
					this.nETighten1.Visible = visible;
					this.lbUnitTighten1.Visible = visible;
					break;
				case 1:
					this.lbDescriptionTighten2.Visible = visible;
					this.nETighten2.Visible = visible;
					this.lbUnitTighten2.Visible = visible;
					break;
				case 2:
					this.lbDescriptionTighten3.Visible = visible;
					this.nETighten3.Visible = visible;
					this.lbUnitTighten3.Visible = visible;
					break;
				case 3:
					this.lbDescriptionTighten4.Visible = visible;
					this.nETighten4.Visible = visible;
					this.lbUnitTighten4.Visible = visible;
					break;
				case 4:
					this.lbDescriptionTighten5.Visible = visible;
					this.nETighten5.Visible = visible;
					this.lbUnitTighten5.Visible = visible;
					break;
				case 5:
					this.lbDescriptionTighten6.Visible = visible;
					this.nETighten6.Visible = visible;
					this.lbUnitTighten6.Visible = visible;
					break;
				case 6:
					this.lbDescriptionTighten7.Visible = visible;
					this.nETighten7.Visible = visible;
					this.lbUnitTighten7.Visible = visible;
					break;
				}
				break;
			}
		}

		public void InitializeValue(int indexFourStep, int index)
		{
			if (indexFourStep < this.PD.FourProg.FourthStep.Length && this.PD.FourProg.FourthStep[indexFourStep].FourStepAtoms[index].StepIndex >= 128)
			{
				this.errorReading4StepData |= this.setValueProperty(indexFourStep, index, this.PD.Info.Steps);
				this.enableFourControl(true, indexFourStep, index);
			}
		}

		private void initializeValues(bool allowEnable)
		{
			this.errorReading4StepData = false;
			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 7; j++)
				{
					if (allowEnable && this.PD.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex >= 128)
					{
						this.enableFourControl(true, i, j);
						this.errorReading4StepData |= this.setValueProperty(i, j, this.PD.Info.Steps);
					}
					else
					{
						this.enableFourControl(false, i, j);
					}
				}
			}
			this.lbProgNum.Text = this.Main.Rm.GetString("Abr_Program") + " " + this.PNum.ToString();
			this.lbProgName.Text = this.Main.CommonFunctions.UShortToString(this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Info.Name);
		}

		public bool IsStepContainedIn4Step(WSP1_VarComm.ProgStruct pd, byte step)
		{
			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 7; j++)
				{
					int stepIndex = pd.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex;
					if (stepIndex >= 128 && (stepIndex & 0x7F) == step)
					{
						return true;
					}
				}
			}
			return false;
		}

		public void InsertedStep(WSP1_VarComm.ProgStruct pd, byte step)
		{
			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 7; j++)
				{
					int stepIndex = pd.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex;
					if (stepIndex >= 128 && (stepIndex & 0x7F) >= step)
					{
						stepIndex++;
						pd.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex = (byte)stepIndex;
					}
				}
			}
		}

		public void DeletedStep(WSP1_VarComm.ProgStruct pd, byte step)
		{
			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 7; j++)
				{
					int stepIndex = pd.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex;
					if (stepIndex >= 128 && (stepIndex & 0x7F) > step)
					{
						stepIndex--;
						pd.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex = (byte)stepIndex;
					}
				}
			}
		}

		private void checkAtomsWeedOutUninitializedStepIndex()
		{
			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 7; j++)
				{
					if (this.PD.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex == 255)
					{
						this.PD.FourProg.FourthStep[i].FourStepAtoms[j].StepIndex = 0;
					}
				}
			}
		}

		private void cBTargetName_SelectedIndexChanged(object sender, EventArgs e)
		{
			bool isInitializeMode = this.IsInitializeMode;
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				string text = this.setProgramValues(false);
				if (text != null && text.Length > 0)
				{
					text += "\n Should the values be stored in any case?";
					DialogResult dialogResult = MessageBox.Show(text, this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
					if (dialogResult == DialogResult.Cancel)
					{
						return;
					}
				}
				this.pnMenu.Enabled = false;
				for (int i = 0; i < this.Main.VC.PProg.Num[this.PNum].Info.Steps; i++)
				{
					this.Main.ProcessProgram.CompareStepStruct(this.PD.Step[i], this.Main.VC.PProg.Num[this.PNum].Step[i], this.PNum, i, 2);
				}
				this.Main.VC.PProgXChanged.Changed[this.PNum] = 1;
				this.Main.StatusBarText(string.Empty);
				this.Main.ProgramOverview1.UpdateMenu();
				this.writeCaption(false);
				base.Hide();
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_1_6_Vier_Stufen_Konzept";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_1_6_Vier_Stufen_Konzept");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.Main.DeleteLogEntries(2, this.PNum);
			this.bCanceled = true;
			this.pnMenu.Enabled = false;
			this.Main.StatusBarText(string.Empty);
			this.writeCaption(false);
			base.Hide();
		}

		private void btEditFind_Click(object sender, EventArgs e)
		{
			this.Main.VC.makeCopyFourProgStruct(ref this.PD_save.FourProg, this.PD.FourProg);
			this.setProgramValues(false);
			this.Main.FourStepEdit1.ShowWindow(this.PNum, this.gBFind.Text, 0, this.PD);
		}

		private void btEditFlowDrill_Click(object sender, EventArgs e)
		{
			this.Main.VC.makeCopyFourProgStruct(ref this.PD_save.FourProg, this.PD.FourProg);
			this.setProgramValues(false);
			this.Main.FourStepEdit1.ShowWindow(this.PNum, this.gBFlowDrill.Text, 1, this.PD);
		}

		private void btEditScrew_Click(object sender, EventArgs e)
		{
			this.Main.VC.makeCopyFourProgStruct(ref this.PD_save.FourProg, this.PD.FourProg);
			this.setProgramValues(false);
			this.Main.FourStepEdit1.ShowWindow(this.PNum, this.gBScrew.Text, 2, this.PD);
		}

		private void btEditTighten_Click(object sender, EventArgs e)
		{
			this.Main.VC.makeCopyFourProgStruct(ref this.PD_save.FourProg, this.PD.FourProg);
			this.setProgramValues(false);
			this.Main.FourStepEdit1.ShowWindow(this.PNum, this.gBTighten.Text, 3, this.PD);
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void chBxx_CheckedChanged(object sender, EventArgs e)
		{
			this.MenEna();
		}

		private void FourStepOverviewForm_Activated(object sender, EventArgs e)
		{
			if (this.Main.FourStepEdit1.WasCanceled)
			{
				this.Main.VC.makeCopyFourProgStruct(ref this.PD.FourProg, this.PD_save.FourProg);
			}
			else
			{
				this.Main.VC.makeCopyFourProgStruct(ref this.PD_save.FourProg, this.PD.FourProg);
			}
			this.MenEna();
			this.bCanceled = false;
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		public void KeyArrived()
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else if (this.Main.PassCodeLevel > 0)
			{
				if (this.Main.GetExclusiveBlock1())
				{
					if (this.Main.ProcessProgram.UploadAllProgDataFromController())
					{
						this.Main.CheckParamAllowed = true;
						this.writeCaption(false);
						base.Hide();
						this.Main.StepOverview1.Hide();
					}
				}
				else
				{
					this.Main.CheckParamAllowed = false;
				}
			}
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void btStoreSettings_Click(object sender, EventArgs e)
		{
			this.saveFileDialog.InitialDirectory = Settings.Default.User4StepDirectory;
			if (this.saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				if (this.saveFileDialog.InitialDirectory != Settings.Default.User4StepDirectory)
				{
					Settings.Default.User4StepDirectory = Path.GetDirectoryName(this.saveFileDialog.InitialDirectory);
					Settings.Default.Save();
				}
				FourStepClass fourStepClass = new FourStepClass();
				fourStepClass.Write(this.saveFileDialog.FileName, this.PD.FourProg);
			}
		}

		private void btLoadSettings_Click(object sender, EventArgs e)
		{
			this.openFileDialog.InitialDirectory = Settings.Default.User4StepDirectory;
			if (this.openFileDialog.ShowDialog() == DialogResult.OK)
			{
				if (this.openFileDialog.InitialDirectory != Settings.Default.User4StepDirectory)
				{
					Settings.Default.User4StepDirectory = Path.GetDirectoryName(this.openFileDialog.InitialDirectory);
					Settings.Default.Save();
				}
				FourStepClass fourStepClass = new FourStepClass();
				fourStepClass.Read(this.openFileDialog.FileName, ref this.PD.FourProg);
				this.Main.SettingsChanged();
				this.getProgramValues();
				this.initializeValues(true);
			}
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.IsInitializeMode)
			{
				this.Main.SettingsChanged();
			}
		}
	}
}
