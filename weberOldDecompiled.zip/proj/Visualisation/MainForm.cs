using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Deployment.Application;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Reflection;
using System.Resources;
using System.Threading;
using System.Windows.Forms;
using Visualisation.Properties;
using Visualisation.USB_Key;
using WSP1_VARCOMM1;
using WUSB_KeyVerwaltung;

namespace Visualisation
{
	public class MainForm : Form
	{
		private delegate void SetTextCallback(string text);

		private const string READ_ONLY_CNTROLLER_DEFINITION = "/READ_ONLY_CONTROLLER";

		private const byte EXCLUSIVEBLOCK_NOACCESS = 0;

		private const byte EXCLUSIVEBLOCK_REQUEST = 1;

		private const byte EXCLUSIVEBLOCK_PERMITTED = 2;

		private const byte SAVEBLOCK_REQUEST = 1;

		private const byte STAT_DELETE = 1;

		private const byte STAT_NONE = 0;

		private const int USER_ACCESS_GRANTED = 1;

		private const int USER_ACCESS_DENIED = 2;

		private const int USER_ACCESS_IN_PREPARATION = 3;

		private const int USER_ACCESS_NONE = 0;

		private const int USB_KEY_ACCESS_DENIED_PASSWORD_EXPIRED = 1;

		private const int USB_KEY_ACCESS_DENIED_PASSWORD_CANCELED = 2;

		private const int USB_KEY_ACCESS_GRANTED = 3;

		private const int USB_KEY_ACCESS_NOT_ACTIVE = 0;

		private const int USB_KEY_ACCESS_DENIED_WRONG_AREA = 4;

		public readonly string MACHINE_VISU_ERROR_TEXT_FILE = "rsf_sprachdatei_error_logfile.xml";

		public bool _READ_ONLY_CONTROLLER;

		public C_CommonFunctions CommonFunctions;

		public WSP1_VarComm VC;

		public C_VisibleParameters VisibleParameters;

		public C_ProcessProgram ProcessProgram;

		public C_SimplePrint SimplePrint;

		public C_XMLParamOut XmlParamOut;

		public C_CurveOutput CurveOut;

		public ResourceManager Rm;

		public CurveFifoClass CurveFifo;

		public AdvanceWarningForm AdvanceWarning1;

		public BackupForm Backup1;

		public CheckParamForm CheckParam1;

		public CurveDisplayForm CurveDisplay1;

		public VisualisationParamForm VisualisationParam1;

		public ComponentForm Component1;

		public CycleCounterForm CycleCounter1;

		public EditDrivingStepForm EditDrivingStep1;

		public EditFinalizeStepForm EditFinalizeStep1;

		public EditOrganizeStepForm EditOrganizeStep1;

		public FourStepEditForm FourStepEdit1;

		public FourStepOverviewForm FourStepOverview1;

		public HandStartForm HandStart1;

		public LastNIOResultsForm LastNIOResults1;

		public LogBookForm LogBookForm1;

		public LogChangesForm LogChangesForm1;

		public MaintenanceForm Maintenance1;

		public MenuAnalysisForm MenuAnalysis1;

		public MenuMaintenanceForm MenuMaintenance1;

		public MenuParameterForm MenuParameter1;

		public MenuStatisticsForm MenuStatistics1;

		public MenuTestForm MenuTest1;

		public PasscodeManagerForm PasscodeManager1;

		public PrgOptParameterForm PrgOptParameter1;

		public ProgramOverviewForm ProgramOverview1;

		public ResultDisplayForm ResultDisplay1;

		public SpindleConstantsForm SpindleConstants1;

		public StatisticsLastResForm StatisticsLastRes1;

		public StepOverviewForm StepOverview1;

		public StepResultForm StepResult1;

		public SystemConstantsForm SystemConstants1;

		public LevelAssignmentForm LevelAssignment1;

		public TestIOForm TestIO1;

		public TestMotorSensorForm TestMotorSensor1;

		public TestSPSIOForm TestSPSIO1;

		public TopTenForm TopTen1;

		public BrowserForm Browser1;

		public BrowserHelpForm BrowserHelp;

		public Ping_Class ControllerPing;

		public FtpProgressForm FtpProgress;

		public ResultMiniDisplayForm ResultMiniDisplay1;

		public ErrorDisplayForm ErrorDisplay1;

		public PasswordInputForm PasswordInput1;

		private USB_PasswordForm usb_PasswordInput1;

		public NumberPadForm NumberPad1;

		public KeyPadForm KeyPad1;

		private USB_Class usb_class;

		private byte usb_PassCodeLevel;

		private string usb_ActualUser = "";

		public string Usb_Password_MD5;

		public DateTime Usb_TimeLimitation;

		public List<string> Areas = new List<string>();

		public bool IsOfflineVersion;

		public bool IsOnlineMode;

		public bool ViewOnlyMode;

		public bool CheckParamAllowed;

		public byte PassCodeLevel;

		private string actualUser = "";

		private string currentUsbDrive = "";

		public List<string> currentUsbAreas = new List<string>();

		public bool ShowVisParWindow;

		private byte Block1Status;

		private byte Block2Status;

		private byte SaveBlockStatus;

		private byte StatDeleteStatus;

		public float TorqueConvert;

		public string TorqueUnitName = "";

		private int LifeSign;

		public string LocalizedHelpFile = "";

		public string SourceDirectoryForHelp = "";

		public string HelpFileName = "";

		public Label lbIsOnlineMode;

		private StatusBar statusBar;

		public Label lbIsAutoMode;

		private System.Windows.Forms.Timer timerControllerOffline;

		private Panel pnStatusBar;

		public Label lbError;

		public Label lbLivingSign;

		private System.Windows.Forms.Timer timerControllerLivingSign;

		private IContainer components;

		private System.Windows.Forms.Timer timerUserDataToKernel;

		public Label lbUser;

		public Label lbMaintenance;

		private System.Windows.Forms.Timer timerCheckMaintenance;

		public Label lbRemainingCurves;

		public Label lbMachineVisu;

		public Label lbProcessVisu;

		private System.Windows.Forms.Timer timerHome;

		public string NioCurveToShow = "";

		private ErrorLogMachineVisuClass machineVisuError;

		private ErrorLogProcessVisuClass processVisuError;

		private Form activationBrowserGrantedBy;

		private C_Global c_global = new C_Global();

		private System.Windows.Forms.Timer timerInitialize;

		public bool DISPLAY_LIVING_SIGN;

		public bool recent_DISPLAY_LIVING_SIGN;

		private System.Windows.Forms.Timer timerDelayKeyRemoved;

		private System.Windows.Forms.Timer timerDelayKeyArrived;

		private static int _STATUS_LABEL_WIDTH = 63;

		private bool closeWithoutQuery;

		private bool settingsChanged;

		private int recentUserAccessMode;

		private string recentActualUser = "";

		private byte recentActualLevel;

		private string recentStatusText = "";

		public Point FtpProgressLocation = Point.Empty;

		public bool OpenGivenProgram;

		public string OpenGivenProgramPath = "";

		private List<LogEntryClass> logEntryList = new List<LogEntryClass>();

		private int currentLogSectionCounter;

		public int NumberPadCharacters;

		private bool usbKeyAccessGranted;

		private bool processingUsbKeyRemovedEvent;

		private bool enterPasswordInProgress;

		private bool loginSuccessfulCompleted;

		private bool usbKeyAccessCanceledByUser;

		private int usb_key_access_result;

		private UsbDetectorEventArgs currentUsbDetectorArguments;

		private Random rnd = new Random();

		private bool usb_key_access;

		private IPAddress myip = IPAddress.None;

		private bool livingSignInit;

		public USB_Class Usb_class => this.usb_class;

		public byte Usb_PassCodeLevel
		{
			get
			{
				return this.usb_PassCodeLevel;
			}
			set
			{
				this.usb_PassCodeLevel = value;
			}
		}

		public string Usb_ActualUser
		{
			get
			{
				return this.usb_ActualUser;
			}
			set
			{
				this.usb_ActualUser = value;
			}
		}

		public string ActualUser
		{
			get
			{
				return this.actualUser;
			}
			set
			{
				this.actualUser = value;
			}
		}

		public ErrorLogMachineVisuClass MachineVisuError => this.machineVisuError;

		public ErrorLogProcessVisuClass ProcessVisuError => this.processVisuError;

		public Form ActivationBrowserGrantedBy
		{
			set
			{
				if (value == null)
				{
					this.WeberLogoImage(1);
				}
				else
				{
					this.WeberLogoImage(2);
				}
				this.activationBrowserGrantedBy = value;
			}
		}

		public C_Global C_global => this.c_global;

		public bool LoginSuccessfulCompleted => this.loginSuccessfulCompleted;

		public bool UsbKeyAccessCanceledByUser => this.usbKeyAccessCanceledByUser;

		public IPAddress MyIp => this.myip;

		public string GetVisuError(uint code)
		{
			if (code < 1000)
			{
				return this.MachineVisuError.TextOf((int)code);
			}
			return this.ProcessVisuError.TextOf((int)code);
		}

		public void ResetBrowserGrantedBy()
		{
			this.WeberLogoImage(1);
			this.activationBrowserGrantedBy = null;
		}

		public bool AreSettingsChanged()
		{
			return this.settingsChanged;
		}

		public void SettingsChangedReset()
		{
			this.settingsChanged = false;
		}

		public void SettingsChanged()
		{
			this.settingsChanged = true;
		}

		public bool DiscardAnySettings()
		{
			Form activeMdiChild = base.ActiveMdiChild;
			if (activeMdiChild != this.MenuMaintenance1 && activeMdiChild != this.MenuAnalysis1 && activeMdiChild != this.MenuParameter1 && activeMdiChild != this.MenuTest1)
			{
				if (!this.settingsChanged)
				{
					return true;
				}
				DialogResult dialogResult = MessageBox.Show(this.Rm.GetString("MbShouldChangesDiscarded"), this.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);
				if (dialogResult == DialogResult.Yes)
				{
					this.settingsChanged = false;
					return true;
				}
				return false;
			}
			return true;
		}

		public void IncrementDownloadProgressBar()
		{
			if (this.FtpProgress != null)
			{
				this.FtpProgress.IncrementDownloadProgressBar();
			}
		}

		public void MaxDownloadProgressBar()
		{
			if (this.FtpProgress != null)
			{
				this.FtpProgress.MaxDownloadProgressBar();
			}
		}

		public void ShowCurrentUserAccessState(int userLevelForMenuAccess, bool viewOnly)
		{
			if (this.PassCodeLevel >= userLevelForMenuAccess && !viewOnly)
			{
				this.userToStatus(this.recentUserAccessMode, true);
			}
			else
			{
				this.lbUser.BackColor = Color.Red;
				this.lbUser.ForeColor = Color.White;
			}
			Application.DoEvents();
		}

		private void userToStatus(int userAccessMode, bool sendToKernel)
		{
			this.recentUserAccessMode = userAccessMode;
			this.userToStatus(sendToKernel);
			switch (userAccessMode)
			{
			case 2:
				this.lbUser.BackColor = Color.Red;
				this.lbUser.ForeColor = Color.White;
				break;
			case 1:
				this.lbUser.BackColor = Color.Lime;
				this.lbUser.ForeColor = Color.Black;
				break;
			case 3:
				this.lbUser.BackColor = Color.Yellow;
				this.lbUser.ForeColor = Color.Black;
				break;
			case 0:
				this.lbUser.BackColor = SystemColors.Control;
				this.lbUser.ForeColor = SystemColors.ControlText;
				break;
			}
		}

		private void userToStatus(bool sendToKernel)
		{
			if (this.ActualUser.Length > 0)
			{
				this.Rm.GetString(this.c_global.GetAccessLevelDefinition(this.PassCodeLevel));
				this.lbUser.Text = this.ActualUser + "(" + this.PassCodeLevel.ToString() + ")";
			}
			else
			{
				this.lbUser.Text = "--(" + this.PassCodeLevel.ToString() + ")";
			}
			if (sendToKernel)
			{
				this.checkForUserDataToKernel(this.ActualUser, this.PassCodeLevel);
			}
		}

		private bool resetCurrentUserDataInKernel()
		{
			if (!this.IsOnlineMode)
			{
				return false;
			}
			WSP1_VarComm.UserRelatedData_Struct userRelatedData_Struct = new WSP1_VarComm.UserRelatedData_Struct();
			this.CommonFunctions.StringToByte(ref userRelatedData_Struct.UserName, "", 5);
			userRelatedData_Struct.UserLevel = 0;
			this.VC.makeCopyUserRelatedData(ref this.VC.UserRelatedData, userRelatedData_Struct);
			if (!this.VC.SendVarBlock(44))
			{
				this.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show("Could not send UserRelatedData!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			return true;
		}

		public bool SendCurrentUserDataToKernel()
		{
			WSP1_VarComm.UserRelatedData_Struct userRelatedData_Struct = new WSP1_VarComm.UserRelatedData_Struct();
			this.CommonFunctions.StringToByte(ref userRelatedData_Struct.UserName, this.ActualUser, 5);
			userRelatedData_Struct.UserLevel = this.PassCodeLevel;
			this.VC.makeCopyUserRelatedData(ref this.VC.UserRelatedData, userRelatedData_Struct);
			if (!this.VC.SendVarBlock(44))
			{
				this.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show("Could not send UserRelatedData!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			return true;
		}

		private bool checkForUserDataToKernel(string actualUser, byte actualLevel)
		{
			bool result = false;
			if (actualLevel != this.recentActualLevel || (actualUser != this.recentActualUser && this.recentActualUser.Length > 0 && this.recentActualUser != "--"))
			{
				if (actualLevel == 0 && this.recentActualLevel == 0)
				{
					return false;
				}
				WSP1_VarComm.UserRelatedData_Struct userRelatedData_Struct = new WSP1_VarComm.UserRelatedData_Struct();
				this.CommonFunctions.StringToByte(ref userRelatedData_Struct.UserName, this.ActualUser, 5);
				userRelatedData_Struct.UserLevel = this.PassCodeLevel;
				string empty = string.Empty;
				empty = Dns.GetHostName();
				IPHostEntry hostEntry = Dns.GetHostEntry(empty);
				IPAddress[] addressList = hostEntry.AddressList;
				if (addressList.Length > 0)
				{
					for (int i = 0; i < addressList.Length; i++)
					{
						bool flag = true;
						byte[] addressBytes = addressList[i].GetAddressBytes();
						for (int j = 0; j < addressBytes.Length && j < 10; j++)
						{
							userRelatedData_Struct.IpAddress[j] = addressBytes[j];
							if (addressBytes[j] == 0)
							{
								flag = false;
								break;
							}
						}
						if (flag)
						{
							break;
						}
						for (int k = 0; k < 10; k++)
						{
							userRelatedData_Struct.IpAddress[k] = 0;
						}
					}
				}
				this.VC.makeCopyUserRelatedData(ref this.VC.UserRelatedData, userRelatedData_Struct);
				this.timerUserDataToKernel.Start();
				result = true;
			}
			this.recentActualLevel = actualLevel;
			this.recentActualUser = actualUser;
			return result;
		}

		private void timerUserDataToKernel_Tick(object sender, EventArgs e)
		{
			this.timerUserDataToKernel.Stop();
			if (this.IsOnlineMode && !this.VC.SendVarBlock(44))
			{
				this.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show("Could not send UserRelatedData!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		public void StatusBarText(string text)
		{
			this.statusBar.Text = "";
			this.userToStatus(true);
			StatusBar obj = this.statusBar;
			obj.Text += text;
			this.recentStatusText = text;
		}

		public void DisplayCurrentUser()
		{
			this.StatusBarText("");
			this.userToStatus(true);
			StatusBar obj = this.statusBar;
			obj.Text += this.recentStatusText;
		}

		public void ResetPasscodeLevel()
		{
			if (!this.Usb_Key_Access() && this.actualUser.Length > 0 && this.PassCodeLevel > 0)
			{
				this.PassCodeLevel = 0;
				this.CommonFunctions.StringToByte(ref this.VC.PLCCommData.Output.UserName, "", 5);
				this.actualUser = "";
				this.checkForUserDataToKernel(this.ActualUser, this.PassCodeLevel);
				this.DisplayCurrentUser();
			}
		}

		public MainForm()
		{
			this.CommonFunctions = new C_CommonFunctions(this);
			this.InitializeComponent();
			this.timerControllerOffline.Interval = 1000;
			this.lbIsAutoMode.Text = string.Empty;
			base.LayoutMdi(MdiLayout.ArrangeIcons);
			this.LocalizedHelpFile = string.Empty;
			this.SourceDirectoryForHelp = string.Empty;
			this.HelpFileName = string.Empty;
			this.MakeVisualSettings();
			this.VC = new WSP1_VarComm();
			this.VisibleParameters = new C_VisibleParameters();
			this.ProcessProgram = new C_ProcessProgram(this);
			this.SimplePrint = new C_SimplePrint();
			this.XmlParamOut = new C_XMLParamOut(this);
			this.CurveOut = new C_CurveOutput(this);
			this.CurveFifo = new CurveFifoClass(this);
			this.AdvanceWarning1 = new AdvanceWarningForm(this);
			this.Backup1 = new BackupForm(this);
			this.CheckParam1 = new CheckParamForm(this);
			this.CurveDisplay1 = new CurveDisplayForm(this);
			this.VisualisationParam1 = new VisualisationParamForm(this);
			this.CycleCounter1 = new CycleCounterForm(this);
			this.Component1 = new ComponentForm(this);
			this.EditDrivingStep1 = new EditDrivingStepForm(this);
			this.EditFinalizeStep1 = new EditFinalizeStepForm(this);
			this.EditOrganizeStep1 = new EditOrganizeStepForm(this);
			this.FourStepEdit1 = new FourStepEditForm(this);
			this.FourStepOverview1 = new FourStepOverviewForm(this);
			this.HandStart1 = new HandStartForm(this);
			this.LastNIOResults1 = new LastNIOResultsForm(this);
			this.LogBookForm1 = new LogBookForm(this);
			this.LogChangesForm1 = new LogChangesForm(this);
			this.Maintenance1 = new MaintenanceForm(this);
			this.MenuAnalysis1 = new MenuAnalysisForm(this);
			this.MenuMaintenance1 = new MenuMaintenanceForm(this);
			this.MenuParameter1 = new MenuParameterForm(this);
			this.MenuStatistics1 = new MenuStatisticsForm(this);
			this.MenuTest1 = new MenuTestForm(this);
			this.PasscodeManager1 = new PasscodeManagerForm(this);
			this.ProgramOverview1 = new ProgramOverviewForm(this);
			this.PrgOptParameter1 = new PrgOptParameterForm(this);
			this.ResultDisplay1 = new ResultDisplayForm(this);
			this.SpindleConstants1 = new SpindleConstantsForm(this);
			this.StatisticsLastRes1 = new StatisticsLastResForm(this);
			this.StepOverview1 = new StepOverviewForm(this);
			this.StepResult1 = new StepResultForm(this);
			this.SystemConstants1 = new SystemConstantsForm(this);
			this.LevelAssignment1 = new LevelAssignmentForm(this);
			this.TestIO1 = new TestIOForm(this);
			this.TestMotorSensor1 = new TestMotorSensorForm(this);
			this.TestSPSIO1 = new TestSPSIOForm(this);
			this.TopTen1 = new TopTenForm(this);
			this.Browser1 = new BrowserForm(this);
			this.BrowserHelp = new BrowserHelpForm(this);
			this.ControllerPing = new Ping_Class();
			this.FtpProgress = new FtpProgressForm(this);
			this.ResultMiniDisplay1 = new ResultMiniDisplayForm(this);
			this.ErrorDisplay1 = new ErrorDisplayForm(this);
			this.PasswordInput1 = new PasswordInputForm(this);
			this.usb_PasswordInput1 = new USB_PasswordForm(this, "");
			this.NumberPad1 = new NumberPadForm(this);
			this.KeyPad1 = new KeyPadForm(this);
			this.machineVisuError = new ErrorLogMachineVisuClass(this);
			this.processVisuError = new ErrorLogProcessVisuClass(this);
			this.AdvanceWarning1.MdiParent = this;
			this.Backup1.MdiParent = this;
			this.CheckParam1.MdiParent = this;
			this.CurveDisplay1.MdiParent = this;
			this.VisualisationParam1.MdiParent = this;
			this.Component1.MdiParent = this;
			this.CycleCounter1.MdiParent = this;
			this.EditDrivingStep1.MdiParent = this;
			this.EditFinalizeStep1.MdiParent = this;
			this.EditOrganizeStep1.MdiParent = this;
			this.FourStepEdit1.MdiParent = this;
			this.FourStepOverview1.MdiParent = this;
			this.HandStart1.MdiParent = this;
			this.LastNIOResults1.MdiParent = this;
			this.LogBookForm1.MdiParent = this;
			this.LogChangesForm1.MdiParent = this;
			this.Maintenance1.MdiParent = this;
			this.MenuAnalysis1.MdiParent = this;
			this.MenuMaintenance1.MdiParent = this;
			this.MenuParameter1.MdiParent = this;
			this.MenuStatistics1.MdiParent = this;
			this.MenuTest1.MdiParent = this;
			this.PasscodeManager1.MdiParent = this;
			this.PrgOptParameter1.MdiParent = this;
			this.ProgramOverview1.MdiParent = this;
			this.ResultDisplay1.MdiParent = this;
			this.SpindleConstants1.MdiParent = this;
			this.StatisticsLastRes1.MdiParent = this;
			this.StepOverview1.MdiParent = this;
			this.StepResult1.MdiParent = this;
			this.SystemConstants1.MdiParent = this;
			this.LevelAssignment1.MdiParent = this;
			this.TestIO1.MdiParent = this;
			this.TestMotorSensor1.MdiParent = this;
			this.TestSPSIO1.MdiParent = this;
			this.TopTen1.MdiParent = this;
			this.Browser1.MdiParent = this;
			this.BrowserHelp.MdiParent = this;
			this.FtpProgress.MdiParent = this;
			this.VC.VARSERVEREVENT_StatusAccessControl += this.VSE_StatusAccessControl;
			this.VC.VARSERVEREVENT_SaveControl += this.VSE_SaveControl;
			this.VC.VARSERVEREVENT_Error += this.VSE_Error;
			this.VC.VARSERVEREVENT_StatControl += this.VSE_StatControl;
			this.VC.VARSERVEREVENT_StatusAutomatic += this.VSE_StatusAutomatic;
			this.IsOfflineVersion = false;
			this.PassCodeLevel = 0;
			this.IsOnlineMode = false;
			this.CheckParamAllowed = true;
			this.Block1Status = 0;
			this.Block2Status = 0;
			this.SaveBlockStatus = 0;
			this.StatDeleteStatus = 0;
			this.ViewOnlyMode = false;
			this.TorqueConvert = 1f;
			this.TorqueUnitName = "Nm";
			this.LifeSign = 0;
			base.HorizontalScroll.Enabled = false;
			base.VerticalScroll.Enabled = false;
			this.lbLivingSign.Text = "";
			this.timerControllerLivingSign.Interval = 5000;
			this.initLivingSignControls();
			this.CurveDisplay1.C_Curve1.DisplayStepsInCurves = Settings.Default.DisplayStepsInCurves;
			try
			{
				string[] parameters = MainArgumentsClass.GetParameters();
				string str = "";
				if (parameters != null)
				{
					string[] array = parameters;
					foreach (string text in array)
					{
						str = str + text + "\n";
						if (text.ToUpper().EndsWith("/READ_ONLY_CONTROLLER".ToUpper()))
						{
							this._READ_ONLY_CONTROLLER = true;
						}
					}
				}
			}
			catch (Exception)
			{
			}
		}

		private void initLivingSignControls()
		{
			if (!this.DISPLAY_LIVING_SIGN)
			{
				this.lbLivingSign.Visible = false;
				Size size = new Size(500 + this.lbLivingSign.Size.Width, this.pnStatusBar.Size.Height);
				this.pnStatusBar.Size = size;
			}
			else
			{
				this.lbLivingSign.Visible = true;
				Size size2 = new Size(500, this.pnStatusBar.Size.Height);
				this.pnStatusBar.Size = size2;
			}
			Point point = new Point(this.pnStatusBar.Location.X + this.pnStatusBar.Width - this.lbMaintenance.Width - this.lbUser.Width, this.lbMaintenance.Location.Y);
			Label label = this.lbRemainingCurves;
			Label label2 = this.lbMaintenance;
			Point point4 = label.Location = (label2.Location = point);
			this.FtpProgressLocation = new Point(point.X - 225, point.Y - 50);
			this.FtpProgress.Location = this.FtpProgressLocation;
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			OperatingSystem oSVersion = Environment.OSVersion;
			if (oSVersion.Platform == PlatformID.Win32NT && oSVersion.Version.Major == 5)
			{
				this.MaximumSize = new Size(800, 580);
				base.Size = new Size(800, 580);
			}
			this.SetAllLanguageTexts();
			this.timerInitialize.Start();
			this.SettingsChangedReset();
		}

		protected override void Dispose(bool disposing)
		{
			this.VC.CloseConnection();
			if (this.ErrorDisplay1 != null)
			{
				this.ErrorDisplay1.DestructErrorThread();
			}
			OperatingSystem oSVersion = Environment.OSVersion;
			if (oSVersion.Platform == PlatformID.Win32NT && oSVersion.Version.Major == 5)
			{
				if (this.BrowserHelp != null)
				{
					this.BrowserHelp.Dispose();
				}
				if (this.Browser1 != null)
				{
					this.Browser1.Dispose();
				}
			}
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timerControllerOffline = new System.Windows.Forms.Timer(this.components);
			this.statusBar = new System.Windows.Forms.StatusBar();
			this.lbIsOnlineMode = new System.Windows.Forms.Label();
			this.pnStatusBar = new System.Windows.Forms.Panel();
			this.lbRemainingCurves = new System.Windows.Forms.Label();
			this.lbMaintenance = new System.Windows.Forms.Label();
			this.lbIsAutoMode = new System.Windows.Forms.Label();
			this.lbError = new System.Windows.Forms.Label();
			this.lbLivingSign = new System.Windows.Forms.Label();
			this.timerControllerLivingSign = new System.Windows.Forms.Timer(this.components);
			this.timerInitialize = new System.Windows.Forms.Timer(this.components);
			this.timerDelayKeyRemoved = new System.Windows.Forms.Timer(this.components);
			this.timerDelayKeyArrived = new System.Windows.Forms.Timer(this.components);
			this.timerUserDataToKernel = new System.Windows.Forms.Timer(this.components);
			this.lbUser = new System.Windows.Forms.Label();
			this.timerCheckMaintenance = new System.Windows.Forms.Timer(this.components);
			this.lbMachineVisu = new System.Windows.Forms.Label();
			this.lbProcessVisu = new System.Windows.Forms.Label();
			this.timerHome = new System.Windows.Forms.Timer(this.components);
			this.pnStatusBar.SuspendLayout();
			this.SuspendLayout();
			// 
			// timerControllerOffline
			// 
			this.timerControllerOffline.Interval = 8000;
			// 
			// statusBar
			// 
			this.statusBar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.statusBar.Dock = System.Windows.Forms.DockStyle.None;
			this.statusBar.Location = new System.Drawing.Point(8, -2);
			this.statusBar.Name = "statusBar";
			this.statusBar.Size = new System.Drawing.Size(425, 20);
			this.statusBar.TabIndex = 21;
			// 
			// lbIsOnlineMode
			// 
			this.lbIsOnlineMode.BackColor = System.Drawing.SystemColors.Control;
			this.lbIsOnlineMode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbIsOnlineMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbIsOnlineMode.Location = new System.Drawing.Point(733, 524);
			this.lbIsOnlineMode.Name = "lbIsOnlineMode";
			this.lbIsOnlineMode.Size = new System.Drawing.Size(60, 22);
			this.lbIsOnlineMode.TabIndex = 22;
			this.lbIsOnlineMode.Text = "Offline";
			// 
			// pnStatusBar
			// 
			this.pnStatusBar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pnStatusBar.Controls.Add(this.statusBar);
			this.pnStatusBar.Location = new System.Drawing.Point(64, 524);
			this.pnStatusBar.Name = "pnStatusBar";
			this.pnStatusBar.Size = new System.Drawing.Size(438, 22);
			this.pnStatusBar.TabIndex = 25;
			// 
			// lbRemainingCurves
			// 
			this.lbRemainingCurves.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbRemainingCurves.BackColor = System.Drawing.Color.Lime;
			this.lbRemainingCurves.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbRemainingCurves.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.lbRemainingCurves.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbRemainingCurves.ForeColor = System.Drawing.Color.Black;
			this.lbRemainingCurves.Location = new System.Drawing.Point(399, 524);
			this.lbRemainingCurves.Name = "lbRemainingCurves";
			this.lbRemainingCurves.Size = new System.Drawing.Size(97, 22);
			this.lbRemainingCurves.TabIndex = 38;
			this.lbRemainingCurves.Text = "Curves";
			this.lbRemainingCurves.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lbRemainingCurves.Visible = false;
			// 
			// lbMaintenance
			// 
			this.lbMaintenance.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbMaintenance.BackColor = System.Drawing.Color.Yellow;
			this.lbMaintenance.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbMaintenance.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.lbMaintenance.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbMaintenance.ForeColor = System.Drawing.Color.Black;
			this.lbMaintenance.Location = new System.Drawing.Point(399, 524);
			this.lbMaintenance.Name = "lbMaintenance";
			this.lbMaintenance.Size = new System.Drawing.Size(97, 22);
			this.lbMaintenance.TabIndex = 36;
			this.lbMaintenance.Text = "Maintenance";
			this.lbMaintenance.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			this.lbMaintenance.Visible = false;
			// 
			// lbIsAutoMode
			// 
			this.lbIsAutoMode.BackColor = System.Drawing.SystemColors.Control;
			this.lbIsAutoMode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbIsAutoMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbIsAutoMode.Location = new System.Drawing.Point(683, 524);
			this.lbIsAutoMode.Name = "lbIsAutoMode";
			this.lbIsAutoMode.Size = new System.Drawing.Size(50, 22);
			this.lbIsAutoMode.TabIndex = 27;
			this.lbIsAutoMode.Text = "Notaus";
			this.lbIsAutoMode.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// lbError
			// 
			this.lbError.BackColor = System.Drawing.SystemColors.Control;
			this.lbError.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbError.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbError.Location = new System.Drawing.Point(633, 524);
			this.lbError.Name = "lbError";
			this.lbError.Size = new System.Drawing.Size(50, 22);
			this.lbError.TabIndex = 29;
			this.lbError.Text = "Error";
			this.lbError.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// lbLivingSign
			// 
			this.lbLivingSign.BackColor = System.Drawing.SystemColors.Control;
			this.lbLivingSign.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbLivingSign.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbLivingSign.Location = new System.Drawing.Point(496, 524);
			this.lbLivingSign.Name = "lbLivingSign";
			this.lbLivingSign.Size = new System.Drawing.Size(50, 22);
			this.lbLivingSign.TabIndex = 31;
			this.lbLivingSign.Text = "Robot";
			this.lbLivingSign.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// timerControllerLivingSign
			// 
			this.timerControllerLivingSign.Interval = 8000;
			// 
			// timerDelayKeyRemoved
			// 
			this.timerDelayKeyRemoved.Interval = 50;
			// 
			// timerDelayKeyArrived
			// 
			this.timerDelayKeyArrived.Interval = 50;
			// 
			// lbUser
			// 
			this.lbUser.BackColor = System.Drawing.SystemColors.Control;
			this.lbUser.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbUser.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.lbUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbUser.Location = new System.Drawing.Point(2, 524);
			this.lbUser.Name = "lbUser";
			this.lbUser.Size = new System.Drawing.Size(66, 21);
			this.lbUser.TabIndex = 32;
			this.lbUser.Text = "MMMM(-)";
			this.lbUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// timerCheckMaintenance
			// 
			this.timerCheckMaintenance.Interval = 10000;
			// 
			// lbMachineVisu
			// 
			this.lbMachineVisu.BackColor = System.Drawing.SystemColors.Control;
			this.lbMachineVisu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbMachineVisu.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbMachineVisu.Location = new System.Drawing.Point(545, 524);
			this.lbMachineVisu.Name = "lbMachineVisu";
			this.lbMachineVisu.Size = new System.Drawing.Size(92, 22);
			this.lbMachineVisu.TabIndex = 40;
			this.lbMachineVisu.Text = "Machine-Visu";
			this.lbMachineVisu.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// lbProcessVisu
			// 
			this.lbProcessVisu.BackColor = System.Drawing.SystemColors.Control;
			this.lbProcessVisu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbProcessVisu.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.lbProcessVisu.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbProcessVisu.Location = new System.Drawing.Point(545, 524);
			this.lbProcessVisu.Name = "lbProcessVisu";
			this.lbProcessVisu.Size = new System.Drawing.Size(92, 22);
			this.lbProcessVisu.TabIndex = 42;
			this.lbProcessVisu.Text = "Process-Visu";
			this.lbProcessVisu.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// timerHome
			// 
			this.timerHome.Interval = 50;
			// 
			// MainForm
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(782, 553);
			this.Controls.Add(this.lbProcessVisu);
			this.Controls.Add(this.lbMachineVisu);
			this.Controls.Add(this.lbRemainingCurves);
			this.Controls.Add(this.lbMaintenance);
			this.Controls.Add(this.lbUser);
			this.Controls.Add(this.lbLivingSign);
			this.Controls.Add(this.lbError);
			this.Controls.Add(this.lbIsAutoMode);
			this.Controls.Add(this.pnStatusBar);
			this.Controls.Add(this.lbIsOnlineMode);
			this.DoubleBuffered = true;
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.HelpButton = true;
			this.IsMdiContainer = true;
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(800, 600);
			this.MinimizeBox = false;
			this.Name = "MainForm";
			this.ShowIcon = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "MainForm";
			this.pnStatusBar.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		[STAThread]
		private static void Main(string[] args)
		{
			Application.ThreadException += MainForm.Application_ThreadException;
			AppDomain.CurrentDomain.UnhandledException += MainForm.CurrentDomain_UnhandledException;
			//try
			{
				MainForm mainForm = new MainForm();
				if (args.Length >= 2 && args[0] == "/PROGRAMS" && args[1].Length > 0)
				{
					mainForm.OpenGivenProgram = true;
					mainForm.OpenGivenProgramPath = args[1];
				}
				Application.Run(mainForm);
			}
			//catch (SystemException ex)
			//{
			//	MessageBox.Show("Main, SystemException: " + ex.InnerException.ToString());
			//}
			//catch (Exception ex2)
			//{
			//	MessageBox.Show(ex2.Message);
			//}
		}

		private static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
		{
			MessageBox.Show(e.Exception.Message, "Main: Unhandled Thread Exception");
		}

		private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			MessageBox.Show((e.ExceptionObject as Exception).Message, "Main: Unhandled UI Exception");
		}

		public void MenEna()
		{
			this.ShowCurrentUserAccessState(0, false);
			if (this.IsOnlineMode)
			{
				this.lbIsOnlineMode.Text = this.Rm.GetString("OnlineMode");
				this.lbIsOnlineMode.BackColor = Color.Lime;
				byte autoMode = this.VC.Status0.AutoMode;
				if (autoMode == 1)
				{
					this.lbIsAutoMode.Text = this.Rm.GetString("AutoMode");
					this.lbIsAutoMode.BackColor = SystemColors.Control;
				}
				else
				{
					this.lbIsAutoMode.Text = this.Rm.GetString("HandMode");
					this.lbIsAutoMode.BackColor = SystemColors.Control;
				}
				if (this.VC.Status0.PowerEnabled == 0)
				{
					this.lbIsAutoMode.Text = this.Rm.GetString("EMGMode");
					this.lbIsAutoMode.BackColor = Color.Red;
				}
				if (this.VC.ErrorSys.Num != 0)
				{
					if (this.VC.ErrorSys.Warning == 0)
					{
						this.lbError.BackColor = Color.Red;
						this.lbError.Text = this.Rm.GetString("ErrorMode");
					}
					else
					{
						this.lbError.BackColor = Color.Yellow;
						this.lbError.Text = "WarningMode";
					}
				}
				else
				{
					this.lbError.BackColor = Color.Lime;
					this.lbError.Text = this.Rm.GetString("NoErrorMode");
				}
			}
			else
			{
				this.lbIsOnlineMode.Text = this.Rm.GetString("OfflineMode");
				this.lbIsOnlineMode.BackColor = Color.Red;
				this.lbIsAutoMode.Text = string.Empty;
				this.lbIsAutoMode.BackColor = SystemColors.Control;
				this.lbError.BackColor = SystemColors.Control;
				this.lbError.Text = string.Empty;
			}
			this.ResultMiniDisplay1.MenEna();
		}

		public void MakeVisualSettings()
		{
			switch (Settings.Default.Language)
			{
			case 0:
				this.Rm = new CustomResourceManager("Visualisation.LanguageText_en", base.GetType().Assembly);
				this.HelpFileName = "Manual_en.htm";
				break;
			case 1:
				this.Rm = new CustomResourceManager("Visualisation.LanguageText_de", base.GetType().Assembly);
				this.HelpFileName = "Manual_de.htm";
				break;
			case 2:
				this.Rm = new CustomResourceManager("Visualisation.LanguageText_fr", base.GetType().Assembly);
				this.HelpFileName = "Manual_fr.htm";
				break;
			case 3:
				this.Rm = new CustomResourceManager("Visualisation.LanguageText_it", base.GetType().Assembly);
				this.HelpFileName = "Manual_it.htm";
				break;
			case 4:
				this.Rm = new CustomResourceManager("Visualisation.LanguageText_es", base.GetType().Assembly);
				this.HelpFileName = "Manual_es.htm";
				break;
			case 5:
				this.Rm = new CustomResourceManager("Visualisation.LanguageText_cz", base.GetType().Assembly);
				this.HelpFileName = "Manual_cz.htm";
				break;
			case 6:
				this.Rm = new CustomResourceManager("Visualisation.LanguageText_sk", base.GetType().Assembly);
				this.HelpFileName = "Manual_sk.htm";
				break;
			case 7:
				this.Rm = new CustomResourceManager("Visualisation.LanguageText_hu", base.GetType().Assembly);
				this.HelpFileName = "Manual_hu.htm";
				break;
			default:
				MessageBox.Show("Wrong Properties.Settings.Default.Language in MakeVisualSettings() of MainForm", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				Settings.Default.Language = 0;
				Settings.Default.Save();
				this.Rm = new CustomResourceManager("Visualisation.LanguageText_en", base.GetType().Assembly);
				this.HelpFileName = "Manual_en.htm";
				break;
			}
			this.LocalizedHelpFile = this.SourceDirectoryForHelp + this.HelpFileName;
			MessageBoxManager.OK = this.Rm.GetString("MsgBoxOk");
			MessageBoxManager.Cancel = this.Rm.GetString("MsgBoxCancel");
			MessageBoxManager.Retry = this.Rm.GetString("MsgBoxRetry");
			MessageBoxManager.Ignore = this.Rm.GetString("MsgBoxIgnore");
			MessageBoxManager.Abort = this.Rm.GetString("MsgBoxAbort");
			MessageBoxManager.Yes = this.Rm.GetString("MsgBoxYes");
			MessageBoxManager.No = this.Rm.GetString("MsgBoxNo");
			MessageBoxManager.Properties = this.Rm.GetString("MsgBoxProperties");
			MessageBoxManager.Store = this.Rm.GetString("MsgBoxStore");
			MessageBoxManager.OutpuInFile = this.Rm.GetString("MsgBoxOutputInFile");
			MessageBoxManager.Sorting = this.Rm.GetString("MsgBoxSorting");
			MessageBoxManager.All = this.Rm.GetString("MsgBoxAll");
			MessageBoxManager.Marking = this.Rm.GetString("MsgBoxMarking");
			MessageBoxManager.Pages = this.Rm.GetString("MsgBoxPages");
			MessageBoxManager.Copies = this.Rm.GetString("MsgBoxCopies");
			MessageBoxManager.PrintRange = this.Rm.GetString("MsgBoxPrintRange");
			MessageBoxManager.Printer = this.Rm.GetString("MsgBoxPrinter");
			MessageBoxManager.NumberOfCopies = this.Rm.GetString("MsgBoxNumberOfCopies");
			MessageBoxManager.CreateNewFolder = this.Rm.GetString("MsgBoxCreateNewFolder");
			if (!MessageBoxManager.IsRegistered())
			{
				MessageBoxManager.Register();
			}
		}

		public void SetAllLanguageTexts()
		{
			try
			{
				this.AdvanceWarning1.SetLanguageTexts();
				this.Backup1.SetLanguageTexts();
				this.BrowserHelp.SetLanguageTexts();
				this.CheckParam1.SetLanguageTexts();
				this.Component1.SetLanguageTexts();
				this.CurveDisplay1.SetLanguageTexts();
				this.CycleCounter1.SetLanguageTexts();
				this.EditDrivingStep1.SetLanguageTexts();
				this.EditFinalizeStep1.SetLanguageTexts();
				this.EditOrganizeStep1.SetLanguageTexts();
				this.FourStepEdit1.SetLanguageTexts();
				this.FourStepOverview1.SetLanguageTexts();
				this.ErrorDisplay1.SetLanguageTexts();
				this.HandStart1.SetLanguageTexts();
				this.KeyPad1.SetLanguageTexts();
				this.LastNIOResults1.SetLanguageTexts();
				this.LogBookForm1.SetLanguageTexts();
				this.LogChangesForm1.SetLanguageTexts();
				this.Maintenance1.SetLanguageTexts();
				this.MenuAnalysis1.SetLanguageTexts();
				this.MenuMaintenance1.SetLanguageTexts();
				this.MenuStatistics1.SetLanguageTexts();
				this.MenuTest1.SetLanguageTexts();
				this.NumberPad1.SetLanguageTexts();
				this.PasscodeManager1.SetLanguageTexts();
				this.PasswordInput1.SetLanguageTexts();
				this.ProgramOverview1.SetLanguageTexts();
				this.PrgOptParameter1.SetLanguageTexts();
				this.ResultMiniDisplay1.SetLanguageTexts();
				this.SpindleConstants1.SetLanguageTexts();
				this.StatisticsLastRes1.SetLanguageTexts();
				this.StepOverview1.SetLanguageTexts();
				this.StepResult1.SetLanguageTexts();
				this.TestIO1.SetLanguageTexts();
				this.TestMotorSensor1.SetLanguageTexts();
				this.TestSPSIO1.SetLanguageTexts();
				this.ProcessProgram.SetLanguageTexts();
				this.TopTen1.SetLanguageTexts();
				this.usb_PasswordInput1.SetLanguageTexts();
				this.ResultDisplay1.SetLanguageTexts();
				this.MenuParameter1.SetLanguageTexts();
				this.MenuParameter1.BringToFront();
				this.SystemConstants1.SetLanguageTexts();
				this.SystemConstants1.BringToFront();
				this.LevelAssignment1.SetLanguageTexts();
				this.VisualisationParam1.SetLanguageTexts();
				this.VisualisationParam1.BringToFront();
				this.lbMaintenance.Text = this.Rm.GetString("MenuMaintenance");
				this.lbMachineVisu.Text = this.Rm.GetString("LbMachineVisu");
				this.lbProcessVisu.Text = this.Rm.GetString("LbProcessVisu");
				this.MenEna();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
				Settings.Default.Language = 0;
				Settings.Default.Save();
			}
		}

		private void MainForm_MdiChildActivate(object sender, EventArgs e)
		{
			this.SetMainText();
			if (this.activationBrowserGrantedBy == null)
			{
				this.lbProcessVisu.Enabled = false;
			}
			else
			{
				this.lbProcessVisu.Enabled = true;
			}
		}

		public void SetMainText()
		{
			if (base.ActiveMdiChild != null && base.ActiveMdiChild.Text.Length > 0)
			{
				string text = "";
				if (this._READ_ONLY_CONTROLLER)
				{
					text = "(Read Only) ";
				}
				this.Text = this.Rm.GetString("ControllerName") + " " + text + this.CommonFunctions.UShortToString(this.VC.SysConst.IdentServerName) + "/" + base.ActiveMdiChild.Text;
			}
		}

		public void ToFront()
		{
			base.TopMost = true;
			base.Focus();
			base.BringToFront();
			base.TopMost = false;
		}

		private void MainForm_Paint(object sender, PaintEventArgs e)
		{
		}

		public void ShowMachineVisu()
		{
			if (this.PassCodeLevel < Settings.Default.UserLevel_BrowserForm)
			{
				if (this.Usb_Key_Access() && !this.UsbPluggedButNotLoggedIn())
				{
					MessageBox.Show(this.Rm.GetString("MbLoginBeforeFunctionStart"), this.Rm.GetString("MbhHint"));
					return;
				}
				if (this.Usb_Key_Access() && this.UsbPluggedPasswordExpired())
				{
					MessageBox.Show(this.Rm.GetString("MbhNoAccess"), this.Rm.GetString("MbhHint"));
					return;
				}
				this.UsbKeyQuery();
				if (!this.usbKeyAccessCanceledByUser)
				{
					this.changeWindows();
				}
			}
			else
			{
				this.changeWindows();
			}
			if (this.activationBrowserGrantedBy == null && this.IsOnlineMode && Settings.Default.IntegratedMachineVisu)
			{
				if (this.PassCodeLevel < Settings.Default.UserLevel_BrowserForm && this.Usb_Key_Access())
				{
					return;
				}
				MessageBox.Show(this.Rm.GetString("MbMachineVisuShowNotAllowed"), this.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}

		public void WriteLogbookData(bool resetTheSettingsChangedFlag)
		{
			if (this.IsOnlineMode && this.StationAvailable())
			{
				int num = 0;
				if (this.VC.LogBookWriteData_elements != 0)
				{
					this.StatusBarText(this.Rm.GetString("WriteLogbookData"));
					this.VC.LogBookWriteControl.Command = 1;
					if (!this.VC.SendVarBlock(61))
					{
						this.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						MessageBox.Show("Could not send LogbookWriteDataBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else if (!this.VC.SendVarBlock(60))
					{
						this.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						MessageBox.Show("Could not send LogbookWriteControlBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						while (this.VC.LogBookWriteControl.Command != 0)
						{
							if (num <= 5 && this.VC.ReceiveVarBlock(60))
							{
								Thread.Sleep(50);
								num++;
								continue;
							}
							this.StatusBarText(string.Empty);
							Cursor.Current = Cursors.Default;
							MessageBox.Show(this.Rm.GetString("MbLogbookWriteFailure"), this.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
							break;
						}
					}
					this.StatusBarText(string.Empty);
					this.LoggingFinished(resetTheSettingsChangedFlag);
				}
			}
		}

		public void MakeLogbookEntry(uint code, ushort type, float oldvalue, float newvalue, uint prog, int step, byte unit)
		{
			if (this.VC.LogBookWriteData_elements < 2500)
			{
				this.VC.LogBookWriteData.LogData[this.VC.LogBookWriteData_elements].Code = code;
				this.VC.LogBookWriteData.LogData[this.VC.LogBookWriteData_elements].Type = type;
				this.CommonFunctions.StringToUShort(ref this.VC.LogBookWriteData.LogData[this.VC.LogBookWriteData_elements].userName, this.ActualUser, 5);
				this.VC.LogBookWriteData.LogData[this.VC.LogBookWriteData_elements].Value1 = oldvalue;
				this.VC.LogBookWriteData.LogData[this.VC.LogBookWriteData_elements].Value2 = newvalue;
				this.VC.LogBookWriteData.LogData[this.VC.LogBookWriteData_elements].ProgNum = prog;
				this.VC.LogBookWriteData.LogData[this.VC.LogBookWriteData_elements].Step = (byte)step;
				this.VC.LogBookWriteData.LogData[this.VC.LogBookWriteData_elements].UnitIndex = unit;
				this.VC.LogBookWriteData_elements += 1u;
			}
		}

		public void NewLogSection()
		{
			this.currentLogSectionCounter++;
		}

		public void MakeLogbookEntry(uint code, ushort type, float oldvalue, float newvalue, uint prog, int step, byte unit, byte logLevel, int logIdentifier)
		{
			if (logLevel > 0 && logLevel != 255)
			{
				this.logEntryList.Add(new LogEntryClass(logLevel, this.VC.LogBookWriteData_elements, logIdentifier + this.currentLogSectionCounter * 1024));
			}
			this.MakeLogbookEntry(code, type, oldvalue, newvalue, prog, step, unit);
		}

		public void DeleteLogEntries(byte logLevel, int logIdentifier)
		{
			byte b;
			switch (logLevel)
			{
			case 1:
				b = 15;
				break;
			case 2:
				b = 14;
				break;
			case 4:
				b = 12;
				break;
			default:
				b = 8;
				break;
			}
			try
			{
				int count = this.logEntryList.Count;
				if (count != 0)
				{
					for (int num = count - 1; num >= 0; num--)
					{
						LogEntryClass logEntryClass = this.logEntryList[num];
						if (logEntryClass.LogLevel != 255 && logEntryClass.LogIdentifier == logIdentifier + this.currentLogSectionCounter * 1024 && (logEntryClass.LogLevel & b) != 0)
						{
							logEntryClass.LogLevel = byte.MaxValue;
							this.VC.LogBookWriteData.LogData[logEntryClass.ElementIndex].ProgNum = uint.MaxValue;
							this.VC.LogBookWriteData_elements -= 1u;
						}
					}
					for (int num2 = count; num2 <= 0; num2--)
					{
						if (this.logEntryList[num2].ElementIndex == uint.MaxValue)
						{
							this.logEntryList.RemoveAt(num2);
						}
					}
					for (int i = 0; i < count; i++)
					{
						if (this.VC.LogBookWriteData.LogData[i].ProgNum == uint.MaxValue)
						{
							for (int j = i; j < count - 1; j++)
							{
								this.VC.LogBookWriteData.LogData[j].Code = this.VC.LogBookWriteData.LogData[j + 1].Code;
								this.VC.LogBookWriteData.LogData[j].Type = this.VC.LogBookWriteData.LogData[j + 1].Type;
								for (int k = 0; k < 5; k++)
								{
									this.VC.LogBookWriteData.LogData[this.VC.LogBookWriteData_elements].userName[k] = this.VC.LogBookWriteData.LogData[this.VC.LogBookWriteData_elements + 1].userName[k];
								}
								this.CommonFunctions.StringToUShort(ref this.VC.LogBookWriteData.LogData[this.VC.LogBookWriteData_elements].userName, this.ActualUser, 5);
								this.VC.LogBookWriteData.LogData[j].Value1 = this.VC.LogBookWriteData.LogData[j + 1].Value1;
								this.VC.LogBookWriteData.LogData[j].Value2 = this.VC.LogBookWriteData.LogData[j + 1].Value2;
								this.VC.LogBookWriteData.LogData[j].ProgNum = this.VC.LogBookWriteData.LogData[j + 1].ProgNum;
								this.VC.LogBookWriteData.LogData[j].Step = this.VC.LogBookWriteData.LogData[j + 1].Step;
								this.VC.LogBookWriteData.LogData[j].UnitIndex = this.VC.LogBookWriteData.LogData[j + 1].UnitIndex;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		public void LoggingFinished(bool resetTheSettingsChangedFlag)
		{
			if (resetTheSettingsChangedFlag)
			{
				this.SettingsChangedReset();
			}
			this.logEntryList.Clear();
			this.VC.LogBookWriteData_elements = 0u;
			this.currentLogSectionCounter = 0;
		}

		public void TextInput(object sender, string text)
		{
			this.KeyPad1.Title = text;
			this.TextInput(sender);
		}

		public void TextInput(object sender)
		{
			if (sender.GetType() == typeof(NumberEdit1))
			{
				NumberEdit1 numberEdit = sender as NumberEdit1;
				if (numberEdit.Visible)
				{
					this.StatusBarText(this.Rm.GetString("ValueRange") + ": " + numberEdit.MinValue.ToString("f" + numberEdit.DecimalNum.ToString()) + " - " + numberEdit.MaxValue.ToString("f" + numberEdit.DecimalNum.ToString()));
					if (Settings.Default.SoftKeyBoardIsUsed)
					{
						float value = numberEdit.Value;
						this.NumberPad1.ShowNumberPad(numberEdit);
						this.StatusBarText("");
						if (value != numberEdit.Value)
						{
							this.SettingsChanged();
						}
						this.NumberPadCharacters = this.NumberPad1.NumberOfCharacters;
					}
				}
			}
			else if (sender.GetType() == typeof(NumericUpDown))
			{
				NumericUpDown numericUpDown = sender as NumericUpDown;
				if (numericUpDown.Visible)
				{
					this.StatusBarText(this.Rm.GetString("ValueRange") + ": " + numericUpDown.Minimum.ToString() + " - " + numericUpDown.Maximum.ToString());
					if (Settings.Default.SoftKeyBoardIsUsed)
					{
						decimal value2 = numericUpDown.Value;
						this.NumberPad1.ShowNumberPad(numericUpDown);
						if (value2 != numericUpDown.Value)
						{
							this.SettingsChanged();
						}
						this.StatusBarText("");
					}
				}
			}
			else if (sender.GetType() == typeof(TextBox))
			{
				TextBox textBox = sender as TextBox;
				if (textBox.Visible && Settings.Default.SoftKeyBoardIsUsed)
				{
					string text = textBox.Text;
					this.KeyPad1.ShowKeyPad(textBox);
					if (text != textBox.Text)
					{
						this.SettingsChanged();
					}
				}
			}
			else if (sender.GetType() == typeof(ComboBox))
			{
				ComboBox comboBox = sender as ComboBox;
				if (comboBox.Visible && Settings.Default.SoftKeyBoardIsUsed)
				{
					string text2 = comboBox.Text;
					this.KeyPad1.ShowKeyPad((ComboBox)sender);
					if (text2 != comboBox.Text)
					{
						this.SettingsChanged();
					}
				}
			}
			else
			{
				this.StatusBarText(string.Empty);
			}
		}

		public void DisableHelpButton()
		{
			base.HelpButton = false;
		}

		private void changeWindows()
		{
			try
			{
				if (this.BrowserHelp.HelpActive)
				{
					this.BrowserHelp.HideHelp();
					base.HelpButton = true;
				}
				else if (this.Browser1.MachineVisuActive)
				{
					this.hideMachineVisu();
					base.HelpButton = true;
				}
				else if (this.activationBrowserGrantedBy != null && this.IsOnlineMode && Settings.Default.IntegratedMachineVisu && (this.PassCodeLevel >= Settings.Default.UserLevel_BrowserForm || !this.Usb_Key_Access()))
				{
					this.checkActiveFormBrowserStart(false);
					base.HelpButton = false;
				}
				else if (this.activationBrowserGrantedBy != null && this.IsOnlineMode && Settings.Default.IntegratedMachineVisu && (this.PassCodeLevel < Settings.Default.UserLevel_BrowserForm || !this.Usb_Key_Access()))
				{
					MessageBox.Show(this.Rm.GetString("MbLoginBeforeFunctionStart"), this.Rm.GetString("MbhHint"));
				}
				if (!this.BrowserHelp.HelpActive && !this.Browser1.MachineVisuActive)
				{
					if (this.activationBrowserGrantedBy == null)
					{
						this.WeberLogoImage(1);
					}
					else if (this.IsOnlineMode)
					{
						this.WeberLogoImage(2);
					}
				}
			}
			catch (Exception)
			{
			}
		}

		private bool checkActiveFormBrowserStart(bool checkOnly)
		{
			bool result = true;
			Form activeMdiChild = base.ActiveMdiChild;
			if (activeMdiChild == this.Component1 && !checkOnly)
			{
				this.Component1.BrowserShow();
			}
			if (activeMdiChild == this.CycleCounter1)
			{
				if (!checkOnly)
				{
					this.CycleCounter1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.ResultDisplay1)
			{
				if (!checkOnly)
				{
					this.ResultDisplay1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.CurveDisplay1)
			{
				if (!checkOnly)
				{
					this.CurveDisplay1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.LastNIOResults1)
			{
				if (!checkOnly)
				{
					this.LastNIOResults1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.LogBookForm1)
			{
				if (!checkOnly)
				{
					this.LogBookForm1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.LogChangesForm1)
			{
				if (!checkOnly)
				{
					this.LogChangesForm1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.Maintenance1)
			{
				if (!checkOnly)
				{
					this.Maintenance1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.MenuStatistics1)
			{
				if (!checkOnly)
				{
					this.MenuStatistics1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.MenuAnalysis1)
			{
				if (!checkOnly)
				{
					this.MenuAnalysis1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.MenuMaintenance1)
			{
				if (!checkOnly)
				{
					this.MenuMaintenance1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.HandStart1)
			{
				if (!checkOnly)
				{
					this.HandStart1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.MenuTest1)
			{
				if (!checkOnly)
				{
					this.MenuTest1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.TestIO1)
			{
				if (!checkOnly)
				{
					this.TestIO1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.TestMotorSensor1)
			{
				if (!checkOnly)
				{
					this.TestMotorSensor1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.TestSPSIO1)
			{
				if (!checkOnly)
				{
					this.TestSPSIO1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.StatisticsLastRes1)
			{
				if (!checkOnly)
				{
					this.StatisticsLastRes1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.StepResult1)
			{
				if (!checkOnly)
				{
					this.StepResult1.BrowserShow();
				}
			}
			else if (activeMdiChild == this.TopTen1)
			{
				if (!checkOnly)
				{
					this.TopTen1.BrowserShow();
				}
			}
			else
			{
				result = false;
			}
			return result;
		}

		public void WeberLogoImage(int logoType)
		{
			if (logoType == 3)
			{
				this.lbIsOnlineMode.Visible = true;
				this.lbMachineVisu.Visible = true;
				this.lbProcessVisu.Visible = false;
			}
			else
			{
				this.lbIsOnlineMode.Visible = true;
				this.lbMachineVisu.Visible = false;
				this.lbProcessVisu.Visible = true;
			}
		}

		private void showWeberLogo()
		{
		}

		private void hideMachineVisu()
		{
			if (this.Browser1.MachineVisuActive)
			{
				if (this.Browser1.ActivatedByForm == this.ResultDisplay1)
				{
					this.Browser1.HideMachineVisu();
					this.ResultDisplay1.Hide();
					this.ResultDisplay1.ShowWindow();
				}
				else
				{
					this.Browser1.HideMachineVisu();
				}
				base.ActivateMdiChild(this.Browser1.ActivatedByForm);
			}
		}

		public void DoActivateMdiChild(Form child)
		{
			base.ActivateMdiChild(child);
		}

		private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (this.closeWithoutQuery)
			{
				e.Cancel = false;
			}
			else if (this.Browser1.MachineVisuActive)
			{
				e.Cancel = true;
				if (!this.Browser1.PreviousPage())
				{
					this.changeWindows();
				}
			}
			else if (this.BrowserHelp.HelpActive)
			{
				e.Cancel = true;
				this.changeWindows();
			}
			else if (base.ActiveMdiChild != this.ResultDisplay1 && base.ActiveMdiChild != null)
			{
				e.Cancel = true;
				MessageBox.Show(this.Rm.GetString("MbClosingOnlyFromMainMenu"), this.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else if (this.CurveDisplay1.IsAutomaticCurveModeActive())
			{
				if (MessageBox.Show(this.Rm.GetString("mbAutomaticStorageActive"), this.Rm.GetString("MbhHint"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
				{
					this.CurveDisplay1.ResetCycleSaveMode();
				}
				e.Cancel = false;
			}
			else
			{
				DialogResult dialogResult = MessageBox.Show(this.Rm.GetString("MbExit"), this.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
				try
				{
					if (dialogResult == DialogResult.Yes)
					{
						this.PassCodeLevel = 0;
						this.actualUser = "";
						if (this.loginSuccessfulCompleted && this.usb_PassCodeLevel > 0)
						{
							this.resetCurrentUserDataInKernel();
						}
						e.Cancel = false;
						this.BrowserHelp.PrepareForShutDown();
						this.Browser1.PrepareForShutDown();
						if (this.IsOnlineMode)
						{
							this.VC.CloseConnection();
							Thread.Sleep(50);
						}
					}
					else
					{
						e.Cancel = true;
					}
				}
				catch (Exception)
				{
				}
			}
		}

		private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
		{
		}

		private void MainForm_SizeChanged(object sender, EventArgs e)
		{
		}

		private void MainForm_Resize(object sender, EventArgs e)
		{
			switch (base.WindowState)
			{
			}
		}

		private void MainForm_Activated(object sender, EventArgs e)
		{
		}

		public void CloseWithoutQuery()
		{
			this.closeWithoutQuery = true;
			base.Close();
		}

		private void initializeUsbKeyDetector()
		{
			if (this.Usb_Key_Access())
			{
				this.usb_class = new USB_Class(this);
				this.usb_class.UsbKeyArrived += this.OnUsbKeyArrived;
				this.usb_class.UsbKeyRemoved += this.OnUsbKeyRemoved;
				this.usb_class.UsbKeyChanged += this.OnUsbKeyChanged;
			}
			else
			{
				this.usb_class = null;
			}
		}

		public void UsbKeyAccessGrant()
		{
			this.usbKeyAccessGranted = true;
		}

		public bool UsbKeyQuery()
		{
			if (!this.Usb_Key_Access())
			{
				if ((!this.IsOnlineMode || !this.StationAvailable() || this.VC.ReceiveVarBlock(42)) && this.VC.PLCCommData.Output.UserLevel > 0 && this.CommonFunctions.ByteToString(this.VC.PLCCommData.Output.UserName) != this.usb_ActualUser)
				{
					this.showLoggedInUserInfo();
				}
				return true;
			}
			bool result = false;
			if (this.usb_key_access_result == 2 || this.usb_key_access_result == 1)
			{
				this.usb_key_access_result = 0;
				this.UsbKeyAccessGrant();
				this.OnUsbKeyArrived(null, this.currentUsbDetectorArguments);
				result = this.usbKeyAccessCanceledByUser;
			}
			return result;
		}

		public bool ProcessingUsbKeyRemovedEvent()
		{
			return this.processingUsbKeyRemovedEvent;
		}

		private void lbUser_Click(object sender, EventArgs e)
		{
			string text = "";
			string text2 = "";
			switch (this.usb_key_access_result)
			{
			case 0:
				break;
			case 2:
				if (!this.IsOnlineMode)
				{
					MessageBox.Show(this.Rm.GetString("MbNoConnectionToController"), this.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					text = this.Rm.GetString("MbLogInUSBAgain") + "\n";
					string text13 = text;
					text = text13 + "   " + this.Rm.GetString("UsbKeyInDrive") + ":   " + this.currentUsbDrive;
					DialogResult dialogResult = MessageBox.Show(this, text, this.Rm.GetString("MbhHint"), MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
					if (dialogResult == DialogResult.OK && this.usb_key_access_result != 0)
					{
						this.usb_key_access_result = 0;
						this.UsbKeyAccessGrant();
						UsbDetectorEventArgs usbDetectorEventArgs = new UsbDetectorEventArgs();
						usbDetectorEventArgs = this.currentUsbDetectorArguments;
						this.OnUsbKeyArrived(null, usbDetectorEventArgs);
					}
				}
				break;
			case 1:
			case 4:
			{
				text = ((this.usb_key_access_result != 1) ? (this.Rm.GetString("MbAreaCodeWrong") + "\n") : (this.Rm.GetString("MbPasswordIsExpired") + "\n"));
				string text8 = text;
				text = text8 + "   " + this.Rm.GetString("User") + ": " + this.usb_ActualUser + "\n";
				string text9 = text;
				text = text9 + "   " + this.Rm.GetString("PasscodeLevel") + ": " + this.Rm.GetString(this.c_global.GetAccessLevelDefinition(this.usb_PassCodeLevel - 1)) + " (" + this.usb_PassCodeLevel.ToString() + ")\n";
				string text10 = text;
				text = text10 + "   " + this.Rm.GetString("ValidUntil") + ": " + this.Usb_TimeLimitation.ToString() + "\n";
				text2 = this.areacodesOnKey();
				if (text2.Length > 0)
				{
					string text11 = text;
					text = text11 + "   " + this.Rm.GetString("AreaCodes") + ": " + text2 + "\n";
				}
				string text12 = text;
				text = text12 + "   " + this.Rm.GetString("UsbKeyInDrive") + ":   " + this.currentUsbDrive + "\n";
				MessageBox.Show(this, text, this.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				break;
			}
			case 3:
			{
				text = this.Rm.GetString("UserLoggedIn") + "\n";
				string text3 = text;
				text = text3 + "   " + this.Rm.GetString("User") + ": " + this.usb_ActualUser + "\n";
				string text4 = text;
				text = text4 + "   " + this.Rm.GetString("PasscodeLevel") + ": " + this.Rm.GetString(this.c_global.GetAccessLevelDefinition(this.usb_PassCodeLevel - 1)) + " (" + this.usb_PassCodeLevel.ToString() + ")\n";
				if (this.usb_PassCodeLevel < 5)
				{
					string text5 = text;
					text = text5 + "   " + this.Rm.GetString("ValidUntil") + ": " + this.Usb_TimeLimitation.ToString() + "\n";
				}
				else
				{
					string text6 = text;
					text = text6 + "   " + this.Rm.GetString("ValidUntil") + ": " + this.Usb_TimeLimitation.Year.ToString() + "\n";
				}
				text2 = this.areacodesOnKey();
				text = text + "   " + this.Rm.GetString("AreaCodes") + ": ";
				text = ((text2.Length <= 0) ? (text + "--\n") : (text + text2 + "\n"));
				string text7 = text;
				text = text7 + "   " + this.Rm.GetString("UsbKeyInDrive") + ":   " + this.currentUsbDrive + "\n";
				text += "   \n";
				text = text + "   " + this.Rm.GetString("LogoutUser");
				DialogResult dialogResult = MessageBox.Show(this, text, this.Rm.GetString("MbhHint"), MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
				if (dialogResult != DialogResult.OK && this.usb_key_access_result != 0)
				{
					this.usb_class.SuspendRecognition = true;
					this.OnUsbKeyChanged(null, this.currentUsbDetectorArguments);
					this.usb_class.SuspendRecognition = false;
				}
				break;
			}
			}
		}

		private string areacodesOnKey()
		{
			string text = "";
			foreach (string currentUsbArea in this.currentUsbAreas)
			{
				if (text.Length > 0)
				{
					text += ", ";
				}
				text += currentUsbArea;
			}
			return text;
		}

		private void checkActiveFromKeyArrived(Form activeChild)
		{
			if (activeChild == this.AdvanceWarning1)
			{
				this.AdvanceWarning1.KeyArrived();
			}
			if (activeChild == this.Backup1)
			{
				this.Backup1.KeyArrived();
			}
			else if (activeChild == this.CheckParam1)
			{
				this.CheckParam1.KeyArrived();
			}
			else if (activeChild == this.CurveDisplay1)
			{
				this.CurveDisplay1.KeyArrived();
			}
			else if (activeChild == this.Component1)
			{
				this.Component1.KeyArrived();
			}
			else if (activeChild == this.CycleCounter1)
			{
				this.CycleCounter1.KeyArrived();
			}
			else if (activeChild == this.VisualisationParam1)
			{
				this.VisualisationParam1.KeyArrived();
			}
			else if (activeChild == this.CycleCounter1)
			{
				this.CycleCounter1.KeyArrived();
			}
			else if (activeChild == this.EditDrivingStep1)
			{
				this.EditDrivingStep1.KeyArrived();
			}
			else if (activeChild == this.EditFinalizeStep1)
			{
				this.EditFinalizeStep1.KeyArrived();
			}
			else if (activeChild == this.EditOrganizeStep1)
			{
				this.EditOrganizeStep1.KeyArrived();
			}
			else if (activeChild == this.FourStepEdit1)
			{
				this.FourStepEdit1.KeyArrived();
			}
			else if (activeChild == this.FourStepOverview1)
			{
				this.FourStepOverview1.KeyArrived();
			}
			else if (activeChild == this.HandStart1)
			{
				this.HandStart1.KeyArrived();
			}
			else if (activeChild == this.LastNIOResults1)
			{
				this.LastNIOResults1.KeyArrived();
			}
			else if (activeChild == this.LogBookForm1)
			{
				this.LogBookForm1.KeyArrived();
			}
			else if (activeChild == this.LogChangesForm1)
			{
				this.LogChangesForm1.KeyArrived();
			}
			else if (activeChild == this.Maintenance1)
			{
				this.Maintenance1.KeyArrived();
			}
			else if (activeChild == this.MenuAnalysis1)
			{
				this.MenuAnalysis1.KeyArrived();
			}
			else if (activeChild == this.MenuMaintenance1)
			{
				this.MenuMaintenance1.KeyArrived();
			}
			else if (activeChild == this.MenuParameter1)
			{
				this.MenuParameter1.KeyArrived();
			}
			else if (activeChild == this.MenuStatistics1)
			{
				this.MenuStatistics1.KeyArrived();
			}
			else if (activeChild == this.MenuTest1)
			{
				this.MenuTest1.KeyArrived();
			}
			else if (activeChild != this.PasscodeManager1)
			{
				if (activeChild == this.PrgOptParameter1)
				{
					this.PrgOptParameter1.KeyArrived();
				}
				else if (activeChild == this.ProgramOverview1)
				{
					this.ProgramOverview1.KeyArrived();
				}
				else if (activeChild == this.ResultDisplay1)
				{
					this.ResultDisplay1.KeyArrived();
				}
				else if (activeChild == this.SpindleConstants1)
				{
					this.SpindleConstants1.KeyArrived();
				}
				else if (activeChild == this.StatisticsLastRes1)
				{
					this.StatisticsLastRes1.KeyArrived();
				}
				else if (activeChild == this.StepOverview1)
				{
					this.StepOverview1.KeyArrived();
				}
				else if (activeChild == this.StepResult1)
				{
					this.StepResult1.KeyArrived();
				}
				else if (activeChild == this.SystemConstants1)
				{
					this.SystemConstants1.KeyArrived();
				}
				else if (activeChild == this.LevelAssignment1)
				{
					this.LevelAssignment1.KeyArrived();
				}
				else if (activeChild == this.TestIO1)
				{
					this.TestIO1.KeyArrived();
				}
				else if (activeChild == this.TestMotorSensor1)
				{
					this.TestMotorSensor1.KeyArrived();
				}
				else if (activeChild == this.TestSPSIO1)
				{
					this.TestSPSIO1.KeyArrived();
				}
				else if (activeChild == this.TopTen1)
				{
					this.TopTen1.KeyArrived();
				}
			}
		}

		private void checkActiveFromKeyRemoved(Form activeChild)
		{
			this.processingUsbKeyRemovedEvent = true;
			if (activeChild == this.AdvanceWarning1)
			{
				this.AdvanceWarning1.KeyRemoved();
			}
			if (activeChild == this.Backup1)
			{
				this.Backup1.KeyRemoved();
			}
			else if (activeChild == this.CheckParam1)
			{
				this.CheckParam1.KeyRemoved();
			}
			else if (activeChild == this.CurveDisplay1)
			{
				this.CurveDisplay1.KeyRemoved();
			}
			else if (activeChild == this.Component1)
			{
				this.Component1.KeyRemoved();
			}
			else if (activeChild == this.CycleCounter1)
			{
				this.CycleCounter1.KeyRemoved();
			}
			else if (activeChild == this.VisualisationParam1)
			{
				this.VisualisationParam1.KeyRemoved();
			}
			else if (activeChild == this.CycleCounter1)
			{
				this.CycleCounter1.KeyRemoved();
			}
			else if (activeChild == this.EditDrivingStep1)
			{
				this.EditDrivingStep1.KeyRemoved();
			}
			else if (activeChild == this.EditFinalizeStep1)
			{
				this.EditFinalizeStep1.KeyRemoved();
			}
			else if (activeChild == this.EditOrganizeStep1)
			{
				this.EditOrganizeStep1.KeyRemoved();
			}
			else if (activeChild == this.FourStepEdit1)
			{
				this.FourStepEdit1.KeyRemoved();
			}
			else if (activeChild == this.FourStepOverview1)
			{
				this.FourStepOverview1.KeyRemoved();
			}
			else if (activeChild == this.HandStart1)
			{
				this.HandStart1.KeyRemoved();
			}
			else if (activeChild == this.LastNIOResults1)
			{
				this.LastNIOResults1.KeyRemoved();
			}
			else if (activeChild == this.LogBookForm1)
			{
				this.LogBookForm1.KeyRemoved();
			}
			else if (activeChild == this.LogChangesForm1)
			{
				this.LogChangesForm1.KeyRemoved();
			}
			else if (activeChild == this.Maintenance1)
			{
				this.Maintenance1.KeyRemoved();
			}
			else if (activeChild == this.MenuAnalysis1)
			{
				this.MenuAnalysis1.KeyRemoved();
			}
			else if (activeChild == this.MenuMaintenance1)
			{
				this.MenuMaintenance1.KeyRemoved();
			}
			else if (activeChild == this.MenuParameter1)
			{
				this.MenuParameter1.KeyRemoved();
			}
			else if (activeChild == this.MenuStatistics1)
			{
				this.MenuStatistics1.KeyRemoved();
			}
			else if (activeChild == this.MenuTest1)
			{
				this.MenuTest1.KeyRemoved();
			}
			else if (activeChild != this.PasscodeManager1)
			{
				if (activeChild == this.PrgOptParameter1)
				{
					this.PrgOptParameter1.KeyRemoved();
				}
				else if (activeChild == this.ProgramOverview1)
				{
					this.ProgramOverview1.KeyRemoved();
				}
				else if (activeChild == this.ResultDisplay1)
				{
					this.ResultDisplay1.KeyRemoved();
				}
				else if (activeChild == this.SpindleConstants1)
				{
					this.SpindleConstants1.KeyRemoved();
				}
				else if (activeChild == this.StatisticsLastRes1)
				{
					this.StatisticsLastRes1.KeyRemoved();
				}
				else if (activeChild == this.StepOverview1)
				{
					this.StepOverview1.KeyRemoved();
				}
				else if (activeChild == this.StepResult1)
				{
					this.StepResult1.KeyRemoved();
				}
				else if (activeChild == this.SystemConstants1)
				{
					this.SystemConstants1.KeyRemoved();
				}
				else if (activeChild == this.LevelAssignment1)
				{
					this.LevelAssignment1.KeyRemoved();
				}
				else if (activeChild == this.TestIO1)
				{
					this.TestIO1.KeyRemoved();
				}
				else if (activeChild == this.TestMotorSensor1)
				{
					this.TestMotorSensor1.KeyRemoved();
				}
				else if (activeChild == this.TestSPSIO1)
				{
					this.TestSPSIO1.KeyRemoved();
				}
				else if (activeChild == this.TopTen1)
				{
					this.TopTen1.KeyRemoved();
				}
			}
			this.processingUsbKeyRemovedEvent = false;
		}

		public bool UsbPluggedButNotLoggedIn()
		{
			if (this.usb_key_access_result != 2 && this.usb_key_access_result != 1 && this.usb_key_access_result != 4)
			{
				return false;
			}
			return true;
		}

		public bool UsbPluggedPasswordExpired()
		{
			if (this.usb_key_access_result != 1 && this.usb_key_access_result != 4)
			{
				return false;
			}
			return true;
		}

		private void OnUsbKeyArrived(object sender, UsbDetectorEventArgs e)
		{
			string text = "";
			this.usbKeyAccessCanceledByUser = false;
			this.loginSuccessfulCompleted = false;
			Form activeMdiChild = base.ActiveMdiChild;
			if (!this.enterPasswordInProgress && this.usb_key_access_result == 0)
			{
				this.enterPasswordInProgress = true;
				OperatingSystem oSVersion = Environment.OSVersion;
				string empty = string.Empty;
				if (this.PassCodeLevel > 0)
				{
					DialogResult dialogResult = MessageBox.Show(this, this.Rm.GetString("MbUsbKeyAlreadyConnected"), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
					if (dialogResult == DialogResult.No)
					{
						return;
					}
				}
				if (!e.UsbKeyValid)
				{
					if (this.usbKeyAccessGranted)
					{
						MessageBox.Show(this, this.Rm.GetString("MbInvalidUsbKey"), this.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					this.enterPasswordInProgress = false;
				}
				else
				{
					this.currentUsbDetectorArguments = e;
					this.usb_key_access_result = 0;
					this.enterPasswordInProgress = true;
					this.usb_ActualUser = e.UserId;
					this.usb_PassCodeLevel = e.UserLevel;
					string text2 = DateTime.Now.ToString();
					string[] array = e.TimeLimitation.Split('.', '/', ' ');
					bool flag = false;
					if (text2.IndexOf('/') >= 0 || text2.IndexOf('.') >= 0)
					{
						if (array.Length > 2)
						{
							int year = int.Parse(array[2]);
							int month = int.Parse(array[1]);
							int day = int.Parse(array[0]);
							this.Usb_TimeLimitation = new DateTime(year, month, day);
							flag = true;
						}
					}
					else
					{
						flag = DateTime.TryParse(e.TimeLimitation, out this.Usb_TimeLimitation);
					}
					if (!flag)
					{
						try
						{
							if (array.Length > 2)
							{
								int year2 = int.Parse(array[2]);
								int month2 = int.Parse(array[0]);
								int day2 = int.Parse(array[1]);
								this.Usb_TimeLimitation = new DateTime(year2, month2, day2);
								flag = true;
							}
						}
						catch (Exception)
						{
							try
							{
								array = e.TimeLimitation.Split('.', '/', ' ');
								if (array.Length > 2)
								{
									int year3 = int.Parse(array[2]);
									int day3 = int.Parse(array[0]);
									int month3 = int.Parse(array[1]);
									this.Usb_TimeLimitation = new DateTime(year3, month3, day3);
									flag = true;
								}
							}
							catch (Exception)
							{
							}
						}
					}
					if (flag)
					{
						this.Usb_TimeLimitation = this.Usb_TimeLimitation.AddHours(23.0);
						this.Usb_TimeLimitation = this.Usb_TimeLimitation.AddMinutes(59.0);
					}
					this.Usb_Password_MD5 = e.Password_MD5;
					this.Areas = e.Areas;
					this.actualUser = e.UserId;
					this.currentUsbDrive = e.Drive;
					this.currentUsbAreas = e.Areas;
					if (this.Usb_TimeLimitation.CompareTo(DateTime.Now) < 0 && this.usb_PassCodeLevel < 5)
					{
						this.usb_key_access_result = 1;
						this.PassCodeLevel = 0;
						this.userToStatus(2, true);
						if (this.usbKeyAccessGranted)
						{
							MessageBox.Show(this, this.Rm.GetString("MbPasswordIsExpired") + "\n" + this.Rm.GetString("MbMenuInReadMode"), this.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						this.enterPasswordInProgress = false;
					}
					else
					{
						if (this.usb_PassCodeLevel == 5)
						{
							new DateTime(this.Usb_TimeLimitation.Year, 12, 31, 23, 59, 59);
							if (this.Usb_TimeLimitation.CompareTo(DateTime.Now) < 0)
							{
								this.usb_key_access_result = 1;
								this.PassCodeLevel = 0;
								this.userToStatus(2, true);
								if (this.usbKeyAccessGranted)
								{
									MessageBox.Show(this, this.Rm.GetString("MbPasswordIsExpired") + "\n" + this.Rm.GetString("MbMenuInReadMode"), this.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								}
								this.enterPasswordInProgress = false;
								return;
							}
						}
						string text3 = this.CommonFunctions.UShortToString(this.VC.SysConst.AreaCode).ToUpper();
						if (text3.Length != 0)
						{
							bool flag2 = true;
							foreach (string area in e.Areas)
							{
								flag2 = false;
								string text4 = area;
								text4 = ((area.Length <= 15) ? area.ToUpper() : area.Remove(15).ToUpper());
								if (text4 == text3)
								{
									flag2 = true;
									break;
								}
							}
							if (!flag2 && this.usb_PassCodeLevel < 5)
							{
								this.usb_key_access_result = 4;
								this.PassCodeLevel = 0;
								this.userToStatus(2, true);
								string text5 = this.CommonFunctions.UShortToString(this.VC.SysConst.AreaCode);
								if (text5.Length == 0)
								{
									text5 = this.Rm.GetString("None");
								}
								if (this.usbKeyAccessGranted)
								{
									MessageBox.Show(this, this.Rm.GetString("MbAreaCodeWrong") + "\n" + this.Rm.GetString("MbAreaCodeNeeded") + " " + text5 + "\n" + this.Rm.GetString("MbMenuInReadMode"), this.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								}
								this.enterPasswordInProgress = false;
								return;
							}
						}
						if (this.IsOnlineMode && this.StationAvailable() && !this.VC.ReceiveVarBlock(42))
						{
							Cursor.Current = Cursors.Default;
							this.StatusBarText(string.Empty);
						}
						else if (this.usbKeyAccessGranted && this.VC.PLCCommData.Output.UserLevel > 0 && this.CommonFunctions.ByteToString(this.VC.PLCCommData.Output.UserName) != this.usb_ActualUser)
						{
							this.usb_key_access_result = 2;
							this.showLoggedInUserInfo();
							this.enterPasswordInProgress = false;
							return;
						}
						this.lbUser.Size = new Size(MainForm._STATUS_LABEL_WIDTH, 30);
						this.lbUser.Location = new Point(2, 517);
						if (!this.usbKeyAccessGranted)
						{
							this.usb_key_access_result = 2;
							this.PassCodeLevel = 0;
							this.actualUser = e.UserId;
							this.userToStatus(3, true);
							this.enterPasswordInProgress = false;
							this.ErrorDisplay1.MakeInvisible(false);
						}
						else
						{
							this.userToStatus(3, true);
							this.usb_PasswordInput1.Usb_MD5_Passcode = e.Password_MD5;
							this.usb_PasswordInput1.Usb_user_id = e.UserId;
							this.usb_PasswordInput1.Drive = e.Drive;
							this.ErrorDisplay1.MakeInvisible(true);
							this.usb_PasswordInput1.ShowDialog();
							if (this.usb_PasswordInput1.AccessMode == 3 || this.usb_PasswordInput1.AccessMode == 5)
							{
								if (this.usb_PasswordInput1.AccessMode == 3)
								{
									this.usbKeyAccessCanceledByUser = true;
								}
								this.usb_key_access_result = 2;
								this.PassCodeLevel = 0;
								this.actualUser = e.UserId;
								this.userToStatus(3, true);
								this.enterPasswordInProgress = false;
								this.ErrorDisplay1.MakeInvisible(false);
							}
							else if (this.usb_PasswordInput1.AccessMode == 4)
							{
								this.lbUser.Size = new Size(MainForm._STATUS_LABEL_WIDTH, 21);
								this.lbUser.Location = new Point(2, 524);
								this.usbKeyAccessCanceledByUser = true;
								this.usb_key_access_result = 0;
								this.PassCodeLevel = 0;
								this.actualUser = "--";
								this.userToStatus(0, true);
								this.enterPasswordInProgress = false;
								this.ErrorDisplay1.MakeInvisible(false);
							}
							else
							{
								if (this.usb_PasswordInput1.AccessMode == 2)
								{
									if (this.VC.PLCCommData.Output.UserLevel > 0 && this.CommonFunctions.ByteToString(this.VC.PLCCommData.Output.UserName) != this.actualUser)
									{
										this.showLoggedInUserInfo();
										this.usb_key_access_result = 2;
										this.PassCodeLevel = 0;
										this.actualUser = e.UserId;
										this.userToStatus(3, true);
										this.enterPasswordInProgress = false;
										this.ErrorDisplay1.MakeInvisible(false);
										return;
									}
									TimeSpan timeSpan = this.Usb_TimeLimitation - DateTime.Now;
									if (this.usb_PassCodeLevel < 5 && timeSpan.Days < 8)
									{
										string str = (timeSpan.Days != 0) ? (timeSpan.Days.ToString() + " " + this.Rm.GetString("MbDay_s")) : (timeSpan.Hours.ToString() + " " + this.Rm.GetString("MbHour_s"));
										text = this.Rm.GetString("MbPasswordWillExpire") + " " + str;
									}
									this.usb_key_access_result = 3;
									this.PassCodeLevel = this.usb_PassCodeLevel;
									this.actualUser = e.UserId;
									this.userToStatus(1, true);
									this.delayTimeCheckLoginState();
								}
								if (Settings.Default.UserLevel_BrowserForm != 0)
								{
									this.Browser1.ResetBrowserNavigated();
								}
								if (text.Length > 0)
								{
									MessageBox.Show(this, text, this.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								}
							}
						}
					}
				}
			}
		}

		private string showLoggedInUserInfo()
		{
			string text = this.Rm.GetString("MbAnotherUserLoggedIn") + "\n";
			string text2 = text;
			text = text2 + "   " + this.Rm.GetString("User") + ": " + this.CommonFunctions.ByteToString(this.VC.PLCCommData.Output.UserName) + "\n";
			string text3 = text;
			text = text3 + "   " + this.Rm.GetString("PasscodeLevel") + ": " + this.Rm.GetString(this.c_global.GetAccessLevelDefinition(this.VC.PLCCommData.Output.UserLevel - 1)) + "\n";
			string text4 = "";
			int i;
			for (i = 0; i < 10; i++)
			{
				byte b = this.VC.PLCCommData.Output.IpAddress[i];
				if (b == 0)
				{
					break;
				}
				if (i > 0)
				{
					text4 += ".";
				}
				text4 += b.ToString();
			}
			if (i < 4)
			{
				string text5 = text;
				text = text5 + "   " + this.Rm.GetString("IPAddress") + ": " + this.Rm.GetString("MbUnknown") + "\n";
			}
			else
			{
				string text6 = text;
				text = text6 + "   " + this.Rm.GetString("IPAddress") + ": " + text4 + "\n";
			}
			MessageBox.Show(this, text, this.Rm.GetString("PasswordInput"), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			this.enterPasswordInProgress = false;
			return text;
		}

		private void delayTimeCheckLoginState()
		{
			int millisecondsTimeout = this.rnd.Next(1000);
			Thread.Sleep(millisecondsTimeout);
			if (this.IsOnlineMode && this.VC.ReceiveVarBlock(42) && this.usb_key_access_result == 3 && this.CommonFunctions.ByteToString(this.VC.PLCCommData.Output.UserName).Length > 0 && this.CommonFunctions.ByteToString(this.VC.PLCCommData.Output.UserName) != "--" && this.CommonFunctions.ByteToString(this.VC.PLCCommData.Output.UserName) != this.actualUser)
			{
				this.usb_key_access_result = 2;
				this.PassCodeLevel = 0;
				this.userToStatus(3, false);
				this.showLoggedInUserInfo();
				this.ErrorDisplay1.MakeInvisible(false);
				this.enterPasswordInProgress = false;
			}
			else
			{
				this.userToStatus(1, true);
				Application.DoEvents();
				this.MakeLogbookEntry(206001u, 6, 0f, (float)(int)this.PassCodeLevel, 0u, 0, byte.MaxValue);
				this.WriteLogbookData(true);
				this.loginSuccessfulCompleted = true;
				this.lbUser.Size = new Size(MainForm._STATUS_LABEL_WIDTH, 21);
				this.lbUser.Location = new Point(2, 524);
				try
				{
					this.ErrorDisplay1.MakeInvisible(false);
					Form activeMdiChild = base.ActiveMdiChild;
					if (activeMdiChild == this.Browser1 && this.Browser1.MachineVisuActive)
					{
						this.Browser1.KeyArrived();
						this.timerDelayKeyArrived.Start();
						this.WeberLogoImage(1);
					}
					if (activeMdiChild == this.BrowserHelp && this.BrowserHelp.HelpActive)
					{
						this.BrowserHelp.KeyArrived();
						this.timerDelayKeyArrived.Start();
						this.WeberLogoImage(1);
					}
					this.checkActiveFromKeyArrived(activeMdiChild);
				}
				catch (Exception)
				{
				}
				this.enterPasswordInProgress = false;
			}
		}

		private void OnUsbKeyRemoved(object sender, UsbDetectorEventArgs e)
		{
			if (e != null)
			{
				if (this.currentUsbDrive.Length > 0 && this.currentUsbDrive != e.Drive)
				{
					return;
				}
				if (this.currentUsbDrive.Length != 0)
				{
					OperatingSystem oSVersion = Environment.OSVersion;
					string empty = string.Empty;
					this.usbKeyAccessGranted = false;
					this.usb_key_access_result = 0;
					this.usb_ActualUser = "";
					this.currentUsbDrive = "";
					byte passCodeLevel = this.PassCodeLevel;
					this.PassCodeLevel = 0;
					this.actualUser = "--";
					Form activeMdiChild = base.ActiveMdiChild;
					if (activeMdiChild != null && !this.enterPasswordInProgress)
					{
						try
						{
							if (activeMdiChild == this.Browser1 && this.Browser1.MachineVisuActive)
							{
								this.hideMachineVisu();
								Form activeMdiChild2 = base.ActiveMdiChild;
								ResultDisplayForm resultDisplay = this.ResultDisplay1;
								base.HelpButton = true;
								this.WeberLogoImage(1);
							}
							if (activeMdiChild == this.BrowserHelp && this.BrowserHelp.HelpActive)
							{
								this.BrowserHelp.KeyRemoved();
								this.timerDelayKeyRemoved.Start();
								this.WeberLogoImage(1);
							}
							this.SettingsChangedReset();
							this.checkActiveFromKeyRemoved(activeMdiChild);
						}
						catch (Exception)
						{
						}
					}
					if (passCodeLevel != 0)
					{
						this.MakeLogbookEntry(206002u, 6, 0f, (float)(int)passCodeLevel, 0u, 0, byte.MaxValue);
						this.WriteLogbookData(true);
					}
					this.loginSuccessfulCompleted = false;
					this.usb_PasswordInput1.Cancel();
					this.userToStatus(0, true);
					this.lbUser.Size = new Size(MainForm._STATUS_LABEL_WIDTH, 21);
					this.lbUser.Location = new Point(2, 524);
					this.ExitExclusiveBlock1();
					this.CheckParamAllowed = false;
					this.NumberPad1.Hide();
					this.KeyPad1.Hide();
					this.CheckParamAllowed = false;
				}
			}
		}

		private void OnUsbKeyChanged(object sender, UsbDetectorEventArgs e)
		{
			if (this.usb_PasswordInput1.ChangedPasswordOnDisk)
			{
				UserKeyfileStruct userKeyfileStruct = new UserKeyfileStruct();
				UsbFileSystemClass usbFileSystemClass = new UsbFileSystemClass();
				if (usbFileSystemClass.ReadUsbKeyFile(e.Drive, ref userKeyfileStruct, out DateTime _))
				{
					this.currentUsbDetectorArguments.Password_MD5 = userKeyfileStruct.Password;
				}
			}
			else
			{
				this.OnUsbKeyRemoved(null, this.currentUsbDetectorArguments);
				this.OnUsbKeyArrived(sender, e);
			}
		}

		public void Init_usb_key_access()
		{
			if (this.IsOnlineMode)
			{
				this.StatusBarText(this.Rm.GetString("LoadSpindleConst"));
				if (!this.VC.ReceiveVarBlock(11))
				{
					Cursor.Current = Cursors.Default;
					this.StatusBarText(string.Empty);
					this.usb_key_access = false;
					MessageBox.Show("Could not receive SpConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					Cursor.Current = Cursors.Default;
					this.StatusBarText(string.Empty);
					if (this.VC.SpConst.UsbKeyActivated != 0)
					{
						this.usb_key_access = true;
						if (this.usb_class == null)
						{
							this.initializeUsbKeyDetector();
						}
					}
					else
					{
						this.usb_key_access = false;
						this.usb_class = null;
					}
				}
			}
			else
			{
				this.usb_key_access = false;
			}
		}

		public bool Usb_Key_Access()
		{
			return this.usb_key_access;
		}

		public bool StartupVarConnection()
		{
			bool flag = false;
			this.timerControllerOffline.Enabled = false;
			string text = string.Empty;
			char[] separator = new char[1]
			{
				'/'
			};
			Cursor.Current = Cursors.WaitCursor;
			this.VC.CloseConnection();
			this.LifeSign = 0;
			Assembly.GetExecutingAssembly();
			try
			{
				text = ((!ApplicationDeployment.IsNetworkDeployed) ? "http://172.20.15.98/Visualisation/Visualisation.application" : ApplicationDeployment.CurrentDeployment.ActivationUri.ToString());
			}
			catch (Exception)
			{
			}
			string[] array = text.Split(separator);
			if (!ApplicationDeployment.IsNetworkDeployed)
			{
				this.IsOfflineVersion = true;
			}
			if (!(array[0] != "http:") && !this.IsOfflineVersion)
			{
				try
				{
					this.myip = IPAddress.Parse(array[2]);
					this.SourceDirectoryForHelp = "http://" + this.myip.ToString() + "/Manual/";
					this.LocalizedHelpFile = this.SourceDirectoryForHelp + this.HelpFileName;
				}
				catch (Exception ex2)
				{
					Cursor.Current = Cursors.Default;
					MessageBox.Show(ex2.Message, this.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return false;
				}
				this.StatusBarText(this.Rm.GetString("Reconnect"));
				this.Cursor = Cursors.WaitCursor;
				Application.DoEvents();
				flag = this.VC.ConnectToServer(this.myip.ToString());
				this.Cursor = Cursors.Default;
				this.StatusBarText("");
				if (flag)
				{
					this.machineVisuError.ReadErrorText(this.MACHINE_VISU_ERROR_TEXT_FILE);
					this.IsOnlineMode = true;
					this.timerControllerOffline.Enabled = true;
					if (this.VC.ReceiveVarBlock(12))
					{
						switch (this.VC.SysConst.UnitTorque)
						{
						case 0:
							this.TorqueConvert = 1f;
							this.TorqueUnitName = this.Rm.GetString("TorqueNm");
							break;
						case 1:
							this.TorqueConvert = 100f;
							this.TorqueUnitName = this.Rm.GetString("TorqueNcm");
							break;
						case 2:
							this.TorqueConvert = 8.850745f;
							this.TorqueUnitName = this.Rm.GetString("Torqueinlb");
							break;
						case 3:
							this.TorqueConvert = 0.7375621f;
							this.TorqueUnitName = this.Rm.GetString("Torqueftlb");
							break;
						case 4:
							this.TorqueConvert = 141.6119f;
							this.TorqueUnitName = this.Rm.GetString("Torqueinoz");
							break;
						case 5:
							this.TorqueConvert = 0.1019716f;
							this.TorqueUnitName = this.Rm.GetString("Torquekgm");
							break;
						case 6:
							this.TorqueConvert = 10.19716f;
							this.TorqueUnitName = this.Rm.GetString("Torquekgcm");
							break;
						default:
							MessageBox.Show("Wrong SysConst.UnitTorque in StartupVarConnection() of MainForm", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							this.TorqueConvert = 1f;
							this.TorqueUnitName = "Nm";
							break;
						}
					}
					else
					{
						this.TorqueConvert = 1f;
						this.TorqueUnitName = "Nm";
						Cursor.Current = Cursors.Default;
						MessageBox.Show("Could not receive SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					this.ErrorDisplay1.CheckMessageStatus();
					if (this.IsOnlineMode && !this.VC.ReceiveVarBlock(0))
					{
						MessageBox.Show("Could not receive Status0Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				else
				{
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Rm.GetString("MbGotNoConnection"), this.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					this.IsOnlineMode = false;
				}
				this.Init_usb_key_access();
				this.MenEna();
				Cursor.Current = Cursors.Default;
				return flag;
			}
			this.Init_usb_key_access();
			Cursor.Current = Cursors.Default;
			MessageBox.Show(this.Rm.GetString("MbLocationError"), this.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			this.IsOfflineVersion = true;
			this.LocalizedHelpFile = this.HelpFileName;
			return false;
		}

		public bool GetExclusiveBlock1()
		{
			int num = 0;
			if (!this.IsOnlineMode)
			{
				MessageBox.Show(this.Rm.GetString("MbNoConnection"), this.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Random random = new Random();
			if (this.Block1Status != 0)
			{
				MessageBox.Show("MbAccessRequestTwice", "MbhError", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Cursor.Current = Cursors.WaitCursor;
			this.StatusBarText(this.Rm.GetString("AccessCheck"));
			if (!this.VC.ReceiveVarBlock(0))
			{
				this.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show("Could not receive Status0Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			if (this.VC.Status0.AutoMode != 0)
			{
				this.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show(this.Rm.GetString("MbNoAccessCauseAuto"), this.Rm.GetString("MbhViewOnlyMode"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				this.ViewOnlyMode = true;
				return false;
			}
			if (this.VC.Status0.OwnerID1 == 0 && this.VC.Status0.OwnerID2 == 0 && this.VC.Status0.ParameterMode == 0 && this.VC.Status0.TestMode == 0)
			{
				this.ViewOnlyMode = false;
				this.VC.Status1.RequestID = (uint)random.Next();
				this.VC.Status1.VisuLive = 1;
				this.StatusBarText(this.Rm.GetString("AccessRequest"));
				if (!this.VC.SendVarBlock(1))
				{
					this.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show("Could not send Status1Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return false;
				}
				this.Block1Status = 1;
				while (this.Block1Status == 1)
				{
					if (num >= 20)
					{
						this.Block1Status = 0;
						this.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						MessageBox.Show(this.Rm.GetString("MBAccessNotPossible"), this.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					Thread.Sleep(50);
					num++;
				}
				if (this.Block1Status == 2)
				{
					this.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					return true;
				}
				this.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				return false;
			}
			this.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			MessageBox.Show(this.Rm.GetString("MbAccessByAnother") + " " + this.Rm.GetString("MbAddParamViewOnly"), this.Rm.GetString("MbhViewOnlyMode"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			this.ViewOnlyMode = true;
			return false;
		}

		public void ExitExclusiveBlock1()
		{
			if (this.Block1Status != 0)
			{
				this.VC.Status1.RequestID = 0u;
				this.VC.Status1.VisuLive = 0;
				if (this.IsOnlineMode)
				{
					this.StatusBarText(this.Rm.GetString("DeblockController"));
					Cursor.Current = Cursors.WaitCursor;
					if (!this.VC.SendVarBlock(1))
					{
						this.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						MessageBox.Show("Could not send Status1Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				this.Block1Status = 0;
				this.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
			}
		}

		public bool GetExclusiveBlock2(bool outputToDisplay)
		{
			int num = 0;
			if (!this.IsOnlineMode)
			{
				MessageBox.Show(this.Rm.GetString("MbNoConnection"), this.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Random random = new Random();
			if (this.Block2Status != 0)
			{
				if (outputToDisplay)
				{
					MessageBox.Show("MbAccessRequestTwice", "MbhError", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				return false;
			}
			Cursor.Current = Cursors.WaitCursor;
			if (outputToDisplay)
			{
				this.StatusBarText(this.Rm.GetString("AccessCheck"));
			}
			if (!this.VC.ReceiveVarBlock(0))
			{
				this.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				if (outputToDisplay)
				{
					MessageBox.Show("Could not receive Status0Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				return false;
			}
			if (this.VC.Status0.AutoMode != 0)
			{
				this.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				if (outputToDisplay)
				{
					MessageBox.Show(this.Rm.GetString("MbNoTestCauseAuto"), this.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				return false;
			}
			if (this.VC.Status0.OwnerID1 == 0 && this.VC.Status0.OwnerID2 == 0 && this.VC.Status0.ParameterMode == 0 && this.VC.Status0.TestMode == 0)
			{
				this.VC.Status2.RequestID = (uint)random.Next();
				this.VC.Status2.VisuLive = 1;
				if (outputToDisplay)
				{
					this.StatusBarText(this.Rm.GetString("AccessRequest"));
				}
				if (!this.VC.SendVarBlock(2))
				{
					this.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					if (outputToDisplay)
					{
						MessageBox.Show("Could not send Status2Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					return false;
				}
				this.Block2Status = 1;
				while (this.Block2Status == 1)
				{
					if (num >= 20)
					{
						this.Block2Status = 0;
						this.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						if (outputToDisplay)
						{
							MessageBox.Show(this.Rm.GetString("MbAccessNotPossible"), this.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
					}
					Thread.Sleep(50);
					num++;
				}
				if (this.Block2Status == 2)
				{
					this.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					return true;
				}
				this.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				return false;
			}
			this.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			if (outputToDisplay)
			{
				MessageBox.Show(this.Rm.GetString("MbAccessByAnother") + " " + this.Rm.GetString("MbAddNoTest"), this.Rm.GetString("MbhViewOnlyMode"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			return false;
		}

		public void ExitExclusiveBlock2()
		{
			if (this.Block2Status != 0)
			{
				this.VC.Status2.RequestID = 0u;
				this.VC.Status2.VisuLive = 0;
				if (this.IsOnlineMode)
				{
					this.StatusBarText(this.Rm.GetString("DeblockController"));
					Cursor.Current = Cursors.WaitCursor;
					if (!this.VC.SendVarBlock(2))
					{
						this.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						MessageBox.Show("Could not send Status2Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				this.Block2Status = 0;
				this.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
			}
		}

		private void VSE_StatusAutomatic(object sender, VARServerEventArgs e)
		{
			if (!this.VC.ReceiveVarBlock(0))
			{
				MessageBox.Show("Could not receive Status0Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				base.Invoke(new MethodInvoker(this.MenEna));
			}
		}

		private void VSE_StatusAccessControl(object sender, VARServerEventArgs e)
		{
			this.LifeSign = 0;
			switch (this.Block1Status)
			{
			case 1:
				if (!this.VC.ReceiveVarBlock(0))
				{
					this.Block1Status = 0;
					MessageBox.Show("Could not receive Status0Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}
				if (this.VC.Status0.OwnerID1 == this.VC.Status1.RequestID)
				{
					this.Block1Status = 2;
				}
				break;
			case 2:
				this.VC.Status1.VisuLive++;
				if (this.VC.SendVarBlock(1))
				{
					break;
				}
				this.Block1Status = 0;
				MessageBox.Show("Could not send Status1Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return;
			default:
				MessageBox.Show("Wrong Block1Status in VSE_StatusAccessControl() of MainForm", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.Block1Status = 0;
				break;
			case 0:
				break;
			}
			switch (this.Block2Status)
			{
			case 0:
				break;
			case 1:
				if (!this.VC.ReceiveVarBlock(0))
				{
					this.Block2Status = 0;
					MessageBox.Show("Could not receive Status0Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else if (this.VC.Status0.OwnerID2 == this.VC.Status2.RequestID)
				{
					this.Block2Status = 2;
				}
				break;
			case 2:
				this.VC.Status2.VisuLive++;
				if (!this.VC.SendVarBlock(2))
				{
					this.Block2Status = 0;
					MessageBox.Show("Could not send Status2Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				break;
			default:
				MessageBox.Show("Wrong Block2Status in VSE_StatusAccessControl() of MainForm", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.Block2Status = 0;
				break;
			}
		}

		public bool SaveOnController(byte type, bool disableLifeSign)
		{
			int num = 0;
			this.VC.SaveSys.RequestBlock = type;
			if (!this.VC.SendVarBlock(4))
			{
				return false;
			}
			this.SaveBlockStatus = 1;
			string[] array = new string[4]
			{
				"\\",
				"--",
				"/",
				"|"
			};
			string text = this.statusBar.Text;
			int num2 = 1;
			this.StatusBarText(text + ' ' + array[0]);
			int num3 = 550;
			if (disableLifeSign)
			{
				this.timerControllerOffline.Enabled = false;
			}
			if (type == 3)
			{
				num3 *= 2;
			}
			while (this.SaveBlockStatus == 1)
			{
				if (num >= num3 || this.VC.SaveSys.RequestBlock == 0)
				{
					this.SaveBlockStatus = 0;
				}
				Thread.Sleep(50);
				num++;
				if (num % 4 == 0)
				{
					this.StatusBarText(text + ' ' + array[num2++]);
					Application.DoEvents();
					if (num2 >= array.Length)
					{
						num2 = 0;
					}
				}
			}
			this.timerControllerOffline.Enabled = true;
			if (this.VC.SaveSys.RequestBlock == 0)
			{
				return true;
			}
			return false;
		}

		public bool ReadFromController(byte type)
		{
			return this.SaveOnController(type, false);
		}

		private void VSE_SaveControl(object sender, VARServerEventArgs e)
		{
			switch (this.SaveBlockStatus)
			{
			case 0:
				break;
			case 1:
				if (!this.VC.ReceiveVarBlock(4))
				{
					this.setStatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show("Could not receive SafeBlockVerification!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				this.SaveBlockStatus = 0;
				break;
			default:
				MessageBox.Show("Wrong SaveBlockStatus in VSE_SaveControl() of MainForm", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.SaveBlockStatus = 0;
				break;
			}
		}

		private void VSE_Error(object sender, VARServerEventArgs e)
		{
			this.ErrorDisplay1.SetErrorFlag();
		}

		public bool DeleteStatBlock(byte command)
		{
			int num = 0;
			this.VC.StatControl.Command = command;
			if (!this.VC.SendVarBlock(33))
			{
				return false;
			}
			this.StatDeleteStatus = 1;
			while (this.StatDeleteStatus == 1)
			{
				if (num >= 400)
				{
					this.StatDeleteStatus = 0;
				}
				Thread.Sleep(50);
				num++;
			}
			if (this.VC.StatControl.Command == 0)
			{
				return true;
			}
			return false;
		}

		private void VSE_StatControl(object sender, VARServerEventArgs e)
		{
			switch (this.StatDeleteStatus)
			{
			case 0:
				break;
			case 1:
				if (!this.VC.ReceiveVarBlock(33))
				{
					this.setStatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show("Could not receive StatControlBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				this.StatDeleteStatus = 0;
				break;
			default:
				MessageBox.Show("Wrong StatDeleteStatus in VSE_StatControl() of MainForm", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.StatDeleteStatus = 0;
				break;
			}
		}

		public void CheckMaintenanceLabel(bool readFromWsp)
		{
			if (this.StationAvailable())
			{
				bool flag;
				if (this.AdvanceWarning1.GetInfo(true) != Color.Black || this.Maintenance1.GetInfo(out flag, out int num, out num, out num, readFromWsp) != Color.Black || !flag)
				{
					flag = false;
				}
				bool flag2 = this.ResultDisplay1.AdvanceWarningsDisplay();
				if (!this.IsOnlineMode)
				{
					this.timerCheckMaintenance.Interval = 8000;
					this.lbMaintenance.Visible = false;
					this.lbRemainingCurves.Visible = false;
				}
				else if (!flag || flag2)
				{
					this.timerCheckMaintenance.Interval = 4000;
					this.lbMaintenance.Visible = true;
				}
				else if (this.CurveDisplay1.IsAutomaticCurveModeActive())
				{
					this.timerCheckMaintenance.Interval = 4000;
					this.lbRemainingCurves.Text = this.Rm.GetString("CurveDisplay") + " " + this.CurveDisplay1.CurvesRemaining.ToString();
					this.lbRemainingCurves.BackColor = Color.Lime;
					this.lbRemainingCurves.Visible = true;
					this.lbMaintenance.Visible = false;
				}
				else if (this.CurveDisplay1.IsFifoCurveBufferActive())
				{
					this.timerCheckMaintenance.Interval = 6000;
					this.lbRemainingCurves.Text = this.Rm.GetString("FIFO_Buffer");
					if (this.CurveFifo.ErrorOnWritingCurves || this.CurveDisplay1.ErrorMessage.Length > 0)
					{
						this.lbRemainingCurves.BackColor = Color.Red;
					}
					else
					{
						this.lbRemainingCurves.BackColor = Color.Lime;
					}
					this.lbRemainingCurves.Visible = true;
					this.lbMaintenance.Visible = false;
				}
				else
				{
					this.timerCheckMaintenance.Interval = 8000;
					this.lbMaintenance.Visible = false;
					this.lbRemainingCurves.Visible = false;
				}
			}
		}

		private void setStatusBarText(string text)
		{
			if (this.statusBar.InvokeRequired)
			{
				SetTextCallback method = this.setStatusBarText;
				base.Invoke(method, text);
			}
			else
			{
				this.StatusBarText(text);
			}
		}

		private void lbError_Click(object sender, EventArgs e)
		{
			this.ErrorDisplay1.WindowState = FormWindowState.Normal;
			this.ErrorDisplay1.BringToFront();
		}

		private void lbLivingSign_Click(object sender, EventArgs e)
		{
			if (this.DISPLAY_LIVING_SIGN && this.VC.PLCCommData.Output.LivingMonitor == 0 && this.IsOnlineMode)
			{
				MessageBox.Show(this.Rm.GetString("LogBookMessage300001"), this.Rm.GetString("LivingSign"));
			}
		}

		private void lbMaintenance_Click(object sender, EventArgs e)
		{
			if (base.ActiveMdiChild == this.ResultDisplay1)
			{
				this.ResultDisplay1.BtParameter_Click();
			}
			if (base.ActiveMdiChild == this.MenuParameter1)
			{
				this.MenuParameter1.BtMaintenance_Click();
			}
			else
			{
				string namesOfReachedCounters = this.AdvanceWarning1.GetNamesOfReachedCounters();
				string text = "";
				if (namesOfReachedCounters.Length != 0)
				{
					text = text + this.Rm.GetString("AdvanceWarningMessages") + "\n\n";
					text += namesOfReachedCounters;
				}
				else
				{
					namesOfReachedCounters = this.AdvanceWarning1.GetNamesOfAdvancedCounters();
					if (namesOfReachedCounters.Length != 0)
					{
						text = text + this.Rm.GetString("AdvanceWarningRemainder") + "\n\n";
						text += namesOfReachedCounters;
					}
				}
				if (text.Length > 0)
				{
					MessageBox.Show(text, this.Rm.GetString("MbhHint"));
				}
			}
		}

		private void lbRemainingCurves_Click(object sender, EventArgs e)
		{
			if (this.CurveDisplay1.IsFifoCurveBufferActive())
			{
				string str = "";
				switch (this.CurveDisplay1.CurvePrint1.GetResultKind())
				{
				case 2:
					str = str + this.Rm.GetString("MbFifoBufferAktive") + "\n      ";
					break;
				case 1:
					str = str + this.Rm.GetString("MbIoFifoBufferAktive") + "\n      ";
					break;
				default:
					str = str + this.Rm.GetString("MbAllFifoBufferAktive") + "\n      ";
					break;
				}
				str += Settings.Default.Curve_StoringFIFO_Directory;
				if (this.CurveFifo.ErrorOnWritingCurves)
				{
					str = str + "\n\n     " + this.Rm.GetString("MbErrorWritingFIFO");
				}
				if (this.CurveDisplay1.ErrorMessage.Length > 0)
				{
					str = str + "\n\n     " + this.CurveDisplay1.ErrorMessage;
				}
				MessageBox.Show(str, this.Rm.GetString("MbhHint"));
			}
			else if (MessageBox.Show(this.Rm.GetString("mbTerminateAutomaticStorage"), this.Rm.GetString("MbhHint"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
			{
				this.CurveDisplay1.ResetCycleSaveMode();
			}
		}

		private void lbIsOnlineMode_Click(object sender, EventArgs e)
		{
			if (!this.IsOnlineMode && MessageBox.Show(this.Rm.GetString("MbReconnectToController"), this.Rm.GetString("MbNoConnection"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
			{
				if (this.Browser1.BrowserNavigated)
				{
					ProcessStartInfo processStartInfo = new ProcessStartInfo();
					processStartInfo.FileName = "http://" + this.MyIp + "/Visualisation/Visualisation.application";
					processStartInfo.CreateNoWindow = true;
					processStartInfo.WindowStyle = ProcessWindowStyle.Minimized;
					Process.Start(processStartInfo);
					Process.GetCurrentProcess().Kill();
				}
				this.HomeButtonClicked();
				this.ResultDisplay1.Reconnect();
			}
		}

		private void lbSwitchVisus_Click(object sender, EventArgs e)
		{
			this.changeWindows();
			if (this.activationBrowserGrantedBy == null && this.IsOnlineMode && Settings.Default.IntegratedMachineVisu)
			{
				if (this.PassCodeLevel < Settings.Default.UserLevel_BrowserForm && this.Usb_Key_Access())
				{
					return;
				}
				MessageBox.Show(this.Rm.GetString("MbMachineVisuShowNotAllowed"), this.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}

		private void lbProcessVisu_Click(object sender, EventArgs e)
		{
			if (!this.IsOnlineMode)
			{
				MessageBox.Show(this.Rm.GetString("MbNoConnection"), this.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else if (this._READ_ONLY_CONTROLLER)
			{
				MessageBox.Show(this.Rm.GetString("MbReadOnlyNoMVisu"), this.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.ShowMachineVisu();
			}
		}

		private void lbIsAutoMode_Click(object sender, EventArgs e)
		{
		}

		private void lbMachineVisu_Click(object sender, EventArgs e)
		{
			this.changeWindows();
		}

		private void lbProcessVisu_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.lbProcessVisu.BackColor = Color.LightGray;
				this.lbMachineVisu.BackColor = Color.LightGray;
			}
		}

		private void lbProcessVisu_MouseUp(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.lbProcessVisu.BackColor = SystemColors.Control;
				this.lbMachineVisu.BackColor = SystemColors.Control;
			}
		}

		private void lbProcessVisu_MouseLeave(object sender, EventArgs e)
		{
			this.lbProcessVisu.BackColor = SystemColors.Control;
			this.lbMachineVisu.BackColor = SystemColors.Control;
		}

		public void HomeButtonClicked()
		{
			Form activeMdiChild = base.ActiveMdiChild;
			if (activeMdiChild != this.ResultDisplay1 && !this.DiscardAnySettings())
			{
				return;
			}
			if (activeMdiChild == this.AdvanceWarning1)
			{
				this.AdvanceWarning1.CancelMenu();
				this.MenuMaintenance1.CancelMenu();
				this.MenuParameter1.CancelMenu();
			}
			if (activeMdiChild == this.Backup1)
			{
				this.Backup1.CancelMenu();
				this.MenuParameter1.CancelMenu();
			}
			else if (activeMdiChild == this.CheckParam1)
			{
				this.CheckParam1.CancelMenu();
				if (base.ActiveMdiChild == this.EditDrivingStep1)
				{
					this.EditDrivingStep1.CancelMenu();
				}
				else
				{
					this.EditFinalizeStep1.CancelMenu();
				}
				this.StepOverview1.CancelMenu();
				this.ProgramOverview1.CancelMenu();
				this.MenuParameter1.CancelMenu();
			}
			else if (activeMdiChild == this.CurveDisplay1)
			{
				this.CurveDisplay1.CancelMenu();
				this.MenuAnalysis1.CancelMenu();
			}
			else if (activeMdiChild == this.Component1)
			{
				this.Component1.CancelMenu();
				this.MenuMaintenance1.CancelMenu();
				this.MenuParameter1.CancelMenu();
			}
			else if (activeMdiChild == this.CycleCounter1)
			{
				this.CycleCounter1.CancelMenu();
				this.MenuStatistics1.CancelMenu();
				this.MenuAnalysis1.CancelMenu();
			}
			else if (activeMdiChild == this.VisualisationParam1)
			{
				this.VisualisationParam1.CancelMenu();
				this.SystemConstants1.CancelMenu();
				this.MenuParameter1.CancelMenu();
			}
			else if (activeMdiChild == this.EditDrivingStep1)
			{
				this.EditDrivingStep1.CancelMenu();
				this.StepOverview1.CancelMenu();
				this.ProgramOverview1.CancelMenu();
				this.MenuParameter1.CancelMenu();
			}
			else if (activeMdiChild == this.EditFinalizeStep1)
			{
				this.EditFinalizeStep1.CancelMenu();
				this.StepOverview1.CancelMenu();
				this.ProgramOverview1.CancelMenu();
				this.MenuParameter1.CancelMenu();
			}
			else if (activeMdiChild == this.EditOrganizeStep1)
			{
				this.EditOrganizeStep1.CancelMenu();
				this.StepOverview1.CancelMenu();
				this.ProgramOverview1.CancelMenu();
				this.MenuParameter1.CancelMenu();
			}
			else if (activeMdiChild == this.FourStepEdit1)
			{
				this.FourStepEdit1.CancelMenu();
				this.FourStepOverview1.CancelMenu();
				this.ProgramOverview1.CancelMenu();
				this.MenuParameter1.CancelMenu();
			}
			else if (activeMdiChild == this.FourStepOverview1)
			{
				this.FourStepOverview1.CancelMenu();
				this.ProgramOverview1.CancelMenu();
				this.MenuParameter1.CancelMenu();
			}
			else if (activeMdiChild == this.HandStart1)
			{
				this.HandStart1.CancelMenu();
			}
			else if (activeMdiChild == this.LastNIOResults1)
			{
				this.LastNIOResults1.CancelMenu();
				this.MenuAnalysis1.CancelMenu();
			}
			else if (activeMdiChild == this.LogBookForm1)
			{
				this.LogBookForm1.CancelMenu();
				this.MenuAnalysis1.CancelMenu();
			}
			else if (activeMdiChild == this.LogChangesForm1)
			{
				this.LogChangesForm1.CancelMenu();
				this.MenuAnalysis1.CancelMenu();
			}
			else if (activeMdiChild == this.Maintenance1)
			{
				this.Maintenance1.CancelMenu();
				this.MenuMaintenance1.CancelMenu();
				this.MenuParameter1.CancelMenu();
			}
			else if (activeMdiChild == this.MenuAnalysis1)
			{
				this.MenuAnalysis1.CancelMenu();
			}
			else if (activeMdiChild == this.MenuMaintenance1)
			{
				this.MenuMaintenance1.CancelMenu();
				this.MenuParameter1.CancelMenu();
			}
			else if (activeMdiChild == this.MenuParameter1)
			{
				this.MenuParameter1.CancelMenu();
			}
			else if (activeMdiChild == this.MenuStatistics1)
			{
				this.MenuStatistics1.CancelMenu();
				this.MenuAnalysis1.CancelMenu();
			}
			else if (activeMdiChild == this.MenuTest1)
			{
				this.MenuTest1.CancelMenu();
			}
			else if (activeMdiChild != this.PasscodeManager1)
			{
				if (activeMdiChild == this.PrgOptParameter1)
				{
					this.PrgOptParameter1.CancelMenu();
					this.StepOverview1.CancelMenu();
					this.ProgramOverview1.CancelMenu();
					this.MenuParameter1.CancelMenu();
				}
				else if (activeMdiChild == this.ProgramOverview1)
				{
					this.ProgramOverview1.CancelMenu();
					this.MenuParameter1.CancelMenu();
				}
				else if (activeMdiChild != this.ResultDisplay1)
				{
					if (activeMdiChild == this.SpindleConstants1)
					{
						this.SpindleConstants1.CancelMenu();
						this.MenuParameter1.CancelMenu();
					}
					else if (activeMdiChild == this.StatisticsLastRes1)
					{
						this.StatisticsLastRes1.CancelMenu();
						this.MenuAnalysis1.CancelMenu();
					}
					else if (activeMdiChild == this.StepOverview1)
					{
						this.StepOverview1.CancelMenu();
						this.ProgramOverview1.CancelMenu();
						this.MenuParameter1.CancelMenu();
					}
					else if (activeMdiChild == this.StepResult1)
					{
						this.StepResult1.CancelMenu();
						this.MenuAnalysis1.CancelMenu();
					}
					else if (activeMdiChild == this.SystemConstants1)
					{
						this.SystemConstants1.CancelMenu();
						this.MenuParameter1.CancelMenu();
					}
					else if (activeMdiChild == this.LevelAssignment1)
					{
						this.LevelAssignment1.CancelMenu();
						this.SystemConstants1.CancelMenu();
						this.MenuParameter1.CancelMenu();
					}
					else if (activeMdiChild == this.TestIO1)
					{
						this.TestIO1.CancelMenu();
						this.MenuTest1.CancelMenu();
					}
					else if (activeMdiChild == this.TestMotorSensor1)
					{
						this.TestMotorSensor1.CancelMenu();
						this.MenuTest1.CancelMenu();
					}
					else if (activeMdiChild == this.TestSPSIO1)
					{
						this.TestSPSIO1.CancelMenu();
						this.MenuTest1.CancelMenu();
					}
					else if (activeMdiChild == this.TopTen1)
					{
						this.TopTen1.CancelMenu();
						this.LogBookForm1.CancelMenu();
						this.MenuAnalysis1.CancelMenu();
					}
				}
			}
		}

		private void MainForm_HelpButtonClicked(object sender, CancelEventArgs e)
		{
			e.Cancel = true;
			if (base.HelpButton)
			{
				base.HelpButton = false;
				Form activeMdiChild = base.ActiveMdiChild;
				if (activeMdiChild == this.AdvanceWarning1)
				{
					this.AdvanceWarning1.ShowHelp();
				}
				if (activeMdiChild == this.Backup1)
				{
					this.Backup1.ShowHelp();
				}
				else if (activeMdiChild == this.CheckParam1)
				{
					this.CheckParam1.ShowHelp();
				}
				else if (activeMdiChild == this.CurveDisplay1)
				{
					this.CurveDisplay1.ShowHelp();
				}
				else if (activeMdiChild == this.Component1)
				{
					this.Component1.ShowHelp();
				}
				else if (activeMdiChild == this.CycleCounter1)
				{
					this.CycleCounter1.ShowHelp();
				}
				else if (activeMdiChild == this.VisualisationParam1)
				{
					this.VisualisationParam1.ShowHelp();
				}
				else if (activeMdiChild == this.EditDrivingStep1)
				{
					this.EditDrivingStep1.ShowHelp();
				}
				else if (activeMdiChild == this.EditFinalizeStep1)
				{
					this.EditFinalizeStep1.ShowHelp();
				}
				else if (activeMdiChild == this.EditOrganizeStep1)
				{
					this.EditOrganizeStep1.ShowHelp();
				}
				else if (activeMdiChild == this.FourStepEdit1)
				{
					this.FourStepEdit1.ShowHelp();
				}
				else if (activeMdiChild == this.FourStepOverview1)
				{
					this.FourStepOverview1.ShowHelp();
				}
				else if (activeMdiChild == this.HandStart1)
				{
					this.HandStart1.ShowHelp();
				}
				else if (activeMdiChild == this.LastNIOResults1)
				{
					this.LastNIOResults1.ShowHelp();
				}
				else if (activeMdiChild == this.LogBookForm1)
				{
					this.LogBookForm1.ShowHelp();
				}
				else if (activeMdiChild == this.LogChangesForm1)
				{
					this.LogChangesForm1.ShowHelp();
				}
				else if (activeMdiChild == this.Maintenance1)
				{
					this.Maintenance1.ShowHelp();
				}
				else if (activeMdiChild == this.MenuAnalysis1)
				{
					this.MenuAnalysis1.ShowHelp();
				}
				else if (activeMdiChild == this.MenuMaintenance1)
				{
					this.MenuMaintenance1.ShowHelp();
				}
				else if (activeMdiChild == this.MenuParameter1)
				{
					this.MenuParameter1.ShowHelp();
				}
				else if (activeMdiChild == this.MenuStatistics1)
				{
					this.MenuStatistics1.ShowHelp();
				}
				else if (activeMdiChild == this.MenuTest1)
				{
					this.MenuTest1.ShowHelp();
				}
				else if (activeMdiChild == this.PasscodeManager1)
				{
					this.PasscodeManager1.ShowHelp();
				}
				else if (activeMdiChild == this.PrgOptParameter1)
				{
					this.PrgOptParameter1.ShowHelp();
				}
				else if (activeMdiChild == this.ProgramOverview1)
				{
					this.ProgramOverview1.ShowHelp();
				}
				else if (activeMdiChild == this.ResultDisplay1)
				{
					this.ResultDisplay1.ShowHelp();
				}
				else if (activeMdiChild == this.SpindleConstants1)
				{
					this.SpindleConstants1.ShowHelp();
				}
				else if (activeMdiChild == this.StatisticsLastRes1)
				{
					this.StatisticsLastRes1.ShowHelp();
				}
				else if (activeMdiChild == this.StepOverview1)
				{
					this.StepOverview1.ShowHelp();
				}
				else if (activeMdiChild == this.StepResult1)
				{
					this.StepResult1.ShowHelp();
				}
				else if (activeMdiChild == this.SystemConstants1)
				{
					this.SystemConstants1.ShowHelp();
				}
				else if (activeMdiChild == this.LevelAssignment1)
				{
					this.LevelAssignment1.ShowHelp();
				}
				else if (activeMdiChild == this.TestIO1)
				{
					this.TestIO1.ShowHelp();
				}
				else if (activeMdiChild == this.TestMotorSensor1)
				{
					this.TestMotorSensor1.ShowHelp();
				}
				else if (activeMdiChild == this.TestSPSIO1)
				{
					this.TestSPSIO1.ShowHelp();
				}
				else if (activeMdiChild == this.TopTen1)
				{
					this.TopTen1.ShowHelp();
				}
				if (!Settings.Default.IntegratedHelp)
				{
					base.HelpButton = true;
				}
			}
		}

		private void pBWeberLogo_Click(object sender, EventArgs e)
		{
			this.changeWindows();
			if (this.activationBrowserGrantedBy == null && this.IsOnlineMode && Settings.Default.IntegratedMachineVisu)
			{
				if (this.PassCodeLevel < Settings.Default.UserLevel_BrowserForm && this.Usb_Key_Access())
				{
					return;
				}
				MessageBox.Show(this.Rm.GetString("MbMachineVisuShowNotAllowed"), this.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}

		private void timerDelayKeyRemoved_Tick(object sender, EventArgs e)
		{
			this.timerDelayKeyRemoved.Stop();
			this.checkActiveFromKeyRemoved(base.ActiveMdiChild);
		}

		private void timerDelayKeyArrived_Tick(object sender, EventArgs e)
		{
			this.timerDelayKeyArrived.Stop();
			this.checkActiveFromKeyArrived(base.ActiveMdiChild);
		}

		private void timerControllerOffline_Tick(object sender, EventArgs e)
		{
			if (this.LifeSign <= 10000 / this.timerControllerOffline.Interval)
			{
				this.LifeSign++;
			}
			else
			{
				this.controllerIsOfflineNow();
			}
		}

		private void timerHome_Tick(object sender, EventArgs e)
		{
			this.timerHome.Enabled = false;
			this.HomeButtonClicked();
			this.ResultDisplay1.EnableMenu();
		}

		public void ControllerIsOfflineNow()
		{
			this.controllerIsOfflineNow();
		}

		private void controllerIsOfflineNow()
		{
			if (this.StationAvailable())
			{
				this.userToStatus(0, true);
			}
			else
			{
				this.userToStatus(0, false);
			}
			this.timerControllerOffline.Enabled = false;
			this.IsOnlineMode = false;
			this.VC.Status0.AutoMode = 0;
			this.VC.PLCCommData.Output.UserLevel = 0;
			this.ResultDisplay1.MenEna();
			this.MenEna();
			this.VC.CloseConnection();
			this.Block1Status = 0;
			this.hideMachineVisu();
			this.FtpProgress.Abort();
			this.WeberLogoImage(1);
			if (this.usb_key_access_result == 3)
			{
				UsbDetectorEventArgs usbDetectorEventArgs = new UsbDetectorEventArgs();
				usbDetectorEventArgs = this.currentUsbDetectorArguments;
				this.OnUsbKeyRemoved(null, usbDetectorEventArgs);
				this.OnUsbKeyArrived(null, usbDetectorEventArgs);
			}
		}

		public bool StationAvailable()
		{
			if (!this.ControllerPing.DoPingController() && !this.ControllerPing.DoCheckSocketController())
			{
				return false;
			}
			return true;
		}

		private void timerControllerLivingSign_Tick(object sender, EventArgs e)
		{
			if (!this.IsOnlineMode)
			{
				this.lbLivingSign.BackColor = SystemColors.Control;
				this.lbLivingSign.Text = this.Rm.GetString("Robot");
				this.ResultMiniDisplay1.LivingSign(false);
				this.livingSignInit = false;
			}
			else
			{
				if (!this.livingSignInit)
				{
					this.timerControllerLivingSign.Stop();
					if (this.StationAvailable() && this.VC.ReceiveVarBlock(42))
					{
						int num = (this.VC.PLCCommData.Input.LivingSignEnabled != 0) ? 1 : 0;
						bool dISPLAY_LIVING_SIGN = (byte)num != 0;
						this.recent_DISPLAY_LIVING_SIGN = ((byte)num != 0);
						this.DISPLAY_LIVING_SIGN = dISPLAY_LIVING_SIGN;
						this.initLivingSignControls();
						this.livingSignInit = true;
					}
					else
					{
						this.livingSignInit = true;
					}
				}
				this.timerControllerLivingSign.Stop();
				if (this.StationAvailable())
				{
					if (!this.VC.ReceiveVarBlock(42))
					{
						this.controllerIsOfflineNow();
					}
					else
					{
						this.DISPLAY_LIVING_SIGN = (this.VC.PLCCommData.Input.LivingSignEnabled != 0 && true);
						if (this.recent_DISPLAY_LIVING_SIGN != this.DISPLAY_LIVING_SIGN)
						{
							this.recent_DISPLAY_LIVING_SIGN = this.DISPLAY_LIVING_SIGN;
							this.initLivingSignControls();
						}
						if (this.VC.PLCCommData.Output.LivingMonitor != 0)
						{
							this.timerControllerLivingSign.Interval = 5000;
							this.ResultMiniDisplay1.LivingSign(true);
							this.lbLivingSign.Text = this.Rm.GetString("Robot");
							this.lbLivingSign.BackColor = Color.Lime;
						}
						else
						{
							this.timerControllerLivingSign.Interval = 2000;
							this.ResultMiniDisplay1.LivingSign(false);
							this.lbLivingSign.Text = this.Rm.GetString("Robot");
							this.lbLivingSign.BackColor = Color.Yellow;
						}
					}
				}
				this.timerControllerLivingSign.Start();
			}
		}

		private void timerInitialize_Tick(object sender, EventArgs e)
		{
			this.timerInitialize.Stop();
			this.StartupVarConnection();
			if (this.ShowVisParWindow)
			{
				this.VisualisationParam1.ShowWindow();
			}
			this.ResultDisplay1.ShowWindow();
			this.timerControllerLivingSign.Start();
			this.Browser1.ResetBrowserNavigated();
			this.LevelAssignment1.LoadWSP_ValuesToSettings(true);
			this.CheckMaintenanceLabel(true);
			this.timerCheckMaintenance.Start();
			if (this.OpenGivenProgram && this.OpenGivenProgramPath.Length != 0 && this.ProcessProgram.LoadAllProgDataFromFile(this.OpenGivenProgramPath, false))
			{
				this.IsOfflineVersion = true;
				this.IsOnlineMode = false;
				this.PassCodeLevel = 3;
				this.actualUser = "WVM";
				this.MenuParameter1.ShowWindow();
				this.ProgramOverview1.ShowWindow();
				this.OpenGivenProgram = false;
			}
		}

		private void timerCheckMaintenance_Tick(object sender, EventArgs e)
		{
			this.timerCheckMaintenance.Stop();
			this.CheckMaintenanceLabel(false);
			this.timerCheckMaintenance.Start();
		}
	}
}
