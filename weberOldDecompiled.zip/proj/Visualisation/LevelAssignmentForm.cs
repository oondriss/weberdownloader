using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class LevelAssignmentForm : Form
	{
		private MainForm Main;

		private OpenFileDialog openFileDialog;

		private SaveFileDialog saveFileDialog;

		private ComboBox cBBackupForm;

		private ComboBox cBEditSteps;

		private ComboBox cBCycleCounterForm;

		private ComboBox cBStepOverviewForm;

		private ComboBox cBTestIOForm;

		private ComboBox cBSystemConstantsForm;

		private ComboBox cBStatisticsLastResForm;

		private ComboBox cBSpindleConstantsForm;

		private ComboBox cBProgramOverviewForm;

		private ComboBox cBCheckParamForm;

		private Label lbBackupForm;

		private Label lbCycleCounterForm;

		private Label lbEditSteps;

		private Label lbPrgOptParameterForm;

		private Label lbVisualisationParamForm;

		private Label lbTestMotorSensorForm;

		private Label lbTestIOForm;

		private Label lbStepOverviewForm;

		private Label lbStatisticsLastResForm;

		private Label lbSpindleConstantsForm;

		private Label lbSystemConstantsForm;

		private Panel pnMenu;

		private Button btHelp;

		private Button btStore;

		private Button btLoadLevel;

		private Button btBack;

		private Button bt5;

		private Button bt3;

		private Button bt4;

		private Button btStoreLevel;

		private Label lbProgramOverviewForm;

		private ComboBox cBPrgOptParameterForm;

		private Label lbCheckParamForm;

		private ComboBox cBVisualisationParamForm;

		private ComboBox cBTestMotorSensorForm;

		private Label lbFourLevelEditForm;

		private ComboBox cBFourLevelEditForm;

		private Label lbMaintenanceForm;

		private ComboBox cBMaintenance;

		private Label lbHandStartForm;

		private ComboBox cBHandStartForm;

		private Label lbBrowserForm;

		private ComboBox cBBrowserForm;

		private IContainer components;

		private bool bInitialize;

		public LevelAssignmentForm(MainForm main)
		{
			this.Main = main;
			this.openFileDialog = new OpenFileDialog();
			this.openFileDialog.Filter = "Level|*.wlxml|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.saveFileDialog = new SaveFileDialog();
			this.saveFileDialog.Filter = "Level|*.wlxml|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btStoreLevel = new Button();
			this.btLoadLevel = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.bt5 = new Button();
			this.bt3 = new Button();
			this.bt4 = new Button();
			this.btStore = new Button();
			this.lbBackupForm = new Label();
			this.lbCycleCounterForm = new Label();
			this.lbEditSteps = new Label();
			this.lbPrgOptParameterForm = new Label();
			this.lbVisualisationParamForm = new Label();
			this.lbTestMotorSensorForm = new Label();
			this.lbTestIOForm = new Label();
			this.lbSystemConstantsForm = new Label();
			this.lbStepOverviewForm = new Label();
			this.lbStatisticsLastResForm = new Label();
			this.lbSpindleConstantsForm = new Label();
			this.cBBackupForm = new ComboBox();
			this.cBEditSteps = new ComboBox();
			this.cBCycleCounterForm = new ComboBox();
			this.cBTestIOForm = new ComboBox();
			this.cBSystemConstantsForm = new ComboBox();
			this.cBStepOverviewForm = new ComboBox();
			this.cBStatisticsLastResForm = new ComboBox();
			this.cBSpindleConstantsForm = new ComboBox();
			this.cBProgramOverviewForm = new ComboBox();
			this.cBCheckParamForm = new ComboBox();
			this.lbProgramOverviewForm = new Label();
			this.cBPrgOptParameterForm = new ComboBox();
			this.lbCheckParamForm = new Label();
			this.cBVisualisationParamForm = new ComboBox();
			this.cBTestMotorSensorForm = new ComboBox();
			this.lbFourLevelEditForm = new Label();
			this.cBFourLevelEditForm = new ComboBox();
			this.lbMaintenanceForm = new Label();
			this.cBMaintenance = new ComboBox();
			this.lbHandStartForm = new Label();
			this.cBHandStartForm = new ComboBox();
			this.lbBrowserForm = new Label();
			this.cBBrowserForm = new ComboBox();
			this.pnMenu.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Controls.Add(this.btStoreLevel);
			this.pnMenu.Controls.Add(this.btLoadLevel);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Controls.Add(this.bt5);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.bt4);
			this.pnMenu.Controls.Add(this.btStore);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btStoreLevel.Location = new Point(3, 323);
			this.btStoreLevel.Name = "btStoreLevel";
			this.btStoreLevel.Size = new Size(74, 62);
			this.btStoreLevel.TabIndex = 7;
			this.btStoreLevel.Text = "Store settings";
			this.btStoreLevel.Click += this.btStoreLevel_Click;
			this.btLoadLevel.Location = new Point(3, 387);
			this.btLoadLevel.Name = "btLoadLevel";
			this.btLoadLevel.Size = new Size(74, 62);
			this.btLoadLevel.TabIndex = 6;
			this.btLoadLevel.Text = "Load Settings";
			this.btLoadLevel.Click += this.btLoadLevel_Click;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 451);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 5;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click_1;
			this.bt5.Enabled = false;
			this.bt5.Location = new Point(3, 259);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(74, 62);
			this.bt5.TabIndex = 4;
			this.bt3.Enabled = false;
			this.bt3.Location = new Point(3, 131);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 2;
			this.bt4.Enabled = false;
			this.bt4.Location = new Point(3, 195);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(74, 62);
			this.bt4.TabIndex = 3;
			this.btStore.Location = new Point(3, 3);
			this.btStore.Name = "btStore";
			this.btStore.Size = new Size(74, 62);
			this.btStore.TabIndex = 0;
			this.btStore.Text = "Speichern";
			this.btStore.Click += this.btStore_Click;
			this.lbBackupForm.AutoSize = true;
			this.lbBackupForm.Location = new Point(228, 266);
			this.lbBackupForm.Name = "lbBackupForm";
			this.lbBackupForm.Size = new Size(69, 15);
			this.lbBackupForm.TabIndex = 1;
			this.lbBackupForm.Text = "BackupForm";
			this.lbCycleCounterForm.AutoSize = true;
			this.lbCycleCounterForm.Location = new Point(228, 340);
			this.lbCycleCounterForm.Name = "lbCycleCounterForm";
			this.lbCycleCounterForm.Size = new Size(99, 15);
			this.lbCycleCounterForm.TabIndex = 3;
			this.lbCycleCounterForm.Text = "CycleCounterForm";
			this.lbCycleCounterForm.Visible = false;
			this.lbEditSteps.AutoSize = true;
			this.lbEditSteps.Location = new Point(228, 92);
			this.lbEditSteps.Name = "lbEditSteps";
			this.lbEditSteps.Size = new Size(87, 15);
			this.lbEditSteps.TabIndex = 4;
			this.lbEditSteps.Text = "EditDrivingSteps";
			this.lbPrgOptParameterForm.AutoSize = true;
			this.lbPrgOptParameterForm.Location = new Point(228, 117);
			this.lbPrgOptParameterForm.Name = "lbPrgOptParameterForm";
			this.lbPrgOptParameterForm.Size = new Size(117, 15);
			this.lbPrgOptParameterForm.TabIndex = 9;
			this.lbPrgOptParameterForm.Text = "PrgOptParameterForm";
			this.lbVisualisationParamForm.AutoSize = true;
			this.lbVisualisationParamForm.Location = new Point(228, 241);
			this.lbVisualisationParamForm.Name = "lbVisualisationParamForm";
			this.lbVisualisationParamForm.Size = new Size(123, 15);
			this.lbVisualisationParamForm.TabIndex = 18;
			this.lbVisualisationParamForm.Text = "VisualisationParamForm";
			this.lbTestMotorSensorForm.AutoSize = true;
			this.lbTestMotorSensorForm.Location = new Point(228, 465);
			this.lbTestMotorSensorForm.Name = "lbTestMotorSensorForm";
			this.lbTestMotorSensorForm.Size = new Size(117, 15);
			this.lbTestMotorSensorForm.TabIndex = 17;
			this.lbTestMotorSensorForm.Text = "TestMotorSensorForm";
			this.lbTestIOForm.AutoSize = true;
			this.lbTestIOForm.Location = new Point(228, 440);
			this.lbTestIOForm.Name = "lbTestIOForm";
			this.lbTestIOForm.Size = new Size(66, 15);
			this.lbTestIOForm.TabIndex = 16;
			this.lbTestIOForm.Text = "TestIOForm";
			this.lbSystemConstantsForm.AutoSize = true;
			this.lbSystemConstantsForm.Location = new Point(228, 216);
			this.lbSystemConstantsForm.Name = "lbSystemConstantsForm";
			this.lbSystemConstantsForm.Size = new Size(118, 15);
			this.lbSystemConstantsForm.TabIndex = 15;
			this.lbSystemConstantsForm.Text = "SystemConstantsForm";
			this.lbStepOverviewForm.AutoSize = true;
			this.lbStepOverviewForm.Location = new Point(228, 67);
			this.lbStepOverviewForm.Name = "lbStepOverviewForm";
			this.lbStepOverviewForm.Size = new Size(101, 15);
			this.lbStepOverviewForm.TabIndex = 14;
			this.lbStepOverviewForm.Text = "StepOverviewForm";
			this.lbStatisticsLastResForm.AutoSize = true;
			this.lbStatisticsLastResForm.Location = new Point(228, 365);
			this.lbStatisticsLastResForm.Name = "lbStatisticsLastResForm";
			this.lbStatisticsLastResForm.Size = new Size(117, 15);
			this.lbStatisticsLastResForm.TabIndex = 13;
			this.lbStatisticsLastResForm.Text = "StatisticsLastResForm";
			this.lbSpindleConstantsForm.AutoSize = true;
			this.lbSpindleConstantsForm.Location = new Point(228, 191);
			this.lbSpindleConstantsForm.Name = "lbSpindleConstantsForm";
			this.lbSpindleConstantsForm.Size = new Size(117, 15);
			this.lbSpindleConstantsForm.TabIndex = 12;
			this.lbSpindleConstantsForm.Text = "SpindleConstantsForm";
			this.cBBackupForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBBackupForm.FormattingEnabled = true;
			this.cBBackupForm.Location = new Point(30, 266);
			this.cBBackupForm.Name = "cBBackupForm";
			this.cBBackupForm.Size = new Size(150, 23);
			this.cBBackupForm.TabIndex = 19;
			this.cBBackupForm.SelectedIndexChanged += this.settingsChanged;
			this.cBEditSteps.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBEditSteps.FormattingEnabled = true;
			this.cBEditSteps.Location = new Point(30, 92);
			this.cBEditSteps.Name = "cBEditSteps";
			this.cBEditSteps.Size = new Size(150, 23);
			this.cBEditSteps.TabIndex = 22;
			this.cBEditSteps.SelectedIndexChanged += this.settingsChanged;
			this.cBCycleCounterForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBCycleCounterForm.FormattingEnabled = true;
			this.cBCycleCounterForm.Location = new Point(30, 340);
			this.cBCycleCounterForm.Name = "cBCycleCounterForm";
			this.cBCycleCounterForm.Size = new Size(150, 23);
			this.cBCycleCounterForm.TabIndex = 21;
			this.cBCycleCounterForm.Visible = false;
			this.cBCycleCounterForm.SelectedIndexChanged += this.settingsChanged;
			this.cBTestIOForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBTestIOForm.FormattingEnabled = true;
			this.cBTestIOForm.Location = new Point(30, 440);
			this.cBTestIOForm.Name = "cBTestIOForm";
			this.cBTestIOForm.Size = new Size(150, 23);
			this.cBTestIOForm.TabIndex = 34;
			this.cBTestIOForm.SelectedIndexChanged += this.settingsChanged;
			this.cBSystemConstantsForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBSystemConstantsForm.FormattingEnabled = true;
			this.cBSystemConstantsForm.Location = new Point(30, 216);
			this.cBSystemConstantsForm.Name = "cBSystemConstantsForm";
			this.cBSystemConstantsForm.Size = new Size(150, 23);
			this.cBSystemConstantsForm.TabIndex = 33;
			this.cBSystemConstantsForm.SelectedIndexChanged += this.settingsChanged;
			this.cBStepOverviewForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBStepOverviewForm.FormattingEnabled = true;
			this.cBStepOverviewForm.Location = new Point(30, 67);
			this.cBStepOverviewForm.Name = "cBStepOverviewForm";
			this.cBStepOverviewForm.Size = new Size(150, 23);
			this.cBStepOverviewForm.TabIndex = 32;
			this.cBStepOverviewForm.SelectedIndexChanged += this.settingsChanged;
			this.cBStatisticsLastResForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBStatisticsLastResForm.FormattingEnabled = true;
			this.cBStatisticsLastResForm.Location = new Point(30, 365);
			this.cBStatisticsLastResForm.Name = "cBStatisticsLastResForm";
			this.cBStatisticsLastResForm.Size = new Size(150, 23);
			this.cBStatisticsLastResForm.TabIndex = 31;
			this.cBStatisticsLastResForm.SelectedIndexChanged += this.settingsChanged;
			this.cBSpindleConstantsForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBSpindleConstantsForm.FormattingEnabled = true;
			this.cBSpindleConstantsForm.Location = new Point(30, 191);
			this.cBSpindleConstantsForm.Name = "cBSpindleConstantsForm";
			this.cBSpindleConstantsForm.Size = new Size(150, 23);
			this.cBSpindleConstantsForm.TabIndex = 30;
			this.cBSpindleConstantsForm.SelectedIndexChanged += this.settingsChanged;
			this.cBProgramOverviewForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBProgramOverviewForm.FormattingEnabled = true;
			this.cBProgramOverviewForm.Location = new Point(30, 42);
			this.cBProgramOverviewForm.Name = "cBProgramOverviewForm";
			this.cBProgramOverviewForm.Size = new Size(150, 23);
			this.cBProgramOverviewForm.TabIndex = 28;
			this.cBProgramOverviewForm.SelectedIndexChanged += this.settingsChanged;
			this.cBCheckParamForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBCheckParamForm.FormattingEnabled = true;
			this.cBCheckParamForm.Location = new Point(30, 142);
			this.cBCheckParamForm.Name = "cBCheckParamForm";
			this.cBCheckParamForm.Size = new Size(150, 23);
			this.cBCheckParamForm.TabIndex = 20;
			this.cBCheckParamForm.SelectedIndexChanged += this.settingsChanged;
			this.lbProgramOverviewForm.AutoSize = true;
			this.lbProgramOverviewForm.Location = new Point(228, 45);
			this.lbProgramOverviewForm.Name = "lbProgramOverviewForm";
			this.lbProgramOverviewForm.Size = new Size(120, 15);
			this.lbProgramOverviewForm.TabIndex = 35;
			this.lbProgramOverviewForm.Text = "ProgramOverviewForm";
			this.cBPrgOptParameterForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBPrgOptParameterForm.FormattingEnabled = true;
			this.cBPrgOptParameterForm.Location = new Point(30, 117);
			this.cBPrgOptParameterForm.Name = "cBPrgOptParameterForm";
			this.cBPrgOptParameterForm.Size = new Size(150, 23);
			this.cBPrgOptParameterForm.TabIndex = 36;
			this.cBPrgOptParameterForm.SelectedIndexChanged += this.settingsChanged;
			this.lbCheckParamForm.AutoSize = true;
			this.lbCheckParamForm.Location = new Point(228, 142);
			this.lbCheckParamForm.Name = "lbCheckParamForm";
			this.lbCheckParamForm.Size = new Size(95, 15);
			this.lbCheckParamForm.TabIndex = 37;
			this.lbCheckParamForm.Text = "CheckParamForm";
			this.cBVisualisationParamForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBVisualisationParamForm.FormattingEnabled = true;
			this.cBVisualisationParamForm.Location = new Point(30, 241);
			this.cBVisualisationParamForm.Name = "cBVisualisationParamForm";
			this.cBVisualisationParamForm.Size = new Size(150, 23);
			this.cBVisualisationParamForm.TabIndex = 38;
			this.cBVisualisationParamForm.SelectedIndexChanged += this.settingsChanged;
			this.cBTestMotorSensorForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBTestMotorSensorForm.FormattingEnabled = true;
			this.cBTestMotorSensorForm.Location = new Point(30, 465);
			this.cBTestMotorSensorForm.Name = "cBTestMotorSensorForm";
			this.cBTestMotorSensorForm.Size = new Size(150, 23);
			this.cBTestMotorSensorForm.TabIndex = 39;
			this.cBTestMotorSensorForm.SelectedIndexChanged += this.settingsChanged;
			this.lbFourLevelEditForm.AutoSize = true;
			this.lbFourLevelEditForm.Location = new Point(228, 166);
			this.lbFourLevelEditForm.Name = "lbFourLevelEditForm";
			this.lbFourLevelEditForm.Size = new Size(99, 15);
			this.lbFourLevelEditForm.TabIndex = 41;
			this.lbFourLevelEditForm.Text = "FourLevelEditForm";
			this.cBFourLevelEditForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBFourLevelEditForm.FormattingEnabled = true;
			this.cBFourLevelEditForm.Location = new Point(30, 166);
			this.cBFourLevelEditForm.Name = "cBFourLevelEditForm";
			this.cBFourLevelEditForm.Size = new Size(150, 23);
			this.cBFourLevelEditForm.TabIndex = 40;
			this.cBFourLevelEditForm.SelectedIndexChanged += this.settingsChanged;
			this.lbMaintenanceForm.AutoSize = true;
			this.lbMaintenanceForm.Location = new Point(228, 292);
			this.lbMaintenanceForm.Name = "lbMaintenanceForm";
			this.lbMaintenanceForm.Size = new Size(94, 15);
			this.lbMaintenanceForm.TabIndex = 42;
			this.lbMaintenanceForm.Text = "MaintenanceForm";
			this.cBMaintenance.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBMaintenance.FormattingEnabled = true;
			this.cBMaintenance.Location = new Point(30, 292);
			this.cBMaintenance.Name = "cBMaintenance";
			this.cBMaintenance.Size = new Size(150, 23);
			this.cBMaintenance.TabIndex = 43;
			this.cBMaintenance.SelectedIndexChanged += this.settingsChanged;
			this.lbHandStartForm.AutoSize = true;
			this.lbHandStartForm.Location = new Point(228, 415);
			this.lbHandStartForm.Name = "lbHandStartForm";
			this.lbHandStartForm.Size = new Size(81, 15);
			this.lbHandStartForm.TabIndex = 44;
			this.lbHandStartForm.Text = "HandStartForm";
			this.cBHandStartForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBHandStartForm.FormattingEnabled = true;
			this.cBHandStartForm.Location = new Point(30, 415);
			this.cBHandStartForm.Name = "cBHandStartForm";
			this.cBHandStartForm.Size = new Size(150, 23);
			this.cBHandStartForm.TabIndex = 45;
			this.cBHandStartForm.SelectedIndexChanged += this.settingsChanged;
			this.lbBrowserForm.AutoSize = true;
			this.lbBrowserForm.Location = new Point(228, 20);
			this.lbBrowserForm.Name = "lbBrowserForm";
			this.lbBrowserForm.Size = new Size(73, 15);
			this.lbBrowserForm.TabIndex = 47;
			this.lbBrowserForm.Text = "BrowserForm";
			this.cBBrowserForm.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBBrowserForm.FormattingEnabled = true;
			this.cBBrowserForm.Location = new Point(30, 17);
			this.cBBrowserForm.Name = "cBBrowserForm";
			this.cBBrowserForm.Size = new Size(150, 23);
			this.cBBrowserForm.TabIndex = 46;
			this.cBBrowserForm.SelectedIndexChanged += this.settingsChanged;
			this.cBBrowserForm.MouseClick += this.cBBrowserForm_MouseClick;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.lbBrowserForm);
			base.Controls.Add(this.cBBrowserForm);
			base.Controls.Add(this.lbHandStartForm);
			base.Controls.Add(this.cBHandStartForm);
			base.Controls.Add(this.lbMaintenanceForm);
			base.Controls.Add(this.cBMaintenance);
			base.Controls.Add(this.lbFourLevelEditForm);
			base.Controls.Add(this.cBFourLevelEditForm);
			base.Controls.Add(this.cBTestMotorSensorForm);
			base.Controls.Add(this.cBVisualisationParamForm);
			base.Controls.Add(this.lbCheckParamForm);
			base.Controls.Add(this.cBPrgOptParameterForm);
			base.Controls.Add(this.lbProgramOverviewForm);
			base.Controls.Add(this.pnMenu);
			base.Controls.Add(this.lbBackupForm);
			base.Controls.Add(this.lbCycleCounterForm);
			base.Controls.Add(this.lbEditSteps);
			base.Controls.Add(this.lbPrgOptParameterForm);
			base.Controls.Add(this.lbVisualisationParamForm);
			base.Controls.Add(this.lbTestMotorSensorForm);
			base.Controls.Add(this.lbTestIOForm);
			base.Controls.Add(this.lbSystemConstantsForm);
			base.Controls.Add(this.lbStepOverviewForm);
			base.Controls.Add(this.lbStatisticsLastResForm);
			base.Controls.Add(this.lbSpindleConstantsForm);
			base.Controls.Add(this.cBBackupForm);
			base.Controls.Add(this.cBCycleCounterForm);
			base.Controls.Add(this.cBEditSteps);
			base.Controls.Add(this.cBTestIOForm);
			base.Controls.Add(this.cBSystemConstantsForm);
			base.Controls.Add(this.cBStepOverviewForm);
			base.Controls.Add(this.cBStatisticsLastResForm);
			base.Controls.Add(this.cBSpindleConstantsForm);
			base.Controls.Add(this.cBProgramOverviewForm);
			base.Controls.Add(this.cBCheckParamForm);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "LevelAssignmentForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen";
			base.Activated += this.MenuParameterForm_Activated;
			this.pnMenu.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public void ShowWindow()
		{
			this.SetLanguageTexts();
			this.MenEna();
			this.LoadWSP_ValuesToSettings(true);
			base.Show();
		}

		public void SetLanguageTexts()
		{
			this.bInitialize = true;
			this.openFileDialog.Filter = this.Main.Rm.GetString("MLevelAssignment") + "|*.wlxml|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.saveFileDialog.Filter = this.Main.Rm.GetString("MLevelAssignment") + "|*.wlxml|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MSystemConstants") + "/" + this.Main.Rm.GetString("MLevelAssignment");
			this.btStore.Text = this.Main.Rm.GetString("StoreAndBack");
			this.btStoreLevel.Text = this.Main.Rm.GetString("SaveToFile");
			this.btLoadLevel.Text = this.Main.Rm.GetString("LoadFromFile");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btBack.Text = this.Main.Rm.GetString("btCancel");
			this.lbBackupForm.Text = this.Main.Backup1.Text;
			this.lbBrowserForm.Text = this.Main.Browser1.Text;
			this.lbCheckParamForm.Text = this.Main.CheckParam1.Text;
			this.lbCycleCounterForm.Text = this.Main.CycleCounter1.Text;
			this.lbEditSteps.Text = this.Main.EditDrivingStep1.Text;
			this.lbHandStartForm.Text = this.Main.HandStart1.Text;
			this.lbFourLevelEditForm.Text = this.Main.FourStepEdit1.Text;
			this.lbMaintenanceForm.Text = this.Main.MenuMaintenance1.Text;
			this.lbPrgOptParameterForm.Text = this.Main.PrgOptParameter1.Text;
			this.lbProgramOverviewForm.Text = this.Main.ProgramOverview1.Text;
			this.lbSpindleConstantsForm.Text = this.Main.SpindleConstants1.Text;
			this.lbStatisticsLastResForm.Text = this.Main.StatisticsLastRes1.Text;
			this.lbStepOverviewForm.Text = this.Main.StepOverview1.Text;
			this.lbSystemConstantsForm.Text = this.Main.SystemConstants1.Text;
			this.lbTestIOForm.Text = this.Main.TestIO1.Text;
			this.lbTestMotorSensorForm.Text = this.Main.TestMotorSensor1.Text;
			this.lbVisualisationParamForm.Text = this.Main.VisualisationParam1.Text;
			this.initComboBoxes();
			this.bInitialize = false;
		}

		private void MenEna()
		{
			if (!this.Main.IsOfflineVersion && !this.Main.IsOnlineMode)
			{
				this.Main.ProcessProgram.InitializeTempProgStruct();
			}
			if (this.Main.PassCodeLevel >= 4)
			{
				this.btStore.Enabled = true;
				this.btStoreLevel.Enabled = true;
				this.btLoadLevel.Enabled = true;
				this.cBBackupForm.Enabled = true;
				this.cBBrowserForm.Enabled = true;
				this.cBCheckParamForm.Enabled = true;
				this.cBCycleCounterForm.Enabled = true;
				this.cBEditSteps.Enabled = true;
				this.cBHandStartForm.Enabled = true;
				this.cBMaintenance.Enabled = true;
				this.cBPrgOptParameterForm.Enabled = true;
				this.cBProgramOverviewForm.Enabled = true;
				this.cBFourLevelEditForm.Enabled = true;
				this.cBSpindleConstantsForm.Enabled = true;
				this.cBStatisticsLastResForm.Enabled = true;
				this.cBStepOverviewForm.Enabled = true;
				this.cBSystemConstantsForm.Enabled = true;
				this.cBTestIOForm.Enabled = true;
				this.cBTestMotorSensorForm.Enabled = true;
				this.cBVisualisationParamForm.Enabled = true;
			}
			else
			{
				this.btStore.Enabled = false;
				this.btStoreLevel.Enabled = false;
				this.btLoadLevel.Enabled = false;
				this.cBBackupForm.Enabled = false;
				this.cBBrowserForm.Enabled = false;
				this.cBCheckParamForm.Enabled = false;
				this.cBCycleCounterForm.Enabled = false;
				this.cBEditSteps.Enabled = false;
				this.cBHandStartForm.Enabled = false;
				this.cBMaintenance.Enabled = false;
				this.cBPrgOptParameterForm.Enabled = false;
				this.cBProgramOverviewForm.Enabled = false;
				this.cBFourLevelEditForm.Enabled = false;
				this.cBSpindleConstantsForm.Enabled = false;
				this.cBStatisticsLastResForm.Enabled = false;
				this.cBStepOverviewForm.Enabled = false;
				this.cBSystemConstantsForm.Enabled = false;
				this.cBTestIOForm.Enabled = false;
				this.cBTestMotorSensorForm.Enabled = false;
				this.cBVisualisationParamForm.Enabled = false;
			}
			this.lbBrowserForm.Enabled = Settings.Default.IntegratedMachineVisu;
			this.cBBrowserForm.Enabled = Settings.Default.IntegratedMachineVisu;
		}

		private void initComboBoxes()
		{
			this.initComboBox(this.cBBackupForm, Settings.Default.UserLevel_BackupForm);
			this.initComboBox(this.cBBrowserForm, Settings.Default.UserLevel_BrowserForm);
			this.initComboBox(this.cBCycleCounterForm, Settings.Default.UserLevel_CycleCounterForm);
			this.initComboBox(this.cBEditSteps, Settings.Default.UserLevel_EditSteps);
			this.initComboBox(this.cBHandStartForm, Settings.Default.UserLevel_HandStartForm);
			this.initComboBox(this.cBPrgOptParameterForm, Settings.Default.UserLevel_PrgOptParameterForm);
			this.initComboBox(this.cBMaintenance, Settings.Default.UserLevel_Maintenance);
			this.initComboBox(this.cBProgramOverviewForm, Settings.Default.UserLevel_ProgramOverviewForm);
			this.initComboBox(this.cBFourLevelEditForm, Settings.Default.UserLevel_FourStepEditForm);
			this.initComboBox(this.cBSpindleConstantsForm, Settings.Default.UserLevel_SpindleConstantsForm);
			this.initComboBox(this.cBStatisticsLastResForm, Settings.Default.UserLevel_StatisticsLastResForm);
			this.initComboBox(this.cBStepOverviewForm, Settings.Default.UserLevel_StepOverviewForm);
			this.initComboBox(this.cBSystemConstantsForm, Settings.Default.UserLevel_SystemConstantsForm);
			this.initComboBox(this.cBTestIOForm, Settings.Default.UserLevel_TestIOForm);
			this.initComboBox(this.cBTestMotorSensorForm, Settings.Default.UserLevel_TestMotorSensorForm);
			this.initComboBox(this.cBVisualisationParamForm, Settings.Default.UserLevel_VisualisationParamForm);
			this.initComboBox(this.cBCheckParamForm, Settings.Default.UserLevel_CheckParamForm);
		}

		private void initComboBox(ComboBox cB, int level)
		{
			cB.Items.Clear();
			if (cB == this.cBBrowserForm)
			{
				cB.Items.Add(this.Main.Rm.GetString("FreeAccess"));
			}
			for (int i = 0; i < 4; i++)
			{
				string accessLevelDefinition = this.Main.C_global.GetAccessLevelDefinition(i);
				if (accessLevelDefinition == null)
				{
					break;
				}
				cB.Items.Add(this.Main.Rm.GetString(accessLevelDefinition));
			}
			if (cB.Items.Count >= level && cB.Items.Count != 0)
			{
				if (cB == this.cBBrowserForm)
				{
					cB.SelectedIndex = level;
				}
				else
				{
					cB.SelectedIndex = level - 1;
				}
			}
		}

		private void applyValues()
		{
			Settings.Default.UserLevel_BackupForm = this.cBBackupForm.SelectedIndex + 1;
			Settings.Default.UserLevel_BrowserForm = this.cBBrowserForm.SelectedIndex;
			Settings.Default.UserLevel_CycleCounterForm = this.cBCycleCounterForm.SelectedIndex + 1;
			Settings.Default.UserLevel_EditSteps = this.cBEditSteps.SelectedIndex + 1;
			Settings.Default.UserLevel_HandStartForm = this.cBHandStartForm.SelectedIndex + 1;
			Settings.Default.UserLevel_Maintenance = this.cBMaintenance.SelectedIndex + 1;
			Settings.Default.UserLevel_PrgOptParameterForm = this.cBPrgOptParameterForm.SelectedIndex + 1;
			Settings.Default.UserLevel_ProgramOverviewForm = this.cBProgramOverviewForm.SelectedIndex + 1;
			Settings.Default.UserLevel_FourStepEditForm = this.cBFourLevelEditForm.SelectedIndex + 1;
			Settings.Default.UserLevel_SpindleConstantsForm = this.cBSpindleConstantsForm.SelectedIndex + 1;
			Settings.Default.UserLevel_StatisticsLastResForm = this.cBStatisticsLastResForm.SelectedIndex + 1;
			Settings.Default.UserLevel_StepOverviewForm = this.cBStepOverviewForm.SelectedIndex + 1;
			Settings.Default.UserLevel_SystemConstantsForm = this.cBSystemConstantsForm.SelectedIndex + 1;
			Settings.Default.UserLevel_TestIOForm = this.cBTestIOForm.SelectedIndex + 1;
			Settings.Default.UserLevel_TestMotorSensorForm = this.cBTestMotorSensorForm.SelectedIndex + 1;
			Settings.Default.UserLevel_VisualisationParamForm = this.cBVisualisationParamForm.SelectedIndex + 1;
			Settings.Default.UserLevel_CheckParamForm = this.cBCheckParamForm.SelectedIndex + 1;
			Settings.Default.Save();
			this.applyValuesToWSP();
		}

		public void LoadWSP_ValuesToSettings(bool readVarComm)
		{
			if (this.Main.IsOnlineMode)
			{
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadSystemConst"));
				if (readVarComm && !this.Main.VC.ReceiveVarBlock(12))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not receive SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					Settings.Default.UserLevel_BackupForm = this.Main.VC.SysConst.UserLevels.UserLevel_BackupForm;
					Settings.Default.UserLevel_BrowserForm = this.Main.VC.SysConst.UserLevels.UserLevel_BrowserForm;
					Settings.Default.UserLevel_CycleCounterForm = this.Main.VC.SysConst.UserLevels.UserLevel_CycleCounterForm;
					Settings.Default.UserLevel_EditSteps = this.Main.VC.SysConst.UserLevels.UserLevel_EditSteps;
					Settings.Default.UserLevel_HandStartForm = this.Main.VC.SysConst.UserLevels.UserLevel_HandStartForm;
					Settings.Default.UserLevel_Maintenance = this.Main.VC.SysConst.UserLevels.UserLevel_Maintenance;
					Settings.Default.UserLevel_PrgOptParameterForm = this.Main.VC.SysConst.UserLevels.UserLevel_PrgOptParameterForm;
					Settings.Default.UserLevel_ProgramOverviewForm = this.Main.VC.SysConst.UserLevels.UserLevel_ProgramOverviewForm;
					Settings.Default.UserLevel_FourStepEditForm = this.Main.VC.SysConst.UserLevels.UserLevel_FourStepEditForm;
					Settings.Default.UserLevel_SpindleConstantsForm = this.Main.VC.SysConst.UserLevels.UserLevel_SpindleConstantsForm;
					Settings.Default.UserLevel_StatisticsLastResForm = this.Main.VC.SysConst.UserLevels.UserLevel_StatisticsLastResForm;
					Settings.Default.UserLevel_StepOverviewForm = this.Main.VC.SysConst.UserLevels.UserLevel_StepOverviewForm;
					Settings.Default.UserLevel_SystemConstantsForm = this.Main.VC.SysConst.UserLevels.UserLevel_SystemConstantsForm;
					Settings.Default.UserLevel_TestIOForm = this.Main.VC.SysConst.UserLevels.UserLevel_TestIOForm;
					Settings.Default.UserLevel_TestMotorSensorForm = this.Main.VC.SysConst.UserLevels.UserLevel_TestMotorSensorForm;
					Settings.Default.UserLevel_VisualisationParamForm = this.Main.VC.SysConst.UserLevels.UserLevel_VisualisationParamForm;
					Settings.Default.UserLevel_CheckParamForm = this.Main.VC.SysConst.UserLevels.UserLevel_CheckParamForm;
					if (Settings.Default.UserLevel_BackupForm == 0)
					{
						Settings.Default.UserLevel_BackupForm = 3;
					}
					if (Settings.Default.UserLevel_CycleCounterForm == 0)
					{
						Settings.Default.UserLevel_CycleCounterForm = 3;
					}
					if (Settings.Default.UserLevel_EditSteps == 0)
					{
						Settings.Default.UserLevel_EditSteps = 2;
					}
					if (Settings.Default.UserLevel_HandStartForm == 0)
					{
						Settings.Default.UserLevel_HandStartForm = 3;
					}
					if (Settings.Default.UserLevel_Maintenance == 0)
					{
						Settings.Default.UserLevel_Maintenance = 3;
					}
					if (Settings.Default.UserLevel_PrgOptParameterForm == 0)
					{
						Settings.Default.UserLevel_PrgOptParameterForm = 3;
					}
					if (Settings.Default.UserLevel_ProgramOverviewForm == 0)
					{
						Settings.Default.UserLevel_ProgramOverviewForm = 2;
					}
					if (Settings.Default.UserLevel_FourStepEditForm == 0)
					{
						Settings.Default.UserLevel_FourStepEditForm = 3;
					}
					if (Settings.Default.UserLevel_SpindleConstantsForm == 0)
					{
						Settings.Default.UserLevel_SpindleConstantsForm = 3;
					}
					if (Settings.Default.UserLevel_StatisticsLastResForm == 0)
					{
						Settings.Default.UserLevel_StatisticsLastResForm = 1;
					}
					if (Settings.Default.UserLevel_StepOverviewForm == 0)
					{
						Settings.Default.UserLevel_StepOverviewForm = 2;
					}
					if (Settings.Default.UserLevel_SystemConstantsForm == 0)
					{
						Settings.Default.UserLevel_SystemConstantsForm = 3;
					}
					if (Settings.Default.UserLevel_TestIOForm == 0)
					{
						Settings.Default.UserLevel_TestIOForm = 4;
					}
					if (Settings.Default.UserLevel_TestMotorSensorForm == 0)
					{
						Settings.Default.UserLevel_TestMotorSensorForm = 2;
					}
					if (Settings.Default.UserLevel_VisualisationParamForm == 0)
					{
						Settings.Default.UserLevel_VisualisationParamForm = 3;
					}
					if (Settings.Default.UserLevel_CheckParamForm == 0)
					{
						Settings.Default.UserLevel_CheckParamForm = 2;
					}
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
				}
			}
		}

		public void ApplyValuesToWSP()
		{
			this.applyValuesToWSP();
		}

		private void applyValuesToWSP()
		{
			bool flag = false;
			if (this.Main.VC.SysConst.UserLevels.UserLevel_BackupForm != (byte)Settings.Default.UserLevel_BackupForm || this.Main.VC.SysConst.UserLevels.UserLevel_BrowserForm != (byte)Settings.Default.UserLevel_BrowserForm || this.Main.VC.SysConst.UserLevels.UserLevel_CycleCounterForm != (byte)Settings.Default.UserLevel_CycleCounterForm || this.Main.VC.SysConst.UserLevels.UserLevel_EditSteps != (byte)Settings.Default.UserLevel_EditSteps || this.Main.VC.SysConst.UserLevels.UserLevel_HandStartForm != (byte)Settings.Default.UserLevel_HandStartForm || this.Main.VC.SysConst.UserLevels.UserLevel_Maintenance != (byte)Settings.Default.UserLevel_Maintenance || this.Main.VC.SysConst.UserLevels.UserLevel_PrgOptParameterForm != (byte)Settings.Default.UserLevel_PrgOptParameterForm || this.Main.VC.SysConst.UserLevels.UserLevel_ProgramOverviewForm != (byte)Settings.Default.UserLevel_ProgramOverviewForm || this.Main.VC.SysConst.UserLevels.UserLevel_FourStepEditForm != (byte)Settings.Default.UserLevel_FourStepEditForm || this.Main.VC.SysConst.UserLevels.UserLevel_SpindleConstantsForm != (byte)Settings.Default.UserLevel_SpindleConstantsForm || this.Main.VC.SysConst.UserLevels.UserLevel_StatisticsLastResForm != (byte)Settings.Default.UserLevel_StatisticsLastResForm || this.Main.VC.SysConst.UserLevels.UserLevel_StepOverviewForm != (byte)Settings.Default.UserLevel_StepOverviewForm || this.Main.VC.SysConst.UserLevels.UserLevel_SystemConstantsForm != (byte)Settings.Default.UserLevel_SystemConstantsForm || this.Main.VC.SysConst.UserLevels.UserLevel_TestIOForm != (byte)Settings.Default.UserLevel_TestIOForm || this.Main.VC.SysConst.UserLevels.UserLevel_TestMotorSensorForm != (byte)Settings.Default.UserLevel_TestMotorSensorForm || this.Main.VC.SysConst.UserLevels.UserLevel_VisualisationParamForm != (byte)Settings.Default.UserLevel_VisualisationParamForm || this.Main.VC.SysConst.UserLevels.UserLevel_CheckParamForm != (byte)Settings.Default.UserLevel_CheckParamForm)
			{
				flag = true;
			}
			this.Main.VC.SysConst.UserLevels.UserLevel_BackupForm = (byte)Settings.Default.UserLevel_BackupForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_BrowserForm = (byte)Settings.Default.UserLevel_BrowserForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_CycleCounterForm = (byte)Settings.Default.UserLevel_CycleCounterForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_EditSteps = (byte)Settings.Default.UserLevel_EditSteps;
			this.Main.VC.SysConst.UserLevels.UserLevel_HandStartForm = (byte)Settings.Default.UserLevel_HandStartForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_Maintenance = (byte)Settings.Default.UserLevel_Maintenance;
			this.Main.VC.SysConst.UserLevels.UserLevel_PrgOptParameterForm = (byte)Settings.Default.UserLevel_PrgOptParameterForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_ProgramOverviewForm = (byte)Settings.Default.UserLevel_ProgramOverviewForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_FourStepEditForm = (byte)Settings.Default.UserLevel_FourStepEditForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_SpindleConstantsForm = (byte)Settings.Default.UserLevel_SpindleConstantsForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_StatisticsLastResForm = (byte)Settings.Default.UserLevel_StatisticsLastResForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_StepOverviewForm = (byte)Settings.Default.UserLevel_StepOverviewForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_SystemConstantsForm = (byte)Settings.Default.UserLevel_SystemConstantsForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_TestIOForm = (byte)Settings.Default.UserLevel_TestIOForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_TestMotorSensorForm = (byte)Settings.Default.UserLevel_TestMotorSensorForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_VisualisationParamForm = (byte)Settings.Default.UserLevel_VisualisationParamForm;
			this.Main.VC.SysConst.UserLevels.UserLevel_CheckParamForm = (byte)Settings.Default.UserLevel_CheckParamForm;
			if (flag)
			{
				this.Main.MakeLogbookEntry(202050u, 3, 0f, 0f, 0u, 0, byte.MaxValue);
				this.Main.StatusBarText(this.Main.Rm.GetString("SendPasscodes"));
				Cursor.Current = Cursors.WaitCursor;
				if (!this.Main.VC.SendVarBlock(12))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show("Could not send SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					this.pnMenu.Enabled = true;
					this.pnMenu.Select();
				}
				else
				{
					this.Main.StatusBarText(this.Main.Rm.GetString("SavePasscodesOnCPU"));
					if (!this.Main.SaveOnController(1, false))
					{
						this.Main.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						MessageBox.Show(this.Main.Rm.GetString("MbSavePasscodeFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
						this.pnMenu.Enabled = true;
						this.pnMenu.Select();
					}
					else
					{
						this.Main.WriteLogbookData(false);
						this.Main.LoggingFinished(true);
						this.Main.StatusBarText(string.Empty);
					}
				}
			}
		}

		private void btStoreLevel_Click(object sender, EventArgs e)
		{
			this.saveFileDialog.InitialDirectory = Settings.Default.UserLevelDirectory;
			if (this.saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				if (this.saveFileDialog.InitialDirectory != Settings.Default.UserLevelDirectory)
				{
					Settings.Default.UserLevelDirectory = Path.GetDirectoryName(this.saveFileDialog.InitialDirectory);
					Settings.Default.Save();
				}
				LevelAssignmentClass levelAssignmentClass = new LevelAssignmentClass();
				levelAssignmentClass.UserLevel_Backup = this.cBBackupForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_BrowserForm = this.cBBrowserForm.SelectedIndex;
				levelAssignmentClass.UserLevel_CheckParam = this.cBCheckParamForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_CycleCounter = this.cBCycleCounterForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_HandStartForm = this.cBHandStartForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_EditSteps = this.cBEditSteps.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_PrgOptParameter = this.cBPrgOptParameterForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_Maintenance = this.cBMaintenance.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_ProgramOverview = this.cBProgramOverviewForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_FourStepEditForm = this.cBFourLevelEditForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_SpindleConstants = this.cBSpindleConstantsForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_StatisticsLastRes = this.cBStatisticsLastResForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_StepOverview = this.cBStepOverviewForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_SystemConstants = this.cBSystemConstantsForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_TestIO = this.cBTestIOForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_TestMotorSensor = this.cBTestMotorSensorForm.SelectedIndex + 1;
				levelAssignmentClass.UserLevel_VisualisationParam = this.cBVisualisationParamForm.SelectedIndex + 1;
				levelAssignmentClass.Write(this.saveFileDialog.FileName, levelAssignmentClass);
			}
		}

		private void btLoadLevel_Click(object sender, EventArgs e)
		{
			this.openFileDialog.InitialDirectory = Settings.Default.UserLevelDirectory;
			if (this.openFileDialog.ShowDialog() == DialogResult.OK)
			{
				if (this.openFileDialog.InitialDirectory != Settings.Default.UserLevelDirectory)
				{
					Settings.Default.UserLevelDirectory = Path.GetDirectoryName(this.openFileDialog.InitialDirectory);
					Settings.Default.Save();
				}
				this.Main.SettingsChanged();
				LevelAssignmentClass levelAssignmentClass = new LevelAssignmentClass();
				levelAssignmentClass.Read(this.openFileDialog.FileName, ref levelAssignmentClass);
				this.cBBackupForm.SelectedIndex = levelAssignmentClass.UserLevel_Backup - 1;
				this.cBBrowserForm.SelectedIndex = levelAssignmentClass.UserLevel_BrowserForm;
				this.cBCheckParamForm.SelectedIndex = levelAssignmentClass.UserLevel_CheckParam - 1;
				this.cBCycleCounterForm.SelectedIndex = levelAssignmentClass.UserLevel_CycleCounter - 1;
				this.cBEditSteps.SelectedIndex = levelAssignmentClass.UserLevel_EditSteps - 1;
				this.cBHandStartForm.SelectedIndex = levelAssignmentClass.UserLevel_HandStartForm - 1;
				this.cBMaintenance.SelectedIndex = levelAssignmentClass.UserLevel_Maintenance - 1;
				this.cBPrgOptParameterForm.SelectedIndex = levelAssignmentClass.UserLevel_PrgOptParameter - 1;
				this.cBProgramOverviewForm.SelectedIndex = levelAssignmentClass.UserLevel_ProgramOverview - 1;
				this.cBFourLevelEditForm.SelectedIndex = levelAssignmentClass.UserLevel_FourStepEditForm - 1;
				this.cBSpindleConstantsForm.SelectedIndex = levelAssignmentClass.UserLevel_SpindleConstants - 1;
				this.cBStatisticsLastResForm.SelectedIndex = levelAssignmentClass.UserLevel_StatisticsLastRes - 1;
				this.cBStepOverviewForm.SelectedIndex = levelAssignmentClass.UserLevel_StepOverview - 1;
				this.cBSystemConstantsForm.SelectedIndex = levelAssignmentClass.UserLevel_SystemConstants - 1;
				this.cBTestIOForm.SelectedIndex = levelAssignmentClass.UserLevel_TestIO - 1;
				this.cBTestMotorSensorForm.SelectedIndex = levelAssignmentClass.UserLevel_TestMotorSensor - 1;
				this.cBVisualisationParamForm.SelectedIndex = levelAssignmentClass.UserLevel_VisualisationParam - 1;
			}
		}

		private void btStore_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.applyValues();
			base.Hide();
		}

		private void btBack_Click_1(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click_1(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_3_3_PasswortLevelZuordnung";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_3_3_PasswortLevelZuordnung");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void MenuParameterForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btStore.Select();
		}

		public void KeyArrived()
		{
			if (!this.Main.IsOnlineMode)
			{
				base.Show();
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else if (this.Main.PassCodeLevel > 0)
			{
				if (this.Main.GetExclusiveBlock1())
				{
					this.Main.CheckParamAllowed = true;
					this.MenEna();
					this.LoadWSP_ValuesToSettings(true);
					this.SetLanguageTexts();
				}
				else
				{
					this.Main.CheckParamAllowed = false;
				}
			}
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.bInitialize)
			{
				this.Main.SettingsChanged();
			}
		}

		private void cBBrowserForm_MouseClick(object sender, MouseEventArgs e)
		{
		}
	}
}
