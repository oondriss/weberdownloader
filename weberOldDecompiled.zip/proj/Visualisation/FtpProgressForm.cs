using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class FtpProgressForm : Form
	{
		private IContainer components;

		private ProgressBar progressBar1;

		private System.Windows.Forms.Timer timerDownloadMonitoring;

		private System.Windows.Forms.Timer timerDownloadFilesForOneStation;

		private Label lbDownloadSettings;

		private Label lbFile;

		private MainForm Main;

		private bool downloadAll;

		private FtpDownloadThreadClass downloadThreadClass;

		private Thread VCThread;

		private Ping_Class DetectIP;

		private bool PingRequest;

		private int PingDone;

		public string DefaultDirectory = "";

		private bool downloadAborted;

		public static int DOWNLOAD_ERROR = -1;

		public static int DOWNLOAD_STARTED = 0;

		public static int FILES_STORED = -2;

		public static int DOWNLOAD_ABORED = -3;

		public int DownloadStatus;

		private bool isDownload;

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			this.progressBar1 = new ProgressBar();
			this.timerDownloadMonitoring = new System.Windows.Forms.Timer(this.components);
			this.timerDownloadFilesForOneStation = new System.Windows.Forms.Timer(this.components);
			this.lbDownloadSettings = new Label();
			this.lbFile = new Label();
			base.SuspendLayout();
			this.progressBar1.BackColor = SystemColors.GradientActiveCaption;
			this.progressBar1.Location = new Point(4, 17);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new Size(417, 22);
			this.progressBar1.Style = ProgressBarStyle.Continuous;
			this.progressBar1.TabIndex = 0;
			this.progressBar1.Click += this.progressBar1_Click;
			this.timerDownloadMonitoring.Interval = 1000;
			this.timerDownloadMonitoring.Tick += this.timerDownloadMonitoring_Tick;
			this.timerDownloadFilesForOneStation.Tick += this.timerDownloadFilesForOneStation_Tick;
			this.lbDownloadSettings.AutoSize = true;
			this.lbDownloadSettings.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.lbDownloadSettings.Location = new Point(3, -1);
			this.lbDownloadSettings.MinimumSize = new Size(183, 17);
			this.lbDownloadSettings.Name = "lbDownloadSettings";
			this.lbDownloadSettings.Size = new Size(183, 17);
			this.lbDownloadSettings.TabIndex = 1;
			this.lbDownloadSettings.Text = "Download settings in progress";
			this.lbDownloadSettings.TextAlign = ContentAlignment.TopCenter;
			this.lbFile.AutoSize = true;
			this.lbFile.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.lbFile.Location = new Point(235, -1);
			this.lbFile.MinimumSize = new Size(183, 17);
			this.lbFile.Name = "lbFile";
			this.lbFile.Size = new Size(183, 17);
			this.lbFile.TabIndex = 2;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(428, 44);
			base.ControlBox = false;
			base.Controls.Add(this.lbFile);
			base.Controls.Add(this.lbDownloadSettings);
			base.Controls.Add(this.progressBar1);
			base.Enabled = false;
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "FtpProgressForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			this.Text = "FtpProgressForm";
			base.TopMost = true;
			base.Activated += this.FtpProgressForm_Activated;
			base.Load += this.FtpProgressForm_Load;
			base.MdiChildActivate += this.FtpProgressForm_MdiChildActivate;
			base.Shown += this.FtpProgressForm_Shown;
			base.LocationChanged += this.FtpProgressForm_LocationChanged;
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public FtpProgressForm(MainForm main)
		{
			this.Main = main;
			this.downloadThreadClass = new FtpDownloadThreadClass(this.Main);
			this.DetectIP = new Ping_Class();
			this.InitializeComponent();
		}

		private void FtpProgressForm_Load(object sender, EventArgs e)
		{
		}

		private void FtpProgressForm_Shown(object sender, EventArgs e)
		{
		}

		private void FtpProgressForm_MdiChildActivate(object sender, EventArgs e)
		{
		}

		private void FtpProgressForm_Activated(object sender, EventArgs e)
		{
		}

		private void FtpProgressForm_LocationChanged(object sender, EventArgs e)
		{
			base.Location = this.Main.FtpProgressLocation;
		}

		public bool StartDownloadSettings(string filename, bool manualDownload)
		{
			this.downloadAborted = false;
			base.Location = this.Main.FtpProgressLocation;
			if (filename == null || filename.Length == 0)
			{
				this.downloadAll = true;
			}
			else
			{
				this.downloadAll = false;
			}
			if (!this.downloadThreadClass.DownloadActive)
			{
				this.lbDownloadSettings.Text = (manualDownload ? this.Main.Rm.GetString("lbSaveBackupInFile") : "Automatic backup");
				this.timerDownloadFilesForOneStation.Stop();
				if (!this.DetectIP.DoPingController())
				{
					this.DownloadStatus = FtpProgressForm.DOWNLOAD_ERROR;
					return false;
				}
				Application.DoEvents();
				this.downloadThreadClass.StartDownload(this.DefaultDirectory);
				this.isDownload = true;
				this.timerDownloadMonitoring.Start();
				base.Show();
				this.DownloadStatus = FtpProgressForm.DOWNLOAD_STARTED;
				return true;
			}
			return false;
		}

		public bool StartUploadSettings(List<string> filenames, bool manualDownload)
		{
			this.downloadAborted = false;
			base.Location = this.Main.FtpProgressLocation;
			if (filenames != null && filenames.Count != 0)
			{
				if (!this.downloadThreadClass.DownloadActive)
				{
					this.lbDownloadSettings.Text = (manualDownload ? this.Main.Rm.GetString("lbBRestoreFromFile") : "Automatic backup");
					this.timerDownloadFilesForOneStation.Stop();
					if (!this.DetectIP.DoPingController())
					{
						this.DownloadStatus = FtpProgressForm.DOWNLOAD_ERROR;
						return false;
					}
					Application.DoEvents();
					this.downloadThreadClass.StartUpload(filenames, this.DefaultDirectory);
					this.isDownload = false;
					this.timerDownloadMonitoring.Start();
					base.Show();
					this.DownloadStatus = FtpProgressForm.DOWNLOAD_STARTED;
					return true;
				}
				return false;
			}
			this.DownloadStatus = FtpProgressForm.DOWNLOAD_ERROR;
			return false;
		}

		public void ResetProgressBar()
		{
			this.progressBar1.Value = 0;
		}

		public void IncrementDownloadProgressBar()
		{
			if (this.progressBar1.Value >= this.progressBar1.Maximum)
			{
				this.progressBar1.Value = 0;
			}
			this.progressBar1.Increment(1);
			this.lbFile.Text = this.downloadThreadClass.CurrentlyProcessedFile;
		}

		public void MaxDownloadProgressBar()
		{
			this.progressBar1.Value = this.progressBar1.Maximum;
		}

		private void timerDownloadMonitoring_Tick(object sender, EventArgs e)
		{
			bool flag = false;
			if (this.downloadThreadClass.DownloadActive)
			{
				this.progressBar1.Maximum = this.downloadThreadClass.FtpRequest.NumberOfFiles;
				if (this.downloadThreadClass.ElapsedTime() > TimeSpan.FromMinutes(7.0))
				{
					this.downloadThreadClass.KillDownload();
					flag = true;
					this.ResetProgressBar();
				}
			}
			else
			{
				flag = true;
			}
			if (flag)
			{
				this.timerDownloadMonitoring.Stop();
				this.timerDownloadFilesForOneStation.Stop();
				string text = "";
				text = (this.isDownload ? this.Main.Rm.GetString("MbFilesStoredInDirectory") : this.Main.Rm.GetString("MbFilesLoadedFromDirectory"));
				text = text + "\n     " + Settings.Default.FileBackupOperationDefaultDirectory;
				if (!this.downloadAborted)
				{
					if (this.isDownload)
					{
						this.DownloadStatus = this.downloadThreadClass.NumberOfFilesDownloaded;
					}
					else
					{
						this.DownloadStatus = this.downloadThreadClass.NumberOfFilesUploaded;
					}
				}
				else
				{
					text = text + "\n\n" + this.Main.Rm.GetString("MbCanceledFileBackup");
					this.DownloadStatus = FtpProgressForm.DOWNLOAD_ABORED;
				}
				MessageBox.Show(text, this.Main.Rm.GetString("MbhHint"));
				this.progressBar1.Value = 0;
				if (!this.isDownload)
				{
					this.Main.Backup1.FtpRestoreFinished();
				}
				else
				{
					this.Main.Backup1.FtpBackupFinished();
				}
				base.Hide();
				Cursor.Current = Cursors.Default;
			}
		}

		private void timerDownloadFilesForOneStation_Tick(object sender, EventArgs e)
		{
		}

		private void progressBar1_Click(object sender, EventArgs e)
		{
		}

		private void VCThreadFunc()
		{
		}

		public void Abort()
		{
			if (this.downloadThreadClass.DownloadActive)
			{
				bool flag = false;
				if (this.Main.IsOnlineMode)
				{
					this.downloadThreadClass.Halt = true;
					if (MessageBox.Show(this.Main.Rm.GetString("MbCancelFileBackup"), "", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
					{
						flag = true;
					}
					this.downloadThreadClass.Halt = false;
				}
				else
				{
					flag = true;
				}
				if (flag)
				{
					this.downloadThreadClass.KillDownload();
					this.downloadAborted = true;
				}
			}
		}
	}
}
