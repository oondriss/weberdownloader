using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Visualisation
{
	[DebuggerNonUserCode]
	[CompilerGenerated]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	internal class LanguageText_es
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(LanguageText_es.resourceMan, null))
				{
					ResourceManager resourceManager = LanguageText_es.resourceMan = new ResourceManager("Visualisation.LanguageText_de", typeof(LanguageText_de).Assembly);
				}
				return LanguageText_es.resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return LanguageText_es.resourceCulture;
			}
			set
			{
				LanguageText_es.resourceCulture = value;
			}
		}

		internal static string Abr_Program => LanguageText_es.ResourceManager.GetString("Abr_Program", LanguageText_es.resourceCulture);

		internal static string AbrAnaDepth => LanguageText_es.ResourceManager.GetString("AbrAnaDepth", LanguageText_es.resourceCulture);

		internal static string AbrAnaSignal => LanguageText_es.ResourceManager.GetString("AbrAnaSignal", LanguageText_es.resourceCulture);

		internal static string AbrAngle => LanguageText_es.ResourceManager.GetString("AbrAngle", LanguageText_es.resourceCulture);

		internal static string AbrDelayTorque => LanguageText_es.ResourceManager.GetString("AbrDelayTorque", LanguageText_es.resourceCulture);

		internal static string AbrDepthGrad => LanguageText_es.ResourceManager.GetString("AbrDepthGrad", LanguageText_es.resourceCulture);

		internal static string AbrFilteredTorque => LanguageText_es.ResourceManager.GetString("AbrFilteredTorque", LanguageText_es.resourceCulture);

		internal static string AbrGradient => LanguageText_es.ResourceManager.GetString("AbrGradient", LanguageText_es.resourceCulture);

		internal static string AbrM360Follow => LanguageText_es.ResourceManager.GetString("AbrM360Follow", LanguageText_es.resourceCulture);

		internal static string AbrMaxTorque => LanguageText_es.ResourceManager.GetString("AbrMaxTorque", LanguageText_es.resourceCulture);

		internal static string AbrNumber => LanguageText_es.ResourceManager.GetString("AbrNumber", LanguageText_es.resourceCulture);

		internal static string AbrTime => LanguageText_es.ResourceManager.GetString("AbrTime", LanguageText_es.resourceCulture);

		internal static string AbrTorque => LanguageText_es.ResourceManager.GetString("AbrTorque", LanguageText_es.resourceCulture);

		internal static string AccessCheck => LanguageText_es.ResourceManager.GetString("AccessCheck", LanguageText_es.resourceCulture);

		internal static string AccessRequest => LanguageText_es.ResourceManager.GetString("AccessRequest", LanguageText_es.resourceCulture);

		internal static string Actualize => LanguageText_es.ResourceManager.GetString("Actualize", LanguageText_es.resourceCulture);

		internal static string AddEntry => LanguageText_es.ResourceManager.GetString("AddEntry", LanguageText_es.resourceCulture);

		internal static string AIError => LanguageText_es.ResourceManager.GetString("AIError", LanguageText_es.resourceCulture);

		internal static string All => LanguageText_es.ResourceManager.GetString("All", LanguageText_es.resourceCulture);

		internal static string AllFiles => LanguageText_es.ResourceManager.GetString("AllFiles", LanguageText_es.resourceCulture);

		internal static string AnaDepth => LanguageText_es.ResourceManager.GetString("AnaDepth", LanguageText_es.resourceCulture);

		internal static string Analysis => LanguageText_es.ResourceManager.GetString("Analysis", LanguageText_es.resourceCulture);

		internal static string AnaOutput => LanguageText_es.ResourceManager.GetString("AnaOutput", LanguageText_es.resourceCulture);

		internal static string AnaSignal => LanguageText_es.ResourceManager.GetString("AnaSignal", LanguageText_es.resourceCulture);

		internal static string AnaSigOffset => LanguageText_es.ResourceManager.GetString("AnaSigOffset", LanguageText_es.resourceCulture);

		internal static string AnaSigScale => LanguageText_es.ResourceManager.GetString("AnaSigScale", LanguageText_es.resourceCulture);

		internal static string Angle => LanguageText_es.ResourceManager.GetString("Angle", LanguageText_es.resourceCulture);

		internal static string AngleRedundantTolerance => LanguageText_es.ResourceManager.GetString("AngleRedundantTolerance", LanguageText_es.resourceCulture);

		internal static string AngleSensorInvers => LanguageText_es.ResourceManager.GetString("AngleSensorInvers", LanguageText_es.resourceCulture);

		internal static string AngleSensorScale => LanguageText_es.ResourceManager.GetString("AngleSensorScale", LanguageText_es.resourceCulture);

		internal static string AngleTorqueSensor => LanguageText_es.ResourceManager.GetString("AngleTorqueSensor", LanguageText_es.resourceCulture);

		internal static string Apply => LanguageText_es.ResourceManager.GetString("Apply", LanguageText_es.resourceCulture);

		internal static string ApplyEntry => LanguageText_es.ResourceManager.GetString("ApplyEntry", LanguageText_es.resourceCulture);

		internal static string AutoCurveAbort => LanguageText_es.ResourceManager.GetString("AutoCurveAbort", LanguageText_es.resourceCulture);

		internal static string Automatic => LanguageText_es.ResourceManager.GetString("Automatic", LanguageText_es.resourceCulture);

		internal static string AutoMode => LanguageText_es.ResourceManager.GetString("AutoMode", LanguageText_es.resourceCulture);

		internal static string AvailableValueNumber => LanguageText_es.ResourceManager.GetString("AvailableValueNumber", LanguageText_es.resourceCulture);

		internal static string Back => LanguageText_es.ResourceManager.GetString("Back", LanguageText_es.resourceCulture);

		internal static string Backup => LanguageText_es.ResourceManager.GetString("Backup", LanguageText_es.resourceCulture);

		internal static string Backup205000 => LanguageText_es.ResourceManager.GetString("Backup205000", LanguageText_es.resourceCulture);

		internal static string Backup205001 => LanguageText_es.ResourceManager.GetString("Backup205001", LanguageText_es.resourceCulture);

		internal static string Backup205002 => LanguageText_es.ResourceManager.GetString("Backup205002", LanguageText_es.resourceCulture);

		internal static string Backup205003 => LanguageText_es.ResourceManager.GetString("Backup205003", LanguageText_es.resourceCulture);

		internal static string Battery => LanguageText_es.ResourceManager.GetString("Battery", LanguageText_es.resourceCulture);

		internal static string Baudrate => LanguageText_es.ResourceManager.GetString("Baudrate", LanguageText_es.resourceCulture);

		internal static string bt0 => LanguageText_es.ResourceManager.GetString("bt0", LanguageText_es.resourceCulture);

		internal static string bt1 => LanguageText_es.ResourceManager.GetString("bt1", LanguageText_es.resourceCulture);

		internal static string bt2 => LanguageText_es.ResourceManager.GetString("bt2", LanguageText_es.resourceCulture);

		internal static string bt3 => LanguageText_es.ResourceManager.GetString("bt3", LanguageText_es.resourceCulture);

		internal static string bt4 => LanguageText_es.ResourceManager.GetString("bt4", LanguageText_es.resourceCulture);

		internal static string bt5 => LanguageText_es.ResourceManager.GetString("bt5", LanguageText_es.resourceCulture);

		internal static string bt6 => LanguageText_es.ResourceManager.GetString("bt6", LanguageText_es.resourceCulture);

		internal static string bt7 => LanguageText_es.ResourceManager.GetString("bt7", LanguageText_es.resourceCulture);

		internal static string bt8 => LanguageText_es.ResourceManager.GetString("bt8", LanguageText_es.resourceCulture);

		internal static string bt9 => LanguageText_es.ResourceManager.GetString("bt9", LanguageText_es.resourceCulture);

		internal static string btA => LanguageText_es.ResourceManager.GetString("btA", LanguageText_es.resourceCulture);

		internal static string btApply => LanguageText_es.ResourceManager.GetString("btApply", LanguageText_es.resourceCulture);

		internal static string btB => LanguageText_es.ResourceManager.GetString("btB", LanguageText_es.resourceCulture);

		internal static string btBackspace => LanguageText_es.ResourceManager.GetString("btBackspace", LanguageText_es.resourceCulture);

		internal static string btC => LanguageText_es.ResourceManager.GetString("btC", LanguageText_es.resourceCulture);

		internal static string btCancel => LanguageText_es.ResourceManager.GetString("btCancel", LanguageText_es.resourceCulture);

		internal static string btChangeDefaultDir => LanguageText_es.ResourceManager.GetString("btChangeDefaultDir", LanguageText_es.resourceCulture);

		internal static string btD => LanguageText_es.ResourceManager.GetString("btD", LanguageText_es.resourceCulture);

		internal static string btE => LanguageText_es.ResourceManager.GetString("btE", LanguageText_es.resourceCulture);

		internal static string btErase => LanguageText_es.ResourceManager.GetString("btErase", LanguageText_es.resourceCulture);

		internal static string btF => LanguageText_es.ResourceManager.GetString("btF", LanguageText_es.resourceCulture);

		internal static string btG => LanguageText_es.ResourceManager.GetString("btG", LanguageText_es.resourceCulture);

		internal static string btH => LanguageText_es.ResourceManager.GetString("btH", LanguageText_es.resourceCulture);

		internal static string btI => LanguageText_es.ResourceManager.GetString("btI", LanguageText_es.resourceCulture);

		internal static string btJ => LanguageText_es.ResourceManager.GetString("btJ", LanguageText_es.resourceCulture);

		internal static string btK => LanguageText_es.ResourceManager.GetString("btK", LanguageText_es.resourceCulture);

		internal static string btL => LanguageText_es.ResourceManager.GetString("btL", LanguageText_es.resourceCulture);

		internal static string btLoad => LanguageText_es.ResourceManager.GetString("btLoad", LanguageText_es.resourceCulture);

		internal static string btM => LanguageText_es.ResourceManager.GetString("btM", LanguageText_es.resourceCulture);

		internal static string btMinusDown => LanguageText_es.ResourceManager.GetString("btMinusDown", LanguageText_es.resourceCulture);

		internal static string btMinusUp => LanguageText_es.ResourceManager.GetString("btMinusUp", LanguageText_es.resourceCulture);

		internal static string btN => LanguageText_es.ResourceManager.GetString("btN", LanguageText_es.resourceCulture);

		internal static string btO => LanguageText_es.ResourceManager.GetString("btO", LanguageText_es.resourceCulture);

		internal static string btP => LanguageText_es.ResourceManager.GetString("btP", LanguageText_es.resourceCulture);

		internal static string btQ => LanguageText_es.ResourceManager.GetString("btQ", LanguageText_es.resourceCulture);

		internal static string btR => LanguageText_es.ResourceManager.GetString("btR", LanguageText_es.resourceCulture);

		internal static string btRes1 => LanguageText_es.ResourceManager.GetString("btRes1", LanguageText_es.resourceCulture);

		internal static string btRes2 => LanguageText_es.ResourceManager.GetString("btRes2", LanguageText_es.resourceCulture);

		internal static string btRes3 => LanguageText_es.ResourceManager.GetString("btRes3", LanguageText_es.resourceCulture);

		internal static string btS => LanguageText_es.ResourceManager.GetString("btS", LanguageText_es.resourceCulture);

		internal static string btShift => LanguageText_es.ResourceManager.GetString("btShift", LanguageText_es.resourceCulture);

		internal static string btSpace => LanguageText_es.ResourceManager.GetString("btSpace", LanguageText_es.resourceCulture);

		internal static string btT => LanguageText_es.ResourceManager.GetString("btT", LanguageText_es.resourceCulture);

		internal static string btTeach => LanguageText_es.ResourceManager.GetString("btTeach", LanguageText_es.resourceCulture);

		internal static string btU => LanguageText_es.ResourceManager.GetString("btU", LanguageText_es.resourceCulture);

		internal static string btV => LanguageText_es.ResourceManager.GetString("btV", LanguageText_es.resourceCulture);

		internal static string btW => LanguageText_es.ResourceManager.GetString("btW", LanguageText_es.resourceCulture);

		internal static string btX => LanguageText_es.ResourceManager.GetString("btX", LanguageText_es.resourceCulture);

		internal static string btY => LanguageText_es.ResourceManager.GetString("btY", LanguageText_es.resourceCulture);

		internal static string btZ => LanguageText_es.ResourceManager.GetString("btZ", LanguageText_es.resourceCulture);

		internal static string CalculateCurves => LanguageText_es.ResourceManager.GetString("CalculateCurves", LanguageText_es.resourceCulture);

		internal static string CalDisable => LanguageText_es.ResourceManager.GetString("CalDisable", LanguageText_es.resourceCulture);

		internal static string CalibrationSignal => LanguageText_es.ResourceManager.GetString("CalibrationSignal", LanguageText_es.resourceCulture);

		internal static string Cancel => LanguageText_es.ResourceManager.GetString("Cancel", LanguageText_es.resourceCulture);

		internal static string Changed => LanguageText_es.ResourceManager.GetString("Changed", LanguageText_es.resourceCulture);

		internal static string ChangeEntry => LanguageText_es.ResourceManager.GetString("ChangeEntry", LanguageText_es.resourceCulture);

		internal static string ChangesLog => LanguageText_es.ResourceManager.GetString("ChangesLog", LanguageText_es.resourceCulture);

		internal static string chBEmtyPrograms => LanguageText_es.ResourceManager.GetString("chBEmtyPrograms", LanguageText_es.resourceCulture);

		internal static string chBProgPreview => LanguageText_es.ResourceManager.GetString("chBProgPreview", LanguageText_es.resourceCulture);

		internal static string chBUseDefaultDir => LanguageText_es.ResourceManager.GetString("chBUseDefaultDir", LanguageText_es.resourceCulture);

		internal static string CheckFrictionTestStart => LanguageText_es.ResourceManager.GetString("CheckFrictionTestStart", LanguageText_es.resourceCulture);

		internal static string CheckHandStart => LanguageText_es.ResourceManager.GetString("CheckHandStart", LanguageText_es.resourceCulture);

		internal static string CheckParameter => LanguageText_es.ResourceManager.GetString("CheckParameter", LanguageText_es.resourceCulture);

		internal static string CheckRight => LanguageText_es.ResourceManager.GetString("CheckRight", LanguageText_es.resourceCulture);

		internal static string Close => LanguageText_es.ResourceManager.GetString("Close", LanguageText_es.resourceCulture);

		internal static string ControllerName => LanguageText_es.ResourceManager.GetString("ControllerName", LanguageText_es.resourceCulture);

		internal static string ControllerTime => LanguageText_es.ResourceManager.GetString("ControllerTime", LanguageText_es.resourceCulture);

		internal static string CopyProgram => LanguageText_es.ResourceManager.GetString("CopyProgram", LanguageText_es.resourceCulture);

		internal static string CountPassMax => LanguageText_es.ResourceManager.GetString("CountPassMax", LanguageText_es.resourceCulture);

		internal static string CreatedUsers => LanguageText_es.ResourceManager.GetString("CreatedUsers", LanguageText_es.resourceCulture);

		internal static string CumulStats => LanguageText_es.ResourceManager.GetString("CumulStats", LanguageText_es.resourceCulture);

		internal static string CursorsCannotSwitch => LanguageText_es.ResourceManager.GetString("CursorsCannotSwitch", LanguageText_es.resourceCulture);

		internal static string CurveDisplay => LanguageText_es.ResourceManager.GetString("CurveDisplay", LanguageText_es.resourceCulture);

		internal static string CurveLoad => LanguageText_es.ResourceManager.GetString("CurveLoad", LanguageText_es.resourceCulture);

		internal static string CurvePrint => LanguageText_es.ResourceManager.GetString("CurvePrint", LanguageText_es.resourceCulture);

		internal static string CurveResultKind => LanguageText_es.ResourceManager.GetString("CurveResultKind", LanguageText_es.resourceCulture);

		internal static string CurveResultNumber => LanguageText_es.ResourceManager.GetString("CurveResultNumber", LanguageText_es.resourceCulture);

		internal static string CurveSave => LanguageText_es.ResourceManager.GetString("CurveSave", LanguageText_es.resourceCulture);

		internal static string CurveSelection => LanguageText_es.ResourceManager.GetString("CurveSelection", LanguageText_es.resourceCulture);

		internal static string CurvesZoomedIn => LanguageText_es.ResourceManager.GetString("CurvesZoomedIn", LanguageText_es.resourceCulture);

		internal static string CurvesZoomedOut => LanguageText_es.ResourceManager.GetString("CurvesZoomedOut", LanguageText_es.resourceCulture);

		internal static string CustomCounter => LanguageText_es.ResourceManager.GetString("CustomCounter", LanguageText_es.resourceCulture);

		internal static string Cycle => LanguageText_es.ResourceManager.GetString("Cycle", LanguageText_es.resourceCulture);

		internal static string CycleCounter => LanguageText_es.ResourceManager.GetString("CycleCounter", LanguageText_es.resourceCulture);

		internal static string CycleNumber => LanguageText_es.ResourceManager.GetString("CycleNumber", LanguageText_es.resourceCulture);

		internal static string CycleSave => LanguageText_es.ResourceManager.GetString("CycleSave", LanguageText_es.resourceCulture);

		internal static string Czech => LanguageText_es.ResourceManager.GetString("Czech", LanguageText_es.resourceCulture);

		internal static string DateTime => LanguageText_es.ResourceManager.GetString("DateTime", LanguageText_es.resourceCulture);

		internal static string DeblockController => LanguageText_es.ResourceManager.GetString("DeblockController", LanguageText_es.resourceCulture);

		internal static string DeclForSpSave => LanguageText_es.ResourceManager.GetString("DeclForSpSave", LanguageText_es.resourceCulture);

		internal static string Degree => LanguageText_es.ResourceManager.GetString("Degree", LanguageText_es.resourceCulture);

		internal static string DelayTorque => LanguageText_es.ResourceManager.GetString("DelayTorque", LanguageText_es.resourceCulture);

		internal static string DeleteCounter => LanguageText_es.ResourceManager.GetString("DeleteCounter", LanguageText_es.resourceCulture);

		internal static string DeleteCustomCounter => LanguageText_es.ResourceManager.GetString("DeleteCustomCounter", LanguageText_es.resourceCulture);

		internal static string DeleteEntry => LanguageText_es.ResourceManager.GetString("DeleteEntry", LanguageText_es.resourceCulture);

		internal static string DeleteJob => LanguageText_es.ResourceManager.GetString("DeleteJob", LanguageText_es.resourceCulture);

		internal static string DeleteLastResults => LanguageText_es.ResourceManager.GetString("DeleteLastResults", LanguageText_es.resourceCulture);

		internal static string DeleteProgram => LanguageText_es.ResourceManager.GetString("DeleteProgram", LanguageText_es.resourceCulture);

		internal static string DeleteRecursiveStat => LanguageText_es.ResourceManager.GetString("DeleteRecursiveStat", LanguageText_es.resourceCulture);

		internal static string DeleteStep => LanguageText_es.ResourceManager.GetString("DeleteStep", LanguageText_es.resourceCulture);

		internal static string DeleteValues => LanguageText_es.ResourceManager.GetString("DeleteValues", LanguageText_es.resourceCulture);

		internal static string DepthFilterTime => LanguageText_es.ResourceManager.GetString("DepthFilterTime", LanguageText_es.resourceCulture);

		internal static string DepthGrad => LanguageText_es.ResourceManager.GetString("DepthGrad", LanguageText_es.resourceCulture);

		internal static string DepthGradLength => LanguageText_es.ResourceManager.GetString("DepthGradLength", LanguageText_es.resourceCulture);

		internal static string DepthSensor => LanguageText_es.ResourceManager.GetString("DepthSensor", LanguageText_es.resourceCulture);

		internal static string DepthSensorInvers => LanguageText_es.ResourceManager.GetString("DepthSensorInvers", LanguageText_es.resourceCulture);

		internal static string DGAddress => LanguageText_es.ResourceManager.GetString("DGAddress", LanguageText_es.resourceCulture);

		internal static string DHCP => LanguageText_es.ResourceManager.GetString("DHCP", LanguageText_es.resourceCulture);

		internal static string DigitalSignal => LanguageText_es.ResourceManager.GetString("DigitalSignal", LanguageText_es.resourceCulture);

		internal static string DigitOut => LanguageText_es.ResourceManager.GetString("DigitOut", LanguageText_es.resourceCulture);

		internal static string DigSigAtEnd => LanguageText_es.ResourceManager.GetString("DigSigAtEnd", LanguageText_es.resourceCulture);

		internal static string DigSigRunning => LanguageText_es.ResourceManager.GetString("DigSigRunning", LanguageText_es.resourceCulture);

		internal static string DiscardChanges => LanguageText_es.ResourceManager.GetString("DiscardChanges", LanguageText_es.resourceCulture);

		internal static string Done => LanguageText_es.ResourceManager.GetString("Done", LanguageText_es.resourceCulture);

		internal static string DriveUnit => LanguageText_es.ResourceManager.GetString("DriveUnit", LanguageText_es.resourceCulture);

		internal static string DriveUnitInvers => LanguageText_es.ResourceManager.GetString("DriveUnitInvers", LanguageText_es.resourceCulture);

		internal static string Driving => LanguageText_es.ResourceManager.GetString("Driving", LanguageText_es.resourceCulture);

		internal static string DrivingStep => LanguageText_es.ResourceManager.GetString("DrivingStep", LanguageText_es.resourceCulture);

		internal static string EditCancel => LanguageText_es.ResourceManager.GetString("EditCancel", LanguageText_es.resourceCulture);

		internal static string EditEntry => LanguageText_es.ResourceManager.GetString("EditEntry", LanguageText_es.resourceCulture);

		internal static string EditProgram => LanguageText_es.ResourceManager.GetString("EditProgram", LanguageText_es.resourceCulture);

		internal static string EditStep => LanguageText_es.ResourceManager.GetString("EditStep", LanguageText_es.resourceCulture);

		internal static string EMGMode => LanguageText_es.ResourceManager.GetString("EMGMode", LanguageText_es.resourceCulture);

		internal static string Empty => LanguageText_es.ResourceManager.GetString("Empty", LanguageText_es.resourceCulture);

		internal static string EmptyString => LanguageText_es.ResourceManager.GetString("EmptyString", LanguageText_es.resourceCulture);

		internal static string EncError => LanguageText_es.ResourceManager.GetString("EncError", LanguageText_es.resourceCulture);

		internal static string English => LanguageText_es.ResourceManager.GetString("English", LanguageText_es.resourceCulture);

		internal static string Error1000 => LanguageText_es.ResourceManager.GetString("Error1000", LanguageText_es.resourceCulture);

		internal static string Error1001 => LanguageText_es.ResourceManager.GetString("Error1001", LanguageText_es.resourceCulture);

		internal static string Error1002 => LanguageText_es.ResourceManager.GetString("Error1002", LanguageText_es.resourceCulture);

		internal static string Error1003 => LanguageText_es.ResourceManager.GetString("Error1003", LanguageText_es.resourceCulture);

		internal static string Error1004 => LanguageText_es.ResourceManager.GetString("Error1004", LanguageText_es.resourceCulture);

		internal static string Error1005 => LanguageText_es.ResourceManager.GetString("Error1005", LanguageText_es.resourceCulture);

		internal static string Error1006 => LanguageText_es.ResourceManager.GetString("Error1006", LanguageText_es.resourceCulture);

		internal static string Error1007 => LanguageText_es.ResourceManager.GetString("Error1007", LanguageText_es.resourceCulture);

		internal static string Error1008 => LanguageText_es.ResourceManager.GetString("Error1008", LanguageText_es.resourceCulture);

		internal static string Error1009 => LanguageText_es.ResourceManager.GetString("Error1009", LanguageText_es.resourceCulture);

		internal static string Error1010 => LanguageText_es.ResourceManager.GetString("Error1010", LanguageText_es.resourceCulture);

		internal static string Error1011 => LanguageText_es.ResourceManager.GetString("Error1011", LanguageText_es.resourceCulture);

		internal static string Error1012 => LanguageText_es.ResourceManager.GetString("Error1012", LanguageText_es.resourceCulture);

		internal static string Error1013 => LanguageText_es.ResourceManager.GetString("Error1013", LanguageText_es.resourceCulture);

		internal static string Error1014 => LanguageText_es.ResourceManager.GetString("Error1014", LanguageText_es.resourceCulture);

		internal static string Error1015 => LanguageText_es.ResourceManager.GetString("Error1015", LanguageText_es.resourceCulture);

		internal static string Error1016 => LanguageText_es.ResourceManager.GetString("Error1016", LanguageText_es.resourceCulture);

		internal static string Error1017 => LanguageText_es.ResourceManager.GetString("Error1017", LanguageText_es.resourceCulture);

		internal static string Error1018 => LanguageText_es.ResourceManager.GetString("Error1018", LanguageText_es.resourceCulture);

		internal static string Error1019 => LanguageText_es.ResourceManager.GetString("Error1019", LanguageText_es.resourceCulture);

		internal static string Error1020 => LanguageText_es.ResourceManager.GetString("Error1020", LanguageText_es.resourceCulture);

		internal static string Error1021 => LanguageText_es.ResourceManager.GetString("Error1021", LanguageText_es.resourceCulture);

		internal static string Error1022 => LanguageText_es.ResourceManager.GetString("Error1022", LanguageText_es.resourceCulture);

		internal static string Error1023 => LanguageText_es.ResourceManager.GetString("Error1023", LanguageText_es.resourceCulture);

		internal static string Error1024 => LanguageText_es.ResourceManager.GetString("Error1024", LanguageText_es.resourceCulture);

		internal static string Error1025 => LanguageText_es.ResourceManager.GetString("Error1025", LanguageText_es.resourceCulture);

		internal static string Error1026 => LanguageText_es.ResourceManager.GetString("Error1026", LanguageText_es.resourceCulture);

		internal static string Error1027 => LanguageText_es.ResourceManager.GetString("Error1027", LanguageText_es.resourceCulture);

		internal static string Error1028 => LanguageText_es.ResourceManager.GetString("Error1028", LanguageText_es.resourceCulture);

		internal static string Error1029 => LanguageText_es.ResourceManager.GetString("Error1029", LanguageText_es.resourceCulture);

		internal static string Error1030 => LanguageText_es.ResourceManager.GetString("Error1030", LanguageText_es.resourceCulture);

		internal static string Error1031 => LanguageText_es.ResourceManager.GetString("Error1031", LanguageText_es.resourceCulture);

		internal static string Error1032 => LanguageText_es.ResourceManager.GetString("Error1032", LanguageText_es.resourceCulture);

		internal static string Error1033 => LanguageText_es.ResourceManager.GetString("Error1033", LanguageText_es.resourceCulture);

		internal static string Error1034 => LanguageText_es.ResourceManager.GetString("Error1034", LanguageText_es.resourceCulture);

		internal static string Error1035 => LanguageText_es.ResourceManager.GetString("Error1035", LanguageText_es.resourceCulture);

		internal static string Error1036 => LanguageText_es.ResourceManager.GetString("Error1036", LanguageText_es.resourceCulture);

		internal static string Error1037 => LanguageText_es.ResourceManager.GetString("Error1037", LanguageText_es.resourceCulture);

		internal static string Error1038 => LanguageText_es.ResourceManager.GetString("Error1038", LanguageText_es.resourceCulture);

		internal static string Error1100 => LanguageText_es.ResourceManager.GetString("Error1100", LanguageText_es.resourceCulture);

		internal static string Error1101 => LanguageText_es.ResourceManager.GetString("Error1101", LanguageText_es.resourceCulture);

		internal static string Error1102 => LanguageText_es.ResourceManager.GetString("Error1102", LanguageText_es.resourceCulture);

		internal static string Error1110 => LanguageText_es.ResourceManager.GetString("Error1110", LanguageText_es.resourceCulture);

		internal static string Error1111 => LanguageText_es.ResourceManager.GetString("Error1111", LanguageText_es.resourceCulture);

		internal static string Error1112 => LanguageText_es.ResourceManager.GetString("Error1112", LanguageText_es.resourceCulture);

		internal static string Error1113 => LanguageText_es.ResourceManager.GetString("Error1113", LanguageText_es.resourceCulture);

		internal static string Error1114 => LanguageText_es.ResourceManager.GetString("Error1114", LanguageText_es.resourceCulture);

		internal static string Error1140 => LanguageText_es.ResourceManager.GetString("Error1140", LanguageText_es.resourceCulture);

		internal static string Error1141 => LanguageText_es.ResourceManager.GetString("Error1141", LanguageText_es.resourceCulture);

		internal static string Error1150 => LanguageText_es.ResourceManager.GetString("Error1150", LanguageText_es.resourceCulture);

		internal static string Error1151 => LanguageText_es.ResourceManager.GetString("Error1151", LanguageText_es.resourceCulture);

		internal static string Error1152 => LanguageText_es.ResourceManager.GetString("Error1152", LanguageText_es.resourceCulture);

		internal static string Error1153 => LanguageText_es.ResourceManager.GetString("Error1153", LanguageText_es.resourceCulture);

		internal static string Error1160 => LanguageText_es.ResourceManager.GetString("Error1160", LanguageText_es.resourceCulture);

		internal static string Error1161 => LanguageText_es.ResourceManager.GetString("Error1161", LanguageText_es.resourceCulture);

		internal static string Error1162 => LanguageText_es.ResourceManager.GetString("Error1162", LanguageText_es.resourceCulture);

		internal static string Error1163 => LanguageText_es.ResourceManager.GetString("Error1163", LanguageText_es.resourceCulture);

		internal static string Error1200 => LanguageText_es.ResourceManager.GetString("Error1200", LanguageText_es.resourceCulture);

		internal static string Error1201 => LanguageText_es.ResourceManager.GetString("Error1201", LanguageText_es.resourceCulture);

		internal static string Error1202 => LanguageText_es.ResourceManager.GetString("Error1202", LanguageText_es.resourceCulture);

		internal static string Error1203 => LanguageText_es.ResourceManager.GetString("Error1203", LanguageText_es.resourceCulture);

		internal static string Error1301 => LanguageText_es.ResourceManager.GetString("Error1301", LanguageText_es.resourceCulture);

		internal static string Error1302 => LanguageText_es.ResourceManager.GetString("Error1302", LanguageText_es.resourceCulture);

		internal static string Error1303 => LanguageText_es.ResourceManager.GetString("Error1303", LanguageText_es.resourceCulture);

		internal static string Error1304 => LanguageText_es.ResourceManager.GetString("Error1304", LanguageText_es.resourceCulture);

		internal static string Error1305 => LanguageText_es.ResourceManager.GetString("Error1305", LanguageText_es.resourceCulture);

		internal static string Error1400 => LanguageText_es.ResourceManager.GetString("Error1400", LanguageText_es.resourceCulture);

		internal static string Error1401 => LanguageText_es.ResourceManager.GetString("Error1401", LanguageText_es.resourceCulture);

		internal static string Error1402 => LanguageText_es.ResourceManager.GetString("Error1402", LanguageText_es.resourceCulture);

		internal static string Error1403 => LanguageText_es.ResourceManager.GetString("Error1403", LanguageText_es.resourceCulture);

		internal static string Error1404 => LanguageText_es.ResourceManager.GetString("Error1404", LanguageText_es.resourceCulture);

		internal static string Error1405 => LanguageText_es.ResourceManager.GetString("Error1405", LanguageText_es.resourceCulture);

		internal static string Error1406 => LanguageText_es.ResourceManager.GetString("Error1406", LanguageText_es.resourceCulture);

		internal static string Error1407 => LanguageText_es.ResourceManager.GetString("Error1407", LanguageText_es.resourceCulture);

		internal static string Error1450 => LanguageText_es.ResourceManager.GetString("Error1450", LanguageText_es.resourceCulture);

		internal static string Error1451 => LanguageText_es.ResourceManager.GetString("Error1451", LanguageText_es.resourceCulture);

		internal static string Error1600 => LanguageText_es.ResourceManager.GetString("Error1600", LanguageText_es.resourceCulture);

		internal static string Error1601 => LanguageText_es.ResourceManager.GetString("Error1601", LanguageText_es.resourceCulture);

		internal static string Error1602 => LanguageText_es.ResourceManager.GetString("Error1602", LanguageText_es.resourceCulture);

		internal static string Error2000 => LanguageText_es.ResourceManager.GetString("Error2000", LanguageText_es.resourceCulture);

		internal static string Error2001 => LanguageText_es.ResourceManager.GetString("Error2001", LanguageText_es.resourceCulture);

		internal static string Error2002 => LanguageText_es.ResourceManager.GetString("Error2002", LanguageText_es.resourceCulture);

		internal static string Error2003 => LanguageText_es.ResourceManager.GetString("Error2003", LanguageText_es.resourceCulture);

		internal static string Error2004 => LanguageText_es.ResourceManager.GetString("Error2004", LanguageText_es.resourceCulture);

		internal static string Error2005 => LanguageText_es.ResourceManager.GetString("Error2005", LanguageText_es.resourceCulture);

		internal static string Error2006 => LanguageText_es.ResourceManager.GetString("Error2006", LanguageText_es.resourceCulture);

		internal static string Error2007 => LanguageText_es.ResourceManager.GetString("Error2007", LanguageText_es.resourceCulture);

		internal static string Error2008 => LanguageText_es.ResourceManager.GetString("Error2008", LanguageText_es.resourceCulture);

		internal static string Error2009 => LanguageText_es.ResourceManager.GetString("Error2009", LanguageText_es.resourceCulture);

		internal static string Error2010 => LanguageText_es.ResourceManager.GetString("Error2010", LanguageText_es.resourceCulture);

		internal static string Error2011 => LanguageText_es.ResourceManager.GetString("Error2011", LanguageText_es.resourceCulture);

		internal static string Error2012 => LanguageText_es.ResourceManager.GetString("Error2012", LanguageText_es.resourceCulture);

		internal static string Error2013 => LanguageText_es.ResourceManager.GetString("Error2013", LanguageText_es.resourceCulture);

		internal static string Error2014 => LanguageText_es.ResourceManager.GetString("Error2014", LanguageText_es.resourceCulture);

		internal static string Error2015 => LanguageText_es.ResourceManager.GetString("Error2015", LanguageText_es.resourceCulture);

		internal static string Error2016 => LanguageText_es.ResourceManager.GetString("Error2016", LanguageText_es.resourceCulture);

		internal static string Error2017 => LanguageText_es.ResourceManager.GetString("Error2017", LanguageText_es.resourceCulture);

		internal static string Error2018 => LanguageText_es.ResourceManager.GetString("Error2018", LanguageText_es.resourceCulture);

		internal static string Error2019 => LanguageText_es.ResourceManager.GetString("Error2019", LanguageText_es.resourceCulture);

		internal static string Error2020 => LanguageText_es.ResourceManager.GetString("Error2020", LanguageText_es.resourceCulture);

		internal static string Error2021 => LanguageText_es.ResourceManager.GetString("Error2021", LanguageText_es.resourceCulture);

		internal static string Error2022 => LanguageText_es.ResourceManager.GetString("Error2022", LanguageText_es.resourceCulture);

		internal static string Error2100 => LanguageText_es.ResourceManager.GetString("Error2100", LanguageText_es.resourceCulture);

		internal static string Error5000 => LanguageText_es.ResourceManager.GetString("Error5000", LanguageText_es.resourceCulture);

		internal static string ErrorCode => LanguageText_es.ResourceManager.GetString("ErrorCode", LanguageText_es.resourceCulture);

		internal static string ErrorLog => LanguageText_es.ResourceManager.GetString("ErrorLog", LanguageText_es.resourceCulture);

		internal static string ErrorMode => LanguageText_es.ResourceManager.GetString("ErrorMode", LanguageText_es.resourceCulture);

		internal static string ErrorNumber => LanguageText_es.ResourceManager.GetString("ErrorNumber", LanguageText_es.resourceCulture);

		internal static string ErrorQuitEMG => LanguageText_es.ResourceManager.GetString("ErrorQuitEMG", LanguageText_es.resourceCulture);

		internal static string EuropeanTime => LanguageText_es.ResourceManager.GetString("EuropeanTime", LanguageText_es.resourceCulture);

		internal static string Even => LanguageText_es.ResourceManager.GetString("Even", LanguageText_es.resourceCulture);

		internal static string Exit => LanguageText_es.ResourceManager.GetString("Exit", LanguageText_es.resourceCulture);

		internal static string Export => LanguageText_es.ResourceManager.GetString("Export", LanguageText_es.resourceCulture);

		internal static string ExportLastResults => LanguageText_es.ResourceManager.GetString("ExportLastResults", LanguageText_es.resourceCulture);

		internal static string ExportLogbook => LanguageText_es.ResourceManager.GetString("ExportLogbook", LanguageText_es.resourceCulture);

		internal static string FileOperation => LanguageText_es.ResourceManager.GetString("FileOperation", LanguageText_es.resourceCulture);

		internal static string FileOperationMenu => LanguageText_es.ResourceManager.GetString("FileOperationMenu", LanguageText_es.resourceCulture);

		internal static string FilteredTorque => LanguageText_es.ResourceManager.GetString("FilteredTorque", LanguageText_es.resourceCulture);

		internal static string Finalizing => LanguageText_es.ResourceManager.GetString("Finalizing", LanguageText_es.resourceCulture);

		internal static string FinalizingStep => LanguageText_es.ResourceManager.GetString("FinalizingStep", LanguageText_es.resourceCulture);

		internal static string ForceSignals => LanguageText_es.ResourceManager.GetString("ForceSignals", LanguageText_es.resourceCulture);

		internal static string French => LanguageText_es.ResourceManager.GetString("French", LanguageText_es.resourceCulture);

		internal static string FrictionSpeed => LanguageText_es.ResourceManager.GetString("FrictionSpeed", LanguageText_es.resourceCulture);

		internal static string FrictionTest => LanguageText_es.ResourceManager.GetString("FrictionTest", LanguageText_es.resourceCulture);

		internal static string FrictionTestEMG => LanguageText_es.ResourceManager.GetString("FrictionTestEMG", LanguageText_es.resourceCulture);

		internal static string FrictionTestStartup => LanguageText_es.ResourceManager.GetString("FrictionTestStartup", LanguageText_es.resourceCulture);

		internal static string FrictionTorque => LanguageText_es.ResourceManager.GetString("FrictionTorque", LanguageText_es.resourceCulture);

		internal static string FromAbove => LanguageText_es.ResourceManager.GetString("FromAbove", LanguageText_es.resourceCulture);

		internal static string FromAboveOverload => LanguageText_es.ResourceManager.GetString("FromAboveOverload", LanguageText_es.resourceCulture);

		internal static string gBAnaSignal => LanguageText_es.ResourceManager.GetString("gBAnaSignal", LanguageText_es.resourceCulture);

		internal static string gBDateTime => LanguageText_es.ResourceManager.GetString("gBDateTime", LanguageText_es.resourceCulture);

		internal static string gBError => LanguageText_es.ResourceManager.GetString("gBError", LanguageText_es.resourceCulture);

		internal static string gBIdentity => LanguageText_es.ResourceManager.GetString("gBIdentity", LanguageText_es.resourceCulture);

		internal static string gBIP => LanguageText_es.ResourceManager.GetString("gBIP", LanguageText_es.resourceCulture);

		internal static string gBLoadBackup => LanguageText_es.ResourceManager.GetString("gBLoadBackup", LanguageText_es.resourceCulture);

		internal static string gBPressure => LanguageText_es.ResourceManager.GetString("gBPressure", LanguageText_es.resourceCulture);

		internal static string gBRedundantSensor => LanguageText_es.ResourceManager.GetString("gBRedundantSensor", LanguageText_es.resourceCulture);

		internal static string gBResultDisplay => LanguageText_es.ResourceManager.GetString("gBResultDisplay", LanguageText_es.resourceCulture);

		internal static string gBRs232 => LanguageText_es.ResourceManager.GetString("gBRs232", LanguageText_es.resourceCulture);

		internal static string gBSaveBackup => LanguageText_es.ResourceManager.GetString("gBSaveBackup", LanguageText_es.resourceCulture);

		internal static string gBSpindle => LanguageText_es.ResourceManager.GetString("gBSpindle", LanguageText_es.resourceCulture);

		internal static string GearFactor => LanguageText_es.ResourceManager.GetString("GearFactor", LanguageText_es.resourceCulture);

		internal static string German => LanguageText_es.ResourceManager.GetString("German", LanguageText_es.resourceCulture);

		internal static string GetCurve => LanguageText_es.ResourceManager.GetString("GetCurve", LanguageText_es.resourceCulture);

		internal static string GetRpm => LanguageText_es.ResourceManager.GetString("GetRpm", LanguageText_es.resourceCulture);

		internal static string GoWithoutPassCode => LanguageText_es.ResourceManager.GetString("GoWithoutPassCode", LanguageText_es.resourceCulture);

		internal static string GradFilter => LanguageText_es.ResourceManager.GetString("GradFilter", LanguageText_es.resourceCulture);

		internal static string Gradient => LanguageText_es.ResourceManager.GetString("Gradient", LanguageText_es.resourceCulture);

		internal static string GradientLength => LanguageText_es.ResourceManager.GetString("GradientLength", LanguageText_es.resourceCulture);

		internal static string HandMode => LanguageText_es.ResourceManager.GetString("HandMode", LanguageText_es.resourceCulture);

		internal static string HandStart => LanguageText_es.ResourceManager.GetString("HandStart", LanguageText_es.resourceCulture);

		internal static string HandStartIsInitiated => LanguageText_es.ResourceManager.GetString("HandStartIsInitiated", LanguageText_es.resourceCulture);

		internal static string Help => LanguageText_es.ResourceManager.GetString("Help", LanguageText_es.resourceCulture);

		internal static string HexSwitch => LanguageText_es.ResourceManager.GetString("HexSwitch", LanguageText_es.resourceCulture);

		internal static string Hold => LanguageText_es.ResourceManager.GetString("Hold", LanguageText_es.resourceCulture);

		internal static string Holder => LanguageText_es.ResourceManager.GetString("Holder", LanguageText_es.resourceCulture);

		internal static string HolderPressureScale => LanguageText_es.ResourceManager.GetString("HolderPressureScale", LanguageText_es.resourceCulture);

		internal static string IdentServer => LanguageText_es.ResourceManager.GetString("IdentServer", LanguageText_es.resourceCulture);

		internal static string Increment => LanguageText_es.ResourceManager.GetString("Increment", LanguageText_es.resourceCulture);

		internal static string Inputs => LanguageText_es.ResourceManager.GetString("Inputs", LanguageText_es.resourceCulture);

		internal static string InsertProgram => LanguageText_es.ResourceManager.GetString("InsertProgram", LanguageText_es.resourceCulture);

		internal static string InsertStep => LanguageText_es.ResourceManager.GetString("InsertStep", LanguageText_es.resourceCulture);

		internal static string IntegratedTests => LanguageText_es.ResourceManager.GetString("IntegratedTests", LanguageText_es.resourceCulture);

		internal static string IONumber => LanguageText_es.ResourceManager.GetString("IONumber", LanguageText_es.resourceCulture);

		internal static string IOTest => LanguageText_es.ResourceManager.GetString("IOTest", LanguageText_es.resourceCulture);

		internal static string IPAddress => LanguageText_es.ResourceManager.GetString("IPAddress", LanguageText_es.resourceCulture);

		internal static string Italian => LanguageText_es.ResourceManager.GetString("Italian", LanguageText_es.resourceCulture);

		internal static string JumpAlwaysTo => LanguageText_es.ResourceManager.GetString("JumpAlwaysTo", LanguageText_es.resourceCulture);

		internal static string JumpNokTo => LanguageText_es.ResourceManager.GetString("JumpNokTo", LanguageText_es.resourceCulture);

		internal static string JumpOkTo => LanguageText_es.ResourceManager.GetString("JumpOkTo", LanguageText_es.resourceCulture);

		internal static string JumpTo => LanguageText_es.ResourceManager.GetString("JumpTo", LanguageText_es.resourceCulture);

		internal static string KeyPad => LanguageText_es.ResourceManager.GetString("KeyPad", LanguageText_es.resourceCulture);

		internal static string Kind => LanguageText_es.ResourceManager.GetString("Kind", LanguageText_es.resourceCulture);

		internal static string Language => LanguageText_es.ResourceManager.GetString("Language", LanguageText_es.resourceCulture);

		internal static string LastDoneStep => LanguageText_es.ResourceManager.GetString("LastDoneStep", LanguageText_es.resourceCulture);

		internal static string LastNIO => LanguageText_es.ResourceManager.GetString("LastNIO", LanguageText_es.resourceCulture);

		internal static string LastResults => LanguageText_es.ResourceManager.GetString("LastResults", LanguageText_es.resourceCulture);

		internal static string LeftAngle => LanguageText_es.ResourceManager.GetString("LeftAngle", LanguageText_es.resourceCulture);

		internal static string LevelAdministrator => LanguageText_es.ResourceManager.GetString("LevelAdministrator", LanguageText_es.resourceCulture);

		internal static string LevelProgramer => LanguageText_es.ResourceManager.GetString("LevelProgramer", LanguageText_es.resourceCulture);

		internal static string LevelUser => LanguageText_es.ResourceManager.GetString("LevelUser", LanguageText_es.resourceCulture);

		internal static string LivingMonitor => LanguageText_es.ResourceManager.GetString("LivingMonitor", LanguageText_es.resourceCulture);

		internal static string LivingSign => LanguageText_es.ResourceManager.GetString("LivingSign", LanguageText_es.resourceCulture);

		internal static string LoadCurveData => LanguageText_es.ResourceManager.GetString("LoadCurveData", LanguageText_es.resourceCulture);

		internal static string LoadCurveDataFromFile => LanguageText_es.ResourceManager.GetString("LoadCurveDataFromFile", LanguageText_es.resourceCulture);

		internal static string LoadCustBackup => LanguageText_es.ResourceManager.GetString("LoadCustBackup", LanguageText_es.resourceCulture);

		internal static string LoadCustBackupFromCF => LanguageText_es.ResourceManager.GetString("LoadCustBackupFromCF", LanguageText_es.resourceCulture);

		internal static string LoadCustBackupSecQuery => LanguageText_es.ResourceManager.GetString("LoadCustBackupSecQuery", LanguageText_es.resourceCulture);

		internal static string LoadCycleCount => LanguageText_es.ResourceManager.GetString("LoadCycleCount", LanguageText_es.resourceCulture);

		internal static string LoadFromFile => LanguageText_es.ResourceManager.GetString("LoadFromFile", LanguageText_es.resourceCulture);

		internal static string LoadIO => LanguageText_es.ResourceManager.GetString("LoadIO", LanguageText_es.resourceCulture);

		internal static string LoadLastNIOResults => LanguageText_es.ResourceManager.GetString("LoadLastNIOResults", LanguageText_es.resourceCulture);

		internal static string LoadLastResults => LanguageText_es.ResourceManager.GetString("LoadLastResults", LanguageText_es.resourceCulture);

		internal static string LoadLogBookData => LanguageText_es.ResourceManager.GetString("LoadLogBookData", LanguageText_es.resourceCulture);

		internal static string LoadPLCIO => LanguageText_es.ResourceManager.GetString("LoadPLCIO", LanguageText_es.resourceCulture);

		internal static string LoadPProgFromFile => LanguageText_es.ResourceManager.GetString("LoadPProgFromFile", LanguageText_es.resourceCulture);

		internal static string LoadProcessInfo => LanguageText_es.ResourceManager.GetString("LoadProcessInfo", LanguageText_es.resourceCulture);

		internal static string LoadProgramData => LanguageText_es.ResourceManager.GetString("LoadProgramData", LanguageText_es.resourceCulture);

		internal static string LoadProgramDataLocally => LanguageText_es.ResourceManager.GetString("LoadProgramDataLocally", LanguageText_es.resourceCulture);

		internal static string LoadRecursiveStat => LanguageText_es.ResourceManager.GetString("LoadRecursiveStat", LanguageText_es.resourceCulture);

		internal static string LoadResults => LanguageText_es.ResourceManager.GetString("LoadResults", LanguageText_es.resourceCulture);

		internal static string LoadSingleProgFromFile => LanguageText_es.ResourceManager.GetString("LoadSingleProgFromFile", LanguageText_es.resourceCulture);

		internal static string LoadSpindleConst => LanguageText_es.ResourceManager.GetString("LoadSpindleConst", LanguageText_es.resourceCulture);

		internal static string LoadSpindleDataLocally => LanguageText_es.ResourceManager.GetString("LoadSpindleDataLocally", LanguageText_es.resourceCulture);

		internal static string LoadSystemConst => LanguageText_es.ResourceManager.GetString("LoadSystemConst", LanguageText_es.resourceCulture);

		internal static string LoadWebBackupSecQuery => LanguageText_es.ResourceManager.GetString("LoadWebBackupSecQuery", LanguageText_es.resourceCulture);

		internal static string LoadWeberBackup => LanguageText_es.ResourceManager.GetString("LoadWeberBackup", LanguageText_es.resourceCulture);

		internal static string LoadWeberBackupFromCF => LanguageText_es.ResourceManager.GetString("LoadWeberBackupFromCF", LanguageText_es.resourceCulture);

		internal static string LocalTime => LanguageText_es.ResourceManager.GetString("LocalTime", LanguageText_es.resourceCulture);

		internal static string LogBook => LanguageText_es.ResourceManager.GetString("LogBook", LanguageText_es.resourceCulture);

		internal static string LogBookMessage100000 => LanguageText_es.ResourceManager.GetString("LogBookMessage100000", LanguageText_es.resourceCulture);

		internal static string LogBookMessage200000 => LanguageText_es.ResourceManager.GetString("LogBookMessage200000", LanguageText_es.resourceCulture);

		internal static string LogBookMessage300000 => LanguageText_es.ResourceManager.GetString("LogBookMessage300000", LanguageText_es.resourceCulture);

		internal static string LogBookMessage300001 => LanguageText_es.ResourceManager.GetString("LogBookMessage300001", LanguageText_es.resourceCulture);

		internal static string LogBookTable => LanguageText_es.ResourceManager.GetString("LogBookTable", LanguageText_es.resourceCulture);

		internal static string Login => LanguageText_es.ResourceManager.GetString("Login", LanguageText_es.resourceCulture);

		internal static string LowerLimit => LanguageText_es.ResourceManager.GetString("LowerLimit", LanguageText_es.resourceCulture);

		internal static string M1FilterTime => LanguageText_es.ResourceManager.GetString("M1FilterTime", LanguageText_es.resourceCulture);

		internal static string M360Follow => LanguageText_es.ResourceManager.GetString("M360Follow", LanguageText_es.resourceCulture);

		internal static string MachineCounter => LanguageText_es.ResourceManager.GetString("MachineCounter", LanguageText_es.resourceCulture);

		internal static string MachineVisu => LanguageText_es.ResourceManager.GetString("MachineVisu", LanguageText_es.resourceCulture);

		internal static string MakeNewEntry => LanguageText_es.ResourceManager.GetString("MakeNewEntry", LanguageText_es.resourceCulture);

		internal static string Max => LanguageText_es.ResourceManager.GetString("Max", LanguageText_es.resourceCulture);

		internal static string MaxFrictionTorque => LanguageText_es.ResourceManager.GetString("MaxFrictionTorque", LanguageText_es.resourceCulture);

		internal static string MaxRpm => LanguageText_es.ResourceManager.GetString("MaxRpm", LanguageText_es.resourceCulture);

		internal static string MaxSaveCurveNum => LanguageText_es.ResourceManager.GetString("MaxSaveCurveNum", LanguageText_es.resourceCulture);

		internal static string MaxScrewTime => LanguageText_es.ResourceManager.GetString("MaxScrewTime", LanguageText_es.resourceCulture);

		internal static string MaxTorque => LanguageText_es.ResourceManager.GetString("MaxTorque", LanguageText_es.resourceCulture);

		internal static string MbAccessByAnother => LanguageText_es.ResourceManager.GetString("MbAccessByAnother", LanguageText_es.resourceCulture);

		internal static string MbAccessNotPossible => LanguageText_es.ResourceManager.GetString("MbAccessNotPossible", LanguageText_es.resourceCulture);

		internal static string MbAccessRequestTwice => LanguageText_es.ResourceManager.GetString("MbAccessRequestTwice", LanguageText_es.resourceCulture);

		internal static string MBackup => LanguageText_es.ResourceManager.GetString("MBackup", LanguageText_es.resourceCulture);

		internal static string MbAddNoFrictionTest => LanguageText_es.ResourceManager.GetString("MbAddNoFrictionTest", LanguageText_es.resourceCulture);

		internal static string MbAddNoManual => LanguageText_es.ResourceManager.GetString("MbAddNoManual", LanguageText_es.resourceCulture);

		internal static string MbAddNoTest => LanguageText_es.ResourceManager.GetString("MbAddNoTest", LanguageText_es.resourceCulture);

		internal static string MbAddParamViewOnly => LanguageText_es.ResourceManager.GetString("MbAddParamViewOnly", LanguageText_es.resourceCulture);

		internal static string MbAutomaticIsActive1 => LanguageText_es.ResourceManager.GetString("MbAutomaticIsActive1", LanguageText_es.resourceCulture);

		internal static string MbAutomaticIsActive2 => LanguageText_es.ResourceManager.GetString("MbAutomaticIsActive2", LanguageText_es.resourceCulture);

		internal static string MbComandTimeOut => LanguageText_es.ResourceManager.GetString("MbComandTimeOut", LanguageText_es.resourceCulture);

		internal static string MbCreateDefaultPasscode => LanguageText_es.ResourceManager.GetString("MbCreateDefaultPasscode", LanguageText_es.resourceCulture);

		internal static string MbCurveLoadFailure => LanguageText_es.ResourceManager.GetString("MbCurveLoadFailure", LanguageText_es.resourceCulture);

		internal static string MbCurveSaveFailure => LanguageText_es.ResourceManager.GetString("MbCurveSaveFailure", LanguageText_es.resourceCulture);

		internal static string MbDeleteCounterFailure => LanguageText_es.ResourceManager.GetString("MbDeleteCounterFailure", LanguageText_es.resourceCulture);

		internal static string MbDeleteCustomCounter => LanguageText_es.ResourceManager.GetString("MbDeleteCustomCounter", LanguageText_es.resourceCulture);

		internal static string MbDeleteLastResFailure => LanguageText_es.ResourceManager.GetString("MbDeleteLastResFailure", LanguageText_es.resourceCulture);

		internal static string MbDeleteLastResults => LanguageText_es.ResourceManager.GetString("MbDeleteLastResults", LanguageText_es.resourceCulture);

		internal static string MbDeleteProg => LanguageText_es.ResourceManager.GetString("MbDeleteProg", LanguageText_es.resourceCulture);

		internal static string MbDeleteRecStatFailure => LanguageText_es.ResourceManager.GetString("MbDeleteRecStatFailure", LanguageText_es.resourceCulture);

		internal static string MbDeleteRecursiveStat => LanguageText_es.ResourceManager.GetString("MbDeleteRecursiveStat", LanguageText_es.resourceCulture);

		internal static string MbDeleteStatAfterProgChange => LanguageText_es.ResourceManager.GetString("MbDeleteStatAfterProgChange", LanguageText_es.resourceCulture);

		internal static string MbDoubleEntryCodeFound => LanguageText_es.ResourceManager.GetString("MbDoubleEntryCodeFound", LanguageText_es.resourceCulture);

		internal static string MbEmptyProgram => LanguageText_es.ResourceManager.GetString("MbEmptyProgram", LanguageText_es.resourceCulture);

		internal static string MbErrorQuitFailure => LanguageText_es.ResourceManager.GetString("MbErrorQuitFailure", LanguageText_es.resourceCulture);

		internal static string MbExit => LanguageText_es.ResourceManager.GetString("MbExit", LanguageText_es.resourceCulture);

		internal static string MbGotNoConnection => LanguageText_es.ResourceManager.GetString("MbGotNoConnection", LanguageText_es.resourceCulture);

		internal static string MbHandstartIsActive => LanguageText_es.ResourceManager.GetString("MbHandstartIsActive", LanguageText_es.resourceCulture);

		internal static string MbHandstartNotTwice => LanguageText_es.ResourceManager.GetString("MbHandstartNotTwice", LanguageText_es.resourceCulture);

		internal static string MbhError => LanguageText_es.ResourceManager.GetString("MbhError", LanguageText_es.resourceCulture);

		internal static string MbhHint => LanguageText_es.ResourceManager.GetString("MbhHint", LanguageText_es.resourceCulture);

		internal static string MbhNoAccess => LanguageText_es.ResourceManager.GetString("MbhNoAccess", LanguageText_es.resourceCulture);

		internal static string MbhSecurityQuery => LanguageText_es.ResourceManager.GetString("MbhSecurityQuery", LanguageText_es.resourceCulture);

		internal static string MbhViewOnlyMode => LanguageText_es.ResourceManager.GetString("MbhViewOnlyMode", LanguageText_es.resourceCulture);

		internal static string MbIPChange => LanguageText_es.ResourceManager.GetString("MbIPChange", LanguageText_es.resourceCulture);

		internal static string MbKeyLockActive => LanguageText_es.ResourceManager.GetString("MbKeyLockActive", LanguageText_es.resourceCulture);

		internal static string MbLoadCustBackupFailure => LanguageText_es.ResourceManager.GetString("MbLoadCustBackupFailure", LanguageText_es.resourceCulture);

		internal static string MbLoadWeberBackupFailure => LanguageText_es.ResourceManager.GetString("MbLoadWeberBackupFailure", LanguageText_es.resourceCulture);

		internal static string MbLocationError => LanguageText_es.ResourceManager.GetString("MbLocationError", LanguageText_es.resourceCulture);

		internal static string MbLogbookWriteFailure => LanguageText_es.ResourceManager.GetString("MbLogbookWriteFailure", LanguageText_es.resourceCulture);

		internal static string MbMaxPasscodeNum1 => LanguageText_es.ResourceManager.GetString("MbMaxPasscodeNum1", LanguageText_es.resourceCulture);

		internal static string MbMaxPasscodeNum2 => LanguageText_es.ResourceManager.GetString("MbMaxPasscodeNum2", LanguageText_es.resourceCulture);

		internal static string MbNoAccess => LanguageText_es.ResourceManager.GetString("MbNoAccess", LanguageText_es.resourceCulture);

		internal static string MbNoAccessCauseAuto => LanguageText_es.ResourceManager.GetString("MbNoAccessCauseAuto", LanguageText_es.resourceCulture);

		internal static string MbNoConnection => LanguageText_es.ResourceManager.GetString("MbNoConnection", LanguageText_es.resourceCulture);

		internal static string MbNoTestCauseAuto => LanguageText_es.ResourceManager.GetString("MbNoTestCauseAuto", LanguageText_es.resourceCulture);

		internal static string MbOfflineMode => LanguageText_es.ResourceManager.GetString("MbOfflineMode", LanguageText_es.resourceCulture);

		internal static string MbOldPProgLoad => LanguageText_es.ResourceManager.GetString("MbOldPProgLoad", LanguageText_es.resourceCulture);

		internal static string MbOldProgLoad => LanguageText_es.ResourceManager.GetString("MbOldProgLoad", LanguageText_es.resourceCulture);

		internal static string MbOverwriteProg => LanguageText_es.ResourceManager.GetString("MbOverwriteProg", LanguageText_es.resourceCulture);

		internal static string MbPasscodeFailure1 => LanguageText_es.ResourceManager.GetString("MbPasscodeFailure1", LanguageText_es.resourceCulture);

		internal static string MbPasscodeFailure2 => LanguageText_es.ResourceManager.GetString("MbPasscodeFailure2", LanguageText_es.resourceCulture);

		internal static string MbPasscodeFailure3 => LanguageText_es.ResourceManager.GetString("MbPasscodeFailure3", LanguageText_es.resourceCulture);

		internal static string MbPasscodeFailure4 => LanguageText_es.ResourceManager.GetString("MbPasscodeFailure4", LanguageText_es.resourceCulture);

		internal static string MbPProgCopyFailure => LanguageText_es.ResourceManager.GetString("MbPProgCopyFailure", LanguageText_es.resourceCulture);

		internal static string MbPProgLoadFromFileFailure => LanguageText_es.ResourceManager.GetString("MbPProgLoadFromFileFailure", LanguageText_es.resourceCulture);

		internal static string MbPProgSaveToFileFailure => LanguageText_es.ResourceManager.GetString("MbPProgSaveToFileFailure", LanguageText_es.resourceCulture);

		internal static string MbProgramCopyFailure => LanguageText_es.ResourceManager.GetString("MbProgramCopyFailure", LanguageText_es.resourceCulture);

		internal static string MbProgramEmptySaveAnyway => LanguageText_es.ResourceManager.GetString("MbProgramEmptySaveAnyway", LanguageText_es.resourceCulture);

		internal static string MbSaveCustBackupFailure => LanguageText_es.ResourceManager.GetString("MbSaveCustBackupFailure", LanguageText_es.resourceCulture);

		internal static string MbSaveDataLocally => LanguageText_es.ResourceManager.GetString("MbSaveDataLocally", LanguageText_es.resourceCulture);

		internal static string MbSavedProgramDataToFile => LanguageText_es.ResourceManager.GetString("MbSavedProgramDataToFile", LanguageText_es.resourceCulture);

		internal static string MbSavedSpindleDataToFile => LanguageText_es.ResourceManager.GetString("MbSavedSpindleDataToFile", LanguageText_es.resourceCulture);

		internal static string MbSaveNotVerifiedData => LanguageText_es.ResourceManager.GetString("MbSaveNotVerifiedData", LanguageText_es.resourceCulture);

		internal static string MbSavePasscodeFailure => LanguageText_es.ResourceManager.GetString("MbSavePasscodeFailure", LanguageText_es.resourceCulture);

		internal static string MbSaveProgFailure => LanguageText_es.ResourceManager.GetString("MbSaveProgFailure", LanguageText_es.resourceCulture);

		internal static string MbSaveProgOnCPUFailure => LanguageText_es.ResourceManager.GetString("MbSaveProgOnCPUFailure", LanguageText_es.resourceCulture);

		internal static string MbSaveSpConstFailure => LanguageText_es.ResourceManager.GetString("MbSaveSpConstFailure", LanguageText_es.resourceCulture);

		internal static string MbSaveSysConstFailure => LanguageText_es.ResourceManager.GetString("MbSaveSysConstFailure", LanguageText_es.resourceCulture);

		internal static string MbSaveWeberBackupFailure => LanguageText_es.ResourceManager.GetString("MbSaveWeberBackupFailure", LanguageText_es.resourceCulture);

		internal static string MbShortNameFailure1 => LanguageText_es.ResourceManager.GetString("MbShortNameFailure1", LanguageText_es.resourceCulture);

		internal static string MbShortNameFailure2 => LanguageText_es.ResourceManager.GetString("MbShortNameFailure2", LanguageText_es.resourceCulture);

		internal static string MbShortNameFailure3 => LanguageText_es.ResourceManager.GetString("MbShortNameFailure3", LanguageText_es.resourceCulture);

		internal static string MbSpindleCopyFailure => LanguageText_es.ResourceManager.GetString("MbSpindleCopyFailure", LanguageText_es.resourceCulture);

		internal static string MbSpindleLoadFromFileFailure => LanguageText_es.ResourceManager.GetString("MbSpindleLoadFromFileFailure", LanguageText_es.resourceCulture);

		internal static string MbSpindleSaveToFileFailure => LanguageText_es.ResourceManager.GetString("MbSpindleSaveToFileFailure", LanguageText_es.resourceCulture);

		internal static string MbStepCopyFailure => LanguageText_es.ResourceManager.GetString("MbStepCopyFailure", LanguageText_es.resourceCulture);

		internal static string MbWrongPassword => LanguageText_es.ResourceManager.GetString("MbWrongPassword", LanguageText_es.resourceCulture);

		internal static string MCheckParameter => LanguageText_es.ResourceManager.GetString("MCheckParameter", LanguageText_es.resourceCulture);

		internal static string MCurveDisplay => LanguageText_es.ResourceManager.GetString("MCurveDisplay", LanguageText_es.resourceCulture);

		internal static string MCurveSelection => LanguageText_es.ResourceManager.GetString("MCurveSelection", LanguageText_es.resourceCulture);

		internal static string MCycleCounter => LanguageText_es.ResourceManager.GetString("MCycleCounter", LanguageText_es.resourceCulture);

		internal static string MDelay => LanguageText_es.ResourceManager.GetString("MDelay", LanguageText_es.resourceCulture);

		internal static string Mean => LanguageText_es.ResourceManager.GetString("Mean", LanguageText_es.resourceCulture);

		internal static string MEditStep => LanguageText_es.ResourceManager.GetString("MEditStep", LanguageText_es.resourceCulture);

		internal static string MenuAnalysis => LanguageText_es.ResourceManager.GetString("MenuAnalysis", LanguageText_es.resourceCulture);

		internal static string MenuParameter => LanguageText_es.ResourceManager.GetString("MenuParameter", LanguageText_es.resourceCulture);

		internal static string MenuStatistics => LanguageText_es.ResourceManager.GetString("MenuStatistics", LanguageText_es.resourceCulture);

		internal static string MenuTest => LanguageText_es.ResourceManager.GetString("MenuTest", LanguageText_es.resourceCulture);

		internal static string Message => LanguageText_es.ResourceManager.GetString("Message", LanguageText_es.resourceCulture);

		internal static string MHandStart => LanguageText_es.ResourceManager.GetString("MHandStart", LanguageText_es.resourceCulture);

		internal static string Milimeter => LanguageText_es.ResourceManager.GetString("Milimeter", LanguageText_es.resourceCulture);

		internal static string Milisecond => LanguageText_es.ResourceManager.GetString("Milisecond", LanguageText_es.resourceCulture);

		internal static string Min => LanguageText_es.ResourceManager.GetString("Min", LanguageText_es.resourceCulture);

		internal static string MiniDisplay => LanguageText_es.ResourceManager.GetString("MiniDisplay", LanguageText_es.resourceCulture);

		internal static string Minimize => LanguageText_es.ResourceManager.GetString("Minimize", LanguageText_es.resourceCulture);

		internal static string MLastNIO => LanguageText_es.ResourceManager.GetString("MLastNIO", LanguageText_es.resourceCulture);

		internal static string MLogBook => LanguageText_es.ResourceManager.GetString("MLogBook", LanguageText_es.resourceCulture);

		internal static string MOptPrgParam => LanguageText_es.ResourceManager.GetString("MOptPrgParam", LanguageText_es.resourceCulture);

		internal static string Motor => LanguageText_es.ResourceManager.GetString("Motor", LanguageText_es.resourceCulture);

		internal static string MPasscodeManager => LanguageText_es.ResourceManager.GetString("MPasscodeManager", LanguageText_es.resourceCulture);

		internal static string MPrintSelection => LanguageText_es.ResourceManager.GetString("MPrintSelection", LanguageText_es.resourceCulture);

		internal static string MProgramOverview => LanguageText_es.ResourceManager.GetString("MProgramOverview", LanguageText_es.resourceCulture);

		internal static string MSpindleConstants => LanguageText_es.ResourceManager.GetString("MSpindleConstants", LanguageText_es.resourceCulture);

		internal static string MStepOverview => LanguageText_es.ResourceManager.GetString("MStepOverview", LanguageText_es.resourceCulture);

		internal static string MStepResults => LanguageText_es.ResourceManager.GetString("MStepResults", LanguageText_es.resourceCulture);

		internal static string MSystemConstants => LanguageText_es.ResourceManager.GetString("MSystemConstants", LanguageText_es.resourceCulture);

		internal static string MVisualisationParam => LanguageText_es.ResourceManager.GetString("MVisualisationParam", LanguageText_es.resourceCulture);

		internal static string Name => LanguageText_es.ResourceManager.GetString("Name", LanguageText_es.resourceCulture);

		internal static string Negative => LanguageText_es.ResourceManager.GetString("Negative", LanguageText_es.resourceCulture);

		internal static string NegOverload => LanguageText_es.ResourceManager.GetString("NegOverload", LanguageText_es.resourceCulture);

		internal static string NewEntry => LanguageText_es.ResourceManager.GetString("NewEntry", LanguageText_es.resourceCulture);

		internal static string NewValue => LanguageText_es.ResourceManager.GetString("NewValue", LanguageText_es.resourceCulture);

		internal static string Next50Curves => LanguageText_es.ResourceManager.GetString("Next50Curves", LanguageText_es.resourceCulture);

		internal static string NIO10 => LanguageText_es.ResourceManager.GetString("NIO10", LanguageText_es.resourceCulture);

		internal static string NIO10001 => LanguageText_es.ResourceManager.GetString("NIO10001", LanguageText_es.resourceCulture);

		internal static string NIO10002 => LanguageText_es.ResourceManager.GetString("NIO10002", LanguageText_es.resourceCulture);

		internal static string NIO10003 => LanguageText_es.ResourceManager.GetString("NIO10003", LanguageText_es.resourceCulture);

		internal static string NIO10004 => LanguageText_es.ResourceManager.GetString("NIO10004", LanguageText_es.resourceCulture);

		internal static string NIO11 => LanguageText_es.ResourceManager.GetString("NIO11", LanguageText_es.resourceCulture);

		internal static string NIO110 => LanguageText_es.ResourceManager.GetString("NIO110", LanguageText_es.resourceCulture);

		internal static string NIO12 => LanguageText_es.ResourceManager.GetString("NIO12", LanguageText_es.resourceCulture);

		internal static string NIO13 => LanguageText_es.ResourceManager.GetString("NIO13", LanguageText_es.resourceCulture);

		internal static string NIO30 => LanguageText_es.ResourceManager.GetString("NIO30", LanguageText_es.resourceCulture);

		internal static string NIO31 => LanguageText_es.ResourceManager.GetString("NIO31", LanguageText_es.resourceCulture);

		internal static string NIO40 => LanguageText_es.ResourceManager.GetString("NIO40", LanguageText_es.resourceCulture);

		internal static string NIO41 => LanguageText_es.ResourceManager.GetString("NIO41", LanguageText_es.resourceCulture);

		internal static string NIO50 => LanguageText_es.ResourceManager.GetString("NIO50", LanguageText_es.resourceCulture);

		internal static string NIO51 => LanguageText_es.ResourceManager.GetString("NIO51", LanguageText_es.resourceCulture);

		internal static string NIO60 => LanguageText_es.ResourceManager.GetString("NIO60", LanguageText_es.resourceCulture);

		internal static string NIO61 => LanguageText_es.ResourceManager.GetString("NIO61", LanguageText_es.resourceCulture);

		internal static string NIO70 => LanguageText_es.ResourceManager.GetString("NIO70", LanguageText_es.resourceCulture);

		internal static string NIO71 => LanguageText_es.ResourceManager.GetString("NIO71", LanguageText_es.resourceCulture);

		internal static string NIO75 => LanguageText_es.ResourceManager.GetString("NIO75", LanguageText_es.resourceCulture);

		internal static string NIO76 => LanguageText_es.ResourceManager.GetString("NIO76", LanguageText_es.resourceCulture);

		internal static string NIO80 => LanguageText_es.ResourceManager.GetString("NIO80", LanguageText_es.resourceCulture);

		internal static string NIO81 => LanguageText_es.ResourceManager.GetString("NIO81", LanguageText_es.resourceCulture);

		internal static string NIO90 => LanguageText_es.ResourceManager.GetString("NIO90", LanguageText_es.resourceCulture);

		internal static string NIO91 => LanguageText_es.ResourceManager.GetString("NIO91", LanguageText_es.resourceCulture);

		internal static string NIO92 => LanguageText_es.ResourceManager.GetString("NIO92", LanguageText_es.resourceCulture);

		internal static string NIO93 => LanguageText_es.ResourceManager.GetString("NIO93", LanguageText_es.resourceCulture);

		internal static string NIO94 => LanguageText_es.ResourceManager.GetString("NIO94", LanguageText_es.resourceCulture);

		internal static string NIO95 => LanguageText_es.ResourceManager.GetString("NIO95", LanguageText_es.resourceCulture);

		internal static string NIO96 => LanguageText_es.ResourceManager.GetString("NIO96", LanguageText_es.resourceCulture);

		internal static string NIO97 => LanguageText_es.ResourceManager.GetString("NIO97", LanguageText_es.resourceCulture);

		internal static string NIO98 => LanguageText_es.ResourceManager.GetString("NIO98", LanguageText_es.resourceCulture);

		internal static string NIO99 => LanguageText_es.ResourceManager.GetString("NIO99", LanguageText_es.resourceCulture);

		internal static string NIONumber => LanguageText_es.ResourceManager.GetString("NIONumber", LanguageText_es.resourceCulture);

		internal static string NIOReason => LanguageText_es.ResourceManager.GetString("NIOReason", LanguageText_es.resourceCulture);

		internal static string No => LanguageText_es.ResourceManager.GetString("No", LanguageText_es.resourceCulture);

		internal static string NoData => LanguageText_es.ResourceManager.GetString("NoData", LanguageText_es.resourceCulture);

		internal static string NoErrorMode => LanguageText_es.ResourceManager.GetString("NoErrorMode", LanguageText_es.resourceCulture);

		internal static string NOK => LanguageText_es.ResourceManager.GetString("NOK", LanguageText_es.resourceCulture);

		internal static string None => LanguageText_es.ResourceManager.GetString("None", LanguageText_es.resourceCulture);

		internal static string NoParity => LanguageText_es.ResourceManager.GetString("NoParity", LanguageText_es.resourceCulture);

		internal static string NoSelection => LanguageText_es.ResourceManager.GetString("NoSelection", LanguageText_es.resourceCulture);

		internal static string NoSignal => LanguageText_es.ResourceManager.GetString("NoSignal", LanguageText_es.resourceCulture);

		internal static string NotValid => LanguageText_es.ResourceManager.GetString("NotValid", LanguageText_es.resourceCulture);

		internal static string Number => LanguageText_es.ResourceManager.GetString("Number", LanguageText_es.resourceCulture);

		internal static string NumberPad => LanguageText_es.ResourceManager.GetString("NumberPad", LanguageText_es.resourceCulture);

		internal static string Odd => LanguageText_es.ResourceManager.GetString("Odd", LanguageText_es.resourceCulture);

		internal static string Off => LanguageText_es.ResourceManager.GetString("Off", LanguageText_es.resourceCulture);

		internal static string OfflineMode => LanguageText_es.ResourceManager.GetString("OfflineMode", LanguageText_es.resourceCulture);

		internal static string OffsetTeachValue => LanguageText_es.ResourceManager.GetString("OffsetTeachValue", LanguageText_es.resourceCulture);

		internal static string OffsetVoltageMax => LanguageText_es.ResourceManager.GetString("OffsetVoltageMax", LanguageText_es.resourceCulture);

		internal static string OffsetVoltageMin => LanguageText_es.ResourceManager.GetString("OffsetVoltageMin", LanguageText_es.resourceCulture);

		internal static string OfStep => LanguageText_es.ResourceManager.GetString("OfStep", LanguageText_es.resourceCulture);

		internal static string OK => LanguageText_es.ResourceManager.GetString("OK", LanguageText_es.resourceCulture);

		internal static string OKNOK => LanguageText_es.ResourceManager.GetString("OKNOK", LanguageText_es.resourceCulture);

		internal static string OldValue => LanguageText_es.ResourceManager.GetString("OldValue", LanguageText_es.resourceCulture);

		internal static string On => LanguageText_es.ResourceManager.GetString("On", LanguageText_es.resourceCulture);

		internal static string OnlineMode => LanguageText_es.ResourceManager.GetString("OnlineMode", LanguageText_es.resourceCulture);

		internal static string OnlyIO => LanguageText_es.ResourceManager.GetString("OnlyIO", LanguageText_es.resourceCulture);

		internal static string OptPrgParam => LanguageText_es.ResourceManager.GetString("OptPrgParam", LanguageText_es.resourceCulture);

		internal static string Organisation => LanguageText_es.ResourceManager.GetString("Organisation", LanguageText_es.resourceCulture);

		internal static string OrganizingStep => LanguageText_es.ResourceManager.GetString("OrganizingStep", LanguageText_es.resourceCulture);

		internal static string OutOfRange => LanguageText_es.ResourceManager.GetString("OutOfRange", LanguageText_es.resourceCulture);

		internal static string Outputs => LanguageText_es.ResourceManager.GetString("Outputs", LanguageText_es.resourceCulture);

		internal static string PaintCurve => LanguageText_es.ResourceManager.GetString("PaintCurve", LanguageText_es.resourceCulture);

		internal static string Parity => LanguageText_es.ResourceManager.GetString("Parity", LanguageText_es.resourceCulture);

		internal static string PasscodeLevel => LanguageText_es.ResourceManager.GetString("PasscodeLevel", LanguageText_es.resourceCulture);

		internal static string PasscodeManager => LanguageText_es.ResourceManager.GetString("PasscodeManager", LanguageText_es.resourceCulture);

		internal static string Password => LanguageText_es.ResourceManager.GetString("Password", LanguageText_es.resourceCulture);

		internal static string PasswordInput => LanguageText_es.ResourceManager.GetString("PasswordInput", LanguageText_es.resourceCulture);

		internal static string Percent => LanguageText_es.ResourceManager.GetString("Percent", LanguageText_es.resourceCulture);

		internal static string PLC_IO => LanguageText_es.ResourceManager.GetString("PLC_IO", LanguageText_es.resourceCulture);

		internal static string PointOfTime => LanguageText_es.ResourceManager.GetString("PointOfTime", LanguageText_es.resourceCulture);

		internal static string Positive => LanguageText_es.ResourceManager.GetString("Positive", LanguageText_es.resourceCulture);

		internal static string PosOverload => LanguageText_es.ResourceManager.GetString("PosOverload", LanguageText_es.resourceCulture);

		internal static string PowerEnabled => LanguageText_es.ResourceManager.GetString("PowerEnabled", LanguageText_es.resourceCulture);

		internal static string Pressure => LanguageText_es.ResourceManager.GetString("Pressure", LanguageText_es.resourceCulture);

		internal static string PressureSpindle => LanguageText_es.ResourceManager.GetString("PressureSpindle", LanguageText_es.resourceCulture);

		internal static string Print => LanguageText_es.ResourceManager.GetString("Print", LanguageText_es.resourceCulture);

		internal static string ProcessInputs => LanguageText_es.ResourceManager.GetString("ProcessInputs", LanguageText_es.resourceCulture);

		internal static string ProcessRunning => LanguageText_es.ResourceManager.GetString("ProcessRunning", LanguageText_es.resourceCulture);

		internal static string Program => LanguageText_es.ResourceManager.GetString("Program", LanguageText_es.resourceCulture);

		internal static string ProgramChange201000 => LanguageText_es.ResourceManager.GetString("ProgramChange201000", LanguageText_es.resourceCulture);

		internal static string ProgramChange201001 => LanguageText_es.ResourceManager.GetString("ProgramChange201001", LanguageText_es.resourceCulture);

		internal static string ProgramChange201002 => LanguageText_es.ResourceManager.GetString("ProgramChange201002", LanguageText_es.resourceCulture);

		internal static string ProgramChange201003 => LanguageText_es.ResourceManager.GetString("ProgramChange201003", LanguageText_es.resourceCulture);

		internal static string ProgramChange201004 => LanguageText_es.ResourceManager.GetString("ProgramChange201004", LanguageText_es.resourceCulture);

		internal static string ProgramChange201005 => LanguageText_es.ResourceManager.GetString("ProgramChange201005", LanguageText_es.resourceCulture);

		internal static string ProgramChange201006 => LanguageText_es.ResourceManager.GetString("ProgramChange201006", LanguageText_es.resourceCulture);

		internal static string ProgramChange201007 => LanguageText_es.ResourceManager.GetString("ProgramChange201007", LanguageText_es.resourceCulture);

		internal static string ProgramChange201008 => LanguageText_es.ResourceManager.GetString("ProgramChange201008", LanguageText_es.resourceCulture);

		internal static string ProgramChange201009 => LanguageText_es.ResourceManager.GetString("ProgramChange201009", LanguageText_es.resourceCulture);

		internal static string ProgramNumber => LanguageText_es.ResourceManager.GetString("ProgramNumber", LanguageText_es.resourceCulture);

		internal static string Programs => LanguageText_es.ResourceManager.GetString("Programs", LanguageText_es.resourceCulture);

		internal static string Quit => LanguageText_es.ResourceManager.GetString("Quit", LanguageText_es.resourceCulture);

		internal static string Ramp => LanguageText_es.ResourceManager.GetString("Ramp", LanguageText_es.resourceCulture);

		internal static string Range => LanguageText_es.ResourceManager.GetString("Range", LanguageText_es.resourceCulture);

		internal static string ReadyToStart => LanguageText_es.ResourceManager.GetString("ReadyToStart", LanguageText_es.resourceCulture);

		internal static string RecentDateTime => LanguageText_es.ResourceManager.GetString("RecentDateTime", LanguageText_es.resourceCulture);

		internal static string Reconnect => LanguageText_es.ResourceManager.GetString("Reconnect", LanguageText_es.resourceCulture);

		internal static string ReconnectToController => LanguageText_es.ResourceManager.GetString("ReconnectToController", LanguageText_es.resourceCulture);

		internal static string RecursiveStatMode => LanguageText_es.ResourceManager.GetString("RecursiveStatMode", LanguageText_es.resourceCulture);

		internal static string RedAngle => LanguageText_es.ResourceManager.GetString("RedAngle", LanguageText_es.resourceCulture);

		internal static string RedTorque => LanguageText_es.ResourceManager.GetString("RedTorque", LanguageText_es.resourceCulture);

		internal static string RedundantSensorActive => LanguageText_es.ResourceManager.GetString("RedundantSensorActive", LanguageText_es.resourceCulture);

		internal static string relatedTo => LanguageText_es.ResourceManager.GetString("relatedTo", LanguageText_es.resourceCulture);

		internal static string RelativeTorque => LanguageText_es.ResourceManager.GetString("RelativeTorque", LanguageText_es.resourceCulture);

		internal static string Release => LanguageText_es.ResourceManager.GetString("Release", LanguageText_es.resourceCulture);

		internal static string ReleaseSpeed => LanguageText_es.ResourceManager.GetString("ReleaseSpeed", LanguageText_es.resourceCulture);

		internal static string RelTorqueStep => LanguageText_es.ResourceManager.GetString("RelTorqueStep", LanguageText_es.resourceCulture);

		internal static string RemainedCurves => LanguageText_es.ResourceManager.GetString("RemainedCurves", LanguageText_es.resourceCulture);

		internal static string Reset => LanguageText_es.ResourceManager.GetString("Reset", LanguageText_es.resourceCulture);

		internal static string ResetADepth => LanguageText_es.ResourceManager.GetString("ResetADepth", LanguageText_es.resourceCulture);

		internal static string ResetAngle => LanguageText_es.ResourceManager.GetString("ResetAngle", LanguageText_es.resourceCulture);

		internal static string Result => LanguageText_es.ResourceManager.GetString("Result", LanguageText_es.resourceCulture);

		internal static string ResultDisplay => LanguageText_es.ResourceManager.GetString("ResultDisplay", LanguageText_es.resourceCulture);

		internal static string Results => LanguageText_es.ResourceManager.GetString("Results", LanguageText_es.resourceCulture);

		internal static string RightAngle => LanguageText_es.ResourceManager.GetString("RightAngle", LanguageText_es.resourceCulture);

		internal static string Robot => LanguageText_es.ResourceManager.GetString("Robot", LanguageText_es.resourceCulture);

		internal static string RoundsPerMinute => LanguageText_es.ResourceManager.GetString("RoundsPerMinute", LanguageText_es.resourceCulture);

		internal static string RpmTest => LanguageText_es.ResourceManager.GetString("RpmTest", LanguageText_es.resourceCulture);

		internal static string RpmUnit => LanguageText_es.ResourceManager.GetString("RpmUnit", LanguageText_es.resourceCulture);

		internal static string RS232PrintMode => LanguageText_es.ResourceManager.GetString("RS232PrintMode", LanguageText_es.resourceCulture);

		internal static string SampleSize => LanguageText_es.ResourceManager.GetString("SampleSize", LanguageText_es.resourceCulture);

		internal static string SampleStatistic => LanguageText_es.ResourceManager.GetString("SampleStatistic", LanguageText_es.resourceCulture);

		internal static string SaveCurveDataToFile => LanguageText_es.ResourceManager.GetString("SaveCurveDataToFile", LanguageText_es.resourceCulture);

		internal static string SaveCustBackup => LanguageText_es.ResourceManager.GetString("SaveCustBackup", LanguageText_es.resourceCulture);

		internal static string SaveCustBackupOnCF => LanguageText_es.ResourceManager.GetString("SaveCustBackupOnCF", LanguageText_es.resourceCulture);

		internal static string SaveCustBackupSecQuery => LanguageText_es.ResourceManager.GetString("SaveCustBackupSecQuery", LanguageText_es.resourceCulture);

		internal static string SavePasscodesOnCPU => LanguageText_es.ResourceManager.GetString("SavePasscodesOnCPU", LanguageText_es.resourceCulture);

		internal static string SavePProgToFile => LanguageText_es.ResourceManager.GetString("SavePProgToFile", LanguageText_es.resourceCulture);

		internal static string SaveProgOnCPU => LanguageText_es.ResourceManager.GetString("SaveProgOnCPU", LanguageText_es.resourceCulture);

		internal static string SaveProgramData => LanguageText_es.ResourceManager.GetString("SaveProgramData", LanguageText_es.resourceCulture);

		internal static string SaveProgramDataLocally => LanguageText_es.ResourceManager.GetString("SaveProgramDataLocally", LanguageText_es.resourceCulture);

		internal static string SaveSingleProgToFile => LanguageText_es.ResourceManager.GetString("SaveSingleProgToFile", LanguageText_es.resourceCulture);

		internal static string SaveSpindleConstOnCPU => LanguageText_es.ResourceManager.GetString("SaveSpindleConstOnCPU", LanguageText_es.resourceCulture);

		internal static string SaveSpindleDataLocally => LanguageText_es.ResourceManager.GetString("SaveSpindleDataLocally", LanguageText_es.resourceCulture);

		internal static string SaveSystemConstOnCPU => LanguageText_es.ResourceManager.GetString("SaveSystemConstOnCPU", LanguageText_es.resourceCulture);

		internal static string SaveToFile => LanguageText_es.ResourceManager.GetString("SaveToFile", LanguageText_es.resourceCulture);

		internal static string SaveVisuParam => LanguageText_es.ResourceManager.GetString("SaveVisuParam", LanguageText_es.resourceCulture);

		internal static string SaveWebBackupSecQuery => LanguageText_es.ResourceManager.GetString("SaveWebBackupSecQuery", LanguageText_es.resourceCulture);

		internal static string SaveWeberBackup => LanguageText_es.ResourceManager.GetString("SaveWeberBackup", LanguageText_es.resourceCulture);

		internal static string SaveWeberBackupOnCF => LanguageText_es.ResourceManager.GetString("SaveWeberBackupOnCF", LanguageText_es.resourceCulture);

		internal static string ScrewID => LanguageText_es.ResourceManager.GetString("ScrewID", LanguageText_es.resourceCulture);

		internal static string ScrewProgramFiles => LanguageText_es.ResourceManager.GetString("ScrewProgramFiles", LanguageText_es.resourceCulture);

		internal static string ScrewPrograms => LanguageText_es.ResourceManager.GetString("ScrewPrograms", LanguageText_es.resourceCulture);

		internal static string ScrewTime => LanguageText_es.ResourceManager.GetString("ScrewTime", LanguageText_es.resourceCulture);

		internal static string Second => LanguageText_es.ResourceManager.GetString("Second", LanguageText_es.resourceCulture);

		internal static string SelectAll => LanguageText_es.ResourceManager.GetString("SelectAll", LanguageText_es.resourceCulture);

		internal static string SelectedKind => LanguageText_es.ResourceManager.GetString("SelectedKind", LanguageText_es.resourceCulture);

		internal static string SelectedXAxis => LanguageText_es.ResourceManager.GetString("SelectedXAxis", LanguageText_es.resourceCulture);

		internal static string SelectedYAxis => LanguageText_es.ResourceManager.GetString("SelectedYAxis", LanguageText_es.resourceCulture);

		internal static string SelectNone => LanguageText_es.ResourceManager.GetString("SelectNone", LanguageText_es.resourceCulture);

		internal static string SelValidNumber => LanguageText_es.ResourceManager.GetString("SelValidNumber", LanguageText_es.resourceCulture);

		internal static string SendIO => LanguageText_es.ResourceManager.GetString("SendIO", LanguageText_es.resourceCulture);

		internal static string SendPasscodes => LanguageText_es.ResourceManager.GetString("SendPasscodes", LanguageText_es.resourceCulture);

		internal static string SendSpindleConstants => LanguageText_es.ResourceManager.GetString("SendSpindleConstants", LanguageText_es.resourceCulture);

		internal static string SendSystemConstants => LanguageText_es.ResourceManager.GetString("SendSystemConstants", LanguageText_es.resourceCulture);

		internal static string SensorTest => LanguageText_es.ResourceManager.GetString("SensorTest", LanguageText_es.resourceCulture);

		internal static string Set => LanguageText_es.ResourceManager.GetString("Set", LanguageText_es.resourceCulture);

		internal static string SetAnaOut => LanguageText_es.ResourceManager.GetString("SetAnaOut", LanguageText_es.resourceCulture);

		internal static string SetDigOut => LanguageText_es.ResourceManager.GetString("SetDigOut", LanguageText_es.resourceCulture);

		internal static string SetOff => LanguageText_es.ResourceManager.GetString("SetOff", LanguageText_es.resourceCulture);

		internal static string SetOn => LanguageText_es.ResourceManager.GetString("SetOn", LanguageText_es.resourceCulture);

		internal static string SetRight => LanguageText_es.ResourceManager.GetString("SetRight", LanguageText_es.resourceCulture);

		internal static string SetRpm => LanguageText_es.ResourceManager.GetString("SetRpm", LanguageText_es.resourceCulture);

		internal static string Settings => LanguageText_es.ResourceManager.GetString("Settings", LanguageText_es.resourceCulture);

		internal static string ShortName => LanguageText_es.ResourceManager.GetString("ShortName", LanguageText_es.resourceCulture);

		internal static string SignalQuit => LanguageText_es.ResourceManager.GetString("SignalQuit", LanguageText_es.resourceCulture);

		internal static string Spain => LanguageText_es.ResourceManager.GetString("Spain", LanguageText_es.resourceCulture);

		internal static string SpChange100010 => LanguageText_es.ResourceManager.GetString("SpChange100010", LanguageText_es.resourceCulture);

		internal static string SpChange203000 => LanguageText_es.ResourceManager.GetString("SpChange203000", LanguageText_es.resourceCulture);

		internal static string SpChange203001 => LanguageText_es.ResourceManager.GetString("SpChange203001", LanguageText_es.resourceCulture);

		internal static string SpChange203002 => LanguageText_es.ResourceManager.GetString("SpChange203002", LanguageText_es.resourceCulture);

		internal static string SpChange203003 => LanguageText_es.ResourceManager.GetString("SpChange203003", LanguageText_es.resourceCulture);

		internal static string SpChange203004 => LanguageText_es.ResourceManager.GetString("SpChange203004", LanguageText_es.resourceCulture);

		internal static string SpChange203005 => LanguageText_es.ResourceManager.GetString("SpChange203005", LanguageText_es.resourceCulture);

		internal static string SpChange203006 => LanguageText_es.ResourceManager.GetString("SpChange203006", LanguageText_es.resourceCulture);

		internal static string SpChange203007 => LanguageText_es.ResourceManager.GetString("SpChange203007", LanguageText_es.resourceCulture);

		internal static string SpChange203008 => LanguageText_es.ResourceManager.GetString("SpChange203008", LanguageText_es.resourceCulture);

		internal static string SpChange203009 => LanguageText_es.ResourceManager.GetString("SpChange203009", LanguageText_es.resourceCulture);

		internal static string SpChange203010 => LanguageText_es.ResourceManager.GetString("SpChange203010", LanguageText_es.resourceCulture);

		internal static string SpChange203011 => LanguageText_es.ResourceManager.GetString("SpChange203011", LanguageText_es.resourceCulture);

		internal static string SpChange203012 => LanguageText_es.ResourceManager.GetString("SpChange203012", LanguageText_es.resourceCulture);

		internal static string SpChange203013 => LanguageText_es.ResourceManager.GetString("SpChange203013", LanguageText_es.resourceCulture);

		internal static string SpChange203014 => LanguageText_es.ResourceManager.GetString("SpChange203014", LanguageText_es.resourceCulture);

		internal static string SpChange203015 => LanguageText_es.ResourceManager.GetString("SpChange203015", LanguageText_es.resourceCulture);

		internal static string SpChange203016 => LanguageText_es.ResourceManager.GetString("SpChange203016", LanguageText_es.resourceCulture);

		internal static string SpChange203017 => LanguageText_es.ResourceManager.GetString("SpChange203017", LanguageText_es.resourceCulture);

		internal static string SpChange203018 => LanguageText_es.ResourceManager.GetString("SpChange203018", LanguageText_es.resourceCulture);

		internal static string SpChange203019 => LanguageText_es.ResourceManager.GetString("SpChange203019", LanguageText_es.resourceCulture);

		internal static string SpChange203020 => LanguageText_es.ResourceManager.GetString("SpChange203020", LanguageText_es.resourceCulture);

		internal static string SpChange203021 => LanguageText_es.ResourceManager.GetString("SpChange203021", LanguageText_es.resourceCulture);

		internal static string SpChange203022 => LanguageText_es.ResourceManager.GetString("SpChange203022", LanguageText_es.resourceCulture);

		internal static string SpChange203023 => LanguageText_es.ResourceManager.GetString("SpChange203023", LanguageText_es.resourceCulture);

		internal static string SpChange203024 => LanguageText_es.ResourceManager.GetString("SpChange203024", LanguageText_es.resourceCulture);

		internal static string SpChange203025 => LanguageText_es.ResourceManager.GetString("SpChange203025", LanguageText_es.resourceCulture);

		internal static string SpChange203026 => LanguageText_es.ResourceManager.GetString("SpChange203026", LanguageText_es.resourceCulture);

		internal static string SpChange203027 => LanguageText_es.ResourceManager.GetString("SpChange203027", LanguageText_es.resourceCulture);

		internal static string SpChange203028 => LanguageText_es.ResourceManager.GetString("SpChange203028", LanguageText_es.resourceCulture);

		internal static string SpChange203029 => LanguageText_es.ResourceManager.GetString("SpChange203029", LanguageText_es.resourceCulture);

		internal static string SpChange203030 => LanguageText_es.ResourceManager.GetString("SpChange203030", LanguageText_es.resourceCulture);

		internal static string SpindleConstants => LanguageText_es.ResourceManager.GetString("SpindleConstants", LanguageText_es.resourceCulture);

		internal static string SpindleConstFiles => LanguageText_es.ResourceManager.GetString("SpindleConstFiles", LanguageText_es.resourceCulture);

		internal static string SpindlePressureScale => LanguageText_es.ResourceManager.GetString("SpindlePressureScale", LanguageText_es.resourceCulture);

		internal static string SpindleTorque => LanguageText_es.ResourceManager.GetString("SpindleTorque", LanguageText_es.resourceCulture);

		internal static string StandardDeviation => LanguageText_es.ResourceManager.GetString("StandardDeviation", LanguageText_es.resourceCulture);

		internal static string StartCycleSave => LanguageText_es.ResourceManager.GetString("StartCycleSave", LanguageText_es.resourceCulture);

		internal static string StartFrictionTest => LanguageText_es.ResourceManager.GetString("StartFrictionTest", LanguageText_es.resourceCulture);

		internal static string StartProgram => LanguageText_es.ResourceManager.GetString("StartProgram", LanguageText_es.resourceCulture);

		internal static string StartSignal => LanguageText_es.ResourceManager.GetString("StartSignal", LanguageText_es.resourceCulture);

		internal static string StartStepResExport => LanguageText_es.ResourceManager.GetString("StartStepResExport", LanguageText_es.resourceCulture);

		internal static string StartTest => LanguageText_es.ResourceManager.GetString("StartTest", LanguageText_es.resourceCulture);

		internal static string StatDelete204000 => LanguageText_es.ResourceManager.GetString("StatDelete204000", LanguageText_es.resourceCulture);

		internal static string StatDelete204001 => LanguageText_es.ResourceManager.GetString("StatDelete204001", LanguageText_es.resourceCulture);

		internal static string StatDelete204002 => LanguageText_es.ResourceManager.GetString("StatDelete204002", LanguageText_es.resourceCulture);

		internal static string StatisticCumul => LanguageText_es.ResourceManager.GetString("StatisticCumul", LanguageText_es.resourceCulture);

		internal static string Statistics => LanguageText_es.ResourceManager.GetString("Statistics", LanguageText_es.resourceCulture);

		internal static string StatisticSample => LanguageText_es.ResourceManager.GetString("StatisticSample", LanguageText_es.resourceCulture);

		internal static string StatisticsLastRes => LanguageText_es.ResourceManager.GetString("StatisticsLastRes", LanguageText_es.resourceCulture);

		internal static string Step => LanguageText_es.ResourceManager.GetString("Step", LanguageText_es.resourceCulture);

		internal static string StepFinish => LanguageText_es.ResourceManager.GetString("StepFinish", LanguageText_es.resourceCulture);

		internal static string StepKind => LanguageText_es.ResourceManager.GetString("StepKind", LanguageText_es.resourceCulture);

		internal static string StepKindChoice => LanguageText_es.ResourceManager.GetString("StepKindChoice", LanguageText_es.resourceCulture);

		internal static string StepResults => LanguageText_es.ResourceManager.GetString("StepResults", LanguageText_es.resourceCulture);

		internal static string Steps => LanguageText_es.ResourceManager.GetString("Steps", LanguageText_es.resourceCulture);

		internal static string StepTmin => LanguageText_es.ResourceManager.GetString("StepTmin", LanguageText_es.resourceCulture);

		internal static string StepTplus => LanguageText_es.ResourceManager.GetString("StepTplus", LanguageText_es.resourceCulture);

		internal static string Stop => LanguageText_es.ResourceManager.GetString("Stop", LanguageText_es.resourceCulture);

		internal static string StopNok => LanguageText_es.ResourceManager.GetString("StopNok", LanguageText_es.resourceCulture);

		internal static string StopOk => LanguageText_es.ResourceManager.GetString("StopOk", LanguageText_es.resourceCulture);

		internal static string StopStepResExport => LanguageText_es.ResourceManager.GetString("StopStepResExport", LanguageText_es.resourceCulture);

		internal static string StorageNumber => LanguageText_es.ResourceManager.GetString("StorageNumber", LanguageText_es.resourceCulture);

		internal static string StorageSignals => LanguageText_es.ResourceManager.GetString("StorageSignals", LanguageText_es.resourceCulture);

		internal static string StoreAndBack => LanguageText_es.ResourceManager.GetString("StoreAndBack", LanguageText_es.resourceCulture);

		internal static string SubnetMask => LanguageText_es.ResourceManager.GetString("SubnetMask", LanguageText_es.resourceCulture);

		internal static string SyncOut => LanguageText_es.ResourceManager.GetString("SyncOut", LanguageText_es.resourceCulture);

		internal static string SyncSignal => LanguageText_es.ResourceManager.GetString("SyncSignal", LanguageText_es.resourceCulture);

		internal static string SysChange202000 => LanguageText_es.ResourceManager.GetString("SysChange202000", LanguageText_es.resourceCulture);

		internal static string SysChange202001 => LanguageText_es.ResourceManager.GetString("SysChange202001", LanguageText_es.resourceCulture);

		internal static string SysChange202002 => LanguageText_es.ResourceManager.GetString("SysChange202002", LanguageText_es.resourceCulture);

		internal static string SysChange202003 => LanguageText_es.ResourceManager.GetString("SysChange202003", LanguageText_es.resourceCulture);

		internal static string SysChange202004 => LanguageText_es.ResourceManager.GetString("SysChange202004", LanguageText_es.resourceCulture);

		internal static string SysChange202005 => LanguageText_es.ResourceManager.GetString("SysChange202005", LanguageText_es.resourceCulture);

		internal static string SysChange202006 => LanguageText_es.ResourceManager.GetString("SysChange202006", LanguageText_es.resourceCulture);

		internal static string SysChange202007 => LanguageText_es.ResourceManager.GetString("SysChange202007", LanguageText_es.resourceCulture);

		internal static string SysChange202008 => LanguageText_es.ResourceManager.GetString("SysChange202008", LanguageText_es.resourceCulture);

		internal static string SysChange202009 => LanguageText_es.ResourceManager.GetString("SysChange202009", LanguageText_es.resourceCulture);

		internal static string SysChange202010 => LanguageText_es.ResourceManager.GetString("SysChange202010", LanguageText_es.resourceCulture);

		internal static string SysChange202011 => LanguageText_es.ResourceManager.GetString("SysChange202011", LanguageText_es.resourceCulture);

		internal static string SysChange202012 => LanguageText_es.ResourceManager.GetString("SysChange202012", LanguageText_es.resourceCulture);

		internal static string SysChange202013 => LanguageText_es.ResourceManager.GetString("SysChange202013", LanguageText_es.resourceCulture);

		internal static string SysChange202014 => LanguageText_es.ResourceManager.GetString("SysChange202014", LanguageText_es.resourceCulture);

		internal static string SysChange202015 => LanguageText_es.ResourceManager.GetString("SysChange202015", LanguageText_es.resourceCulture);

		internal static string SysChange202016 => LanguageText_es.ResourceManager.GetString("SysChange202016", LanguageText_es.resourceCulture);

		internal static string SysChange202017 => LanguageText_es.ResourceManager.GetString("SysChange202017", LanguageText_es.resourceCulture);

		internal static string SysChange202018 => LanguageText_es.ResourceManager.GetString("SysChange202018", LanguageText_es.resourceCulture);

		internal static string SystemConstants => LanguageText_es.ResourceManager.GetString("SystemConstants", LanguageText_es.resourceCulture);

		internal static string SystemID => LanguageText_es.ResourceManager.GetString("SystemID", LanguageText_es.resourceCulture);

		internal static string SystemOK => LanguageText_es.ResourceManager.GetString("SystemOK", LanguageText_es.resourceCulture);

		internal static string Target => LanguageText_es.ResourceManager.GetString("Target", LanguageText_es.resourceCulture);

		internal static string TargetRight => LanguageText_es.ResourceManager.GetString("TargetRight", LanguageText_es.resourceCulture);

		internal static string TeachSignal => LanguageText_es.ResourceManager.GetString("TeachSignal", LanguageText_es.resourceCulture);

		internal static string Test => LanguageText_es.ResourceManager.GetString("Test", LanguageText_es.resourceCulture);

		internal static string TestIO => LanguageText_es.ResourceManager.GetString("TestIO", LanguageText_es.resourceCulture);

		internal static string TestMFS => LanguageText_es.ResourceManager.GetString("TestMFS", LanguageText_es.resourceCulture);

		internal static string TestSPSIO => LanguageText_es.ResourceManager.GetString("TestSPSIO", LanguageText_es.resourceCulture);

		internal static string Time => LanguageText_es.ResourceManager.GetString("Time", LanguageText_es.resourceCulture);

		internal static string TimeDateFormat => LanguageText_es.ResourceManager.GetString("TimeDateFormat", LanguageText_es.resourceCulture);

		internal static string TimeSet => LanguageText_es.ResourceManager.GetString("TimeSet", LanguageText_es.resourceCulture);

		internal static string TimeSynchronize => LanguageText_es.ResourceManager.GetString("TimeSynchronize", LanguageText_es.resourceCulture);

		internal static string TM1 => LanguageText_es.ResourceManager.GetString("TM1", LanguageText_es.resourceCulture);

		internal static string TM2 => LanguageText_es.ResourceManager.GetString("TM2", LanguageText_es.resourceCulture);

		internal static string TN => LanguageText_es.ResourceManager.GetString("TN", LanguageText_es.resourceCulture);

		internal static string ToggleCursor => LanguageText_es.ResourceManager.GetString("ToggleCursor", LanguageText_es.resourceCulture);

		internal static string TopAll => LanguageText_es.ResourceManager.GetString("TopAll", LanguageText_es.resourceCulture);

		internal static string TopTen => LanguageText_es.ResourceManager.GetString("TopTen", LanguageText_es.resourceCulture);

		internal static string Torque => LanguageText_es.ResourceManager.GetString("Torque", LanguageText_es.resourceCulture);

		internal static string Torqueftlb => LanguageText_es.ResourceManager.GetString("Torqueftlb", LanguageText_es.resourceCulture);

		internal static string Torqueinlb => LanguageText_es.ResourceManager.GetString("Torqueinlb", LanguageText_es.resourceCulture);

		internal static string Torqueinoz => LanguageText_es.ResourceManager.GetString("Torqueinoz", LanguageText_es.resourceCulture);

		internal static string Torquekgcm => LanguageText_es.ResourceManager.GetString("Torquekgcm", LanguageText_es.resourceCulture);

		internal static string Torquekgm => LanguageText_es.ResourceManager.GetString("Torquekgm", LanguageText_es.resourceCulture);

		internal static string TorqueNcm => LanguageText_es.ResourceManager.GetString("TorqueNcm", LanguageText_es.resourceCulture);

		internal static string TorqueNm => LanguageText_es.ResourceManager.GetString("TorqueNm", LanguageText_es.resourceCulture);

		internal static string TorqueRedundantTime => LanguageText_es.ResourceManager.GetString("TorqueRedundantTime", LanguageText_es.resourceCulture);

		internal static string TorqueRedundantTolerance => LanguageText_es.ResourceManager.GetString("TorqueRedundantTolerance", LanguageText_es.resourceCulture);

		internal static string TorqueSensorInvers => LanguageText_es.ResourceManager.GetString("TorqueSensorInvers", LanguageText_es.resourceCulture);

		internal static string TorqueSensorScale => LanguageText_es.ResourceManager.GetString("TorqueSensorScale", LanguageText_es.resourceCulture);

		internal static string TorqueSensorTolerance => LanguageText_es.ResourceManager.GetString("TorqueSensorTolerance", LanguageText_es.resourceCulture);

		internal static string TorqueUnitChoose => LanguageText_es.ResourceManager.GetString("TorqueUnitChoose", LanguageText_es.resourceCulture);

		internal static string TreshTorque => LanguageText_es.ResourceManager.GetString("TreshTorque", LanguageText_es.resourceCulture);

		internal static string Type => LanguageText_es.ResourceManager.GetString("Type", LanguageText_es.resourceCulture);

		internal static string Unit => LanguageText_es.ResourceManager.GetString("Unit", LanguageText_es.resourceCulture);

		internal static string UnitBar => LanguageText_es.ResourceManager.GetString("UnitBar", LanguageText_es.resourceCulture);

		internal static string UpperLimit => LanguageText_es.ResourceManager.GetString("UpperLimit", LanguageText_es.resourceCulture);

		internal static string UsedKeyboard => LanguageText_es.ResourceManager.GetString("UsedKeyboard", LanguageText_es.resourceCulture);

		internal static string UsedValueNumber => LanguageText_es.ResourceManager.GetString("UsedValueNumber", LanguageText_es.resourceCulture);

		internal static string UseLanguageSettings => LanguageText_es.ResourceManager.GetString("UseLanguageSettings", LanguageText_es.resourceCulture);

		internal static string User => LanguageText_es.ResourceManager.GetString("User", LanguageText_es.resourceCulture);

		internal static string UserRights => LanguageText_es.ResourceManager.GetString("UserRights", LanguageText_es.resourceCulture);

		internal static string USTime => LanguageText_es.ResourceManager.GetString("USTime", LanguageText_es.resourceCulture);

		internal static string Valid => LanguageText_es.ResourceManager.GetString("Valid", LanguageText_es.resourceCulture);

		internal static string Value => LanguageText_es.ResourceManager.GetString("Value", LanguageText_es.resourceCulture);

		internal static string ValueRange => LanguageText_es.ResourceManager.GetString("ValueRange", LanguageText_es.resourceCulture);

		internal static string ValuesNotApplied => LanguageText_es.ResourceManager.GetString("ValuesNotApplied", LanguageText_es.resourceCulture);

		internal static string VersionController => LanguageText_es.ResourceManager.GetString("VersionController", LanguageText_es.resourceCulture);

		internal static string VersionInfo => LanguageText_es.ResourceManager.GetString("VersionInfo", LanguageText_es.resourceCulture);

		internal static string VersionVisu => LanguageText_es.ResourceManager.GetString("VersionVisu", LanguageText_es.resourceCulture);

		internal static string Visualisation => LanguageText_es.ResourceManager.GetString("Visualisation", LanguageText_es.resourceCulture);

		internal static string VisuParam => LanguageText_es.ResourceManager.GetString("VisuParam", LanguageText_es.resourceCulture);

		internal static string Voltage => LanguageText_es.ResourceManager.GetString("Voltage", LanguageText_es.resourceCulture);

		internal static string WaitForAck => LanguageText_es.ResourceManager.GetString("WaitForAck", LanguageText_es.resourceCulture);

		internal static string Warning => LanguageText_es.ResourceManager.GetString("Warning", LanguageText_es.resourceCulture);

		internal static string WarningMode => LanguageText_es.ResourceManager.GetString("WarningMode", LanguageText_es.resourceCulture);

		internal static string WarningNumber => LanguageText_es.ResourceManager.GetString("WarningNumber", LanguageText_es.resourceCulture);

		internal static string WasReset => LanguageText_es.ResourceManager.GetString("WasReset", LanguageText_es.resourceCulture);

		internal static string WasSet => LanguageText_es.ResourceManager.GetString("WasSet", LanguageText_es.resourceCulture);

		internal static string WeberCurveFormat => LanguageText_es.ResourceManager.GetString("WeberCurveFormat", LanguageText_es.resourceCulture);

		internal static string WN => LanguageText_es.ResourceManager.GetString("WN", LanguageText_es.resourceCulture);

		internal static string WriteLastNIOTable => LanguageText_es.ResourceManager.GetString("WriteLastNIOTable", LanguageText_es.resourceCulture);

		internal static string WriteLastResultsTable => LanguageText_es.ResourceManager.GetString("WriteLastResultsTable", LanguageText_es.resourceCulture);

		internal static string WriteLogbookData => LanguageText_es.ResourceManager.GetString("WriteLogbookData", LanguageText_es.resourceCulture);

		internal static string WriteLogBookTable => LanguageText_es.ResourceManager.GetString("WriteLogBookTable", LanguageText_es.resourceCulture);

		internal static string WriteStepResults => LanguageText_es.ResourceManager.GetString("WriteStepResults", LanguageText_es.resourceCulture);

		internal static string Xmax => LanguageText_es.ResourceManager.GetString("Xmax", LanguageText_es.resourceCulture);

		internal static string Xmin => LanguageText_es.ResourceManager.GetString("Xmin", LanguageText_es.resourceCulture);

		internal static string XmlExport => LanguageText_es.ResourceManager.GetString("XmlExport", LanguageText_es.resourceCulture);

		internal static string Yes => LanguageText_es.ResourceManager.GetString("Yes", LanguageText_es.resourceCulture);

		internal static string ZoomIn => LanguageText_es.ResourceManager.GetString("ZoomIn", LanguageText_es.resourceCulture);

		internal static string ZoomOut => LanguageText_es.ResourceManager.GetString("ZoomOut", LanguageText_es.resourceCulture);

		internal LanguageText_es()
		{
		}
	}
}
