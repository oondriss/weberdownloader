using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.Threading;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class ComponentForm : Form
	{
		private MainForm Main;

		private int PrintPos;

		private string[] ColumnName;

		private static Color UNSAVED_BACKGROUND_COLOR = Color.LightGreen;

		private ComponentNewEntryForm componentNewForm;

		private Panel pnMenu;

		private Button btBack;

		private Button btHelp;

		private Button btNewEntry;

		private Button btDelete;

		private Button btPrint;

		private PrintDocument printDocument;

		private PrintDialog printDialog;

		private SaveFileDialog SFD;

		private Button btAdvanceWarning;

		private DataGridView dGMResults;

		private Container components;

		private Button btCancel;

		private Button btEdit;

		private static int LAST_ITEM_IS_NEW = 1;

		private static int ITEM_IS_CHANGED = 2;

		private static int ALL_ITEMS_ARE_NEW = 3;

		private static int ITEM_WAS_DELETED = 4;

		private bool loadDataFromController = true;

		private string[] componentList;

		private List<WSP1_VarComm.ComponentBufferStruct> ComponentDataList = new List<WSP1_VarComm.ComponentBufferStruct>();

		private bool level1;

		public string ComponentText(int i)
		{
			string result = "n.v.";
			if (i < this.componentList.Length && this.componentList[i] != null)
			{
				return this.componentList[i];
			}
			return result;
		}

		public void LoadDataFromController()
		{
			this.loadDataFromController = true;
		}

		public ComponentForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.componentNewForm = new ComponentNewEntryForm(this.Main);
			this.PrintPos = 0;
		}

		private void initDataGrid()
		{
			this.ColumnName = new string[8];
			this.ColumnName[0] = "Number";
			this.ColumnName[1] = "Date";
			this.ColumnName[2] = "Module or Part";
			this.ColumnName[3] = "Serial number";
			this.ColumnName[4] = "Piece count";
			this.ColumnName[5] = "Reason";
			this.ColumnName[6] = "Cycle";
			this.ColumnName[7] = "User";
			this.dGMResults.Columns.Clear();
			this.dGMResults.Columns.Add("Col1", this.ColumnName[0]);
			this.dGMResults.Columns.Add("Col2", this.ColumnName[1]);
			this.dGMResults.Columns.Add("Col4", this.ColumnName[2]);
			this.dGMResults.Columns.Add("Col3", this.ColumnName[3]);
			this.dGMResults.Columns.Add("Col5", this.ColumnName[4]);
			this.dGMResults.Columns.Add("Col6", this.ColumnName[5]);
			this.dGMResults.Columns.Add("Col7", this.ColumnName[6]);
			this.dGMResults.Columns.Add("Col8", this.ColumnName[7]);
			this.dGMResults.Columns[0].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[1].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[2].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[3].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[4].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[5].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[6].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[7].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[0].Width = 25;
			this.dGMResults.Columns[1].Width = 60;
			this.dGMResults.Columns[2].Width = 170;
			this.dGMResults.Columns[2].MinimumWidth = 170;
			this.dGMResults.Columns[3].Width = 105;
			this.dGMResults.Columns[3].MinimumWidth = 105;
			this.dGMResults.Columns[4].Width = 55;
			this.dGMResults.Columns[4].MinimumWidth = 55;
			this.dGMResults.Columns[5].Width = 170;
			this.dGMResults.Columns[2].MinimumWidth = 170;
			this.dGMResults.Columns[6].Width = 50;
			this.dGMResults.Columns[7].Width = 50;
			this.dGMResults.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[3].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[5].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[6].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[7].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[0].HeaderText = "";
			this.dGMResults.Columns[1].HeaderText = this.Main.Rm.GetString("DateTime");
			this.dGMResults.Columns[2].HeaderText = this.Main.Rm.GetString("ModuleOrPart");
			this.dGMResults.Columns[3].HeaderText = this.Main.Rm.GetString("SerialNumber");
			this.dGMResults.Columns[4].HeaderText = this.Main.Rm.GetString("PieceCount");
			this.dGMResults.Columns[5].HeaderText = this.Main.Rm.GetString("ReasonOfChange");
			this.dGMResults.Columns[6].HeaderText = this.Main.Rm.GetString("Cycle_Number");
			this.dGMResults.Columns[7].HeaderText = this.Main.Rm.GetString("User");
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
			this.pnMenu = new Panel();
			this.btEdit = new Button();
			this.btCancel = new Button();
			this.btAdvanceWarning = new Button();
			this.btPrint = new Button();
			this.btNewEntry = new Button();
			this.btDelete = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.printDocument = new PrintDocument();
			this.printDialog = new PrintDialog();
			this.SFD = new SaveFileDialog();
			this.dGMResults = new DataGridView();
			this.pnMenu.SuspendLayout();
			((ISupportInitialize)this.dGMResults).BeginInit();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btEdit);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.btAdvanceWarning);
			this.pnMenu.Controls.Add(this.btPrint);
			this.pnMenu.Controls.Add(this.btNewEntry);
			this.pnMenu.Controls.Add(this.btDelete);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btEdit.Location = new Point(3, 195);
			this.btEdit.Name = "btEdit";
			this.btEdit.Size = new Size(74, 62);
			this.btEdit.TabIndex = 3;
			this.btEdit.Text = "Edit entry";
			this.btEdit.Click += this.btEdit_Click;
			this.btCancel.Location = new Point(3, 449);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 7;
			this.btCancel.Text = "Änderungen verwerfen";
			this.btCancel.Click += this.btCancel_Click;
			this.btAdvanceWarning.Location = new Point(3, 323);
			this.btAdvanceWarning.Name = "btAdvanceWarning";
			this.btAdvanceWarning.Size = new Size(74, 62);
			this.btAdvanceWarning.TabIndex = 5;
			this.btAdvanceWarning.Text = "Vorwarn- werte";
			this.btAdvanceWarning.Click += this.btAdvanceWarning_Click;
			this.btPrint.Location = new Point(3, 386);
			this.btPrint.Name = "btPrint";
			this.btPrint.Size = new Size(74, 62);
			this.btPrint.TabIndex = 6;
			this.btPrint.Text = "Print";
			this.btPrint.Click += this.btPrint_Click;
			this.btNewEntry.Location = new Point(3, 131);
			this.btNewEntry.Name = "btNewEntry";
			this.btNewEntry.Size = new Size(74, 62);
			this.btNewEntry.TabIndex = 2;
			this.btNewEntry.Text = "New entry";
			this.btNewEntry.Click += this.btNewEntry_Click;
			this.btDelete.Enabled = false;
			this.btDelete.Location = new Point(3, 259);
			this.btDelete.Name = "btDelete";
			this.btDelete.Size = new Size(74, 62);
			this.btDelete.TabIndex = 4;
			this.btDelete.Text = "Delete entry";
			this.btDelete.Click += this.btDelete_Click;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.printDocument.PrintPage += this.printDocument_PrintPage;
			this.printDialog.Document = this.printDocument;
			this.SFD.Filter = "LogFiles (.txt)|*.txt|All Files|*.*";
			this.dGMResults.AllowUserToAddRows = false;
			this.dGMResults.AllowUserToDeleteRows = false;
			this.dGMResults.AllowUserToResizeColumns = false;
			this.dGMResults.AllowUserToResizeRows = false;
			dataGridViewCellStyle.WrapMode = DataGridViewTriState.True;
			this.dGMResults.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle;
			this.dGMResults.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
			this.dGMResults.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
			this.dGMResults.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = SystemColors.Window;
			dataGridViewCellStyle2.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = Color.Transparent;
			dataGridViewCellStyle2.SelectionForeColor = Color.Black;
			dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
			this.dGMResults.DefaultCellStyle = dataGridViewCellStyle2;
			this.dGMResults.Location = new Point(0, 0);
			this.dGMResults.MultiSelect = false;
			this.dGMResults.Name = "dGMResults";
			this.dGMResults.ReadOnly = true;
			this.dGMResults.RowHeadersVisible = false;
			this.dGMResults.RowHeadersWidth = 10;
			dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
			this.dGMResults.RowsDefaultCellStyle = dataGridViewCellStyle3;
			this.dGMResults.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			this.dGMResults.Size = new Size(709, 522);
			this.dGMResults.TabIndex = 4;
			this.dGMResults.CellDoubleClick += this.dGMResults_CellDoubleClick;
			this.dGMResults.RowPostPaint += this.dGMResults_RowPostPaint;
			this.dGMResults.SelectionChanged += this.dGMResults_SelectionChanged;
			this.dGMResults.MouseDown += this.dGMResults_MouseDown;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.dGMResults);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.Name = "ComponentForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Komponenten-Statistik";
			base.Activated += this.ComponentForm_Activated;
			this.pnMenu.ResumeLayout(false);
			((ISupportInitialize)this.dGMResults).EndInit();
			base.ResumeLayout(false);
		}

		public bool ShowWindow()
		{
			if (!this.Main.IsOnlineMode)
			{
				this.btNewEntry.Enabled = false;
				this.btPrint.Enabled = false;
				this.btBack.Enabled = false;
				this.btEdit.Enabled = false;
				base.Show();
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadLogBookData"));
			if (!this.Main.VC.ReceiveVarBlock(7))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				base.Show();
				MessageBox.Show("Could not receive LogBookSysBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.MenEna();
			base.Show();
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			this.pnMenu.Enabled = false;
			this.Main.HelpButton = false;
			this.Cursor = Cursors.WaitCursor;
			if (this.loadDataFromController)
			{
				this.dGMResults.Rows.Clear();
				Application.DoEvents();
				this.readDataFromWSP();
				this.loadDataFromController = false;
				this.updateMenu(ComponentForm.ALL_ITEMS_ARE_NEW, 0);
				if (this.maxSizeOfJounalReached())
				{
					if (this.level1)
					{
						this.btDelete.Enabled = true;
					}
					this.btDelete.Text = this.Main.Rm.GetString("PrintJournalAndDelete");
					this.btDelete.ForeColor = Color.Red;
				}
				else
				{
					this.btDelete.Text = this.Main.Rm.GetString("DeleteEntry");
					this.btDelete.ForeColor = Color.Black;
				}
			}
			this.Cursor = Cursors.Default;
			this.Main.HelpButton = true;
			this.pnMenu.Enabled = true;
			this.Main.SettingsChangedReset();
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MenuMaintenance") + "/" + this.Main.Rm.GetString("MComponentStatistic");
			this.btBack.Text = this.Main.Rm.GetString("StoreAndBack");
			this.btCancel.Text = this.Main.Rm.GetString("DiscardChanges");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btPrint.Text = this.Main.Rm.GetString("Print");
			this.btEdit.Text = this.Main.Rm.GetString("ChangeEntry");
			this.printDocument.DocumentName = this.Main.Rm.GetString("MLogBook");
			this.btNewEntry.Text = this.Main.Rm.GetString("btNewEntrie");
			this.btDelete.Text = this.Main.Rm.GetString("DeleteEntry");
			this.SFD.Filter = this.Main.Rm.GetString("MComponentStatistic") + "|*.txt|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.btAdvanceWarning.Text = this.Main.Rm.GetString("btAdvanceWarning");
			this.componentList = new string[18];
			this.componentList[0] = this.Main.Rm.GetString("Packet-1");
			this.componentList[1] = this.Main.Rm.GetString("Packet-2");
			this.componentList[2] = this.Main.Rm.GetString("Packet-3");
			this.componentList[3] = this.Main.Rm.GetString("Packet-4");
			this.componentList[4] = this.Main.Rm.GetString("Packet-5");
			this.componentList[5] = this.Main.Rm.GetString("Packet-6");
			this.componentList[6] = this.Main.Rm.GetString("Packet-7");
			this.componentList[7] = this.Main.Rm.GetString("Packet-8");
			this.componentList[8] = this.Main.Rm.GetString("Packet-9");
			this.componentList[9] = this.Main.Rm.GetString("Packet-10");
			this.componentList[10] = this.Main.Rm.GetString("Packet-11");
			this.componentList[11] = this.Main.Rm.GetString("Packet-12");
			this.componentList[12] = this.Main.Rm.GetString("Packet-13");
			this.componentList[13] = this.Main.Rm.GetString("Packet-14");
			this.componentList[14] = this.Main.Rm.GetString("Packet-15");
			this.componentList[15] = this.Main.Rm.GetString("Packet-16");
			this.componentList[16] = this.Main.Rm.GetString("Packet-17");
			this.componentList[17] = this.Main.Rm.GetString("Packet-18");
			this.initDataGrid();
		}

		private void MenEna()
		{
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_Maintenance && !this.Main.ViewOnlyMode)
			{
				this.level1 = true;
			}
			this.btNewEntry.Enabled = this.level1;
			this.btBack.Enabled = this.level1;
			this.btPrint.Enabled = true;
			if (this.Main._READ_ONLY_CONTROLLER)
			{
				this.btBack.Enabled = false;
			}
			else
			{
				this.btBack.Enabled = true;
			}
		}

		private bool maxSizeOfJounalReached()
		{
			if (this.dGMResults.Rows.Count > 2000)
			{
				return true;
			}
			return false;
		}

		private void getAllModulesFromList(ref List<string> listOfModules)
		{
			listOfModules.Clear();
			for (int i = 0; i < this.componentList.Length; i++)
			{
				listOfModules.Add(this.componentList[i]);
			}
		}

		private void updateMenu(int itemNewOrChanged_OrAllNew, int indexChanged)
		{
			if (itemNewOrChanged_OrAllNew != ComponentForm.ALL_ITEMS_ARE_NEW && itemNewOrChanged_OrAllNew != ComponentForm.LAST_ITEM_IS_NEW && itemNewOrChanged_OrAllNew == ComponentForm.ITEM_IS_CHANGED && indexChanged >= this.dGMResults.Rows.Count)
			{
				return;
			}
			string empty = string.Empty;
			if (itemNewOrChanged_OrAllNew == ComponentForm.ALL_ITEMS_ARE_NEW)
			{
				this.dGMResults.Rows.Clear();
				Application.DoEvents();
			}
			else if (itemNewOrChanged_OrAllNew == ComponentForm.ITEM_IS_CHANGED)
			{
				this.dGMResults.Rows.RemoveAt(indexChanged);
			}
			else if (itemNewOrChanged_OrAllNew != ComponentForm.LAST_ITEM_IS_NEW)
			{
				if (itemNewOrChanged_OrAllNew == ComponentForm.ITEM_WAS_DELETED)
				{
					this.dGMResults.Rows.RemoveAt(indexChanged);
				}
				return;
			}
			string @string = this.Main.Rm.GetString("CreationOfList");
			this.Main.StatusBarText(@string);
			for (int i = 0; i < this.dGMResults.Columns.Count; i++)
			{
				this.dGMResults.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
				this.dGMResults.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
			}
			if (this.ComponentDataList.Count > 0)
			{
				this.dGMResults.Rows.Add(this.ComponentDataList.Count);
			}
			int num = (itemNewOrChanged_OrAllNew != ComponentForm.ALL_ITEMS_ARE_NEW) ? (this.ComponentDataList.Count - 1) : 0;
			for (int j = num; j < this.ComponentDataList.Count; j++)
			{
				if (j % 100 == 0)
				{
					this.Main.StatusBarText("(" + j.ToString() + ")" + @string);
				}
				try
				{
					this.dGMResults.Rows[j].Cells[0].Value = j + 1;
					DateTime dateTime;
					try
					{
						dateTime = new DateTime(this.ComponentDataList[j].Time.Year, this.ComponentDataList[j].Time.Month, this.ComponentDataList[j].Time.Day, this.ComponentDataList[j].Time.Hour, this.ComponentDataList[j].Time.Minute, this.ComponentDataList[j].Time.Second);
					}
					catch
					{
						dateTime = new DateTime(1, 1, 1, 0, 0, 0);
					}
					string timeSet = Settings.Default.TimeSet;
					dateTime.ToString(timeSet);
					this.dGMResults.Rows[j].Cells[1].Value = dateTime;
					this.dGMResults.Rows[j].Cells[2].Value = this.Main.CommonFunctions.UShortToString(this.ComponentDataList[j].ComponentOrPartText);
					this.dGMResults.Rows[j].Cells[3].Value = this.Main.CommonFunctions.UShortToString(this.ComponentDataList[j].SerialNumber);
					this.dGMResults.Rows[j].Cells[4].Value = this.ComponentDataList[j].PieceCount;
					this.dGMResults.Rows[j].Cells[5].Value = this.Main.CommonFunctions.UShortToString(this.ComponentDataList[j].ReasonText);
					this.dGMResults.Rows[j].Cells[6].Value = this.ComponentDataList[j].Cycle;
					this.dGMResults.Rows[j].Cells[7].Value = this.Main.CommonFunctions.UShortToString(this.ComponentDataList[j].userName);
					if (itemNewOrChanged_OrAllNew != ComponentForm.ALL_ITEMS_ARE_NEW && j == this.ComponentDataList.Count - 1)
					{
						for (int k = 0; k < this.dGMResults.Rows[j].Cells.Count; k++)
						{
							this.dGMResults.Rows[j].Cells[k].Style.BackColor = Color.LightGreen;
						}
					}
				}
				catch (Exception)
				{
				}
			}
			this.Main.StatusBarText(@string);
			this.dGMResults.Columns[0].SortMode = DataGridViewColumnSortMode.Automatic;
			this.dGMResults.Columns[2].SortMode = DataGridViewColumnSortMode.Automatic;
			this.dGMResults.Columns[3].SortMode = DataGridViewColumnSortMode.Automatic;
			this.dGMResults.Columns[4].SortMode = DataGridViewColumnSortMode.Automatic;
			this.dGMResults.Columns[5].SortMode = DataGridViewColumnSortMode.Automatic;
			this.dGMResults.Columns[6].SortMode = DataGridViewColumnSortMode.Automatic;
			this.dGMResults.Columns[7].SortMode = DataGridViewColumnSortMode.Automatic;
			foreach (DataGridViewRow selectedRow in this.dGMResults.SelectedRows)
			{
				this.dGMResults.Rows[selectedRow.Index].Selected = false;
			}
			this.dGMResults.Sort(this.dGMResults.Columns[0], ListSortDirection.Descending);
			this.Main.StatusBarText(this.Main.Rm.GetString(""));
		}

		private bool importDataFromVC()
		{
			bool result = true;
			for (int i = 0; i < 32; i++)
			{
				string text = this.Main.CommonFunctions.UShortToString(this.Main.VC.ComponentDataBlock.ComponentData[i].ComponentOrPartText);
				if (text.Length == 0)
				{
					result = false;
				}
				else
				{
					WSP1_VarComm.ComponentBufferStruct item = new WSP1_VarComm.ComponentBufferStruct();
					this.Main.VC.makeCopyComponentBufferStruct(ref item, this.Main.VC.ComponentDataBlock.ComponentData[i]);
					this.ComponentDataList.Add(item);
				}
			}
			return result;
		}

		private void readDataFromWSP()
		{
			if (this.Main.IsOnlineMode)
			{
				this.ComponentDataList.Clear();
				Cursor.Current = Cursors.WaitCursor;
				this.Main.VC.ComponentDataBlock.NextBlock = 0u;
				int num = 0;
				string @string = this.Main.Rm.GetString("LoadComponentData");
				while (this.Main.VC.ComponentDataBlock.NextBlock != 255 && num < 254)
				{
					this.Main.StatusBarText(this.Main.Rm.GetString("LoadComponentData"));
					this.Main.StatusBarText("(" + num.ToString() + ")" + @string);
					if (!((num != 0) ? this.Main.ReadFromController(82) : this.Main.ReadFromController(81)))
					{
						this.Main.StatusBarText(string.Empty);
						this.Main.VC.ComponentDataBlock.NextBlock = 255u;
						break;
					}
					bool flag = this.Main.VC.ReceiveVarBlock(71);
					this.importDataFromVC();
					num++;
				}
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void writeDataToWSP(bool writeAll)
		{
			int num = 0;
			uint num2 = 0u;
			while (num < this.ComponentDataList.Count)
			{
				this.Main.VC.ComponentDataBlock.Initialize();
				this.Main.VC.ComponentDataBlock.BlockNum = num2;
				bool flag = false;
				int i;
				for (i = 0; i < 32; i++)
				{
					if (num >= this.ComponentDataList.Count)
					{
						break;
					}
					if (this.ComponentDataList[num].NewEntry != 0 || writeAll)
					{
						flag = true;
						this.ComponentDataList[num].NewEntry = 0;
					}
					this.Main.VC.makeCopyComponentBufferStruct(ref this.Main.VC.ComponentDataBlock.ComponentData[i], this.ComponentDataList[num]);
					num++;
				}
				if (num >= this.ComponentDataList.Count && num % 32 != 0)
				{
					while (i % 32 != 0)
					{
						this.Main.VC.makeCopyComponentBufferStruct(ref this.Main.VC.ComponentDataBlock.ComponentData[i], new WSP1_VarComm.ComponentBufferStruct());
						i++;
						num++;
					}
				}
				num2++;
				if (num < this.ComponentDataList.Count)
				{
					this.Main.VC.ComponentDataBlock.NextBlock = num2;
				}
				else
				{
					this.Main.VC.ComponentDataBlock.NextBlock = 255u;
				}
				if (flag)
				{
					this.Main.StatusBarText(this.Main.Rm.GetString("WriteComponentData") + "  " + num2.ToString());
					if (!this.Main.VC.SendVarBlock(71))
					{
						this.Main.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						MessageBox.Show("Could not send COMPONENTDATABLOCK_BLOCKNUM!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						return;
					}
					Thread.Sleep(50);
					this.Main.StatusBarText(this.Main.Rm.GetString("SaveSystemConstOnCPU"));
					if (!this.Main.SaveOnController(80, false))
					{
						this.Main.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						MessageBox.Show(this.Main.Rm.GetString("MbSaveSysConstFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
						this.pnMenu.Enabled = true;
						this.pnMenu.Select();
						return;
					}
					Thread.Sleep(50);
				}
			}
			this.Main.StatusBarText(string.Empty);
		}

		private void saveNewestEntries(int numberOfLines)
		{
			int num = this.ComponentDataList.Count - numberOfLines;
			for (int i = 0; i < num; i++)
			{
				this.ComponentDataList.RemoveAt(0);
			}
			this.writeDataToWSP(true);
		}

		private bool unsavedItems()
		{
			for (int i = 0; i < this.dGMResults.Rows.Count; i++)
			{
				if (this.dGMResults.Rows[i].Cells[5].Style.BackColor == ComponentForm.UNSAVED_BACKGROUND_COLOR)
				{
					return true;
				}
			}
			return false;
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				this.pnMenu.Enabled = false;
				base.Hide();
			}
			else
			{
				this.writeDataToWSP(false);
				this.pnMenu.Enabled = false;
				base.Hide();
				if (sender != null)
				{
					this.Main.MenuMaintenance1.Back();
				}
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			if (sender != null && this.unsavedItems())
			{
				DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MDataNotSavedExit"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
				if (dialogResult == DialogResult.No)
				{
					return;
				}
			}
			this.pnMenu.Enabled = false;
			base.Hide();
			if (sender != null)
			{
				this.Main.MenuMaintenance1.Back();
			}
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_5_2_Menue_Komponenten_Statistik";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_5_2_Menue_Komponenten_Statistik");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void ComponentForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
			this.btAdvanceWarning.ForeColor = this.Main.AdvanceWarning1.GetInfo(false);
		}

		private void btPrint_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnectionToController"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.prepareDocument();
				this.Main.SimplePrint.DocName = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) + "_" + this.Main.Rm.GetString("MComponentStatistic");
				this.Main.SimplePrint.Print(false, true);
			}
		}

		private void prepareDocument()
		{
			this.Main.SimplePrint.SetLeft();
			this.Main.SimplePrint.SetStyleBold();
			this.Main.SimplePrint.SetSizeXL();
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("MaintenanceList") + " (" + this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) + "):");
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.ResetStyle();
			this.Main.SimplePrint.SetSizeLarge();
			DateTime now = DateTime.Now;
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("LocalTime") + ": " + now.ToString());
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.SetSizeLarge();
			for (int i = 0; i < this.dGMResults.Rows.Count; i++)
			{
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[0].Value.ToString() + ":");
				if (this.dGMResults.Rows[i].Cells[5].Style.BackColor == ComponentForm.UNSAVED_BACKGROUND_COLOR)
				{
					this.Main.SimplePrint.SetStyleBold();
					this.Main.SimplePrint.SetTab(1);
					this.Main.SimplePrint.Sb.Append("  (" + this.Main.Rm.GetString("MbEntryNotYetStored") + ")");
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.ResetStyle();
					this.Main.SimplePrint.SetSizeLarge();
				}
				else
				{
					this.Main.SimplePrint.SetNewLine();
				}
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[1].HeaderText);
				this.Main.SimplePrint.SetTab(7);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[1].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[2].HeaderText);
				this.Main.SimplePrint.SetTab(7);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[2].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[3].HeaderText);
				this.Main.SimplePrint.SetTab(7);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[3].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[4].HeaderText);
				this.Main.SimplePrint.SetTab(7);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[4].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[5].HeaderText);
				this.Main.SimplePrint.SetTab(7);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[5].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[6].HeaderText);
				this.Main.SimplePrint.SetTab(7);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[6].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[7].HeaderText);
				this.Main.SimplePrint.SetTab(7);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[7].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetNewLine();
			}
		}

		private void printDocument_PrintPage(object sender, PrintPageEventArgs e)
		{
		}

		public void MakeNewEntry()
		{
			this.btNewEntry_Click(null, EventArgs.Empty);
		}

		private void btNewEntry_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnectionToController"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.componentNewForm.MaxlenMaintenanceText = 100;
				this.componentNewForm.MaxlenModuleOrPartText = 100;
				this.componentNewForm.MaxlenSerialNumberText = 31;
				List<string> listOfModules = new List<string>();
				this.getAllModulesFromList(ref listOfModules);
				this.componentNewForm.AddModules(listOfModules, true);
				this.componentNewForm.NewEntry = true;
				this.componentNewForm.ShowDialog();
				if (this.componentNewForm.Result == 2)
				{
					WSP1_VarComm.ComponentBufferStruct componentBufferStruct = new WSP1_VarComm.ComponentBufferStruct();
					componentBufferStruct.NewEntry = 1;
					string moduleOrPartText = this.componentNewForm.ModuleOrPartText;
					this.Main.CommonFunctions.StringToUShort(ref componentBufferStruct.ComponentOrPartText, moduleOrPartText, moduleOrPartText.Length);
					moduleOrPartText = this.componentNewForm.SerialNumberText;
					this.Main.CommonFunctions.StringToUShort(ref componentBufferStruct.SerialNumber, moduleOrPartText, moduleOrPartText.Length);
					moduleOrPartText = this.componentNewForm.MaintenanceText;
					this.Main.CommonFunctions.StringToUShort(ref componentBufferStruct.ReasonText, moduleOrPartText, moduleOrPartText.Length);
					componentBufferStruct.Time.Year = (ushort)DateTime.Now.Year;
					componentBufferStruct.Time.Month = (byte)DateTime.Now.Month;
					componentBufferStruct.Time.Day = (byte)DateTime.Now.Day;
					componentBufferStruct.Time.Hour = (byte)DateTime.Now.Hour;
					componentBufferStruct.Time.Minute = (byte)DateTime.Now.Minute;
					componentBufferStruct.Time.Second = (byte)DateTime.Now.Second;
					componentBufferStruct.PieceCount = this.componentNewForm.PieceCount;
					componentBufferStruct.Cycle = this.Main.VC.CycleCount.Machine;
					this.Main.CommonFunctions.StringToUShort(ref componentBufferStruct.userName, this.Main.ActualUser, this.Main.ActualUser.Length + 1);
					this.ComponentDataList.Add(componentBufferStruct);
					this.updateMenu(ComponentForm.LAST_ITEM_IS_NEW, 0);
					this.ComponentDataList.IndexOf(componentBufferStruct);
					DateTime dateTime;
					try
					{
						dateTime = new DateTime(componentBufferStruct.Time.Year, componentBufferStruct.Time.Month, componentBufferStruct.Time.Day, componentBufferStruct.Time.Hour, componentBufferStruct.Time.Minute, componentBufferStruct.Time.Second);
					}
					catch
					{
						dateTime = new DateTime(1, 1, 1, 0, 0, 0);
					}
					int num = 0;
					while (true)
					{
						if (num < this.dGMResults.Rows.Count)
						{
							if (!(this.dGMResults.Rows[num].Cells[1].Value.ToString() == dateTime.ToString()))
							{
								num++;
								continue;
							}
							break;
						}
						return;
					}
					this.dGMResults.FirstDisplayedCell = this.dGMResults.Rows[num].Cells[0];
				}
			}
		}

		private void btEdit_Click(object sender, EventArgs e)
		{
			if (this.dGMResults.SelectedRows.Count != 0)
			{
				if (!this.Main.IsOnlineMode)
				{
					MessageBox.Show(this.Main.Rm.GetString("MbNoConnectionToController"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					int index = this.dGMResults.SelectedRows[0].Index;
					this.componentNewForm.MaxlenMaintenanceText = 100;
					this.componentNewForm.MaxlenModuleOrPartText = 100;
					this.componentNewForm.MaxlenSerialNumberText = 31;
					this.componentNewForm.ModuleOrPartText = this.Main.CommonFunctions.UShortToString(this.ComponentDataList[index].ComponentOrPartText);
					this.componentNewForm.SerialNumberText = this.Main.CommonFunctions.UShortToString(this.ComponentDataList[index].SerialNumber);
					this.componentNewForm.MaintenanceText = this.Main.CommonFunctions.UShortToString(this.ComponentDataList[index].ReasonText);
					this.componentNewForm.PieceCount = this.ComponentDataList[index].PieceCount;
					List<string> listOfModules = new List<string>();
					this.getAllModulesFromList(ref listOfModules);
					this.componentNewForm.AddModules(listOfModules, true);
					this.componentNewForm.NewEntry = false;
					this.componentNewForm.ShowDialog();
					if (this.componentNewForm.Result != 1)
					{
						WSP1_VarComm.ComponentBufferStruct componentBufferStruct = new WSP1_VarComm.ComponentBufferStruct();
						string moduleOrPartText = this.componentNewForm.ModuleOrPartText;
						this.Main.CommonFunctions.StringToUShort(ref componentBufferStruct.ComponentOrPartText, moduleOrPartText, moduleOrPartText.Length + 1);
						moduleOrPartText = this.componentNewForm.SerialNumberText;
						this.Main.CommonFunctions.StringToUShort(ref componentBufferStruct.SerialNumber, moduleOrPartText, moduleOrPartText.Length + 1);
						moduleOrPartText = this.componentNewForm.MaintenanceText;
						this.Main.CommonFunctions.StringToUShort(ref componentBufferStruct.ReasonText, moduleOrPartText, moduleOrPartText.Length + 1);
						componentBufferStruct.Time.Year = (ushort)DateTime.Now.Year;
						componentBufferStruct.Time.Month = (byte)DateTime.Now.Month;
						componentBufferStruct.Time.Day = (byte)DateTime.Now.Day;
						componentBufferStruct.Time.Hour = (byte)DateTime.Now.Hour;
						componentBufferStruct.Time.Minute = (byte)DateTime.Now.Minute;
						componentBufferStruct.Time.Second = (byte)DateTime.Now.Second;
						componentBufferStruct.PieceCount = this.componentNewForm.PieceCount;
						componentBufferStruct.Cycle = this.Main.VC.Result.Cycle;
						this.Main.CommonFunctions.StringToUShort(ref componentBufferStruct.userName, this.Main.ActualUser, this.Main.ActualUser.Length + 1);
						this.ComponentDataList.RemoveAt(index);
						this.ComponentDataList.Add(componentBufferStruct);
						this.updateMenu(ComponentForm.ITEM_IS_CHANGED, index);
					}
				}
			}
		}

		private void btDelete_Click(object sender, EventArgs e)
		{
			if (this.btDelete.Text == this.Main.Rm.GetString("PrintJournalAndDelete"))
			{
				if (!this.Main.IsOnlineMode)
				{
					MessageBox.Show(this.Main.Rm.GetString("MbNoConnectionToController"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbDeleteMaintenanceJournal"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
					if (dialogResult == DialogResult.Yes)
					{
						this.btPrint_Click(null, EventArgs.Empty);
						this.saveNewestEntries(300);
						this.pnMenu.Enabled = false;
						base.Hide();
						this.Main.MenuMaintenance1.Back();
					}
				}
			}
			else if (this.dGMResults.SelectedRows.Count != 0)
			{
				if (!this.Main.IsOnlineMode)
				{
					MessageBox.Show(this.Main.Rm.GetString("MbNoConnectionToController"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					int index = this.dGMResults.SelectedRows[0].Index;
					this.ComponentDataList.RemoveAt(index);
					this.updateMenu(ComponentForm.ITEM_WAS_DELETED, index);
				}
			}
		}

		private void btAdvanceWarning_Click(object sender, EventArgs e)
		{
			if (this.Main.AreSettingsChanged())
			{
				DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbShouldChangesDiscarded"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);
				if (dialogResult != DialogResult.Yes)
				{
					return;
				}
			}
			this.btCancel_Click(null, EventArgs.Empty);
			this.Main.AdvanceWarning1.ShowWindow();
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
			this.MenEna();
			if (this.Main.GetExclusiveBlock1())
			{
				this.Main.ProcessProgram.UploadAllProgDataFromController();
				this.Main.ProcessProgram.InitializeTempProgStruct();
			}
			this.Cursor = Cursors.WaitCursor;
			this.readDataFromWSP();
			this.updateMenu(ComponentForm.ALL_ITEMS_ARE_NEW, 0);
			if (this.maxSizeOfJounalReached() && this.level1)
			{
				this.btDelete.Text = this.Main.Rm.GetString("PrintJournalAndDelete");
				this.btDelete.Enabled = true;
				this.btDelete.ForeColor = Color.Red;
			}
			else
			{
				this.btDelete.Text = this.Main.Rm.GetString("DeleteEntry");
				this.btDelete.ForeColor = Color.Black;
			}
			this.Cursor = Cursors.Default;
			this.Main.HelpButton = true;
			this.pnMenu.Enabled = true;
			this.Main.SettingsChangedReset();
		}

		public void KeyRemoved()
		{
			this.componentNewForm.Cancel();
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void dGMResults_SelectionChanged(object sender, EventArgs e)
		{
			if (this.dGMResults.SelectedRows.Count == 0)
			{
				this.btEdit.Enabled = false;
				this.btDelete.Enabled = false;
			}
			else if (this.dGMResults.Rows[this.dGMResults.SelectedRows[0].Index].Cells[0].Style.BackColor == ComponentForm.UNSAVED_BACKGROUND_COLOR)
			{
				this.btEdit.Enabled = true;
				this.btDelete.Enabled = true;
			}
			else
			{
				this.dGMResults.Rows[this.dGMResults.SelectedRows[0].Index].Selected = false;
				this.btEdit.Enabled = false;
				this.btDelete.Enabled = false;
			}
		}

		private void dGMResults_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			if (this.dGMResults.SelectedRows.Count != 0 && !(this.dGMResults.Rows[this.dGMResults.SelectedRows[0].Index].Cells[0].Style.BackColor != Color.LightGreen))
			{
				this.btEdit_Click(null, EventArgs.Empty);
			}
		}

		private void dGMResults_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
		{
			if (this.dGMResults.Rows[e.RowIndex].Selected && this.dGMResults.Rows[e.RowIndex].Cells[0].Style.BackColor == Color.LightGreen)
			{
				using (Pen pen = new Pen(Color.Red))
				{
					int num = 2;
					pen.Width = (float)num;
					int x = e.RowBounds.Left + num / 2;
					int y = e.RowBounds.Top + num / 2;
					int width = e.RowBounds.Width - num;
					int height = e.RowBounds.Height - num;
					e.Graphics.DrawRectangle(pen, x, y, width, height);
				}
			}
		}

		private void dGMResults_MouseDown(object sender, MouseEventArgs e)
		{
			if (this.dGMResults.SelectedRows.Count > 0)
			{
				this.dGMResults.Rows[this.dGMResults.SelectedRows[0].Index].Selected = false;
				Application.DoEvents();
			}
		}
	}
}
