using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class TopTenForm : Form
	{
		private class errorCodeCountStruct
		{
			public int Pointer;

			public uint Code;

			public int CodeCount;

			public DateTime Dt;

			public ushort Type;

			public uint CycNum;

			public errorCodeCountStruct(uint code)
			{
				this.Code = code;
				this.CodeCount = 1;
				this.Pointer = 0;
			}
		}

		private MainForm Main;

		private int PrintPos;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Container components;

		private Button btTopToggle;

		private Button btLoad;

		private Button bt2;

		private Button btPrint;

		private PrintDocument printDocument;

		private PrintDialog printDialog;

		private Button btExport;

		private SaveFileDialog SFD;

		private DataGrid_Specific_Class LogGrid;

		private DataGridTableStyle Ts;

		private DataTable LogData;

		private Label label1;

		private Button btBrowser;

		private string[] ColumnName;

		private bool isTopTenActive = true;

		public TopTenForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.LogGrid = new DataGrid_Specific_Class(1, base.Controls);
			this.PrintPos = 0;
			this.LogData = new DataTable("TopTen");
			this.ColumnName = new string[5];
			this.ColumnName[0] = "Number";
			this.ColumnName[1] = "Date";
			this.ColumnName[2] = "Message";
			this.ColumnName[3] = "ErrorCode";
			this.ColumnName[4] = "Cycle";
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[0], typeof(int)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[1], typeof(string)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[2], typeof(string)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[3], typeof(uint)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[4], typeof(uint)));
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btBrowser = new Button();
			this.btPrint = new Button();
			this.btExport = new Button();
			this.btLoad = new Button();
			this.bt2 = new Button();
			this.btTopToggle = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.printDocument = new PrintDocument();
			this.printDialog = new PrintDialog();
			this.SFD = new SaveFileDialog();
			this.label1 = new Label();
			this.pnMenu.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btBrowser);
			this.pnMenu.Controls.Add(this.btPrint);
			this.pnMenu.Controls.Add(this.btExport);
			this.pnMenu.Controls.Add(this.btLoad);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.btTopToggle);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btBrowser.Enabled = false;
			this.btBrowser.Location = new Point(3, 323);
			this.btBrowser.Name = "btBrowser";
			this.btBrowser.Size = new Size(74, 62);
			this.btBrowser.TabIndex = 11;
			this.btBrowser.Click += this.btBrowser_Click;
			this.btPrint.Location = new Point(3, 451);
			this.btPrint.Name = "btPrint";
			this.btPrint.Size = new Size(74, 62);
			this.btPrint.TabIndex = 7;
			this.btPrint.Text = "Print";
			this.btPrint.Click += this.btPrint_Click;
			this.btExport.Location = new Point(3, 387);
			this.btExport.Name = "btExport";
			this.btExport.Size = new Size(74, 62);
			this.btExport.TabIndex = 6;
			this.btExport.Text = "Exportieren";
			this.btExport.Click += this.btExport_Click;
			this.btLoad.Location = new Point(3, 195);
			this.btLoad.Name = "btLoad";
			this.btLoad.Size = new Size(74, 62);
			this.btLoad.TabIndex = 5;
			this.btLoad.Text = "Load again";
			this.btLoad.Click += this.btLoad_Click;
			this.bt2.Enabled = false;
			this.bt2.Location = new Point(3, 259);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 4;
			this.btTopToggle.Location = new Point(3, 131);
			this.btTopToggle.Name = "btTopToggle";
			this.btTopToggle.Size = new Size(74, 62);
			this.btTopToggle.TabIndex = 2;
			this.btTopToggle.Text = "Top All";
			this.btTopToggle.Click += this.btTopToggle_Click;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.printDocument.DocumentName = "LastResults";
			this.printDocument.PrintPage += this.printDocument_PrintPage;
			this.printDialog.Document = this.printDocument;
			this.SFD.Filter = "TopTen|*.txt|All Files|*.*";
			this.label1.AutoSize = true;
			this.label1.Location = new Point(27, 231);
			this.label1.Name = "label1";
			this.label1.Size = new Size(655, 15);
			this.label1.TabIndex = 1;
			this.label1.Text = "DataGrid LogGrid will not be displayed in Editor due to introduction of derived class DataGrid_Specific_Class (DataGrid defined there!)";
			this.label1.Visible = false;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.pnMenu);
			base.Controls.Add(this.label1);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "TopTenForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Auswertung/FehlerLogbuch/Top Ten";
			base.Activated += this.TopTenForm_Activated;
			this.pnMenu.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public bool ShowWindow()
		{
			this.btBrowser.Enabled = Settings.Default.IntegratedMachineVisu;
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.Main.ActivationBrowserGrantedBy = this;
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadLastResults"));
			if (!this.Main.VC.ReceiveVarBlock(86))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive LogBookSysBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("WriteLastResultsTable"));
			this.makeDataSet();
			base.Show();
			Cursor.Current = Cursors.Default;
			this.Main.StatusBarText(string.Empty);
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuAnalysis") + "/" + this.Main.Rm.GetString("ErrorLog") + "/" + this.Main.Rm.GetString("TopTen");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btPrint.Text = this.Main.Rm.GetString("Print");
			this.btExport.Text = this.Main.Rm.GetString("ExportTopResults");
			this.printDocument.DocumentName = this.Main.Rm.GetString("TopTen");
			this.btLoad.Text = this.Main.Rm.GetString("btLoad");
			this.btTopToggle.Text = this.Main.Rm.GetString("TopAll");
			this.printDocument.DocumentName = this.Main.Rm.GetString("TopTen");
			this.SFD.Filter = this.Main.Rm.GetString("TopTen") + "|*.txt|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
		}

		private bool calculateTopTen(ref List<errorCodeCountStruct> errorCont)
		{
			errorCont.Clear();
			int num = (int)(this.Main.VC.PlcLogBookSys.Position - 1);
			int num2 = 0;
			for (int i = 0; i < this.Main.VC.PlcLogBookSys.Length; i++)
			{
				if (num < 0)
				{
					num = 2499;
				}
				WSP1_VarComm.PlcLogMessageStruct plcLogMessageStruct = this.Main.VC.PlcLogBookSys.plcLogMessBuffer[num];
				if (plcLogMessageStruct.Type != 17 && plcLogMessageStruct.Type != 19)
				{
					num--;
				}
				else if (plcLogMessageStruct.Type == 0 && (plcLogMessageStruct.Code == 300001 || plcLogMessageStruct.Code == 300000 || plcLogMessageStruct.Code == 100000))
				{
					num--;
				}
				else
				{
					bool flag = false;
					for (int j = 0; j < errorCont.Count; j++)
					{
						if (errorCont[j].Code == plcLogMessageStruct.Code)
						{
							flag = true;
							errorCont[j].CodeCount++;
						}
					}
					if (!flag)
					{
						errorCodeCountStruct errorCodeCountStruct = new errorCodeCountStruct(plcLogMessageStruct.Code);
						errorCodeCountStruct.Pointer = num;
						errorCodeCountStruct.Type = plcLogMessageStruct.Type;
						errorCodeCountStruct.CycNum = plcLogMessageStruct.cycNum;
						try
						{
							errorCodeCountStruct.Dt = new DateTime(plcLogMessageStruct.Time.Year, plcLogMessageStruct.Time.Month, plcLogMessageStruct.Time.Day, plcLogMessageStruct.Time.Hour, plcLogMessageStruct.Time.Minute, plcLogMessageStruct.Time.Second);
						}
						catch
						{
							errorCodeCountStruct.Dt = new DateTime(1, 1, 1, 0, 0, 0);
						}
						errorCont.Add(errorCodeCountStruct);
					}
					num--;
					num2++;
				}
			}
			errorCont.Sort(TopTenForm.compareErrorCounts);
			if (this.isTopTenActive && errorCont.Count > 10)
			{
				int count = errorCont.Count;
				for (int k = 10; k < count; k++)
				{
					errorCont.RemoveAt(10);
				}
				return true;
			}
			if (this.isTopTenActive)
			{
				return false;
			}
			return true;
		}

		private static int compareErrorCounts(errorCodeCountStruct x, errorCodeCountStruct y)
		{
			if (x.CodeCount > y.CodeCount)
			{
				return -1;
			}
			if (x.CodeCount < y.CodeCount)
			{
				return 1;
			}
			return 0;
		}

		public void makeDataSet()
		{
			string empty = string.Empty;
			string empty2 = string.Empty;
			string empty3 = string.Empty;
			int num = this.Main.VC.LogBookSys.logMessBuffer[0].userName.Length;
			int num2 = this.ColumnName.Length;
			int[] array = new int[num2];
			for (int i = 0; i < num2; i++)
			{
				array[i] = 0;
			}
			this.LogData.Clear();
			Graphics graphics = this.LogGrid.CreateGraphics();
			uint position = this.Main.VC.PlcLogBookSys.Position;
			uint length = this.Main.VC.PlcLogBookSys.Length;
			int num3 = (int)(this.Main.VC.PlcLogBookSys.Position - 1);
			int num4 = 0;
			List<errorCodeCountStruct> list = new List<errorCodeCountStruct>();
			this.btTopToggle.Enabled = this.calculateTopTen(ref list);
			for (num4 = 0; num4 < list.Count; num4++)
			{
				DataRow row = this.LogData.NewRow();
				this.LogData.Rows.Add(row);
				this.LogData.Rows[num4][this.ColumnName[0]] = list[num4].CodeCount;
				string text = "A" + this.LogData.Rows[num4][this.ColumnName[0]].ToString();
				int num5 = (int)Math.Ceiling((double)graphics.MeasureString(text, this.LogGrid.Font).Width);
				if (num5 > array[0])
				{
					array[0] = num5;
				}
				string text2 = list[num4].Dt.ToString(Settings.Default.TimeSet);
				this.LogData.Rows[num4][this.ColumnName[1]] = text2;
				text = "AA" + text2;
				num5 = (int)Math.Ceiling((double)graphics.MeasureString(text, this.LogGrid.Font).Width);
				if (num5 > array[1])
				{
					array[1] = num5;
				}
				switch (list[num4].Type)
				{
				case 16:
				case 17:
				case 18:
					text = this.Main.GetVisuError(list[num4].Code);
					break;
				case 19:
					text = this.Main.Rm.GetString("LogBookMessage100000");
					break;
				default:
					text = string.Empty;
					break;
				}
				this.LogData.Rows[num4][this.ColumnName[2]] = text;
				num5 = (int)Math.Ceiling((double)graphics.MeasureString(text + "A", this.LogGrid.Font).Width);
				if (num5 > array[2])
				{
					array[2] = num5;
				}
				this.LogData.Rows[num4][this.ColumnName[3]] = list[num4].Code;
				num5 = (int)Math.Ceiling((double)graphics.MeasureString(this.LogData.Rows[num4][this.ColumnName[3]].ToString() + "A", this.LogGrid.Font).Width);
				if (num5 > array[3])
				{
					array[3] = num5;
				}
				this.LogData.Rows[num4][this.ColumnName[4]] = list[num4].CycNum;
				text = "A" + this.LogData.Rows[num4]["Cycle"].ToString();
				num5 = (int)Math.Ceiling((double)graphics.MeasureString(text, this.LogGrid.Font).Width);
				if (num5 > array[4])
				{
					array[4] = num5;
				}
				num3--;
			}
			this.LogGrid.DataSource = this.LogData;
			this.LogGrid.Columns[0].HeaderText = this.Main.Rm.GetString("CurveResultNumber");
			this.LogGrid.Columns[1].HeaderText = this.Main.Rm.GetString("RecentDateTime");
			this.LogGrid.Columns[2].HeaderText = this.Main.Rm.GetString("Message");
			this.LogGrid.Columns[3].HeaderText = this.Main.Rm.GetString("ErrorCode");
			this.LogGrid.Columns[4].HeaderText = this.Main.Rm.GetString("Cycle");
			this.LogGrid.Columns[1].ReadOnly = true;
			for (int i = 0; i < num2; i++)
			{
				if (i == 2)
				{
					array[i] = 450;
				}
				else
				{
					int num5 = (int)Math.Ceiling((double)graphics.MeasureString(this.LogGrid.Columns[i].HeaderText + new string('a', 1), this.LogGrid.Font).Width);
					if (num5 > array[i])
					{
						array[i] = num5;
					}
				}
				this.LogGrid.Columns[i].Width = array[i];
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_2_5_1_Top_Ten_Liste";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_2_5_1_Top_Ten_Liste");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void TopTenForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void btPrint_Click(object sender, EventArgs e)
		{
			if (this.printDialog.ShowDialog() == DialogResult.OK)
			{
				this.printDocument.DefaultPageSettings.Margins.Bottom = 50;
				this.printDocument.DefaultPageSettings.Margins.Left = 50;
				this.printDocument.DefaultPageSettings.Margins.Right = 50;
				this.printDocument.DefaultPageSettings.Margins.Top = 50;
				this.printDocument.Print();
			}
		}

		private void printDocument_PrintPage(object sender, PrintPageEventArgs e)
		{
			float num = 0f;
			float num2 = 0f;
			float num3 = 0f;
			float num4 = 0f;
			int count = this.LogData.Columns.Count;
			float[] array = new float[count + 1];
			string empty = string.Empty;
			DateTime now = DateTime.Now;
			Graphics graphics = e.Graphics;
			float num5 = (float)e.MarginBounds.Left;
			float x = (float)e.MarginBounds.Right;
			float num6 = (float)e.MarginBounds.Bottom;
			float num7 = (float)e.MarginBounds.Top;
			Font font = new Font("Arial", 11f, FontStyle.Bold);
			Pen pen = new Pen(Brushes.Black);
			for (int i = 0; i < count; i++)
			{
				array[i] = (float)this.LogGrid.Columns[i].Width;
				num += array[i];
			}
			num3 = (float)e.MarginBounds.Width / num;
			Font font2 = new Font("Arial Unicode MS", 11f * num3, GraphicsUnit.Pixel);
			num = num5;
			for (int i = 0; i <= count; i++)
			{
				num4 = num;
				num += array[i] * num3;
				array[i] = num4;
			}
			num2 = num7;
			if (this.PrintPos <= 0)
			{
				empty = this.Main.Rm.GetString("TopTen") + " (" + now.ToString(Settings.Default.TimeSet) + "):";
				graphics.DrawString(empty, font, Brushes.Black, new RectangleF((float)e.MarginBounds.Left, num2, (float)e.MarginBounds.Width, (float)e.MarginBounds.Bottom - num2));
				num2 += font.GetHeight();
				this.PrintPos = -1;
			}
			num7 = num2;
			num = num5;
			graphics.DrawLine(pen, num5, num2, x, num2);
			for (int i = this.PrintPos; i < this.LogData.Rows.Count; i++)
			{
				if (i == -1)
				{
					for (int j = 0; j < count; j++)
					{
						string headerText = this.LogGrid.Columns[j].HeaderText;
						graphics.DrawString(headerText, font2, Brushes.Black, array[j], num2);
					}
				}
				else
				{
					for (int j = 0; j < count; j++)
					{
						string headerText = this.LogData.Rows[i][this.ColumnName[j]].ToString();
						graphics.DrawString(headerText, font2, Brushes.Black, array[j], num2);
					}
				}
				num2 += font2.GetHeight();
				graphics.DrawLine(pen, num5, num2, x, num2);
				if (num2 > num6)
				{
					if (this.LogData.Rows.Count - i > 1)
					{
						this.PrintPos = i + 1;
					}
					break;
				}
				this.PrintPos = 0;
			}
			graphics.DrawLine(pen, num, num7, num, num2);
			for (int i = 0; i <= count; i++)
			{
				graphics.DrawLine(pen, array[i], num7, array[i], num2);
			}
			font2.Dispose();
			font.Dispose();
			if (this.PrintPos > 0)
			{
				e.HasMorePages = true;
			}
		}

		private void btExport_Click(object sender, EventArgs e)
		{
			string empty = string.Empty;
			CultureInfo invariantCulture = CultureInfo.InvariantCulture;
			DialogResult dialogResult = this.SFD.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				try
				{
					StreamWriter streamWriter = new StreamWriter(this.SFD.FileName);
					empty = this.LogGrid.Columns[0].HeaderText;
					for (int i = 1; i < this.ColumnName.GetLength(0); i++)
					{
						empty = empty + ";" + this.LogGrid.Columns[i].HeaderText;
					}
					streamWriter.WriteLine(empty);
					for (int j = 0; j < this.LogData.Rows.Count; j++)
					{
						empty = this.LogData.Rows[j][0].ToString();
						for (int i = 1; i < this.ColumnName.GetLength(0); i++)
						{
							empty = empty + ";" + this.LogData.Rows[j][i].ToString();
						}
						streamWriter.WriteLine(empty);
					}
					streamWriter.Close();
					streamWriter.Dispose();
				}
				catch (Exception ex)
				{
					MessageBox.Show("Could not open file! " + ex.Message, "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btTopToggle_Click(object sender, EventArgs e)
		{
			if (this.isTopTenActive)
			{
				this.isTopTenActive = false;
				this.btTopToggle.Text = this.Main.Rm.GetString("TopTen");
			}
			else
			{
				this.isTopTenActive = true;
				this.btTopToggle.Text = this.Main.Rm.GetString("TopAll");
			}
			this.makeDataSet();
		}

		private void btLoad_Click(object sender, EventArgs e)
		{
			if (this.Main.IsOnlineMode)
			{
				if (!this.Main.VC.ReceiveVarBlock(86))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not receive LogBookSysBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.makeDataSet();
				}
			}
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
			this.BrowserShow();
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}
	}
}
