using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;
using WUSB_KeyVerwaltung;

namespace Visualisation
{
	public class USB_PasswordForm : Form
	{
		public const int PASSWORD_INIT = 0;

		public const int PASSWORD_CHANGED = 1;

		public const int PASSWORD_OK = 2;

		public const int USER_CANCELED = 3;

		public const int SYSTEM_ABORTED = 4;

		public const int USER_WITHOUT_PASSWORD = 5;

		private MainForm Main;

		private string drive = "";

		private string usb_MD5_Passcode;

		private string usb_user_id;

		private int NESelectionStart;

		private uint Number;

		private string OldText;

		public int AccessMode;

		private Label lbPassword;

		private Button btLogin;

		private Button btCancel;

		private Button btClear;

		private Button bt3;

		private Button bt0;

		private Button bt2;

		private Button bt1;

		private Button bt6;

		private Button bt5;

		private Button bt4;

		private Button bt9;

		private Button bt8;

		private Button bt7;

		private TextBox tBLogin;

		private Button btChangePassCode;

		private Button btGoWithoutPassCode;

		private Container components;

		private bool changedPasswordOnDisk;

		private USB_ChangePasswordForm changePasswordForm;

		public string Drive
		{
			set
			{
				this.drive = value;
			}
		}

		public string Usb_MD5_Passcode
		{
			set
			{
				this.usb_MD5_Passcode = value;
			}
		}

		public string Usb_user_id
		{
			set
			{
				this.usb_user_id = value;
			}
		}

		public bool ChangedPasswordOnDisk => this.changedPasswordOnDisk;

		public USB_PasswordForm(MainForm main, string _usb_MD5_Passcode, string _usb_user_id, string _drive)
		{
			this.Main = main;
			this.drive = _drive;
			this.initForm(_usb_MD5_Passcode, _usb_user_id);
		}

		public USB_PasswordForm(MainForm main, string _drive)
		{
			this.Main = main;
			this.drive = _drive;
			this.initForm("", "");
		}

		private void initForm(string _usb_MD5_Passcode, string _usb_user_id)
		{
			this.usb_MD5_Passcode = _usb_MD5_Passcode;
			this.usb_user_id = _usb_user_id;
			this.InitializeComponent();
			this.AccessMode = 0;
			this.tBLogin.MaxLength = 5;
			this.NESelectionStart = 0;
			this.Number = 0u;
			this.OldText = string.Empty;
			this.AccessMode = 0;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.lbPassword = new Label();
			this.btLogin = new Button();
			this.btCancel = new Button();
			this.tBLogin = new TextBox();
			this.btClear = new Button();
			this.bt3 = new Button();
			this.bt0 = new Button();
			this.bt2 = new Button();
			this.bt1 = new Button();
			this.bt6 = new Button();
			this.bt5 = new Button();
			this.bt4 = new Button();
			this.bt9 = new Button();
			this.bt8 = new Button();
			this.bt7 = new Button();
			this.btChangePassCode = new Button();
			this.btGoWithoutPassCode = new Button();
			base.SuspendLayout();
			this.lbPassword.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbPassword.Location = new Point(16, 16);
			this.lbPassword.Name = "lbPassword";
			this.lbPassword.Size = new Size(120, 23);
			this.lbPassword.TabIndex = 5;
			this.lbPassword.Text = "Kennwort";
			this.lbPassword.TextAlign = ContentAlignment.MiddleLeft;
			this.btLogin.Enabled = false;
			this.btLogin.Location = new Point(208, 248);
			this.btLogin.Name = "btLogin";
			this.btLogin.Size = new Size(120, 56);
			this.btLogin.TabIndex = 13;
			this.btLogin.Text = "Enter";
			this.btLogin.Click += this.btLogin_Click;
			this.btCancel.Location = new Point(208, 120);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(120, 56);
			this.btCancel.TabIndex = 12;
			this.btCancel.Text = "Abbrechen";
			this.btCancel.Click += this.btCancel_Click;
			this.tBLogin.Font = new Font("Microsoft Sans Serif", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.tBLogin.Location = new Point(144, 15);
			this.tBLogin.MaxLength = 5;
			this.tBLogin.Name = "tBLogin";
			this.tBLogin.PasswordChar = '*';
			this.tBLogin.Size = new Size(120, 24);
			this.tBLogin.TabIndex = 0;
			this.tBLogin.Text = "Password";
			this.tBLogin.TextChanged += this.tBNewValue_TextChanged;
			this.tBLogin.KeyPress += this.USB_PasswordForm_KeyPress;
			this.tBLogin.KeyUp += this.tBNewValue_KeyUp;
			this.tBLogin.MouseDown += this.tBNewValue_MouseDown;
			this.btClear.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btClear.Location = new Point(72, 248);
			this.btClear.Name = "btClear";
			this.btClear.Size = new Size(56, 56);
			this.btClear.TabIndex = 11;
			this.btClear.Tag = "{BS}";
			this.btClear.Text = "C";
			this.btClear.Click += this.numberKey_Click;
			this.bt3.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt3.Location = new Point(136, 184);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(56, 56);
			this.bt3.TabIndex = 9;
			this.bt3.Tag = "3";
			this.bt3.Text = "3";
			this.bt3.Click += this.numberKey_Click;
			this.bt0.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt0.Location = new Point(8, 248);
			this.bt0.Name = "bt0";
			this.bt0.Size = new Size(56, 56);
			this.bt0.TabIndex = 10;
			this.bt0.Tag = "0";
			this.bt0.Text = "0";
			this.bt0.Click += this.numberKey_Click;
			this.bt2.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt2.Location = new Point(72, 184);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(56, 56);
			this.bt2.TabIndex = 8;
			this.bt2.Tag = "2";
			this.bt2.Text = "2";
			this.bt2.Click += this.numberKey_Click;
			this.bt1.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt1.Location = new Point(8, 184);
			this.bt1.Name = "bt1";
			this.bt1.Size = new Size(56, 56);
			this.bt1.TabIndex = 7;
			this.bt1.Tag = "1";
			this.bt1.Text = "1";
			this.bt1.Click += this.numberKey_Click;
			this.bt6.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt6.Location = new Point(136, 120);
			this.bt6.Name = "bt6";
			this.bt6.Size = new Size(56, 56);
			this.bt6.TabIndex = 6;
			this.bt6.Tag = "6";
			this.bt6.Text = "6";
			this.bt6.Click += this.numberKey_Click;
			this.bt5.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt5.Location = new Point(72, 120);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(56, 56);
			this.bt5.TabIndex = 5;
			this.bt5.Tag = "5";
			this.bt5.Text = "5";
			this.bt5.Click += this.numberKey_Click;
			this.bt4.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt4.Location = new Point(8, 120);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(56, 56);
			this.bt4.TabIndex = 4;
			this.bt4.Tag = "4";
			this.bt4.Text = "4";
			this.bt4.Click += this.numberKey_Click;
			this.bt9.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt9.Location = new Point(136, 56);
			this.bt9.Name = "bt9";
			this.bt9.Size = new Size(56, 56);
			this.bt9.TabIndex = 3;
			this.bt9.Tag = "9";
			this.bt9.Text = "9";
			this.bt9.Click += this.numberKey_Click;
			this.bt8.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt8.Location = new Point(72, 56);
			this.bt8.Name = "bt8";
			this.bt8.Size = new Size(56, 56);
			this.bt8.TabIndex = 2;
			this.bt8.Tag = "8";
			this.bt8.Text = "8";
			this.bt8.Click += this.numberKey_Click;
			this.bt7.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt7.Location = new Point(8, 56);
			this.bt7.Name = "bt7";
			this.bt7.Size = new Size(56, 56);
			this.bt7.TabIndex = 1;
			this.bt7.Tag = "7";
			this.bt7.Text = "7";
			this.bt7.Click += this.numberKey_Click;
			this.btChangePassCode.Location = new Point(208, 56);
			this.btChangePassCode.Name = "btChangePassCode";
			this.btChangePassCode.Size = new Size(120, 56);
			this.btChangePassCode.TabIndex = 14;
			this.btChangePassCode.Text = "Passwort ändern";
			this.btChangePassCode.Click += this.btChangePassCode_Click;
			this.btGoWithoutPassCode.Location = new Point(208, 184);
			this.btGoWithoutPassCode.Name = "btGoWithoutPassCode";
			this.btGoWithoutPassCode.Size = new Size(120, 56);
			this.btGoWithoutPassCode.TabIndex = 15;
			this.btGoWithoutPassCode.Text = "Weiter ohne Passwort";
			this.btGoWithoutPassCode.Click += this.btGoWithoutPassCode_Click;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(338, 310);
			base.ControlBox = false;
			base.Controls.Add(this.btGoWithoutPassCode);
			base.Controls.Add(this.btChangePassCode);
			base.Controls.Add(this.btClear);
			base.Controls.Add(this.bt3);
			base.Controls.Add(this.bt0);
			base.Controls.Add(this.bt2);
			base.Controls.Add(this.bt1);
			base.Controls.Add(this.bt6);
			base.Controls.Add(this.bt5);
			base.Controls.Add(this.bt4);
			base.Controls.Add(this.bt9);
			base.Controls.Add(this.bt8);
			base.Controls.Add(this.bt7);
			base.Controls.Add(this.tBLogin);
			base.Controls.Add(this.btCancel);
			base.Controls.Add(this.btLogin);
			base.Controls.Add(this.lbPassword);
			this.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "USB_PasswordForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "USB Passwort";
			base.TopMost = true;
			base.Activated += this.USB_PasswordForm_Activated;
			base.Shown += this.USB_PasswordForm_Shown;
			base.KeyPress += this.USB_PasswordForm_KeyPress;
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public void Cancel()
		{
			this.AccessMode = 4;
			if (this.changePasswordForm != null)
			{
				this.changePasswordForm.Cancel();
			}
			base.Hide();
		}

		public void ShowWindow(bool testmode)
		{
			if (testmode)
			{
				this.btChangePassCode.Enabled = false;
			}
			else
			{
				this.btChangePassCode.Enabled = true;
			}
			this.Number = 0u;
			this.tBLogin.Text = string.Empty;
			this.btLogin.Enabled = false;
			this.NESelectionStart = 0;
			this.tBLogin.Select();
			this.AccessMode = 0;
			base.ShowDialog();
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("UsbPasswordInput") + " " + this.usb_user_id;
			this.btCancel.Text = this.Main.Rm.GetString("Cancel");
			this.btLogin.Text = this.Main.Rm.GetString("Login");
			this.btChangePassCode.Text = this.Main.Rm.GetString("ChangePassCode");
			this.btGoWithoutPassCode.Text = this.Main.Rm.GetString("GoWithoutPassCode");
			this.lbPassword.Text = this.Main.Rm.GetString("Password");
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.Main.ResetPasscodeLevel();
			this.AccessMode = 3;
			base.Hide();
		}

		private void btGoWithoutPassCode_Click(object sender, EventArgs e)
		{
			this.Main.ResetPasscodeLevel();
			this.AccessMode = 5;
			base.Hide();
		}

		private void btLogin_Click(object sender, EventArgs e)
		{
			this.Login();
		}

		private void Login()
		{
			this.Main.ResetPasscodeLevel();
			if (this.Number != 0 && this.Number == 14142)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbWrongPassword"), this.Main.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				this.tBLogin.Text = string.Empty;
				this.tBLogin.Focus();
			}
			else if (this.usb_MD5_Passcode == MD5HashClass.MD5Hash(this.tBLogin.Text))
			{
				this.AccessMode = 2;
				base.Hide();
			}
			else
			{
				MessageBox.Show(this.Main.Rm.GetString("MbWrongPassword"), this.Main.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				this.tBLogin.Text = string.Empty;
				this.tBLogin.Focus();
			}
		}

		private void USB_PasswordForm_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == '\r')
			{
				this.Login();
			}
		}

		private void numberKey_Click(object sender, EventArgs e)
		{
			string text = base.ActiveControl.Tag.ToString();
			this.tBLogin.Focus();
			this.tBLogin.Select(this.NESelectionStart, 0);
			if (this.Main.CommonFunctions.GetCapsLockState())
			{
				MessageBox.Show(this.Main.Rm.GetString("MbKeyLockActive"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else if (text == "{BS}")
			{
				if (this.NESelectionStart > 0)
				{
					this.tBLogin.Text = this.tBLogin.Text.Remove(this.NESelectionStart - 1, 1);
				}
			}
			else
			{
				this.tBLogin.Text = this.tBLogin.Text.Substring(0, this.NESelectionStart) + text + this.tBLogin.Text.Substring(this.NESelectionStart);
			}
		}

		private void tBNewValue_TextChanged(object sender, EventArgs e)
		{
			if (!(this.tBLogin.Text == this.OldText))
			{
				if (this.tBLogin.Text.Length > this.tBLogin.MaxLength)
				{
					this.tBLogin.Text = this.OldText;
					this.tBLogin.SelectionStart = this.NESelectionStart;
				}
				else
				{
					if (this.tBLogin.Text.Length == 0)
					{
						this.btLogin.Enabled = false;
					}
					else
					{
						this.btLogin.Enabled = true;
					}
					if (!this.NumberCheck())
					{
						this.tBLogin.ForeColor = Color.Red;
					}
					else
					{
						this.tBLogin.ForeColor = Color.Black;
					}
				}
			}
		}

		private bool NumberCheck()
		{
			string numberDecimalSeparator = Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;
			char c = numberDecimalSeparator[0];
			this.tBLogin.Text.Trim();
			if (this.tBLogin.Text.Length < this.OldText.Length)
			{
				if (this.tBLogin.SelectionStart == 0 && this.NESelectionStart > 0)
				{
					this.tBLogin.SelectionStart = this.NESelectionStart - 1;
				}
				this.NESelectionStart = this.tBLogin.SelectionStart;
			}
			else if (this.tBLogin.Text == this.OldText)
			{
				this.tBLogin.SelectionStart = this.NESelectionStart;
			}
			else
			{
				this.tBLogin.SelectionStart = this.NESelectionStart + 1;
			}
			try
			{
				this.Number = uint.Parse(this.tBLogin.Text, NumberStyles.Integer);
				this.OldText = this.tBLogin.Text;
			}
			catch
			{
				if (this.tBLogin.Text == string.Empty)
				{
					this.OldText = string.Empty;
					this.NESelectionStart = 0;
					return false;
				}
				this.tBLogin.Text = this.OldText;
				this.tBLogin.SelectionStart = this.NESelectionStart;
			}
			this.NESelectionStart = this.tBLogin.SelectionStart;
			return true;
		}

		private void tBNewValue_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode != Keys.Left && e.KeyCode != Keys.Right)
			{
				return;
			}
			this.NESelectionStart = this.tBLogin.SelectionStart;
		}

		private void tBNewValue_MouseDown(object sender, MouseEventArgs e)
		{
			this.NESelectionStart = this.tBLogin.SelectionStart;
		}

		private void btChangePassCode_Click(object sender, EventArgs e)
		{
			bool topMost = base.TopMost;
			base.TopMost = false;
			this.changePasswordForm = new USB_ChangePasswordForm(this.Main, 4, this.usb_MD5_Passcode);
			this.changePasswordForm.ShowDialog();
			if (this.changePasswordForm.Result == 1)
			{
				UserKeyfileStruct userKeyfileStruct = new UserKeyfileStruct();
				UsbFileSystemClass usbFileSystemClass = new UsbFileSystemClass();
				if (usbFileSystemClass.ReadUsbKeyFile(this.drive, ref userKeyfileStruct, out DateTime dateTime))
				{
					string text = userKeyfileStruct.Password = this.changePasswordForm.NewPassword;
					this.changedPasswordOnDisk = true;
					if (usbFileSystemClass.WriteUsbKeyFile(this.drive, userKeyfileStruct, out dateTime))
					{
						MessageBox.Show(this, this.Main.Rm.GetString("MbPasswordSavedOnUsbKey"), this.Main.Rm.GetString("Password"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						this.AccessMode = 2;
						base.Hide();
					}
					else
					{
						MessageBox.Show(this, this.Main.Rm.GetString("MbUsbKeySaveFailure"), this.Main.Rm.GetString("Password"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					this.changedPasswordOnDisk = false;
				}
				else
				{
					MessageBox.Show(this, this.Main.Rm.GetString("MbUsbKeyReadFailure"), this.Main.Rm.GetString("Password"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			else
			{
				int result = this.changePasswordForm.Result;
			}
			base.TopMost = topMost;
			this.changePasswordForm = null;
		}

		private void USB_PasswordForm_Shown(object sender, EventArgs e)
		{
			this.tBLogin.Text = "";
		}

		private void USB_PasswordForm_Activated(object sender, EventArgs e)
		{
			this.Text = this.Main.Rm.GetString("UsbPasswordInput") + " " + this.usb_user_id;
		}
	}
}
