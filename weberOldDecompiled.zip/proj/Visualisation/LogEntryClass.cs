namespace Visualisation
{
	internal class LogEntryClass
	{
		public byte LogLevel;

		public uint ElementIndex;

		public int LogIdentifier;

		public LogEntryClass(byte logLevel, uint elementIndex, int logIdentifier)
		{
			this.LogLevel = logLevel;
			this.ElementIndex = elementIndex;
			this.LogIdentifier = logIdentifier;
		}
	}
}
