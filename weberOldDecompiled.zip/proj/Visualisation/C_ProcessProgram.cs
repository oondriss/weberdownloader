using System;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class C_ProcessProgram
	{
		private MainForm Main;

		public WSP1_VarComm.PProg_Struct TempProgStruct;

		private OpenFileDialog openFileDialog;

		private SaveFileDialog saveFileDialog;

		private OpenFileDialog openSingleFileDialog;

		private SaveFileDialog saveSingleFileDialog;

		public C_ProcessProgram(MainForm main)
		{
			this.Main = main;
			this.TempProgStruct = this.NewInitializedProgStruct();
			this.openFileDialog = new OpenFileDialog();
			this.openFileDialog.Filter = this.Main.Rm.GetString("ScrewProgramFiles") + "|*.wprg|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.saveFileDialog = new SaveFileDialog();
			this.saveFileDialog.Filter = this.Main.Rm.GetString("ScrewProgramFiles") + "|*.wprg|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.openSingleFileDialog = new OpenFileDialog();
			this.openSingleFileDialog.Filter = this.Main.Rm.GetString("ScrewProgramFilesSingular") + "|*.wspg|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.saveSingleFileDialog = new SaveFileDialog();
			this.saveSingleFileDialog.Filter = this.Main.Rm.GetString("ScrewProgramFilesSingular") + "|*.wspg|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
		}

		public void SetLanguageTexts()
		{
			this.openFileDialog.Filter = this.Main.Rm.GetString("ScrewProgramFiles") + "|*.wprg|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.saveFileDialog.Filter = this.Main.Rm.GetString("ScrewProgramFiles") + "|*.wprg|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.openSingleFileDialog.Filter = this.Main.Rm.GetString("ScrewProgramFilesSingular") + "|*.wspg|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.saveSingleFileDialog.Filter = this.Main.Rm.GetString("ScrewProgramFilesSingular") + "|*.wspg|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
		}

		public WSP1_VarComm.StepStruct NewInitializedStep()
		{
			WSP1_VarComm.StepStruct stepStruct = new WSP1_VarComm.StepStruct();
			stepStruct.AnaMax = 0f;
			stepStruct.AnaMin = 0f;
			stepStruct.AnaP = 0f;
			stepStruct.CountPassMax = 0;
			stepStruct.DigMax = 0;
			stepStruct.DigMin = 0;
			stepStruct.DigP = 0;
			stepStruct.Enable = new WSP1_VarComm.EnableParamStruct();
			stepStruct.Enable.ADepth = 0;
			stepStruct.Enable.ADepthGradMax = 0;
			stepStruct.Enable.ADepthGradMin = 0;
			stepStruct.Enable.Ana = 0;
			stepStruct.Enable.Angle = 0;
			stepStruct.Enable.FTorque = 0;
			stepStruct.Enable.GradientMin = 0;
			stepStruct.Enable.GradientMax = 0;
			stepStruct.Enable.Release = 0;
			stepStruct.Enable.Snug = 0;
			stepStruct.Enable.Time = 0;
			stepStruct.Enable.Torque = 0;
			stepStruct.IsResult1 = 0;
			stepStruct.IsResult2 = 0;
			stepStruct.IsResult3 = 0;
			stepStruct.JumpTo = 0;
			stepStruct.LGmax = 0f;
			stepStruct.LGmin = 0f;
			stepStruct.LGP = 0f;
			stepStruct.Lmax = 0f;
			stepStruct.Lmin = 0f;
			stepStruct.LP = 0f;
			stepStruct.MDelayTime = 0f;
			stepStruct.MFmax = 0f;
			stepStruct.MFmin = 0f;
			stepStruct.MFP = 0f;
			stepStruct.MGmax = 0f;
			stepStruct.MGmin = 0f;
			stepStruct.MGP = 0f;
			stepStruct.Mmax = 0f;
			stepStruct.Mmin = 0f;
			stepStruct.ModDigOut = 1;
			stepStruct.MP = 0f;
			stepStruct.MRP = 0f;
			stepStruct.MRStep = 0;
			stepStruct.MRType = 0;
			stepStruct.MS = 0f;
			stepStruct.NA = 0f;
			stepStruct.Switch = 0;
			stepStruct.PressureSpindle = 0f;
			stepStruct.TM = 0f;
			stepStruct.Tmax = 0f;
			stepStruct.Tmin = 0f;
			stepStruct.TN = 0f;
			stepStruct.TP = 0f;
			stepStruct.Type = 0;
			stepStruct.UserRights = 7;
			stepStruct.Wmax = 0f;
			stepStruct.Wmin = 0f;
			stepStruct.WN = 0f;
			stepStruct.WP = 0f;
			return stepStruct;
		}

		public WSP1_VarComm.ProgStruct NewInitializedProg()
		{
			WSP1_VarComm.ProgStruct progStruct = new WSP1_VarComm.ProgStruct();
			progStruct.ADepthFilterTime = 0f;
			progStruct.ADepthGradientLength = 1;
			progStruct.EndSetDigOut1 = 0;
			progStruct.EndSetDigOut2 = 0;
			progStruct.EndSetSync1 = 0;
			progStruct.EndSetSync2 = 0;
			progStruct.EndValueDigOut1 = 0;
			progStruct.EndValueDigOut2 = 0;
			progStruct.EndValueSync1 = 0;
			progStruct.EndValueSync2 = 0;
			progStruct.GradientFilter = 0;
			progStruct.GradientLength = 1;
			progStruct.M1FilterTime = 0f;
			progStruct.MaxTime = 15f;
			progStruct.Info = new WSP1_VarComm.ProgInfoStruct();
			progStruct.Info.Name = new ushort[32];
			for (int i = 0; i < 32; i++)
			{
				progStruct.Info.Name[i] = 0;
			}
			progStruct.Info.ProgNum = 0u;
			progStruct.Info.ResultParam1 = 1;
			progStruct.Info.ResultParam2 = 1;
			progStruct.Info.ResultParam3 = 1;
			progStruct.Step = new WSP1_VarComm.StepStruct[25];
			progStruct.PressureHolder = 0f;
			for (int i = 0; i < 25; i++)
			{
				progStruct.Step[i] = this.NewInitializedStep();
			}
			progStruct.Info.Steps = 0;
			return progStruct;
		}

		private WSP1_VarComm.PProg_Struct NewInitializedProgStruct()
		{
			WSP1_VarComm.PProg_Struct pProg_Struct = new WSP1_VarComm.PProg_Struct();
			pProg_Struct.Num = new WSP1_VarComm.ProgStruct[1024];
			for (int i = 0; i < 1024; i++)
			{
				pProg_Struct.Num[i] = this.NewInitializedProg();
			}
			return pProg_Struct;
		}

		public void InitializeTempProgStruct()
		{
			this.TempProgStruct = this.NewInitializedProgStruct();
		}

		public bool CopyStep(ref WSP1_VarComm.StepStruct dest, WSP1_VarComm.StepStruct source)
		{
			this.Main.VC.makeCopyStepStruct(ref dest, source);
			return true;
		}

		public bool CopyProg(ref WSP1_VarComm.ProgStruct dest, WSP1_VarComm.ProgStruct source)
		{
			this.Main.VC.makeCopyProgStruct(ref dest, source);
			return true;
		}

		public bool CopyProgStruct(ref WSP1_VarComm.PProg_Struct dest, WSP1_VarComm.PProg_Struct source)
		{
			this.Main.VC.makeCopyPProg(ref dest, source);
			return true;
		}

		public bool CompareStepStruct(WSP1_VarComm.StepStruct dest, WSP1_VarComm.StepStruct source, int programnumber, int snum, byte logLevel)
		{
			uint progNum = this.TempProgStruct.Num[programnumber].Info.ProgNum;
			bool result = false;
			if (dest.NA != source.NA)
			{
				this.Main.MakeLogbookEntry(201145u, 2, source.NA, dest.NA, progNum, snum, 23, logLevel, programnumber);
				result = true;
			}
			if (dest.TM != source.TM)
			{
				this.Main.MakeLogbookEntry(201147u, 2, source.TM, dest.TM, progNum, snum, 21, logLevel, programnumber);
				result = true;
			}
			if (dest.PressureSpindle != source.PressureSpindle)
			{
				byte unit = 17;
				this.Main.MakeLogbookEntry(201158u, 2, source.PressureSpindle, dest.PressureSpindle, progNum, snum, unit, logLevel, programnumber);
				result = true;
			}
			if (dest.Switch != source.Switch)
			{
				this.Main.MakeLogbookEntry(201146u, 2, (float)(int)source.Switch, (float)(int)dest.Switch, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.MP != source.MP)
			{
				this.Main.MakeLogbookEntry(201140u, 2, source.MP, dest.MP, progNum, snum, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque), logLevel, programnumber);
				result = true;
			}
			if (dest.MFP != source.MFP)
			{
				this.Main.MakeLogbookEntry(201132u, 2, source.MFP, dest.MFP, progNum, snum, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque), logLevel, programnumber);
				result = true;
			}
			if (dest.MRP != source.MRP)
			{
				this.Main.MakeLogbookEntry(201141u, 2, source.MRP, dest.MRP, progNum, snum, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque), logLevel, programnumber);
				result = true;
			}
			if (dest.MRStep != source.MRStep)
			{
				this.Main.MakeLogbookEntry(201142u, 2, (float)(source.MRStep + 1), (float)(dest.MRStep + 1), progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.MRType != source.MRType)
			{
				this.Main.MakeLogbookEntry(201143u, 2, (float)(int)source.MRType, (float)(int)dest.MRType, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.MGP != source.MGP)
			{
				this.Main.MakeLogbookEntry(201135u, 2, source.MGP, dest.MGP, progNum, snum, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque), logLevel, programnumber);
				result = true;
			}
			if (dest.WP != source.WP)
			{
				this.Main.MakeLogbookEntry(201157u, 2, source.WP, dest.WP, progNum, snum, 28, logLevel, programnumber);
				result = true;
			}
			if (dest.TP != source.TP)
			{
				this.Main.MakeLogbookEntry(201151u, 2, source.TP, dest.TP, progNum, snum, 21, logLevel, programnumber);
				result = true;
			}
			if (dest.LP != source.LP)
			{
				this.Main.MakeLogbookEntry(201128u, 2, source.LP, dest.LP, progNum, snum, 22, logLevel, programnumber);
				result = true;
			}
			if (dest.LGP != source.LGP)
			{
				this.Main.MakeLogbookEntry(201125u, 2, source.LGP, dest.LGP, progNum, snum, 40, logLevel, programnumber);
				result = true;
			}
			if (dest.AnaP != source.AnaP)
			{
				this.Main.MakeLogbookEntry(201102u, 2, source.AnaP, dest.AnaP, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.DigP != source.DigP)
			{
				this.Main.MakeLogbookEntry(201106u, 2, (float)source.DigP, (float)dest.DigP, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.Tmax != source.Tmax)
			{
				this.Main.MakeLogbookEntry(201148u, 2, source.Tmax, dest.Tmax, progNum, snum, 21, logLevel, programnumber);
				result = true;
			}
			if (dest.IsResult1 != source.IsResult1)
			{
				this.Main.MakeLogbookEntry(201119u, 2, (float)(int)source.IsResult1, (float)(int)dest.IsResult1, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.IsResult2 != source.IsResult2)
			{
				this.Main.MakeLogbookEntry(201120u, 2, (float)(int)source.IsResult2, (float)(int)dest.IsResult2, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.IsResult3 != source.IsResult3)
			{
				this.Main.MakeLogbookEntry(201121u, 2, (float)(int)source.IsResult3, (float)(int)dest.IsResult3, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.MDelayTime != source.MDelayTime)
			{
				this.Main.MakeLogbookEntry(201129u, 2, source.MDelayTime, dest.MDelayTime, progNum, snum, 21, logLevel, programnumber);
				result = true;
			}
			if (dest.TN != source.TN)
			{
				this.Main.MakeLogbookEntry(201150u, 2, source.TN, dest.TN, progNum, snum, 21, logLevel, programnumber);
				result = true;
			}
			if (dest.Enable.Release != source.Enable.Release)
			{
				this.Main.MakeLogbookEntry(201115u, 2, (float)(int)source.Enable.Release, (float)(int)dest.Enable.Release, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.WN != source.WN)
			{
				this.Main.MakeLogbookEntry(201156u, 2, source.WN, dest.WN, progNum, snum, 28, logLevel, programnumber);
				result = true;
			}
			if (dest.Enable.Time != source.Enable.Time)
			{
				this.Main.MakeLogbookEntry(201117u, 2, (float)(int)source.Enable.Time, (float)(int)dest.Enable.Time, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.Tmin != source.Tmin)
			{
				this.Main.MakeLogbookEntry(201149u, 2, source.Tmin, dest.Tmin, progNum, snum, 21, logLevel, programnumber);
				result = true;
			}
			if (dest.Enable.Angle != source.Enable.Angle)
			{
				this.Main.MakeLogbookEntry(201111u, 2, (float)(int)source.Enable.Angle, (float)(int)dest.Enable.Angle, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.Wmin != source.Wmin)
			{
				this.Main.MakeLogbookEntry(201155u, 2, source.Wmin, dest.Wmin, progNum, snum, 1, logLevel, programnumber);
				result = true;
			}
			if (dest.Wmax != source.Wmax)
			{
				this.Main.MakeLogbookEntry(201154u, 2, source.Wmax, dest.Wmax, progNum, snum, 1, logLevel, programnumber);
				result = true;
			}
			if (dest.Enable.Snug != source.Enable.Snug)
			{
				this.Main.MakeLogbookEntry(201116u, 2, (float)(int)source.Enable.Snug, (float)(int)dest.Enable.Snug, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.MS != source.MS)
			{
				this.Main.MakeLogbookEntry(201144u, 2, source.MS, dest.MS, progNum, snum, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque), logLevel, programnumber);
				result = true;
			}
			if (dest.Enable.Torque != source.Enable.Torque)
			{
				this.Main.MakeLogbookEntry(201118u, 2, (float)(int)source.Enable.Torque, (float)(int)dest.Enable.Torque, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.Mmin != source.Mmin)
			{
				this.Main.MakeLogbookEntry(201137u, 2, source.Mmin, dest.Mmin, progNum, snum, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque), logLevel, programnumber);
				result = true;
			}
			if (dest.Mmax != source.Mmax)
			{
				this.Main.MakeLogbookEntry(201136u, 2, source.Mmax, dest.Mmax, progNum, snum, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque), logLevel, programnumber);
				result = true;
			}
			if (dest.Enable.FTorque != source.Enable.FTorque)
			{
				this.Main.MakeLogbookEntry(201112u, 2, (float)(int)source.Enable.FTorque, (float)(int)dest.Enable.FTorque, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.MFmin != source.MFmin)
			{
				this.Main.MakeLogbookEntry(201131u, 2, source.MFmin, dest.MFmin, progNum, snum, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque), logLevel, programnumber);
				result = true;
			}
			if (dest.MFmax != source.MFmax)
			{
				this.Main.MakeLogbookEntry(201130u, 2, source.MFmax, dest.MFmax, progNum, snum, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque), logLevel, programnumber);
				result = true;
			}
			if (dest.Enable.GradientMin != source.Enable.GradientMin)
			{
				this.Main.MakeLogbookEntry(201113u, 2, (float)(int)source.Enable.GradientMin, (float)(int)dest.Enable.GradientMin, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.MGmin != source.MGmin)
			{
				this.Main.MakeLogbookEntry(201134u, 2, source.MGmin, dest.MGmin, progNum, snum, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque), logLevel, programnumber);
				result = true;
			}
			if (dest.Enable.GradientMax != source.Enable.GradientMax)
			{
				this.Main.MakeLogbookEntry(201114u, 2, (float)(int)source.Enable.GradientMax, (float)(int)dest.Enable.GradientMax, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.MGmax != source.MGmax)
			{
				this.Main.MakeLogbookEntry(201133u, 2, source.MGmax, dest.MGmax, progNum, snum, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque), logLevel, programnumber);
				result = true;
			}
			if (dest.Enable.ADepth != source.Enable.ADepth)
			{
				this.Main.MakeLogbookEntry(201107u, 2, (float)(int)source.Enable.ADepth, (float)(int)dest.Enable.ADepth, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.Lmin != source.Lmin)
			{
				this.Main.MakeLogbookEntry(201127u, 2, source.Lmin, dest.Lmin, progNum, snum, 22, logLevel, programnumber);
				result = true;
			}
			if (dest.Lmax != source.Lmax)
			{
				this.Main.MakeLogbookEntry(201126u, 2, source.Lmax, dest.Lmax, progNum, snum, 22, logLevel, programnumber);
				result = true;
			}
			if (dest.Enable.ADepthGradMin != source.Enable.ADepthGradMin)
			{
				this.Main.MakeLogbookEntry(201109u, 2, (float)(int)source.Enable.ADepthGradMin, (float)(int)dest.Enable.ADepthGradMin, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.LGmin != source.LGmin)
			{
				this.Main.MakeLogbookEntry(201124u, 2, source.LGmin, dest.LGmin, progNum, snum, 40, logLevel, programnumber);
				result = true;
			}
			if (dest.Enable.ADepthGradMax != source.Enable.ADepthGradMax)
			{
				this.Main.MakeLogbookEntry(201108u, 2, (float)(int)source.Enable.ADepthGradMax, (float)(int)dest.Enable.ADepthGradMax, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.LGmax != source.LGmax)
			{
				this.Main.MakeLogbookEntry(201123u, 2, source.LGmax, dest.LGmax, progNum, snum, 40, logLevel, programnumber);
				result = true;
			}
			if (dest.Enable.Ana != source.Enable.Ana)
			{
				this.Main.MakeLogbookEntry(201110u, 2, (float)(int)source.Enable.Ana, (float)(int)dest.Enable.Ana, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.AnaMin != source.AnaMin)
			{
				this.Main.MakeLogbookEntry(201101u, 2, source.AnaMin, dest.AnaMin, progNum, snum, 9, logLevel, programnumber);
				result = true;
			}
			if (dest.AnaMax != source.AnaMax)
			{
				this.Main.MakeLogbookEntry(201100u, 2, source.AnaMax, dest.AnaMax, progNum, snum, 9, logLevel, programnumber);
				result = true;
			}
			if (dest.DigMax != source.DigMax)
			{
				this.Main.MakeLogbookEntry(201104u, 2, (float)source.DigMax, (float)dest.DigMax, progNum, snum, 10, logLevel, programnumber);
				result = true;
			}
			if (dest.DigMin != source.DigMin)
			{
				this.Main.MakeLogbookEntry(201105u, 2, (float)source.DigMin, (float)dest.DigMin, progNum, snum, 10, logLevel, programnumber);
				result = true;
			}
			if (dest.JumpTo != source.JumpTo)
			{
				this.Main.MakeLogbookEntry(201122u, 2, (float)(source.JumpTo + 1), (float)(dest.JumpTo + 1), progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.ModDigOut != source.ModDigOut)
			{
				this.Main.MakeLogbookEntry(201138u, 2, (float)source.ModDigOut, (float)dest.ModDigOut, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.CountPassMax != source.CountPassMax)
			{
				this.Main.MakeLogbookEntry(201103u, 2, (float)(int)source.CountPassMax, (float)(int)dest.CountPassMax, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			if (dest.Type != source.Type)
			{
				result = true;
			}
			if (dest.UserRights != source.UserRights)
			{
				this.Main.MakeLogbookEntry(201153u, 2, (float)(int)source.UserRights, (float)(int)dest.UserRights, progNum, snum, byte.MaxValue, logLevel, programnumber);
				result = true;
			}
			return result;
		}

		public bool UploadAllProgDataFromController()
		{
			if (!this.Main.IsOnlineMode)
			{
				return false;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadProgramData"));
			Cursor.Current = Cursors.WaitCursor;
			if (!this.Main.VC.ReceiveVarBlock(10))
			{
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show("Could not receive PProgBlock in UploadAllProgDataFromController() of C_ProcessProgram", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			if (!this.Main.VC.ReceiveVarBlock(11))
			{
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show("Could not receive SpConstBlock in UploadAllProgDataFromController() of C_ProcessProgram", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.CopyProgStruct(ref this.TempProgStruct, this.Main.VC.PProg);
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			return true;
		}

		public void SafeAllProgDataToController(bool wasDataFromFile)
		{
			if (this.Main.PassCodeLevel > 0)
			{
				this.CopyProgStruct(ref this.Main.VC.PProg, this.TempProgStruct);
				if (!this.Main.IsOnlineMode)
				{
					this.Main.StatusBarText(string.Empty);
					switch (MessageBox.Show(this.Main.Rm.GetString("MbSaveDataLocally"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question))
					{
					case DialogResult.Yes:
						this.SafeAllProgDataToFile(null, true);
						break;
					default:
						MessageBox.Show("DialogResultError1 in SafeAllProgDataToController of C_ProcessProgram", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						break;
					case DialogResult.No:
						break;
					}
					goto IL_03f3;
				}
				if (wasDataFromFile)
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					switch (MessageBox.Show(this.Main.Rm.GetString("MbSaveNotVerifiedData"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question))
					{
					case DialogResult.No:
						break;
					default:
						goto IL_012d;
					case DialogResult.Yes:
						goto IL_0145;
					}
					this.SafeAllProgDataToFile(null, true);
					goto IL_03f3;
				}
				goto IL_0145;
			}
			goto IL_03f3;
			IL_0145:
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("SaveProgramData"));
			if (!this.Main.VC.SendVarBlock(10))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				switch (MessageBox.Show(this.Main.Rm.GetString("MbSaveProgFailure"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question))
				{
				case DialogResult.Yes:
					this.SafeAllProgDataToFile(null, true);
					break;
				default:
					MessageBox.Show("DialogResultError3 in SafeAllProgDataTo Controller of C_ProcessProgram", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					break;
				case DialogResult.No:
					break;
				}
			}
			else
			{
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveProgramData") + "+");
				Thread.Sleep(50);
				if (!this.Main.VC.SendVarBlock(17))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					switch (MessageBox.Show(this.Main.Rm.GetString("MbSaveProgFailure"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question))
					{
					case DialogResult.Yes:
						this.SafeAllProgDataToFile(null, true);
						break;
					default:
						MessageBox.Show("DialogResultError3 in SafeAllProgDataTo Controller of C_ProcessProgram", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						break;
					case DialogResult.No:
						break;
					}
				}
				else
				{
					Thread.Sleep(50);
					this.Main.VC.PProgXChanged.Initialize();
					this.Main.StatusBarText(this.Main.Rm.GetString("SaveProgOnCPU"));
					if (!this.Main.SaveOnController(3, true))
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						switch (MessageBox.Show(this.Main.Rm.GetString("MbSaveProgOnCPUFailure"), this.Main.Rm.GetString("SecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question))
						{
						case DialogResult.Yes:
							this.SafeAllProgDataToFile(null, true);
							break;
						default:
							MessageBox.Show("DialogResultError4 in SafeAllProgDataTo Controller of C_ProcessProgram", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							break;
						case DialogResult.No:
							break;
						}
					}
					else
					{
						DialogResult dialogResult = DialogResult.No;
						if (wasDataFromFile)
						{
							this.Main.VC.LogBookWriteData_elements = 1u;
							this.Main.MakeLogbookEntry(200000u, 0, 0f, 0f, 0u, 0, byte.MaxValue);
						}
						this.Main.WriteLogbookData(true);
					}
				}
			}
			goto IL_03f3;
			IL_012d:
			MessageBox.Show("DialogResultError2 in SafeAllProgDataTo Controller of C_ProcessProgram", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			goto IL_03f3;
			IL_03f3:
			this.Main.LoggingFinished(true);
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
		}

		public string SafeAllProgDataToFile(string directory, bool showMessage)
		{
			string text = "";
			bool flag;
			string directoryS;
			if (directory == null)
			{
				flag = Settings.Default.ProgFileOperationDefaultUse;
				directoryS = Settings.Default.ProgFileOperationDefaultDirectory;
			}
			else
			{
				flag = true;
				directoryS = directory;
			}
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			FileStream fileStream = null;
			try
			{
				if (!flag)
				{
					this.saveFileDialog.FileName = this.Main.Rm.GetString("ScrewProgramFiles") + " V" + Assembly.GetExecutingAssembly().GetName().Version.ToString();
					if (this.saveFileDialog.ShowDialog() != DialogResult.OK)
					{
						return "";
					}
					fileStream = new FileStream(this.saveFileDialog.FileName, FileMode.Create);
				}
				else
				{
					fileStream = this.GetNextFile(directoryS, this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) + "_ALL_PROGRAMS_", "wprg");
				}
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveProgramDataLocally"));
				Cursor.Current = Cursors.WaitCursor;
				Application.DoEvents();
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				binaryFormatter.AssemblyFormat = FormatterAssemblyStyle.Simple;
				binaryFormatter.Serialize(fileStream, this.TempProgStruct);
				string name = fileStream.Name;
				fileStream.Close();
				fileStream.Dispose();
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				text = this.Main.Rm.GetString("MbSavedProgramDataToFile") + "\n" + name;
				if (flag && showMessage)
				{
					MessageBox.Show(text);
				}
				return text;
			}
			catch (Exception ex)
			{
				if (fileStream != null)
				{
					fileStream.Close();
					fileStream.Dispose();
				}
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show(this.Main.Rm.GetString("MbPProgSaveToFileFailure") + ":\n" + ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return "";
			}
		}

		public bool LoadAllProgDataFromFile(string directory, bool useOpenFileDialog)
		{
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			if (useOpenFileDialog)
			{
				if (directory == null)
				{
					if (Settings.Default.ProgFileOperationDefaultUse)
					{
						this.openFileDialog.InitialDirectory = Settings.Default.ProgFileOperationDefaultDirectory;
					}
				}
				else
				{
					this.openFileDialog.InitialDirectory = directory;
				}
				if (this.openFileDialog.ShowDialog() != DialogResult.OK)
				{
					return false;
				}
			}
			else
			{
				this.openFileDialog.FileName = directory;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadProgramDataLocally"));
			Cursor.Current = Cursors.WaitCursor;
			Application.DoEvents();
			FileStream fileStream = null;
			BinaryFormatter binaryFormatter = null;
			try
			{
				fileStream = new FileStream(this.openFileDialog.FileName, FileMode.OpenOrCreate);
				binaryFormatter = new BinaryFormatter();
				WSP1_VarComm.PProg_Struct pProg_Struct = this.NewInitializedProgStruct();
				binaryFormatter.Binder = new myBinder();
				pProg_Struct = (WSP1_VarComm.PProg_Struct)binaryFormatter.Deserialize(fileStream);
				if (pProg_Struct.Num.Length == 1024)
				{
					this.Main.VC.makeCopyPProg(ref this.TempProgStruct, pProg_Struct);
					this.Main.SettingsChanged();
				}
				else
				{
					MessageBox.Show(this.Main.Rm.GetString("MbOldPProgLoad"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				fileStream.Close();
				fileStream.Dispose();
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				return true;
			}
			catch (Exception ex)
			{
				if (fileStream != null)
				{
					fileStream.Close();
					fileStream.Dispose();
				}
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show(this.Main.Rm.GetString("MbPProgLoadFromFileFailure") + ":\n" + ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
		}

		private void ImportWSP1_ProgStruct(ref WSP1_VarComm.ProgStruct dest, WSP1_VarComm.ProgStruct source)
		{
			int num = 0;
			int num2 = 0;
			string text = this.Main.CommonFunctions.UShortToString(source.Info.Name);
			source.Info.Name = new ushort[32];
			this.Main.CommonFunctions.StringToUShort(ref source.Info.Name, text, 32);
			for (num = 0; num < 25 && num + num2 < 25; num++)
			{
				if (source.Step[num + num2].Switch == 1031)
				{
					num2++;
				}
				if (num2 > 0)
				{
					if (num + num2 >= 25)
					{
						break;
					}
					this.Main.VC.makeCopyStepStruct(ref source.Step[num], source.Step[num + num2]);
				}
			}
			source.Info.Steps = (byte)(source.Info.Steps - (byte)num2);
			this.Main.VC.makeCopyProgStruct(ref dest, source);
		}

		private void ImportWSP1_PProgStruct(ref WSP1_VarComm.PProg_Struct dest, WSP1_VarComm.PProg_Struct source)
		{
			int i;
			for (i = 0; i < source.Num.Length; i++)
			{
				this.ImportWSP1_ProgStruct(ref dest.Num[i], source.Num[i]);
			}
			for (; i < 1024; i++)
			{
				dest.Num[i] = this.NewInitializedProg();
			}
		}

		public bool SafeProgDataToFile(int progNum)
		{
			if (this.TempProgStruct.Num[progNum].Info.Steps == 0)
			{
				DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbProgramEmptySaveAnyway"), this.Main.Rm.GetString("SaveToFile"), MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
				if (dialogResult == DialogResult.Cancel)
				{
					return false;
				}
			}
			bool progFileOperationDefaultUse = Settings.Default.ProgFileOperationDefaultUse;
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			FileStream fileStream = null;
			try
			{
				if (!progFileOperationDefaultUse)
				{
					this.saveSingleFileDialog.FileName = this.Main.Rm.GetString("ScrewProgramFilesSingular") + " V" + Assembly.GetExecutingAssembly().GetName().Version.ToString();
					if (this.saveSingleFileDialog.ShowDialog() != DialogResult.OK)
					{
						return false;
					}
					fileStream = new FileStream(this.saveSingleFileDialog.FileName, FileMode.Create);
				}
				else
				{
					fileStream = this.GetNextFile(Settings.Default.ProgFileOperationDefaultDirectory, this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) + "_PROGRAM_", "wspg");
				}
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveProgramDataLocally"));
				Application.DoEvents();
				Cursor.Current = Cursors.WaitCursor;
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				binaryFormatter.AssemblyFormat = FormatterAssemblyStyle.Simple;
				binaryFormatter.Serialize(fileStream, this.TempProgStruct.Num[progNum]);
				string name = fileStream.Name;
				fileStream.Close();
				fileStream.Dispose();
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				if (progFileOperationDefaultUse)
				{
					MessageBox.Show(this.Main.Rm.GetString("MbSavedProgramDataToFile") + "\n" + name);
				}
				return true;
			}
			catch (Exception ex)
			{
				if (fileStream != null)
				{
					fileStream.Close();
					fileStream.Dispose();
				}
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show(this.Main.Rm.GetString("MbPProgSaveToFileFailure") + ":\n" + ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
		}

		public bool LoadProgDataFromFile(int progNum)
		{
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			if (Settings.Default.ProgFileOperationDefaultUse)
			{
				this.openSingleFileDialog.InitialDirectory = Settings.Default.ProgFileOperationDefaultDirectory;
			}
			if (this.openSingleFileDialog.ShowDialog() != DialogResult.OK)
			{
				return false;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadProgramDataLocally"));
			Cursor.Current = Cursors.WaitCursor;
			FileStream fileStream = null;
			BinaryFormatter binaryFormatter = null;
			try
			{
				fileStream = new FileStream(this.openSingleFileDialog.FileName, FileMode.OpenOrCreate);
				binaryFormatter = new BinaryFormatter();
				WSP1_VarComm.ProgStruct progStruct = this.NewInitializedProg();
				binaryFormatter.Binder = new myBinder();
				progStruct = (WSP1_VarComm.ProgStruct)binaryFormatter.Deserialize(fileStream);
				if (progStruct.Info.Name.Length == 32)
				{
					this.Main.VC.makeCopyProgStruct(ref this.TempProgStruct.Num[progNum], progStruct);
					this.Main.SettingsChanged();
				}
				else
				{
					MessageBox.Show(this.Main.Rm.GetString("MbOldProgLoad"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				fileStream.Close();
				fileStream.Dispose();
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				return true;
			}
			catch (Exception ex)
			{
				if (fileStream != null)
				{
					fileStream.Close();
					fileStream.Dispose();
				}
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show(this.Main.Rm.GetString("MbPProgLoadFromFileFailure") + ":\n" + ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
		}

		public FileStream GetNextFile(string directoryS, string basicName, string extension)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(directoryS);
			int num = directoryInfo.GetFiles().Length;
			if (num > 1048575)
			{
				return null;
			}
			DateTime now = DateTime.Now;
			string text = $"{now:yyyy-MM-dd}";
			string text2 = $"{now:HH:mm:ss}";
			text = text.Replace("-", "");
			text2 = text2.Replace(":", "");
			FileStream fileStream = null;
			if (directoryS.Length > 0 && directoryS[directoryS.Length - 1] != '\\')
			{
				directoryS += "\\";
			}
			string text3 = directoryS;
			string text4 = text3;
			text3 = text4 + basicName + text + "_" + text2 + "." + extension;
			try
			{
				fileStream = new FileStream(text3, FileMode.Create, FileAccess.Write, FileShare.None);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
			}
			if (fileStream != null)
			{
				return fileStream;
			}
			return fileStream;
		}
	}
}
