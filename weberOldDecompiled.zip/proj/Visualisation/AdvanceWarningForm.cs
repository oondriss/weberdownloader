using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class AdvanceWarningForm : Form
	{
		private MainForm Main;

		private int name1SelectionStart;

		private int name2SelectionStart;

		private int name3SelectionStart;

		private int name4SelectionStart;

		private int name5SelectionStart;

		private string name1Text;

		private string name2Text;

		private string name3Text;

		private string name4Text;

		private string name5Text;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Button bt3;

		private IContainer components;

		private Label lbMachineCounter;

		private Label lbCustomCounter;

		private Label lbShowMachineCounter;

		private Label lbShowCustomCounter;

		private Button bt4;

		private Button btComponents;

		private GroupBox gBMachineInfo;

		private Button btAdvanceWarning;

		private GroupBox gBAdvanceWarning;

		private NumberEdit1 nEValue1;

		private NumberEdit1 nEValue3;

		private NumberEdit1 nEValue2;

		private Label lbCounter;

		private Label lbLimit;

		private Label lbName;

		private Button btDeleteCounter3;

		private Button btDeleteCounter2;

		private Button btDeleteCounter1;

		private Label lbShowCounter3;

		private Label lbShowCounter2;

		private Label lbShowCounter1;

		private Button btDeleteCustomCounter;

		private Button btCancel;

		private Button bt1;

		private Label lbMachineCounterNIO;

		private Label lbCustomCounterNIO;

		private Button btDeleteCustomCounterNIO;

		private Label lbShowCustomCounterNIO;

		private Label lbShowMachineCounterNIO;

		private Timer timer_init;

		private NumberEdit1 nEAdvance5;

		private Button btDeleteCounter5;

		private Label lbShowCounter5;

		private NumberEdit1 nEValue5;

		private NumberEdit1 nEAdvance4;

		private Button btDeleteCounter4;

		private Label lbShowCounter4;

		private NumberEdit1 nEValue4;

		private Label lbAdvanced;

		private NumberEdit1 nEAdvance3;

		private NumberEdit1 nEAdvance2;

		private NumberEdit1 nEAdvance1;

		private Button btDeleteMachineCounterNIO;

		private CheckBox chBDate_5;

		private DateTimePicker dateTimePickerSchedul_5;

		private Label lbDays5;

		private NumberEdit1 nEAdvanceDays5;

		private bool bInitialize;

		private Label lbName5;

		private Label lbName3;

		private Label lbName2;

		private Label lbName1;

		private TextBox tBName4;

		private string[] advanvedWarningNames;

		private bool ebene3;

		public string AdvancedWarningName(int i)
		{
			if (i <= this.advanvedWarningNames.Length && this.advanvedWarningNames[i] != null && this.advanvedWarningNames[i].Length != 0)
			{
				return this.advanvedWarningNames[i];
			}
			return this.Main.Rm.GetString("NotValid");
		}

		public AdvanceWarningForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.advanvedWarningNames = new string[5];
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			this.pnMenu = new Panel();
			this.btCancel = new Button();
			this.btAdvanceWarning = new Button();
			this.bt4 = new Button();
			this.btComponents = new Button();
			this.bt1 = new Button();
			this.bt3 = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.lbMachineCounter = new Label();
			this.lbCustomCounter = new Label();
			this.lbShowMachineCounter = new Label();
			this.lbShowCustomCounter = new Label();
			this.gBMachineInfo = new GroupBox();
			this.btDeleteMachineCounterNIO = new Button();
			this.btDeleteCustomCounterNIO = new Button();
			this.lbShowCustomCounterNIO = new Label();
			this.lbShowMachineCounterNIO = new Label();
			this.lbMachineCounterNIO = new Label();
			this.lbCustomCounterNIO = new Label();
			this.btDeleteCustomCounter = new Button();
			this.gBAdvanceWarning = new GroupBox();
			this.tBName4 = new TextBox();
			this.lbName5 = new Label();
			this.lbName3 = new Label();
			this.lbName2 = new Label();
			this.lbName1 = new Label();
			this.lbDays5 = new Label();
			this.nEAdvanceDays5 = new NumberEdit1();
			this.chBDate_5 = new CheckBox();
			this.dateTimePickerSchedul_5 = new DateTimePicker();
			this.nEAdvance5 = new NumberEdit1();
			this.btDeleteCounter5 = new Button();
			this.lbShowCounter5 = new Label();
			this.nEValue5 = new NumberEdit1();
			this.nEAdvance4 = new NumberEdit1();
			this.btDeleteCounter4 = new Button();
			this.lbShowCounter4 = new Label();
			this.nEValue4 = new NumberEdit1();
			this.lbAdvanced = new Label();
			this.nEAdvance3 = new NumberEdit1();
			this.nEAdvance2 = new NumberEdit1();
			this.nEAdvance1 = new NumberEdit1();
			this.lbCounter = new Label();
			this.lbLimit = new Label();
			this.lbName = new Label();
			this.btDeleteCounter3 = new Button();
			this.btDeleteCounter2 = new Button();
			this.btDeleteCounter1 = new Button();
			this.lbShowCounter3 = new Label();
			this.lbShowCounter2 = new Label();
			this.lbShowCounter1 = new Label();
			this.nEValue3 = new NumberEdit1();
			this.nEValue2 = new NumberEdit1();
			this.nEValue1 = new NumberEdit1();
			this.timer_init = new Timer(this.components);
			this.pnMenu.SuspendLayout();
			this.gBMachineInfo.SuspendLayout();
			this.gBAdvanceWarning.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.btAdvanceWarning);
			this.pnMenu.Controls.Add(this.bt4);
			this.pnMenu.Controls.Add(this.btComponents);
			this.pnMenu.Controls.Add(this.bt1);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 8;
			this.btCancel.Text = "Änderungen verwerfen";
			this.btCancel.Click += this.btCancel_Click;
			this.btAdvanceWarning.Enabled = false;
			this.btAdvanceWarning.Location = new Point(3, 323);
			this.btAdvanceWarning.Name = "btAdvanceWarning";
			this.btAdvanceWarning.Size = new Size(74, 62);
			this.btAdvanceWarning.TabIndex = 5;
			this.btAdvanceWarning.Text = "Vorwarn- werte";
			this.btAdvanceWarning.Click += this.btAdvanceWarning_Click;
			this.bt4.Enabled = false;
			this.bt4.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt4.Location = new Point(3, 387);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(74, 62);
			this.bt4.TabIndex = 6;
			this.btComponents.Enabled = false;
			this.btComponents.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btComponents.Location = new Point(3, 259);
			this.btComponents.Name = "btComponents";
			this.btComponents.Size = new Size(74, 62);
			this.btComponents.TabIndex = 4;
			this.btComponents.Text = "Komponen- ten- Statistik";
			this.btComponents.Click += this.btComponents_Click;
			this.bt1.Enabled = false;
			this.bt1.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt1.Location = new Point(3, 195);
			this.bt1.Name = "bt1";
			this.bt1.Size = new Size(74, 62);
			this.bt1.TabIndex = 3;
			this.bt3.Enabled = false;
			this.bt3.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt3.Location = new Point(3, 131);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 2;
			this.btHelp.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.lbMachineCounter.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMachineCounter.Location = new Point(16, 23);
			this.lbMachineCounter.Name = "lbMachineCounter";
			this.lbMachineCounter.Size = new Size(319, 24);
			this.lbMachineCounter.TabIndex = 18;
			this.lbMachineCounter.Text = "Zähler";
			this.lbMachineCounter.TextAlign = ContentAlignment.MiddleLeft;
			this.lbCustomCounter.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbCustomCounter.Location = new Point(16, 103);
			this.lbCustomCounter.Name = "lbCustomCounter";
			this.lbCustomCounter.Size = new Size(319, 24);
			this.lbCustomCounter.TabIndex = 19;
			this.lbCustomCounter.Text = "Kundenzähler";
			this.lbCustomCounter.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowMachineCounter.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowMachineCounter.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowMachineCounter.Location = new Point(433, 22);
			this.lbShowMachineCounter.Name = "lbShowMachineCounter";
			this.lbShowMachineCounter.Size = new Size(80, 24);
			this.lbShowMachineCounter.TabIndex = 0;
			this.lbShowMachineCounter.Text = "99999999";
			this.lbShowMachineCounter.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowCustomCounter.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowCustomCounter.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowCustomCounter.Location = new Point(433, 102);
			this.lbShowCustomCounter.Name = "lbShowCustomCounter";
			this.lbShowCustomCounter.Size = new Size(80, 24);
			this.lbShowCustomCounter.TabIndex = 3;
			this.lbShowCustomCounter.Text = "0";
			this.lbShowCustomCounter.TextAlign = ContentAlignment.MiddleRight;
			this.gBMachineInfo.Controls.Add(this.btDeleteMachineCounterNIO);
			this.gBMachineInfo.Controls.Add(this.btDeleteCustomCounterNIO);
			this.gBMachineInfo.Controls.Add(this.lbShowCustomCounterNIO);
			this.gBMachineInfo.Controls.Add(this.lbShowMachineCounterNIO);
			this.gBMachineInfo.Controls.Add(this.lbMachineCounterNIO);
			this.gBMachineInfo.Controls.Add(this.lbCustomCounterNIO);
			this.gBMachineInfo.Controls.Add(this.btDeleteCustomCounter);
			this.gBMachineInfo.Controls.Add(this.lbMachineCounter);
			this.gBMachineInfo.Controls.Add(this.lbCustomCounter);
			this.gBMachineInfo.Controls.Add(this.lbShowMachineCounter);
			this.gBMachineInfo.Controls.Add(this.lbShowCustomCounter);
			this.gBMachineInfo.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBMachineInfo.Location = new Point(24, 14);
			this.gBMachineInfo.Name = "gBMachineInfo";
			this.gBMachineInfo.Size = new Size(657, 179);
			this.gBMachineInfo.TabIndex = 1;
			this.gBMachineInfo.TabStop = false;
			this.gBMachineInfo.Text = "Maschineninformation";
			this.btDeleteMachineCounterNIO.Font = new Font("Arial Unicode MS", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.btDeleteMachineCounterNIO.Location = new Point(529, 64);
			this.btDeleteMachineCounterNIO.Name = "btDeleteMachineCounterNIO";
			this.btDeleteMachineCounterNIO.Size = new Size(112, 24);
			this.btDeleteMachineCounterNIO.TabIndex = 2;
			this.btDeleteMachineCounterNIO.Text = "Lösche Zähler";
			this.btDeleteMachineCounterNIO.UseVisualStyleBackColor = true;
			this.btDeleteMachineCounterNIO.Click += this.btDeleteMachineCounterNIO_Click;
			this.btDeleteCustomCounterNIO.Font = new Font("Arial Unicode MS", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.btDeleteCustomCounterNIO.Location = new Point(529, 142);
			this.btDeleteCustomCounterNIO.Name = "btDeleteCustomCounterNIO";
			this.btDeleteCustomCounterNIO.Size = new Size(112, 24);
			this.btDeleteCustomCounterNIO.TabIndex = 6;
			this.btDeleteCustomCounterNIO.Text = "Lösche Zähler";
			this.btDeleteCustomCounterNIO.UseVisualStyleBackColor = true;
			this.btDeleteCustomCounterNIO.Click += this.btDeleteCustomCounterNIO_Click;
			this.lbShowCustomCounterNIO.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowCustomCounterNIO.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowCustomCounterNIO.Location = new Point(433, 142);
			this.lbShowCustomCounterNIO.Name = "lbShowCustomCounterNIO";
			this.lbShowCustomCounterNIO.Size = new Size(80, 24);
			this.lbShowCustomCounterNIO.TabIndex = 5;
			this.lbShowCustomCounterNIO.Text = "0";
			this.lbShowCustomCounterNIO.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowMachineCounterNIO.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowMachineCounterNIO.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowMachineCounterNIO.Location = new Point(433, 60);
			this.lbShowMachineCounterNIO.Name = "lbShowMachineCounterNIO";
			this.lbShowMachineCounterNIO.Size = new Size(80, 24);
			this.lbShowMachineCounterNIO.TabIndex = 1;
			this.lbShowMachineCounterNIO.Text = "0";
			this.lbShowMachineCounterNIO.TextAlign = ContentAlignment.MiddleRight;
			this.lbMachineCounterNIO.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMachineCounterNIO.Location = new Point(16, 63);
			this.lbMachineCounterNIO.Name = "lbMachineCounterNIO";
			this.lbMachineCounterNIO.Size = new Size(319, 20);
			this.lbMachineCounterNIO.TabIndex = 22;
			this.lbMachineCounterNIO.Text = "Zähler NIO";
			this.lbMachineCounterNIO.TextAlign = ContentAlignment.MiddleLeft;
			this.lbCustomCounterNIO.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbCustomCounterNIO.Location = new Point(16, 143);
			this.lbCustomCounterNIO.Name = "lbCustomCounterNIO";
			this.lbCustomCounterNIO.Size = new Size(319, 24);
			this.lbCustomCounterNIO.TabIndex = 21;
			this.lbCustomCounterNIO.Text = "Kundenzähler NIO";
			this.lbCustomCounterNIO.TextAlign = ContentAlignment.MiddleLeft;
			this.btDeleteCustomCounter.Font = new Font("Arial Unicode MS", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.btDeleteCustomCounter.Location = new Point(529, 102);
			this.btDeleteCustomCounter.Name = "btDeleteCustomCounter";
			this.btDeleteCustomCounter.Size = new Size(112, 24);
			this.btDeleteCustomCounter.TabIndex = 4;
			this.btDeleteCustomCounter.Text = "Lösche Zähler";
			this.btDeleteCustomCounter.UseVisualStyleBackColor = true;
			this.btDeleteCustomCounter.Click += this.btDeleteCustomCounter_Click;
			this.gBAdvanceWarning.Controls.Add(this.tBName4);
			this.gBAdvanceWarning.Controls.Add(this.lbName5);
			this.gBAdvanceWarning.Controls.Add(this.lbName3);
			this.gBAdvanceWarning.Controls.Add(this.lbName2);
			this.gBAdvanceWarning.Controls.Add(this.lbName1);
			this.gBAdvanceWarning.Controls.Add(this.lbDays5);
			this.gBAdvanceWarning.Controls.Add(this.nEAdvanceDays5);
			this.gBAdvanceWarning.Controls.Add(this.chBDate_5);
			this.gBAdvanceWarning.Controls.Add(this.dateTimePickerSchedul_5);
			this.gBAdvanceWarning.Controls.Add(this.nEAdvance5);
			this.gBAdvanceWarning.Controls.Add(this.btDeleteCounter5);
			this.gBAdvanceWarning.Controls.Add(this.lbShowCounter5);
			this.gBAdvanceWarning.Controls.Add(this.nEValue5);
			this.gBAdvanceWarning.Controls.Add(this.nEAdvance4);
			this.gBAdvanceWarning.Controls.Add(this.btDeleteCounter4);
			this.gBAdvanceWarning.Controls.Add(this.lbShowCounter4);
			this.gBAdvanceWarning.Controls.Add(this.nEValue4);
			this.gBAdvanceWarning.Controls.Add(this.lbAdvanced);
			this.gBAdvanceWarning.Controls.Add(this.nEAdvance3);
			this.gBAdvanceWarning.Controls.Add(this.nEAdvance2);
			this.gBAdvanceWarning.Controls.Add(this.nEAdvance1);
			this.gBAdvanceWarning.Controls.Add(this.lbCounter);
			this.gBAdvanceWarning.Controls.Add(this.lbLimit);
			this.gBAdvanceWarning.Controls.Add(this.lbName);
			this.gBAdvanceWarning.Controls.Add(this.btDeleteCounter3);
			this.gBAdvanceWarning.Controls.Add(this.btDeleteCounter2);
			this.gBAdvanceWarning.Controls.Add(this.btDeleteCounter1);
			this.gBAdvanceWarning.Controls.Add(this.lbShowCounter3);
			this.gBAdvanceWarning.Controls.Add(this.lbShowCounter2);
			this.gBAdvanceWarning.Controls.Add(this.lbShowCounter1);
			this.gBAdvanceWarning.Controls.Add(this.nEValue3);
			this.gBAdvanceWarning.Controls.Add(this.nEValue2);
			this.gBAdvanceWarning.Controls.Add(this.nEValue1);
			this.gBAdvanceWarning.Location = new Point(24, 199);
			this.gBAdvanceWarning.Name = "gBAdvanceWarning";
			this.gBAdvanceWarning.Size = new Size(657, 318);
			this.gBAdvanceWarning.TabIndex = 3;
			this.gBAdvanceWarning.TabStop = false;
			this.gBAdvanceWarning.Text = "Vorwarnwerte";
			this.tBName4.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.tBName4.Location = new Point(6, 191);
			this.tBName4.Name = "tBName4";
			this.tBName4.Size = new Size(240, 25);
			this.tBName4.TabIndex = 36;
			this.tBName4.Text = "0";
			this.tBName4.TextChanged += this.tBName4_TextChanged;
			this.tBName4.KeyUp += this.tBName4_KeyUp;
			this.tBName4.MouseUp += this.StartInput;
			this.lbName5.BorderStyle = BorderStyle.Fixed3D;
			this.lbName5.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbName5.Location = new Point(6, 240);
			this.lbName5.Name = "lbName5";
			this.lbName5.Size = new Size(240, 24);
			this.lbName5.TabIndex = 35;
			this.lbName5.Text = "0";
			this.lbName5.TextAlign = ContentAlignment.MiddleLeft;
			this.lbName5.Click += this.lbName5_Click;
			this.lbName3.BorderStyle = BorderStyle.Fixed3D;
			this.lbName3.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbName3.Location = new Point(6, 152);
			this.lbName3.Name = "lbName3";
			this.lbName3.Size = new Size(240, 24);
			this.lbName3.TabIndex = 33;
			this.lbName3.Text = "0";
			this.lbName3.TextAlign = ContentAlignment.MiddleLeft;
			this.lbName3.Click += this.lbName3_Click;
			this.lbName2.BorderStyle = BorderStyle.Fixed3D;
			this.lbName2.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbName2.Location = new Point(6, 110);
			this.lbName2.Name = "lbName2";
			this.lbName2.Size = new Size(240, 24);
			this.lbName2.TabIndex = 32;
			this.lbName2.Text = "0";
			this.lbName2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbName2.Click += this.lbName2_Click;
			this.lbName1.BorderStyle = BorderStyle.Fixed3D;
			this.lbName1.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbName1.Location = new Point(7, 70);
			this.lbName1.Name = "lbName1";
			this.lbName1.Size = new Size(240, 24);
			this.lbName1.TabIndex = 31;
			this.lbName1.Text = "Packet 12345678901234567890";
			this.lbName1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbName1.Click += this.lbName1_Click;
			this.lbDays5.Font = new Font("Arial Unicode MS", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbDays5.Location = new Point(434, 239);
			this.lbDays5.Name = "lbDays5";
			this.lbDays5.Size = new Size(206, 24);
			this.lbDays5.TabIndex = 30;
			this.lbDays5.Text = "(Tage)";
			this.lbDays5.TextAlign = ContentAlignment.MiddleLeft;
			this.nEAdvanceDays5.BackColor = Color.White;
			this.nEAdvanceDays5.DecimalNum = 0;
			this.nEAdvanceDays5.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAdvanceDays5.ForeColor = SystemColors.ControlText;
			this.nEAdvanceDays5.Location = new Point(355, 239);
			this.nEAdvanceDays5.MaxValue = 1E+07f;
			this.nEAdvanceDays5.MinValue = 0f;
			this.nEAdvanceDays5.Name = "nEAdvanceDays5";
			this.nEAdvanceDays5.Size = new Size(70, 28);
			this.nEAdvanceDays5.TabIndex = 21;
			this.nEAdvanceDays5.Text = "0";
			this.nEAdvanceDays5.TextAlign = HorizontalAlignment.Right;
			this.nEAdvanceDays5.Value = 0f;
			this.nEAdvanceDays5.MouseClick += this.StartInput;
			this.nEAdvanceDays5.TextChanged += this.textChanged;
			this.nEAdvanceDays5.Enter += this.Start_Input;
			this.chBDate_5.AutoSize = true;
			this.chBDate_5.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.chBDate_5.Location = new Point(6, 267);
			this.chBDate_5.Name = "chBDate_5";
			this.chBDate_5.Size = new Size(155, 22);
			this.chBDate_5.TabIndex = 28;
			this.chBDate_5.Text = "zusätzlich zum Zähler";
			this.chBDate_5.UseVisualStyleBackColor = true;
			this.chBDate_5.Visible = false;
			this.chBDate_5.CheckedChanged += this.chBDate_5_CheckedChanged;
			this.dateTimePickerSchedul_5.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.dateTimePickerSchedul_5.Location = new Point(256, 239);
			this.dateTimePickerSchedul_5.MinDate = new DateTime(2014, 1, 1, 0, 0, 0, 0);
			this.dateTimePickerSchedul_5.Name = "dateTimePickerSchedul_5";
			this.dateTimePickerSchedul_5.Size = new Size(93, 25);
			this.dateTimePickerSchedul_5.TabIndex = 20;
			this.nEAdvance5.BackColor = Color.White;
			this.nEAdvance5.DecimalNum = 0;
			this.nEAdvance5.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAdvance5.ForeColor = SystemColors.ControlText;
			this.nEAdvance5.Location = new Point(345, 268);
			this.nEAdvance5.MaxValue = 1E+07f;
			this.nEAdvance5.MinValue = 0f;
			this.nEAdvance5.Name = "nEAdvance5";
			this.nEAdvance5.Size = new Size(80, 28);
			this.nEAdvance5.TabIndex = 24;
			this.nEAdvance5.Text = "0";
			this.nEAdvance5.TextAlign = HorizontalAlignment.Right;
			this.nEAdvance5.Value = 0f;
			this.nEAdvance5.Visible = false;
			this.nEAdvance5.MouseClick += this.StartInput;
			this.nEAdvance5.TextChanged += this.textChanged;
			this.nEAdvance5.Enter += this.Start_Input;
			this.btDeleteCounter5.Location = new Point(528, 268);
			this.btDeleteCounter5.Name = "btDeleteCounter5";
			this.btDeleteCounter5.Size = new Size(112, 24);
			this.btDeleteCounter5.TabIndex = 26;
			this.btDeleteCounter5.Text = "Lösche Zähler";
			this.btDeleteCounter5.UseVisualStyleBackColor = true;
			this.btDeleteCounter5.Visible = false;
			this.btDeleteCounter5.Click += this.btDeleteCounterX_Click;
			this.lbShowCounter5.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowCounter5.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowCounter5.Location = new Point(435, 268);
			this.lbShowCounter5.Name = "lbShowCounter5";
			this.lbShowCounter5.Size = new Size(80, 24);
			this.lbShowCounter5.TabIndex = 25;
			this.lbShowCounter5.Text = "0";
			this.lbShowCounter5.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowCounter5.Visible = false;
			this.nEValue5.BackColor = Color.White;
			this.nEValue5.DecimalNum = 0;
			this.nEValue5.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue5.ForeColor = SystemColors.ControlText;
			this.nEValue5.Location = new Point(255, 267);
			this.nEValue5.MaxValue = 1E+07f;
			this.nEValue5.MinValue = 0f;
			this.nEValue5.Name = "nEValue5";
			this.nEValue5.Size = new Size(80, 28);
			this.nEValue5.TabIndex = 23;
			this.nEValue5.Text = "0";
			this.nEValue5.TextAlign = HorizontalAlignment.Right;
			this.nEValue5.Value = 0f;
			this.nEValue5.Visible = false;
			this.nEValue5.TextChanged += this.textChanged;
			this.nEValue5.Enter += this.Start_Input;
			this.nEValue5.MouseDown += this.StartInput;
			this.nEAdvance4.BackColor = Color.White;
			this.nEAdvance4.DecimalNum = 0;
			this.nEAdvance4.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAdvance4.ForeColor = SystemColors.ControlText;
			this.nEAdvance4.Location = new Point(345, 191);
			this.nEAdvance4.MaxValue = 1E+07f;
			this.nEAdvance4.MinValue = 0f;
			this.nEAdvance4.Name = "nEAdvance4";
			this.nEAdvance4.Size = new Size(80, 28);
			this.nEAdvance4.TabIndex = 17;
			this.nEAdvance4.Text = "0";
			this.nEAdvance4.TextAlign = HorizontalAlignment.Right;
			this.nEAdvance4.Value = 0f;
			this.nEAdvance4.MouseClick += this.StartInput;
			this.nEAdvance4.TextChanged += this.textChanged;
			this.nEAdvance4.Enter += this.Start_Input;
			this.btDeleteCounter4.Location = new Point(529, 191);
			this.btDeleteCounter4.Name = "btDeleteCounter4";
			this.btDeleteCounter4.Size = new Size(112, 24);
			this.btDeleteCounter4.TabIndex = 19;
			this.btDeleteCounter4.Text = "Lösche Zähler";
			this.btDeleteCounter4.UseVisualStyleBackColor = true;
			this.btDeleteCounter4.Click += this.btDeleteCounterX_Click;
			this.lbShowCounter4.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowCounter4.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowCounter4.Location = new Point(435, 191);
			this.lbShowCounter4.Name = "lbShowCounter4";
			this.lbShowCounter4.Size = new Size(80, 24);
			this.lbShowCounter4.TabIndex = 18;
			this.lbShowCounter4.Text = "0";
			this.lbShowCounter4.TextAlign = ContentAlignment.MiddleRight;
			this.nEValue4.BackColor = Color.White;
			this.nEValue4.DecimalNum = 0;
			this.nEValue4.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue4.ForeColor = SystemColors.ControlText;
			this.nEValue4.Location = new Point(255, 190);
			this.nEValue4.MaxValue = 1E+07f;
			this.nEValue4.MinValue = 0f;
			this.nEValue4.Name = "nEValue4";
			this.nEValue4.Size = new Size(80, 28);
			this.nEValue4.TabIndex = 16;
			this.nEValue4.Text = "0";
			this.nEValue4.TextAlign = HorizontalAlignment.Right;
			this.nEValue4.Value = 0f;
			this.nEValue4.TextChanged += this.textChanged;
			this.nEValue4.Enter += this.Start_Input;
			this.nEValue4.MouseDown += this.StartInput;
			this.lbAdvanced.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAdvanced.Location = new Point(343, 18);
			this.lbAdvanced.Name = "lbAdvanced";
			this.lbAdvanced.Size = new Size(85, 51);
			this.lbAdvanced.TabIndex = 26;
			this.lbAdvanced.Text = "Warnung vor Grenzwert";
			this.lbAdvanced.TextAlign = ContentAlignment.BottomLeft;
			this.nEAdvance3.BackColor = Color.White;
			this.nEAdvance3.DecimalNum = 0;
			this.nEAdvance3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAdvance3.ForeColor = SystemColors.ControlText;
			this.nEAdvance3.Location = new Point(343, 151);
			this.nEAdvance3.MaxValue = 1E+07f;
			this.nEAdvance3.MinValue = 0f;
			this.nEAdvance3.Name = "nEAdvance3";
			this.nEAdvance3.Size = new Size(80, 28);
			this.nEAdvance3.TabIndex = 12;
			this.nEAdvance3.Text = "0";
			this.nEAdvance3.TextAlign = HorizontalAlignment.Right;
			this.nEAdvance3.Value = 0f;
			this.nEAdvance3.MouseClick += this.StartInput;
			this.nEAdvance3.TextChanged += this.textChanged;
			this.nEAdvance3.Enter += this.Start_Input;
			this.nEAdvance2.BackColor = Color.White;
			this.nEAdvance2.DecimalNum = 0;
			this.nEAdvance2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAdvance2.ForeColor = SystemColors.ControlText;
			this.nEAdvance2.Location = new Point(343, 111);
			this.nEAdvance2.MaxValue = 1E+07f;
			this.nEAdvance2.MinValue = 0f;
			this.nEAdvance2.Name = "nEAdvance2";
			this.nEAdvance2.Size = new Size(80, 28);
			this.nEAdvance2.TabIndex = 7;
			this.nEAdvance2.Text = "0";
			this.nEAdvance2.TextAlign = HorizontalAlignment.Right;
			this.nEAdvance2.Value = 0f;
			this.nEAdvance2.MouseClick += this.StartInput;
			this.nEAdvance2.TextChanged += this.textChanged;
			this.nEAdvance2.Enter += this.Start_Input;
			this.nEAdvance1.BackColor = Color.White;
			this.nEAdvance1.DecimalNum = 0;
			this.nEAdvance1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAdvance1.ForeColor = SystemColors.ControlText;
			this.nEAdvance1.Location = new Point(343, 71);
			this.nEAdvance1.MaxValue = 1E+07f;
			this.nEAdvance1.MinValue = 0f;
			this.nEAdvance1.Name = "nEAdvance1";
			this.nEAdvance1.Size = new Size(80, 28);
			this.nEAdvance1.TabIndex = 2;
			this.nEAdvance1.Text = "9999999";
			this.nEAdvance1.TextAlign = HorizontalAlignment.Right;
			this.nEAdvance1.Value = 9999999f;
			this.nEAdvance1.MouseClick += this.StartInput;
			this.nEAdvance1.TextChanged += this.textChanged;
			this.nEAdvance1.Enter += this.Start_Input;
			this.lbCounter.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbCounter.Location = new Point(434, 15);
			this.lbCounter.Name = "lbCounter";
			this.lbCounter.Size = new Size(92, 54);
			this.lbCounter.TabIndex = 22;
			this.lbCounter.Text = "Zähler";
			this.lbCounter.TextAlign = ContentAlignment.BottomLeft;
			this.lbLimit.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbLimit.Location = new Point(253, 14);
			this.lbLimit.Name = "lbLimit";
			this.lbLimit.Size = new Size(80, 54);
			this.lbLimit.TabIndex = 21;
			this.lbLimit.Text = "Grenzwert";
			this.lbLimit.TextAlign = ContentAlignment.BottomLeft;
			this.lbName.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbName.Location = new Point(6, 43);
			this.lbName.Name = "lbName";
			this.lbName.Size = new Size(241, 24);
			this.lbName.TabIndex = 20;
			this.lbName.Text = "Name der Warnung";
			this.lbName.TextAlign = ContentAlignment.MiddleLeft;
			this.btDeleteCounter3.Location = new Point(529, 151);
			this.btDeleteCounter3.Name = "btDeleteCounter3";
			this.btDeleteCounter3.Size = new Size(112, 24);
			this.btDeleteCounter3.TabIndex = 14;
			this.btDeleteCounter3.Text = "Lösche Zähler";
			this.btDeleteCounter3.UseVisualStyleBackColor = true;
			this.btDeleteCounter3.Click += this.btDeleteCounterX_Click;
			this.btDeleteCounter2.Location = new Point(529, 111);
			this.btDeleteCounter2.Name = "btDeleteCounter2";
			this.btDeleteCounter2.Size = new Size(112, 24);
			this.btDeleteCounter2.TabIndex = 9;
			this.btDeleteCounter2.Text = "Lösche Zähler";
			this.btDeleteCounter2.UseVisualStyleBackColor = true;
			this.btDeleteCounter2.Click += this.btDeleteCounterX_Click;
			this.btDeleteCounter1.Location = new Point(529, 71);
			this.btDeleteCounter1.Name = "btDeleteCounter1";
			this.btDeleteCounter1.Size = new Size(112, 24);
			this.btDeleteCounter1.TabIndex = 4;
			this.btDeleteCounter1.Text = "Lösche Zähler";
			this.btDeleteCounter1.UseVisualStyleBackColor = true;
			this.btDeleteCounter1.Click += this.btDeleteCounterX_Click;
			this.lbShowCounter3.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowCounter3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowCounter3.Location = new Point(433, 151);
			this.lbShowCounter3.Name = "lbShowCounter3";
			this.lbShowCounter3.Size = new Size(80, 24);
			this.lbShowCounter3.TabIndex = 13;
			this.lbShowCounter3.Text = "0";
			this.lbShowCounter3.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowCounter2.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowCounter2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowCounter2.Location = new Point(433, 111);
			this.lbShowCounter2.Name = "lbShowCounter2";
			this.lbShowCounter2.Size = new Size(80, 24);
			this.lbShowCounter2.TabIndex = 8;
			this.lbShowCounter2.Text = "0";
			this.lbShowCounter2.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowCounter1.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowCounter1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowCounter1.Location = new Point(433, 71);
			this.lbShowCounter1.Name = "lbShowCounter1";
			this.lbShowCounter1.Size = new Size(80, 24);
			this.lbShowCounter1.TabIndex = 3;
			this.lbShowCounter1.Text = "0";
			this.lbShowCounter1.TextAlign = ContentAlignment.MiddleRight;
			this.nEValue3.BackColor = Color.White;
			this.nEValue3.DecimalNum = 0;
			this.nEValue3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue3.ForeColor = SystemColors.ControlText;
			this.nEValue3.Location = new Point(253, 150);
			this.nEValue3.MaxValue = 1E+07f;
			this.nEValue3.MinValue = 0f;
			this.nEValue3.Name = "nEValue3";
			this.nEValue3.Size = new Size(80, 28);
			this.nEValue3.TabIndex = 11;
			this.nEValue3.Text = "0";
			this.nEValue3.TextAlign = HorizontalAlignment.Right;
			this.nEValue3.Value = 0f;
			this.nEValue3.TextChanged += this.textChanged;
			this.nEValue3.Enter += this.Start_Input;
			this.nEValue3.MouseDown += this.StartInput;
			this.nEValue2.BackColor = Color.White;
			this.nEValue2.DecimalNum = 0;
			this.nEValue2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue2.ForeColor = SystemColors.ControlText;
			this.nEValue2.Location = new Point(253, 110);
			this.nEValue2.MaxValue = 1E+07f;
			this.nEValue2.MinValue = 0f;
			this.nEValue2.Name = "nEValue2";
			this.nEValue2.Size = new Size(80, 28);
			this.nEValue2.TabIndex = 6;
			this.nEValue2.Text = "0";
			this.nEValue2.TextAlign = HorizontalAlignment.Right;
			this.nEValue2.Value = 0f;
			this.nEValue2.TextChanged += this.textChanged;
			this.nEValue2.Enter += this.Start_Input;
			this.nEValue2.MouseDown += this.StartInput;
			this.nEValue1.BackColor = Color.White;
			this.nEValue1.DecimalNum = 0;
			this.nEValue1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue1.ForeColor = SystemColors.ControlText;
			this.nEValue1.Location = new Point(253, 70);
			this.nEValue1.MaxValue = 1E+07f;
			this.nEValue1.MinValue = 0f;
			this.nEValue1.Name = "nEValue1";
			this.nEValue1.Size = new Size(80, 28);
			this.nEValue1.TabIndex = 1;
			this.nEValue1.Text = "9999999";
			this.nEValue1.TextAlign = HorizontalAlignment.Right;
			this.nEValue1.Value = 9999999f;
			this.nEValue1.TextChanged += this.textChanged;
			this.nEValue1.Enter += this.Start_Input;
			this.nEValue1.MouseDown += this.StartInput;
			this.timer_init.Tick += this.timer_init_Tick;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.gBAdvanceWarning);
			base.Controls.Add(this.gBMachineInfo);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "AdvanceWarningForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Auswertung/Statistik/Zykluszähler";
			base.Activated += this.CycleCounterForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBMachineInfo.ResumeLayout(false);
			this.gBAdvanceWarning.ResumeLayout(false);
			this.gBAdvanceWarning.PerformLayout();
			base.ResumeLayout(false);
		}

		public bool ShowWindow()
		{
			this.bInitialize = true;
			this.Main.ResetBrowserGrantedBy();
			if (this.Main.IsOfflineVersion)
			{
				this.MenEna();
				base.Show();
				return true;
			}
			if (!this.Main.IsOnlineMode)
			{
				this.MenEna();
				this.btBack.Enabled = false;
				this.btDeleteCounter1.Enabled = false;
				this.btDeleteCounter2.Enabled = false;
				this.btDeleteCounter3.Enabled = false;
				this.btDeleteCustomCounter.Enabled = false;
				this.btDeleteCustomCounterNIO.Enabled = false;
				this.nEValue1.Enabled = false;
				this.nEValue2.Enabled = false;
				this.nEValue3.Enabled = false;
				this.nEValue4.Enabled = false;
				this.nEValue5.Enabled = false;
				base.Show();
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return true;
			}
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadSystemConst"));
			if (!this.Main.VC.ReceiveVarBlock(12))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadCycleCount"));
			if (!this.Main.VC.ReceiveVarBlock(30))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive CycleCountBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.showCounter();
			this.MenEna();
			base.Show();
			Cursor.Current = Cursors.Default;
			this.Main.StatusBarText(string.Empty);
			this.Main.SettingsChangedReset();
			this.bInitialize = false;
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MenuMaintenance") + "/" + this.Main.Rm.GetString("MAdvanceWarning");
			this.lbCustomCounter.Text = this.Main.Rm.GetString("CustomCounter");
			this.lbCustomCounterNIO.Text = this.Main.Rm.GetString("CustomCounter") + " " + this.Main.Rm.GetString("NOK");
			this.lbMachineCounter.Text = this.Main.Rm.GetString("MachineCounter");
			this.lbCounter.Text = this.Main.Rm.GetString("CycleCounter");
			this.lbLimit.Text = this.Main.Rm.GetString("Limit");
			this.lbName.Text = this.Main.Rm.GetString("Name");
			this.btBack.Text = this.Main.Rm.GetString("StoreAndBack");
			this.btCancel.Text = this.Main.Rm.GetString("DiscardChanges");
			this.btDeleteCounter1.Text = this.Main.Rm.GetString("DeleteWarningCounter");
			this.btDeleteCounter2.Text = this.Main.Rm.GetString("DeleteWarningCounter");
			this.btDeleteCounter3.Text = this.Main.Rm.GetString("DeleteWarningCounter");
			this.btDeleteCounter4.Text = this.Main.Rm.GetString("DeleteWarningCounter");
			this.btDeleteCounter5.Text = this.Main.Rm.GetString("DeleteWarningCounter");
			this.btDeleteCustomCounterNIO.Text = this.Main.Rm.GetString("DeleteWarningCounter");
			this.btDeleteCustomCounter.Text = this.Main.Rm.GetString("DeleteWarningCounter");
			this.btDeleteMachineCounterNIO.Text = this.Main.Rm.GetString("DeleteWarningCounter");
			this.btAdvanceWarning.Text = this.Main.Rm.GetString("btAdvanceWarning");
			this.btComponents.Text = this.Main.Rm.GetString("btComponents");
			this.lbAdvanced.Text = this.Main.Rm.GetString("WarningBeforeLimit");
			this.lbMachineCounterNIO.Text = this.Main.Rm.GetString("MCycleCounter") + " " + this.Main.Rm.GetString("NOK");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.gBMachineInfo.Text = this.Main.Rm.GetString("MachineCounters");
			this.gBAdvanceWarning.Text = this.Main.Rm.GetString("AdvanceWarningValues");
			this.lbDays5.Text = this.Main.Rm.GetString("Days");
			this.chBDate_5.Text = this.Main.Rm.GetString("AdditionalToCounter");
			this.advanvedWarningNames[0] = this.Main.Rm.GetString("MaintenancePacket1");
			this.advanvedWarningNames[1] = this.Main.Rm.GetString("MaintenancePacket2");
			this.advanvedWarningNames[2] = this.Main.Rm.GetString("MaintenancePacket3");
			this.advanvedWarningNames[3] = this.Main.Rm.GetString("MaintenancePacket4");
			this.advanvedWarningNames[4] = this.Main.Rm.GetString("MaintenancePacket5");
		}

		private void MenEna()
		{
			this.ebene3 = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_CycleCounterForm && !this.Main.ViewOnlyMode)
			{
				this.ebene3 = true;
			}
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_CycleCounterForm, false);
			this.btBack.Enabled = this.ebene3;
			this.btDeleteCounter1.Enabled = this.ebene3;
			this.btDeleteCounter2.Enabled = this.ebene3;
			this.btDeleteCounter3.Enabled = this.ebene3;
			this.tBName4.Enabled = this.ebene3;
			this.nEValue1.Enabled = this.ebene3;
			this.nEValue2.Enabled = this.ebene3;
			this.nEValue3.Enabled = this.ebene3;
			this.nEValue4.Enabled = this.ebene3;
			this.nEValue5.Enabled = this.ebene3;
			this.nEAdvance1.Enabled = this.ebene3;
			this.nEAdvance2.Enabled = this.ebene3;
			this.nEAdvance3.Enabled = this.ebene3;
			this.nEAdvance4.Enabled = this.ebene3;
			this.nEAdvance5.Enabled = this.ebene3;
			this.btDeleteCounter1.Enabled = this.ebene3;
			this.btDeleteCounter2.Enabled = this.ebene3;
			this.btDeleteCounter3.Enabled = this.ebene3;
			this.btDeleteCounter4.Enabled = this.ebene3;
			this.btDeleteCounter5.Enabled = this.ebene3;
			if (!this.ebene3)
			{
				this.dateTimePickerSchedul_5.Enabled = false;
				this.nEAdvanceDays5.Enabled = false;
			}
			else
			{
				this.dateTimePickerSchedul_5.Enabled = this.chBDate_5.Checked;
				this.nEAdvanceDays5.Enabled = this.chBDate_5.Checked;
			}
			this.dateTimePickerSchedul_5.Format = DateTimePickerFormat.Custom;
			this.dateTimePickerSchedul_5.CustomFormat = Settings.Default.TimeSet.Remove(Settings.Default.TimeSet.IndexOf(' '));
			this.chBDate_5.Enabled = this.ebene3;
			this.btDeleteMachineCounterNIO.Enabled = this.ebene3;
			this.btDeleteCustomCounter.Enabled = this.ebene3;
			this.btDeleteCustomCounterNIO.Enabled = this.ebene3;
			this.btAdvanceWarning.Enabled = false;
			this.btComponents.Enabled = true;
			this.chBDate_5.Visible = false;
			this.nEValue5.Visible = false;
			this.nEAdvance5.Visible = false;
			this.lbShowCounter5.Visible = false;
			this.btDeleteCounter5.Visible = false;
			if (this.Main._READ_ONLY_CONTROLLER)
			{
				this.btBack.Enabled = false;
			}
			else
			{
				this.btBack.Enabled = true;
			}
		}

		private void showCounter()
		{
			this.lbShowCustomCounter.Text = this.Main.VC.CycleCount.Customer.ToString();
			this.lbShowMachineCounter.Text = this.Main.VC.CycleCount.Machine.ToString();
			this.lbShowCounter1.Text = this.Main.VC.CycleCount.Count[0].ToString();
			this.lbShowCounter2.Text = this.Main.VC.CycleCount.Count[1].ToString();
			this.lbShowCounter3.Text = this.Main.VC.CycleCount.Count[2].ToString();
			this.lbShowCounter4.Text = this.Main.VC.CycleCount.Count[3].ToString();
			this.lbShowCounter5.Text = this.Main.VC.CycleCount.Count[4].ToString();
			this.lbShowCustomCounterNIO.Text = this.Main.VC.CycleCount.CustomerNIO.ToString();
			this.lbShowMachineCounterNIO.Text = this.Main.VC.CycleCount.MachineNIO.ToString();
			this.tBName4.Text = this.Main.CommonFunctions.ByteToString(this.Main.VC.SysConst.AdvancedWarnings[3].Name);
			this.lbName1.Text = this.AdvancedWarningName(0);
			this.lbName2.Text = this.AdvancedWarningName(1);
			this.lbName3.Text = this.AdvancedWarningName(2);
			this.lbName5.Text = this.AdvancedWarningName(4);
			this.nEValue1.Text = this.Main.VC.SysConst.AdvancedWarnings[0].Limit.ToString();
			this.nEValue2.Text = this.Main.VC.SysConst.AdvancedWarnings[1].Limit.ToString();
			this.nEValue3.Text = this.Main.VC.SysConst.AdvancedWarnings[2].Limit.ToString();
			this.nEValue4.Text = this.Main.VC.SysConst.AdvancedWarnings[3].Limit.ToString();
			this.nEValue5.Text = this.Main.VC.SysConst.AdvancedWarnings[4].Limit.ToString();
			this.nEAdvance1.Text = this.Main.VC.SysConst.AdvancedWarnings[0].Advance.ToString();
			this.nEAdvance2.Text = this.Main.VC.SysConst.AdvancedWarnings[1].Advance.ToString();
			this.nEAdvance3.Text = this.Main.VC.SysConst.AdvancedWarnings[2].Advance.ToString();
			this.nEAdvance4.Text = this.Main.VC.SysConst.AdvancedWarnings[3].Advance.ToString();
			this.nEAdvance5.Text = this.Main.VC.SysConst.AdvancedWarnings[4].Advance.ToString();
			this.chBDate_5.Checked = true;
			if (this.ebene3)
			{
				this.dateTimePickerSchedul_5.Enabled = this.chBDate_5.Checked;
			}
			DateTime value;
			try
			{
				WSP1_VarComm.DateTimeStruct advancedWarningTime = this.Main.VC.SysConst.AdvancedWarnings[4].AdvancedWarningTime;
				value = new DateTime(advancedWarningTime.Year, advancedWarningTime.Month, advancedWarningTime.Day, advancedWarningTime.Hour, advancedWarningTime.Minute, advancedWarningTime.Second);
			}
			catch
			{
				value = DateTime.Now.AddHours(23.0);
			}
			this.dateTimePickerSchedul_5.Value = value;
			if (this.Main.VC.CycleCount.Count[0] >= this.Main.VC.SysConst.AdvancedWarnings[0].Limit)
			{
				this.lbName1.BackColor = Color.Red;
				this.lbName1.ForeColor = Color.White;
			}
			else if (this.Main.VC.CycleCount.Count[0] >= this.Main.VC.SysConst.AdvancedWarnings[0].Limit - this.Main.VC.SysConst.AdvancedWarnings[0].Advance)
			{
				this.lbName1.BackColor = Color.Yellow;
				this.lbName1.ForeColor = Color.Black;
			}
			else
			{
				this.lbName1.BackColor = SystemColors.Control;
				this.lbName1.ForeColor = Color.Black;
			}
			if (this.Main.VC.CycleCount.Count[1] >= this.Main.VC.SysConst.AdvancedWarnings[1].Limit)
			{
				this.lbName2.BackColor = Color.Red;
				this.lbName2.ForeColor = Color.White;
			}
			else if (this.Main.VC.CycleCount.Count[1] >= this.Main.VC.SysConst.AdvancedWarnings[1].Limit - this.Main.VC.SysConst.AdvancedWarnings[1].Advance)
			{
				this.lbName2.BackColor = Color.Yellow;
				this.lbName2.ForeColor = Color.Black;
			}
			else
			{
				this.lbName2.BackColor = SystemColors.Control;
				this.lbName2.ForeColor = Color.Black;
			}
			if (this.Main.VC.CycleCount.Count[2] >= this.Main.VC.SysConst.AdvancedWarnings[2].Limit)
			{
				this.lbName3.BackColor = Color.Red;
				this.lbName3.ForeColor = Color.White;
			}
			else if (this.Main.VC.CycleCount.Count[2] >= this.Main.VC.SysConst.AdvancedWarnings[2].Limit - this.Main.VC.SysConst.AdvancedWarnings[2].Advance)
			{
				this.lbName3.BackColor = Color.Yellow;
				this.lbName3.ForeColor = Color.Black;
			}
			else
			{
				this.lbName3.BackColor = SystemColors.Control;
				this.lbName3.ForeColor = Color.Black;
			}
			if (this.Main.VC.CycleCount.Count[3] >= this.Main.VC.SysConst.AdvancedWarnings[3].Limit)
			{
				this.tBName4.BackColor = Color.Red;
				this.tBName4.ForeColor = Color.White;
			}
			else if (this.Main.VC.CycleCount.Count[3] >= this.Main.VC.SysConst.AdvancedWarnings[3].Limit - this.Main.VC.SysConst.AdvancedWarnings[3].Advance)
			{
				this.tBName4.BackColor = SystemColors.Window;
				this.tBName4.ForeColor = Color.Black;
			}
			else
			{
				if (this.ebene3)
				{
					this.tBName4.BackColor = SystemColors.Window;
				}
				else
				{
					this.tBName4.BackColor = SystemColors.Control;
				}
				this.tBName4.ForeColor = Color.Black;
			}
			bool flag = false;
			bool flag2 = false;
			WSP1_VarComm.DateTimeStruct advancedWarningTime2 = this.Main.VC.SysConst.AdvancedWarnings[4].AdvancedWarningTime;
			try
			{
				if (this.Main.VC.SysConst.AdvancedWarnings[4].EnableAdvancedWarningTime != 0)
				{
					DateTime t = new DateTime(advancedWarningTime2.Year, advancedWarningTime2.Month, advancedWarningTime2.Day, advancedWarningTime2.Hour, advancedWarningTime2.Minute, advancedWarningTime2.Second);
					DateTime t2;
					if (!this.Main.VC.ReceiveVarBlock(12))
					{
						t2 = new DateTime(1, 1, 1, 0, 0, 0);
					}
					try
					{
						t2 = new DateTime(this.Main.VC.SysConst.ActualTime.Year, this.Main.VC.SysConst.ActualTime.Month, this.Main.VC.SysConst.ActualTime.Day, this.Main.VC.SysConst.ActualTime.Hour, this.Main.VC.SysConst.ActualTime.Minute, this.Main.VC.SysConst.ActualTime.Second);
					}
					catch
					{
						t2 = new DateTime(1, 1, 1, 0, 0, 0);
					}
					if (t2 > t)
					{
						flag = true;
					}
					if (t2.AddDays((double)this.Main.VC.SysConst.AdvancedWarnings[4].AdvancedDays) > t)
					{
						flag2 = true;
					}
				}
			}
			catch
			{
			}
			if (flag)
			{
				this.lbName5.BackColor = Color.Red;
				this.lbName5.ForeColor = Color.White;
			}
			else if (flag2)
			{
				this.lbName5.BackColor = Color.Yellow;
				this.lbName5.ForeColor = Color.Black;
			}
			else
			{
				this.lbName5.BackColor = SystemColors.Control;
				this.lbName5.ForeColor = Color.Black;
			}
		}

		public Color GetInfo(bool readFromWsp)
		{
			if (!this.Main.IsOnlineMode)
			{
				return Color.Black;
			}
			if (readFromWsp)
			{
				if (!this.Main.VC.ReceiveVarBlock(12))
				{
					return Color.Black;
				}
				if (!this.Main.VC.ReceiveVarBlock(30))
				{
					return Color.Black;
				}
			}
			for (int i = 0; i < 4; i++)
			{
				if (this.Main.VC.CycleCount.Count[i] >= this.Main.VC.SysConst.AdvancedWarnings[i].Limit)
				{
					return Color.Red;
				}
			}
			WSP1_VarComm.DateTimeStruct advancedWarningTime = this.Main.VC.SysConst.AdvancedWarnings[4].AdvancedWarningTime;
			DateTime t;
			DateTime t2;
			try
			{
				t = new DateTime(advancedWarningTime.Year, advancedWarningTime.Month, advancedWarningTime.Day, advancedWarningTime.Hour, advancedWarningTime.Minute, advancedWarningTime.Second);
				t2 = new DateTime(this.Main.VC.SysConst.ActualTime.Year, this.Main.VC.SysConst.ActualTime.Month, this.Main.VC.SysConst.ActualTime.Day, this.Main.VC.SysConst.ActualTime.Hour, this.Main.VC.SysConst.ActualTime.Minute, this.Main.VC.SysConst.ActualTime.Second);
			}
			catch
			{
				t = new DateTime(1, 1, 1, 0, 0, 0);
				t2 = new DateTime(1, 1, 1, 0, 0, 0);
			}
			if (t2 > t)
			{
				return Color.Red;
			}
			return Color.Black;
		}

		public string GetNamesOfReachedCounters()
		{
			string text = "";
			bool flag = false;
			WSP1_VarComm.DateTimeStruct advancedWarningTime = this.Main.VC.SysConst.AdvancedWarnings[4].AdvancedWarningTime;
			try
			{
				DateTime t = new DateTime(this.Main.VC.SysConst.ActualTime.Year, this.Main.VC.SysConst.ActualTime.Month, this.Main.VC.SysConst.ActualTime.Day, this.Main.VC.SysConst.ActualTime.Hour, this.Main.VC.SysConst.ActualTime.Minute, this.Main.VC.SysConst.ActualTime.Second);
				DateTime t2 = new DateTime(advancedWarningTime.Year, advancedWarningTime.Month, advancedWarningTime.Day, advancedWarningTime.Hour, advancedWarningTime.Minute, advancedWarningTime.Second);
				if (t > t2)
				{
					flag = true;
				}
			}
			catch
			{
			}
			int num = 0;
			while (num < 4)
			{
				if (this.Main.VC.CycleCount.Count[num] < this.Main.VC.SysConst.AdvancedWarnings[num].Limit && (num != 4 || !flag))
				{
					num++;
					continue;
				}
				if (text.Length > 0)
				{
					text += " + ";
				}
				string text2 = "";
				text2 = ((num == 3) ? this.Main.CommonFunctions.ByteToString(this.Main.VC.SysConst.AdvancedWarnings[num].Name) : this.Packet(num + 1, false));
				if (text2.Length != 0)
				{
					return text + text2;
				}
				text2 = this.Main.Rm.GetString("NotValid") + "(" + num.ToString() + ")";
				break;
			}
			if (flag)
			{
				if (text.Length > 0)
				{
					text += " + ";
				}
				text += this.Packet(5, false);
			}
			return text;
		}

		public string GetNamesOfAdvancedCounters()
		{
			string text = "";
			bool flag = false;
			WSP1_VarComm.DateTimeStruct advancedWarningTime = this.Main.VC.SysConst.AdvancedWarnings[4].AdvancedWarningTime;
			try
			{
				DateTime t = new DateTime(this.Main.VC.SysConst.ActualTime.Year, this.Main.VC.SysConst.ActualTime.Month, this.Main.VC.SysConst.ActualTime.Day, this.Main.VC.SysConst.ActualTime.Hour, this.Main.VC.SysConst.ActualTime.Minute, this.Main.VC.SysConst.ActualTime.Second);
				t = t.AddDays((double)this.Main.VC.SysConst.AdvancedWarnings[4].AdvancedDays);
				if (t > new DateTime(advancedWarningTime.Year, advancedWarningTime.Month, advancedWarningTime.Day, advancedWarningTime.Hour, advancedWarningTime.Minute, advancedWarningTime.Second))
				{
					flag = true;
				}
			}
			catch
			{
			}
			for (int i = 0; i < 4; i++)
			{
				if (this.Main.VC.CycleCount.Count[i] >= this.Main.VC.SysConst.AdvancedWarnings[i].Limit - this.Main.VC.SysConst.AdvancedWarnings[i].Advance || (i == 4 && flag))
				{
					if (text.Length > 0)
					{
						text += " + ";
					}
					text = ((i == 3) ? (text + this.AdvancedWarningName(i)) : (text + this.Packet(i + 1, false)));
					if (text.Length == 0)
					{
						text = "?";
					}
				}
			}
			if (flag)
			{
				if (text.Length > 0)
				{
					text += " + ";
				}
				text += this.Packet(5, false);
			}
			return text;
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			if (this.Main.IsOnlineMode)
			{
				if (this.Main.VC.SysConst.AdvancedWarnings[0].Limit != (uint)this.nEValue1.Value)
				{
					this.Main.MakeLogbookEntry(202101u, 3, (float)(double)this.Main.VC.SysConst.AdvancedWarnings[0].Limit, this.nEValue1.Value, 0u, 0, byte.MaxValue);
					this.Main.VC.SysConst.AdvancedWarnings[0].Limit = (uint)this.nEValue1.Value;
				}
				if (this.Main.VC.SysConst.AdvancedWarnings[1].Limit != (uint)this.nEValue2.Value)
				{
					this.Main.MakeLogbookEntry(202102u, 3, (float)(double)this.Main.VC.SysConst.AdvancedWarnings[1].Limit, this.nEValue2.Value, 0u, 0, byte.MaxValue);
					this.Main.VC.SysConst.AdvancedWarnings[1].Limit = (uint)this.nEValue2.Value;
				}
				if (this.Main.VC.SysConst.AdvancedWarnings[2].Limit != (uint)this.nEValue3.Value)
				{
					this.Main.MakeLogbookEntry(202103u, 3, (float)(double)this.Main.VC.SysConst.AdvancedWarnings[2].Limit, this.nEValue3.Value, 0u, 0, byte.MaxValue);
					this.Main.VC.SysConst.AdvancedWarnings[2].Limit = (uint)this.nEValue3.Value;
				}
				if (this.Main.VC.SysConst.AdvancedWarnings[3].Limit != (uint)this.nEValue4.Value)
				{
					this.Main.MakeLogbookEntry(202104u, 3, (float)(double)this.Main.VC.SysConst.AdvancedWarnings[3].Limit, this.nEValue4.Value, 0u, 0, byte.MaxValue);
					this.Main.VC.SysConst.AdvancedWarnings[3].Limit = (uint)this.nEValue4.Value;
				}
				if (this.Main.VC.SysConst.AdvancedWarnings[4].Limit != (uint)this.nEValue5.Value)
				{
					this.Main.MakeLogbookEntry(202105u, 3, (float)(double)this.Main.VC.SysConst.AdvancedWarnings[4].Limit, this.nEValue5.Value, 0u, 0, byte.MaxValue);
					this.Main.VC.SysConst.AdvancedWarnings[4].Limit = (uint)this.nEValue5.Value;
				}
				if (this.Main.VC.SysConst.AdvancedWarnings[0].Advance != (uint)this.nEAdvance1.Value)
				{
					this.Main.MakeLogbookEntry(202121u, 3, (float)(double)this.Main.VC.SysConst.AdvancedWarnings[0].Advance, this.nEAdvance1.Value, 0u, 0, byte.MaxValue);
					this.Main.VC.SysConst.AdvancedWarnings[0].Advance = (uint)this.nEAdvance1.Value;
				}
				if (this.Main.VC.SysConst.AdvancedWarnings[1].Advance != (uint)this.nEAdvance2.Value)
				{
					this.Main.MakeLogbookEntry(202122u, 3, (float)(double)this.Main.VC.SysConst.AdvancedWarnings[1].Advance, this.nEAdvance2.Value, 0u, 0, byte.MaxValue);
					this.Main.VC.SysConst.AdvancedWarnings[1].Advance = (uint)this.nEAdvance2.Value;
				}
				if (this.Main.VC.SysConst.AdvancedWarnings[2].Advance != (uint)this.nEAdvance3.Value)
				{
					this.Main.MakeLogbookEntry(202123u, 3, (float)(double)this.Main.VC.SysConst.AdvancedWarnings[2].Advance, this.nEAdvance3.Value, 0u, 0, byte.MaxValue);
					this.Main.VC.SysConst.AdvancedWarnings[2].Advance = (uint)this.nEAdvance3.Value;
				}
				if (this.Main.VC.SysConst.AdvancedWarnings[3].Advance != (uint)this.nEAdvance4.Value)
				{
					this.Main.MakeLogbookEntry(202124u, 3, (float)(double)this.Main.VC.SysConst.AdvancedWarnings[3].Advance, this.nEAdvance4.Value, 0u, 0, byte.MaxValue);
					this.Main.VC.SysConst.AdvancedWarnings[3].Advance = (uint)this.nEAdvance4.Value;
				}
				if (this.Main.VC.SysConst.AdvancedWarnings[4].Advance != (uint)this.nEAdvance5.Value)
				{
					this.Main.MakeLogbookEntry(202125u, 3, (float)(double)this.Main.VC.SysConst.AdvancedWarnings[4].Advance, this.nEAdvance5.Value, 0u, 0, byte.MaxValue);
					this.Main.VC.SysConst.AdvancedWarnings[4].Advance = (uint)this.nEAdvance5.Value;
				}
				if (this.Main.CommonFunctions.ByteToString(this.Main.VC.SysConst.AdvancedWarnings[3].Name) != this.tBName4.Text)
				{
					this.Main.MakeLogbookEntry(202114u, 3, 0f, 0f, 0u, 0, byte.MaxValue);
					this.Main.CommonFunctions.StringToByte(ref this.Main.VC.SysConst.AdvancedWarnings[3].Name, this.tBName4.Text, this.tBName4.Text.Length + 1);
				}
				WSP1_VarComm.DateTimeStruct advancedWarningTime = this.Main.VC.SysConst.AdvancedWarnings[4].AdvancedWarningTime;
				DateTime d;
				try
				{
					d = new DateTime(advancedWarningTime.Year, advancedWarningTime.Month, advancedWarningTime.Day, advancedWarningTime.Hour, advancedWarningTime.Minute, advancedWarningTime.Second);
				}
				catch
				{
					d = new DateTime(1, 1, 1, 0, 0, 0);
				}
				if (d != this.dateTimePickerSchedul_5.Value)
				{
					this.Main.MakeLogbookEntry(202135u, 3, 0f, 0f, 0u, 0, byte.MaxValue);
					advancedWarningTime.Year = (ushort)this.dateTimePickerSchedul_5.Value.Year;
					advancedWarningTime.Month = (byte)this.dateTimePickerSchedul_5.Value.Month;
					advancedWarningTime.Day = (byte)this.dateTimePickerSchedul_5.Value.Day;
					advancedWarningTime.Hour = (byte)this.dateTimePickerSchedul_5.Value.Hour;
					advancedWarningTime.Minute = (byte)this.dateTimePickerSchedul_5.Value.Minute;
					advancedWarningTime.Second = (byte)this.dateTimePickerSchedul_5.Value.Second;
				}
				if (this.Main.VC.SysConst.AdvancedWarnings[4].EnableAdvancedWarningTime != 0 && !this.chBDate_5.Checked)
				{
					goto IL_0801;
				}
				if (this.Main.VC.SysConst.AdvancedWarnings[4].EnableAdvancedWarningTime == 0 && this.chBDate_5.Checked)
				{
					goto IL_0801;
				}
				goto IL_0875;
			}
			goto IL_0a21;
			IL_0875:
			if (this.Main.VC.SysConst.AdvancedWarnings[4].AdvancedDays != (uint)this.nEAdvanceDays5.Value)
			{
				this.Main.MakeLogbookEntry(202155u, 3, (float)(double)this.Main.VC.SysConst.AdvancedWarnings[4].AdvancedDays, this.nEAdvanceDays5.Value, 0u, 0, byte.MaxValue);
				this.Main.VC.SysConst.AdvancedWarnings[4].AdvancedDays = (uint)this.nEAdvanceDays5.Value;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("SendSystemConstants"));
			if (!this.Main.VC.SendVarBlock(12))
			{
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show("Could not send SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.pnMenu.Enabled = true;
				this.pnMenu.Select();
				return;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("SaveSystemConstOnCPU"));
			if (!this.Main.SaveOnController(1, false))
			{
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show(this.Main.Rm.GetString("MbSaveSysConstFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.pnMenu.Enabled = true;
				this.pnMenu.Select();
				return;
			}
			this.Main.WriteLogbookData(true);
			goto IL_0a21;
			IL_0801:
			this.Main.MakeLogbookEntry(202145u, 3, (float)(int)this.Main.VC.SysConst.AdvancedWarnings[4].EnableAdvancedWarningTime, (float)(this.chBDate_5.Checked ? 1 : 0), 0u, 0, byte.MaxValue);
			this.Main.VC.SysConst.AdvancedWarnings[4].EnableAdvancedWarningTime = (byte)(this.chBDate_5.Checked ? 1 : 0);
			goto IL_0875;
			IL_0a21:
			this.Main.CheckMaintenanceLabel(false);
			this.Main.LoggingFinished(true);
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			this.pnMenu.Enabled = false;
			base.Hide();
			if (sender != null)
			{
				this.Main.MenuMaintenance1.Back();
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_5_1_Menue_Vorwarnwerte";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_5_1_Menue_Vorwarnwerte");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btDeleteMachineCounterNIO_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbDeleteAdvanceWarningCounter"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				if (dialogResult == DialogResult.Yes)
				{
					float oldvalue = (float)(double)this.Main.VC.CycleCount.MachineNIO;
					this.pnMenu.Enabled = false;
					Cursor.Current = Cursors.WaitCursor;
					this.Main.StatusBarText(this.Main.Rm.GetString("DeleteCounter"));
					if (!this.Main.DeleteStatBlock(5))
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						MessageBox.Show(this.Main.Rm.GetString("MbDeleteCounterFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						this.Main.StatusBarText(this.Main.Rm.GetString("LoadCycleCount"));
						if (!this.Main.VC.ReceiveVarBlock(30))
						{
							Cursor.Current = Cursors.Default;
							this.Main.StatusBarText(string.Empty);
							MessageBox.Show("Could not receive CycleCountBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						else
						{
							this.Main.MakeLogbookEntry(204004u, 5, oldvalue, 0f, 0u, 0, byte.MaxValue);
							this.Main.WriteLogbookData(false);
							this.showCounter();
						}
					}
					this.Main.LoggingFinished(false);
					this.pnMenu.Enabled = true;
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
				}
			}
		}

		private void btDeleteCustomCounter_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbDeleteCustomCounter"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				if (dialogResult == DialogResult.Yes)
				{
					float oldvalue = (float)(double)this.Main.VC.CycleCount.Customer;
					this.pnMenu.Enabled = false;
					Cursor.Current = Cursors.WaitCursor;
					this.Main.StatusBarText(this.Main.Rm.GetString("DeleteCounter"));
					if (!this.Main.DeleteStatBlock(1))
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						MessageBox.Show(this.Main.Rm.GetString("MbDeleteCounterFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						this.Main.StatusBarText(this.Main.Rm.GetString("LoadCycleCount"));
						if (!this.Main.VC.ReceiveVarBlock(30))
						{
							Cursor.Current = Cursors.Default;
							this.Main.StatusBarText(string.Empty);
							MessageBox.Show("Could not receive CycleCountBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						else
						{
							this.Main.MakeLogbookEntry(204002u, 5, oldvalue, 0f, 0u, 0, byte.MaxValue);
							this.Main.WriteLogbookData(false);
							this.showCounter();
						}
					}
					this.Main.LoggingFinished(false);
					this.pnMenu.Enabled = true;
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
				}
			}
		}

		private void btDeleteCustomCounterNIO_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbDeleteCustomCounter"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				if (dialogResult == DialogResult.Yes)
				{
					float oldvalue = (float)(double)this.Main.VC.CycleCount.CustomerNIO;
					this.pnMenu.Enabled = false;
					Cursor.Current = Cursors.WaitCursor;
					this.Main.StatusBarText(this.Main.Rm.GetString("DeleteCounter"));
					if (!this.Main.DeleteStatBlock(3))
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						MessageBox.Show(this.Main.Rm.GetString("MbDeleteCounterFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						this.Main.StatusBarText(this.Main.Rm.GetString("LoadCycleCount"));
						if (!this.Main.VC.ReceiveVarBlock(30))
						{
							Cursor.Current = Cursors.Default;
							this.Main.StatusBarText(string.Empty);
							MessageBox.Show("Could not receive CycleCountBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						else
						{
							this.Main.MakeLogbookEntry(204003u, 5, oldvalue, 0f, 0u, 0, byte.MaxValue);
							this.Main.WriteLogbookData(false);
							this.showCounter();
						}
					}
					this.Main.LoggingFinished(false);
					this.pnMenu.Enabled = true;
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
				}
			}
		}

		private void btDeleteCounterX_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				string text = "";
				float num = 0f;
				byte command;
				uint code;
				if (sender == this.btDeleteCounter1)
				{
					num = (float)(double)this.Main.VC.CycleCount.Count[0];
					text = this.lbName1.Text;
					if (text.Length == 0)
					{
						text = "1";
					}
					command = 11;
					code = 204011u;
				}
				else if (sender == this.btDeleteCounter2)
				{
					num = (float)(double)this.Main.VC.CycleCount.Count[1];
					text = this.lbName2.Text;
					if (text.Length == 0)
					{
						text = "2";
					}
					command = 12;
					code = 204012u;
				}
				else if (sender == this.btDeleteCounter3)
				{
					num = (float)(double)this.Main.VC.CycleCount.Count[2];
					text = this.lbName3.Text;
					if (text.Length == 0)
					{
						text = "3";
					}
					command = 13;
					code = 204013u;
				}
				else if (sender == this.btDeleteCounter4)
				{
					num = (float)(double)this.Main.VC.CycleCount.Count[3];
					text = this.tBName4.Text;
					if (text.Length == 0)
					{
						text = "4";
					}
					command = 14;
					code = 204014u;
				}
				else
				{
					if (sender != this.btDeleteCounter5)
					{
						return;
					}
					num = (float)(double)this.Main.VC.CycleCount.Count[4];
					text = this.lbName5.Text;
					if (text.Length == 0)
					{
						text = "5";
					}
					command = 15;
					code = 204015u;
				}
				DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbDeleteCustomCounter") + "\n   (" + text + ")", this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				bool flag = false;
				if (dialogResult == DialogResult.Yes)
				{
					this.pnMenu.Enabled = false;
					Cursor.Current = Cursors.WaitCursor;
					this.Main.StatusBarText(this.Main.Rm.GetString("DeleteCounter"));
					if (!this.Main.DeleteStatBlock(command))
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						MessageBox.Show(this.Main.Rm.GetString("MbDeleteCounterFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						this.Main.StatusBarText(this.Main.Rm.GetString("LoadCycleCount"));
						if (!this.Main.VC.ReceiveVarBlock(30))
						{
							Cursor.Current = Cursors.Default;
							this.Main.StatusBarText(string.Empty);
							MessageBox.Show("Could not receive CycleCountBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						else
						{
							if (num != 0f)
							{
								this.Main.MakeLogbookEntry(code, 5, num, 0f, 0u, 0, byte.MaxValue);
								this.Main.WriteLogbookData(false);
								this.showCounter();
							}
							dialogResult = MessageBox.Show(this.Main.Rm.GetString("EntryInComponentJournal"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
							if (dialogResult == DialogResult.OK)
							{
								flag = true;
							}
						}
					}
					this.Main.LoggingFinished(false);
					this.pnMenu.Enabled = true;
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					this.showCounter();
				}
				if (flag)
				{
					this.btComponents_Click(null, EventArgs.Empty);
					if (this.Main.ActiveMdiChild == this.Main.Component1)
					{
						this.Main.Component1.MakeNewEntry();
					}
				}
			}
		}

		private void chBDate_5_CheckedChanged(object sender, EventArgs e)
		{
			this.dateTimePickerSchedul_5.Enabled = this.chBDate_5.Checked;
			this.nEAdvanceDays5.Enabled = this.chBDate_5.Checked;
		}

		private void btAdvanceWarning_Click(object sender, EventArgs e)
		{
		}

		private void btComponents_Click(object sender, EventArgs e)
		{
			if (this.Main.AreSettingsChanged())
			{
				DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbShouldChangesDiscarded"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);
				if (dialogResult != DialogResult.Yes)
				{
					return;
				}
			}
			this.btCancel_Click(null, EventArgs.Empty);
			this.Main.Component1.ShowWindow();
		}

		private void CycleCounterForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void Start_Input(object sender, EventArgs e)
		{
			this.name4SelectionStart = this.tBName4.SelectionStart;
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void tBName1_TextChanged(object sender, EventArgs e)
		{
		}

		private void tBName2_TextChanged(object sender, EventArgs e)
		{
		}

		private void tBName3_TextChanged(object sender, EventArgs e)
		{
		}

		private void tBName4_TextChanged(object sender, EventArgs e)
		{
			if (!this.bInitialize)
			{
				this.Main.SettingsChanged();
			}
			char[] trimChars = new char[1]
			{
				' '
			};
			if (this.tBName4.Text != this.name4Text)
			{
				this.tBName4.Text = this.tBName4.Text.TrimStart(trimChars);
				string text = this.tBName4.Text;
				for (int i = 0; i < this.tBName4.Text.Length; i++)
				{
					if (text[i] != '-' && text[i] != '_' && text[i] != ' ' && (!char.IsLetterOrDigit(text, i) || text[i] == 'Ö' || text[i] == 'ö' || text[i] == 'Ä' || text[i] == 'ä' || text[i] == 'Ü' || text[i] == 'ü' || text[i] == 'ß'))
					{
						this.tBName4.Text = this.name4Text;
						if (this.name3SelectionStart < 0)
						{
							this.name4SelectionStart = 0;
						}
						this.tBName4.SelectionStart = this.name4SelectionStart;
						return;
					}
				}
				this.name4Text = this.tBName4.Text;
				this.name4SelectionStart = this.tBName4.SelectionStart;
			}
		}

		private void tBName5_TextChanged(object sender, EventArgs e)
		{
		}

		private void tBName1_KeyUp(object sender, KeyEventArgs e)
		{
		}

		private void tBName2_KeyUp(object sender, KeyEventArgs e)
		{
		}

		private void tBName3_KeyUp(object sender, KeyEventArgs e)
		{
		}

		private void tBName4_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode != Keys.Left && e.KeyCode != Keys.Right)
			{
				return;
			}
			this.name4SelectionStart = this.tBName4.SelectionStart;
		}

		private void tBName5_KeyUp(object sender, KeyEventArgs e)
		{
		}

		public void KeyArrived()
		{
			this.MenEna();
			if (this.Main.IsOnlineMode)
			{
				if (this.Main.GetExclusiveBlock1())
				{
					this.Main.ProcessProgram.UploadAllProgDataFromController();
					this.Main.ProcessProgram.InitializeTempProgStruct();
				}
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadSystemConst"));
				if (!this.Main.VC.ReceiveVarBlock(12))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
				}
				else
				{
					this.Main.StatusBarText(this.Main.Rm.GetString("LoadCycleCount"));
					if (!this.Main.VC.ReceiveVarBlock(30))
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
					}
					else
					{
						this.showCounter();
						this.Main.StatusBarText(string.Empty);
					}
				}
			}
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.Main.SettingsChangedReset();
			base.Hide();
			if (sender != null)
			{
				this.Main.MenuMaintenance1.Back();
			}
		}

		private void timer_init_Tick(object sender, EventArgs e)
		{
			Cursor.Current = Cursors.Default;
		}

		private void textChanged(object sender, EventArgs e)
		{
			if (!this.bInitialize)
			{
				this.Main.SettingsChanged();
			}
		}

		private void lbName1_Click(object sender, EventArgs e)
		{
			MessageBox.Show(this.Packet(1, true), this.lbName1.Text);
		}

		private void lbName2_Click(object sender, EventArgs e)
		{
			MessageBox.Show(this.Packet(2, true), this.lbName2.Text);
		}

		private void lbName3_Click(object sender, EventArgs e)
		{
			MessageBox.Show(this.Packet(3, true), this.lbName3.Text);
		}

		private void lbName5_Click(object sender, EventArgs e)
		{
			MessageBox.Show(this.Packet(5, true), this.lbName5.Text);
		}

		private string Packet(int number, bool forMessageBox)
		{
			string text = "--";
			if (forMessageBox)
			{
				switch (number)
				{
				case 1:
					return this.Main.Rm.GetString("PacketChange") + ":\n      " + this.Main.Component1.ComponentText(0) + ", " + this.Main.Component1.ComponentText(1) + ", " + this.Main.Component1.ComponentText(2) + ", " + this.Main.Component1.ComponentText(3) + "\n\n" + this.Main.Rm.GetString("PacketCheck") + ":\n      " + this.Main.Component1.ComponentText(9) + ", " + this.Main.Component1.ComponentText(10) + ", " + this.Main.Component1.ComponentText(11);
				case 2:
					return this.Main.Rm.GetString("PacketChange") + ":\n       " + this.Main.Component1.ComponentText(4) + ", " + this.Main.Component1.ComponentText(5) + "\n\n" + this.Main.Rm.GetString("PacketCheck") + ":\n       " + this.Main.Component1.ComponentText(12) + ", " + this.Main.Component1.ComponentText(13);
				case 3:
					return this.Main.Rm.GetString("PacketChange") + ":\n       " + this.Main.Component1.ComponentText(6) + ", " + this.Main.Component1.ComponentText(7) + "\n\n" + this.Main.Rm.GetString("PacketCheck") + ":\n       " + this.Main.Component1.ComponentText(14) + ", " + this.Main.Component1.ComponentText(15) + ", " + this.Main.Component1.ComponentText(16) + ", " + this.Main.Component1.ComponentText(17);
				case 5:
					return this.Main.Component1.ComponentText(8);
				default:
					return "--";
				}
			}
			switch (number)
			{
			case 1:
				return this.Main.Rm.GetString("PacketChange") + ": " + this.Main.Component1.ComponentText(0) + ", " + this.Main.Component1.ComponentText(1) + ", " + this.Main.Component1.ComponentText(2) + ", " + this.Main.Component1.ComponentText(3) + "\n" + this.Main.Rm.GetString("PacketCheck") + ": " + this.Main.Component1.ComponentText(9) + ", " + this.Main.Component1.ComponentText(10) + ", " + this.Main.Component1.ComponentText(11);
			case 2:
				return this.Main.Rm.GetString("PacketChange") + ": " + this.Main.Component1.ComponentText(4) + ", " + this.Main.Component1.ComponentText(5) + "\n" + this.Main.Rm.GetString("PacketCheck") + ": " + this.Main.Component1.ComponentText(12) + ", " + this.Main.Component1.ComponentText(13);
			case 3:
				return this.Main.Rm.GetString("PacketChange") + ":  " + this.Main.Component1.ComponentText(6) + ", " + this.Main.Component1.ComponentText(7) + "\n" + this.Main.Rm.GetString("PacketCheck") + ":  " + this.Main.Component1.ComponentText(14) + ", " + this.Main.Component1.ComponentText(15) + ", " + this.Main.Component1.ComponentText(16) + ", " + this.Main.Component1.ComponentText(17);
			case 5:
				return this.Main.Component1.ComponentText(8);
			default:
				return "--";
			}
		}
	}
}
