using System.Collections.Generic;

namespace Visualisation
{
	public class FileWithAttrList
	{
		private List<FileWithAttrClass> selectedFiles = new List<FileWithAttrClass>();

		public void Add(string filename, string cluster, bool enabled)
		{
			FileWithAttrClass item = new FileWithAttrClass(filename, cluster, enabled);
			this.selectedFiles.Add(item);
		}

		public void Disable(string cluster)
		{
			foreach (FileWithAttrClass selectedFile in this.selectedFiles)
			{
				if (selectedFile.Cluster == cluster)
				{
					selectedFile.Enabled = false;
				}
			}
		}

		public List<string> GetFileList()
		{
			List<string> list = new List<string>();
			foreach (FileWithAttrClass selectedFile in this.selectedFiles)
			{
				if (selectedFile.Enabled)
				{
					list.Add(selectedFile.Filename);
				}
			}
			return list;
		}
	}
}
