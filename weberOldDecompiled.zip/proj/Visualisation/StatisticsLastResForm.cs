using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class StatisticsLastResForm : Form
	{
		private MainForm Main;

		private int PrintPos;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Container components;

		private Button btDeleteValues;

		private Button btPrint;

		private PrintDocument printDocument;

		private PrintDialog printDialog;

		private Button btExport;

		private DataGridView dGVResults;

		private Button btShowCurve;

		private Button btStepResults;

		private Button btLast5NIO;

		private SaveFileDialog SFD;

		private bool fistTimeInitialiseationDone;

		public StatisticsLastResForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.PrintPos = 0;
			this.dGVResults.Columns.Add("Col1", "Nr");
			this.dGVResults.Columns.Add("Col2", "ProgNum");
			this.dGVResults.Columns.Add("Col3", "Res1");
			this.dGVResults.Columns.Add("Col4", "Res2");
			this.dGVResults.Columns.Add("Col5", "Res3");
			this.dGVResults.Columns.Add("Col6", "IONIO");
			this.dGVResults.Columns.Add("Col7", "Duration");
			this.dGVResults.Columns.Add("Col8", "ID");
			this.dGVResults.Columns.Add("Col9", "Cycle");
			this.dGVResults.Columns.Add("Col10", "DateTime");
			this.dGVResults.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
			this.dGVResults.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
			this.dGVResults.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
			this.dGVResults.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
			this.dGVResults.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
			this.pnMenu = new Panel();
			this.btLast5NIO = new Button();
			this.btStepResults = new Button();
			this.btShowCurve = new Button();
			this.btPrint = new Button();
			this.btExport = new Button();
			this.btDeleteValues = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.printDocument = new PrintDocument();
			this.printDialog = new PrintDialog();
			this.SFD = new SaveFileDialog();
			this.dGVResults = new DataGridView();
			this.pnMenu.SuspendLayout();
			((ISupportInitialize)this.dGVResults).BeginInit();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btLast5NIO);
			this.pnMenu.Controls.Add(this.btStepResults);
			this.pnMenu.Controls.Add(this.btShowCurve);
			this.pnMenu.Controls.Add(this.btPrint);
			this.pnMenu.Controls.Add(this.btExport);
			this.pnMenu.Controls.Add(this.btDeleteValues);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btLast5NIO.Location = new Point(3, 195);
			this.btLast5NIO.Name = "btLast5NIO";
			this.btLast5NIO.Size = new Size(74, 62);
			this.btLast5NIO.TabIndex = 8;
			this.btLast5NIO.Text = "Letzten 5 NIO";
			this.btLast5NIO.Click += this.btLast5NIO_Click;
			this.btStepResults.Location = new Point(3, 130);
			this.btStepResults.Name = "btStepResults";
			this.btStepResults.Size = new Size(74, 62);
			this.btStepResults.TabIndex = 11;
			this.btStepResults.Text = "Stufenergebnisse";
			this.btStepResults.Click += this.btStepResults_Click;
			this.btShowCurve.Enabled = false;
			this.btShowCurve.Location = new Point(3, 323);
			this.btShowCurve.Name = "btShowCurve";
			this.btShowCurve.Size = new Size(74, 62);
			this.btShowCurve.TabIndex = 10;
			this.btShowCurve.Text = "Current curve";
			this.btShowCurve.Click += this.btShowCurve_Click;
			this.btPrint.Location = new Point(3, 451);
			this.btPrint.Name = "btPrint";
			this.btPrint.Size = new Size(74, 62);
			this.btPrint.TabIndex = 7;
			this.btPrint.Text = "Print";
			this.btPrint.Click += this.btPrint_Click;
			this.btExport.Location = new Point(3, 387);
			this.btExport.Name = "btExport";
			this.btExport.Size = new Size(74, 62);
			this.btExport.TabIndex = 6;
			this.btExport.Text = "Exportieren";
			this.btExport.Click += this.btExport_Click;
			this.btDeleteValues.Location = new Point(3, 260);
			this.btDeleteValues.Name = "btDeleteValues";
			this.btDeleteValues.Size = new Size(74, 62);
			this.btDeleteValues.TabIndex = 2;
			this.btDeleteValues.Text = "Werte löschen";
			this.btDeleteValues.Click += this.btDeleteValues_Click;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.printDocument.DocumentName = "LastResults";
			this.printDocument.PrintPage += this.printDocument_PrintPage;
			this.printDialog.Document = this.printDocument;
			this.SFD.Filter = "Last Results|*.txt|All Files|*.*";
			this.dGVResults.AllowUserToAddRows = false;
			this.dGVResults.AllowUserToDeleteRows = false;
			this.dGVResults.AllowUserToOrderColumns = true;
			this.dGVResults.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = SystemColors.Window;
			dataGridViewCellStyle.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			dataGridViewCellStyle.ForeColor = SystemColors.ControlText;
			dataGridViewCellStyle.SelectionBackColor = SystemColors.Highlight;
			dataGridViewCellStyle.SelectionForeColor = SystemColors.HighlightText;
			this.dGVResults.DefaultCellStyle = dataGridViewCellStyle;
			this.dGVResults.Location = new Point(0, 0);
			this.dGVResults.MultiSelect = false;
			this.dGVResults.Name = "dGVResults";
			this.dGVResults.ReadOnly = true;
			this.dGVResults.RowHeadersVisible = false;
			this.dGVResults.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			this.dGVResults.Size = new Size(709, 522);
			this.dGVResults.TabIndex = 2;
			this.dGVResults.ColumnAdded += this.dGVResults_ColumnAdded;
			this.dGVResults.SelectionChanged += this.dGVResults_SelectionChanged;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.dGVResults);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "StatisticsLastResForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Auswertung/Statistik/Letzte Ergebnisse";
			base.Activated += this.StatisticsLastResForm_Activated;
			this.pnMenu.ResumeLayout(false);
			((ISupportInitialize)this.dGVResults).EndInit();
			base.ResumeLayout(false);
		}

		public bool ShowWindow()
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadLastResults"));
			if (!this.Main.VC.ReceiveVarBlock(32))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive StatSampleBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.Main.ActivationBrowserGrantedBy = this;
			this.MenEna();
			this.Main.StatusBarText(this.Main.Rm.GetString("WriteLastResultsTable"));
			this.UpdateMenu();
			base.Show();
			Cursor.Current = Cursors.Default;
			this.Main.StatusBarText(string.Empty);
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuAnalysis") + "/" + this.Main.Rm.GetString("StatisticsLastRes");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btDeleteValues.Text = this.Main.Rm.GetString("DeleteValues");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btPrint.Text = this.Main.Rm.GetString("Print");
			this.btExport.Text = this.Main.Rm.GetString("ExportLastResults");
			this.btShowCurve.Text = this.Main.Rm.GetString("lbCurrentCurve");
			this.btLast5NIO.Text = this.Main.Rm.GetString("LastNIO");
			this.btStepResults.Text = this.Main.Rm.GetString("StepResults");
			this.SFD.Filter = this.Main.Rm.GetString("StatisticsLastRes") + "|*.txt|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.printDocument.DocumentName = this.Main.Rm.GetString("StatisticsLastRes");
			this.dGVResults.Columns[0].HeaderText = this.Main.Rm.GetString("AbrNumber");
			this.dGVResults.Columns[1].HeaderText = this.Main.Rm.GetString("ProgramNumber");
			this.dGVResults.Columns[2].HeaderText = this.Main.Rm.GetString("Result") + "1";
			this.dGVResults.Columns[3].HeaderText = this.Main.Rm.GetString("Result") + "2";
			this.dGVResults.Columns[4].HeaderText = this.Main.Rm.GetString("Result") + "3";
			this.dGVResults.Columns[5].HeaderText = this.Main.Rm.GetString("OKNOK");
			this.dGVResults.Columns[6].HeaderText = this.Main.Rm.GetString("ScrewTime");
			this.dGVResults.Columns[7].HeaderText = this.Main.Rm.GetString("ScrewID");
			this.dGVResults.Columns[8].HeaderText = this.Main.Rm.GetString("Cycle");
			this.dGVResults.Columns[9].HeaderText = this.Main.Rm.GetString("DateTime");
		}

		private void MenEna()
		{
			bool enabled = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_StatisticsLastResForm)
			{
				enabled = true;
			}
			if (this.Main.Usb_Key_Access())
			{
				this.btDeleteValues.Text = this.Main.Rm.GetString("DeleteValues");
				this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_StatisticsLastResForm, false);
			}
			else
			{
				this.btDeleteValues.Text = "";
			}
			this.btDeleteValues.Enabled = enabled;
		}

		public void UpdateMenu()
		{
			int num = 0;
			string empty = string.Empty;
			float num2 = 0f;
			this.dGVResults.Rows.Clear();
			if (this.Main.VC.StatSample.Info.Length > 0)
			{
				this.dGVResults.Rows.Add(this.Main.VC.StatSample.Info.Length);
				num = this.Main.VC.StatSample.Info.Position - 1;
				bool flag = false;
				try
				{
					for (int i = 0; i < this.Main.VC.StatSample.Info.Length; i++)
					{
						this.dGVResults.Rows[i].Cells[0].Value = i + 1;
						string text = this.Main.CommonFunctions.ByteToString(this.Main.VC.StatSample.Data[num].ProgName);
						if (text.Length == 0)
						{
							this.dGVResults.Rows[i].Cells[1].Value = this.Main.VC.StatSample.Data[num].ProgNum.ToString();
						}
						else
						{
							flag = true;
							this.dGVResults.Rows[i].Cells[1].Value = text;
						}
						if ((this.Main.VC.StatSample.Data[num].Valid & 1) > 0)
						{
							empty = this.Main.CommonFunctions.GetResName(this.Main.VC.StatSample.Data[num].ResultParam1) + "(" + (this.Main.VC.StatSample.Data[num].ResultStep1 + 1).ToString() + "): ";
							num2 = (1f + this.Main.CommonFunctions.GetResFactor(this.Main.VC.StatSample.Data[num].ResultParam1) * (this.Main.TorqueConvert - 1f)) * this.Main.VC.StatSample.Data[num].Res1;
							empty += Math.Round((double)num2, this.Main.CommonFunctions.GetResDigits(this.Main.VC.StatSample.Data[num].ResultParam1)).ToString();
							empty += this.Main.CommonFunctions.GetResUnit(this.Main.VC.StatSample.Data[num].ResultParam1, this.Main.TorqueUnitName);
						}
						else
						{
							empty = this.Main.Rm.GetString("NotValid");
						}
						this.dGVResults.Rows[i].Cells[2].Value = empty;
						if ((this.Main.VC.StatSample.Data[num].Valid & 2) > 0)
						{
							empty = this.Main.CommonFunctions.GetResName(this.Main.VC.StatSample.Data[num].ResultParam2) + "(" + (this.Main.VC.StatSample.Data[num].ResultStep2 + 1).ToString() + "): ";
							num2 = (1f + this.Main.CommonFunctions.GetResFactor(this.Main.VC.StatSample.Data[num].ResultParam2) * (this.Main.TorqueConvert - 1f)) * this.Main.VC.StatSample.Data[num].Res2;
							empty += Math.Round((double)num2, this.Main.CommonFunctions.GetResDigits(this.Main.VC.StatSample.Data[num].ResultParam2)).ToString();
							empty += this.Main.CommonFunctions.GetResUnit(this.Main.VC.StatSample.Data[num].ResultParam2, this.Main.TorqueUnitName);
						}
						else
						{
							empty = this.Main.Rm.GetString("NotValid");
						}
						this.dGVResults.Rows[i].Cells[3].Value = empty;
						if ((this.Main.VC.StatSample.Data[num].Valid & 4) > 0)
						{
							empty = this.Main.CommonFunctions.GetResName(this.Main.VC.StatSample.Data[num].ResultParam3) + "(" + (this.Main.VC.StatSample.Data[num].ResultStep3 + 1).ToString() + "): ";
							num2 = (1f + this.Main.CommonFunctions.GetResFactor(this.Main.VC.StatSample.Data[num].ResultParam3) * (this.Main.TorqueConvert - 1f)) * this.Main.VC.StatSample.Data[num].Res3;
							empty += Math.Round((double)num2, this.Main.CommonFunctions.GetResDigits(this.Main.VC.StatSample.Data[num].ResultParam3)).ToString();
							empty += this.Main.CommonFunctions.GetResUnit(this.Main.VC.StatSample.Data[num].ResultParam3, this.Main.TorqueUnitName);
						}
						else
						{
							empty = this.Main.Rm.GetString("NotValid");
						}
						this.dGVResults.Rows[i].Cells[4].Value = empty;
						switch (this.Main.VC.StatSample.Data[num].IONIO)
						{
						case 1:
							empty = this.Main.Rm.GetString("OK");
							break;
						case 0:
							empty = "n. def.";
							break;
						default:
							empty = this.Main.Rm.GetString("NOK") + ": " + this.Main.Rm.GetString("NIO" + this.Main.VC.StatSample.Data[num].IONIO.ToString()) + "(" + (this.Main.VC.StatSample.Data[num].LastStep + 1).ToString() + ")";
							break;
						}
						this.dGVResults.Rows[i].Cells[5].Value = empty;
						this.dGVResults.Rows[i].Cells[6].Value = this.Main.VC.StatSample.Data[num].ScrewDuration.ToString("f" + 2.ToString()) + this.Main.Rm.GetString("Second");
						this.dGVResults.Rows[i].Cells[7].Value = this.Main.CommonFunctions.ByteToString(this.Main.VC.StatSample.Data[num].ScrewID);
						this.dGVResults.Rows[i].Cells[8].Value = this.Main.VC.StatSample.Data[num].Cycle;
						DateTime dateTime;
						try
						{
							dateTime = new DateTime(this.Main.VC.StatSample.Data[num].Time.Year, this.Main.VC.StatSample.Data[num].Time.Month, this.Main.VC.StatSample.Data[num].Time.Day, this.Main.VC.StatSample.Data[num].Time.Hour, this.Main.VC.StatSample.Data[num].Time.Minute, this.Main.VC.StatSample.Data[num].Time.Second);
						}
						catch
						{
							dateTime = new DateTime(1, 1, 1, 0, 0, 0);
						}
						this.dGVResults.Rows[i].Cells[9].Value = dateTime.ToString(Settings.Default.TimeSet);
						num--;
						if (num < 0)
						{
							num = 1999;
						}
					}
					if (!flag)
					{
						this.dGVResults.Columns[1].HeaderText = this.Main.Rm.GetString("ProgramNumber");
					}
					else
					{
						this.dGVResults.Columns[1].HeaderText = this.Main.Rm.GetString("Name");
					}
					if (!this.fistTimeInitialiseationDone)
					{
						this.dGVResults.Columns[0].Width = 30;
						this.dGVResults.Columns[1].Width = 60;
						this.dGVResults.Columns[2].Width = 65;
						this.dGVResults.Columns[3].Width = 65;
						this.dGVResults.Columns[4].Width = 65;
						this.dGVResults.Columns[6].Width = 95;
						this.dGVResults.Columns[7].Width = 60;
						this.dGVResults.Columns[8].Width = 60;
					}
					this.fistTimeInitialiseationDone = true;
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message, "Internal Error");
				}
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_2_3_1_Letzte_Ergebnisse";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_2_3_1_Letzte_Ergebnisse");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btDeleteValues_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbDeleteLastResults"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				if (dialogResult == DialogResult.Yes)
				{
					Cursor.Current = Cursors.WaitCursor;
					this.Main.StatusBarText(this.Main.Rm.GetString("DeleteLastResults"));
					this.pnMenu.Enabled = false;
					if (!this.Main.DeleteStatBlock(2))
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						MessageBox.Show(this.Main.Rm.GetString("MbDeleteLastResFailure"), "MbhError", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						this.Main.StatusBarText(this.Main.Rm.GetString("LoadLastResults"));
						if (!this.Main.VC.ReceiveVarBlock(32))
						{
							Cursor.Current = Cursors.Default;
							this.Main.StatusBarText(string.Empty);
							MessageBox.Show("Could not receive StatSampleBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						else
						{
							this.Main.MakeLogbookEntry(204001u, 5, 0f, 0f, 0u, 0, byte.MaxValue);
							this.Main.WriteLogbookData(true);
							this.UpdateMenu();
						}
					}
					this.Main.LoggingFinished(true);
					this.pnMenu.Enabled = true;
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText("");
				}
			}
		}

		private void StatisticsLastResForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void btPrint_Click(object sender, EventArgs e)
		{
			if (this.printDialog.ShowDialog() == DialogResult.OK)
			{
				this.printDocument.DefaultPageSettings.Margins.Bottom = 50;
				this.printDocument.DefaultPageSettings.Margins.Left = 50;
				this.printDocument.DefaultPageSettings.Margins.Right = 50;
				this.printDocument.DefaultPageSettings.Margins.Top = 50;
				this.printDocument.Print();
			}
		}

		private void printDocument_PrintPage(object sender, PrintPageEventArgs e)
		{
			float num = 0f;
			float num2 = 0f;
			float num3 = 0f;
			float num4 = 0f;
			int count = this.dGVResults.Columns.Count;
			float[] array = new float[count + 1];
			string empty = string.Empty;
			DateTime now = DateTime.Now;
			Graphics graphics = e.Graphics;
			float num5 = (float)e.MarginBounds.Left;
			float x = (float)e.MarginBounds.Right;
			float num6 = (float)e.MarginBounds.Bottom;
			float num7 = (float)e.MarginBounds.Top;
			Font font = new Font("Arial", 10f, FontStyle.Bold);
			Pen pen = new Pen(Brushes.Black);
			for (int i = 0; i < count; i++)
			{
				array[i] = (float)this.dGVResults.Columns[i].Width;
				num += array[i];
			}
			num3 = (float)e.MarginBounds.Width / num;
			Font font2 = new Font("Arial Unicode MS", 11f * num3, GraphicsUnit.Pixel);
			num = num5;
			for (int i = 0; i <= count; i++)
			{
				num4 = num;
				num += array[i] * num3;
				array[i] = num4;
			}
			num2 = num7;
			if (this.PrintPos <= 0)
			{
				empty = this.Main.Rm.GetString("StatisticsLastRes") + " (" + now.ToString(Settings.Default.TimeSet) + ")";
				graphics.DrawString(empty, font, Brushes.Black, new RectangleF((float)e.MarginBounds.Left, num2, (float)e.MarginBounds.Width, (float)e.MarginBounds.Bottom - num2));
				num2 += font.GetHeight();
				this.PrintPos = -1;
			}
			num7 = num2;
			num = num5;
			graphics.DrawLine(pen, num5, num2, x, num2);
			for (int i = this.PrintPos; i < this.dGVResults.Rows.Count; i++)
			{
				if (i == -1)
				{
					for (int j = 0; j < count; j++)
					{
						string headerText = this.dGVResults.Columns[j].HeaderText;
						graphics.DrawString(headerText, font2, Brushes.Black, array[j], num2);
					}
				}
				else
				{
					for (int j = 0; j < count; j++)
					{
						string headerText = this.dGVResults.Rows[i].Cells[j].Value.ToString();
						graphics.DrawString(headerText, font2, Brushes.Black, array[j], num2);
					}
				}
				num2 += font2.GetHeight();
				graphics.DrawLine(pen, num5, num2, x, num2);
				if (num2 > num6)
				{
					if (this.dGVResults.Rows.Count - i > 1)
					{
						this.PrintPos = i + 1;
					}
					break;
				}
				this.PrintPos = 0;
			}
			graphics.DrawLine(pen, num, num7, num, num2);
			for (int i = 0; i <= count; i++)
			{
				graphics.DrawLine(pen, array[i], num7, array[i], num2);
			}
			empty = "\n" + this.Main.Rm.GetString("MachineCounter") + ": " + this.Main.VC.CycleCount.Machine.ToString() + "\n";
			font2.Dispose();
			font.Dispose();
			if (this.PrintPos > 0)
			{
				e.HasMorePages = true;
			}
		}

		private void btExport_Click(object sender, EventArgs e)
		{
			string empty = string.Empty;
			CultureInfo invariantCulture = CultureInfo.InvariantCulture;
			DialogResult dialogResult = this.SFD.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				try
				{
					StreamWriter streamWriter = new StreamWriter(this.SFD.FileName);
					empty = this.dGVResults.Columns[0].HeaderText;
					for (int i = 1; i < this.dGVResults.Columns.Count; i++)
					{
						empty = empty + ";" + this.dGVResults.Columns[i].HeaderText;
					}
					streamWriter.WriteLine(empty);
					for (int j = 0; j < this.dGVResults.Rows.Count; j++)
					{
						empty = this.dGVResults.Rows[j].Cells[0].Value.ToString();
						for (int i = 1; i < this.dGVResults.Columns.Count; i++)
						{
							empty = empty + ";" + this.dGVResults.Rows[j].Cells[i].Value.ToString();
						}
						streamWriter.WriteLine(empty);
					}
					streamWriter.Close();
					streamWriter.Dispose();
				}
				catch (Exception ex)
				{
					MessageBox.Show("Could not open file! " + ex.Message, "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void dGVResults_ColumnAdded(object sender, DataGridViewColumnEventArgs e)
		{
			if (e.Column.Index == 9)
			{
				e.Column.SortMode = DataGridViewColumnSortMode.NotSortable;
			}
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
			this.MenEna();
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void btShowCurve_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.Main.CurveDisplay1.ShowWindow();
		}

		private void dGVResults_SelectionChanged(object sender, EventArgs e)
		{
			this.Main.NioCurveToShow = "";
			if (this.dGVResults.SelectedRows.Count == 0)
			{
				this.btShowCurve.Enabled = false;
			}
			else
			{
				int index = this.dGVResults.SelectedRows[0].Index;
				uint num = 0u;
				uint.TryParse(this.dGVResults.Rows[index].Cells[8].Value.ToString(), out num);
				string path = Settings.Default.Curve_StoringFIFO_Directory + "\\";
				string text = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.SystemID) + "_C" + num.ToString("00000000");
				string[] files;
				try
				{
					files = Directory.GetFiles(path, "*.wcrv");
				}
				catch (Exception)
				{
					this.btShowCurve.Enabled = false;
					return;
				}
				if (files.Length == 0)
				{
					this.btShowCurve.Enabled = false;
				}
				else
				{
					bool flag = false;
					string[] array = files;
					foreach (string text2 in array)
					{
						string fileName = Path.GetFileName(text2);
						if (fileName.StartsWith(text))
						{
							text = text2;
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						this.btShowCurve.Enabled = false;
					}
					else if (!File.Exists(text))
					{
						this.btShowCurve.Enabled = false;
					}
					else
					{
						this.btShowCurve.Enabled = true;
						this.Main.NioCurveToShow = text;
					}
				}
			}
		}

		private void btStepResults_Click(object sender, EventArgs e)
		{
			this.btBack_Click(null, EventArgs.Empty);
			this.pnMenu.Enabled = false;
			if (this.Main.IsOnlineMode)
			{
				this.Main.StepResult1.ShowWindow();
			}
			else
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.pnMenu.Enabled = true;
				this.MenEna();
			}
		}

		private void btLast5NIO_Click(object sender, EventArgs e)
		{
			this.btBack_Click(null, EventArgs.Empty);
			this.pnMenu.Enabled = false;
			if (!this.Main.LastNIOResults1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
				this.MenEna();
			}
		}
	}
}
