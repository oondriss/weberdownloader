using System;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Xml;

namespace Visualisation
{
	public class C_CurveOutput
	{
		private MainForm Main;

		public C_CurveOutput(MainForm main)
		{
			this.Main = main;
		}

		public bool ExportToTxt(string filename, string[] curveName, string[] curveUnit, float[,] curveData, S_ResultData resData)
		{
			string empty = string.Empty;
			try
			{
				StreamWriter streamWriter = new StreamWriter(filename);
				empty = curveName[0] + "[" + curveUnit[0] + "]";
				for (int i = 1; i < 11; i++)
				{
					empty = empty + ";" + curveName[i] + "[" + curveUnit[i] + "]";
				}
				streamWriter.WriteLine(empty);
				for (int j = 0; j < resData.curvelength; j++)
				{
					empty = curveData[0, j].ToString();
					for (int i = 1; i < curveData.GetLength(0); i++)
					{
						empty = empty + ";" + curveData[i, j].ToString();
					}
					streamWriter.WriteLine(empty);
				}
				streamWriter.Close();
				streamWriter.Dispose();
				return true;
			}
			catch (Exception ex)
			{
				MessageBox.Show("Could not open file! " + ex.Message, "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
		}

		public bool ExportToXml(string filename, string[] curveName, string[] curveUnit, float[,] curveData, S_ResultData resData)
		{
			string empty = string.Empty;
			CultureInfo provider = CultureInfo.CreateSpecificCulture("en-CA");
			XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
			xmlWriterSettings.NewLineOnAttributes = true;
			try
			{
				using (FileStream stream = new FileStream(filename, FileMode.Create))
				{
					using (StreamWriter w = new StreamWriter(stream))
					{
						using (XmlTextWriter xmlTextWriter = new XmlTextWriter(w))
						{
							xmlTextWriter.Formatting = Formatting.Indented;
							xmlTextWriter.Indentation = 2;
							xmlTextWriter.WriteStartDocument();
							xmlTextWriter.WriteStartElement("XML_Data");
							xmlTextWriter.WriteStartElement("Wsk3Header");
							xmlTextWriter.WriteElementString("Version", "C50S" + Assembly.GetExecutingAssembly().GetName().Version.ToString());
							xmlTextWriter.WriteElementString("Date", resData.dt.ToString("dd'.'MM'.'yyyy"));
							xmlTextWriter.WriteElementString("Time", resData.dt.ToString("HH':'mm':'ss"));
							xmlTextWriter.WriteElementString("Title", "C50S_Curve");
							xmlTextWriter.WriteElementString("NumberofYAxes", 11.ToString());
							xmlTextWriter.WriteElementString("NumberOfVectors", resData.curvelength.ToString());
							xmlTextWriter.WriteStartElement("Controller");
							xmlTextWriter.WriteElementString("Type", "C50S_WSP2");
							xmlTextWriter.WriteElementString("Id", this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.SystemID));
							xmlTextWriter.WriteEndElement();
							xmlTextWriter.WriteStartElement("ProcessProg");
							xmlTextWriter.WriteElementString("Number", resData.prog.ToString());
							xmlTextWriter.WriteElementString("Name", "");
							xmlTextWriter.WriteElementString("Type", "");
							xmlTextWriter.WriteEndElement();
							xmlTextWriter.WriteStartElement("Result");
							xmlTextWriter.WriteElementString("Cycle", resData.cycle.ToString());
							xmlTextWriter.WriteElementString("PartID", resData.screwID);
							xmlTextWriter.WriteElementString("Kind", "");
							xmlTextWriter.WriteStartElement("NumericalResultList");
							xmlTextWriter.WriteEndElement();
							xmlTextWriter.WriteEndElement();
							xmlTextWriter.WriteEndElement();
							xmlTextWriter.WriteStartElement("Wsk3Vectors");
							xmlTextWriter.WriteStartElement("X_Axis");
							xmlTextWriter.WriteElementString("_Index", "0");
							xmlTextWriter.WriteStartElement("Header");
							xmlTextWriter.WriteElementString("Name", curveName[0]);
							xmlTextWriter.WriteElementString("Unit", curveUnit[0]);
							xmlTextWriter.WriteEndElement();
							xmlTextWriter.WriteStartElement("Values");
							for (int i = 0; i < resData.curvelength; i++)
							{
								xmlTextWriter.WriteElementString("float", ((int)curveData[0, i]).ToString());
							}
							xmlTextWriter.WriteEndElement();
							xmlTextWriter.WriteEndElement();
							xmlTextWriter.WriteStartElement("Y_AxesList");
							for (int j = 1; j < 12; j++)
							{
								xmlTextWriter.WriteStartElement("AxisData");
								xmlTextWriter.WriteElementString("_Index", (j - 1).ToString());
								xmlTextWriter.WriteStartElement("Header");
								if (j == 11)
								{
									xmlTextWriter.WriteElementString("Name", "Step");
									xmlTextWriter.WriteElementString("Unit", "-");
								}
								else
								{
									xmlTextWriter.WriteElementString("Name", curveName[j]);
									xmlTextWriter.WriteElementString("Unit", curveUnit[j]);
								}
								xmlTextWriter.WriteEndElement();
								xmlTextWriter.WriteStartElement("Values");
								for (int i = 0; i < resData.curvelength; i++)
								{
									xmlTextWriter.WriteElementString("float", curveData[j, i].ToString("f3", provider));
								}
								xmlTextWriter.WriteEndElement();
								xmlTextWriter.WriteEndElement();
							}
							xmlTextWriter.WriteEndElement();
							xmlTextWriter.WriteEndElement();
							xmlTextWriter.WriteEndElement();
							xmlTextWriter.WriteEndDocument();
							xmlTextWriter.Flush();
							xmlTextWriter.Close();
							return true;
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Could not open file! " + ex.Message, "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
		}
	}
}
