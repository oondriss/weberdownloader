namespace Visualisation
{
	public class ZipClass
	{
		public bool Zip()
		{
			return false;
		}

		public bool UnZip()
		{
			return false;
		}
	}
}
