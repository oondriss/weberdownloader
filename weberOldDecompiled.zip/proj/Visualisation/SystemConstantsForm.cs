using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class SystemConstantsForm : Form
	{
		private MainForm Main;

		private int IDSelectionStart;

		private string IDNewText;

		private int IdentServerSelectionStart;

		private int AreaCodeSelectionStart;

		private string IdentServerNewText;

		private string AreaCodeNewText;

		private bool UpdateControllerTime;

		private bool initInProgress;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Button btPasscodeManager;

		private Button btVisuParam;

		private Timer timerUpdate;

		private Button btCancel;

		private Button bt3;

		private Button bt2;

		private Button btLevelAssignment;

		private GroupBox gBDateTime;

		private Label lbShowLocalTime;

		private Button btTimeSynchronize;

		private Label lbLocalTime;

		private Label lbControllerTime;

		private DateTimePicker dateTimePicker;

		private Button btTimeSet;

		private GroupBox gBTorque;

		private ComboBox cBTorqueUnit;

		private Label lbTorqueUnit;

		private GroupBox gBIdentity;

		private Label lbID;

		private TextBox tBID;

		private Label lbIdentServer;

		private TextBox tBIdentServer;

		private GroupBox gBIP;

		private NumberEdit1 nEIP1;

		private Label lbIP;

		private NumberEdit1 nEIP4;

		private NumberEdit1 nEIP2;

		private NumberEdit1 nEIP3;

		private NumberEdit1 nESubnet3;

		private NumberEdit1 nESubnet2;

		private NumberEdit1 nESubnet4;

		private Label lbSubnetMask;

		private NumberEdit1 nESubnet1;

		private GroupBox gBRS232;

		private ComboBox cBBaudrate;

		private Label lbBaudrate;

		private Label lbParity;

		private ComboBox cBParity;

		private GroupBox gBVersionInfo;

		private Label lbVersionController;

		private Label lbVersionVisualisation;

		private Label lbShowVersionController;

		private Label lbShowVersionVisualisation;

		private CheckBox chBDHCP;

		private NumberEdit1 nEDG3;

		private NumberEdit1 nEDG2;

		private NumberEdit1 nEDG4;

		private Label lbDG;

		private NumberEdit1 nEDG1;

		private Label lbAreaCode;

		private TextBox tbAreaCode;

		private IContainer components;

		public SystemConstantsForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.UpdateControllerTime = true;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			this.pnMenu = new Panel();
			this.btCancel = new Button();
			this.bt3 = new Button();
			this.bt2 = new Button();
			this.btLevelAssignment = new Button();
			this.btVisuParam = new Button();
			this.btPasscodeManager = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.timerUpdate = new Timer(this.components);
			this.gBDateTime = new GroupBox();
			this.lbShowLocalTime = new Label();
			this.btTimeSynchronize = new Button();
			this.lbLocalTime = new Label();
			this.lbControllerTime = new Label();
			this.dateTimePicker = new DateTimePicker();
			this.btTimeSet = new Button();
			this.gBTorque = new GroupBox();
			this.cBTorqueUnit = new ComboBox();
			this.lbTorqueUnit = new Label();
			this.gBIdentity = new GroupBox();
			this.lbAreaCode = new Label();
			this.tbAreaCode = new TextBox();
			this.lbID = new Label();
			this.tBID = new TextBox();
			this.lbIdentServer = new Label();
			this.tBIdentServer = new TextBox();
			this.gBIP = new GroupBox();
			this.chBDHCP = new CheckBox();
			this.nEDG3 = new NumberEdit1();
			this.nEDG2 = new NumberEdit1();
			this.nEDG4 = new NumberEdit1();
			this.lbDG = new Label();
			this.nEDG1 = new NumberEdit1();
			this.nEIP1 = new NumberEdit1();
			this.lbIP = new Label();
			this.nEIP4 = new NumberEdit1();
			this.nEIP2 = new NumberEdit1();
			this.nEIP3 = new NumberEdit1();
			this.nESubnet3 = new NumberEdit1();
			this.nESubnet2 = new NumberEdit1();
			this.nESubnet4 = new NumberEdit1();
			this.lbSubnetMask = new Label();
			this.nESubnet1 = new NumberEdit1();
			this.gBRS232 = new GroupBox();
			this.cBBaudrate = new ComboBox();
			this.lbBaudrate = new Label();
			this.lbParity = new Label();
			this.cBParity = new ComboBox();
			this.gBVersionInfo = new GroupBox();
			this.lbShowVersionVisualisation = new Label();
			this.lbShowVersionController = new Label();
			this.lbVersionController = new Label();
			this.lbVersionVisualisation = new Label();
			this.pnMenu.SuspendLayout();
			this.gBDateTime.SuspendLayout();
			this.gBTorque.SuspendLayout();
			this.gBIdentity.SuspendLayout();
			this.gBIP.SuspendLayout();
			this.gBRS232.SuspendLayout();
			this.gBVersionInfo.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.btLevelAssignment);
			this.pnMenu.Controls.Add(this.btVisuParam);
			this.pnMenu.Controls.Add(this.btPasscodeManager);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 4;
			this.btCancel.Text = "Abbruch";
			this.btCancel.Click += this.btCancel_Click;
			this.btCancel.Enter += this.Start_Input;
			this.bt3.Enabled = false;
			this.bt3.Location = new Point(3, 387);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 7;
			this.bt3.Enter += this.Start_Input;
			this.bt2.Enabled = false;
			this.bt2.Location = new Point(3, 323);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 6;
			this.bt2.Enter += this.Start_Input;
			this.btLevelAssignment.Location = new Point(3, 259);
			this.btLevelAssignment.Name = "btLevelAssignment";
			this.btLevelAssignment.Size = new Size(74, 62);
			this.btLevelAssignment.TabIndex = 5;
			this.btLevelAssignment.Text = "Passwort Level Zuordnung";
			this.btLevelAssignment.Click += this.btLevelAssignment_Click;
			this.btLevelAssignment.Enter += this.Start_Input;
			this.btVisuParam.Location = new Point(3, 195);
			this.btVisuParam.Name = "btVisuParam";
			this.btVisuParam.Size = new Size(74, 62);
			this.btVisuParam.TabIndex = 3;
			this.btVisuParam.Text = "Visualisierungsparameter";
			this.btVisuParam.Click += this.btVisuParam_Click;
			this.btVisuParam.Enter += this.Start_Input;
			this.btPasscodeManager.Location = new Point(3, 131);
			this.btPasscodeManager.Name = "btPasscodeManager";
			this.btPasscodeManager.Size = new Size(74, 62);
			this.btPasscodeManager.TabIndex = 2;
			this.btPasscodeManager.Text = "Passwortverwaltung";
			this.btPasscodeManager.Click += this.btPasscodeManager_Click;
			this.btPasscodeManager.Enter += this.Start_Input;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btHelp.Enter += this.Start_Input;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Speichern + Zurück";
			this.btBack.Click += this.btBack_Click;
			this.btBack.Enter += this.Start_Input;
			this.timerUpdate.Interval = 1000;
			this.timerUpdate.Tick += this.timerUpdate_Tick;
			this.gBDateTime.Controls.Add(this.lbShowLocalTime);
			this.gBDateTime.Controls.Add(this.btTimeSynchronize);
			this.gBDateTime.Controls.Add(this.lbLocalTime);
			this.gBDateTime.Controls.Add(this.lbControllerTime);
			this.gBDateTime.Controls.Add(this.dateTimePicker);
			this.gBDateTime.Controls.Add(this.btTimeSet);
			this.gBDateTime.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBDateTime.Location = new Point(16, 8);
			this.gBDateTime.Name = "gBDateTime";
			this.gBDateTime.Size = new Size(680, 104);
			this.gBDateTime.TabIndex = 1;
			this.gBDateTime.TabStop = false;
			this.gBDateTime.Text = "Datum/Zeit";
			this.lbShowLocalTime.BackColor = SystemColors.Window;
			this.lbShowLocalTime.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowLocalTime.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowLocalTime.Location = new Point(176, 70);
			this.lbShowLocalTime.Name = "lbShowLocalTime";
			this.lbShowLocalTime.Size = new Size(248, 23);
			this.lbShowLocalTime.TabIndex = 1;
			this.btTimeSynchronize.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btTimeSynchronize.Location = new Point(440, 67);
			this.btTimeSynchronize.Name = "btTimeSynchronize";
			this.btTimeSynchronize.Size = new Size(224, 29);
			this.btTimeSynchronize.TabIndex = 20;
			this.btTimeSynchronize.Text = "Steuerung synchronisieren";
			this.btTimeSynchronize.Click += this.btTimeSynchronize_Click;
			this.btTimeSynchronize.Enter += this.Start_Input;
			this.lbLocalTime.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbLocalTime.Location = new Point(16, 70);
			this.lbLocalTime.Name = "lbLocalTime";
			this.lbLocalTime.Size = new Size(152, 23);
			this.lbLocalTime.TabIndex = 18;
			this.lbLocalTime.Text = "lokal";
			this.lbLocalTime.TextAlign = ContentAlignment.MiddleLeft;
			this.lbControllerTime.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbControllerTime.Location = new Point(16, 32);
			this.lbControllerTime.Name = "lbControllerTime";
			this.lbControllerTime.Size = new Size(152, 23);
			this.lbControllerTime.TabIndex = 17;
			this.lbControllerTime.Text = "Steuerung";
			this.lbControllerTime.TextAlign = ContentAlignment.MiddleLeft;
			this.dateTimePicker.CustomFormat = "dd'/'MM'/'yyyy HH':'mm':'ss";
			this.dateTimePicker.Font = new Font("Arial Unicode MS", 24f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.dateTimePicker.Format = DateTimePickerFormat.Custom;
			this.dateTimePicker.Location = new Point(176, 23);
			this.dateTimePicker.Name = "dateTimePicker";
			this.dateTimePicker.ShowUpDown = true;
			this.dateTimePicker.Size = new Size(248, 40);
			this.dateTimePicker.TabIndex = 0;
			this.dateTimePicker.Enter += this.Start_Input;
			this.dateTimePicker.Leave += this.dateTimePicker_Leave;
			this.dateTimePicker.MouseDown += this.dateTimePicker_MouseDown;
			this.btTimeSet.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btTimeSet.Location = new Point(440, 29);
			this.btTimeSet.Name = "btTimeSet";
			this.btTimeSet.Size = new Size(224, 29);
			this.btTimeSet.TabIndex = 1;
			this.btTimeSet.Text = "Neu einstellen";
			this.btTimeSet.Click += this.btTimeSet_Click;
			this.btTimeSet.Enter += this.Start_Input;
			this.gBTorque.Controls.Add(this.cBTorqueUnit);
			this.gBTorque.Controls.Add(this.lbTorqueUnit);
			this.gBTorque.Location = new Point(16, 112);
			this.gBTorque.Name = "gBTorque";
			this.gBTorque.Size = new Size(680, 48);
			this.gBTorque.TabIndex = 2;
			this.gBTorque.TabStop = false;
			this.cBTorqueUnit.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBTorqueUnit.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBTorqueUnit.Items.AddRange(new object[7]
			{
				"Nm",
				"Ncm",
				"inlb",
				"ftlb",
				"inoz",
				"kgm",
				"kgcm"
			});
			this.cBTorqueUnit.Location = new Point(376, 14);
			this.cBTorqueUnit.Name = "cBTorqueUnit";
			this.cBTorqueUnit.Size = new Size(121, 28);
			this.cBTorqueUnit.TabIndex = 0;
			this.cBTorqueUnit.SelectedIndexChanged += this.settingsChanged;
			this.lbTorqueUnit.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTorqueUnit.Location = new Point(16, 17);
			this.lbTorqueUnit.Name = "lbTorqueUnit";
			this.lbTorqueUnit.Size = new Size(352, 23);
			this.lbTorqueUnit.TabIndex = 29;
			this.lbTorqueUnit.Text = "angezeigte Einheit des Drehmoments";
			this.lbTorqueUnit.TextAlign = ContentAlignment.MiddleLeft;
			this.gBIdentity.Controls.Add(this.lbAreaCode);
			this.gBIdentity.Controls.Add(this.tbAreaCode);
			this.gBIdentity.Controls.Add(this.lbID);
			this.gBIdentity.Controls.Add(this.tBID);
			this.gBIdentity.Controls.Add(this.lbIdentServer);
			this.gBIdentity.Controls.Add(this.tBIdentServer);
			this.gBIdentity.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBIdentity.Location = new Point(16, 166);
			this.gBIdentity.Name = "gBIdentity";
			this.gBIdentity.Size = new Size(680, 124);
			this.gBIdentity.TabIndex = 3;
			this.gBIdentity.TabStop = false;
			this.gBIdentity.Text = "Identifikation";
			this.lbAreaCode.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAreaCode.Location = new Point(16, 87);
			this.lbAreaCode.Name = "lbAreaCode";
			this.lbAreaCode.Size = new Size(200, 23);
			this.lbAreaCode.TabIndex = 46;
			this.lbAreaCode.Text = "Fertigungsbereich";
			this.lbAreaCode.TextAlign = ContentAlignment.MiddleLeft;
			this.tbAreaCode.BackColor = Color.White;
			this.tbAreaCode.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.tbAreaCode.Location = new Point(224, 84);
			this.tbAreaCode.MaxLength = 15;
			this.tbAreaCode.Name = "tbAreaCode";
			this.tbAreaCode.Size = new Size(288, 28);
			this.tbAreaCode.TabIndex = 45;
			this.tbAreaCode.TextChanged += this.tbAreaCode_TextChanged;
			this.tbAreaCode.Enter += this.Start_Input;
			this.tbAreaCode.KeyUp += this.tBAreaCode_KeyUp;
			this.tbAreaCode.MouseDown += this.StartInput;
			this.lbID.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbID.Location = new Point(16, 19);
			this.lbID.Name = "lbID";
			this.lbID.Size = new Size(200, 23);
			this.lbID.TabIndex = 31;
			this.lbID.Text = "SystemID";
			this.lbID.TextAlign = ContentAlignment.MiddleLeft;
			this.tBID.BackColor = Color.White;
			this.tBID.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.tBID.Location = new Point(224, 16);
			this.tBID.MaxLength = 19;
			this.tBID.Name = "tBID";
			this.tBID.Size = new Size(152, 28);
			this.tBID.TabIndex = 0;
			this.tBID.Text = "1110000/99";
			this.tBID.TextChanged += this.settingsChanged;
			this.tBID.Enter += this.Start_Input;
			this.tBID.KeyUp += this.tBID_KeyUp;
			this.tBID.MouseDown += this.StartInput;
			this.lbIdentServer.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbIdentServer.Location = new Point(16, 51);
			this.lbIdentServer.Name = "lbIdentServer";
			this.lbIdentServer.Size = new Size(200, 23);
			this.lbIdentServer.TabIndex = 44;
			this.lbIdentServer.Text = "Steuerungsname";
			this.lbIdentServer.TextAlign = ContentAlignment.MiddleLeft;
			this.tBIdentServer.BackColor = Color.White;
			this.tBIdentServer.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.tBIdentServer.Location = new Point(224, 48);
			this.tBIdentServer.MaxLength = 31;
			this.tBIdentServer.Name = "tBIdentServer";
			this.tBIdentServer.Size = new Size(288, 28);
			this.tBIdentServer.TabIndex = 1;
			this.tBIdentServer.TextChanged += this.settingsChanged;
			this.tBIdentServer.Enter += this.Start_Input;
			this.tBIdentServer.KeyUp += this.tBIdentServer_KeyUp;
			this.tBIdentServer.MouseDown += this.StartInput;
			this.gBIP.Controls.Add(this.chBDHCP);
			this.gBIP.Controls.Add(this.nEDG3);
			this.gBIP.Controls.Add(this.nEDG2);
			this.gBIP.Controls.Add(this.nEDG4);
			this.gBIP.Controls.Add(this.lbDG);
			this.gBIP.Controls.Add(this.nEDG1);
			this.gBIP.Controls.Add(this.nEIP1);
			this.gBIP.Controls.Add(this.lbIP);
			this.gBIP.Controls.Add(this.nEIP4);
			this.gBIP.Controls.Add(this.nEIP2);
			this.gBIP.Controls.Add(this.nEIP3);
			this.gBIP.Controls.Add(this.nESubnet3);
			this.gBIP.Controls.Add(this.nESubnet2);
			this.gBIP.Controls.Add(this.nESubnet4);
			this.gBIP.Controls.Add(this.lbSubnetMask);
			this.gBIP.Controls.Add(this.nESubnet1);
			this.gBIP.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBIP.Location = new Point(16, 292);
			this.gBIP.Name = "gBIP";
			this.gBIP.Size = new Size(680, 88);
			this.gBIP.TabIndex = 4;
			this.gBIP.TabStop = false;
			this.gBIP.Text = "IP Einstellungen";
			this.chBDHCP.AutoSize = true;
			this.chBDHCP.Location = new Point(363, 58);
			this.chBDHCP.Name = "chBDHCP";
			this.chBDHCP.Size = new Size(129, 22);
			this.chBDHCP.TabIndex = 12;
			this.chBDHCP.Text = "DHCP verwenden";
			this.chBDHCP.UseVisualStyleBackColor = true;
			this.chBDHCP.CheckedChanged += this.chBDHCP_CheckedChanged;
			this.chBDHCP.Enter += this.Start_Input;
			this.nEDG3.BackColor = Color.White;
			this.nEDG3.DecimalNum = 0;
			this.nEDG3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDG3.ForeColor = SystemColors.ControlText;
			this.nEDG3.Location = new Point(240, 51);
			this.nEDG3.MaxValue = 255f;
			this.nEDG3.MinValue = 0f;
			this.nEDG3.Name = "nEDG3";
			this.nEDG3.Size = new Size(40, 28);
			this.nEDG3.TabIndex = 10;
			this.nEDG3.Text = "0";
			this.nEDG3.TextAlign = HorizontalAlignment.Right;
			this.nEDG3.Value = 0f;
			this.nEDG3.TextChanged += this.settingsChanged;
			this.nEDG3.Enter += this.Start_Input;
			this.nEDG3.MouseDown += this.StartInput;
			this.nEDG2.BackColor = Color.White;
			this.nEDG2.DecimalNum = 0;
			this.nEDG2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDG2.ForeColor = SystemColors.ControlText;
			this.nEDG2.Location = new Point(200, 51);
			this.nEDG2.MaxValue = 255f;
			this.nEDG2.MinValue = 0f;
			this.nEDG2.Name = "nEDG2";
			this.nEDG2.Size = new Size(40, 28);
			this.nEDG2.TabIndex = 9;
			this.nEDG2.Text = "0";
			this.nEDG2.TextAlign = HorizontalAlignment.Right;
			this.nEDG2.Value = 0f;
			this.nEDG2.TextChanged += this.settingsChanged;
			this.nEDG2.Enter += this.Start_Input;
			this.nEDG2.MouseDown += this.StartInput;
			this.nEDG4.BackColor = Color.White;
			this.nEDG4.DecimalNum = 0;
			this.nEDG4.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDG4.ForeColor = SystemColors.ControlText;
			this.nEDG4.Location = new Point(280, 51);
			this.nEDG4.MaxValue = 255f;
			this.nEDG4.MinValue = 0f;
			this.nEDG4.Name = "nEDG4";
			this.nEDG4.Size = new Size(40, 28);
			this.nEDG4.TabIndex = 11;
			this.nEDG4.Text = "0";
			this.nEDG4.TextAlign = HorizontalAlignment.Right;
			this.nEDG4.Value = 0f;
			this.nEDG4.TextChanged += this.settingsChanged;
			this.nEDG4.Enter += this.Start_Input;
			this.nEDG4.MouseDown += this.StartInput;
			this.lbDG.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDG.Location = new Point(16, 54);
			this.lbDG.Name = "lbDG";
			this.lbDG.Size = new Size(136, 23);
			this.lbDG.TabIndex = 48;
			this.lbDG.Text = "Default Gateway";
			this.lbDG.TextAlign = ContentAlignment.MiddleLeft;
			this.nEDG1.BackColor = Color.White;
			this.nEDG1.DecimalNum = 0;
			this.nEDG1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDG1.ForeColor = SystemColors.ControlText;
			this.nEDG1.Location = new Point(160, 51);
			this.nEDG1.MaxValue = 255f;
			this.nEDG1.MinValue = 0f;
			this.nEDG1.Name = "nEDG1";
			this.nEDG1.Size = new Size(40, 28);
			this.nEDG1.TabIndex = 8;
			this.nEDG1.Text = "0";
			this.nEDG1.TextAlign = HorizontalAlignment.Right;
			this.nEDG1.Value = 0f;
			this.nEDG1.TextChanged += this.settingsChanged;
			this.nEDG1.Enter += this.Start_Input;
			this.nEDG1.MouseDown += this.StartInput;
			this.nEIP1.BackColor = Color.White;
			this.nEIP1.DecimalNum = 0;
			this.nEIP1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEIP1.ForeColor = SystemColors.ControlText;
			this.nEIP1.Location = new Point(160, 21);
			this.nEIP1.MaxValue = 255f;
			this.nEIP1.MinValue = 0f;
			this.nEIP1.Name = "nEIP1";
			this.nEIP1.Size = new Size(40, 28);
			this.nEIP1.TabIndex = 0;
			this.nEIP1.Text = "0";
			this.nEIP1.TextAlign = HorizontalAlignment.Right;
			this.nEIP1.Value = 0f;
			this.nEIP1.TextChanged += this.settingsChanged;
			this.nEIP1.Enter += this.Start_Input;
			this.nEIP1.MouseDown += this.StartInput;
			this.lbIP.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbIP.Location = new Point(16, 24);
			this.lbIP.Name = "lbIP";
			this.lbIP.Size = new Size(136, 23);
			this.lbIP.TabIndex = 28;
			this.lbIP.Text = "IP Adresse";
			this.lbIP.TextAlign = ContentAlignment.MiddleLeft;
			this.nEIP4.DecimalNum = 0;
			this.nEIP4.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEIP4.ForeColor = SystemColors.ControlText;
			this.nEIP4.Location = new Point(280, 21);
			this.nEIP4.MaxValue = 255f;
			this.nEIP4.MinValue = 0f;
			this.nEIP4.Name = "nEIP4";
			this.nEIP4.ReadOnly = true;
			this.nEIP4.Size = new Size(40, 28);
			this.nEIP4.TabIndex = 3;
			this.nEIP4.Text = "0";
			this.nEIP4.TextAlign = HorizontalAlignment.Right;
			this.nEIP4.Value = 0f;
			this.nEIP4.TextChanged += this.settingsChanged;
			this.nEIP2.BackColor = Color.White;
			this.nEIP2.DecimalNum = 0;
			this.nEIP2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEIP2.ForeColor = SystemColors.ControlText;
			this.nEIP2.Location = new Point(200, 21);
			this.nEIP2.MaxValue = 255f;
			this.nEIP2.MinValue = 0f;
			this.nEIP2.Name = "nEIP2";
			this.nEIP2.Size = new Size(40, 28);
			this.nEIP2.TabIndex = 1;
			this.nEIP2.Text = "0";
			this.nEIP2.TextAlign = HorizontalAlignment.Right;
			this.nEIP2.Value = 0f;
			this.nEIP2.TextChanged += this.settingsChanged;
			this.nEIP2.Enter += this.Start_Input;
			this.nEIP2.MouseDown += this.StartInput;
			this.nEIP3.BackColor = Color.White;
			this.nEIP3.DecimalNum = 0;
			this.nEIP3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEIP3.ForeColor = SystemColors.ControlText;
			this.nEIP3.Location = new Point(240, 21);
			this.nEIP3.MaxValue = 255f;
			this.nEIP3.MinValue = 0f;
			this.nEIP3.Name = "nEIP3";
			this.nEIP3.Size = new Size(40, 28);
			this.nEIP3.TabIndex = 2;
			this.nEIP3.Text = "0";
			this.nEIP3.TextAlign = HorizontalAlignment.Right;
			this.nEIP3.Value = 0f;
			this.nEIP3.TextChanged += this.settingsChanged;
			this.nEIP3.Enter += this.Start_Input;
			this.nEIP3.MouseDown += this.StartInput;
			this.nESubnet3.BackColor = Color.White;
			this.nESubnet3.DecimalNum = 0;
			this.nESubnet3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nESubnet3.ForeColor = SystemColors.ControlText;
			this.nESubnet3.Location = new Point(587, 21);
			this.nESubnet3.MaxValue = 255f;
			this.nESubnet3.MinValue = 0f;
			this.nESubnet3.Name = "nESubnet3";
			this.nESubnet3.Size = new Size(40, 28);
			this.nESubnet3.TabIndex = 6;
			this.nESubnet3.Text = "0";
			this.nESubnet3.TextAlign = HorizontalAlignment.Right;
			this.nESubnet3.Value = 0f;
			this.nESubnet3.TextChanged += this.settingsChanged;
			this.nESubnet3.Enter += this.Start_Input;
			this.nESubnet3.MouseDown += this.StartInput;
			this.nESubnet2.BackColor = Color.White;
			this.nESubnet2.DecimalNum = 0;
			this.nESubnet2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nESubnet2.ForeColor = SystemColors.ControlText;
			this.nESubnet2.Location = new Point(547, 21);
			this.nESubnet2.MaxValue = 255f;
			this.nESubnet2.MinValue = 0f;
			this.nESubnet2.Name = "nESubnet2";
			this.nESubnet2.Size = new Size(40, 28);
			this.nESubnet2.TabIndex = 5;
			this.nESubnet2.Text = "0";
			this.nESubnet2.TextAlign = HorizontalAlignment.Right;
			this.nESubnet2.Value = 0f;
			this.nESubnet2.TextChanged += this.settingsChanged;
			this.nESubnet2.Enter += this.Start_Input;
			this.nESubnet2.MouseDown += this.StartInput;
			this.nESubnet4.BackColor = Color.White;
			this.nESubnet4.DecimalNum = 0;
			this.nESubnet4.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nESubnet4.ForeColor = SystemColors.ControlText;
			this.nESubnet4.Location = new Point(627, 21);
			this.nESubnet4.MaxValue = 255f;
			this.nESubnet4.MinValue = 0f;
			this.nESubnet4.Name = "nESubnet4";
			this.nESubnet4.Size = new Size(40, 28);
			this.nESubnet4.TabIndex = 7;
			this.nESubnet4.Text = "0";
			this.nESubnet4.TextAlign = HorizontalAlignment.Right;
			this.nESubnet4.Value = 0f;
			this.nESubnet4.TextChanged += this.settingsChanged;
			this.nESubnet4.Enter += this.Start_Input;
			this.nESubnet4.MouseDown += this.StartInput;
			this.lbSubnetMask.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbSubnetMask.Location = new Point(360, 14);
			this.lbSubnetMask.Name = "lbSubnetMask";
			this.lbSubnetMask.Size = new Size(136, 40);
			this.lbSubnetMask.TabIndex = 43;
			this.lbSubnetMask.Text = "Subnetmask";
			this.lbSubnetMask.TextAlign = ContentAlignment.MiddleLeft;
			this.nESubnet1.BackColor = Color.White;
			this.nESubnet1.DecimalNum = 0;
			this.nESubnet1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nESubnet1.ForeColor = SystemColors.ControlText;
			this.nESubnet1.Location = new Point(507, 21);
			this.nESubnet1.MaxValue = 255f;
			this.nESubnet1.MinValue = 0f;
			this.nESubnet1.Name = "nESubnet1";
			this.nESubnet1.Size = new Size(40, 28);
			this.nESubnet1.TabIndex = 4;
			this.nESubnet1.Text = "0";
			this.nESubnet1.TextAlign = HorizontalAlignment.Right;
			this.nESubnet1.Value = 0f;
			this.nESubnet1.TextChanged += this.settingsChanged;
			this.nESubnet1.Enter += this.Start_Input;
			this.nESubnet1.MouseDown += this.StartInput;
			this.gBRS232.Controls.Add(this.cBBaudrate);
			this.gBRS232.Controls.Add(this.lbBaudrate);
			this.gBRS232.Controls.Add(this.lbParity);
			this.gBRS232.Controls.Add(this.cBParity);
			this.gBRS232.Enabled = false;
			this.gBRS232.Location = new Point(16, 385);
			this.gBRS232.Name = "gBRS232";
			this.gBRS232.Size = new Size(680, 56);
			this.gBRS232.TabIndex = 5;
			this.gBRS232.TabStop = false;
			this.gBRS232.Text = "COM1";
			this.cBBaudrate.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBBaudrate.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBBaudrate.Items.AddRange(new object[8]
			{
				"2400",
				"4800",
				"9600",
				"14400",
				"19200",
				"38400",
				"57600",
				"115200"
			});
			this.cBBaudrate.Location = new Point(184, 18);
			this.cBBaudrate.Name = "cBBaudrate";
			this.cBBaudrate.Size = new Size(121, 28);
			this.cBBaudrate.TabIndex = 0;
			this.cBBaudrate.SelectedIndexChanged += this.settingsChanged;
			this.lbBaudrate.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbBaudrate.Location = new Point(16, 21);
			this.lbBaudrate.Name = "lbBaudrate";
			this.lbBaudrate.Size = new Size(160, 23);
			this.lbBaudrate.TabIndex = 34;
			this.lbBaudrate.Text = "Baudrate";
			this.lbBaudrate.TextAlign = ContentAlignment.MiddleLeft;
			this.lbParity.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbParity.Location = new Point(368, 21);
			this.lbParity.Name = "lbParity";
			this.lbParity.Size = new Size(160, 23);
			this.lbParity.TabIndex = 36;
			this.lbParity.Text = "Parität";
			this.lbParity.TextAlign = ContentAlignment.MiddleLeft;
			this.cBParity.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBParity.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBParity.Items.AddRange(new object[3]
			{
				"keine",
				"ungerade",
				"gerade"
			});
			this.cBParity.Location = new Point(536, 18);
			this.cBParity.Name = "cBParity";
			this.cBParity.Size = new Size(121, 28);
			this.cBParity.TabIndex = 1;
			this.cBParity.SelectedIndexChanged += this.settingsChanged;
			this.gBVersionInfo.Controls.Add(this.lbShowVersionVisualisation);
			this.gBVersionInfo.Controls.Add(this.lbShowVersionController);
			this.gBVersionInfo.Controls.Add(this.lbVersionController);
			this.gBVersionInfo.Controls.Add(this.lbVersionVisualisation);
			this.gBVersionInfo.Location = new Point(16, 447);
			this.gBVersionInfo.Name = "gBVersionInfo";
			this.gBVersionInfo.Size = new Size(680, 56);
			this.gBVersionInfo.TabIndex = 6;
			this.gBVersionInfo.TabStop = false;
			this.gBVersionInfo.Text = "Versionsinformationen";
			this.lbShowVersionVisualisation.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowVersionVisualisation.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowVersionVisualisation.Location = new Point(472, 24);
			this.lbShowVersionVisualisation.Name = "lbShowVersionVisualisation";
			this.lbShowVersionVisualisation.Size = new Size(200, 23);
			this.lbShowVersionVisualisation.TabIndex = 38;
			this.lbShowVersionVisualisation.Text = "Version";
			this.lbShowVersionVisualisation.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowVersionController.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowVersionController.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowVersionController.Location = new Point(128, 24);
			this.lbShowVersionController.Name = "lbShowVersionController";
			this.lbShowVersionController.Size = new Size(200, 23);
			this.lbShowVersionController.TabIndex = 37;
			this.lbShowVersionController.Text = "Version";
			this.lbShowVersionController.TextAlign = ContentAlignment.MiddleLeft;
			this.lbVersionController.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbVersionController.Location = new Point(16, 24);
			this.lbVersionController.Name = "lbVersionController";
			this.lbVersionController.Size = new Size(104, 23);
			this.lbVersionController.TabIndex = 34;
			this.lbVersionController.Text = "Steuerung";
			this.lbVersionController.TextAlign = ContentAlignment.MiddleLeft;
			this.lbVersionVisualisation.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbVersionVisualisation.Location = new Point(360, 24);
			this.lbVersionVisualisation.Name = "lbVersionVisualisation";
			this.lbVersionVisualisation.Size = new Size(104, 23);
			this.lbVersionVisualisation.TabIndex = 36;
			this.lbVersionVisualisation.Text = "Visualisierung";
			this.lbVersionVisualisation.TextAlign = ContentAlignment.MiddleLeft;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.gBVersionInfo);
			base.Controls.Add(this.gBDateTime);
			base.Controls.Add(this.gBTorque);
			base.Controls.Add(this.gBIdentity);
			base.Controls.Add(this.gBIP);
			base.Controls.Add(this.gBRS232);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "SystemConstantsForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen/Systemkonstanten";
			base.Activated += this.SystemConstantsForm_Activated;
			base.Paint += this.SystemConstantsForm_Paint;
			this.pnMenu.ResumeLayout(false);
			this.gBDateTime.ResumeLayout(false);
			this.gBTorque.ResumeLayout(false);
			this.gBIdentity.ResumeLayout(false);
			this.gBIdentity.PerformLayout();
			this.gBIP.ResumeLayout(false);
			this.gBIP.PerformLayout();
			this.gBRS232.ResumeLayout(false);
			this.gBVersionInfo.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public bool ShowWindow()
		{
			this.Main.ResetBrowserGrantedBy();
			this.tbAreaCode.MaxLength = 15;
			this.initInProgress = true;
			if (this.Main.IsOfflineVersion)
			{
				this.tBIdentServer.Text = string.Empty;
				this.tbAreaCode.Text = string.Empty;
				this.tBID.Text = string.Empty;
				this.cBTorqueUnit.SelectedIndex = 0;
				this.cBBaudrate.SelectedIndex = 0;
				this.cBParity.SelectedIndex = 0;
				this.lbShowVersionController.Text = string.Empty;
				this.lbShowVersionVisualisation.Text = Assembly.GetExecutingAssembly().GetName().Version.ToString();
				this.lbShowLocalTime.Text = DateTime.Now.ToString(Settings.Default.TimeSet);
				this.MenEna();
				base.Show();
				this.initInProgress = false;
				return true;
			}
			if (!this.Main.IsOnlineMode)
			{
				this.tBIdentServer.Text = string.Empty;
				this.tbAreaCode.Text = string.Empty;
				this.tBID.Text = string.Empty;
				this.cBTorqueUnit.SelectedIndex = 0;
				this.cBBaudrate.SelectedIndex = 0;
				this.cBParity.SelectedIndex = 0;
				this.lbShowVersionController.Text = string.Empty;
				this.lbShowVersionVisualisation.Text = Assembly.GetExecutingAssembly().GetName().Version.ToString();
				this.lbShowLocalTime.Text = DateTime.Now.ToString(Settings.Default.TimeSet);
				this.MenEna();
				base.Show();
				this.timerUpdate.Enabled = true;
				this.initInProgress = false;
				return true;
			}
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadSystemConst"));
			if (!this.Main.VC.ReceiveVarBlock(12))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.initInProgress = false;
				return false;
			}
			this.lbShowVersionController.Text = this.Main.CommonFunctions.UShortToString(this.Main.VC.Status0.Version);
			this.lbShowVersionVisualisation.Text = Assembly.GetExecutingAssembly().GetName().Version.ToString();
			this.nEIP1.Value = (float)(int)this.Main.VC.SysConst.IPAddress.Byte1;
			this.nEIP2.Value = (float)(int)this.Main.VC.SysConst.IPAddress.Byte2;
			this.nEIP3.Value = (float)(int)this.Main.VC.SysConst.IPAddress.Byte3;
			this.nEIP4.Value = (float)(int)this.Main.VC.SysConst.IPAddress.Byte4;
			this.nESubnet1.Value = (float)(int)this.Main.VC.SysConst.SubNetMask.Byte1;
			this.nESubnet2.Value = (float)(int)this.Main.VC.SysConst.SubNetMask.Byte2;
			this.nESubnet3.Value = (float)(int)this.Main.VC.SysConst.SubNetMask.Byte3;
			this.nESubnet4.Value = (float)(int)this.Main.VC.SysConst.SubNetMask.Byte4;
			this.nEDG1.Value = (float)(int)this.Main.VC.SysConst.DefaultGateway.Byte1;
			this.nEDG2.Value = (float)(int)this.Main.VC.SysConst.DefaultGateway.Byte2;
			this.nEDG3.Value = (float)(int)this.Main.VC.SysConst.DefaultGateway.Byte3;
			this.nEDG4.Value = (float)(int)this.Main.VC.SysConst.DefaultGateway.Byte4;
			if (this.Main.VC.SysConst.DHCP == 1)
			{
				this.chBDHCP.Checked = true;
			}
			else
			{
				this.chBDHCP.Checked = false;
			}
			this.tBIdentServer.Text = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName);
			this.tbAreaCode.Text = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.AreaCode);
			this.tBID.Text = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.SystemID);
			this.cBTorqueUnit.SelectedIndex = this.Main.VC.SysConst.UnitTorque;
			switch (this.Main.VC.SysConst.Com1.BaudRate)
			{
			case 0u:
				this.cBBaudrate.SelectedIndex = 2;
				break;
			case 2400u:
				this.cBBaudrate.SelectedIndex = 0;
				break;
			case 4800u:
				this.cBBaudrate.SelectedIndex = 1;
				break;
			case 9600u:
				this.cBBaudrate.SelectedIndex = 2;
				break;
			case 14400u:
				this.cBBaudrate.SelectedIndex = 3;
				break;
			case 19200u:
				this.cBBaudrate.SelectedIndex = 4;
				break;
			case 38400u:
				this.cBBaudrate.SelectedIndex = 5;
				break;
			case 57600u:
				this.cBBaudrate.SelectedIndex = 6;
				break;
			case 115200u:
				this.cBBaudrate.SelectedIndex = 7;
				break;
			default:
				MessageBox.Show("Wrong baudrate in ShowWindow() of SystemConstants", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.cBBaudrate.SelectedIndex = 2;
				break;
			}
			if (this.Main.VC.SysConst.Com1.Parity >= this.cBParity.Items.Count || this.Main.VC.SysConst.Com1.Parity < 0)
			{
				this.cBParity.SelectedIndex = 0;
			}
			else
			{
				this.cBParity.SelectedIndex = this.Main.VC.SysConst.Com1.Parity;
			}
			this.dateTimePicker.CustomFormat = Settings.Default.TimeSet;
			this.UpdateTime();
			Cursor.Current = Cursors.Default;
			this.Main.StatusBarText(string.Empty);
			this.MenEna();
			if (!base.Visible)
			{
				base.Show();
			}
			this.UpdateControllerTime = true;
			this.timerUpdate.Enabled = true;
			this.initInProgress = false;
			return true;
		}

		public void SetLanguageTexts()
		{
			this.initInProgress = true;
			int num = 0;
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MSystemConstants");
			this.lbBaudrate.Text = this.Main.Rm.GetString("Baudrate");
			this.lbControllerTime.Text = this.Main.Rm.GetString("ControllerTime");
			this.lbID.Text = this.Main.Rm.GetString("SystemID");
			this.lbIdentServer.Text = this.Main.Rm.GetString("IdentServer");
			this.lbAreaCode.Text = this.Main.Rm.GetString("AreaCode");
			this.lbIP.Text = this.Main.Rm.GetString("IPAddress");
			this.lbDG.Text = this.Main.Rm.GetString("DGAddress");
			this.chBDHCP.Text = this.Main.Rm.GetString("DHCP");
			this.lbParity.Text = this.Main.Rm.GetString("Parity");
			this.lbLocalTime.Text = this.Main.Rm.GetString("LocalTime");
			this.lbSubnetMask.Text = this.Main.Rm.GetString("SubnetMask");
			this.lbTorqueUnit.Text = this.Main.Rm.GetString("TorqueUnitChoose");
			this.gBDateTime.Text = this.Main.Rm.GetString("gBDateTime");
			this.gBIP.Text = this.Main.Rm.GetString("gBIP");
			this.gBRS232.Text = this.Main.Rm.GetString("gBRs232");
			this.gBIdentity.Text = this.Main.Rm.GetString("gBIdentity");
			this.btBack.Text = this.Main.Rm.GetString("StoreAndBack");
			this.btCancel.Text = this.Main.Rm.GetString("btCancel");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btLevelAssignment.Text = this.Main.Rm.GetString("btLevelAssignment");
			if (this.Main.Usb_Key_Access())
			{
				this.btPasscodeManager.Text = "";
				this.btPasscodeManager.Enabled = false;
			}
			else
			{
				this.btPasscodeManager.Text = this.Main.Rm.GetString("PasscodeManager");
			}
			this.btVisuParam.Text = this.Main.Rm.GetString("VisuParam");
			this.btTimeSet.Text = this.Main.Rm.GetString("TimeSet");
			this.btTimeSynchronize.Text = this.Main.Rm.GetString("TimeSynchronize");
			num = ((this.cBParity.SelectedIndex >= 0) ? this.cBParity.SelectedIndex : 0);
			this.cBParity.Items.Clear();
			this.cBParity.Items.Add(this.Main.Rm.GetString("None") + string.Empty);
			this.cBParity.Items.Add(this.Main.Rm.GetString("Odd") + string.Empty);
			this.cBParity.Items.Add(this.Main.Rm.GetString("Even") + string.Empty);
			this.cBParity.SelectedIndex = num;
			num = ((this.cBTorqueUnit.SelectedIndex >= 0) ? this.cBTorqueUnit.SelectedIndex : 0);
			this.cBTorqueUnit.Items.Clear();
			this.cBTorqueUnit.Items.Add(this.Main.Rm.GetString("TorqueNm") + string.Empty);
			this.cBTorqueUnit.Items.Add(this.Main.Rm.GetString("TorqueNcm") + string.Empty);
			this.cBTorqueUnit.Items.Add(this.Main.Rm.GetString("Torqueinlb") + string.Empty);
			this.cBTorqueUnit.Items.Add(this.Main.Rm.GetString("Torqueftlb") + string.Empty);
			this.cBTorqueUnit.Items.Add(this.Main.Rm.GetString("Torqueinoz") + string.Empty);
			this.cBTorqueUnit.Items.Add(this.Main.Rm.GetString("Torquekgm") + string.Empty);
			this.cBTorqueUnit.Items.Add(this.Main.Rm.GetString("Torquekgcm") + string.Empty);
			this.cBTorqueUnit.SelectedIndex = num;
			this.lbVersionController.Text = this.Main.Rm.GetString("VersionController");
			this.lbVersionVisualisation.Text = this.Main.Rm.GetString("VersionVisu");
			this.gBVersionInfo.Text = this.Main.Rm.GetString("VersionInfo");
			this.initInProgress = false;
		}

		private void MenEna()
		{
			bool enabled = false;
			bool enabled2 = false;
			bool enabled3 = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_SystemConstantsForm)
			{
				enabled = true;
			}
			if (this.Main.PassCodeLevel >= 4)
			{
				enabled2 = true;
			}
			if (this.Main.PassCodeLevel >= 5)
			{
				enabled3 = true;
			}
			if (this.Main.IsOfflineVersion)
			{
				enabled2 = false;
				enabled = false;
			}
			if (this.Main.ViewOnlyMode)
			{
				enabled = false;
				enabled2 = false;
				enabled3 = false;
			}
			if (this.Main.IsOfflineVersion)
			{
				enabled = true;
				enabled2 = true;
				enabled3 = true;
			}
			this.lbAreaCode.Visible = this.Main.Usb_Key_Access();
			this.tbAreaCode.Visible = this.Main.Usb_Key_Access();
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_SystemConstantsForm, this.Main.ViewOnlyMode);
			this.btBack.Enabled = enabled;
			this.dateTimePicker.Enabled = enabled;
			this.btTimeSet.Enabled = enabled;
			this.btTimeSynchronize.Enabled = enabled;
			this.btLevelAssignment.Enabled = enabled2;
			this.cBTorqueUnit.Enabled = enabled;
			this.tBID.Enabled = enabled3;
			this.tBIdentServer.Enabled = enabled;
			this.tbAreaCode.Enabled = enabled;
			this.nEIP1.Enabled = enabled;
			this.nEIP2.Enabled = enabled;
			this.nEIP3.Enabled = enabled;
			this.nESubnet1.Enabled = enabled;
			this.nESubnet2.Enabled = enabled;
			this.nESubnet3.Enabled = enabled;
			this.nESubnet4.Enabled = enabled;
			this.nEDG1.Enabled = enabled;
			this.nEDG2.Enabled = enabled;
			this.nEDG3.Enabled = enabled;
			this.nEDG4.Enabled = enabled;
			this.chBDHCP.Enabled = enabled;
			this.cBBaudrate.Enabled = enabled;
			this.cBParity.Enabled = enabled;
			if (!this.Main.Usb_Key_Access())
			{
				this.btPasscodeManager.Enabled = enabled;
				this.btPasscodeManager.Text = this.Main.Rm.GetString("PasscodeManager");
			}
			else
			{
				this.btPasscodeManager.Enabled = false;
				this.btPasscodeManager.Text = "";
			}
			if (!this.Main.IsOnlineMode)
			{
				this.cBTorqueUnit.Enabled = false;
				this.tBIdentServer.Enabled = false;
				this.tbAreaCode.Enabled = false;
				this.chBDHCP.Enabled = false;
				this.nEIP1.Enabled = false;
				this.nEIP2.Enabled = false;
				this.nEIP3.Enabled = false;
				this.nEDG1.Enabled = false;
				this.nEDG2.Enabled = false;
				this.nEDG3.Enabled = false;
				this.nEDG4.Enabled = false;
				this.nESubnet1.Enabled = false;
				this.nESubnet2.Enabled = false;
				this.nESubnet3.Enabled = false;
				this.nESubnet4.Enabled = false;
				this.btTimeSet.Enabled = false;
				this.btTimeSynchronize.Enabled = false;
				this.UpdateControllerTime = false;
				this.dateTimePicker.Enabled = false;
			}
			else
			{
				this.timerUpdate.Enabled = true;
				this.enableIpControls(enabled);
			}
			this.tBID.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.tBIdentServer.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.tbAreaCode.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEIP1.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEIP2.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEIP3.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nESubnet1.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nESubnet2.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nESubnet3.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nESubnet4.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDG1.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDG2.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDG3.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDG4.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
		}

		private void UpdateTime()
		{
			if (!this.Main.IsOnlineMode)
			{
				this.UpdateControllerTime = false;
			}
			else if (!this.Main.VC.ReceiveVarBlock(12))
			{
				this.UpdateControllerTime = false;
			}
			else
			{
				DateTime value;
				try
				{
					value = new DateTime(this.Main.VC.SysConst.ActualTime.Year, this.Main.VC.SysConst.ActualTime.Month, this.Main.VC.SysConst.ActualTime.Day, this.Main.VC.SysConst.ActualTime.Hour, this.Main.VC.SysConst.ActualTime.Minute, this.Main.VC.SysConst.ActualTime.Second);
				}
				catch
				{
					value = new DateTime(1, 1, 1, 0, 0, 0);
				}
				this.dateTimePicker.CustomFormat = Settings.Default.TimeSet;
				this.dateTimePicker.Value = value;
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			bool flag = false;
			bool flag2 = false;
			string text = string.Empty;
			if (this.Main.IsOnlineMode)
			{
				if (!this.nEIP1.IsOK)
				{
					text = text + this.lbIP.Text + " Byte 1 " + this.Main.Rm.GetString("OutOfRange") + this.nEIP1.MinValue.ToString() + " - " + this.nEIP1.MaxValue.ToString() + "\n";
				}
				if (!this.nEIP2.IsOK)
				{
					text = text + this.lbIP.Text + " Byte 2 " + this.Main.Rm.GetString("OutOfRange") + this.nEIP2.MinValue.ToString() + " - " + this.nEIP2.MaxValue.ToString() + "\n";
				}
				if (!this.nEIP3.IsOK)
				{
					text = text + this.lbIP.Text + " Byte 3 " + this.Main.Rm.GetString("OutOfRange") + this.nEIP3.MinValue.ToString() + " - " + this.nEIP3.MaxValue.ToString() + "\n";
				}
				if (!this.nESubnet1.IsOK)
				{
					text = text + this.lbSubnetMask.Text + " Byte 1 " + this.Main.Rm.GetString("OutOfRange") + this.nESubnet1.MinValue.ToString() + " - " + this.nESubnet1.MaxValue.ToString() + "\n";
				}
				if (!this.nESubnet2.IsOK)
				{
					text = text + this.lbSubnetMask.Text + " Byte 2 " + this.Main.Rm.GetString("OutOfRange") + this.nESubnet2.MinValue.ToString() + " - " + this.nESubnet2.MaxValue.ToString() + "\n";
				}
				if (!this.nESubnet3.IsOK)
				{
					text = text + this.lbSubnetMask.Text + " Byte 3 " + this.Main.Rm.GetString("OutOfRange") + this.nESubnet3.MinValue.ToString() + " - " + this.nESubnet3.MaxValue.ToString() + "\n";
				}
				if (!this.nESubnet4.IsOK)
				{
					text = text + this.lbSubnetMask.Text + " Byte 4 " + this.Main.Rm.GetString("OutOfRange") + this.nESubnet4.MinValue.ToString() + " - " + this.nESubnet4.MaxValue.ToString() + "\n";
				}
				if (!this.nEDG1.IsOK)
				{
					text = text + this.lbDG.Text + " Byte 1 " + this.Main.Rm.GetString("OutOfRange") + this.nEDG1.MinValue.ToString() + " - " + this.nEDG1.MaxValue.ToString() + "\n";
				}
				if (!this.nEDG2.IsOK)
				{
					text = text + this.lbDG.Text + " Byte 2 " + this.Main.Rm.GetString("OutOfRange") + this.nEDG2.MinValue.ToString() + " - " + this.nEDG2.MaxValue.ToString() + "\n";
				}
				if (!this.nEDG3.IsOK)
				{
					text = text + this.lbDG.Text + " Byte 3 " + this.Main.Rm.GetString("OutOfRange") + this.nEDG3.MinValue.ToString() + " - " + this.nEDG3.MaxValue.ToString() + "\n";
				}
				if (!this.nEDG4.IsOK)
				{
					text = text + this.lbDG.Text + " Byte 4 " + this.Main.Rm.GetString("OutOfRange") + this.nEDG4.MinValue.ToString() + " - " + this.nEDG4.MaxValue.ToString() + "\n";
				}
				if (text != string.Empty)
				{
					MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + text, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}
				this.pnMenu.Enabled = false;
				Cursor.Current = Cursors.WaitCursor;
				if (this.Main.VC.SysConst.IPAddress.Byte1 != (byte)this.nEIP1.Value)
				{
					this.Main.MakeLogbookEntry(202000u, 3, (float)(int)this.Main.VC.SysConst.IPAddress.Byte1, this.nEIP1.Value, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.VC.SysConst.IPAddress.Byte2 != (byte)this.nEIP2.Value)
				{
					this.Main.MakeLogbookEntry(202001u, 3, (float)(int)this.Main.VC.SysConst.IPAddress.Byte2, this.nEIP2.Value, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.VC.SysConst.IPAddress.Byte3 != (byte)this.nEIP3.Value)
				{
					this.Main.MakeLogbookEntry(202002u, 3, (float)(int)this.Main.VC.SysConst.IPAddress.Byte3, this.nEIP3.Value, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.VC.SysConst.SubNetMask.Byte1 != (byte)this.nESubnet1.Value)
				{
					this.Main.MakeLogbookEntry(202003u, 3, (float)(int)this.Main.VC.SysConst.SubNetMask.Byte1, this.nESubnet1.Value, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.VC.SysConst.SubNetMask.Byte2 != (byte)this.nESubnet2.Value)
				{
					this.Main.MakeLogbookEntry(202004u, 3, (float)(int)this.Main.VC.SysConst.SubNetMask.Byte2, this.nESubnet2.Value, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.VC.SysConst.SubNetMask.Byte3 != (byte)this.nESubnet3.Value)
				{
					this.Main.MakeLogbookEntry(202005u, 3, (float)(int)this.Main.VC.SysConst.SubNetMask.Byte3, this.nESubnet3.Value, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.VC.SysConst.SubNetMask.Byte4 != (byte)this.nESubnet4.Value)
				{
					this.Main.MakeLogbookEntry(202006u, 3, (float)(int)this.Main.VC.SysConst.SubNetMask.Byte4, this.nESubnet4.Value, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.VC.SysConst.DefaultGateway.Byte1 != (byte)this.nEDG1.Value)
				{
					this.Main.MakeLogbookEntry(202007u, 3, (float)(int)this.Main.VC.SysConst.DefaultGateway.Byte1, this.nEDG1.Value, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.VC.SysConst.DefaultGateway.Byte2 != (byte)this.nEDG2.Value)
				{
					this.Main.MakeLogbookEntry(202008u, 3, (float)(int)this.Main.VC.SysConst.DefaultGateway.Byte2, this.nEDG2.Value, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.VC.SysConst.DefaultGateway.Byte3 != (byte)this.nEDG3.Value)
				{
					this.Main.MakeLogbookEntry(202009u, 3, (float)(int)this.Main.VC.SysConst.DefaultGateway.Byte3, this.nEDG3.Value, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.VC.SysConst.DefaultGateway.Byte4 != (byte)this.nEDG4.Value)
				{
					this.Main.MakeLogbookEntry(202010u, 3, (float)(int)this.Main.VC.SysConst.DefaultGateway.Byte4, this.nEDG4.Value, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.VC.SysConst.DHCP == 0 && this.chBDHCP.Checked)
				{
					this.Main.MakeLogbookEntry(202011u, 3, 0f, 1f, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.VC.SysConst.DHCP == 1 && !this.chBDHCP.Checked)
				{
					this.Main.MakeLogbookEntry(202011u, 3, 1f, 0f, 0u, 0, byte.MaxValue);
					flag = true;
				}
				if (this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) != this.tBIdentServer.Text)
				{
					this.Main.MakeLogbookEntry(202013u, 3, 0f, 0f, 0u, 0, byte.MaxValue);
				}
				if (this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.AreaCode) != this.tbAreaCode.Text)
				{
					this.Main.MakeLogbookEntry(202019u, 3, 0f, 0f, 0u, 0, byte.MaxValue);
				}
				if (this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.SystemID) != this.tBID.Text)
				{
					this.Main.MakeLogbookEntry(202012u, 3, 0f, 0f, 0u, 0, byte.MaxValue);
				}
				if (this.Main.VC.SysConst.UnitTorque != (byte)this.cBTorqueUnit.SelectedIndex)
				{
					this.Main.MakeLogbookEntry(202014u, 3, (float)(int)this.Main.VC.SysConst.UnitTorque, (float)this.cBTorqueUnit.SelectedIndex, 0u, 0, byte.MaxValue);
					flag2 = true;
				}
				uint num;
				switch (this.cBBaudrate.SelectedIndex)
				{
				case 0:
					num = 2400u;
					break;
				case 1:
					num = 4800u;
					break;
				case 2:
					num = 9600u;
					break;
				case 3:
					num = 14400u;
					break;
				case 4:
					num = 19200u;
					break;
				case 5:
					num = 38400u;
					break;
				case 6:
					num = 57600u;
					break;
				case 7:
					num = 115200u;
					break;
				default:
					MessageBox.Show("Wrong selected index in btBack_Click() of SystemConstants", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					num = 9600u;
					break;
				}
				if (this.Main.VC.SysConst.Com1.BaudRate != num)
				{
					this.Main.MakeLogbookEntry(202016u, 3, (float)(double)this.Main.VC.SysConst.Com1.BaudRate, (float)(double)num, 0u, 0, byte.MaxValue);
				}
				if (this.Main.VC.SysConst.Com1.Parity != (byte)this.cBParity.SelectedIndex)
				{
					this.Main.MakeLogbookEntry(202017u, 3, (float)(int)this.Main.VC.SysConst.Com1.Parity, (float)this.cBParity.SelectedIndex, 0u, 0, byte.MaxValue);
				}
				this.Main.VC.SysConst.IPAddress.Byte1 = (byte)this.nEIP1.Value;
				this.Main.VC.SysConst.IPAddress.Byte2 = (byte)this.nEIP2.Value;
				this.Main.VC.SysConst.IPAddress.Byte3 = (byte)this.nEIP3.Value;
				this.Main.VC.SysConst.SubNetMask.Byte1 = (byte)this.nESubnet1.Value;
				this.Main.VC.SysConst.SubNetMask.Byte2 = (byte)this.nESubnet2.Value;
				this.Main.VC.SysConst.SubNetMask.Byte3 = (byte)this.nESubnet3.Value;
				this.Main.VC.SysConst.SubNetMask.Byte4 = (byte)this.nESubnet4.Value;
				this.Main.VC.SysConst.DefaultGateway.Byte1 = (byte)this.nEDG1.Value;
				this.Main.VC.SysConst.DefaultGateway.Byte2 = (byte)this.nEDG2.Value;
				this.Main.VC.SysConst.DefaultGateway.Byte3 = (byte)this.nEDG3.Value;
				this.Main.VC.SysConst.DefaultGateway.Byte4 = (byte)this.nEDG4.Value;
				if (this.chBDHCP.Checked)
				{
					this.Main.VC.SysConst.DHCP = 1u;
				}
				else
				{
					this.Main.VC.SysConst.DHCP = 0u;
				}
				this.Main.CommonFunctions.StringToUShort(ref this.Main.VC.SysConst.IdentServerName, this.tBIdentServer.Text, 32);
				this.Main.CommonFunctions.StringToUShort(ref this.Main.VC.SysConst.AreaCode, this.tbAreaCode.Text, 16);
				this.Main.CommonFunctions.StringToUShort(ref this.Main.VC.SysConst.SystemID, this.tBID.Text, 20);
				this.Main.VC.SysConst.UnitTorque = (byte)this.cBTorqueUnit.SelectedIndex;
				this.Main.VC.SysConst.Com1.BaudRate = num;
				if (this.cBParity.SelectedIndex >= 0)
				{
					this.Main.VC.SysConst.Com1.Parity = (byte)this.cBParity.SelectedIndex;
				}
				this.Main.StatusBarText(this.Main.Rm.GetString("SendSystemConstants"));
				if (!this.Main.VC.SendVarBlock(12))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show("Could not send SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					this.pnMenu.Enabled = true;
					this.pnMenu.Select();
					return;
				}
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveSystemConstOnCPU"));
				if (!this.Main.SaveOnController(1, false))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Main.Rm.GetString("MbSaveSysConstFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					this.pnMenu.Enabled = true;
					this.pnMenu.Select();
					return;
				}
				if (flag2)
				{
					switch (this.Main.VC.SysConst.UnitTorque)
					{
					case 0:
						this.Main.TorqueConvert = 1f;
						this.Main.TorqueUnitName = this.Main.Rm.GetString("TorqueNm");
						break;
					case 1:
						this.Main.TorqueConvert = 100f;
						this.Main.TorqueUnitName = this.Main.Rm.GetString("TorqueNcm");
						break;
					case 2:
						this.Main.TorqueConvert = 8.850745f;
						this.Main.TorqueUnitName = this.Main.Rm.GetString("Torqueinlb");
						break;
					case 3:
						this.Main.TorqueConvert = 0.7375621f;
						this.Main.TorqueUnitName = this.Main.Rm.GetString("Torqueftlb");
						break;
					case 4:
						this.Main.TorqueConvert = 141.6119f;
						this.Main.TorqueUnitName = this.Main.Rm.GetString("Torqueinoz");
						break;
					case 5:
						this.Main.TorqueConvert = 0.1019716f;
						this.Main.TorqueUnitName = this.Main.Rm.GetString("Torquekgm");
						break;
					case 6:
						this.Main.TorqueConvert = 10.19716f;
						this.Main.TorqueUnitName = this.Main.Rm.GetString("Torquekgcm");
						break;
					default:
						MessageBox.Show("Wrong unitTorque type in btBack_Click() of SystemConstants", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						this.Main.TorqueConvert = 1f;
						this.Main.TorqueUnitName = "Nm";
						break;
					}
					this.Main.ResultDisplay1.UpdateValues();
					this.Main.CurveDisplay1.SetLanguageTexts();
				}
				this.Main.WriteLogbookData(true);
				if (flag)
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Main.Rm.GetString("MbIPChange"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			this.Main.LoggingFinished(true);
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			this.timerUpdate.Enabled = false;
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_3_Systemkonstanten";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_3_Systemkonstanten");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btPasscodeManager_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.gBDateTime.Select();
			if (this.Main.PassCodeLevel >= 4)
			{
				this.timerUpdate.Stop();
				this.Main.PasscodeManager1.ShowWindow();
			}
			else
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoAccess"), this.Main.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.pnMenu.Enabled = true;
			}
		}

		private void btLevelAssignment_Click(object sender, EventArgs e)
		{
			this.timerUpdate.Stop();
			this.pnMenu.Enabled = false;
			this.Main.LevelAssignment1.ShowWindow();
		}

		private void btVisuParam_Click(object sender, EventArgs e)
		{
			this.timerUpdate.Stop();
			this.pnMenu.Enabled = false;
			this.gBDateTime.Select();
			this.Main.VisualisationParam1.ShowWindow();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.timerUpdate.Enabled = false;
			this.pnMenu.Enabled = false;
			this.Main.LoggingFinished(true);
			base.Hide();
		}

		private void btTimeSet_Click(object sender, EventArgs e)
		{
			DateTime value = this.dateTimePicker.Value;
			this.SetTimeOnController(value);
		}

		private void timerUpdate_Tick(object sender, EventArgs e)
		{
			this.timerUpdate.Stop();
			if (this.UpdateControllerTime)
			{
				this.UpdateTime();
			}
			this.lbShowLocalTime.Text = DateTime.Now.ToString(Settings.Default.TimeSet);
			this.timerUpdate.Start();
		}

		private void dateTimePicker_MouseDown(object sender, MouseEventArgs e)
		{
			this.UpdateControllerTime = false;
		}

		private void btTimeSynchronize_Click(object sender, EventArgs e)
		{
			DateTime now = DateTime.Now;
			this.SetTimeOnController(now);
		}

		private void SetTimeOnController(DateTime dt)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.Main.VC.SysConst.SettingTime.Year = (ushort)dt.Year;
				this.Main.VC.SysConst.SettingTime.Month = (byte)dt.Month;
				this.Main.VC.SysConst.SettingTime.Day = (byte)dt.Day;
				this.Main.VC.SysConst.SettingTime.Hour = (byte)dt.Hour;
				this.Main.VC.SysConst.SettingTime.Minute = (byte)dt.Minute;
				this.Main.VC.SysConst.SettingTime.Second = (byte)dt.Second;
				this.Main.StatusBarText(this.Main.Rm.GetString("SendSystemConstants"));
				Cursor.Current = Cursors.WaitCursor;
				if (!this.Main.VC.SendVarBlock(12))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show("Could not send SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					this.pnMenu.Enabled = true;
					this.pnMenu.Select();
				}
				else
				{
					this.Main.StatusBarText(this.Main.Rm.GetString("SaveSystemConstOnCPU"));
					if (!this.Main.SaveOnController(4, false))
					{
						this.Main.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						MessageBox.Show(this.Main.Rm.GetString("MbSaveSysConstFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
						this.pnMenu.Enabled = true;
						this.pnMenu.Select();
					}
					else
					{
						this.Main.MakeLogbookEntry(202015u, 3, 0f, 0f, 0u, 0, byte.MaxValue);
						this.Main.WriteLogbookData(true);
						this.Main.LoggingFinished(true);
					}
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					this.UpdateControllerTime = true;
				}
			}
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			this.IDSelectionStart = this.tBID.SelectionStart;
			this.IdentServerSelectionStart = this.tBIdentServer.SelectionStart;
			this.AreaCodeSelectionStart = this.tbAreaCode.SelectionStart;
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void SystemConstantsForm_Paint(object sender, PaintEventArgs e)
		{
		}

		private void SystemConstantsForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
			this.MenEna();
			this.Main.DisplayCurrentUser();
		}

		private void dateTimePicker_Leave(object sender, EventArgs e)
		{
			this.UpdateControllerTime = true;
		}

		private void tBID_TextChanged(object sender, EventArgs e)
		{
			char[] trimChars = new char[1]
			{
				' '
			};
			if (this.tBID.Text != this.IDNewText)
			{
				this.tBID.Text = this.tBID.Text.TrimStart(trimChars);
				string text = this.tBID.Text;
				for (int i = 0; i < this.tBID.Text.Length; i++)
				{
					if (text[i] != '-' && text[i] != '_' && text[i] != ' ' && (!char.IsLetterOrDigit(text, i) || text[i] == 'Ö' || text[i] == 'ö' || text[i] == 'Ä' || text[i] == 'ä' || text[i] == 'Ü' || text[i] == 'ü' || text[i] == 'ß'))
					{
						this.tBID.Text = this.IDNewText;
						if (this.IDSelectionStart < 0)
						{
							this.IDSelectionStart = 0;
						}
						this.tBID.SelectionStart = this.IDSelectionStart;
						return;
					}
				}
				this.IDNewText = this.tBID.Text;
				this.IDSelectionStart = this.tBID.SelectionStart;
			}
		}

		private void tBIdentServer_TextChanged(object sender, EventArgs e)
		{
			char[] trimChars = new char[1]
			{
				' '
			};
			if (this.tBIdentServer.Text != this.IdentServerNewText)
			{
				this.tBIdentServer.Text = this.tBIdentServer.Text.TrimStart(trimChars);
				string text = this.tBIdentServer.Text;
				for (int i = 0; i < this.tBIdentServer.Text.Length; i++)
				{
					if (text[i] != '-' && text[i] != '_' && text[i] != ' ' && (!char.IsLetterOrDigit(text, i) || text[i] == 'Ö' || text[i] == 'ö' || text[i] == 'Ä' || text[i] == 'ä' || text[i] == 'Ü' || text[i] == 'ü' || text[i] == 'ß'))
					{
						this.tBIdentServer.Text = this.IdentServerNewText;
						if (this.IdentServerSelectionStart < 0)
						{
							this.IdentServerSelectionStart = 0;
						}
						this.tBIdentServer.SelectionStart = this.IdentServerSelectionStart;
						return;
					}
				}
				this.IdentServerNewText = this.tBIdentServer.Text;
				this.IdentServerSelectionStart = this.tBIdentServer.SelectionStart;
			}
		}

		private void tbAreaCode_TextChanged(object sender, EventArgs e)
		{
			char[] trimChars = new char[1]
			{
				' '
			};
			if (this.tbAreaCode.Text != this.AreaCodeNewText)
			{
				this.tbAreaCode.Text = this.tbAreaCode.Text.TrimStart(trimChars);
				string text = this.tbAreaCode.Text;
				for (int i = 0; i < this.tbAreaCode.Text.Length; i++)
				{
					if (text[i] != '-' && text[i] != '_' && text[i] != ' ' && (!char.IsLetterOrDigit(text, i) || text[i] == 'Ö' || text[i] == 'ö' || text[i] == 'Ä' || text[i] == 'ä' || text[i] == 'Ü' || text[i] == 'ü' || text[i] == 'ß'))
					{
						this.tbAreaCode.Text = this.AreaCodeNewText;
						if (this.AreaCodeSelectionStart < 0)
						{
							this.AreaCodeSelectionStart = 0;
						}
						this.tbAreaCode.SelectionStart = this.AreaCodeSelectionStart;
						return;
					}
				}
				this.AreaCodeNewText = this.tbAreaCode.Text;
				this.AreaCodeSelectionStart = this.tbAreaCode.SelectionStart;
			}
		}

		private void tBID_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode != Keys.Left && e.KeyCode != Keys.Right)
			{
				return;
			}
			this.IDSelectionStart = this.tBID.SelectionStart;
		}

		private void tBIdentServer_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode != Keys.Left && e.KeyCode != Keys.Right)
			{
				return;
			}
			this.IdentServerSelectionStart = this.tBIdentServer.SelectionStart;
		}

		private void tBAreaCode_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode != Keys.Left && e.KeyCode != Keys.Right)
			{
				return;
			}
			this.AreaCodeSelectionStart = this.tbAreaCode.SelectionStart;
		}

		public void KeyArrived()
		{
			if (this.Main.PassCodeLevel > 0)
			{
				if (this.Main.GetExclusiveBlock1())
				{
					this.Main.ProcessProgram.UploadAllProgDataFromController();
					this.Main.ProcessProgram.InitializeTempProgStruct();
					this.Main.CheckParamAllowed = true;
					this.ShowWindow();
				}
				else
				{
					this.Main.CheckParamAllowed = false;
				}
			}
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void enableIpControls(bool enabled)
		{
			if (enabled)
			{
				bool enabled2 = !this.chBDHCP.Checked && true;
				this.nEIP1.Enabled = enabled2;
				this.nEIP2.Enabled = enabled2;
				this.nEIP3.Enabled = enabled2;
				this.nEIP4.Enabled = enabled2;
				this.nESubnet1.Enabled = enabled2;
				this.nESubnet2.Enabled = enabled2;
				this.nESubnet3.Enabled = enabled2;
				this.nESubnet4.Enabled = enabled2;
				this.nEDG1.Enabled = enabled2;
				this.nEDG2.Enabled = enabled2;
				this.nEDG3.Enabled = enabled2;
				this.nEDG4.Enabled = enabled2;
				this.lbIP.Enabled = enabled2;
				this.lbSubnetMask.Enabled = enabled2;
				this.lbDG.Enabled = enabled2;
			}
		}

		private void chBDHCP_CheckedChanged(object sender, EventArgs e)
		{
			bool enabled = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_SystemConstantsForm)
			{
				enabled = true;
			}
			this.enableIpControls(enabled);
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.initInProgress)
			{
				this.Main.SettingsChanged();
			}
		}
	}
}
