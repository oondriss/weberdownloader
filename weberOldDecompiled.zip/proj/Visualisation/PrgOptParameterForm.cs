using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class PrgOptParameterForm : Form
	{
		private MainForm Main;

		private WSP1_VarComm.ProgStruct PD;

		private int PNum;

		private int SNum;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Container components;

		private Label lbProgNum;

		private Label lbGradientLength;

		private NumberEdit1 nEGradientLength;

		private Label lbM1FilterTime;

		private NumberEdit1 nEM1FilterTime;

		private Label lbUnitM1FilterTime;

		private CheckBox chBGradFilter;

		private Button btCancel;

		private Button bt3;

		private Button bt2;

		private Button bt5;

		private Button bt4;

		private Button bt1;

		private Panel pnPrgOptSettings;

		private Panel pnProgName;

		private Label lbProgramName;

		private GroupBox gBForceSignals;

		private ComboBox cBDigSig1;

		private CheckBox chBDigSig1;

		private CheckBox chBDigSig2;

		private CheckBox chBSync1;

		private CheckBox chBSync2;

		private ComboBox cBDigSig2;

		private ComboBox cBSync1;

		private ComboBox cBSync2;

		private GroupBox gBFilterGradient;

		private GroupBox gBDepthGrad;

		private Label lbUnitDepthFilterTime;

		private Label lbDepthFilterTime;

		private Label lbUnitDepthGradLength;

		private Label lbDepthGradLength;

		private Label lbUnitGradLength;

		private NumberEdit1 nEDepthFilterTime;

		private GroupBox gBHolder;

		private Label lbPressureHolder;

		private NumberEdit1 nEPressureHolder;

		private NumberEdit1 nEDepthGradLength;

		private Label lbUnitSpindlePressureKN;

		private bool bCanceled;

		private bool bInitialize;

		public bool WasCanceled
		{
			get
			{
				bool result = this.bCanceled;
				this.bCanceled = false;
				return result;
			}
		}

		public PrgOptParameterForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.PNum = 1;
			this.SNum = 0;
			this.nEGradientLength.MaxValue = 100f;
			this.nEDepthGradLength.MaxValue = 500f;
			this.nEM1FilterTime.MaxValue = 999f;
			this.nEDepthFilterTime.MaxValue = 500f;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.btCancel = new Button();
			this.bt3 = new Button();
			this.btHelp = new Button();
			this.bt2 = new Button();
			this.bt5 = new Button();
			this.bt4 = new Button();
			this.bt1 = new Button();
			this.btBack = new Button();
			this.pnProgName = new Panel();
			this.lbProgramName = new Label();
			this.lbProgNum = new Label();
			this.lbGradientLength = new Label();
			this.nEGradientLength = new NumberEdit1();
			this.lbM1FilterTime = new Label();
			this.nEM1FilterTime = new NumberEdit1();
			this.lbUnitM1FilterTime = new Label();
			this.lbUnitGradLength = new Label();
			this.chBGradFilter = new CheckBox();
			this.pnPrgOptSettings = new Panel();
			this.gBHolder = new GroupBox();
			this.lbUnitSpindlePressureKN = new Label();
			this.lbPressureHolder = new Label();
			this.nEPressureHolder = new NumberEdit1();
			this.gBDepthGrad = new GroupBox();
			this.lbUnitDepthFilterTime = new Label();
			this.lbDepthFilterTime = new Label();
			this.nEDepthFilterTime = new NumberEdit1();
			this.lbUnitDepthGradLength = new Label();
			this.lbDepthGradLength = new Label();
			this.nEDepthGradLength = new NumberEdit1();
			this.gBFilterGradient = new GroupBox();
			this.gBForceSignals = new GroupBox();
			this.cBSync2 = new ComboBox();
			this.cBSync1 = new ComboBox();
			this.cBDigSig2 = new ComboBox();
			this.chBSync2 = new CheckBox();
			this.chBSync1 = new CheckBox();
			this.chBDigSig2 = new CheckBox();
			this.chBDigSig1 = new CheckBox();
			this.cBDigSig1 = new ComboBox();
			this.pnMenu = new Panel();
			this.pnProgName.SuspendLayout();
			this.pnPrgOptSettings.SuspendLayout();
			this.gBHolder.SuspendLayout();
			this.gBDepthGrad.SuspendLayout();
			this.gBFilterGradient.SuspendLayout();
			this.gBForceSignals.SuspendLayout();
			this.pnMenu.SuspendLayout();
			base.SuspendLayout();
			this.btCancel.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 7;
			this.btCancel.Text = "Abbruch";
			this.btCancel.Click += this.btCancel_Click;
			this.bt3.Enabled = false;
			this.bt3.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt3.Location = new Point(3, 259);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 4;
			this.btHelp.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btHelp.Enter += this.Start_Input;
			this.bt2.Enabled = false;
			this.bt2.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt2.Location = new Point(3, 195);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 3;
			this.bt5.Enabled = false;
			this.bt5.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt5.Location = new Point(3, 387);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(74, 62);
			this.bt5.TabIndex = 6;
			this.bt4.Enabled = false;
			this.bt4.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt4.Location = new Point(3, 323);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(74, 62);
			this.bt4.TabIndex = 5;
			this.bt1.Enabled = false;
			this.bt1.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt1.Location = new Point(3, 131);
			this.bt1.Name = "bt1";
			this.bt1.Size = new Size(74, 62);
			this.bt1.TabIndex = 2;
			this.btBack.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Fertig";
			this.btBack.Click += this.btBack_Click;
			this.btBack.Enter += this.Start_Input;
			this.pnProgName.Controls.Add(this.lbProgramName);
			this.pnProgName.Controls.Add(this.lbProgNum);
			this.pnProgName.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnProgName.Location = new Point(0, 0);
			this.pnProgName.Name = "pnProgName";
			this.pnProgName.Size = new Size(288, 39);
			this.pnProgName.TabIndex = 0;
			this.lbProgramName.BorderStyle = BorderStyle.Fixed3D;
			this.lbProgramName.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgramName.Location = new Point(48, 8);
			this.lbProgramName.Name = "lbProgramName";
			this.lbProgramName.Size = new Size(232, 23);
			this.lbProgramName.TabIndex = 2;
			this.lbProgramName.Text = "Name";
			this.lbProgramName.TextAlign = ContentAlignment.MiddleLeft;
			this.lbProgNum.BorderStyle = BorderStyle.Fixed3D;
			this.lbProgNum.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgNum.Location = new Point(8, 8);
			this.lbProgNum.Name = "lbProgNum";
			this.lbProgNum.Size = new Size(32, 23);
			this.lbProgNum.TabIndex = 1;
			this.lbProgNum.Text = "0";
			this.lbProgNum.TextAlign = ContentAlignment.MiddleRight;
			this.lbGradientLength.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbGradientLength.Location = new Point(16, 64);
			this.lbGradientLength.Name = "lbGradientLength";
			this.lbGradientLength.Size = new Size(192, 23);
			this.lbGradientLength.TabIndex = 53;
			this.lbGradientLength.Text = "Gradient Länge";
			this.lbGradientLength.TextAlign = ContentAlignment.MiddleLeft;
			this.nEGradientLength.BackColor = Color.White;
			this.nEGradientLength.DecimalNum = 0;
			this.nEGradientLength.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEGradientLength.ForeColor = SystemColors.ControlText;
			this.nEGradientLength.Location = new Point(208, 61);
			this.nEGradientLength.MaxValue = 2000f;
			this.nEGradientLength.MinValue = 1f;
			this.nEGradientLength.Name = "nEGradientLength";
			this.nEGradientLength.Size = new Size(64, 28);
			this.nEGradientLength.TabIndex = 2;
			this.nEGradientLength.Text = "1";
			this.nEGradientLength.TextAlign = HorizontalAlignment.Right;
			this.nEGradientLength.Value = 1f;
			this.nEGradientLength.TextChanged += this.settingsChanged;
			this.nEGradientLength.Enter += this.Start_Input;
			this.nEGradientLength.MouseDown += this.StartInput;
			this.lbM1FilterTime.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbM1FilterTime.Location = new Point(16, 32);
			this.lbM1FilterTime.Name = "lbM1FilterTime";
			this.lbM1FilterTime.Size = new Size(192, 23);
			this.lbM1FilterTime.TabIndex = 73;
			this.lbM1FilterTime.Text = "Moment Filter Zeit";
			this.lbM1FilterTime.TextAlign = ContentAlignment.MiddleLeft;
			this.nEM1FilterTime.BackColor = Color.White;
			this.nEM1FilterTime.DecimalNum = 0;
			this.nEM1FilterTime.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEM1FilterTime.ForeColor = SystemColors.ControlText;
			this.nEM1FilterTime.Location = new Point(208, 29);
			this.nEM1FilterTime.MaxValue = 999f;
			this.nEM1FilterTime.MinValue = 0f;
			this.nEM1FilterTime.Name = "nEM1FilterTime";
			this.nEM1FilterTime.Size = new Size(64, 28);
			this.nEM1FilterTime.TabIndex = 1;
			this.nEM1FilterTime.Text = "0";
			this.nEM1FilterTime.TextAlign = HorizontalAlignment.Right;
			this.nEM1FilterTime.Value = 0f;
			this.nEM1FilterTime.TextChanged += this.settingsChanged;
			this.nEM1FilterTime.Enter += this.Start_Input;
			this.nEM1FilterTime.MouseDown += this.StartInput;
			this.lbUnitM1FilterTime.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitM1FilterTime.Location = new Point(280, 32);
			this.lbUnitM1FilterTime.Name = "lbUnitM1FilterTime";
			this.lbUnitM1FilterTime.Size = new Size(48, 23);
			this.lbUnitM1FilterTime.TabIndex = 74;
			this.lbUnitM1FilterTime.Text = "ms";
			this.lbUnitM1FilterTime.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitGradLength.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitGradLength.Location = new Point(280, 64);
			this.lbUnitGradLength.Name = "lbUnitGradLength";
			this.lbUnitGradLength.Size = new Size(48, 23);
			this.lbUnitGradLength.TabIndex = 78;
			this.lbUnitGradLength.Text = "Inc";
			this.lbUnitGradLength.TextAlign = ContentAlignment.MiddleLeft;
			this.chBGradFilter.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBGradFilter.Location = new Point(16, 96);
			this.chBGradFilter.Name = "chBGradFilter";
			this.chBGradFilter.Size = new Size(216, 24);
			this.chBGradFilter.TabIndex = 0;
			this.chBGradFilter.Text = "Gradient filtern";
			this.chBGradFilter.CheckedChanged += this.settingsChanged;
			this.chBGradFilter.Enter += this.Start_Input;
			this.pnPrgOptSettings.Controls.Add(this.gBHolder);
			this.pnPrgOptSettings.Controls.Add(this.gBDepthGrad);
			this.pnPrgOptSettings.Controls.Add(this.gBFilterGradient);
			this.pnPrgOptSettings.Controls.Add(this.gBForceSignals);
			this.pnPrgOptSettings.Location = new Point(0, 48);
			this.pnPrgOptSettings.Name = "pnPrgOptSettings";
			this.pnPrgOptSettings.Size = new Size(709, 450);
			this.pnPrgOptSettings.TabIndex = 2;
			this.gBHolder.Controls.Add(this.lbUnitSpindlePressureKN);
			this.gBHolder.Controls.Add(this.lbPressureHolder);
			this.gBHolder.Controls.Add(this.nEPressureHolder);
			this.gBHolder.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBHolder.Location = new Point(16, 263);
			this.gBHolder.Name = "gBHolder";
			this.gBHolder.Size = new Size(336, 74);
			this.gBHolder.TabIndex = 82;
			this.gBHolder.TabStop = false;
			this.gBHolder.Text = "Niederhalter";
			this.lbUnitSpindlePressureKN.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitSpindlePressureKN.Location = new Point(280, 32);
			this.lbUnitSpindlePressureKN.Name = "lbUnitSpindlePressureKN";
			this.lbUnitSpindlePressureKN.Size = new Size(50, 23);
			this.lbUnitSpindlePressureKN.TabIndex = 74;
			this.lbUnitSpindlePressureKN.Text = "kN";
			this.lbUnitSpindlePressureKN.TextAlign = ContentAlignment.MiddleLeft;
			this.lbPressureHolder.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbPressureHolder.Location = new Point(16, 32);
			this.lbPressureHolder.Name = "lbPressureHolder";
			this.lbPressureHolder.Size = new Size(192, 23);
			this.lbPressureHolder.TabIndex = 73;
			this.lbPressureHolder.Text = "Druck";
			this.lbPressureHolder.TextAlign = ContentAlignment.MiddleLeft;
			this.nEPressureHolder.BackColor = Color.White;
			this.nEPressureHolder.DecimalNum = 2;
			this.nEPressureHolder.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEPressureHolder.ForeColor = SystemColors.ControlText;
			this.nEPressureHolder.Location = new Point(208, 29);
			this.nEPressureHolder.MaxValue = 10f;
			this.nEPressureHolder.MinValue = 0f;
			this.nEPressureHolder.Name = "nEPressureHolder";
			this.nEPressureHolder.Size = new Size(64, 28);
			this.nEPressureHolder.TabIndex = 1;
			this.nEPressureHolder.Text = "0,00";
			this.nEPressureHolder.TextAlign = HorizontalAlignment.Right;
			this.nEPressureHolder.Value = 0f;
			this.nEPressureHolder.TextChanged += this.settingsChanged;
			this.nEPressureHolder.Enter += this.Start_Input;
			this.nEPressureHolder.MouseDown += this.StartInput;
			this.gBDepthGrad.Controls.Add(this.lbUnitDepthFilterTime);
			this.gBDepthGrad.Controls.Add(this.lbDepthFilterTime);
			this.gBDepthGrad.Controls.Add(this.nEDepthFilterTime);
			this.gBDepthGrad.Controls.Add(this.lbUnitDepthGradLength);
			this.gBDepthGrad.Controls.Add(this.lbDepthGradLength);
			this.gBDepthGrad.Controls.Add(this.nEDepthGradLength);
			this.gBDepthGrad.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBDepthGrad.Location = new Point(16, 150);
			this.gBDepthGrad.Name = "gBDepthGrad";
			this.gBDepthGrad.Size = new Size(336, 107);
			this.gBDepthGrad.TabIndex = 81;
			this.gBDepthGrad.TabStop = false;
			this.gBDepthGrad.Text = "Analogtiefe";
			this.lbUnitDepthFilterTime.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitDepthFilterTime.Location = new Point(280, 32);
			this.lbUnitDepthFilterTime.Name = "lbUnitDepthFilterTime";
			this.lbUnitDepthFilterTime.Size = new Size(48, 23);
			this.lbUnitDepthFilterTime.TabIndex = 74;
			this.lbUnitDepthFilterTime.Text = "ms";
			this.lbUnitDepthFilterTime.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDepthFilterTime.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDepthFilterTime.Location = new Point(16, 32);
			this.lbDepthFilterTime.Name = "lbDepthFilterTime";
			this.lbDepthFilterTime.Size = new Size(192, 23);
			this.lbDepthFilterTime.TabIndex = 73;
			this.lbDepthFilterTime.Text = "Moment Filter Zeit";
			this.lbDepthFilterTime.TextAlign = ContentAlignment.MiddleLeft;
			this.nEDepthFilterTime.BackColor = Color.White;
			this.nEDepthFilterTime.DecimalNum = 0;
			this.nEDepthFilterTime.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDepthFilterTime.ForeColor = SystemColors.ControlText;
			this.nEDepthFilterTime.Location = new Point(208, 29);
			this.nEDepthFilterTime.MaxValue = 500f;
			this.nEDepthFilterTime.MinValue = 0f;
			this.nEDepthFilterTime.Name = "nEDepthFilterTime";
			this.nEDepthFilterTime.Size = new Size(64, 28);
			this.nEDepthFilterTime.TabIndex = 1;
			this.nEDepthFilterTime.Text = "0";
			this.nEDepthFilterTime.TextAlign = HorizontalAlignment.Right;
			this.nEDepthFilterTime.Value = 0f;
			this.nEDepthFilterTime.TextChanged += this.settingsChanged;
			this.nEDepthFilterTime.Enter += this.Start_Input;
			this.nEDepthFilterTime.MouseDown += this.StartInput;
			this.lbUnitDepthGradLength.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitDepthGradLength.Location = new Point(280, 64);
			this.lbUnitDepthGradLength.Name = "lbUnitDepthGradLength";
			this.lbUnitDepthGradLength.Size = new Size(48, 23);
			this.lbUnitDepthGradLength.TabIndex = 78;
			this.lbUnitDepthGradLength.Text = "Inc";
			this.lbUnitDepthGradLength.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDepthGradLength.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDepthGradLength.Location = new Point(16, 64);
			this.lbDepthGradLength.Name = "lbDepthGradLength";
			this.lbDepthGradLength.Size = new Size(192, 23);
			this.lbDepthGradLength.TabIndex = 53;
			this.lbDepthGradLength.Text = "Gradient Länge";
			this.lbDepthGradLength.TextAlign = ContentAlignment.MiddleLeft;
			this.nEDepthGradLength.BackColor = Color.White;
			this.nEDepthGradLength.DecimalNum = 0;
			this.nEDepthGradLength.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDepthGradLength.ForeColor = SystemColors.ControlText;
			this.nEDepthGradLength.Location = new Point(208, 61);
			this.nEDepthGradLength.MaxValue = 500f;
			this.nEDepthGradLength.MinValue = 1f;
			this.nEDepthGradLength.Name = "nEDepthGradLength";
			this.nEDepthGradLength.Size = new Size(64, 28);
			this.nEDepthGradLength.TabIndex = 2;
			this.nEDepthGradLength.Text = "1";
			this.nEDepthGradLength.TextAlign = HorizontalAlignment.Right;
			this.nEDepthGradLength.Value = 1f;
			this.nEDepthGradLength.TextChanged += this.settingsChanged;
			this.nEDepthGradLength.Enter += this.Start_Input;
			this.nEDepthGradLength.MouseDown += this.StartInput;
			this.gBFilterGradient.Controls.Add(this.lbUnitM1FilterTime);
			this.gBFilterGradient.Controls.Add(this.lbM1FilterTime);
			this.gBFilterGradient.Controls.Add(this.nEM1FilterTime);
			this.gBFilterGradient.Controls.Add(this.lbUnitGradLength);
			this.gBFilterGradient.Controls.Add(this.lbGradientLength);
			this.gBFilterGradient.Controls.Add(this.nEGradientLength);
			this.gBFilterGradient.Controls.Add(this.chBGradFilter);
			this.gBFilterGradient.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBFilterGradient.Location = new Point(16, 8);
			this.gBFilterGradient.Name = "gBFilterGradient";
			this.gBFilterGradient.Size = new Size(336, 136);
			this.gBFilterGradient.TabIndex = 80;
			this.gBFilterGradient.TabStop = false;
			this.gBFilterGradient.Text = "Moment";
			this.gBForceSignals.Controls.Add(this.cBSync2);
			this.gBForceSignals.Controls.Add(this.cBSync1);
			this.gBForceSignals.Controls.Add(this.cBDigSig2);
			this.gBForceSignals.Controls.Add(this.chBSync2);
			this.gBForceSignals.Controls.Add(this.chBSync1);
			this.gBForceSignals.Controls.Add(this.chBDigSig2);
			this.gBForceSignals.Controls.Add(this.chBDigSig1);
			this.gBForceSignals.Controls.Add(this.cBDigSig1);
			this.gBForceSignals.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBForceSignals.Location = new Point(360, 8);
			this.gBForceSignals.Name = "gBForceSignals";
			this.gBForceSignals.Size = new Size(336, 161);
			this.gBForceSignals.TabIndex = 79;
			this.gBForceSignals.TabStop = false;
			this.gBForceSignals.Text = "am Programmende zu setzende Werte";
			this.cBSync2.BackColor = SystemColors.Window;
			this.cBSync2.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBSync2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBSync2.Items.AddRange(new object[9]
			{
				"Moment",
				"MaxMoment",
				"gefilt. M",
				"Gradient",
				"Winkel",
				"Zeit",
				"anal. Tiefe",
				"Analogsignal",
				"dig. Tiefe"
			});
			this.cBSync2.Location = new Point(192, 120);
			this.cBSync2.MaxDropDownItems = 10;
			this.cBSync2.Name = "cBSync2";
			this.cBSync2.Size = new Size(88, 28);
			this.cBSync2.TabIndex = 9;
			this.cBSync2.SelectionChangeCommitted += this.settingsChanged;
			this.cBSync1.BackColor = SystemColors.Window;
			this.cBSync1.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBSync1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBSync1.Items.AddRange(new object[9]
			{
				"Moment",
				"MaxMoment",
				"gefilt. M",
				"Gradient",
				"Winkel",
				"Zeit",
				"anal. Tiefe",
				"Analogsignal",
				"dig. Tiefe"
			});
			this.cBSync1.Location = new Point(192, 88);
			this.cBSync1.MaxDropDownItems = 10;
			this.cBSync1.Name = "cBSync1";
			this.cBSync1.Size = new Size(88, 28);
			this.cBSync1.TabIndex = 7;
			this.cBSync1.Visible = false;
			this.cBSync1.SelectionChangeCommitted += this.settingsChanged;
			this.cBDigSig2.BackColor = SystemColors.Window;
			this.cBDigSig2.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBDigSig2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBDigSig2.Items.AddRange(new object[9]
			{
				"Moment",
				"MaxMoment",
				"gefilt. M",
				"Gradient",
				"Winkel",
				"Zeit",
				"anal. Tiefe",
				"Analogsignal",
				"dig. Tiefe"
			});
			this.cBDigSig2.Location = new Point(192, 56);
			this.cBDigSig2.MaxDropDownItems = 10;
			this.cBDigSig2.Name = "cBDigSig2";
			this.cBDigSig2.Size = new Size(88, 28);
			this.cBDigSig2.TabIndex = 5;
			this.cBDigSig2.SelectionChangeCommitted += this.settingsChanged;
			this.chBSync2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBSync2.Location = new Point(16, 122);
			this.chBSync2.Name = "chBSync2";
			this.chBSync2.Size = new Size(160, 24);
			this.chBSync2.TabIndex = 8;
			this.chBSync2.Text = "Sync 2";
			this.chBSync2.CheckedChanged += this.chBSync2_CheckedChanged;
			this.chBSync2.Enter += this.Start_Input;
			this.chBSync1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBSync1.Location = new Point(16, 90);
			this.chBSync1.Name = "chBSync1";
			this.chBSync1.Size = new Size(160, 24);
			this.chBSync1.TabIndex = 6;
			this.chBSync1.Text = "Sync 1";
			this.chBSync1.Visible = false;
			this.chBSync1.CheckedChanged += this.chBSync2_CheckedChanged;
			this.chBSync1.Enter += this.Start_Input;
			this.chBDigSig2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBDigSig2.Location = new Point(16, 58);
			this.chBDigSig2.Name = "chBDigSig2";
			this.chBDigSig2.Size = new Size(160, 24);
			this.chBDigSig2.TabIndex = 4;
			this.chBDigSig2.Text = "Digitalsignal 2";
			this.chBDigSig2.CheckedChanged += this.chBSync2_CheckedChanged;
			this.chBDigSig2.Enter += this.Start_Input;
			this.chBDigSig1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBDigSig1.Location = new Point(16, 26);
			this.chBDigSig1.Name = "chBDigSig1";
			this.chBDigSig1.Size = new Size(160, 24);
			this.chBDigSig1.TabIndex = 2;
			this.chBDigSig1.Text = "Digitalsignal 1";
			this.chBDigSig1.CheckedChanged += this.chBSync2_CheckedChanged;
			this.chBDigSig1.Enter += this.Start_Input;
			this.cBDigSig1.BackColor = SystemColors.Window;
			this.cBDigSig1.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBDigSig1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBDigSig1.Items.AddRange(new object[9]
			{
				"Moment",
				"MaxMoment",
				"gefilt. M",
				"Gradient",
				"Winkel",
				"Zeit",
				"anal. Tiefe",
				"Analogsignal",
				"dig. Tiefe"
			});
			this.cBDigSig1.Location = new Point(192, 24);
			this.cBDigSig1.MaxDropDownItems = 10;
			this.cBDigSig1.Name = "cBDigSig1";
			this.cBDigSig1.Size = new Size(88, 28);
			this.cBDigSig1.TabIndex = 3;
			this.cBDigSig1.SelectionChangeCommitted += this.settingsChanged;
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.bt1);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.bt4);
			this.pnMenu.Controls.Add(this.bt5);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 1;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.pnPrgOptSettings);
			base.Controls.Add(this.pnProgName);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "PrgOptParameterForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen/Programme/Stufen";
			base.Activated += this.StepOverviewForm_Activated;
			this.pnProgName.ResumeLayout(false);
			this.pnPrgOptSettings.ResumeLayout(false);
			this.gBHolder.ResumeLayout(false);
			this.gBHolder.PerformLayout();
			this.gBDepthGrad.ResumeLayout(false);
			this.gBDepthGrad.PerformLayout();
			this.gBFilterGradient.ResumeLayout(false);
			this.gBFilterGradient.PerformLayout();
			this.gBForceSignals.ResumeLayout(false);
			this.pnMenu.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public bool ShowWindow(int number)
		{
			if (number >= 1 && number < 1024)
			{
				this.Main.ResetBrowserGrantedBy();
				this.PNum = number;
				this.PD = this.Main.ProcessProgram.TempProgStruct.Num[this.PNum];
				this.MenEna();
				this.SNum = 0;
				this.InitializeValues();
				this.pnProgName.Select();
				base.Show();
				return true;
			}
			return false;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MProgramOverview") + "/" + this.Main.Rm.GetString("MStepOverview") + "/" + this.Main.Rm.GetString("MOptPrgParam");
			this.chBGradFilter.Text = this.Main.Rm.GetString("GradFilter");
			this.lbGradientLength.Text = this.Main.Rm.GetString("GradientLength");
			this.lbDepthGradLength.Text = this.Main.Rm.GetString("DepthGradLength");
			this.lbM1FilterTime.Text = this.Main.Rm.GetString("M1FilterTime");
			this.lbDepthFilterTime.Text = this.Main.Rm.GetString("DepthFilterTime");
			this.lbPressureHolder.Text = this.Main.Rm.GetString("Force");
			this.btBack.Text = this.Main.Rm.GetString("Done");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btCancel.Text = this.Main.Rm.GetString("btCancel");
			this.lbUnitM1FilterTime.Text = this.Main.Rm.GetString("Milisecond");
			this.lbUnitDepthFilterTime.Text = this.Main.Rm.GetString("Milisecond");
			this.lbUnitGradLength.Text = this.Main.Rm.GetString("Increment");
			this.lbUnitDepthGradLength.Text = this.Main.Rm.GetString("Milisecond");
			this.gBForceSignals.Text = this.Main.Rm.GetString("ForceSignals");
			this.gBFilterGradient.Text = this.Main.Rm.GetString("Torque");
			this.gBDepthGrad.Text = this.Main.Rm.GetString("AnaDepth");
			this.gBHolder.Text = this.Main.Rm.GetString("Holder");
			this.chBDigSig1.Text = this.Main.Rm.GetString("DigitalSignal") + "1";
			this.chBDigSig2.Text = this.Main.Rm.GetString("DigitalSignal") + "2";
			this.chBSync1.Text = this.Main.Rm.GetString("SyncSignal") + "1";
			this.chBSync2.Text = this.Main.Rm.GetString("SyncSignal") + "2";
			this.cBDigSig1.Items.Clear();
			this.cBDigSig1.Items.Add(this.Main.Rm.GetString("SetOff"));
			this.cBDigSig1.Items.Add(this.Main.Rm.GetString("SetOn"));
			this.cBDigSig1.SelectedIndex = 0;
			this.cBDigSig2.Items.Clear();
			this.cBDigSig2.Items.Add(this.Main.Rm.GetString("SetOff"));
			this.cBDigSig2.Items.Add(this.Main.Rm.GetString("SetOn"));
			this.cBDigSig2.SelectedIndex = 0;
			this.cBSync1.Items.Clear();
			this.cBSync1.Items.Add(this.Main.Rm.GetString("SetOff"));
			this.cBSync1.Items.Add(this.Main.Rm.GetString("SetOn"));
			this.cBSync1.SelectedIndex = 0;
			this.cBSync2.Items.Clear();
			this.cBSync2.Items.Add(this.Main.Rm.GetString("SetOff"));
			this.cBSync2.Items.Add(this.Main.Rm.GetString("SetOn"));
			this.cBSync2.SelectedIndex = 0;
			this.lbUnitSpindlePressureKN.Text = this.Main.Rm.GetString("KiloNewton");
		}

		private void MenEna()
		{
			bool flag = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_PrgOptParameterForm)
			{
				flag = true;
			}
			byte passCodeLevel = this.Main.PassCodeLevel;
			if (this.Main.ViewOnlyMode)
			{
				flag = false;
			}
			if (this.Main.IsOfflineVersion)
			{
				flag = true;
			}
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_PrgOptParameterForm, false);
			this.chBGradFilter.Enabled = flag;
			this.nEGradientLength.Enabled = flag;
			this.nEDepthGradLength.Enabled = flag;
			this.nEM1FilterTime.Enabled = flag;
			this.nEDepthFilterTime.Enabled = flag;
			this.nEPressureHolder.Enabled = flag;
			this.chBDigSig1.Enabled = flag;
			this.chBDigSig2.Enabled = flag;
			this.chBSync1.Enabled = flag;
			this.chBSync2.Enabled = flag;
			this.cBDigSig1.Enabled = (this.chBDigSig1.Checked && flag);
			this.cBDigSig2.Enabled = (this.chBDigSig2.Checked && flag);
			this.cBSync1.Enabled = (this.chBSync1.Checked && flag);
			this.cBSync2.Enabled = (this.chBSync2.Checked && flag);
			this.nEGradientLength.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDepthGradLength.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEM1FilterTime.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDepthFilterTime.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEPressureHolder.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
		}

		private void InitializeValues()
		{
			this.bInitialize = true;
			this.nEPressureHolder.MaxValue = this.Main.VC.SpConst.PressureScaleHolder * 6f;
			this.nEPressureHolder.DecimalNum = 2;
			this.lbProgNum.Text = this.PNum.ToString();
			this.lbProgramName.Text = this.Main.CommonFunctions.UShortToString(this.PD.Info.Name);
			if (this.PD.GradientFilter == 1)
			{
				this.chBGradFilter.Checked = true;
			}
			else
			{
				this.chBGradFilter.Checked = false;
			}
			this.nEGradientLength.Value = (float)(int)this.PD.GradientLength;
			this.nEDepthGradLength.Value = (float)(int)this.PD.ADepthGradientLength;
			this.nEM1FilterTime.Value = this.PD.M1FilterTime;
			this.nEDepthFilterTime.Value = this.PD.ADepthFilterTime;
			this.nEPressureHolder.Value = this.PD.PressureHolder;
			if (this.PD.EndSetDigOut1 == 1)
			{
				this.chBDigSig1.Checked = true;
			}
			else
			{
				this.chBDigSig1.Checked = false;
			}
			if (this.PD.EndSetDigOut2 == 1)
			{
				this.chBDigSig2.Checked = true;
			}
			else
			{
				this.chBDigSig2.Checked = false;
			}
			if (this.PD.EndSetSync1 == 1)
			{
				this.chBSync1.Checked = true;
			}
			else
			{
				this.chBSync1.Checked = false;
			}
			if (this.PD.EndSetSync2 == 1)
			{
				this.chBSync2.Checked = true;
			}
			else
			{
				this.chBSync2.Checked = false;
			}
			if (this.PD.EndValueDigOut1 == 0)
			{
				this.cBDigSig1.SelectedIndex = 0;
			}
			else
			{
				this.cBDigSig1.SelectedIndex = 1;
			}
			if (this.PD.EndValueDigOut2 == 0)
			{
				this.cBDigSig2.SelectedIndex = 0;
			}
			else
			{
				this.cBDigSig2.SelectedIndex = 1;
			}
			if (this.PD.EndValueSync1 == 0)
			{
				this.cBSync1.SelectedIndex = 0;
			}
			else
			{
				this.cBSync1.SelectedIndex = 1;
			}
			if (this.PD.EndValueSync2 == 0)
			{
				this.cBSync2.SelectedIndex = 0;
			}
			else
			{
				this.cBSync2.SelectedIndex = 1;
			}
			this.bInitialize = false;
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			string text = string.Empty;
			if (!this.nEGradientLength.IsOK)
			{
				text = text + this.lbGradientLength.Text + " OutOfRange " + this.nEGradientLength.MinValue.ToString() + " - " + this.nEGradientLength.MaxValue.ToString() + "\n";
			}
			if (!this.nEDepthGradLength.IsOK)
			{
				text = text + this.lbDepthGradLength.Text + " OutOfRange " + this.nEDepthGradLength.MinValue.ToString() + " - " + this.nEDepthGradLength.MaxValue.ToString() + "\n";
			}
			if (!this.nEM1FilterTime.IsOK)
			{
				text = text + this.lbM1FilterTime.Text + " OutOfRange " + this.nEM1FilterTime.MinValue.ToString() + " - " + this.nEM1FilterTime.MaxValue.ToString() + "\n";
			}
			if (!this.nEDepthFilterTime.IsOK)
			{
				text = text + this.lbDepthFilterTime.Text + " OutOfRange " + this.nEDepthFilterTime.MinValue.ToString() + " - " + this.nEDepthFilterTime.MaxValue.ToString() + "\n";
			}
			if (!this.nEPressureHolder.IsOK)
			{
				text = text + this.lbPressureHolder.Text + " OutOfRange " + this.nEPressureHolder.MinValue.ToString() + " - " + this.nEPressureHolder.MaxValue.ToString() + "\n";
			}
			if (this.Main.CheckParamAllowed && text != string.Empty)
			{
				MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + text, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.pnMenu.Enabled = false;
				if (this.chBGradFilter.Checked)
				{
					this.PD.GradientFilter = 1;
				}
				else
				{
					this.PD.GradientFilter = 0;
				}
				this.PD.GradientLength = (ushort)this.nEGradientLength.Value;
				this.PD.ADepthGradientLength = (ushort)this.nEDepthGradLength.Value;
				this.PD.M1FilterTime = this.nEM1FilterTime.Value;
				this.PD.ADepthFilterTime = this.nEDepthFilterTime.Value;
				if (this.PD.PressureHolder != this.nEPressureHolder.Value)
				{
					float value = this.nEPressureHolder.Value - this.PD.PressureHolder;
					DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbHolderForceChangeCylinderForce"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.YesNo);
					if (dialogResult == DialogResult.Yes)
					{
						this.adaptAllCylinderForces(value);
					}
					this.PD.PressureHolder = this.nEPressureHolder.Value;
				}
				if (this.chBDigSig1.Checked)
				{
					this.PD.EndSetDigOut1 = 1;
				}
				else
				{
					this.PD.EndSetDigOut1 = 0;
				}
				if (this.chBDigSig2.Checked)
				{
					this.PD.EndSetDigOut2 = 1;
				}
				else
				{
					this.PD.EndSetDigOut2 = 0;
				}
				if (this.chBSync1.Checked)
				{
					this.PD.EndSetSync1 = 1;
				}
				else
				{
					this.PD.EndSetSync1 = 0;
				}
				if (this.chBSync2.Checked)
				{
					this.PD.EndSetSync2 = 1;
				}
				else
				{
					this.PD.EndSetSync2 = 0;
				}
				if (this.cBDigSig1.SelectedIndex == 0)
				{
					this.PD.EndValueDigOut1 = 0;
				}
				else
				{
					this.PD.EndValueDigOut1 = 1;
				}
				if (this.cBDigSig2.SelectedIndex == 0)
				{
					this.PD.EndValueDigOut2 = 0;
				}
				else
				{
					this.PD.EndValueDigOut2 = 1;
				}
				if (this.cBSync1.SelectedIndex == 0)
				{
					this.PD.EndValueSync1 = 0;
				}
				else
				{
					this.PD.EndValueSync1 = 1;
				}
				if (this.cBSync2.SelectedIndex == 0)
				{
					this.PD.EndValueSync2 = 0;
				}
				else
				{
					this.PD.EndValueSync2 = 1;
				}
				base.Hide();
			}
		}

		private void adaptAllCylinderForces(float value)
		{
			if (value != 0f)
			{
				for (int i = 0; i < this.PD.Info.Steps; i++)
				{
					if (this.PD.Step[i].Type != 1)
					{
						this.PD.Step[i].PressureSpindle += value;
						if (this.PD.Step[i].PressureSpindle > this.Main.VC.SpConst.PressureScaleSpindle * 6f)
						{
							this.PD.Step[i].PressureSpindle = this.Main.VC.SpConst.PressureScaleSpindle * 6f;
						}
						else if (this.PD.Step[i].PressureSpindle < 0f)
						{
							this.PD.Step[i].PressureSpindle = 0f;
						}
						this.Main.ProcessProgram.CompareStepStruct(this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Step[i], this.Main.VC.PProg.Num[this.PNum].Step[i], this.PNum, i, 4);
					}
				}
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_1_1_4_Optionale_Programmparameter";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_1_1_4_Optionale_Programmparameter");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StepOverviewForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void chBSync2_CheckedChanged(object sender, EventArgs e)
		{
			this.settingsChanged(sender, e);
			this.MenEna();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.Main.DeleteLogEntries(2, this.PNum);
			this.bCanceled = true;
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.bInitialize)
			{
				this.Main.SettingsChanged();
			}
		}

		public void KeyArrived()
		{
			base.Hide();
			this.Main.StepOverview1.KeyArrived();
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}
	}
}
