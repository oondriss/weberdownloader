using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class EditDrivingStepForm : Form
	{
		private MainForm Main;

		private WSP1_VarComm.StepStruct SD;

		private int PNum;

		private int SNum;

		private bool IsInitializeMode;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Button btCheckPar;

		private Container components;

		private Button btCancel;

		private Button bt4;

		private Button bt3;

		private GroupBox gBTarget;

		private ComboBox cBTargetDigSignal;

		private NumberEdit1 nETargetValue;

		private Label lbTargetUnit;

		private Label lbTarget;

		private ComboBox cBTargetName;

		private Label lbUnitTplus;

		private NumberEdit1 nETplus;

		private Label lbTplus;

		private GroupBox gBHeader;

		private Label lbProgNum;

		private Label lbProgName;

		private Label lbStepType;

		private Label lbStepNum;

		private GroupBox gBDriveUnit;

		private Label lbUnitRamp;

		private Label lbUnitRpm;

		private NumberEdit1 nERamp;

		private NumberEdit1 nErpm;

		private Label lbRamp;

		private Label lbRpm;

		private Panel pnMRTarget;

		private NumberEdit1 nEMRStep;

		private Label lbMRStep;

		private ComboBox cBMRType;

		private Label lbMRType;

		private Panel pnDigTarget;

		private Panel pnNormalTarget;

		private Label lbUnitMminCheck;

		private NumberEdit1 nEMminCheck;

		private Label lbMminCheck;

		private Label lbUnitMmaxCheck;

		private NumberEdit1 nEMmaxCheck;

		private Label lbMmaxCheck;

		private Panel pnTreshM;

		private Label lbUnitTreshM;

		private NumberEdit1 nETreshM;

		private CheckBox chBTreshM;

		private Panel pnMmax;

		private Panel pnMmin;

		private Label lbCheckTorque;

		private Panel pnMaxTime;

		private GroupBox gBResult;

		private CheckBox chBRes3;

		private CheckBox chBRes2;

		private CheckBox chBRes1;

		private Label lbMDelay;

		private Label lbUnitMDelay;

		private NumberEdit1 nEMDelay;

		private GroupBox gBMDelay;

		private GroupBox gBRights;

		private CheckBox chBCheckRight;

		private CheckBox chBTargetRight;

		private CheckBox chBSetRight;

		private NumberEdit1 nEPressureSpindle;

		private Label lbPressureSpindle;

		private Label lbUnitSpindlePressureKN;

		private Button btNext;

		private Button btPrevious;

		private bool bCanceled;

		public bool WasCanceled
		{
			get
			{
				bool result = this.bCanceled;
				this.bCanceled = false;
				return result;
			}
		}

		public EditDrivingStepForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.PNum = 1;
			this.SNum = 0;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btPrevious = new Button();
			this.btNext = new Button();
			this.btCancel = new Button();
			this.bt4 = new Button();
			this.bt3 = new Button();
			this.btCheckPar = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.gBTarget = new GroupBox();
			this.pnMaxTime = new Panel();
			this.lbTplus = new Label();
			this.lbUnitTplus = new Label();
			this.nETplus = new NumberEdit1();
			this.pnTreshM = new Panel();
			this.chBTreshM = new CheckBox();
			this.lbUnitTreshM = new Label();
			this.nETreshM = new NumberEdit1();
			this.pnMmax = new Panel();
			this.lbMmaxCheck = new Label();
			this.nEMmaxCheck = new NumberEdit1();
			this.lbUnitMmaxCheck = new Label();
			this.lbCheckTorque = new Label();
			this.pnMmin = new Panel();
			this.lbMminCheck = new Label();
			this.nEMminCheck = new NumberEdit1();
			this.lbUnitMminCheck = new Label();
			this.pnNormalTarget = new Panel();
			this.nETargetValue = new NumberEdit1();
			this.lbTargetUnit = new Label();
			this.pnDigTarget = new Panel();
			this.cBTargetDigSignal = new ComboBox();
			this.pnMRTarget = new Panel();
			this.nEMRStep = new NumberEdit1();
			this.lbMRStep = new Label();
			this.cBMRType = new ComboBox();
			this.lbMRType = new Label();
			this.lbTarget = new Label();
			this.cBTargetName = new ComboBox();
			this.gBHeader = new GroupBox();
			this.lbProgNum = new Label();
			this.lbProgName = new Label();
			this.lbStepType = new Label();
			this.lbStepNum = new Label();
			this.gBDriveUnit = new GroupBox();
			this.lbUnitSpindlePressureKN = new Label();
			this.nEPressureSpindle = new NumberEdit1();
			this.lbPressureSpindle = new Label();
			this.lbUnitRamp = new Label();
			this.lbUnitRpm = new Label();
			this.nERamp = new NumberEdit1();
			this.nErpm = new NumberEdit1();
			this.lbRamp = new Label();
			this.lbRpm = new Label();
			this.gBResult = new GroupBox();
			this.chBRes3 = new CheckBox();
			this.chBRes2 = new CheckBox();
			this.chBRes1 = new CheckBox();
			this.lbMDelay = new Label();
			this.lbUnitMDelay = new Label();
			this.nEMDelay = new NumberEdit1();
			this.gBMDelay = new GroupBox();
			this.gBRights = new GroupBox();
			this.chBCheckRight = new CheckBox();
			this.chBTargetRight = new CheckBox();
			this.chBSetRight = new CheckBox();
			this.pnMenu.SuspendLayout();
			this.gBTarget.SuspendLayout();
			this.pnMaxTime.SuspendLayout();
			this.pnTreshM.SuspendLayout();
			this.pnMmax.SuspendLayout();
			this.pnMmin.SuspendLayout();
			this.pnNormalTarget.SuspendLayout();
			this.pnDigTarget.SuspendLayout();
			this.pnMRTarget.SuspendLayout();
			this.gBHeader.SuspendLayout();
			this.gBDriveUnit.SuspendLayout();
			this.gBResult.SuspendLayout();
			this.gBMDelay.SuspendLayout();
			this.gBRights.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btPrevious);
			this.pnMenu.Controls.Add(this.btNext);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.bt4);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.btCheckPar);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btPrevious.Location = new Point(3, 259);
			this.btPrevious.Name = "btPrevious";
			this.btPrevious.Size = new Size(74, 62);
			this.btPrevious.TabIndex = 4;
			this.btPrevious.Text = "Vorherige";
			this.btPrevious.Click += this.btPrevious_Click;
			this.btNext.Location = new Point(3, 195);
			this.btNext.Name = "btNext";
			this.btNext.Size = new Size(74, 62);
			this.btNext.TabIndex = 3;
			this.btNext.Text = "Nächste";
			this.btNext.Click += this.btNext_Click;
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 7;
			this.btCancel.Text = "Abbruch";
			this.btCancel.Click += this.btCancel_Click;
			this.bt4.Enabled = false;
			this.bt4.Location = new Point(3, 387);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(74, 62);
			this.bt4.TabIndex = 6;
			this.bt3.Enabled = false;
			this.bt3.Location = new Point(3, 323);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 5;
			this.btCheckPar.Location = new Point(3, 131);
			this.btCheckPar.Name = "btCheckPar";
			this.btCheckPar.Size = new Size(74, 62);
			this.btCheckPar.TabIndex = 2;
			this.btCheckPar.Text = "Überwachungsparameter";
			this.btCheckPar.Click += this.btCheckPar_Click;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Fertig";
			this.btBack.Click += this.btBack_Click;
			this.gBTarget.Controls.Add(this.pnMaxTime);
			this.gBTarget.Controls.Add(this.pnTreshM);
			this.gBTarget.Controls.Add(this.pnMmax);
			this.gBTarget.Controls.Add(this.pnNormalTarget);
			this.gBTarget.Controls.Add(this.pnDigTarget);
			this.gBTarget.Controls.Add(this.pnMRTarget);
			this.gBTarget.Controls.Add(this.lbTarget);
			this.gBTarget.Controls.Add(this.cBTargetName);
			this.gBTarget.Location = new Point(6, 173);
			this.gBTarget.Name = "gBTarget";
			this.gBTarget.Size = new Size(696, 184);
			this.gBTarget.TabIndex = 3;
			this.gBTarget.TabStop = false;
			this.pnMaxTime.Controls.Add(this.lbTplus);
			this.pnMaxTime.Controls.Add(this.lbUnitTplus);
			this.pnMaxTime.Controls.Add(this.nETplus);
			this.pnMaxTime.Location = new Point(8, 104);
			this.pnMaxTime.Name = "pnMaxTime";
			this.pnMaxTime.Size = new Size(336, 28);
			this.pnMaxTime.TabIndex = 60;
			this.lbTplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTplus.Location = new Point(0, 3);
			this.lbTplus.Name = "lbTplus";
			this.lbTplus.Size = new Size(152, 23);
			this.lbTplus.TabIndex = 43;
			this.lbTplus.Text = "Maximale Zeit";
			this.lbTplus.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitTplus.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitTplus.Location = new Point(272, 3);
			this.lbUnitTplus.Name = "lbUnitTplus";
			this.lbUnitTplus.Size = new Size(56, 23);
			this.lbUnitTplus.TabIndex = 44;
			this.lbUnitTplus.Text = "s";
			this.lbUnitTplus.TextAlign = ContentAlignment.MiddleLeft;
			this.nETplus.BackColor = Color.White;
			this.nETplus.DecimalNum = 2;
			this.nETplus.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETplus.ForeColor = Color.Red;
			this.nETplus.Location = new Point(160, 0);
			this.nETplus.MaxValue = 60f;
			this.nETplus.MinValue = 0.1f;
			this.nETplus.Name = "nETplus";
			this.nETplus.Size = new Size(104, 28);
			this.nETplus.TabIndex = 4;
			this.nETplus.Text = "0,00";
			this.nETplus.TextAlign = HorizontalAlignment.Right;
			this.nETplus.Value = 0f;
			this.nETplus.TextChanged += this.settingsChanged;
			this.nETplus.Enter += this.Start_Input;
			this.nETplus.MouseDown += this.StartInput;
			this.pnTreshM.Controls.Add(this.chBTreshM);
			this.pnTreshM.Controls.Add(this.lbUnitTreshM);
			this.pnTreshM.Controls.Add(this.nETreshM);
			this.pnTreshM.Location = new Point(168, 61);
			this.pnTreshM.Name = "pnTreshM";
			this.pnTreshM.Size = new Size(520, 28);
			this.pnTreshM.TabIndex = 59;
			this.chBTreshM.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBTreshM.Location = new Point(0, 2);
			this.chBTreshM.Name = "chBTreshM";
			this.chBTreshM.Size = new Size(160, 24);
			this.chBTreshM.TabIndex = 109;
			this.chBTreshM.Text = "Schwellm";
			this.chBTreshM.CheckedChanged += this.chBTreshM_CheckedChanged;
			this.chBTreshM.Enter += this.Start_Input;
			this.lbUnitTreshM.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitTreshM.Location = new Point(280, 3);
			this.lbUnitTreshM.Name = "lbUnitTreshM";
			this.lbUnitTreshM.RightToLeft = RightToLeft.No;
			this.lbUnitTreshM.Size = new Size(72, 23);
			this.lbUnitTreshM.TabIndex = 87;
			this.lbUnitTreshM.Text = "Nm";
			this.lbUnitTreshM.TextAlign = ContentAlignment.MiddleLeft;
			this.nETreshM.BackColor = Color.White;
			this.nETreshM.DecimalNum = 2;
			this.nETreshM.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETreshM.ForeColor = SystemColors.ControlText;
			this.nETreshM.Location = new Point(168, 0);
			this.nETreshM.MaxValue = 50000f;
			this.nETreshM.MinValue = -50000f;
			this.nETreshM.Name = "nETreshM";
			this.nETreshM.Size = new Size(104, 28);
			this.nETreshM.TabIndex = 85;
			this.nETreshM.Text = "0,00";
			this.nETreshM.TextAlign = HorizontalAlignment.Right;
			this.nETreshM.Value = 0f;
			this.nETreshM.TextChanged += this.textChanged;
			this.nETreshM.Enter += this.Start_Input;
			this.nETreshM.MouseDown += this.StartInput;
			this.pnMmax.Controls.Add(this.lbMmaxCheck);
			this.pnMmax.Controls.Add(this.nEMmaxCheck);
			this.pnMmax.Controls.Add(this.lbUnitMmaxCheck);
			this.pnMmax.Controls.Add(this.lbCheckTorque);
			this.pnMmax.Controls.Add(this.pnMmin);
			this.pnMmax.Location = new Point(8, 141);
			this.pnMmax.Name = "pnMmax";
			this.pnMmax.Size = new Size(680, 28);
			this.pnMmax.TabIndex = 58;
			this.lbMmaxCheck.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMmaxCheck.Location = new Point(420, 3);
			this.lbMmaxCheck.Name = "lbMmaxCheck";
			this.lbMmaxCheck.Size = new Size(72, 23);
			this.lbMmaxCheck.TabIndex = 53;
			this.lbMmaxCheck.Text = "M+";
			this.lbMmaxCheck.TextAlign = ContentAlignment.MiddleLeft;
			this.nEMmaxCheck.BackColor = Color.White;
			this.nEMmaxCheck.DecimalNum = 2;
			this.nEMmaxCheck.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMmaxCheck.ForeColor = SystemColors.ControlText;
			this.nEMmaxCheck.Location = new Point(500, 0);
			this.nEMmaxCheck.MaxValue = 10f;
			this.nEMmaxCheck.MinValue = 0f;
			this.nEMmaxCheck.Name = "nEMmaxCheck";
			this.nEMmaxCheck.Size = new Size(104, 28);
			this.nEMmaxCheck.TabIndex = 52;
			this.nEMmaxCheck.Text = "0,00";
			this.nEMmaxCheck.TextAlign = HorizontalAlignment.Right;
			this.nEMmaxCheck.Value = 0f;
			this.nEMmaxCheck.TextChanged += this.settingsChanged;
			this.nEMmaxCheck.Enter += this.Start_Input;
			this.nEMmaxCheck.MouseDown += this.StartInput;
			this.lbUnitMmaxCheck.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitMmaxCheck.Location = new Point(612, 3);
			this.lbUnitMmaxCheck.Name = "lbUnitMmaxCheck";
			this.lbUnitMmaxCheck.Size = new Size(56, 23);
			this.lbUnitMmaxCheck.TabIndex = 54;
			this.lbUnitMmaxCheck.Text = "s";
			this.lbUnitMmaxCheck.TextAlign = ContentAlignment.MiddleLeft;
			this.lbCheckTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbCheckTorque.Location = new Point(0, 3);
			this.lbCheckTorque.Name = "lbCheckTorque";
			this.lbCheckTorque.Size = new Size(152, 23);
			this.lbCheckTorque.TabIndex = 61;
			this.lbCheckTorque.Text = "Torque";
			this.lbCheckTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.pnMmin.Controls.Add(this.lbMminCheck);
			this.pnMmin.Controls.Add(this.nEMminCheck);
			this.pnMmin.Controls.Add(this.lbUnitMminCheck);
			this.pnMmin.Location = new Point(160, 0);
			this.pnMmin.Name = "pnMmin";
			this.pnMmin.Size = new Size(260, 28);
			this.pnMmin.TabIndex = 60;
			this.lbMminCheck.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMminCheck.Location = new Point(0, 3);
			this.lbMminCheck.Name = "lbMminCheck";
			this.lbMminCheck.Size = new Size(72, 23);
			this.lbMminCheck.TabIndex = 56;
			this.lbMminCheck.Text = "M-";
			this.lbMminCheck.TextAlign = ContentAlignment.MiddleLeft;
			this.nEMminCheck.BackColor = Color.White;
			this.nEMminCheck.DecimalNum = 2;
			this.nEMminCheck.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMminCheck.ForeColor = SystemColors.ControlText;
			this.nEMminCheck.Location = new Point(80, 0);
			this.nEMminCheck.MaxValue = 10f;
			this.nEMminCheck.MinValue = 0f;
			this.nEMminCheck.Name = "nEMminCheck";
			this.nEMminCheck.Size = new Size(104, 28);
			this.nEMminCheck.TabIndex = 55;
			this.nEMminCheck.Text = "0,00";
			this.nEMminCheck.TextAlign = HorizontalAlignment.Right;
			this.nEMminCheck.Value = 0f;
			this.nEMminCheck.TextChanged += this.settingsChanged;
			this.nEMminCheck.Enter += this.Start_Input;
			this.nEMminCheck.MouseDown += this.StartInput;
			this.lbUnitMminCheck.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitMminCheck.Location = new Point(192, 3);
			this.lbUnitMminCheck.Name = "lbUnitMminCheck";
			this.lbUnitMminCheck.Size = new Size(56, 23);
			this.lbUnitMminCheck.TabIndex = 57;
			this.lbUnitMminCheck.Text = "s";
			this.lbUnitMminCheck.TextAlign = ContentAlignment.MiddleLeft;
			this.pnNormalTarget.Controls.Add(this.nETargetValue);
			this.pnNormalTarget.Controls.Add(this.lbTargetUnit);
			this.pnNormalTarget.Location = new Point(464, 21);
			this.pnNormalTarget.Name = "pnNormalTarget";
			this.pnNormalTarget.Size = new Size(224, 28);
			this.pnNormalTarget.TabIndex = 1;
			this.nETargetValue.BackColor = Color.White;
			this.nETargetValue.DecimalNum = 2;
			this.nETargetValue.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETargetValue.ForeColor = SystemColors.ControlText;
			this.nETargetValue.Location = new Point(0, 0);
			this.nETargetValue.MaxValue = 30000f;
			this.nETargetValue.MinValue = -30000f;
			this.nETargetValue.Name = "nETargetValue";
			this.nETargetValue.Size = new Size(96, 28);
			this.nETargetValue.TabIndex = 0;
			this.nETargetValue.Text = "0,00";
			this.nETargetValue.TextAlign = HorizontalAlignment.Right;
			this.nETargetValue.Value = 0f;
			this.nETargetValue.TextChanged += this.textChanged;
			this.nETargetValue.Enter += this.Start_Input;
			this.nETargetValue.MouseDown += this.StartInput;
			this.lbTargetUnit.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTargetUnit.Location = new Point(104, 3);
			this.lbTargetUnit.Name = "lbTargetUnit";
			this.lbTargetUnit.Size = new Size(104, 23);
			this.lbTargetUnit.TabIndex = 39;
			this.lbTargetUnit.Text = "Einheit";
			this.lbTargetUnit.TextAlign = ContentAlignment.MiddleLeft;
			this.pnDigTarget.Controls.Add(this.cBTargetDigSignal);
			this.pnDigTarget.Location = new Point(464, 21);
			this.pnDigTarget.Name = "pnDigTarget";
			this.pnDigTarget.Size = new Size(224, 28);
			this.pnDigTarget.TabIndex = 2;
			this.cBTargetDigSignal.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBTargetDigSignal.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBTargetDigSignal.Location = new Point(0, 0);
			this.cBTargetDigSignal.MaxDropDownItems = 10;
			this.cBTargetDigSignal.Name = "cBTargetDigSignal";
			this.cBTargetDigSignal.Size = new Size(200, 28);
			this.cBTargetDigSignal.TabIndex = 0;
			this.cBTargetDigSignal.SelectedIndexChanged += this.settingsChanged;
			this.pnMRTarget.Controls.Add(this.nEMRStep);
			this.pnMRTarget.Controls.Add(this.lbMRStep);
			this.pnMRTarget.Controls.Add(this.cBMRType);
			this.pnMRTarget.Controls.Add(this.lbMRType);
			this.pnMRTarget.Location = new Point(168, 61);
			this.pnMRTarget.Name = "pnMRTarget";
			this.pnMRTarget.Size = new Size(520, 28);
			this.pnMRTarget.TabIndex = 3;
			this.nEMRStep.BackColor = Color.White;
			this.nEMRStep.DecimalNum = 0;
			this.nEMRStep.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMRStep.ForeColor = SystemColors.ControlText;
			this.nEMRStep.Location = new Point(400, 0);
			this.nEMRStep.MaxValue = 25f;
			this.nEMRStep.MinValue = 1f;
			this.nEMRStep.Name = "nEMRStep";
			this.nEMRStep.Size = new Size(40, 28);
			this.nEMRStep.TabIndex = 1;
			this.nEMRStep.Text = "1";
			this.nEMRStep.TextAlign = HorizontalAlignment.Right;
			this.nEMRStep.Value = 1f;
			this.nEMRStep.TextChanged += this.settingsChanged;
			this.nEMRStep.Enter += this.Start_Input;
			this.nEMRStep.MouseDown += this.StartInput;
			this.lbMRStep.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMRStep.Location = new Point(312, 3);
			this.lbMRStep.Name = "lbMRStep";
			this.lbMRStep.Size = new Size(80, 23);
			this.lbMRStep.TabIndex = 46;
			this.lbMRStep.Text = "Stufe";
			this.lbMRStep.TextAlign = ContentAlignment.MiddleLeft;
			this.cBMRType.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBMRType.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBMRType.Items.AddRange(new object[3]
			{
				"Moment",
				"gef. M.",
				"max. M."
			});
			this.cBMRType.Location = new Point(120, 0);
			this.cBMRType.MaxDropDownItems = 7;
			this.cBMRType.Name = "cBMRType";
			this.cBMRType.Size = new Size(168, 28);
			this.cBMRType.TabIndex = 0;
			this.cBMRType.SelectedIndexChanged += this.settingsChanged;
			this.lbMRType.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMRType.Location = new Point(0, 3);
			this.lbMRType.Name = "lbMRType";
			this.lbMRType.Size = new Size(120, 23);
			this.lbMRType.TabIndex = 44;
			this.lbMRType.Text = "bezogen auf";
			this.lbMRType.TextAlign = ContentAlignment.MiddleLeft;
			this.lbTarget.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTarget.Location = new Point(8, 24);
			this.lbTarget.Name = "lbTarget";
			this.lbTarget.Size = new Size(152, 23);
			this.lbTarget.TabIndex = 38;
			this.lbTarget.Text = "Zielparameter:";
			this.lbTarget.TextAlign = ContentAlignment.MiddleLeft;
			this.cBTargetName.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBTargetName.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBTargetName.Items.AddRange(new object[14]
			{
				"Moment",
				"gefiltertes Moment",
				"relatives Moment",
				"Gradient",
				"Winkel",
				"Zeit",
				"Analogtiefe",
				"Ext. Analogsignal",
				"Digitalsignal",
				"Moment (von oben)",
				"gefiltertes Moment (von oben)",
				"Gradient (von Oben)",
				"Analogtiefe (von oben)",
				"Ext. Analogsignal (von oben)"
			});
			this.cBTargetName.Location = new Point(168, 21);
			this.cBTargetName.MaxDropDownItems = 17;
			this.cBTargetName.Name = "cBTargetName";
			this.cBTargetName.Size = new Size(288, 28);
			this.cBTargetName.TabIndex = 0;
			this.cBTargetName.SelectedIndexChanged += this.cBTargetName_SelectedIndexChanged;
			this.gBHeader.Controls.Add(this.lbProgNum);
			this.gBHeader.Controls.Add(this.lbProgName);
			this.gBHeader.Controls.Add(this.lbStepType);
			this.gBHeader.Controls.Add(this.lbStepNum);
			this.gBHeader.Location = new Point(6, 8);
			this.gBHeader.Name = "gBHeader";
			this.gBHeader.Size = new Size(696, 64);
			this.gBHeader.TabIndex = 1;
			this.gBHeader.TabStop = false;
			this.lbProgNum.BorderStyle = BorderStyle.Fixed3D;
			this.lbProgNum.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgNum.Location = new Point(8, 24);
			this.lbProgNum.Name = "lbProgNum";
			this.lbProgNum.Size = new Size(95, 23);
			this.lbProgNum.TabIndex = 17;
			this.lbProgNum.Text = "Prog. 1023";
			this.lbProgName.BorderStyle = BorderStyle.Fixed3D;
			this.lbProgName.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgName.Location = new Point(109, 24);
			this.lbProgName.Name = "lbProgName";
			this.lbProgName.Size = new Size(232, 23);
			this.lbProgName.TabIndex = 16;
			this.lbProgName.Text = "Name";
			this.lbStepType.BorderStyle = BorderStyle.Fixed3D;
			this.lbStepType.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbStepType.Location = new Point(472, 24);
			this.lbStepType.Name = "lbStepType";
			this.lbStepType.Size = new Size(192, 23);
			this.lbStepType.TabIndex = 15;
			this.lbStepType.Text = "Typ";
			this.lbStepNum.BorderStyle = BorderStyle.Fixed3D;
			this.lbStepNum.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbStepNum.Location = new Point(392, 24);
			this.lbStepNum.Name = "lbStepNum";
			this.lbStepNum.Size = new Size(72, 23);
			this.lbStepNum.TabIndex = 14;
			this.lbStepNum.Text = "Stufe 25";
			this.gBDriveUnit.Controls.Add(this.lbUnitSpindlePressureKN);
			this.gBDriveUnit.Controls.Add(this.nEPressureSpindle);
			this.gBDriveUnit.Controls.Add(this.lbPressureSpindle);
			this.gBDriveUnit.Controls.Add(this.lbUnitRamp);
			this.gBDriveUnit.Controls.Add(this.lbUnitRpm);
			this.gBDriveUnit.Controls.Add(this.nERamp);
			this.gBDriveUnit.Controls.Add(this.nErpm);
			this.gBDriveUnit.Controls.Add(this.lbRamp);
			this.gBDriveUnit.Controls.Add(this.lbRpm);
			this.gBDriveUnit.Location = new Point(6, 77);
			this.gBDriveUnit.Name = "gBDriveUnit";
			this.gBDriveUnit.Size = new Size(696, 90);
			this.gBDriveUnit.TabIndex = 2;
			this.gBDriveUnit.TabStop = false;
			this.lbUnitSpindlePressureKN.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitSpindlePressureKN.Location = new Point(280, 56);
			this.lbUnitSpindlePressureKN.Name = "lbUnitSpindlePressureKN";
			this.lbUnitSpindlePressureKN.Size = new Size(56, 23);
			this.lbUnitSpindlePressureKN.TabIndex = 50;
			this.lbUnitSpindlePressureKN.Text = "kN";
			this.lbUnitSpindlePressureKN.TextAlign = ContentAlignment.MiddleLeft;
			this.nEPressureSpindle.BackColor = Color.White;
			this.nEPressureSpindle.DecimalNum = 2;
			this.nEPressureSpindle.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEPressureSpindle.ForeColor = SystemColors.ControlText;
			this.nEPressureSpindle.Location = new Point(168, 54);
			this.nEPressureSpindle.MaxValue = 10000f;
			this.nEPressureSpindle.MinValue = 0f;
			this.nEPressureSpindle.Name = "nEPressureSpindle";
			this.nEPressureSpindle.Size = new Size(104, 28);
			this.nEPressureSpindle.TabIndex = 48;
			this.nEPressureSpindle.Text = "0,00";
			this.nEPressureSpindle.TextAlign = HorizontalAlignment.Right;
			this.nEPressureSpindle.Value = 0f;
			this.nEPressureSpindle.TextChanged += this.textChanged;
			this.nEPressureSpindle.Enter += this.Start_Input;
			this.nEPressureSpindle.MouseDown += this.StartInput;
			this.lbPressureSpindle.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbPressureSpindle.Location = new Point(8, 57);
			this.lbPressureSpindle.Name = "lbPressureSpindle";
			this.lbPressureSpindle.Size = new Size(152, 23);
			this.lbPressureSpindle.TabIndex = 49;
			this.lbPressureSpindle.Text = "Spindeldruck";
			this.lbPressureSpindle.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitRamp.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitRamp.Location = new Point(632, 24);
			this.lbUnitRamp.Name = "lbUnitRamp";
			this.lbUnitRamp.Size = new Size(56, 23);
			this.lbUnitRamp.TabIndex = 47;
			this.lbUnitRamp.Text = "s";
			this.lbUnitRamp.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitRpm.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitRpm.Location = new Point(280, 24);
			this.lbUnitRpm.Name = "lbUnitRpm";
			this.lbUnitRpm.Size = new Size(56, 23);
			this.lbUnitRpm.TabIndex = 46;
			this.lbUnitRpm.Text = "U/min";
			this.lbUnitRpm.TextAlign = ContentAlignment.MiddleLeft;
			this.nERamp.BackColor = Color.White;
			this.nERamp.DecimalNum = 2;
			this.nERamp.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nERamp.ForeColor = SystemColors.ControlText;
			this.nERamp.Location = new Point(520, 21);
			this.nERamp.MaxValue = 10f;
			this.nERamp.MinValue = 0f;
			this.nERamp.Name = "nERamp";
			this.nERamp.Size = new Size(104, 28);
			this.nERamp.TabIndex = 1;
			this.nERamp.Text = "0,00";
			this.nERamp.TextAlign = HorizontalAlignment.Right;
			this.nERamp.Value = 0f;
			this.nERamp.TextChanged += this.textChanged;
			this.nERamp.Enter += this.Start_Input;
			this.nERamp.MouseDown += this.StartInput;
			this.nErpm.BackColor = Color.White;
			this.nErpm.DecimalNum = 0;
			this.nErpm.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nErpm.ForeColor = SystemColors.ControlText;
			this.nErpm.Location = new Point(168, 21);
			this.nErpm.MaxValue = 10000f;
			this.nErpm.MinValue = -10000f;
			this.nErpm.Name = "nErpm";
			this.nErpm.Size = new Size(104, 28);
			this.nErpm.TabIndex = 0;
			this.nErpm.Text = "0";
			this.nErpm.TextAlign = HorizontalAlignment.Right;
			this.nErpm.Value = 0f;
			this.nErpm.TextChanged += this.textChanged;
			this.nErpm.Enter += this.Start_Input;
			this.nErpm.MouseDown += this.StartInput;
			this.lbRamp.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbRamp.Location = new Point(360, 24);
			this.lbRamp.Name = "lbRamp";
			this.lbRamp.Size = new Size(152, 23);
			this.lbRamp.TabIndex = 45;
			this.lbRamp.Text = "Rampe:";
			this.lbRamp.TextAlign = ContentAlignment.MiddleLeft;
			this.lbRpm.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbRpm.Location = new Point(8, 24);
			this.lbRpm.Name = "lbRpm";
			this.lbRpm.Size = new Size(152, 23);
			this.lbRpm.TabIndex = 44;
			this.lbRpm.Text = "Drehzahl:";
			this.lbRpm.TextAlign = ContentAlignment.MiddleLeft;
			this.gBResult.Controls.Add(this.chBRes3);
			this.gBResult.Controls.Add(this.chBRes2);
			this.gBResult.Controls.Add(this.chBRes1);
			this.gBResult.Location = new Point(6, 365);
			this.gBResult.Name = "gBResult";
			this.gBResult.Size = new Size(174, 120);
			this.gBResult.TabIndex = 7;
			this.gBResult.TabStop = false;
			this.gBResult.Text = "Auswertung";
			this.chBRes3.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBRes3.Location = new Point(16, 88);
			this.chBRes3.Name = "chBRes3";
			this.chBRes3.Size = new Size(144, 24);
			this.chBRes3.TabIndex = 111;
			this.chBRes3.Text = "Ergebnis 3";
			this.chBRes3.CheckedChanged += this.settingsChanged;
			this.chBRes2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBRes2.Location = new Point(16, 56);
			this.chBRes2.Name = "chBRes2";
			this.chBRes2.Size = new Size(144, 24);
			this.chBRes2.TabIndex = 110;
			this.chBRes2.Text = "Ergebnis 2";
			this.chBRes2.CheckedChanged += this.settingsChanged;
			this.chBRes1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBRes1.Location = new Point(16, 24);
			this.chBRes1.Name = "chBRes1";
			this.chBRes1.Size = new Size(144, 24);
			this.chBRes1.TabIndex = 109;
			this.chBRes1.Text = "Ergebnis 1";
			this.chBRes1.CheckedChanged += this.settingsChanged;
			this.lbMDelay.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMDelay.Location = new Point(8, 24);
			this.lbMDelay.Name = "lbMDelay";
			this.lbMDelay.Size = new Size(161, 40);
			this.lbMDelay.TabIndex = 46;
			this.lbMDelay.Text = "Verzögerungszeit für Bezugsmoment";
			this.lbMDelay.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitMDelay.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitMDelay.Location = new Point(254, 33);
			this.lbUnitMDelay.Name = "lbUnitMDelay";
			this.lbUnitMDelay.Size = new Size(33, 23);
			this.lbUnitMDelay.TabIndex = 47;
			this.lbUnitMDelay.Text = "ms";
			this.lbUnitMDelay.TextAlign = ContentAlignment.MiddleLeft;
			this.nEMDelay.BackColor = Color.White;
			this.nEMDelay.DecimalNum = 0;
			this.nEMDelay.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMDelay.ForeColor = SystemColors.ControlText;
			this.nEMDelay.Location = new Point(176, 30);
			this.nEMDelay.MaxValue = 500f;
			this.nEMDelay.MinValue = 0f;
			this.nEMDelay.Name = "nEMDelay";
			this.nEMDelay.Size = new Size(72, 28);
			this.nEMDelay.TabIndex = 45;
			this.nEMDelay.Text = "0";
			this.nEMDelay.TextAlign = HorizontalAlignment.Right;
			this.nEMDelay.Value = 0f;
			this.nEMDelay.TextChanged += this.settingsChanged;
			this.nEMDelay.Enter += this.Start_Input;
			this.nEMDelay.MouseDown += this.StartInput;
			this.gBMDelay.Controls.Add(this.nEMDelay);
			this.gBMDelay.Controls.Add(this.lbUnitMDelay);
			this.gBMDelay.Controls.Add(this.lbMDelay);
			this.gBMDelay.Location = new Point(186, 365);
			this.gBMDelay.Name = "gBMDelay";
			this.gBMDelay.Size = new Size(303, 72);
			this.gBMDelay.TabIndex = 48;
			this.gBMDelay.TabStop = false;
			this.gBRights.Controls.Add(this.chBCheckRight);
			this.gBRights.Controls.Add(this.chBTargetRight);
			this.gBRights.Controls.Add(this.chBSetRight);
			this.gBRights.Location = new Point(495, 365);
			this.gBRights.Name = "gBRights";
			this.gBRights.Size = new Size(207, 120);
			this.gBRights.TabIndex = 49;
			this.gBRights.TabStop = false;
			this.gBRights.Text = "Berechtigung Bediener";
			this.chBCheckRight.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBCheckRight.Location = new Point(16, 88);
			this.chBCheckRight.Name = "chBCheckRight";
			this.chBCheckRight.Size = new Size(185, 24);
			this.chBCheckRight.TabIndex = 111;
			this.chBCheckRight.Text = "Überwachung";
			this.chBCheckRight.CheckedChanged += this.settingsChanged;
			this.chBTargetRight.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBTargetRight.Location = new Point(16, 56);
			this.chBTargetRight.Name = "chBTargetRight";
			this.chBTargetRight.Size = new Size(185, 24);
			this.chBTargetRight.TabIndex = 110;
			this.chBTargetRight.Text = "Zielwerte";
			this.chBTargetRight.CheckedChanged += this.settingsChanged;
			this.chBSetRight.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBSetRight.Location = new Point(16, 24);
			this.chBSetRight.Name = "chBSetRight";
			this.chBSetRight.Size = new Size(185, 24);
			this.chBSetRight.TabIndex = 109;
			this.chBSetRight.Text = "Sollwerte";
			this.chBSetRight.CheckedChanged += this.settingsChanged;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.gBRights);
			base.Controls.Add(this.gBMDelay);
			base.Controls.Add(this.gBResult);
			base.Controls.Add(this.gBDriveUnit);
			base.Controls.Add(this.gBHeader);
			base.Controls.Add(this.gBTarget);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "EditDrivingStepForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen/Programme/Stufen/Stufe bearbeiten";
			base.Activated += this.EditDrivingStepForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBTarget.ResumeLayout(false);
			this.pnMaxTime.ResumeLayout(false);
			this.pnMaxTime.PerformLayout();
			this.pnTreshM.ResumeLayout(false);
			this.pnTreshM.PerformLayout();
			this.pnMmax.ResumeLayout(false);
			this.pnMmax.PerformLayout();
			this.pnMmin.ResumeLayout(false);
			this.pnMmin.PerformLayout();
			this.pnNormalTarget.ResumeLayout(false);
			this.pnNormalTarget.PerformLayout();
			this.pnDigTarget.ResumeLayout(false);
			this.pnMRTarget.ResumeLayout(false);
			this.pnMRTarget.PerformLayout();
			this.gBHeader.ResumeLayout(false);
			this.gBDriveUnit.ResumeLayout(false);
			this.gBDriveUnit.PerformLayout();
			this.gBResult.ResumeLayout(false);
			this.gBMDelay.ResumeLayout(false);
			this.gBMDelay.PerformLayout();
			this.gBRights.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public bool ShowWindow(int progNum, int stepNum)
		{
			if (stepNum >= 0 && stepNum < 25)
			{
				this.Main.ResetBrowserGrantedBy();
				this.IsInitializeMode = true;
				this.SNum = stepNum;
				this.PNum = progNum;
				this.SD = this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Step[this.SNum];
				this.SetLanguageTexts();
				this.InitializeValues();
				this.MenEna();
				base.Show();
				this.IsInitializeMode = false;
				return true;
			}
			return false;
		}

		public void SetLanguageTexts()
		{
			bool isInitializeMode = this.IsInitializeMode;
			this.IsInitializeMode = true;
			string[] array = new string[17];
			string[] array2 = new string[10];
			string[] array3 = new string[4];
			array[0] = this.Main.Rm.GetString("Torque") + string.Empty;
			array[1] = this.Main.Rm.GetString("FilteredTorque") + string.Empty;
			array[2] = this.Main.Rm.GetString("RelativeTorque") + string.Empty;
			array[3] = this.Main.Rm.GetString("M360Follow") + string.Empty;
			array[4] = this.Main.Rm.GetString("Gradient") + string.Empty;
			array[5] = this.Main.Rm.GetString("Angle") + string.Empty;
			array[6] = this.Main.Rm.GetString("Time") + string.Empty;
			array[7] = this.Main.Rm.GetString("AnaDepth") + string.Empty;
			array[8] = this.Main.Rm.GetString("DepthGrad") + string.Empty;
			array[9] = this.Main.Rm.GetString("AnaSignal") + string.Empty;
			array[10] = this.Main.Rm.GetString("DigitalSignal") + string.Empty;
			array[11] = this.Main.Rm.GetString("Torque") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
			array[12] = this.Main.Rm.GetString("FilteredTorque") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
			array[13] = this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
			array[14] = this.Main.Rm.GetString("AnaDepth") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
			array[15] = this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
			array[16] = this.Main.Rm.GetString("AnaSignal") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
			array2[0] = this.Main.Rm.GetString("TM1") + " (" + this.Main.Rm.GetString("Positive") + ")";
			array2[1] = this.Main.Rm.GetString("TM1") + " (" + this.Main.Rm.GetString("Negative") + ")";
			array2[2] = this.Main.Rm.GetString("TM2") + " (" + this.Main.Rm.GetString("Positive") + ")";
			array2[3] = this.Main.Rm.GetString("TM2") + " (" + this.Main.Rm.GetString("Negative") + ")";
			array2[4] = this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("Positive") + ")";
			array2[5] = this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("Negative") + ")";
			array2[6] = this.Main.Rm.GetString("JawOpen") + " (" + this.Main.Rm.GetString("Positive") + ")";
			array2[7] = this.Main.Rm.GetString("JawOpen") + " (" + this.Main.Rm.GetString("Negative") + ")";
			array2[8] = this.Main.Rm.GetString("SyncSignal") + "2 (" + this.Main.Rm.GetString("Positive") + ")";
			array2[9] = this.Main.Rm.GetString("SyncSignal") + "2 (" + this.Main.Rm.GetString("Negative") + ")";
			array3[0] = this.Main.Rm.GetString("Torque") + string.Empty;
			array3[1] = this.Main.Rm.GetString("FilteredTorque") + string.Empty;
			array3[2] = this.Main.Rm.GetString("MaxTorque") + string.Empty;
			array3[3] = this.Main.Rm.GetString("DelayTorque") + string.Empty;
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MProgramOverview") + "/" + this.Main.Rm.GetString("MStepOverview") + "/" + this.Main.Rm.GetString("MEditStep");
			this.btBack.Text = this.Main.Rm.GetString("Done");
			this.btCheckPar.Text = this.Main.Rm.GetString("CheckParameter");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btCancel.Text = this.Main.Rm.GetString("btCancel");
			this.btNext.Text = this.Main.Rm.GetString("btNext");
			this.btPrevious.Text = this.Main.Rm.GetString("btPrevious");
			this.lbRamp.Text = this.Main.Rm.GetString("Ramp");
			this.lbRpm.Text = this.Main.Rm.GetString("RoundsPerMinute");
			this.lbUnitRpm.Text = this.Main.Rm.GetString("RpmUnit");
			this.lbTarget.Text = this.Main.Rm.GetString("Target");
			this.lbTplus.Text = this.Main.Rm.GetString("StepTplus");
			this.lbUnitRamp.Text = this.Main.Rm.GetString("Second");
			this.lbUnitTplus.Text = this.Main.Rm.GetString("Second");
			this.lbMRStep.Text = this.Main.Rm.GetString("OfStep");
			this.lbMRType.Text = this.Main.Rm.GetString("relatedTo");
			this.lbCheckTorque.Text = this.Main.Rm.GetString("Torque");
			this.lbMminCheck.Text = this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("M-") + ")";
			this.lbMmaxCheck.Text = this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("M+") + ")";
			this.lbMDelay.Text = this.Main.Rm.GetString("MDelay");
			this.lbUnitMDelay.Text = this.Main.Rm.GetString("Milisecond");
			this.chBTreshM.Text = this.Main.Rm.GetString("TreshTorque");
			this.cBTargetName.Items.Clear();
			this.cBTargetName.Items.AddRange(array);
			this.cBTargetDigSignal.Items.Clear();
			this.cBTargetDigSignal.Items.AddRange(array2);
			this.cBTargetDigSignal.SelectedIndex = 0;
			this.cBMRType.Items.Clear();
			this.cBMRType.Items.AddRange(array3);
			this.cBMRType.SelectedIndex = 0;
			this.gBResult.Text = this.Main.Rm.GetString("gBResultDisplay");
			this.chBRes1.Text = this.Main.Rm.GetString("Result") + " 1";
			this.chBRes2.Text = this.Main.Rm.GetString("Result") + " 2";
			this.chBRes3.Text = this.Main.Rm.GetString("Result") + " 3";
			this.chBCheckRight.Text = this.Main.Rm.GetString("CheckRight");
			this.chBSetRight.Text = this.Main.Rm.GetString("SetRight");
			this.chBTargetRight.Text = this.Main.Rm.GetString("TargetRight");
			this.gBRights.Text = this.Main.Rm.GetString("UserRights");
			this.lbPressureSpindle.Text = this.Main.Rm.GetString("PressureCylinder");
			this.lbUnitSpindlePressureKN.Text = this.Main.Rm.GetString("KiloNewton");
			this.IsInitializeMode = isInitializeMode;
		}

		private void MenEna()
		{
			if ((this.SD.UserRights & 1) == 1 && this.Main.PassCodeLevel > 0)
			{
				goto IL_0035;
			}
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_EditSteps)
			{
				goto IL_0035;
			}
			bool flag = false;
			goto IL_003b;
			IL_0070:
			bool enabled = true;
			goto IL_0076;
			IL_0076:
			if ((this.SD.UserRights & 4) == 4 && this.Main.PassCodeLevel > 0)
			{
				goto IL_00ab;
			}
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_EditSteps)
			{
				goto IL_00ab;
			}
			bool enabled2 = false;
			goto IL_00b1;
			IL_0035:
			flag = true;
			goto IL_003b;
			IL_00ab:
			enabled2 = true;
			goto IL_00b1;
			IL_003b:
			if ((this.SD.UserRights & 2) == 2 && this.Main.PassCodeLevel > 0)
			{
				goto IL_0070;
			}
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_EditSteps)
			{
				goto IL_0070;
			}
			enabled = false;
			goto IL_0076;
			IL_00b1:
			bool enabled3 = false;
			bool enabled4 = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_EditSteps)
			{
				enabled4 = true;
			}
			if (this.Main.PassCodeLevel >= 1)
			{
				enabled3 = true;
			}
			if (this.Main.ViewOnlyMode)
			{
				enabled3 = false;
				enabled4 = false;
				flag = false;
				enabled = false;
				enabled2 = false;
			}
			if (this.Main.IsOfflineVersion)
			{
				enabled3 = true;
				enabled4 = true;
				flag = true;
				enabled = true;
				enabled2 = true;
			}
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_EditSteps, this.Main.ViewOnlyMode);
			this.cBTargetName.Enabled = enabled4;
			this.nETplus.Enabled = enabled2;
			this.nErpm.Enabled = enabled;
			this.nERamp.Enabled = enabled;
			this.nEPressureSpindle.Enabled = enabled;
			this.nETargetValue.Enabled = flag;
			this.cBTargetDigSignal.Enabled = flag;
			this.cBMRType.Enabled = enabled4;
			this.nEMRStep.Enabled = enabled4;
			this.nEMmaxCheck.Enabled = enabled2;
			this.nEMminCheck.Enabled = enabled2;
			this.nETreshM.Enabled = (flag && this.chBTreshM.Checked);
			this.nEMDelay.Enabled = flag;
			this.chBTreshM.Enabled = enabled4;
			this.chBRes1.Enabled = enabled4;
			this.chBRes2.Enabled = enabled4;
			this.chBRes3.Enabled = enabled4;
			this.chBCheckRight.Enabled = enabled4;
			this.chBSetRight.Enabled = enabled4;
			this.chBTargetRight.Enabled = enabled4;
			this.btBack.Enabled = enabled3;
			this.nETplus.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nErpm.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nERamp.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEPressureSpindle.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nETargetValue.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMRStep.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMmaxCheck.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMminCheck.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nETreshM.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMDelay.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			if (this.SNum == 0)
			{
				this.btPrevious.Enabled = false;
			}
			else
			{
				this.btPrevious.Enabled = true;
			}
			if (this.SNum >= this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Info.Steps - 1)
			{
				this.btNext.Enabled = false;
			}
			else
			{
				this.btNext.Enabled = true;
			}
		}

		private bool ApplyValues()
		{
			string text = string.Empty;
			if (!this.nErpm.IsOK)
			{
				text = text + this.lbRpm.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nErpm.MinValue.ToString() + " - " + this.nErpm.MaxValue.ToString() + "\n";
			}
			if (this.nERamp.Value < this.nERamp.MinValue || this.nERamp.Value > this.nERamp.MaxValue)
			{
				text = text + this.lbRamp.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nERamp.MinValue.ToString() + " - " + this.nERamp.MaxValue.ToString() + "\n";
			}
			if (!this.nEPressureSpindle.IsOK)
			{
				text = text + this.lbPressureSpindle.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEPressureSpindle.MinValue.ToString() + " - " + this.nEPressureSpindle.MaxValue.ToString() + "\n";
			}
			if (!this.nETargetValue.IsOK)
			{
				text = text + this.Main.Rm.GetString("Target") + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nETargetValue.MinValue.ToString() + " - " + this.nETargetValue.MaxValue.ToString() + "\n";
			}
			if (this.cBTargetName.SelectedIndex == 2 && !this.nEMRStep.IsOK)
			{
				text = text + this.Main.Rm.GetString("RelTorqueStep") + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMRStep.MinValue.ToString() + " - " + this.nEMRStep.MaxValue.ToString() + "\n";
			}
			if (this.cBTargetName.SelectedIndex == 4 && !this.nETreshM.IsOK)
			{
				text = text + this.chBTreshM.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nETreshM.MinValue.ToString() + " - " + this.nETreshM.MaxValue.ToString() + "\n";
			}
			if (!this.nETplus.IsOK)
			{
				text = text + this.lbTplus.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nETplus.MinValue.ToString() + " - " + this.nETplus.MaxValue.ToString() + "\n";
			}
			if ((this.cBTargetName.SelectedIndex == 2 || this.cBTargetName.SelectedIndex == 9 || this.cBTargetName.SelectedIndex == 10 || this.cBTargetName.SelectedIndex == 11) && !this.nEMmaxCheck.IsOK)
			{
				text = text + this.lbMmaxCheck.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMmaxCheck.MinValue.ToString() + " - " + this.nEMmaxCheck.MaxValue.ToString() + "\n";
			}
			if ((this.cBTargetName.SelectedIndex == 2 || this.cBTargetName.SelectedIndex == 11) && !this.nEMminCheck.IsOK)
			{
				text = text + this.lbMminCheck.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMminCheck.MinValue.ToString() + " - " + this.nEMminCheck.MaxValue.ToString() + "\n";
			}
			if ((this.cBTargetName.SelectedIndex == 2 || this.cBTargetName.SelectedIndex == 11) && this.nErpm.Value > 0f && this.nEMminCheck.Value > this.nEMmaxCheck.Value)
			{
				text = text + this.lbMmaxCheck.Text + " " + this.Main.Rm.GetString("PosOverload") + " " + this.lbMminCheck.Text + "\n";
			}
			if ((this.cBTargetName.SelectedIndex == 2 || this.cBTargetName.SelectedIndex == 11) && this.nErpm.Value < 0f && this.nEMminCheck.Value < this.nEMmaxCheck.Value)
			{
				text = text + this.lbMmaxCheck.Text + " " + this.Main.Rm.GetString("NegOverload") + " " + this.lbMminCheck.Text + "\n";
			}
			if (!this.nEMDelay.IsOK)
			{
				text = text + this.lbMDelay.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMDelay.MinValue.ToString() + " - " + this.nEMDelay.MaxValue.ToString() + "\n";
			}
			if (this.Main.CheckParamAllowed && text != string.Empty)
			{
				MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + text, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.SD.NA = this.nErpm.Value;
			this.SD.PressureSpindle = this.nEPressureSpindle.Value;
			this.SD.TM = this.nERamp.Value;
			this.SD.Tmax = this.nETplus.Value;
			this.SD.MDelayTime = this.nEMDelay.Value;
			this.SD.Enable.Release = 0;
			if (this.chBRes1.Checked)
			{
				this.SD.IsResult1 = 1;
			}
			else
			{
				this.SD.IsResult1 = 0;
			}
			if (this.chBRes2.Checked)
			{
				this.SD.IsResult2 = 1;
			}
			else
			{
				this.SD.IsResult2 = 0;
			}
			if (this.chBRes3.Checked)
			{
				this.SD.IsResult3 = 1;
			}
			else
			{
				this.SD.IsResult3 = 0;
			}
			byte b = 0;
			if (this.chBTargetRight.Checked)
			{
				b = (byte)(b + 1);
			}
			if (this.chBSetRight.Checked)
			{
				b = (byte)(b + 2);
			}
			if (this.chBCheckRight.Checked)
			{
				b = (byte)(b + 4);
			}
			this.SD.UserRights = b;
			switch (this.cBTargetName.SelectedIndex)
			{
			case 0:
				this.SD.Switch = 1;
				this.SD.MP = this.nETargetValue.Value / this.Main.TorqueConvert;
				break;
			case 1:
				this.SD.Switch = 3;
				this.SD.MFP = this.nETargetValue.Value / this.Main.TorqueConvert;
				break;
			case 2:
				this.SD.Switch = 2;
				this.SD.MRP = this.nETargetValue.Value / this.Main.TorqueConvert;
				switch (this.cBMRType.SelectedIndex)
				{
				case 0:
					this.SD.MRType = 1;
					break;
				case 1:
					this.SD.MRType = 3;
					break;
				case 2:
					this.SD.MRType = 2;
					break;
				case 3:
					this.SD.MRType = 10;
					break;
				default:
					MessageBox.Show("Wrong selected index 2 in ApplyValues() of EditDrivingStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					this.SD.MRType = 1;
					break;
				}
				this.SD.MRStep = (byte)(this.nEMRStep.Value - 1f);
				this.SD.Enable.Torque = 1;
				this.SD.Mmax = this.nEMmaxCheck.Value / this.Main.TorqueConvert;
				this.SD.Mmin = this.nEMminCheck.Value / this.Main.TorqueConvert;
				break;
			case 3:
				this.SD.Switch = 11;
				this.SD.MRP = this.nETargetValue.Value / this.Main.TorqueConvert;
				this.SD.Enable.Torque = 1;
				this.SD.Mmax = this.nEMmaxCheck.Value / this.Main.TorqueConvert;
				this.SD.Mmin = this.nEMminCheck.Value / this.Main.TorqueConvert;
				break;
			case 4:
				this.SD.Switch = 4;
				this.SD.MGP = this.nETargetValue.Value / this.Main.TorqueConvert;
				break;
			case 5:
				this.SD.Switch = 5;
				this.SD.WP = this.nETargetValue.Value;
				if (this.chBTreshM.Checked)
				{
					this.SD.Enable.Snug = 1;
					this.SD.MS = this.nETreshM.Value / this.Main.TorqueConvert;
				}
				else
				{
					this.SD.Enable.Snug = 0;
				}
				break;
			case 6:
				this.SD.Switch = 6;
				this.SD.TP = this.nETargetValue.Value;
				break;
			case 7:
				this.SD.Switch = 7;
				this.SD.LP = this.nETargetValue.Value;
				break;
			case 8:
				this.SD.Switch = 10;
				this.SD.LGP = this.nETargetValue.Value;
				break;
			case 9:
				this.SD.Switch = 8;
				this.SD.AnaP = this.nETargetValue.Value;
				break;
			case 10:
				this.SD.Switch = 9;
				if (this.cBTargetDigSignal.SelectedIndex % 2 == 0)
				{
					this.SD.DigP = (sbyte)(this.cBTargetDigSignal.SelectedIndex / 2 + 1);
				}
				else
				{
					this.SD.DigP = (sbyte)((this.cBTargetDigSignal.SelectedIndex + 1) / -2);
				}
				break;
			case 11:
				this.SD.Switch = 50;
				this.SD.MP = this.nETargetValue.Value / this.Main.TorqueConvert;
				this.SD.Mmax = this.nEMmaxCheck.Value / this.Main.TorqueConvert;
				this.SD.Enable.Torque = 1;
				break;
			case 12:
				this.SD.Switch = 51;
				this.SD.MFP = this.nETargetValue.Value / this.Main.TorqueConvert;
				this.SD.Mmax = this.nEMmaxCheck.Value / this.Main.TorqueConvert;
				this.SD.Enable.Torque = 1;
				break;
			case 13:
				this.SD.Switch = 52;
				this.SD.MGP = this.nETargetValue.Value / this.Main.TorqueConvert;
				this.SD.Mmax = this.nEMmaxCheck.Value / this.Main.TorqueConvert;
				this.SD.Mmin = this.nEMminCheck.Value / this.Main.TorqueConvert;
				this.SD.Enable.Torque = 1;
				break;
			case 14:
				this.SD.Switch = 53;
				this.SD.LP = this.nETargetValue.Value;
				break;
			case 15:
				this.SD.Switch = 55;
				this.SD.LGP = this.nETargetValue.Value;
				break;
			case 16:
				this.SD.Switch = 54;
				this.SD.AnaP = this.nETargetValue.Value;
				break;
			default:
				MessageBox.Show("Wrong selected index 1 in ApplyValues() of EditDrivingStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				break;
			}
			return true;
		}

		private void InitializeValues()
		{
			this.IsInitializeMode = true;
			this.lbUnitTreshM.Text = this.Main.TorqueUnitName;
			this.lbUnitMmaxCheck.Text = this.Main.TorqueUnitName;
			this.lbUnitMminCheck.Text = this.Main.TorqueUnitName;
			this.nErpm.MaxValue = this.Main.VC.SpConst.DriveUnitRpm / this.Main.VC.SpConst.SpindleGearFactor;
			this.nErpm.MinValue = -1f * this.Main.VC.SpConst.DriveUnitRpm / this.Main.VC.SpConst.SpindleGearFactor;
			this.nERamp.MaxValue = 60f;
			this.nEPressureSpindle.MaxValue = this.Main.VC.SpConst.PressureScaleSpindle * 6f;
			this.nEPressureSpindle.MinValue = 0f;
			this.nEMRStep.MaxValue = (float)(int)this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Info.Steps;
			this.nETplus.MaxValue = 60f;
			this.nEMmaxCheck.MaxValue = this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMmaxCheck.MinValue = (0f - this.Main.TorqueConvert) * this.Main.VC.SpConst.SpindleTorque;
			this.nEMminCheck.MaxValue = this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nEMminCheck.MinValue = (0f - this.Main.TorqueConvert) * this.Main.VC.SpConst.SpindleTorque;
			this.nETreshM.MaxValue = this.Main.TorqueConvert * this.Main.VC.SpConst.SpindleTorque;
			this.nETreshM.MinValue = (0f - this.Main.TorqueConvert) * this.Main.VC.SpConst.SpindleTorque;
			this.nERamp.DecimalNum = 2;
			this.nEPressureSpindle.DecimalNum = 2;
			this.nETplus.DecimalNum = 2;
			this.nEMmaxCheck.DecimalNum = 2;
			this.nEMminCheck.DecimalNum = 2;
			this.nETreshM.DecimalNum = 2;
			this.lbProgNum.Text = this.Main.Rm.GetString("Abr_Program") + " " + this.PNum.ToString();
			this.lbProgName.Text = this.Main.CommonFunctions.UShortToString(this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Info.Name);
			this.lbStepNum.Text = this.Main.Rm.GetString("Step") + " " + (this.SNum + 1).ToString();
			this.lbStepType.Text = this.Main.Rm.GetString("DrivingStep");
			switch (this.SD.Switch)
			{
			case 0:
				this.cBTargetName.SelectedIndex = 0;
				break;
			case 1:
				this.cBTargetName.SelectedIndex = 0;
				break;
			case 3:
				this.cBTargetName.SelectedIndex = 1;
				break;
			case 2:
				this.cBTargetName.SelectedIndex = 2;
				break;
			case 11:
				this.cBTargetName.SelectedIndex = 3;
				break;
			case 4:
				this.cBTargetName.SelectedIndex = 4;
				break;
			case 5:
				this.cBTargetName.SelectedIndex = 5;
				break;
			case 6:
				this.cBTargetName.SelectedIndex = 6;
				break;
			case 7:
				this.cBTargetName.SelectedIndex = 7;
				break;
			case 10:
				this.cBTargetName.SelectedIndex = 8;
				break;
			case 8:
				this.cBTargetName.SelectedIndex = 9;
				break;
			case 9:
				this.cBTargetName.SelectedIndex = 10;
				break;
			case 50:
				this.cBTargetName.SelectedIndex = 11;
				break;
			case 51:
				this.cBTargetName.SelectedIndex = 12;
				break;
			case 52:
				this.cBTargetName.SelectedIndex = 13;
				break;
			case 53:
				this.cBTargetName.SelectedIndex = 14;
				break;
			case 55:
				this.cBTargetName.SelectedIndex = 15;
				break;
			case 54:
				this.cBTargetName.SelectedIndex = 16;
				break;
			default:
				MessageBox.Show("Wrong switch type in InitializeValues() of EditDrivingStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.cBTargetName.SelectedIndex = 0;
				break;
			}
			this.SetTargetParameter();
			switch (this.SD.MRType)
			{
			case 0:
				this.cBMRType.SelectedIndex = 0;
				break;
			case 1:
				this.cBMRType.SelectedIndex = 0;
				break;
			case 3:
				this.cBMRType.SelectedIndex = 1;
				break;
			case 2:
				this.cBMRType.SelectedIndex = 2;
				break;
			case 10:
				this.cBMRType.SelectedIndex = 3;
				break;
			default:
				MessageBox.Show("Wrong relative type in InitializeValues() of EditDrivingStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.cBMRType.SelectedIndex = 0;
				break;
			}
			this.nEMRStep.Value = (float)(int)this.SD.MRStep + 1f;
			this.nErpm.Value = this.SD.NA;
			this.nERamp.Value = this.SD.TM;
			this.nEPressureSpindle.Value = this.SD.PressureSpindle;
			this.nEMDelay.Value = this.SD.MDelayTime;
			if (this.SD.IsResult1 == 1)
			{
				this.chBRes1.Checked = true;
			}
			else
			{
				this.chBRes1.Checked = false;
			}
			if (this.SD.IsResult2 == 1)
			{
				this.chBRes2.Checked = true;
			}
			else
			{
				this.chBRes2.Checked = false;
			}
			if (this.SD.IsResult3 == 1)
			{
				this.chBRes3.Checked = true;
			}
			else
			{
				this.chBRes3.Checked = false;
			}
			if (this.SD.Enable.Snug == 1)
			{
				this.chBTreshM.Checked = true;
			}
			else
			{
				this.chBTreshM.Checked = false;
			}
			this.nETreshM.Value = this.SD.MS * this.Main.TorqueConvert;
			this.nETplus.Value = this.SD.Tmax;
			this.nEMmaxCheck.Value = this.SD.Mmax * this.Main.TorqueConvert;
			this.nEMminCheck.Value = this.SD.Mmin * this.Main.TorqueConvert;
			if ((this.SD.UserRights & 1) == 1)
			{
				this.chBTargetRight.Checked = true;
			}
			else
			{
				this.chBTargetRight.Checked = false;
			}
			if ((this.SD.UserRights & 2) == 2)
			{
				this.chBSetRight.Checked = true;
			}
			else
			{
				this.chBSetRight.Checked = false;
			}
			if ((this.SD.UserRights & 4) == 4)
			{
				this.chBCheckRight.Checked = true;
			}
			else
			{
				this.chBCheckRight.Checked = false;
			}
			base.Invalidate();
			this.IsInitializeMode = false;
		}

		private void cBTargetName_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (!this.IsInitializeMode)
			{
				this.Main.SettingsChanged();
				this.SD.Enable.ADepth = 0;
				this.SD.Enable.Ana = 0;
				this.SD.Enable.Angle = 0;
				this.SD.Enable.FTorque = 0;
				this.SD.Enable.GradientMin = 0;
				this.SD.Enable.GradientMax = 0;
				this.SD.Enable.ADepthGradMax = 0;
				this.SD.Enable.ADepthGradMin = 0;
				this.SD.Enable.Time = 0;
				this.SD.Enable.Torque = 0;
				this.SD.Enable.Snug = 0;
				this.SD.DigMax = 0;
				this.SD.DigMin = 0;
				this.chBTreshM.Checked = false;
				this.SetTargetParameter();
			}
		}

		private void SetTargetParameter()
		{
			switch (this.cBTargetName.SelectedIndex)
			{
			case 0:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.MP * this.Main.TorqueConvert;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = false;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName;
				break;
			case 1:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.MFP * this.Main.TorqueConvert;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = false;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName;
				break;
			case 2:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.MRP * this.Main.TorqueConvert;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName;
				this.pnMRTarget.Visible = true;
				this.pnMmax.Visible = true;
				this.pnMmin.Visible = true;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				break;
			case 3:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.MRP * this.Main.TorqueConvert;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = true;
				this.pnMmin.Visible = true;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				break;
			case 4:
				this.nETargetValue.MaxValue = 100f * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -100f * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 4;
				this.nETargetValue.Value = this.SD.MGP * this.Main.TorqueConvert;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = false;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName + "/" + this.Main.Rm.GetString("Degree");
				break;
			case 5:
				this.nETargetValue.MaxValue = 30000f;
				this.nETargetValue.MinValue = -30000f;
				this.nETargetValue.DecimalNum = 1;
				this.nETargetValue.Value = this.SD.WP;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = false;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = true;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = this.Main.Rm.GetString("Degree");
				break;
			case 6:
				this.nETargetValue.MaxValue = 60f;
				this.nETargetValue.MinValue = 0f;
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.TP;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = false;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = this.Main.Rm.GetString("Second");
				break;
			case 7:
				this.nETargetValue.MaxValue = 999f;
				this.nETargetValue.MinValue = -999f;
				this.nETargetValue.DecimalNum = 1;
				this.nETargetValue.Value = this.SD.LP;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = false;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = this.Main.Rm.GetString("Milimeter");
				break;
			case 8:
				this.nETargetValue.MaxValue = 1000f * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -1000f * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 4;
				this.nETargetValue.Value = this.SD.LGP;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = false;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second");
				break;
			case 9:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.AnaSigScale * (10f + this.Main.VC.SpConst.AnaSigOffset);
				this.nETargetValue.MinValue = this.Main.VC.SpConst.AnaSigScale * (-10f + this.Main.VC.SpConst.AnaSigOffset);
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.AnaP;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = false;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = string.Empty;
				break;
			case 10:
				if (this.SD.DigP < -5)
				{
					this.SD.DigP = -5;
				}
				if (this.SD.DigP > 5)
				{
					this.SD.DigP = 5;
				}
				if (this.SD.DigP < 0)
				{
					this.cBTargetDigSignal.SelectedIndex = -this.SD.DigP * 2 - 1;
				}
				if (this.SD.DigP > 0)
				{
					this.cBTargetDigSignal.SelectedIndex = this.SD.DigP * 2 - 2;
				}
				if (this.SD.DigP == 0)
				{
					this.cBTargetDigSignal.SelectedIndex = 0;
				}
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = false;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = true;
				this.pnNormalTarget.Visible = false;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = string.Empty;
				break;
			case 11:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.MP * this.Main.TorqueConvert;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = true;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName;
				break;
			case 12:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -1f * this.Main.VC.SpConst.SpindleTorque * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.MFP * this.Main.TorqueConvert;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = true;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName;
				break;
			case 13:
				this.nETargetValue.MaxValue = 100f * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -100f * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 4;
				this.nETargetValue.Value = this.SD.MGP * this.Main.TorqueConvert;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = true;
				this.pnMmin.Visible = true;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.lbTargetUnit.Text = this.Main.TorqueUnitName + "/" + this.Main.Rm.GetString("Degree");
				break;
			case 14:
				this.nETargetValue.MaxValue = 999f;
				this.nETargetValue.MinValue = -999f;
				this.nETargetValue.DecimalNum = 1;
				this.nETargetValue.Value = this.SD.LP;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = false;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = this.Main.Rm.GetString("Milimeter");
				break;
			case 15:
				this.nETargetValue.MaxValue = 1000f * this.Main.TorqueConvert;
				this.nETargetValue.MinValue = -1000f * this.Main.TorqueConvert;
				this.nETargetValue.DecimalNum = 4;
				this.nETargetValue.Value = this.SD.LGP;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = false;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second");
				break;
			case 16:
				this.nETargetValue.MaxValue = this.Main.VC.SpConst.AnaSigScale * (10f + this.Main.VC.SpConst.AnaSigOffset);
				this.nETargetValue.MinValue = this.Main.VC.SpConst.AnaSigScale * (-10f + this.Main.VC.SpConst.AnaSigOffset);
				this.nETargetValue.DecimalNum = 2;
				this.nETargetValue.Value = this.SD.AnaP;
				this.pnMRTarget.Visible = false;
				this.pnMmax.Visible = false;
				this.pnMmin.Visible = false;
				this.pnDigTarget.Visible = false;
				this.pnNormalTarget.Visible = true;
				this.pnTreshM.Visible = false;
				this.pnMaxTime.Visible = true;
				this.lbTargetUnit.Text = string.Empty;
				break;
			default:
				MessageBox.Show("Wrong selected index in SetTargetParameter() of EditDrivingStep", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				break;
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.gBHeader.Select();
				this.pnMenu.Enabled = false;
				this.Main.ProcessProgram.CompareStepStruct(this.SD, this.Main.VC.PProg.Num[this.PNum].Step[this.SNum], this.PNum, this.SNum, 4);
				this.Main.StatusBarText(string.Empty);
				this.Main.StepOverview1.StepButtonShow();
				base.Hide();
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap6_4_1_StufentypDrehen";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap6_4_1_StufentypDrehen");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btCheckPar_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.gBHeader.Select();
				this.pnMenu.Enabled = false;
				this.Main.CheckParam1.ShowWindow(this.PNum, this.SNum);
			}
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void EditDrivingStepForm_Activated(object sender, EventArgs e)
		{
			this.IsInitializeMode = true;
			this.MenEna();
			this.bCanceled = false;
			this.pnMenu.Enabled = true;
			this.btBack.Select();
			this.IsInitializeMode = false;
		}

		private void chBTreshM_CheckedChanged(object sender, EventArgs e)
		{
			if (!this.IsInitializeMode)
			{
				this.Main.SettingsChanged();
			}
			this.MenEna();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.Main.DeleteLogEntries(4, this.PNum);
			this.bCanceled = true;
			this.gBHeader.Select();
			this.pnMenu.Enabled = false;
			this.Main.StatusBarText(string.Empty);
			base.Hide();
		}

		public void KeyArrived()
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else if (this.Main.PassCodeLevel > 0)
			{
				if (this.Main.GetExclusiveBlock1())
				{
					if (this.Main.ProcessProgram.UploadAllProgDataFromController())
					{
						this.Main.CheckParamAllowed = true;
						base.Hide();
						this.Main.StepOverview1.Hide();
					}
				}
				else
				{
					this.Main.CheckParamAllowed = false;
				}
			}
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void btPrevious_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.gBHeader.Select();
				this.pnMenu.Enabled = false;
				this.Main.ProcessProgram.CompareStepStruct(this.SD, this.Main.VC.PProg.Num[this.PNum].Step[this.SNum], this.PNum, this.SNum, 4);
				this.Main.StatusBarText(string.Empty);
				base.Hide();
				this.Main.StepOverview1.EditPreviousStep();
			}
		}

		private void btNext_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.gBHeader.Select();
				this.pnMenu.Enabled = false;
				this.Main.ProcessProgram.CompareStepStruct(this.SD, this.Main.VC.PProg.Num[this.PNum].Step[this.SNum], this.PNum, this.SNum, 4);
				this.Main.StatusBarText(string.Empty);
				base.Hide();
				this.Main.StepOverview1.EditNextStep();
			}
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.IsInitializeMode)
			{
				this.Main.SettingsChanged();
			}
		}

		private void textChanged(object sender, EventArgs e)
		{
			this.settingsChanged(sender, e);
		}
	}
}
