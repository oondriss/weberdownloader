using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class MenuParameterForm : Form
	{
		private MainForm Main;

		private ParameterPrintForm ParameterPrint1;

		private Panel pnMenu;

		private Button btHome;

		private Button btBack;

		private Button btPrint;

		private Button btBackup;

		private Button btSystemConstants;

		private Button btScrewPrograms;

		private Button btSpindleConstants;

		private Button btMaintenance;

		private GroupBox gBOverview;

		private GroupBox gbPrograms;

		private Label lbProgramms;

		private GroupBox gbMaintenance;

		private Label lbMaintenance;

		private Label lbAdvanced;

		private GroupBox gbSystem;

		private Label lbIp;

		private IContainer components;

		public MenuParameterForm(MainForm main)
		{
			this.Main = main;
			this.ParameterPrint1 = new ParameterPrintForm(this.Main);
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btMaintenance = new Button();
			this.btPrint = new Button();
			this.btHome = new Button();
			this.btBackup = new Button();
			this.btSystemConstants = new Button();
			this.btScrewPrograms = new Button();
			this.btSpindleConstants = new Button();
			this.btBack = new Button();
			this.gBOverview = new GroupBox();
			this.gbSystem = new GroupBox();
			this.lbIp = new Label();
			this.gbMaintenance = new GroupBox();
			this.lbMaintenance = new Label();
			this.lbAdvanced = new Label();
			this.gbPrograms = new GroupBox();
			this.lbProgramms = new Label();
			this.pnMenu.SuspendLayout();
			this.gBOverview.SuspendLayout();
			this.gbSystem.SuspendLayout();
			this.gbMaintenance.SuspendLayout();
			this.gbPrograms.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Controls.Add(this.btMaintenance);
			this.pnMenu.Controls.Add(this.btPrint);
			this.pnMenu.Controls.Add(this.btHome);
			this.pnMenu.Controls.Add(this.btBackup);
			this.pnMenu.Controls.Add(this.btSystemConstants);
			this.pnMenu.Controls.Add(this.btScrewPrograms);
			this.pnMenu.Controls.Add(this.btSpindleConstants);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btMaintenance.Location = new Point(3, 387);
			this.btMaintenance.Name = "btMaintenance";
			this.btMaintenance.Size = new Size(74, 62);
			this.btMaintenance.TabIndex = 6;
			this.btMaintenance.Text = "Wartung";
			this.btMaintenance.Click += this.btMaintenance_Click;
			this.btPrint.Location = new Point(3, 451);
			this.btPrint.Name = "btPrint";
			this.btPrint.Size = new Size(74, 62);
			this.btPrint.TabIndex = 7;
			this.btPrint.Text = "Drucken";
			this.btPrint.Click += this.btPrint_Click;
			///this.btHome.Image = Resources.Home1;
			this.btHome.Location = new Point(3, 67);
			this.btHome.Name = "btHome";
			this.btHome.Size = new Size(74, 62);
			this.btHome.TabIndex = 1;
			this.btHome.Click += this.btHome_Click;
			this.btBackup.Location = new Point(3, 323);
			this.btBackup.Name = "btBackup";
			this.btBackup.Size = new Size(74, 62);
			this.btBackup.TabIndex = 5;
			this.btBackup.Text = "Backup";
			this.btBackup.Click += this.btBackup_Click;
			this.btSystemConstants.Location = new Point(3, 259);
			this.btSystemConstants.Name = "btSystemConstants";
			this.btSystemConstants.Size = new Size(74, 62);
			this.btSystemConstants.TabIndex = 4;
			this.btSystemConstants.Text = "Systemkonstanten";
			this.btSystemConstants.Click += this.btSystemConstants_Click;
			this.btScrewPrograms.Location = new Point(3, 131);
			this.btScrewPrograms.Name = "btScrewPrograms";
			this.btScrewPrograms.Size = new Size(74, 62);
			this.btScrewPrograms.TabIndex = 2;
			this.btScrewPrograms.Text = "Schraubprogramme";
			this.btScrewPrograms.Click += this.btScrewPrograms_Click;
			this.btSpindleConstants.Location = new Point(3, 195);
			this.btSpindleConstants.Name = "btSpindleConstants";
			this.btSpindleConstants.Size = new Size(74, 62);
			this.btSpindleConstants.TabIndex = 3;
			this.btSpindleConstants.Text = "Spindelkonstanten";
			this.btSpindleConstants.Click += this.btSpindleConstants_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.gBOverview.Controls.Add(this.gbSystem);
			this.gBOverview.Controls.Add(this.gbMaintenance);
			this.gBOverview.Controls.Add(this.gbPrograms);
			this.gBOverview.Location = new Point(420, 106);
			this.gBOverview.Name = "gBOverview";
			this.gBOverview.Size = new Size(274, 407);
			this.gBOverview.TabIndex = 2;
			this.gBOverview.TabStop = false;
			this.gBOverview.Text = "Übersicht";
			this.gbSystem.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.gbSystem.Controls.Add(this.lbIp);
			this.gbSystem.Location = new Point(8, 153);
			this.gbSystem.Name = "gbSystem";
			this.gbSystem.Size = new Size(260, 62);
			this.gbSystem.TabIndex = 8;
			this.gbSystem.TabStop = false;
			this.gbSystem.Visible = false;
			this.lbIp.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.lbIp.Location = new Point(8, 13);
			this.lbIp.Name = "lbIp";
			this.lbIp.Size = new Size(245, 41);
			this.lbIp.TabIndex = 2;
			this.lbIp.Text = "IP Address";
			this.lbIp.Click += this.btSystemConstants_Click;
			this.lbIp.MouseDown += this.lbX_MouseDown;
			this.lbIp.MouseLeave += this.lbX_MouseLeave;
			this.lbIp.MouseUp += this.lbX_MouseUp;
			this.gbMaintenance.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.gbMaintenance.Controls.Add(this.lbMaintenance);
			this.gbMaintenance.Controls.Add(this.lbAdvanced);
			this.gbMaintenance.Location = new Point(8, 281);
			this.gbMaintenance.Name = "gbMaintenance";
			this.gbMaintenance.Size = new Size(260, 62);
			this.gbMaintenance.TabIndex = 7;
			this.gbMaintenance.TabStop = false;
			this.lbMaintenance.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.lbMaintenance.Location = new Point(8, 38);
			this.lbMaintenance.Name = "lbMaintenance";
			this.lbMaintenance.Size = new Size(245, 22);
			this.lbMaintenance.TabIndex = 3;
			this.lbMaintenance.Text = "Wartungsmeldungen";
			this.lbMaintenance.TextAlign = ContentAlignment.MiddleLeft;
			this.lbMaintenance.Click += this.btMaintenance_Click;
			this.lbMaintenance.MouseDown += this.lbX_MouseDown;
			this.lbMaintenance.MouseLeave += this.lbX_MouseLeave;
			this.lbMaintenance.MouseUp += this.lbX_MouseUp;
			this.lbAdvanced.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.lbAdvanced.Location = new Point(8, 7);
			this.lbAdvanced.Name = "lbAdvanced";
			this.lbAdvanced.Size = new Size(245, 32);
			this.lbAdvanced.TabIndex = 2;
			this.lbAdvanced.Text = "Vorwarnwerte Zweizeilig xxxxxxxxxxxxxxxxxxxxxxxxxxxx";
			this.lbAdvanced.TextAlign = ContentAlignment.MiddleLeft;
			this.lbAdvanced.Click += this.btMaintenance_Click;
			this.lbAdvanced.MouseDown += this.lbX_MouseDown;
			this.lbAdvanced.MouseLeave += this.lbX_MouseLeave;
			this.lbAdvanced.MouseUp += this.lbX_MouseUp;
			this.gbPrograms.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.gbPrograms.Controls.Add(this.lbProgramms);
			this.gbPrograms.Location = new Point(8, 25);
			this.gbPrograms.Name = "gbPrograms";
			this.gbPrograms.Size = new Size(260, 62);
			this.gbPrograms.TabIndex = 6;
			this.gbPrograms.TabStop = false;
			this.lbProgramms.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.lbProgramms.Location = new Point(9, 14);
			this.lbProgramms.Name = "lbProgramms";
			this.lbProgramms.Size = new Size(245, 41);
			this.lbProgramms.TabIndex = 2;
			this.lbProgramms.Text = "Anzahl in der Liste:";
			this.lbProgramms.TextAlign = ContentAlignment.MiddleLeft;
			this.lbProgramms.Click += this.btScrewPrograms_Click;
			this.lbProgramms.MouseDown += this.lbX_MouseDown;
			this.lbProgramms.MouseLeave += this.lbX_MouseLeave;
			this.lbProgramms.MouseUp += this.lbX_MouseUp;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.gBOverview);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "MenuParameterForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen";
			base.Activated += this.MenuParameterForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBOverview.ResumeLayout(false);
			this.gbSystem.ResumeLayout(false);
			this.gbMaintenance.ResumeLayout(false);
			this.gbPrograms.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public void ShowWindow()
		{
			this.Main.ResetBrowserGrantedBy();
			this.Overview(true);
			this.MenEna();
			base.Show();
		}

		public void SetLanguageTexts()
		{
			this.Main.ResetBrowserGrantedBy();
			this.Text = this.Main.Rm.GetString("MenuParameter");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btBackup.Text = this.Main.Rm.GetString("Backup");
			this.btHome.Text = this.Main.Rm.GetString("btHome");
			this.btPrint.Text = this.Main.Rm.GetString("Print");
			this.btScrewPrograms.Text = this.Main.Rm.GetString("ScrewPrograms");
			this.btSpindleConstants.Text = this.Main.Rm.GetString("SpindleConstants");
			this.btSystemConstants.Text = this.Main.Rm.GetString("SystemConstants");
			this.btMaintenance.Text = this.Main.Rm.GetString("btMaintenance0");
			this.ParameterPrint1.SetLanguageTexts();
			this.gBOverview.Text = this.Main.Rm.GetString("gbOverview");
		}

		private void MenEna()
		{
			if (!this.Main.IsOfflineVersion && !this.Main.IsOnlineMode)
			{
				this.Main.ProcessProgram.InitializeTempProgStruct();
			}
			this.btPrint.Enabled = true;
			this.btMaintenance.Enabled = true;
			this.Main.ShowCurrentUserAccessState(0, false);
		}

		public void Overview(bool loadFromWSP)
		{
			this.lbProgramms.Text = this.Main.Rm.GetString("lbNumberInList") + " " + this.Main.Rm.GetString("ScrewPrograms_") + ": " + this.Main.ProgramOverview1.Count(loadFromWSP);
			if (this.Main.IsOnlineMode)
			{
				this.gbSystem.Visible = true;
				this.lbIp.Text = this.Main.Rm.GetString("IPAddress") + ": " + this.Main.MyIp.ToString();
			}
			else
			{
				this.gbSystem.Visible = false;
			}
			this.btMaintenance.ForeColor = this.Main.AdvanceWarning1.GetInfo(true);
			bool flag;
			int num;
			int num2;
			int num3;
			if (this.btMaintenance.ForeColor == Color.Black)
			{
				this.btMaintenance.ForeColor = this.Main.Maintenance1.GetInfo(out flag, out num, out num2, out num3, true);
			}
			bool visible = false;
			string namesOfAdvancedCounters = this.Main.AdvanceWarning1.GetNamesOfAdvancedCounters();
			if (namesOfAdvancedCounters.Length != 0 || this.btMaintenance.ForeColor != Color.Black)
			{
				if (this.Main.AdvanceWarning1.GetInfo(false) != Color.Black)
				{
					visible = true;
					this.lbAdvanced.Text = this.Main.Rm.GetString("AdvanceWarningMessages");
				}
				else if (namesOfAdvancedCounters.Length != 0)
				{
					visible = true;
					this.lbAdvanced.Text = this.Main.Rm.GetString("AdvanceWarningRemainder");
				}
				else
				{
					this.lbAdvanced.Text = "";
				}
				if (this.Main.Maintenance1.GetInfo(out flag, out num, out num2, out num3, false) != Color.Black || !flag)
				{
					visible = true;
					this.lbMaintenance.Text = this.Main.Rm.GetString("MaintMessages");
				}
				else
				{
					this.lbMaintenance.Text = "";
				}
			}
			this.gbMaintenance.Visible = visible;
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.Main.ExitExclusiveBlock1();
			this.Main.ResetPasscodeLevel();
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_Einstellungen";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_Einstellungen");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btScrewPrograms_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.ProgramOverview1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void btSpindleConstants_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.SpindleConstants1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void btSystemConstants_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.SystemConstants1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void btBackup_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.Main.Backup1.ShowWindow();
		}

		public void BtMaintenance_Click()
		{
			this.btMaintenance_Click(null, EventArgs.Empty);
		}

		private void btMaintenance_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.Main.Component1.LoadDataFromController();
			this.Main.MenuMaintenance1.ShowWindow();
		}

		private void MenuParameterForm_Activated(object sender, EventArgs e)
		{
			this.Overview(false);
			this.pnMenu.Enabled = true;
			this.MenEna();
			this.btBack.Select();
		}

		private void btPrint_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOfflineVersion)
			{
				if (!this.Main.IsOnlineMode)
				{
					this.MenEna();
					MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadSystemConst"));
				if (!this.Main.VC.ReceiveVarBlock(12))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not receive SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadSpindleConst"));
				if (!this.Main.VC.ReceiveVarBlock(11))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not receive SpConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadProgramData"));
				if (!this.Main.VC.ReceiveVarBlock(10))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not receive ProgramBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
			}
			this.ParameterPrint1.ShowWindow();
		}

		public void KeyArrived()
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else if (this.Main.PassCodeLevel > 0)
			{
				if (this.Main.GetExclusiveBlock1())
				{
					this.Main.ProcessProgram.UploadAllProgDataFromController();
					this.Main.ProcessProgram.InitializeTempProgStruct();
					this.Main.CheckParamAllowed = true;
					this.ShowWindow();
				}
				else
				{
					this.Main.CheckParamAllowed = false;
				}
			}
		}

		public void KeyRemoved()
		{
			this.ParameterPrint1.Cancel();
			this.ParameterPrint1.Dispose();
			this.ParameterPrint1 = new ParameterPrintForm(this.Main);
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void lbX_MouseDown(object sender, MouseEventArgs e)
		{
			Label label = sender as Label;
			if (label == this.lbProgramms)
			{
				this.lbProgramms.BackColor = SystemColors.ControlLight;
			}
			else if (label == this.lbIp)
			{
				this.lbIp.BackColor = SystemColors.ControlLight;
			}
			else
			{
				if (label != this.lbAdvanced && label != this.lbMaintenance)
				{
					return;
				}
				this.lbAdvanced.BackColor = SystemColors.ControlLight;
				this.lbMaintenance.BackColor = SystemColors.ControlLight;
			}
		}

		private void lbX_MouseUp(object sender, MouseEventArgs e)
		{
			this.lbProgramms.BackColor = SystemColors.Control;
			this.lbIp.BackColor = SystemColors.Control;
			this.lbAdvanced.BackColor = SystemColors.Control;
			this.lbMaintenance.BackColor = SystemColors.Control;
		}

		private void lbX_MouseLeave(object sender, EventArgs e)
		{
			this.lbProgramms.BackColor = SystemColors.Control;
			this.lbIp.BackColor = SystemColors.Control;
			this.lbAdvanced.BackColor = SystemColors.Control;
			this.lbMaintenance.BackColor = SystemColors.Control;
		}
	}
}
