using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;

namespace Visualisation
{
	public class NumberPadForm : Form
	{
		private MainForm Main;

		private NumberEdit1 NE;

		private NumericUpDown NUD;

		private int NESelectionStart;

		private float Number;

		private float MaxValue;

		private float MinValue;

		private uint UintNumber;

		private uint UintMaxValue;

		private uint UintMinValue;

		private int DecimalNum;

		private string OldText;

		private bool IsNumberEdit;

		private Panel panel1;

		private Label lbOldValue;

		private Button btApply;

		private Button btCancel;

		private Button bt7;

		private Button bt8;

		private Button bt9;

		private Button bt4;

		private Button bt5;

		private Button bt6;

		private Button bt1;

		private Button bt2;

		private Button bt0;

		private Button bt3;

		private Button btDecSeparator;

		private Button btClear;

		private TextBox tBNewValue;

		private Button btMinus;

		private Container components;

		public int NumberOfCharacters => this.OldText.Length;

		public NumberPadForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.btDecSeparator.Tag = Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;
			this.btDecSeparator.Text = Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;
			this.Number = 0f;
			this.MaxValue = 0f;
			this.MinValue = 0f;
			this.UintNumber = 0u;
			this.UintMaxValue = 0u;
			this.UintMinValue = 0u;
			this.DecimalNum = 0;
			this.OldText = string.Empty;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.panel1 = new Panel();
			this.btMinus = new Button();
			this.tBNewValue = new TextBox();
			this.btClear = new Button();
			this.btDecSeparator = new Button();
			this.bt3 = new Button();
			this.bt0 = new Button();
			this.bt2 = new Button();
			this.bt1 = new Button();
			this.bt6 = new Button();
			this.bt5 = new Button();
			this.bt4 = new Button();
			this.bt9 = new Button();
			this.bt8 = new Button();
			this.lbOldValue = new Label();
			this.bt7 = new Button();
			this.btApply = new Button();
			this.btCancel = new Button();
			this.panel1.SuspendLayout();
			base.SuspendLayout();
			this.panel1.Controls.Add(this.btMinus);
			this.panel1.Controls.Add(this.tBNewValue);
			this.panel1.Controls.Add(this.btClear);
			this.panel1.Controls.Add(this.btDecSeparator);
			this.panel1.Controls.Add(this.bt3);
			this.panel1.Controls.Add(this.bt0);
			this.panel1.Controls.Add(this.bt2);
			this.panel1.Controls.Add(this.bt1);
			this.panel1.Controls.Add(this.bt6);
			this.panel1.Controls.Add(this.bt5);
			this.panel1.Controls.Add(this.bt4);
			this.panel1.Controls.Add(this.bt9);
			this.panel1.Controls.Add(this.bt8);
			this.panel1.Controls.Add(this.lbOldValue);
			this.panel1.Controls.Add(this.bt7);
			this.panel1.Controls.Add(this.btApply);
			this.panel1.Controls.Add(this.btCancel);
			this.panel1.Location = new Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new Size(200, 366);
			this.panel1.TabIndex = 0;
			this.btMinus.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btMinus.Location = new Point(136, 240);
			this.btMinus.Name = "btMinus";
			this.btMinus.Size = new Size(56, 56);
			this.btMinus.TabIndex = 12;
			this.btMinus.Tag = "-";
			this.btMinus.Text = "-";
			this.btMinus.Click += this.numberKey_Click;
			this.tBNewValue.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.tBNewValue.Location = new Point(8, 8);
			this.tBNewValue.Name = "tBNewValue";
			this.tBNewValue.Size = new Size(88, 28);
			this.tBNewValue.TabIndex = 0;
			this.tBNewValue.Text = "textBox1";
			this.tBNewValue.TextAlign = HorizontalAlignment.Right;
			this.tBNewValue.TextChanged += this.tBNewValue_TextChanged;
			this.tBNewValue.KeyUp += this.tBNewValue_KeyUp;
			this.tBNewValue.MouseDown += this.tBNewValue_MouseDown;
			this.btClear.Location = new Point(72, 304);
			this.btClear.Name = "btClear";
			this.btClear.Size = new Size(56, 56);
			this.btClear.TabIndex = 15;
			this.btClear.Tag = "{BS}";
			this.btClear.Text = "C";
			this.btClear.Click += this.numberKey_Click;
			this.btDecSeparator.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDecSeparator.Location = new Point(72, 240);
			this.btDecSeparator.Name = "btDecSeparator";
			this.btDecSeparator.Size = new Size(56, 56);
			this.btDecSeparator.TabIndex = 11;
			this.btDecSeparator.Tag = ",";
			this.btDecSeparator.Text = ",";
			this.btDecSeparator.Click += this.numberKey_Click;
			this.bt3.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt3.Location = new Point(136, 176);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(56, 56);
			this.bt3.TabIndex = 9;
			this.bt3.Tag = "3";
			this.bt3.Text = "3";
			this.bt3.Click += this.numberKey_Click;
			this.bt0.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt0.Location = new Point(8, 240);
			this.bt0.Name = "bt0";
			this.bt0.Size = new Size(56, 56);
			this.bt0.TabIndex = 10;
			this.bt0.Tag = "0";
			this.bt0.Text = "0";
			this.bt0.Click += this.numberKey_Click;
			this.bt2.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt2.Location = new Point(72, 176);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(56, 56);
			this.bt2.TabIndex = 8;
			this.bt2.Tag = "2";
			this.bt2.Text = "2";
			this.bt2.Click += this.numberKey_Click;
			this.bt1.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt1.Location = new Point(8, 176);
			this.bt1.Name = "bt1";
			this.bt1.Size = new Size(56, 56);
			this.bt1.TabIndex = 7;
			this.bt1.Tag = "1";
			this.bt1.Text = "1";
			this.bt1.Click += this.numberKey_Click;
			this.bt6.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt6.Location = new Point(136, 112);
			this.bt6.Name = "bt6";
			this.bt6.Size = new Size(56, 56);
			this.bt6.TabIndex = 6;
			this.bt6.Tag = "6";
			this.bt6.Text = "6";
			this.bt6.Click += this.numberKey_Click;
			this.bt5.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt5.Location = new Point(72, 112);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(56, 56);
			this.bt5.TabIndex = 5;
			this.bt5.Tag = "5";
			this.bt5.Text = "5";
			this.bt5.Click += this.numberKey_Click;
			this.bt4.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt4.Location = new Point(8, 112);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(56, 56);
			this.bt4.TabIndex = 4;
			this.bt4.Tag = "4";
			this.bt4.Text = "4";
			this.bt4.Click += this.numberKey_Click;
			this.bt9.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt9.Location = new Point(136, 48);
			this.bt9.Name = "bt9";
			this.bt9.Size = new Size(56, 56);
			this.bt9.TabIndex = 3;
			this.bt9.Tag = "9";
			this.bt9.Text = "9";
			this.bt9.Click += this.numberKey_Click;
			this.bt8.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt8.Location = new Point(72, 48);
			this.bt8.Name = "bt8";
			this.bt8.Size = new Size(56, 56);
			this.bt8.TabIndex = 2;
			this.bt8.Tag = "8";
			this.bt8.Text = "8";
			this.bt8.Click += this.numberKey_Click;
			this.lbOldValue.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbOldValue.Location = new Point(104, 10);
			this.lbOldValue.Name = "lbOldValue";
			this.lbOldValue.Size = new Size(88, 23);
			this.lbOldValue.TabIndex = 8;
			this.lbOldValue.Text = "label1";
			this.lbOldValue.TextAlign = ContentAlignment.MiddleRight;
			this.bt7.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt7.Location = new Point(8, 48);
			this.bt7.Name = "bt7";
			this.bt7.Size = new Size(56, 56);
			this.bt7.TabIndex = 1;
			this.bt7.Tag = "7";
			this.bt7.Text = "7";
			this.bt7.Click += this.numberKey_Click;
			this.btApply.Location = new Point(136, 304);
			this.btApply.Name = "btApply";
			this.btApply.Size = new Size(56, 56);
			this.btApply.TabIndex = 13;
			this.btApply.Text = "OK";
			this.btApply.Click += this.btApply_Click;
			this.btCancel.Location = new Point(8, 304);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(56, 56);
			this.btCancel.TabIndex = 14;
			this.btCancel.Text = "ESC";
			this.btCancel.Click += this.btCancel_Click;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(200, 366);
			base.ControlBox = false;
			base.Controls.Add(this.panel1);
			this.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "NumberPadForm";
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.CenterScreen;
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			base.ResumeLayout(false);
		}

		public void ShowNumberPad(NumberEdit1 nE)
		{
			if (!this.Main.ProcessingUsbKeyRemovedEvent())
			{
				this.NE = nE;
				this.IsNumberEdit = true;
				this.lbOldValue.Text = nE.Text;
				this.tBNewValue.Text = string.Empty;
				this.tBNewValue.MaxLength = nE.MaxLength;
				this.Number = 0f;
				this.MaxValue = nE.MaxValue;
				this.MinValue = nE.MinValue;
				this.DecimalNum = nE.DecimalNum;
				this.NESelectionStart = 0;
				this.tBNewValue.Select();
				base.ShowDialog();
			}
		}

		public void ShowNumberPad(NumericUpDown nUD)
		{
			this.NUD = nUD;
			this.IsNumberEdit = false;
			this.lbOldValue.Text = nUD.Value.ToString();
			this.tBNewValue.Text = string.Empty;
			this.tBNewValue.MaxLength = nUD.Maximum.ToString().Length;
			this.UintNumber = 0u;
			try
			{
				this.UintMaxValue = (uint)nUD.Maximum;
			}
			catch
			{
				this.UintMaxValue = uint.MaxValue;
				MessageBox.Show("Uint value overflow in ShowNumberPad()", "Internal Error");
			}
			try
			{
				this.UintMinValue = (uint)nUD.Minimum;
			}
			catch
			{
				this.UintMinValue = 0u;
				MessageBox.Show("Uint value overflow in ShowNumberPad()", "Internal Error");
			}
			this.DecimalNum = 0;
			this.NESelectionStart = 0;
			this.tBNewValue.Select();
			base.ShowDialog();
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("NumberPad");
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		private void btApply_Click(object sender, EventArgs e)
		{
			if (this.IsNumberEdit)
			{
				this.NE.Value = this.Number;
			}
			else
			{
				this.NUD.Value = this.UintNumber;
			}
			this.Main.SettingsChanged();
			base.Close();
		}

		private void numberKey_Click(object sender, EventArgs e)
		{
			string text = base.ActiveControl.Tag.ToString();
			this.tBNewValue.Focus();
			this.tBNewValue.Select(this.NESelectionStart, 0);
			if (this.Main.CommonFunctions.GetCapsLockState())
			{
				MessageBox.Show(this.Main.Rm.GetString("MbKeyLockActive"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else if (text == "{BS}")
			{
				if (this.NESelectionStart > 0)
				{
					this.tBNewValue.Text = this.tBNewValue.Text.Remove(this.NESelectionStart - 1, 1);
				}
			}
			else if (text == "-" && this.tBNewValue.Text.Length > 0)
			{
				if (this.tBNewValue.Text.StartsWith("-"))
				{
					this.tBNewValue.Text = this.tBNewValue.Text.Remove(0, 1);
				}
				else
				{
					this.tBNewValue.Text = "-" + this.tBNewValue.Text;
				}
			}
			else
			{
				this.tBNewValue.Text = this.tBNewValue.Text.Substring(0, this.NESelectionStart) + text + this.tBNewValue.Text.Substring(this.NESelectionStart);
			}
		}

		private void tBNewValue_TextChanged(object sender, EventArgs e)
		{
			if (!(this.tBNewValue.Text == this.OldText))
			{
				if (this.tBNewValue.Text.Length > this.tBNewValue.MaxLength)
				{
					this.tBNewValue.Text = this.OldText;
					this.tBNewValue.SelectionStart = this.NESelectionStart;
				}
				else if (!this.NumberCheck())
				{
					this.tBNewValue.ForeColor = Color.Red;
				}
				else
				{
					this.tBNewValue.ForeColor = Color.Black;
				}
			}
		}

		private bool NumberCheck()
		{
			string numberDecimalSeparator = Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;
			char c = numberDecimalSeparator[0];
			this.tBNewValue.Text.Trim();
			if (this.tBNewValue.Text.Length < this.OldText.Length)
			{
				if (this.tBNewValue.SelectionStart == 0 && this.NESelectionStart > 0)
				{
					this.tBNewValue.SelectionStart = this.NESelectionStart - 1;
				}
				this.NESelectionStart = this.tBNewValue.SelectionStart;
			}
			else if (this.tBNewValue.Text == this.OldText)
			{
				this.tBNewValue.SelectionStart = this.NESelectionStart;
			}
			else
			{
				this.tBNewValue.SelectionStart = this.NESelectionStart + 1;
			}
			try
			{
				if (this.IsNumberEdit)
				{
					this.Number = float.Parse(this.tBNewValue.Text, NumberStyles.Float);
				}
				else
				{
					this.UintNumber = uint.Parse(this.tBNewValue.Text);
				}
				this.OldText = this.tBNewValue.Text;
			}
			catch
			{
				if (!(this.tBNewValue.Text == string.Empty) && !(this.tBNewValue.Text == "-") && !(this.tBNewValue.Text == "-" + numberDecimalSeparator) && !(this.tBNewValue.Text == numberDecimalSeparator))
				{
					this.tBNewValue.Text = this.OldText;
					this.tBNewValue.SelectionStart = this.NESelectionStart;
					goto end_IL_0116;
				}
				this.OldText = this.tBNewValue.Text;
				this.NESelectionStart = this.tBNewValue.SelectionStart;
				return false;
				end_IL_0116:;
			}
			if (this.IsNumberEdit)
			{
				return this.CheckDigitNumber();
			}
			return this.CheckUintNumber();
		}

		private bool CheckDigitNumber()
		{
			string numberDecimalSeparator = Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;
			char[] separator = new char[1]
			{
				numberDecimalSeparator[0]
			};
			string[] array = this.tBNewValue.Text.Split(separator, 2);
			if (array.Length > 1 && array[1].Length > this.DecimalNum)
			{
				this.OldText = this.tBNewValue.Text.Remove(this.tBNewValue.Text.Length - (array[1].Length - this.DecimalNum), array[1].Length - this.DecimalNum);
				this.tBNewValue.Text = this.OldText;
				if (this.NESelectionStart < this.OldText.Length)
				{
					this.NESelectionStart++;
				}
				this.tBNewValue.SelectionStart = this.NESelectionStart;
				if (this.tBNewValue.Text == numberDecimalSeparator)
				{
					this.Number = 0f;
				}
				else
				{
					this.Number = float.Parse(this.tBNewValue.Text, NumberStyles.Float);
				}
			}
			this.NESelectionStart = this.tBNewValue.SelectionStart;
			if (this.Number > this.MaxValue)
			{
				return false;
			}
			if (this.Number < this.MinValue)
			{
				return false;
			}
			return true;
		}

		private bool CheckUintNumber()
		{
			string numberDecimalSeparator = Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;
			char[] separator = new char[1]
			{
				numberDecimalSeparator[0]
			};
			string[] array = this.tBNewValue.Text.Split(separator, 2);
			if (array.Length > 1 && array[1].Length > this.DecimalNum)
			{
				this.OldText = this.tBNewValue.Text.Remove(this.tBNewValue.Text.Length - (array[1].Length - this.DecimalNum), array[1].Length - this.DecimalNum);
				this.tBNewValue.Text = this.OldText;
				if (this.NESelectionStart < this.OldText.Length)
				{
					this.NESelectionStart++;
				}
				this.tBNewValue.SelectionStart = this.NESelectionStart;
				if (this.tBNewValue.Text == numberDecimalSeparator)
				{
					this.UintNumber = 0u;
				}
				else
				{
					this.UintNumber = uint.Parse(this.tBNewValue.Text);
				}
			}
			this.NESelectionStart = this.tBNewValue.SelectionStart;
			if (this.UintNumber > this.UintMaxValue)
			{
				return false;
			}
			if (this.UintNumber < this.UintMinValue)
			{
				return false;
			}
			return true;
		}

		private void tBNewValue_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode != Keys.Left && e.KeyCode != Keys.Right)
			{
				return;
			}
			this.NESelectionStart = this.tBNewValue.SelectionStart;
		}

		private void tBNewValue_MouseDown(object sender, MouseEventArgs e)
		{
			this.NESelectionStart = this.tBNewValue.SelectionStart;
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (msg.WParam.ToInt32() == 27)
			{
				base.Close();
			}
			else if (msg.WParam.ToInt32() == 13)
			{
				this.btApply_Click(null, EventArgs.Empty);
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}
	}
}
