using System.Collections.Generic;

namespace Visualisation
{
	public class ErrorLogProcessVisuClass
	{
		public List<int> ErrorList = new List<int>();

		private MainForm Main;

		private int currentErrorIndex = -1;

		public ErrorLogProcessVisuClass(MainForm main)
		{
			this.Main = main;
			this.ErrorList.Add(1000);
			this.ErrorList.Add(1001);
			this.ErrorList.Add(1002);
			this.ErrorList.Add(1003);
			this.ErrorList.Add(1004);
			this.ErrorList.Add(1005);
			this.ErrorList.Add(1006);
			this.ErrorList.Add(1007);
			this.ErrorList.Add(1008);
			this.ErrorList.Add(1009);
			this.ErrorList.Add(1010);
			this.ErrorList.Add(1011);
			this.ErrorList.Add(1012);
			this.ErrorList.Add(1013);
			this.ErrorList.Add(1014);
			this.ErrorList.Add(1015);
			this.ErrorList.Add(1016);
			this.ErrorList.Add(1017);
			this.ErrorList.Add(1018);
			this.ErrorList.Add(1019);
			this.ErrorList.Add(1020);
			this.ErrorList.Add(1021);
			this.ErrorList.Add(1022);
			this.ErrorList.Add(1023);
			this.ErrorList.Add(1024);
			this.ErrorList.Add(1025);
			this.ErrorList.Add(1026);
			this.ErrorList.Add(1027);
			this.ErrorList.Add(1028);
			this.ErrorList.Add(1029);
			this.ErrorList.Add(1030);
			this.ErrorList.Add(1031);
			this.ErrorList.Add(1032);
			this.ErrorList.Add(1033);
			this.ErrorList.Add(1034);
			this.ErrorList.Add(1035);
			this.ErrorList.Add(1036);
			this.ErrorList.Add(1037);
			this.ErrorList.Add(1038);
			this.ErrorList.Add(1100);
			this.ErrorList.Add(1101);
			this.ErrorList.Add(1102);
			this.ErrorList.Add(1110);
			this.ErrorList.Add(1111);
			this.ErrorList.Add(1112);
			this.ErrorList.Add(1113);
			this.ErrorList.Add(1114);
			this.ErrorList.Add(1140);
			this.ErrorList.Add(1141);
			this.ErrorList.Add(1150);
			this.ErrorList.Add(1151);
			this.ErrorList.Add(1152);
			this.ErrorList.Add(1153);
			this.ErrorList.Add(1160);
			this.ErrorList.Add(1161);
			this.ErrorList.Add(1162);
			this.ErrorList.Add(1163);
			this.ErrorList.Add(1200);
			this.ErrorList.Add(1201);
			this.ErrorList.Add(1202);
			this.ErrorList.Add(1203);
			this.ErrorList.Add(1301);
			this.ErrorList.Add(1302);
			this.ErrorList.Add(1303);
			this.ErrorList.Add(1304);
			this.ErrorList.Add(1305);
			this.ErrorList.Add(1400);
			this.ErrorList.Add(1401);
			this.ErrorList.Add(1402);
			this.ErrorList.Add(1403);
			this.ErrorList.Add(1404);
			this.ErrorList.Add(1405);
			this.ErrorList.Add(1406);
			this.ErrorList.Add(1407);
			this.ErrorList.Add(1600);
			this.ErrorList.Add(1601);
			this.ErrorList.Add(1602);
			this.ErrorList.Add(1450);
			this.ErrorList.Add(1451);
			this.ErrorList.Add(2000);
			this.ErrorList.Add(2001);
			this.ErrorList.Add(2002);
			this.ErrorList.Add(2003);
			this.ErrorList.Add(2004);
			this.ErrorList.Add(2005);
			this.ErrorList.Add(2006);
			this.ErrorList.Add(2007);
			this.ErrorList.Add(2008);
			this.ErrorList.Add(2009);
			this.ErrorList.Add(2010);
			this.ErrorList.Add(2011);
			this.ErrorList.Add(2012);
			this.ErrorList.Add(2013);
			this.ErrorList.Add(2014);
			this.ErrorList.Add(2015);
			this.ErrorList.Add(2016);
			this.ErrorList.Add(2017);
			this.ErrorList.Add(2018);
			this.ErrorList.Add(2019);
			this.ErrorList.Add(2020);
			this.ErrorList.Add(2021);
			this.ErrorList.Add(2022);
			this.ErrorList.Add(2025);
			this.ErrorList.Add(2026);
			this.ErrorList.Add(2029);
			this.ErrorList.Add(2030);
			this.ErrorList.Add(2100);
			this.ErrorList.Add(5000);
		}

		public string TextOf(int id)
		{
			return this.Main.Rm.GetString("Error" + id.ToString());
		}

		public int GetNextErrorId(bool first)
		{
			if (first)
			{
				this.currentErrorIndex = 0;
			}
			else
			{
				this.currentErrorIndex++;
			}
			if (this.currentErrorIndex >= this.ErrorList.Count)
			{
				return -1;
			}
			return this.ErrorList[this.currentErrorIndex];
		}
	}
}
