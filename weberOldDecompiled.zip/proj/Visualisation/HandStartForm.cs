using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class HandStartForm : Form
	{
		private MainForm Main;

		private uint ActualProgStorageNumber;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Container components;

		private Button bt5;

		private Button btBrowser;

		private Button bt4;

		private Button bt2;

		private Button btStartFrictionTest;

		private DataGridView dGVPrograms;

		private Button btStart;

		public HandStartForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.dGVPrograms.Columns.Add("Col1", "SpNr");
			this.dGVPrograms.Columns.Add("Col2", "PrgNr");
			this.dGVPrograms.Columns.Add("Col3", "Name");
			this.dGVPrograms.Columns.Add("Col4", "Steps");
			this.dGVPrograms.Rows.Add(1023);
			this.ActualProgStorageNumber = 1u;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.bt5 = new Button();
			this.btBrowser = new Button();
			this.btHelp = new Button();
			this.bt4 = new Button();
			this.btStart = new Button();
			this.btBack = new Button();
			this.btStartFrictionTest = new Button();
			this.bt2 = new Button();
			this.dGVPrograms = new DataGridView();
			this.pnMenu.SuspendLayout();
			((ISupportInitialize)this.dGVPrograms).BeginInit();
			base.SuspendLayout();
			this.pnMenu.Controls.Add(this.bt5);
			this.pnMenu.Controls.Add(this.btBrowser);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.bt4);
			this.pnMenu.Controls.Add(this.btStart);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Controls.Add(this.btStartFrictionTest);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.bt5.Enabled = false;
			this.bt5.Location = new Point(3, 451);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(74, 62);
			this.bt5.TabIndex = 7;
			this.btBrowser.Enabled = false;
			this.btBrowser.Location = new Point(3, 323);
			this.btBrowser.Name = "btBrowser";
			this.btBrowser.Size = new Size(74, 62);
			this.btBrowser.TabIndex = 5;
			this.btBrowser.Click += this.btBrowser_Click;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.bt4.Enabled = false;
			this.bt4.Location = new Point(3, 387);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(74, 62);
			this.bt4.TabIndex = 6;
			this.btStart.Location = new Point(3, 131);
			this.btStart.Name = "btStart";
			this.btStart.Size = new Size(74, 62);
			this.btStart.TabIndex = 2;
			this.btStart.Text = "Programm starten";
			this.btStart.Click += this.btStart_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.btStartFrictionTest.Location = new Point(3, 195);
			this.btStartFrictionTest.Name = "btStartFrictionTest";
			this.btStartFrictionTest.Size = new Size(74, 62);
			this.btStartFrictionTest.TabIndex = 3;
			this.btStartFrictionTest.Text = "Reibwert-test starten";
			this.btStartFrictionTest.Click += this.btStartFrictionTest_Click;
			this.bt2.Enabled = false;
			this.bt2.Location = new Point(3, 259);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 4;
			this.dGVPrograms.AllowUserToAddRows = false;
			this.dGVPrograms.AllowUserToDeleteRows = false;
			this.dGVPrograms.AllowUserToResizeRows = false;
			this.dGVPrograms.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dGVPrograms.Location = new Point(0, 0);
			this.dGVPrograms.MultiSelect = false;
			this.dGVPrograms.Name = "dGVPrograms";
			this.dGVPrograms.ReadOnly = true;
			this.dGVPrograms.RowHeadersVisible = false;
			this.dGVPrograms.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			this.dGVPrograms.Size = new Size(460, 522);
			this.dGVPrograms.TabIndex = 2;
			this.dGVPrograms.SelectionChanged += this.dGVPrograms_SelectionChanged;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.dGVPrograms);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "HandStartForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "HandStartForm";
			base.Activated += this.HandStartForm_Activated;
			this.pnMenu.ResumeLayout(false);
			((ISupportInitialize)this.dGVPrograms).EndInit();
			base.ResumeLayout(false);
		}

		public bool ShowWindow()
		{
			if (!this.Main.IsOnlineMode)
			{
				base.Show();
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadProgramData"));
			if (!this.Main.VC.ReceiveVarBlock(15))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive ProcessInfoBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.MenEna();
			base.Show();
			this.UpdateMenu();
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			return true;
		}

		private void MenEna()
		{
			bool enabled = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_HandStartForm)
			{
				enabled = true;
			}
			if (!this.Main.Usb_Key_Access())
			{
				enabled = true;
			}
			else
			{
				this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_HandStartForm, false);
			}
			this.btStart.Enabled = enabled;
			this.btStartFrictionTest.Enabled = enabled;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MHandStart");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btStart.Text = this.Main.Rm.GetString("StartProgram");
			this.btStartFrictionTest.Text = this.Main.Rm.GetString("StartFrictionTest");
			this.dGVPrograms.Columns[0].HeaderText = this.Main.Rm.GetString("StorageNumber");
			this.dGVPrograms.Columns[1].HeaderText = this.Main.Rm.GetString("ProgramNumber");
			this.dGVPrograms.Columns[2].HeaderText = this.Main.Rm.GetString("Name");
			this.dGVPrograms.Columns[3].HeaderText = this.Main.Rm.GetString("Steps");
		}

		public void UpdateMenu()
		{
			int num = 0;
			int index = 0;
			int num2 = -1;
			try
			{
				index = this.dGVPrograms.SelectedRows[0].Index;
			}
			catch
			{
			}
			this.dGVPrograms.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			this.dGVPrograms.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			this.dGVPrograms.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			this.dGVPrograms.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			for (int i = 1; i < 1024; i++)
			{
				if (this.Main.VC.ProcessInfo.ProgInfo[i].Steps > 0)
				{
					num++;
				}
			}
			this.dGVPrograms.Rows.Clear();
			if (num > 0)
			{
				this.dGVPrograms.Rows.Add(num);
			}
			for (int j = 1; j < 1024; j++)
			{
				if (this.Main.VC.ProcessInfo.ProgInfo[j].Steps != 0)
				{
					num2++;
					this.dGVPrograms.Rows[num2].Cells[0].Value = j;
					this.dGVPrograms.Rows[num2].Cells[1].Value = this.Main.VC.ProcessInfo.ProgInfo[j].ProgNum;
					this.dGVPrograms.Rows[num2].Cells[2].Value = this.Main.CommonFunctions.UShortToString(this.Main.VC.ProcessInfo.ProgInfo[j].Name);
					this.dGVPrograms.Rows[num2].Cells[3].Value = this.Main.VC.ProcessInfo.ProgInfo[j].Steps;
				}
			}
			this.dGVPrograms.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			this.dGVPrograms.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			this.dGVPrograms.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
			this.dGVPrograms.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			try
			{
				this.dGVPrograms.Rows[index].Selected = true;
			}
			catch
			{
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_4_Handstart";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_4_Handstart");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btStart_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.StartProgram();
			}
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
			this.BrowserShow();
		}

		private void StartProgram()
		{
			if (this.dGVPrograms.SelectedRows.Count == 0 || (byte)this.dGVPrograms.SelectedRows[0].Cells[3].Value <= 0)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbEmptyProgram"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.pnMenu.Enabled = false;
				base.Hide();
			}
			else
			{
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("AccessCheck"));
				if (!this.Main.VC.ReceiveVarBlock(0))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show("Could not receive Status0Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else if (this.Main.VC.Status0.AutoMode == 1)
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Main.Rm.GetString("MbAutomaticIsActive1"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else if (this.Main.VC.Status0.OwnerID1 != 0 || this.Main.VC.Status0.OwnerID2 != 0 || this.Main.VC.Status0.ParameterMode != 0 || this.Main.VC.Status0.TestMode != 0)
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Main.Rm.GetString("MbAccessByAnother") + " " + this.Main.Rm.GetString("MbAddNoManual"), this.Main.Rm.GetString("MbhViewOnlyMode"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.Main.StatusBarText(this.Main.Rm.GetString("CheckHandStart"));
					if (!this.Main.VC.ReceiveVarBlock(50))
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						MessageBox.Show("Could not receive ManualStartControlBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else if (this.Main.VC.ManualStartControl.Command == 0)
					{
						this.Main.VC.ManualStartControl.Command = 1;
						this.Main.VC.ManualStartControl.ProgNum = (uint)this.dGVPrograms.SelectedRows[0].Cells[1].Value;
						this.Main.StatusBarText(this.Main.Rm.GetString("HandStartIsInitiated"));
						if (!this.Main.VC.SendVarBlock(50))
						{
							Cursor.Current = Cursors.Default;
							this.Main.StatusBarText(string.Empty);
							MessageBox.Show("Could not send ManualStartControlBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						else
						{
							Cursor.Current = Cursors.Default;
							this.Main.StatusBarText(string.Empty);
							this.pnMenu.Enabled = false;
							base.Hide();
						}
					}
					else
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						MessageBox.Show(this.Main.Rm.GetString("MbHandstartNotTwice"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
			}
		}

		public void SimulateFrictionTest()
		{
			this.btStartFrictionTest_Click(null, EventArgs.Empty);
		}

		private void btStartFrictionTest_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("AccessCheck"));
				if (!this.Main.VC.ReceiveVarBlock(0))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show("Could not receive Status0Block!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else if (this.Main.VC.Status0.AutoMode == 1)
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Main.Rm.GetString("MbAutomaticIsActive1"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else if (this.Main.VC.Status0.OwnerID1 != 0 || this.Main.VC.Status0.OwnerID2 != 0 || this.Main.VC.Status0.ParameterMode != 0 || this.Main.VC.Status0.TestMode != 0)
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Main.Rm.GetString("MbAccessByAnother") + " " + this.Main.Rm.GetString("MbAddNoFrictionTest"), this.Main.Rm.GetString("MbhViewOnlyMode"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					Cursor.Current = Cursors.WaitCursor;
					this.Main.StatusBarText(this.Main.Rm.GetString("CheckFrictionTestStart"));
					if (!this.Main.VC.ReceiveVarBlock(50))
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						MessageBox.Show("Could not receive ManualStartControlBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else if (this.Main.VC.ManualStartControl.Command == 0)
					{
						this.Main.VC.ManualStartControl.Command = 1;
						this.Main.VC.ManualStartControl.ProgNum = 0u;
						this.Main.StatusBarText(this.Main.Rm.GetString("HandStartIsInitiated"));
						if (!this.Main.VC.SendVarBlock(50))
						{
							Cursor.Current = Cursors.Default;
							this.Main.StatusBarText(string.Empty);
							MessageBox.Show("Could not send ManualStartControlBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						else
						{
							Cursor.Current = Cursors.Default;
							this.Main.StatusBarText(string.Empty);
							this.pnMenu.Enabled = false;
							base.Hide();
						}
					}
					else
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						MessageBox.Show(this.Main.Rm.GetString("MbHandstartIsActive"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
			}
		}

		private void HandStartForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void dGVPrograms_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			this.StartProgram();
		}

		private void dGVPrograms_SelectionChanged(object sender, EventArgs e)
		{
			try
			{
				this.ActualProgStorageNumber = (uint)this.dGVPrograms.SelectedRows[0].Cells[1].Value;
			}
			catch
			{
			}
		}

		public void KeyArrived()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}
	}
}
