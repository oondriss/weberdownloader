using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class MenuStatisticsForm : Form
	{
		private MainForm Main;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Container components;

		private Button btCycleCounter;

		private Button bt1;

		private Button bt3;

		private Button bt4;

		private Button btBrowser;

		private Button btLastResults;

		public MenuStatisticsForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btBrowser = new Button();
			this.bt4 = new Button();
			this.bt3 = new Button();
			this.btCycleCounter = new Button();
			this.bt1 = new Button();
			this.btLastResults = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.pnMenu.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btBrowser);
			this.pnMenu.Controls.Add(this.bt4);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.btCycleCounter);
			this.pnMenu.Controls.Add(this.bt1);
			this.pnMenu.Controls.Add(this.btLastResults);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btBrowser.Enabled = false;
			this.btBrowser.Location = new Point(3, 323);
			this.btBrowser.Name = "btBrowser";
			this.btBrowser.Size = new Size(74, 62);
			this.btBrowser.TabIndex = 10;
			this.btBrowser.Click += this.btBrowser_Click;
			this.bt4.Enabled = false;
			this.bt4.Location = new Point(3, 451);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(74, 62);
			this.bt4.TabIndex = 7;
			this.bt3.Enabled = false;
			this.bt3.Location = new Point(3, 387);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 6;
			this.btCycleCounter.Location = new Point(3, 195);
			this.btCycleCounter.Name = "btCycleCounter";
			this.btCycleCounter.Size = new Size(74, 62);
			this.btCycleCounter.TabIndex = 3;
			this.btCycleCounter.Text = "Zykluszähler";
			this.btCycleCounter.Click += this.btCycleCounter_Click;
			this.bt1.Enabled = false;
			this.bt1.Location = new Point(3, 259);
			this.bt1.Name = "bt1";
			this.bt1.Size = new Size(74, 62);
			this.bt1.TabIndex = 4;
			this.btLastResults.Location = new Point(3, 131);
			this.btLastResults.Name = "btLastResults";
			this.btLastResults.Size = new Size(74, 62);
			this.btLastResults.TabIndex = 2;
			this.btLastResults.Text = "Die letzten Ergebnisse";
			this.btLastResults.Click += this.btLastResults_Click;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "MenuStatisticsForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Auswertung/Statistik";
			base.Activated += this.MenuStatisticsForm_Activated;
			this.pnMenu.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public bool ShowWindow()
		{
			this.btBrowser.Enabled = Settings.Default.IntegratedMachineVisu;
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadProcessInfo"));
			if (!this.Main.VC.ReceiveVarBlock(15))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive ProcessInfoBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Cursor.Current = Cursors.Default;
			this.Main.StatusBarText(string.Empty);
			base.Show();
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuAnalysis") + "/" + this.Main.Rm.GetString("MenuStatistics");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btCycleCounter.Text = this.Main.Rm.GetString("CycleCounter");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btLastResults.Text = this.Main.Rm.GetString("LastResults");
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.Main.ResetPasscodeLevel();
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_2_3_Statistik";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_2_3_Statistik");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btLastResults_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.StatisticsLastRes1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void btCycleCounter_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.CycleCounter1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void MenuStatisticsForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.Main.ShowCurrentUserAccessState(0, false);
			this.btBack.Select();
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
			this.BrowserShow();
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}
	}
}
