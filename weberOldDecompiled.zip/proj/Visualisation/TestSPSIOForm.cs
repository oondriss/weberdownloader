using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class TestSPSIOForm : Form
	{
		private MainForm Main;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Button bt6;

		private Button bt5;

		private Timer timerUpdate;

		private GroupBox gBInputs;

		private Label lbAutomatic;

		private Label lbShowAutomatic;

		private Label lbShowInputProgram;

		private Label lbShowStart;

		private Label lbStart;

		private Label lbShowQuit;

		private Label lbQuit;

		private Label lbShowCalDisable;

		private Label lbCalDisable;

		private Label lbShowInputSync1;

		private Label lbInputSync1;

		private Label lbShowInputSync2;

		private Label lbInputSync2;

		private GroupBox gBOutputs;

		private Label lbShowOutputSync2;

		private Label lbOutputSync2;

		private Label lbShowOutputSync1;

		private Label lbOutputSync1;

		private Label lbShowSystemOk;

		private Label lbSystemOk;

		private Label lbShowProcessRunning;

		private Label lbProcessRunning;

		private Label lbShowReadyToStart;

		private Label lbReadyToStart;

		private Label lbShowNIO;

		private Label lbNIO;

		private Label lbShowIO;

		private Label lbIO;

		private GroupBox gBResults;

		private Label lbShowValid;

		private Label lbValid;

		private Label lbShowLastStep;

		private Label lbLastStep;

		private Label lbShowTime;

		private Label lbTime;

		private Label lbShowScrewDuration;

		private Label lbScrewDuration;

		private Label lbShowIONIO;

		private Label lbIONIO;

		private Label lbShowResultProgram;

		private Label lbResultProgram;

		private Label lbShowCycle;

		private Label lbCycle;

		private Label lbShowKind3;

		private Label lbResult3;

		private Label lbShowKind2;

		private Label lbResult2;

		private Label lbShowKind1;

		private Label lbResult1;

		private Label lbShowRes3;

		private Label lbShowRes2;

		private Label lbShowRes1;

		private Label lbShowStep3;

		private Label lbShowStep2;

		private Label lbShowStep1;

		private Label lbResultKind;

		private Label lbResultNum;

		private Label lbResultStep;

		private GroupBox gBErrors;

		private Label lbWarning;

		private Label lbShowErrorNum;

		private Label lbErrorNum;

		private Label lbShowWarning;

		private Label lbInputProgram;

		private Label lbShowPowerEnabled;

		private Label lbPowerEnabled;

		private GroupBox gBProcessSignals;

		private Label lbShowTM2;

		private Label lbShowTM1;

		private Label lbTM1;

		private Label lbShowExtDig;

		private Label lbExtDig;

		private Label lbShowExtAna;

		private Label lbExtAna;

		private Label lbShowAnaDepth;

		private Label lbAnaDepth;

		private Label lbTM2;

		private Label lbShowLInVoltage;

		private Label lbUnitMilimeter;

		private Label lbUnitVoltage;

		private Label lbUnitSecond;

		private Label lbTeach;

		private Label lbInputScrewID;

		private Label lbShowTeach;

		private Label lbShowInputScrewID;

		private Label lbResultScrewID;

		private Label lbShowResultScrewID;

		private Label lbShowStorageSignals;

		private Label lbStorageSignals;

		private Label lbShowLivingSignI;

		private Label lbLivingSignI;

		private Label lbShowLivingSignO;

		private Label lbLivingSignO;

		private Label lbShowLivingMonitor;

		private Label lbLivingMonitor;

		private Label lbShowUser;

		private Label lbUser;

		private Label lbResSigOut;

		private Label lbResSigIn;

		private Label lbShowResSigOut;

		private Label lbShowResSigIn;

		private Button btBrowser;

		private Label lbShowInputPointName;

		private Label lbName;

		private Label lbShowHoderPressure;

		private Label lbHolderPressure;

		private Label lbShowSpindlePressure;

		private Label lbSpindlePressure;

		private Button btPLCInterface;

		private Button btMotorSensor;

		private Button btIOTest;

		private Label lbCounterElapsed;

		private Label lbCtElapsed;

		private Label lbCounterWarning;

		private Label lbCtWarning;

		private IContainer components;

		public TestSPSIOForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.timerUpdate.Interval = 500;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			this.pnMenu = new Panel();
			this.btPLCInterface = new Button();
			this.btMotorSensor = new Button();
			this.btIOTest = new Button();
			this.btBrowser = new Button();
			this.bt6 = new Button();
			this.bt5 = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.timerUpdate = new Timer(this.components);
			this.gBInputs = new GroupBox();
			this.lbShowInputPointName = new Label();
			this.lbName = new Label();
			this.lbShowLivingSignI = new Label();
			this.lbLivingSignI = new Label();
			this.lbShowInputScrewID = new Label();
			this.lbShowTeach = new Label();
			this.lbInputScrewID = new Label();
			this.lbTeach = new Label();
			this.lbShowInputSync2 = new Label();
			this.lbInputSync2 = new Label();
			this.lbShowInputSync1 = new Label();
			this.lbInputSync1 = new Label();
			this.lbShowCalDisable = new Label();
			this.lbCalDisable = new Label();
			this.lbShowQuit = new Label();
			this.lbQuit = new Label();
			this.lbShowStart = new Label();
			this.lbStart = new Label();
			this.lbShowInputProgram = new Label();
			this.lbInputProgram = new Label();
			this.lbShowAutomatic = new Label();
			this.lbAutomatic = new Label();
			this.gBOutputs = new GroupBox();
			this.lbShowHoderPressure = new Label();
			this.lbHolderPressure = new Label();
			this.lbShowSpindlePressure = new Label();
			this.lbSpindlePressure = new Label();
			this.lbShowUser = new Label();
			this.lbUser = new Label();
			this.lbShowLivingMonitor = new Label();
			this.lbShowLivingSignO = new Label();
			this.lbLivingMonitor = new Label();
			this.lbLivingSignO = new Label();
			this.lbShowStorageSignals = new Label();
			this.lbStorageSignals = new Label();
			this.lbShowOutputSync2 = new Label();
			this.lbOutputSync2 = new Label();
			this.lbShowOutputSync1 = new Label();
			this.lbOutputSync1 = new Label();
			this.lbShowSystemOk = new Label();
			this.lbSystemOk = new Label();
			this.lbShowProcessRunning = new Label();
			this.lbProcessRunning = new Label();
			this.lbShowReadyToStart = new Label();
			this.lbReadyToStart = new Label();
			this.lbShowNIO = new Label();
			this.lbNIO = new Label();
			this.lbShowIO = new Label();
			this.lbIO = new Label();
			this.lbShowPowerEnabled = new Label();
			this.lbPowerEnabled = new Label();
			this.gBResults = new GroupBox();
			this.lbShowResultScrewID = new Label();
			this.lbResultScrewID = new Label();
			this.lbUnitSecond = new Label();
			this.lbResultStep = new Label();
			this.lbResultNum = new Label();
			this.lbResultKind = new Label();
			this.lbShowStep3 = new Label();
			this.lbShowStep2 = new Label();
			this.lbShowStep1 = new Label();
			this.lbShowRes3 = new Label();
			this.lbShowRes2 = new Label();
			this.lbShowRes1 = new Label();
			this.lbShowKind3 = new Label();
			this.lbResult3 = new Label();
			this.lbShowKind2 = new Label();
			this.lbResult2 = new Label();
			this.lbShowKind1 = new Label();
			this.lbResult1 = new Label();
			this.lbShowValid = new Label();
			this.lbValid = new Label();
			this.lbShowLastStep = new Label();
			this.lbLastStep = new Label();
			this.lbShowTime = new Label();
			this.lbTime = new Label();
			this.lbShowScrewDuration = new Label();
			this.lbScrewDuration = new Label();
			this.lbShowIONIO = new Label();
			this.lbIONIO = new Label();
			this.lbShowResultProgram = new Label();
			this.lbResultProgram = new Label();
			this.lbShowCycle = new Label();
			this.lbCycle = new Label();
			this.gBErrors = new GroupBox();
			this.lbShowWarning = new Label();
			this.lbWarning = new Label();
			this.lbShowErrorNum = new Label();
			this.lbErrorNum = new Label();
			this.gBProcessSignals = new GroupBox();
			this.lbResSigOut = new Label();
			this.lbResSigIn = new Label();
			this.lbShowResSigOut = new Label();
			this.lbShowResSigIn = new Label();
			this.lbUnitVoltage = new Label();
			this.lbUnitMilimeter = new Label();
			this.lbShowLInVoltage = new Label();
			this.lbShowTM2 = new Label();
			this.lbTM2 = new Label();
			this.lbShowTM1 = new Label();
			this.lbTM1 = new Label();
			this.lbShowExtDig = new Label();
			this.lbExtDig = new Label();
			this.lbShowExtAna = new Label();
			this.lbExtAna = new Label();
			this.lbShowAnaDepth = new Label();
			this.lbAnaDepth = new Label();
			this.lbCounterElapsed = new Label();
			this.lbCtElapsed = new Label();
			this.lbCounterWarning = new Label();
			this.lbCtWarning = new Label();
			this.pnMenu.SuspendLayout();
			this.gBInputs.SuspendLayout();
			this.gBOutputs.SuspendLayout();
			this.gBResults.SuspendLayout();
			this.gBErrors.SuspendLayout();
			this.gBProcessSignals.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btPLCInterface);
			this.pnMenu.Controls.Add(this.btMotorSensor);
			this.pnMenu.Controls.Add(this.btIOTest);
			this.pnMenu.Controls.Add(this.btBrowser);
			this.pnMenu.Controls.Add(this.bt6);
			this.pnMenu.Controls.Add(this.bt5);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btPLCInterface.Enabled = false;
			this.btPLCInterface.Location = new Point(3, 259);
			this.btPLCInterface.Name = "btPLCInterface";
			this.btPLCInterface.Size = new Size(74, 62);
			this.btPLCInterface.TabIndex = 10;
			this.btPLCInterface.Text = "SPS I/O";
			this.btMotorSensor.Location = new Point(3, 131);
			this.btMotorSensor.Name = "btMotorSensor";
			this.btMotorSensor.Size = new Size(74, 62);
			this.btMotorSensor.TabIndex = 8;
			this.btMotorSensor.Text = "Motor Reibwert Sensor";
			this.btMotorSensor.Click += this.btMotorSensor_Click;
			this.btIOTest.Location = new Point(3, 195);
			this.btIOTest.Name = "btIOTest";
			this.btIOTest.Size = new Size(74, 62);
			this.btIOTest.TabIndex = 9;
			this.btIOTest.Text = "I/O";
			this.btIOTest.Click += this.btIOTest_Click;
			this.btBrowser.Enabled = false;
			this.btBrowser.Location = new Point(3, 323);
			this.btBrowser.Name = "btBrowser";
			this.btBrowser.Size = new Size(74, 62);
			this.btBrowser.TabIndex = 5;
			this.btBrowser.Click += this.btBrowser_Click;
			this.bt6.Enabled = false;
			this.bt6.Location = new Point(3, 451);
			this.bt6.Name = "bt6";
			this.bt6.Size = new Size(74, 62);
			this.bt6.TabIndex = 7;
			this.bt5.Enabled = false;
			this.bt5.Location = new Point(3, 387);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(74, 62);
			this.bt5.TabIndex = 6;
			// this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.timerUpdate.Interval = 1000;
			this.timerUpdate.Tick += this.timerUpdate_Tick;
			this.gBInputs.Controls.Add(this.lbShowInputPointName);
			this.gBInputs.Controls.Add(this.lbName);
			this.gBInputs.Controls.Add(this.lbShowLivingSignI);
			this.gBInputs.Controls.Add(this.lbLivingSignI);
			this.gBInputs.Controls.Add(this.lbShowInputScrewID);
			this.gBInputs.Controls.Add(this.lbShowTeach);
			this.gBInputs.Controls.Add(this.lbInputScrewID);
			this.gBInputs.Controls.Add(this.lbTeach);
			this.gBInputs.Controls.Add(this.lbShowInputSync2);
			this.gBInputs.Controls.Add(this.lbInputSync2);
			this.gBInputs.Controls.Add(this.lbShowInputSync1);
			this.gBInputs.Controls.Add(this.lbInputSync1);
			this.gBInputs.Controls.Add(this.lbShowCalDisable);
			this.gBInputs.Controls.Add(this.lbCalDisable);
			this.gBInputs.Controls.Add(this.lbShowQuit);
			this.gBInputs.Controls.Add(this.lbQuit);
			this.gBInputs.Controls.Add(this.lbShowStart);
			this.gBInputs.Controls.Add(this.lbStart);
			this.gBInputs.Controls.Add(this.lbShowInputProgram);
			this.gBInputs.Controls.Add(this.lbInputProgram);
			this.gBInputs.Controls.Add(this.lbShowAutomatic);
			this.gBInputs.Controls.Add(this.lbAutomatic);
			this.gBInputs.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBInputs.Location = new Point(8, 16);
			this.gBInputs.Name = "gBInputs";
			this.gBInputs.Size = new Size(200, 330);
			this.gBInputs.TabIndex = 1;
			this.gBInputs.TabStop = false;
			this.gBInputs.Text = "Eingänge";
			this.lbShowInputPointName.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowInputPointName.Font = new Font("Arial", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbShowInputPointName.Location = new Point(40, 283);
			this.lbShowInputPointName.Name = "lbShowInputPointName";
			this.lbShowInputPointName.Size = new Size(152, 33);
			this.lbShowInputPointName.TabIndex = 21;
			this.lbShowInputPointName.Text = "test";
			this.lbShowInputPointName.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowInputPointName.Visible = false;
			this.lbName.Location = new Point(8, 290);
			this.lbName.Name = "lbName";
			this.lbName.Size = new Size(32, 23);
			this.lbName.TabIndex = 20;
			this.lbName.Text = "Pt";
			this.lbName.TextAlign = ContentAlignment.MiddleLeft;
			this.lbName.Visible = false;
			this.lbShowLivingSignI.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowLivingSignI.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowLivingSignI.Location = new Point(152, 213);
			this.lbShowLivingSignI.Name = "lbShowLivingSignI";
			this.lbShowLivingSignI.Size = new Size(40, 23);
			this.lbShowLivingSignI.TabIndex = 19;
			this.lbShowLivingSignI.Text = "label13";
			this.lbShowLivingSignI.TextAlign = ContentAlignment.MiddleRight;
			this.lbLivingSignI.Location = new Point(8, 213);
			this.lbLivingSignI.Name = "lbLivingSignI";
			this.lbLivingSignI.Size = new Size(136, 23);
			this.lbLivingSignI.TabIndex = 18;
			this.lbLivingSignI.Text = "Living Sign";
			this.lbLivingSignI.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowInputScrewID.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowInputScrewID.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowInputScrewID.Location = new Point(40, 238);
			this.lbShowInputScrewID.Name = "lbShowInputScrewID";
			this.lbShowInputScrewID.Size = new Size(152, 37);
			this.lbShowInputScrewID.TabIndex = 17;
			this.lbShowInputScrewID.Text = "test5678901234567890123456789012";
			this.lbShowInputScrewID.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowTeach.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowTeach.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowTeach.Location = new Point(152, 189);
			this.lbShowTeach.Name = "lbShowTeach";
			this.lbShowTeach.Size = new Size(40, 23);
			this.lbShowTeach.TabIndex = 16;
			this.lbShowTeach.Text = "label13";
			this.lbShowTeach.TextAlign = ContentAlignment.MiddleRight;
			this.lbInputScrewID.Location = new Point(8, 238);
			this.lbInputScrewID.Name = "lbInputScrewID";
			this.lbInputScrewID.Size = new Size(32, 37);
			this.lbInputScrewID.TabIndex = 15;
			this.lbInputScrewID.Text = "ID";
			this.lbInputScrewID.TextAlign = ContentAlignment.MiddleLeft;
			this.lbTeach.Location = new Point(8, 189);
			this.lbTeach.Name = "lbTeach";
			this.lbTeach.Size = new Size(136, 23);
			this.lbTeach.TabIndex = 14;
			this.lbTeach.Text = "Teach Signal";
			this.lbTeach.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowInputSync2.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowInputSync2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowInputSync2.Location = new Point(152, 165);
			this.lbShowInputSync2.Name = "lbShowInputSync2";
			this.lbShowInputSync2.Size = new Size(40, 23);
			this.lbShowInputSync2.TabIndex = 13;
			this.lbShowInputSync2.Text = "label13";
			this.lbShowInputSync2.TextAlign = ContentAlignment.MiddleRight;
			this.lbInputSync2.Location = new Point(8, 165);
			this.lbInputSync2.Name = "lbInputSync2";
			this.lbInputSync2.Size = new Size(136, 23);
			this.lbInputSync2.TabIndex = 12;
			this.lbInputSync2.Text = "Sync2";
			this.lbInputSync2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowInputSync1.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowInputSync1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowInputSync1.Location = new Point(152, 141);
			this.lbShowInputSync1.Name = "lbShowInputSync1";
			this.lbShowInputSync1.Size = new Size(40, 23);
			this.lbShowInputSync1.TabIndex = 11;
			this.lbShowInputSync1.Text = "label11";
			this.lbShowInputSync1.TextAlign = ContentAlignment.MiddleRight;
			this.lbInputSync1.Location = new Point(8, 141);
			this.lbInputSync1.Name = "lbInputSync1";
			this.lbInputSync1.Size = new Size(136, 23);
			this.lbInputSync1.TabIndex = 10;
			this.lbInputSync1.Text = "Sync1";
			this.lbInputSync1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowCalDisable.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowCalDisable.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowCalDisable.Location = new Point(152, 117);
			this.lbShowCalDisable.Name = "lbShowCalDisable";
			this.lbShowCalDisable.Size = new Size(40, 23);
			this.lbShowCalDisable.TabIndex = 9;
			this.lbShowCalDisable.Text = "label9";
			this.lbShowCalDisable.TextAlign = ContentAlignment.MiddleRight;
			this.lbCalDisable.Location = new Point(8, 117);
			this.lbCalDisable.Name = "lbCalDisable";
			this.lbCalDisable.Size = new Size(136, 23);
			this.lbCalDisable.TabIndex = 8;
			this.lbCalDisable.Text = "KalDisable";
			this.lbCalDisable.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowQuit.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowQuit.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowQuit.Location = new Point(152, 93);
			this.lbShowQuit.Name = "lbShowQuit";
			this.lbShowQuit.Size = new Size(40, 23);
			this.lbShowQuit.TabIndex = 7;
			this.lbShowQuit.Text = "label7";
			this.lbShowQuit.TextAlign = ContentAlignment.MiddleRight;
			this.lbQuit.Location = new Point(8, 93);
			this.lbQuit.Name = "lbQuit";
			this.lbQuit.Size = new Size(136, 23);
			this.lbQuit.TabIndex = 6;
			this.lbQuit.Text = "Quitierung";
			this.lbQuit.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowStart.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowStart.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowStart.Location = new Point(152, 69);
			this.lbShowStart.Name = "lbShowStart";
			this.lbShowStart.Size = new Size(40, 23);
			this.lbShowStart.TabIndex = 5;
			this.lbShowStart.Text = "label5";
			this.lbShowStart.TextAlign = ContentAlignment.MiddleRight;
			this.lbStart.Location = new Point(8, 69);
			this.lbStart.Name = "lbStart";
			this.lbStart.Size = new Size(136, 23);
			this.lbStart.TabIndex = 4;
			this.lbStart.Text = "Start";
			this.lbStart.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowInputProgram.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowInputProgram.Font = new Font("Arial Unicode MS", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbShowInputProgram.Location = new Point(152, 45);
			this.lbShowInputProgram.Name = "lbShowInputProgram";
			this.lbShowInputProgram.Size = new Size(40, 23);
			this.lbShowInputProgram.TabIndex = 3;
			this.lbShowInputProgram.Text = "88888888";
			this.lbShowInputProgram.TextAlign = ContentAlignment.MiddleRight;
			this.lbInputProgram.Location = new Point(8, 45);
			this.lbInputProgram.Name = "lbInputProgram";
			this.lbInputProgram.Size = new Size(136, 23);
			this.lbInputProgram.TabIndex = 2;
			this.lbInputProgram.Text = "Programm";
			this.lbInputProgram.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowAutomatic.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowAutomatic.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowAutomatic.Location = new Point(152, 21);
			this.lbShowAutomatic.Name = "lbShowAutomatic";
			this.lbShowAutomatic.Size = new Size(40, 23);
			this.lbShowAutomatic.TabIndex = 1;
			this.lbShowAutomatic.Text = "label2";
			this.lbShowAutomatic.TextAlign = ContentAlignment.MiddleRight;
			this.lbAutomatic.Location = new Point(8, 21);
			this.lbAutomatic.Name = "lbAutomatic";
			this.lbAutomatic.Size = new Size(136, 23);
			this.lbAutomatic.TabIndex = 0;
			this.lbAutomatic.Text = "Automatic";
			this.lbAutomatic.TextAlign = ContentAlignment.MiddleLeft;
			this.gBOutputs.Controls.Add(this.lbShowHoderPressure);
			this.gBOutputs.Controls.Add(this.lbHolderPressure);
			this.gBOutputs.Controls.Add(this.lbShowSpindlePressure);
			this.gBOutputs.Controls.Add(this.lbSpindlePressure);
			this.gBOutputs.Controls.Add(this.lbShowUser);
			this.gBOutputs.Controls.Add(this.lbUser);
			this.gBOutputs.Controls.Add(this.lbShowLivingMonitor);
			this.gBOutputs.Controls.Add(this.lbShowLivingSignO);
			this.gBOutputs.Controls.Add(this.lbLivingMonitor);
			this.gBOutputs.Controls.Add(this.lbLivingSignO);
			this.gBOutputs.Controls.Add(this.lbShowStorageSignals);
			this.gBOutputs.Controls.Add(this.lbStorageSignals);
			this.gBOutputs.Controls.Add(this.lbShowOutputSync2);
			this.gBOutputs.Controls.Add(this.lbOutputSync2);
			this.gBOutputs.Controls.Add(this.lbShowOutputSync1);
			this.gBOutputs.Controls.Add(this.lbOutputSync1);
			this.gBOutputs.Controls.Add(this.lbShowSystemOk);
			this.gBOutputs.Controls.Add(this.lbSystemOk);
			this.gBOutputs.Controls.Add(this.lbShowProcessRunning);
			this.gBOutputs.Controls.Add(this.lbProcessRunning);
			this.gBOutputs.Controls.Add(this.lbShowReadyToStart);
			this.gBOutputs.Controls.Add(this.lbReadyToStart);
			this.gBOutputs.Controls.Add(this.lbShowNIO);
			this.gBOutputs.Controls.Add(this.lbNIO);
			this.gBOutputs.Controls.Add(this.lbShowIO);
			this.gBOutputs.Controls.Add(this.lbIO);
			this.gBOutputs.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBOutputs.Location = new Point(216, 16);
			this.gBOutputs.Name = "gBOutputs";
			this.gBOutputs.Size = new Size(168, 330);
			this.gBOutputs.TabIndex = 2;
			this.gBOutputs.TabStop = false;
			this.gBOutputs.Text = "Ausgänge";
			this.lbShowHoderPressure.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowHoderPressure.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowHoderPressure.Location = new Point(100, 304);
			this.lbShowHoderPressure.Name = "lbShowHoderPressure";
			this.lbShowHoderPressure.Size = new Size(60, 23);
			this.lbShowHoderPressure.TabIndex = 25;
			this.lbShowHoderPressure.Text = "label13";
			this.lbShowHoderPressure.TextAlign = ContentAlignment.MiddleRight;
			this.lbHolderPressure.Font = new Font("Arial Unicode MS", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbHolderPressure.Location = new Point(8, 304);
			this.lbHolderPressure.Name = "lbHolderPressure";
			this.lbHolderPressure.Size = new Size(90, 23);
			this.lbHolderPressure.TabIndex = 24;
			this.lbHolderPressure.Text = "Holder pressure";
			this.lbHolderPressure.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowSpindlePressure.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowSpindlePressure.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowSpindlePressure.Location = new Point(100, 281);
			this.lbShowSpindlePressure.Name = "lbShowSpindlePressure";
			this.lbShowSpindlePressure.Size = new Size(60, 23);
			this.lbShowSpindlePressure.TabIndex = 23;
			this.lbShowSpindlePressure.Text = "label13";
			this.lbShowSpindlePressure.TextAlign = ContentAlignment.MiddleRight;
			this.lbSpindlePressure.Font = new Font("Arial Unicode MS", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbSpindlePressure.Location = new Point(8, 281);
			this.lbSpindlePressure.Name = "lbSpindlePressure";
			this.lbSpindlePressure.Size = new Size(90, 23);
			this.lbSpindlePressure.TabIndex = 22;
			this.lbSpindlePressure.Text = "Spindle pressure";
			this.lbSpindlePressure.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowUser.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowUser.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbShowUser.Location = new Point(100, 259);
			this.lbShowUser.Name = "lbShowUser";
			this.lbShowUser.Size = new Size(60, 23);
			this.lbShowUser.TabIndex = 21;
			this.lbShowUser.Text = "label13";
			this.lbShowUser.TextAlign = ContentAlignment.MiddleRight;
			this.lbUser.Location = new Point(8, 259);
			this.lbUser.Name = "lbUser";
			this.lbUser.Size = new Size(90, 23);
			this.lbUser.TabIndex = 20;
			this.lbUser.Text = "User";
			this.lbUser.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowLivingMonitor.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowLivingMonitor.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowLivingMonitor.Location = new Point(120, 237);
			this.lbShowLivingMonitor.Name = "lbShowLivingMonitor";
			this.lbShowLivingMonitor.Size = new Size(40, 23);
			this.lbShowLivingMonitor.TabIndex = 19;
			this.lbShowLivingMonitor.Text = "label13";
			this.lbShowLivingMonitor.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowLivingSignO.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowLivingSignO.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowLivingSignO.Location = new Point(120, 213);
			this.lbShowLivingSignO.Name = "lbShowLivingSignO";
			this.lbShowLivingSignO.Size = new Size(40, 23);
			this.lbShowLivingSignO.TabIndex = 17;
			this.lbShowLivingSignO.Text = "label13";
			this.lbShowLivingSignO.TextAlign = ContentAlignment.MiddleRight;
			this.lbLivingMonitor.Location = new Point(8, 237);
			this.lbLivingMonitor.Name = "lbLivingMonitor";
			this.lbLivingMonitor.Size = new Size(112, 23);
			this.lbLivingMonitor.TabIndex = 18;
			this.lbLivingMonitor.Text = "Living Monitor";
			this.lbLivingMonitor.TextAlign = ContentAlignment.MiddleLeft;
			this.lbLivingSignO.Location = new Point(8, 213);
			this.lbLivingSignO.Name = "lbLivingSignO";
			this.lbLivingSignO.Size = new Size(112, 23);
			this.lbLivingSignO.TabIndex = 16;
			this.lbLivingSignO.Text = "Living Sign";
			this.lbLivingSignO.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowStorageSignals.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowStorageSignals.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowStorageSignals.Location = new Point(120, 189);
			this.lbShowStorageSignals.Name = "lbShowStorageSignals";
			this.lbShowStorageSignals.Size = new Size(40, 23);
			this.lbShowStorageSignals.TabIndex = 15;
			this.lbShowStorageSignals.Text = "label13";
			this.lbShowStorageSignals.TextAlign = ContentAlignment.MiddleRight;
			this.lbStorageSignals.Location = new Point(8, 189);
			this.lbStorageSignals.Name = "lbStorageSignals";
			this.lbStorageSignals.Size = new Size(112, 23);
			this.lbStorageSignals.TabIndex = 14;
			this.lbStorageSignals.Text = "StorSignals";
			this.lbStorageSignals.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowOutputSync2.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowOutputSync2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowOutputSync2.Location = new Point(120, 165);
			this.lbShowOutputSync2.Name = "lbShowOutputSync2";
			this.lbShowOutputSync2.Size = new Size(40, 23);
			this.lbShowOutputSync2.TabIndex = 13;
			this.lbShowOutputSync2.Text = "label13";
			this.lbShowOutputSync2.TextAlign = ContentAlignment.MiddleRight;
			this.lbOutputSync2.Location = new Point(8, 165);
			this.lbOutputSync2.Name = "lbOutputSync2";
			this.lbOutputSync2.Size = new Size(104, 23);
			this.lbOutputSync2.TabIndex = 12;
			this.lbOutputSync2.Text = "Sync2";
			this.lbOutputSync2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowOutputSync1.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowOutputSync1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowOutputSync1.Location = new Point(120, 141);
			this.lbShowOutputSync1.Name = "lbShowOutputSync1";
			this.lbShowOutputSync1.Size = new Size(40, 23);
			this.lbShowOutputSync1.TabIndex = 11;
			this.lbShowOutputSync1.Text = "label11";
			this.lbShowOutputSync1.TextAlign = ContentAlignment.MiddleRight;
			this.lbOutputSync1.Location = new Point(8, 141);
			this.lbOutputSync1.Name = "lbOutputSync1";
			this.lbOutputSync1.Size = new Size(104, 23);
			this.lbOutputSync1.TabIndex = 10;
			this.lbOutputSync1.Text = "Sync1";
			this.lbOutputSync1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowSystemOk.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowSystemOk.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowSystemOk.Location = new Point(120, 21);
			this.lbShowSystemOk.Name = "lbShowSystemOk";
			this.lbShowSystemOk.Size = new Size(40, 23);
			this.lbShowSystemOk.TabIndex = 9;
			this.lbShowSystemOk.Text = "label9";
			this.lbShowSystemOk.TextAlign = ContentAlignment.MiddleRight;
			this.lbSystemOk.Location = new Point(8, 21);
			this.lbSystemOk.Name = "lbSystemOk";
			this.lbSystemOk.Size = new Size(104, 23);
			this.lbSystemOk.TabIndex = 8;
			this.lbSystemOk.Text = "System OK";
			this.lbSystemOk.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowProcessRunning.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowProcessRunning.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowProcessRunning.Location = new Point(120, 69);
			this.lbShowProcessRunning.Name = "lbShowProcessRunning";
			this.lbShowProcessRunning.Size = new Size(40, 23);
			this.lbShowProcessRunning.TabIndex = 7;
			this.lbShowProcessRunning.Text = "label7";
			this.lbShowProcessRunning.TextAlign = ContentAlignment.MiddleRight;
			this.lbProcessRunning.Location = new Point(8, 69);
			this.lbProcessRunning.Name = "lbProcessRunning";
			this.lbProcessRunning.Size = new Size(104, 23);
			this.lbProcessRunning.TabIndex = 6;
			this.lbProcessRunning.Text = "Prozess running";
			this.lbProcessRunning.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowReadyToStart.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowReadyToStart.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowReadyToStart.Location = new Point(120, 45);
			this.lbShowReadyToStart.Name = "lbShowReadyToStart";
			this.lbShowReadyToStart.Size = new Size(40, 23);
			this.lbShowReadyToStart.TabIndex = 5;
			this.lbShowReadyToStart.Text = "label5";
			this.lbShowReadyToStart.TextAlign = ContentAlignment.MiddleRight;
			this.lbReadyToStart.Location = new Point(8, 45);
			this.lbReadyToStart.Name = "lbReadyToStart";
			this.lbReadyToStart.Size = new Size(104, 23);
			this.lbReadyToStart.TabIndex = 4;
			this.lbReadyToStart.Text = "Startbereit";
			this.lbReadyToStart.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowNIO.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowNIO.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowNIO.Location = new Point(120, 117);
			this.lbShowNIO.Name = "lbShowNIO";
			this.lbShowNIO.Size = new Size(40, 23);
			this.lbShowNIO.TabIndex = 3;
			this.lbShowNIO.Text = "label3";
			this.lbShowNIO.TextAlign = ContentAlignment.MiddleRight;
			this.lbNIO.Location = new Point(8, 117);
			this.lbNIO.Name = "lbNIO";
			this.lbNIO.Size = new Size(104, 23);
			this.lbNIO.TabIndex = 2;
			this.lbNIO.Text = "NIO";
			this.lbNIO.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowIO.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowIO.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowIO.Location = new Point(120, 93);
			this.lbShowIO.Name = "lbShowIO";
			this.lbShowIO.Size = new Size(40, 23);
			this.lbShowIO.TabIndex = 1;
			this.lbShowIO.Text = "label2";
			this.lbShowIO.TextAlign = ContentAlignment.MiddleRight;
			this.lbIO.Location = new Point(8, 93);
			this.lbIO.Name = "lbIO";
			this.lbIO.Size = new Size(104, 23);
			this.lbIO.TabIndex = 0;
			this.lbIO.Text = "IO";
			this.lbIO.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowPowerEnabled.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowPowerEnabled.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowPowerEnabled.Location = new Point(168, 142);
			this.lbShowPowerEnabled.Name = "lbShowPowerEnabled";
			this.lbShowPowerEnabled.Size = new Size(80, 23);
			this.lbShowPowerEnabled.TabIndex = 15;
			this.lbShowPowerEnabled.Text = "label13";
			this.lbShowPowerEnabled.TextAlign = ContentAlignment.MiddleRight;
			this.lbPowerEnabled.Location = new Point(16, 142);
			this.lbPowerEnabled.Name = "lbPowerEnabled";
			this.lbPowerEnabled.Size = new Size(144, 23);
			this.lbPowerEnabled.TabIndex = 14;
			this.lbPowerEnabled.Text = "Steuerspannung";
			this.lbPowerEnabled.TextAlign = ContentAlignment.MiddleLeft;
			this.gBResults.Controls.Add(this.lbShowResultScrewID);
			this.gBResults.Controls.Add(this.lbResultScrewID);
			this.gBResults.Controls.Add(this.lbUnitSecond);
			this.gBResults.Controls.Add(this.lbResultStep);
			this.gBResults.Controls.Add(this.lbResultNum);
			this.gBResults.Controls.Add(this.lbResultKind);
			this.gBResults.Controls.Add(this.lbShowStep3);
			this.gBResults.Controls.Add(this.lbShowStep2);
			this.gBResults.Controls.Add(this.lbShowStep1);
			this.gBResults.Controls.Add(this.lbShowRes3);
			this.gBResults.Controls.Add(this.lbShowRes2);
			this.gBResults.Controls.Add(this.lbShowRes1);
			this.gBResults.Controls.Add(this.lbShowKind3);
			this.gBResults.Controls.Add(this.lbResult3);
			this.gBResults.Controls.Add(this.lbShowKind2);
			this.gBResults.Controls.Add(this.lbResult2);
			this.gBResults.Controls.Add(this.lbShowKind1);
			this.gBResults.Controls.Add(this.lbResult1);
			this.gBResults.Controls.Add(this.lbShowValid);
			this.gBResults.Controls.Add(this.lbValid);
			this.gBResults.Controls.Add(this.lbShowLastStep);
			this.gBResults.Controls.Add(this.lbLastStep);
			this.gBResults.Controls.Add(this.lbShowTime);
			this.gBResults.Controls.Add(this.lbTime);
			this.gBResults.Controls.Add(this.lbShowScrewDuration);
			this.gBResults.Controls.Add(this.lbScrewDuration);
			this.gBResults.Controls.Add(this.lbShowIONIO);
			this.gBResults.Controls.Add(this.lbIONIO);
			this.gBResults.Controls.Add(this.lbShowResultProgram);
			this.gBResults.Controls.Add(this.lbResultProgram);
			this.gBResults.Controls.Add(this.lbShowCycle);
			this.gBResults.Controls.Add(this.lbCycle);
			this.gBResults.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBResults.Location = new Point(392, 16);
			this.gBResults.Name = "gBResults";
			this.gBResults.Size = new Size(312, 392);
			this.gBResults.TabIndex = 3;
			this.gBResults.TabStop = false;
			this.gBResults.Text = "Ergebnisse";
			this.lbShowResultScrewID.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowResultScrewID.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowResultScrewID.Location = new Point(120, 228);
			this.lbShowResultScrewID.Name = "lbShowResultScrewID";
			this.lbShowResultScrewID.Size = new Size(160, 44);
			this.lbShowResultScrewID.TabIndex = 31;
			this.lbShowResultScrewID.Text = "test5678901234567890123456789012";
			this.lbShowResultScrewID.TextAlign = ContentAlignment.MiddleRight;
			this.lbResultScrewID.Location = new Point(16, 237);
			this.lbResultScrewID.Name = "lbResultScrewID";
			this.lbResultScrewID.Size = new Size(104, 23);
			this.lbResultScrewID.TabIndex = 30;
			this.lbResultScrewID.Text = "ID";
			this.lbResultScrewID.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitSecond.Location = new Point(288, 116);
			this.lbUnitSecond.Name = "lbUnitSecond";
			this.lbUnitSecond.Size = new Size(16, 23);
			this.lbUnitSecond.TabIndex = 29;
			this.lbUnitSecond.Text = "s";
			this.lbUnitSecond.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResultStep.Location = new Point(246, 272);
			this.lbResultStep.Name = "lbResultStep";
			this.lbResultStep.Size = new Size(56, 23);
			this.lbResultStep.TabIndex = 28;
			this.lbResultStep.Text = "Stufe";
			this.lbResultStep.TextAlign = ContentAlignment.MiddleCenter;
			this.lbResultNum.Location = new Point(176, 272);
			this.lbResultNum.Name = "lbResultNum";
			this.lbResultNum.Size = new Size(64, 23);
			this.lbResultNum.TabIndex = 27;
			this.lbResultNum.Text = "Zahl";
			this.lbResultNum.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResultKind.Location = new Point(128, 272);
			this.lbResultKind.Name = "lbResultKind";
			this.lbResultKind.Size = new Size(46, 23);
			this.lbResultKind.TabIndex = 26;
			this.lbResultKind.Text = "Art";
			this.lbResultKind.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowStep3.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowStep3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowStep3.Location = new Point(256, 360);
			this.lbShowStep3.Name = "lbShowStep3";
			this.lbShowStep3.Size = new Size(40, 23);
			this.lbShowStep3.TabIndex = 25;
			this.lbShowStep3.Text = "label13";
			this.lbShowStep3.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowStep2.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowStep2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowStep2.Location = new Point(256, 328);
			this.lbShowStep2.Name = "lbShowStep2";
			this.lbShowStep2.Size = new Size(40, 23);
			this.lbShowStep2.TabIndex = 24;
			this.lbShowStep2.Text = "label11";
			this.lbShowStep2.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowStep1.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowStep1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowStep1.Location = new Point(256, 296);
			this.lbShowStep1.Name = "lbShowStep1";
			this.lbShowStep1.Size = new Size(40, 23);
			this.lbShowStep1.TabIndex = 23;
			this.lbShowStep1.Text = "label9";
			this.lbShowStep1.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowRes3.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowRes3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowRes3.Location = new Point(176, 360);
			this.lbShowRes3.Name = "lbShowRes3";
			this.lbShowRes3.Size = new Size(72, 23);
			this.lbShowRes3.TabIndex = 22;
			this.lbShowRes3.Text = "label13";
			this.lbShowRes3.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowRes2.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowRes2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowRes2.Location = new Point(176, 328);
			this.lbShowRes2.Name = "lbShowRes2";
			this.lbShowRes2.Size = new Size(72, 23);
			this.lbShowRes2.TabIndex = 21;
			this.lbShowRes2.Text = "label11";
			this.lbShowRes2.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowRes1.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowRes1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowRes1.Location = new Point(176, 296);
			this.lbShowRes1.Name = "lbShowRes1";
			this.lbShowRes1.Size = new Size(72, 23);
			this.lbShowRes1.TabIndex = 20;
			this.lbShowRes1.Text = "label9";
			this.lbShowRes1.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowKind3.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowKind3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowKind3.Location = new Point(128, 360);
			this.lbShowKind3.Name = "lbShowKind3";
			this.lbShowKind3.Size = new Size(40, 23);
			this.lbShowKind3.TabIndex = 19;
			this.lbShowKind3.Text = "label13";
			this.lbShowKind3.TextAlign = ContentAlignment.MiddleRight;
			this.lbResult3.Location = new Point(16, 360);
			this.lbResult3.Name = "lbResult3";
			this.lbResult3.Size = new Size(100, 23);
			this.lbResult3.TabIndex = 18;
			this.lbResult3.Text = "Ergebnis 3";
			this.lbResult3.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowKind2.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowKind2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowKind2.Location = new Point(128, 328);
			this.lbShowKind2.Name = "lbShowKind2";
			this.lbShowKind2.Size = new Size(40, 23);
			this.lbShowKind2.TabIndex = 17;
			this.lbShowKind2.Text = "label11";
			this.lbShowKind2.TextAlign = ContentAlignment.MiddleRight;
			this.lbResult2.Location = new Point(16, 328);
			this.lbResult2.Name = "lbResult2";
			this.lbResult2.Size = new Size(100, 23);
			this.lbResult2.TabIndex = 16;
			this.lbResult2.Text = "Ergebnis 2";
			this.lbResult2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowKind1.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowKind1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowKind1.Location = new Point(128, 296);
			this.lbShowKind1.Name = "lbShowKind1";
			this.lbShowKind1.Size = new Size(40, 23);
			this.lbShowKind1.TabIndex = 15;
			this.lbShowKind1.Text = "label9";
			this.lbShowKind1.TextAlign = ContentAlignment.MiddleRight;
			this.lbResult1.Location = new Point(16, 296);
			this.lbResult1.Name = "lbResult1";
			this.lbResult1.Size = new Size(100, 23);
			this.lbResult1.TabIndex = 14;
			this.lbResult1.Text = "Ergebnis 1";
			this.lbResult1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowValid.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowValid.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowValid.Location = new Point(224, 200);
			this.lbShowValid.Name = "lbShowValid";
			this.lbShowValid.Size = new Size(56, 23);
			this.lbShowValid.TabIndex = 13;
			this.lbShowValid.Text = "label13";
			this.lbShowValid.TextAlign = ContentAlignment.MiddleRight;
			this.lbValid.Location = new Point(16, 200);
			this.lbValid.Name = "lbValid";
			this.lbValid.Size = new Size(184, 23);
			this.lbValid.TabIndex = 12;
			this.lbValid.Text = "Gültigkeit";
			this.lbValid.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowLastStep.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowLastStep.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowLastStep.Location = new Point(224, 172);
			this.lbShowLastStep.Name = "lbShowLastStep";
			this.lbShowLastStep.Size = new Size(56, 23);
			this.lbShowLastStep.TabIndex = 11;
			this.lbShowLastStep.Text = "label11";
			this.lbShowLastStep.TextAlign = ContentAlignment.MiddleRight;
			this.lbLastStep.Location = new Point(16, 172);
			this.lbLastStep.Name = "lbLastStep";
			this.lbLastStep.Size = new Size(184, 23);
			this.lbLastStep.TabIndex = 10;
			this.lbLastStep.Text = "Lezte Stufe";
			this.lbLastStep.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowTime.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowTime.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowTime.Location = new Point(120, 144);
			this.lbShowTime.Name = "lbShowTime";
			this.lbShowTime.Size = new Size(160, 23);
			this.lbShowTime.TabIndex = 9;
			this.lbShowTime.Text = "label9";
			this.lbShowTime.TextAlign = ContentAlignment.MiddleRight;
			this.lbTime.Location = new Point(16, 144);
			this.lbTime.Name = "lbTime";
			this.lbTime.Size = new Size(104, 23);
			this.lbTime.TabIndex = 8;
			this.lbTime.Text = "Zeit";
			this.lbTime.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowScrewDuration.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowScrewDuration.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowScrewDuration.Location = new Point(224, 116);
			this.lbShowScrewDuration.Name = "lbShowScrewDuration";
			this.lbShowScrewDuration.Size = new Size(56, 23);
			this.lbShowScrewDuration.TabIndex = 7;
			this.lbShowScrewDuration.Text = "label7";
			this.lbShowScrewDuration.TextAlign = ContentAlignment.MiddleRight;
			this.lbScrewDuration.Location = new Point(16, 116);
			this.lbScrewDuration.Name = "lbScrewDuration";
			this.lbScrewDuration.Size = new Size(184, 23);
			this.lbScrewDuration.TabIndex = 6;
			this.lbScrewDuration.Text = "Schraubzeit";
			this.lbScrewDuration.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowIONIO.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowIONIO.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowIONIO.Location = new Point(224, 88);
			this.lbShowIONIO.Name = "lbShowIONIO";
			this.lbShowIONIO.Size = new Size(56, 23);
			this.lbShowIONIO.TabIndex = 5;
			this.lbShowIONIO.Text = "99999";
			this.lbShowIONIO.TextAlign = ContentAlignment.MiddleRight;
			this.lbIONIO.Location = new Point(16, 88);
			this.lbIONIO.Name = "lbIONIO";
			this.lbIONIO.Size = new Size(184, 23);
			this.lbIONIO.TabIndex = 4;
			this.lbIONIO.Text = "IONIO";
			this.lbIONIO.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowResultProgram.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowResultProgram.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowResultProgram.Location = new Point(224, 60);
			this.lbShowResultProgram.Name = "lbShowResultProgram";
			this.lbShowResultProgram.Size = new Size(56, 23);
			this.lbShowResultProgram.TabIndex = 3;
			this.lbShowResultProgram.Text = "label3";
			this.lbShowResultProgram.TextAlign = ContentAlignment.MiddleRight;
			this.lbResultProgram.Location = new Point(16, 60);
			this.lbResultProgram.Name = "lbResultProgram";
			this.lbResultProgram.Size = new Size(184, 23);
			this.lbResultProgram.TabIndex = 2;
			this.lbResultProgram.Text = "Programm";
			this.lbResultProgram.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowCycle.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowCycle.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowCycle.Location = new Point(184, 32);
			this.lbShowCycle.Name = "lbShowCycle";
			this.lbShowCycle.Size = new Size(96, 23);
			this.lbShowCycle.TabIndex = 1;
			this.lbShowCycle.Text = "9999999999";
			this.lbShowCycle.TextAlign = ContentAlignment.MiddleRight;
			this.lbCycle.Location = new Point(16, 32);
			this.lbCycle.Name = "lbCycle";
			this.lbCycle.Size = new Size(128, 23);
			this.lbCycle.TabIndex = 0;
			this.lbCycle.Text = "Zyklus";
			this.lbCycle.TextAlign = ContentAlignment.MiddleLeft;
			this.gBErrors.Controls.Add(this.lbShowWarning);
			this.gBErrors.Controls.Add(this.lbWarning);
			this.gBErrors.Controls.Add(this.lbShowErrorNum);
			this.gBErrors.Controls.Add(this.lbErrorNum);
			this.gBErrors.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBErrors.Location = new Point(392, 416);
			this.gBErrors.Name = "gBErrors";
			this.gBErrors.Size = new Size(216, 96);
			this.gBErrors.TabIndex = 14;
			this.gBErrors.TabStop = false;
			this.gBErrors.Text = "Fehler";
			this.lbShowWarning.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowWarning.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowWarning.Location = new Point(128, 64);
			this.lbShowWarning.Name = "lbShowWarning";
			this.lbShowWarning.Size = new Size(72, 23);
			this.lbShowWarning.TabIndex = 3;
			this.lbShowWarning.Text = "label2";
			this.lbShowWarning.TextAlign = ContentAlignment.MiddleRight;
			this.lbWarning.Location = new Point(16, 64);
			this.lbWarning.Name = "lbWarning";
			this.lbWarning.Size = new Size(100, 23);
			this.lbWarning.TabIndex = 2;
			this.lbWarning.Text = "Warnung";
			this.lbWarning.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowErrorNum.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowErrorNum.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowErrorNum.Location = new Point(128, 32);
			this.lbShowErrorNum.Name = "lbShowErrorNum";
			this.lbShowErrorNum.Size = new Size(72, 23);
			this.lbShowErrorNum.TabIndex = 1;
			this.lbShowErrorNum.Text = "label2";
			this.lbShowErrorNum.TextAlign = ContentAlignment.MiddleRight;
			this.lbErrorNum.Location = new Point(16, 32);
			this.lbErrorNum.Name = "lbErrorNum";
			this.lbErrorNum.Size = new Size(100, 23);
			this.lbErrorNum.TabIndex = 0;
			this.lbErrorNum.Text = "Nummer";
			this.lbErrorNum.TextAlign = ContentAlignment.MiddleLeft;
			this.gBProcessSignals.Controls.Add(this.lbCounterWarning);
			this.gBProcessSignals.Controls.Add(this.lbCtWarning);
			this.gBProcessSignals.Controls.Add(this.lbCounterElapsed);
			this.gBProcessSignals.Controls.Add(this.lbCtElapsed);
			this.gBProcessSignals.Controls.Add(this.lbResSigOut);
			this.gBProcessSignals.Controls.Add(this.lbResSigIn);
			this.gBProcessSignals.Controls.Add(this.lbShowResSigOut);
			this.gBProcessSignals.Controls.Add(this.lbShowResSigIn);
			this.gBProcessSignals.Controls.Add(this.lbUnitVoltage);
			this.gBProcessSignals.Controls.Add(this.lbUnitMilimeter);
			this.gBProcessSignals.Controls.Add(this.lbShowLInVoltage);
			this.gBProcessSignals.Controls.Add(this.lbShowTM2);
			this.gBProcessSignals.Controls.Add(this.lbTM2);
			this.gBProcessSignals.Controls.Add(this.lbShowTM1);
			this.gBProcessSignals.Controls.Add(this.lbTM1);
			this.gBProcessSignals.Controls.Add(this.lbShowExtDig);
			this.gBProcessSignals.Controls.Add(this.lbExtDig);
			this.gBProcessSignals.Controls.Add(this.lbShowExtAna);
			this.gBProcessSignals.Controls.Add(this.lbExtAna);
			this.gBProcessSignals.Controls.Add(this.lbShowAnaDepth);
			this.gBProcessSignals.Controls.Add(this.lbAnaDepth);
			this.gBProcessSignals.Controls.Add(this.lbShowPowerEnabled);
			this.gBProcessSignals.Controls.Add(this.lbPowerEnabled);
			this.gBProcessSignals.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBProcessSignals.Location = new Point(8, 344);
			this.gBProcessSignals.Name = "gBProcessSignals";
			this.gBProcessSignals.Size = new Size(376, 167);
			this.gBProcessSignals.TabIndex = 14;
			this.gBProcessSignals.TabStop = false;
			this.gBProcessSignals.Text = "Process signals";
			this.lbResSigOut.Enabled = false;
			this.lbResSigOut.Location = new Point(266, 88);
			this.lbResSigOut.Name = "lbResSigOut";
			this.lbResSigOut.Size = new Size(36, 23);
			this.lbResSigOut.TabIndex = 25;
			this.lbResSigOut.Text = "SOut";
			this.lbResSigOut.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResSigOut.Visible = false;
			this.lbResSigIn.Enabled = false;
			this.lbResSigIn.Location = new Point(266, 61);
			this.lbResSigIn.Name = "lbResSigIn";
			this.lbResSigIn.Size = new Size(36, 23);
			this.lbResSigIn.TabIndex = 24;
			this.lbResSigIn.Text = "SIn";
			this.lbResSigIn.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResSigIn.Visible = false;
			this.lbShowResSigOut.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowResSigOut.Enabled = false;
			this.lbShowResSigOut.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbShowResSigOut.Location = new Point(308, 87);
			this.lbShowResSigOut.Name = "lbShowResSigOut";
			this.lbShowResSigOut.Size = new Size(60, 23);
			this.lbShowResSigOut.TabIndex = 23;
			this.lbShowResSigOut.Text = "label15";
			this.lbShowResSigOut.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowResSigOut.Visible = false;
			this.lbShowResSigIn.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowResSigIn.Enabled = false;
			this.lbShowResSigIn.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbShowResSigIn.Location = new Point(308, 61);
			this.lbShowResSigIn.Name = "lbShowResSigIn";
			this.lbShowResSigIn.Size = new Size(60, 23);
			this.lbShowResSigIn.TabIndex = 22;
			this.lbShowResSigIn.Text = "label14";
			this.lbShowResSigIn.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowResSigIn.Visible = false;
			this.lbUnitVoltage.Location = new Point(352, 16);
			this.lbUnitVoltage.Name = "lbUnitVoltage";
			this.lbUnitVoltage.Size = new Size(16, 23);
			this.lbUnitVoltage.TabIndex = 18;
			this.lbUnitVoltage.Text = "V";
			this.lbUnitVoltage.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitMilimeter.Location = new Point(256, 21);
			this.lbUnitMilimeter.Name = "lbUnitMilimeter";
			this.lbUnitMilimeter.Size = new Size(28, 23);
			this.lbUnitMilimeter.TabIndex = 17;
			this.lbUnitMilimeter.Text = "mm";
			this.lbUnitMilimeter.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowLInVoltage.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowLInVoltage.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowLInVoltage.Location = new Point(288, 17);
			this.lbShowLInVoltage.Name = "lbShowLInVoltage";
			this.lbShowLInVoltage.Size = new Size(56, 23);
			this.lbShowLInVoltage.TabIndex = 16;
			this.lbShowLInVoltage.Text = "99,99999";
			this.lbShowLInVoltage.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowTM2.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowTM2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowTM2.Location = new Point(168, 117);
			this.lbShowTM2.Name = "lbShowTM2";
			this.lbShowTM2.Size = new Size(80, 23);
			this.lbShowTM2.TabIndex = 9;
			this.lbShowTM2.Text = "label9";
			this.lbShowTM2.TextAlign = ContentAlignment.MiddleRight;
			this.lbTM2.Location = new Point(16, 117);
			this.lbTM2.Name = "lbTM2";
			this.lbTM2.Size = new Size(144, 23);
			this.lbTM2.TabIndex = 8;
			this.lbTM2.Text = "TM2";
			this.lbTM2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowTM1.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowTM1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowTM1.Location = new Point(168, 92);
			this.lbShowTM1.Name = "lbShowTM1";
			this.lbShowTM1.Size = new Size(80, 23);
			this.lbShowTM1.TabIndex = 7;
			this.lbShowTM1.Text = "label7";
			this.lbShowTM1.TextAlign = ContentAlignment.MiddleRight;
			this.lbTM1.Location = new Point(16, 92);
			this.lbTM1.Name = "lbTM1";
			this.lbTM1.Size = new Size(144, 23);
			this.lbTM1.TabIndex = 6;
			this.lbTM1.Text = "TM1";
			this.lbTM1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowExtDig.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowExtDig.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowExtDig.Location = new Point(168, 67);
			this.lbShowExtDig.Name = "lbShowExtDig";
			this.lbShowExtDig.Size = new Size(80, 23);
			this.lbShowExtDig.TabIndex = 5;
			this.lbShowExtDig.Text = "label5";
			this.lbShowExtDig.TextAlign = ContentAlignment.MiddleRight;
			this.lbExtDig.Location = new Point(16, 67);
			this.lbExtDig.Name = "lbExtDig";
			this.lbExtDig.Size = new Size(144, 23);
			this.lbExtDig.TabIndex = 4;
			this.lbExtDig.Text = "ExtDigSig";
			this.lbExtDig.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowExtAna.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowExtAna.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowExtAna.Location = new Point(168, 42);
			this.lbShowExtAna.Name = "lbShowExtAna";
			this.lbShowExtAna.Size = new Size(80, 23);
			this.lbShowExtAna.TabIndex = 3;
			this.lbShowExtAna.Text = "label3";
			this.lbShowExtAna.TextAlign = ContentAlignment.MiddleRight;
			this.lbExtAna.Location = new Point(16, 42);
			this.lbExtAna.Name = "lbExtAna";
			this.lbExtAna.Size = new Size(144, 23);
			this.lbExtAna.TabIndex = 2;
			this.lbExtAna.Text = "AnaSignal";
			this.lbExtAna.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowAnaDepth.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowAnaDepth.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowAnaDepth.Location = new Point(168, 17);
			this.lbShowAnaDepth.Name = "lbShowAnaDepth";
			this.lbShowAnaDepth.Size = new Size(80, 23);
			this.lbShowAnaDepth.TabIndex = 1;
			this.lbShowAnaDepth.Text = "99,99999";
			this.lbShowAnaDepth.TextAlign = ContentAlignment.MiddleRight;
			this.lbAnaDepth.Location = new Point(16, 17);
			this.lbAnaDepth.Name = "lbAnaDepth";
			this.lbAnaDepth.Size = new Size(144, 23);
			this.lbAnaDepth.TabIndex = 0;
			this.lbAnaDepth.Text = "AnaDepth";
			this.lbAnaDepth.TextAlign = ContentAlignment.MiddleLeft;
			this.lbCounterElapsed.Enabled = false;
			this.lbCounterElapsed.Location = new Point(266, 114);
			this.lbCounterElapsed.Name = "lbCounterElapsed";
			this.lbCounterElapsed.Size = new Size(36, 23);
			this.lbCounterElapsed.TabIndex = 27;
			this.lbCounterElapsed.Text = "CtEl";
			this.lbCounterElapsed.TextAlign = ContentAlignment.MiddleLeft;
			this.lbCounterElapsed.Visible = false;
			this.lbCtElapsed.BorderStyle = BorderStyle.Fixed3D;
			this.lbCtElapsed.Enabled = false;
			this.lbCtElapsed.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbCtElapsed.Location = new Point(308, 113);
			this.lbCtElapsed.Name = "lbCtElapsed";
			this.lbCtElapsed.Size = new Size(60, 23);
			this.lbCtElapsed.TabIndex = 26;
			this.lbCtElapsed.Text = "011111";
			this.lbCtElapsed.TextAlign = ContentAlignment.MiddleRight;
			this.lbCtElapsed.Visible = false;
			this.lbCounterWarning.Enabled = false;
			this.lbCounterWarning.Location = new Point(266, 140);
			this.lbCounterWarning.Name = "lbCounterWarning";
			this.lbCounterWarning.Size = new Size(36, 23);
			this.lbCounterWarning.TabIndex = 29;
			this.lbCounterWarning.Text = "CtW";
			this.lbCounterWarning.TextAlign = ContentAlignment.MiddleLeft;
			this.lbCounterWarning.Visible = false;
			this.lbCtWarning.BorderStyle = BorderStyle.Fixed3D;
			this.lbCtWarning.Enabled = false;
			this.lbCtWarning.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbCtWarning.Location = new Point(308, 139);
			this.lbCtWarning.Name = "lbCtWarning";
			this.lbCtWarning.Size = new Size(60, 23);
			this.lbCtWarning.TabIndex = 28;
			this.lbCtWarning.Text = "011111";
			this.lbCtWarning.TextAlign = ContentAlignment.MiddleRight;
			this.lbCtWarning.Visible = false;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.gBResults);
			base.Controls.Add(this.gBOutputs);
			base.Controls.Add(this.gBInputs);
			base.Controls.Add(this.pnMenu);
			base.Controls.Add(this.gBErrors);
			base.Controls.Add(this.gBProcessSignals);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "TestSPSIOForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Test/SPS_IO";
			base.Activated += this.TestSPSIOForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBInputs.ResumeLayout(false);
			this.gBOutputs.ResumeLayout(false);
			this.gBResults.ResumeLayout(false);
			this.gBErrors.ResumeLayout(false);
			this.gBProcessSignals.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public bool ShowWindow()
		{
			this.Main.ActivationBrowserGrantedBy = this;
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadPLCIO"));
			if (!this.Main.VC.ReceiveVarBlock(42))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive PLCCommDataBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.MenEna();
			Cursor.Current = Cursors.Default;
			this.UpdateValues();
			this.timerUpdate.Enabled = true;
			base.Show();
			Application.DoEvents();
			this.Main.StatusBarText(string.Empty);
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuTest") + "/" + this.Main.Rm.GetString("TestSPSIO");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btIOTest.Text = this.Main.Rm.GetString("IOTest");
			this.btMotorSensor.Text = this.Main.Rm.GetString("IntegratedTests");
			this.btPLCInterface.Text = this.Main.Rm.GetString("PLC_IO");
			this.gBErrors.Text = this.Main.Rm.GetString("gBError");
			this.gBInputs.Text = this.Main.Rm.GetString("Inputs");
			this.gBOutputs.Text = this.Main.Rm.GetString("Outputs");
			this.gBResults.Text = this.Main.Rm.GetString("Results");
			this.lbAutomatic.Text = this.Main.Rm.GetString("Automatic");
			this.lbCalDisable.Text = this.Main.Rm.GetString("CalDisable");
			this.lbCycle.Text = this.Main.Rm.GetString("Cycle");
			this.lbErrorNum.Text = this.Main.Rm.GetString("Number");
			this.lbInputProgram.Text = this.Main.Rm.GetString("Program");
			this.lbInputSync1.Text = this.Main.Rm.GetString("SyncSignal") + "1";
			this.lbInputSync2.Text = this.Main.Rm.GetString("SyncSignal") + "2";
			this.lbInputScrewID.Text = this.Main.Rm.GetString("ScrewID");
			this.lbTeach.Text = this.Main.Rm.GetString("TeachSignal");
			this.lbResultScrewID.Text = this.Main.Rm.GetString("ScrewID");
			this.lbIO.Text = this.Main.Rm.GetString("OK");
			this.lbIONIO.Text = this.Main.Rm.GetString("OKNOK");
			this.lbLastStep.Text = this.Main.Rm.GetString("LastDoneStep");
			this.lbNIO.Text = this.Main.Rm.GetString("NOK");
			this.lbOutputSync1.Text = this.Main.Rm.GetString("SyncSignal") + "1";
			this.lbOutputSync2.Text = this.Main.Rm.GetString("SyncSignal") + "2";
			this.lbStorageSignals.Text = this.Main.Rm.GetString("StorageSignals");
			this.lbLivingSignI.Text = this.Main.Rm.GetString("LivingSign");
			this.lbLivingSignO.Text = this.Main.Rm.GetString("LivingSign");
			this.lbProcessRunning.Text = this.Main.Rm.GetString("ProcessRunning");
			this.lbPowerEnabled.Text = this.Main.Rm.GetString("PowerEnabled");
			this.lbQuit.Text = this.Main.Rm.GetString("SignalQuit");
			this.lbReadyToStart.Text = this.Main.Rm.GetString("ReadyToStart");
			this.lbResult1.Text = this.Main.Rm.GetString("Result") + " 1";
			this.lbResult2.Text = this.Main.Rm.GetString("Result") + " 2";
			this.lbResult3.Text = this.Main.Rm.GetString("Result") + " 3";
			this.lbResultKind.Text = this.Main.Rm.GetString("Kind");
			this.lbResultNum.Text = this.Main.Rm.GetString("Value");
			this.lbResultProgram.Text = this.Main.Rm.GetString("Program");
			this.lbResultStep.Text = this.Main.Rm.GetString("Step");
			this.lbScrewDuration.Text = this.Main.Rm.GetString("ScrewTime");
			this.lbStart.Text = this.Main.Rm.GetString("StartSignal");
			this.lbSystemOk.Text = this.Main.Rm.GetString("SystemOK");
			this.lbTime.Text = this.Main.Rm.GetString("Time");
			this.lbValid.Text = this.Main.Rm.GetString("Valid");
			this.lbWarning.Text = this.Main.Rm.GetString("Warning");
			this.lbAnaDepth.Text = this.Main.Rm.GetString("AnaDepth");
			this.lbExtAna.Text = this.Main.Rm.GetString("AnaSignal");
			this.lbExtDig.Text = this.Main.Rm.GetString("DigitalSignal");
			this.lbTM1.Text = this.Main.Rm.GetString("TM1");
			this.lbTM2.Text = this.Main.Rm.GetString("TM2");
			this.gBProcessSignals.Text = this.Main.Rm.GetString("ProcessInputs");
			this.lbUnitSecond.Text = this.Main.Rm.GetString("Second");
			this.lbUnitMilimeter.Text = this.Main.Rm.GetString("Milimeter");
			this.lbUnitVoltage.Text = this.Main.Rm.GetString("Voltage");
			this.lbLivingMonitor.Text = this.Main.Rm.GetString("LivingMonitor");
			this.lbLivingSignI.Text = this.Main.Rm.GetString("LivingSign");
			this.lbLivingSignO.Text = this.Main.Rm.GetString("LivingSign");
			this.lbSpindlePressure.Text = this.Main.Rm.GetString("gBSpindle");
			this.lbHolderPressure.Text = this.Main.Rm.GetString("Holder");
		}

		private void MenEna()
		{
			if (!this.Main.DISPLAY_LIVING_SIGN)
			{
				this.lbLivingSignI.Visible = false;
				this.lbShowLivingSignI.Visible = false;
				this.lbLivingSignO.Visible = false;
				this.lbShowLivingSignO.Visible = false;
				this.lbLivingMonitor.Visible = false;
				this.lbShowLivingMonitor.Visible = false;
			}
			else
			{
				this.lbLivingSignI.Visible = true;
				this.lbShowLivingSignI.Visible = true;
				this.lbLivingSignO.Visible = true;
				this.lbShowLivingSignO.Visible = true;
				this.lbLivingMonitor.Visible = true;
				this.lbShowLivingMonitor.Visible = true;
			}
		}

		private void UpdateValues()
		{
			DateTime dateTime;
			try
			{
				dateTime = new DateTime(this.Main.VC.PLCCommData.Result.Time.Year, this.Main.VC.PLCCommData.Result.Time.Month, this.Main.VC.PLCCommData.Result.Time.Day, this.Main.VC.PLCCommData.Result.Time.Hour, this.Main.VC.PLCCommData.Result.Time.Minute, this.Main.VC.PLCCommData.Result.Time.Second);
			}
			catch
			{
				dateTime = new DateTime(1, 1, 1, 0, 0, 0);
			}
			if (this.Main.VC.PLCCommData.Input.UsingProgName != 0)
			{
				this.lbShowInputPointName.Visible = true;
				this.lbName.Visible = true;
			}
			else
			{
				this.lbShowInputPointName.Visible = false;
				this.lbName.Visible = false;
			}
			this.lbShowAutomatic.Text = this.Main.VC.PLCCommData.Input.Automatic.ToString();
			this.lbShowCalDisable.Text = this.Main.VC.PLCCommData.Input.KalDisable.ToString();
			this.lbShowCycle.Text = this.Main.VC.PLCCommData.Result.Cycle.ToString();
			this.lbShowErrorNum.Text = this.Main.VC.PLCCommData.Error.Num.ToString();
			this.lbShowInputProgram.Text = this.Main.VC.PLCCommData.Input.ProgNum.ToString();
			this.lbShowInputSync1.Text = this.Main.VC.PLCCommData.Input.Sync1.ToString();
			this.lbShowInputSync2.Text = this.Main.VC.PLCCommData.Input.Sync2.ToString();
			this.lbShowInputScrewID.Text = this.Main.CommonFunctions.ByteToString(this.Main.VC.PLCCommData.Input.ScrewID);
			this.lbShowInputPointName.Text = this.Main.CommonFunctions.ByteToString(this.Main.VC.PLCCommData.Input.ProgName);
			this.lbShowResultScrewID.Text = this.Main.CommonFunctions.ByteToString(this.Main.VC.PLCCommData.Result.ScrewID);
			this.lbShowTeach.Text = this.Main.VC.PLCCommData.Input.TeachAnalogDepth.ToString();
			this.lbShowIO.Text = this.Main.VC.PLCCommData.Output.IO.ToString();
			this.lbShowIONIO.Text = this.Main.VC.PLCCommData.Result.IONIO.ToString();
			this.lbShowKind1.Text = this.Main.VC.PLCCommData.Result.ResultParam1.ToString();
			this.lbShowKind2.Text = this.Main.VC.PLCCommData.Result.ResultParam2.ToString();
			this.lbShowKind3.Text = this.Main.VC.PLCCommData.Result.ResultParam3.ToString();
			this.lbShowLastStep.Text = this.Main.VC.PLCCommData.Result.LastStep.ToString();
			this.lbShowNIO.Text = this.Main.VC.PLCCommData.Output.NIO.ToString();
			this.lbShowOutputSync1.Text = this.Main.VC.PLCCommData.Output.Sync1.ToString();
			this.lbShowOutputSync2.Text = this.Main.VC.PLCCommData.Output.Sync2.ToString();
			this.lbShowPowerEnabled.Text = this.Main.VC.PLCCommData.Output.PowerEnabled.ToString();
			this.lbShowProcessRunning.Text = this.Main.VC.PLCCommData.Output.ProcessRunning.ToString();
			this.lbShowQuit.Text = this.Main.VC.PLCCommData.Input.Quit.ToString();
			this.lbShowReadyToStart.Text = this.Main.VC.PLCCommData.Output.ReadyToStart.ToString();
			this.lbShowRes1.Text = this.Main.VC.PLCCommData.Result.Res1.ToString();
			this.lbShowRes2.Text = this.Main.VC.PLCCommData.Result.Res2.ToString();
			this.lbShowRes3.Text = this.Main.VC.PLCCommData.Result.Res3.ToString();
			this.lbShowResultProgram.Text = this.Main.VC.PLCCommData.Result.ProgNum.ToString();
			this.lbShowScrewDuration.Text = this.Main.VC.PLCCommData.Result.ScrewDuration.ToString("f3");
			this.lbShowStart.Text = this.Main.VC.PLCCommData.Input.Start.ToString();
			this.lbShowStep1.Text = this.Main.VC.PLCCommData.Result.ResultStep1.ToString();
			this.lbShowStep2.Text = this.Main.VC.PLCCommData.Result.ResultStep2.ToString();
			this.lbShowStep3.Text = this.Main.VC.PLCCommData.Result.ResultStep3.ToString();
			this.lbShowSystemOk.Text = this.Main.VC.PLCCommData.Output.SystemOK.ToString();
			this.lbShowTime.Text = dateTime.ToString(Settings.Default.TimeSet);
			this.lbShowValid.Text = this.Main.VC.PLCCommData.Result.Valid.ToString();
			this.lbShowWarning.Text = this.Main.VC.PLCCommData.Error.Warning.ToString();
			this.lbShowAnaDepth.Text = this.Main.VC.PLCCommData.Output.AnaDepthMM.ToString();
			this.lbShowExtAna.Text = this.Main.VC.PLCCommData.Output.ExtAna.ToString();
			this.lbShowExtDig.Text = this.Main.VC.PLCCommData.Output.ExtDigIn.ToString();
			this.lbShowTM1.Text = this.Main.VC.PLCCommData.Output.TM1.ToString();
			this.lbShowTM2.Text = this.Main.VC.PLCCommData.Output.TM2.ToString();
			this.lbShowLInVoltage.Text = this.Main.VC.PLCCommData.Output.AnaDepthVolt.ToString("f3");
			this.lbShowStorageSignals.Text = this.Main.VC.PLCCommData.Output.StorageSignals.ToString();
			this.lbShowLivingSignI.Text = this.Main.VC.PLCCommData.Output.LivingSignResponse.ToString();
			this.lbShowLivingSignO.Text = this.Main.VC.PLCCommData.Input.LivingSignRequest.ToString();
			this.lbShowLivingMonitor.Text = this.Main.VC.PLCCommData.Output.LivingMonitor.ToString();
			this.lbShowUser.Text = this.Main.CommonFunctions.ByteToString(this.Main.VC.PLCCommData.Output.UserName) + " (" + this.Main.VC.PLCCommData.Output.UserLevel.ToString() + ")";
			this.lbShowResSigIn.Text = this.Main.VC.PLCCommData.Input.ReserveSignals.ToString();
			this.lbShowResSigOut.Text = this.Main.VC.PLCCommData.Output.ReserveSignals.ToString();
			this.lbShowSpindlePressure.Text = this.Main.VC.PLCCommData.Output.PressureSpindle.ToString("f3");
			this.lbShowHoderPressure.Text = this.Main.VC.PLCCommData.Output.PressureHolder.ToString("f3");
			this.lbCtElapsed.Text = Convert.ToString(this.Main.VC.PLCCommData.Output.MaintenanceCounterReached, 2).PadLeft(5, '0');
			this.lbCtWarning.Text = Convert.ToString(this.Main.VC.PLCCommData.Output.AdvancedCounterReached, 2).PadLeft(5, '0');
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.timerUpdate.Enabled = false;
			base.Hide();
			if (sender != null)
			{
				this.Main.MenuTest1.Back();
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
			this.BrowserShow();
		}

		private void btMotorSensor_Click(object sender, EventArgs e)
		{
			this.btBack_Click(null, EventArgs.Empty);
			this.Main.MenuTest1.ShowMotorSensor();
		}

		private void btIOTest_Click(object sender, EventArgs e)
		{
			this.btBack_Click(null, EventArgs.Empty);
			this.Main.MenuTest1.ShowIOTest();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_3_3_SPS_IO_Anzeige";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_3_3_SPS_IO_Anzeige");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void TestSPSIOForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void timerUpdate_Tick(object sender, EventArgs e)
		{
			this.timerUpdate.Enabled = false;
			if (this.Main.IsOnlineMode)
			{
				this.timerUpdate.Stop();
				if (!this.Main.VC.ReceiveVarBlock(42))
				{
					MessageBox.Show("Could not receive PLCComDataBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.timerUpdate.Start();
				}
				this.UpdateValues();
				this.timerUpdate.Enabled = true;
			}
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}
	}
}
