using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class ResultMiniDisplayForm : Form
	{
		private MainForm Main;

		private int OldHeight;

		private Label lbResUnit3;

		private Label lbResUnit2;

		private Label lbResUnit1;

		private Label lbResName3;

		private Label lbResName2;

		private Label lbResName1;

		private Label lbResult3;

		private Label lbResult2;

		private Label lbResult1;

		private Label lbIONIO;

		private Button btClose;

		private Container components;

		private Label lbResultHeadline;

		private Label lbCycleNumber;

		private Label lbTime;

		private Label lbNIOReason;

		public Label lbError;

		public Label lbIsAutoMode;

		public Label lbIsOnlineMode;

		private Label lbChannelName;

		private Label lbWeber;

		public Label lbLivingSign;

		private Label lbScrewTime;

		public ResultMiniDisplayForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.OldHeight = base.Size.Height;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(ResultMiniDisplayForm));
			this.lbResUnit3 = new Label();
			this.lbResUnit2 = new Label();
			this.lbResUnit1 = new Label();
			this.lbResName3 = new Label();
			this.lbResName2 = new Label();
			this.lbResName1 = new Label();
			this.lbResult3 = new Label();
			this.lbResult2 = new Label();
			this.lbResult1 = new Label();
			this.lbIONIO = new Label();
			this.btClose = new Button();
			this.lbResultHeadline = new Label();
			this.lbCycleNumber = new Label();
			this.lbTime = new Label();
			this.lbNIOReason = new Label();
			this.lbScrewTime = new Label();
			this.lbError = new Label();
			this.lbIsAutoMode = new Label();
			this.lbIsOnlineMode = new Label();
			this.lbChannelName = new Label();
			this.lbWeber = new Label();
			this.lbLivingSign = new Label();
			base.SuspendLayout();
			this.lbResUnit3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResUnit3.Location = new Point(328, 216);
			this.lbResUnit3.Name = "lbResUnit3";
			this.lbResUnit3.Size = new Size(56, 28);
			this.lbResUnit3.TabIndex = 22;
			this.lbResUnit3.Text = "unit";
			this.lbResUnit3.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResUnit2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResUnit2.Location = new Point(328, 188);
			this.lbResUnit2.Name = "lbResUnit2";
			this.lbResUnit2.Size = new Size(56, 28);
			this.lbResUnit2.TabIndex = 21;
			this.lbResUnit2.Text = "unit";
			this.lbResUnit2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResUnit1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResUnit1.Location = new Point(328, 162);
			this.lbResUnit1.Name = "lbResUnit1";
			this.lbResUnit1.Size = new Size(56, 24);
			this.lbResUnit1.TabIndex = 20;
			this.lbResUnit1.Text = "unit";
			this.lbResUnit1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResName3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResName3.Location = new Point(8, 218);
			this.lbResName3.Name = "lbResName3";
			this.lbResName3.Size = new Size(216, 24);
			this.lbResName3.TabIndex = 19;
			this.lbResName3.Text = "name";
			this.lbResName3.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResName2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResName2.Location = new Point(8, 190);
			this.lbResName2.Name = "lbResName2";
			this.lbResName2.Size = new Size(216, 24);
			this.lbResName2.TabIndex = 18;
			this.lbResName2.Text = "Gefiltertes Moment(Stufe 25)";
			this.lbResName2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResName1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResName1.Location = new Point(8, 162);
			this.lbResName1.Name = "lbResName1";
			this.lbResName1.Size = new Size(216, 24);
			this.lbResName1.TabIndex = 17;
			this.lbResName1.Text = "name";
			this.lbResName1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResult3.BackColor = SystemColors.Window;
			this.lbResult3.BorderStyle = BorderStyle.Fixed3D;
			this.lbResult3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResult3.Location = new Point(224, 218);
			this.lbResult3.Name = "lbResult3";
			this.lbResult3.Size = new Size(96, 24);
			this.lbResult3.TabIndex = 16;
			this.lbResult3.TextAlign = ContentAlignment.MiddleRight;
			this.lbResult2.BackColor = SystemColors.Window;
			this.lbResult2.BorderStyle = BorderStyle.Fixed3D;
			this.lbResult2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResult2.Location = new Point(224, 190);
			this.lbResult2.Name = "lbResult2";
			this.lbResult2.Size = new Size(96, 24);
			this.lbResult2.TabIndex = 15;
			this.lbResult2.TextAlign = ContentAlignment.MiddleRight;
			this.lbResult1.BackColor = SystemColors.Window;
			this.lbResult1.BorderStyle = BorderStyle.Fixed3D;
			this.lbResult1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResult1.Location = new Point(224, 162);
			this.lbResult1.Name = "lbResult1";
			this.lbResult1.Size = new Size(96, 24);
			this.lbResult1.TabIndex = 14;
			this.lbResult1.Text = "Ty";
			this.lbResult1.TextAlign = ContentAlignment.MiddleRight;
			this.lbIONIO.BackColor = SystemColors.Window;
			this.lbIONIO.BorderStyle = BorderStyle.Fixed3D;
			this.lbIONIO.Font = new Font("Arial Unicode MS", 36f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbIONIO.Location = new Point(8, 104);
			this.lbIONIO.Name = "lbIONIO";
			this.lbIONIO.Size = new Size(96, 52);
			this.lbIONIO.TabIndex = 23;
			this.lbIONIO.Text = "NOK";
			this.lbIONIO.TextAlign = ContentAlignment.MiddleLeft;
			this.btClose.Font = new Font("Microsoft Sans Serif", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btClose.Location = new Point(360, 0);
			this.btClose.Name = "btClose";
			this.btClose.Size = new Size(32, 32);
			this.btClose.TabIndex = 0;
			this.btClose.Text = "[]";
			this.btClose.Click += this.btClose_Click;
			this.lbResultHeadline.Font = new Font("Arial Unicode MS", 14f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResultHeadline.Location = new Point(8, 38);
			this.lbResultHeadline.Name = "lbResultHeadline";
			this.lbResultHeadline.Size = new Size(376, 34);
			this.lbResultHeadline.TabIndex = 25;
			this.lbResultHeadline.Text = "Prg. 25: WMWMWMWMWMWMWMWMWMWM ID:WMWMWMWMWMWM";
			this.lbResultHeadline.TextAlign = ContentAlignment.MiddleLeft;
			this.lbCycleNumber.Font = new Font("Microsoft Sans Serif", 14f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbCycleNumber.Location = new Point(8, 76);
			this.lbCycleNumber.Name = "lbCycleNumber";
			this.lbCycleNumber.Size = new Size(160, 21);
			this.lbCycleNumber.TabIndex = 26;
			this.lbCycleNumber.Text = "ylabel1";
			this.lbCycleNumber.TextAlign = ContentAlignment.MiddleLeft;
			this.lbTime.Font = new Font("Microsoft Sans Serif", 14f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTime.Location = new Point(176, 76);
			this.lbTime.Name = "lbTime";
			this.lbTime.Size = new Size(208, 21);
			this.lbTime.TabIndex = 27;
			this.lbTime.Text = "label2";
			this.lbTime.TextAlign = ContentAlignment.MiddleLeft;
			this.lbNIOReason.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbNIOReason.Location = new Point(112, 136);
			this.lbNIOReason.Name = "lbNIOReason";
			this.lbNIOReason.Size = new Size(272, 18);
			this.lbNIOReason.TabIndex = 28;
			this.lbNIOReason.Text = "yGglabel2";
			this.lbNIOReason.TextAlign = ContentAlignment.MiddleLeft;
			this.lbScrewTime.Font = new Font("Microsoft Sans Serif", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbScrewTime.Location = new Point(112, 104);
			this.lbScrewTime.Name = "lbScrewTime";
			this.lbScrewTime.Size = new Size(272, 24);
			this.lbScrewTime.TabIndex = 29;
			this.lbScrewTime.Text = "yYlabel2";
			this.lbScrewTime.TextAlign = ContentAlignment.MiddleLeft;
			this.lbError.BackColor = SystemColors.Control;
			this.lbError.BorderStyle = BorderStyle.Fixed3D;
			this.lbError.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbError.Location = new Point(216, 248);
			this.lbError.Name = "lbError";
			this.lbError.Size = new Size(50, 22);
			this.lbError.TabIndex = 32;
			this.lbError.Text = "Error";
			this.lbIsAutoMode.BackColor = SystemColors.Control;
			this.lbIsAutoMode.BorderStyle = BorderStyle.Fixed3D;
			this.lbIsAutoMode.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbIsAutoMode.Location = new Point(272, 248);
			this.lbIsAutoMode.Name = "lbIsAutoMode";
			this.lbIsAutoMode.Size = new Size(50, 22);
			this.lbIsAutoMode.TabIndex = 31;
			this.lbIsAutoMode.Text = "Notaus";
			this.lbIsOnlineMode.BackColor = SystemColors.Control;
			this.lbIsOnlineMode.BorderStyle = BorderStyle.Fixed3D;
			this.lbIsOnlineMode.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbIsOnlineMode.Location = new Point(328, 248);
			this.lbIsOnlineMode.Name = "lbIsOnlineMode";
			this.lbIsOnlineMode.Size = new Size(60, 22);
			this.lbIsOnlineMode.TabIndex = 30;
			this.lbIsOnlineMode.Text = "Offline";
			this.lbChannelName.Font = new Font("Arial Unicode MS", 20f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbChannelName.Location = new Point(8, 5);
			this.lbChannelName.Name = "lbChannelName";
			this.lbChannelName.Size = new Size(350, 29);
			this.lbChannelName.TabIndex = 36;
			this.lbChannelName.Text = "Name der Steuereinheit";
			this.lbChannelName.TextAlign = ContentAlignment.MiddleLeft;
			this.lbWeber.Font = new Font("Arial Unicode MS", 18f, FontStyle.Bold, GraphicsUnit.Pixel, 0);
			this.lbWeber.ForeColor = Color.DodgerBlue;
			this.lbWeber.Location = new Point(8, 248);
			this.lbWeber.Name = "lbWeber";
			this.lbWeber.Size = new Size(160, 22);
			this.lbWeber.TabIndex = 37;
			this.lbWeber.Text = "WEBER - C50S";
			this.lbWeber.TextAlign = ContentAlignment.MiddleLeft;
			this.lbLivingSign.BackColor = SystemColors.Control;
			this.lbLivingSign.BorderStyle = BorderStyle.Fixed3D;
			this.lbLivingSign.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbLivingSign.Location = new Point(160, 248);
			this.lbLivingSign.Name = "lbLivingSign";
			this.lbLivingSign.Size = new Size(50, 22);
			this.lbLivingSign.TabIndex = 38;
			this.lbLivingSign.Text = "Robot";
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(392, 272);
			base.ControlBox = false;
			base.Controls.Add(this.lbLivingSign);
			base.Controls.Add(this.lbWeber);
			base.Controls.Add(this.lbChannelName);
			base.Controls.Add(this.lbResUnit3);
			base.Controls.Add(this.lbResUnit2);
			base.Controls.Add(this.lbResUnit1);
			base.Controls.Add(this.lbResName3);
			base.Controls.Add(this.lbResName2);
			base.Controls.Add(this.lbResName1);
			base.Controls.Add(this.lbResult3);
			base.Controls.Add(this.lbResult2);
			base.Controls.Add(this.lbResult1);
			base.Controls.Add(this.lbIONIO);
			base.Controls.Add(this.btClose);
			base.Controls.Add(this.lbResultHeadline);
			base.Controls.Add(this.lbCycleNumber);
			base.Controls.Add(this.lbTime);
			base.Controls.Add(this.lbNIOReason);
			base.Controls.Add(this.lbScrewTime);
			base.Controls.Add(this.lbError);
			base.Controls.Add(this.lbIsAutoMode);
			base.Controls.Add(this.lbIsOnlineMode);
			this.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//base.Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "ResultMiniDisplayForm";
			base.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "Results";
			base.Resize += this.ResultMiniDisplayForm_Resize;
			base.ResumeLayout(false);
		}

		public void ShowWindow()
		{
			this.lbLivingSign.Visible = this.Main.DISPLAY_LIVING_SIGN;
			this.UpdateValues();
			this.SetLanguageTexts();
			base.Show();
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("ControllerName") + " " + this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) + "/" + this.Main.Rm.GetString("ResultDisplay");
		}

		public void MenEna()
		{
			if (this.Main.IsOnlineMode)
			{
				this.lbIsOnlineMode.Text = this.Main.Rm.GetString("OnlineMode");
				this.lbIsOnlineMode.BackColor = Color.Lime;
				byte autoMode = this.Main.VC.Status0.AutoMode;
				if (autoMode == 1)
				{
					this.lbIsAutoMode.Text = this.Main.Rm.GetString("AutoMode");
					this.lbIsAutoMode.BackColor = SystemColors.Control;
				}
				else
				{
					this.lbIsAutoMode.Text = this.Main.Rm.GetString("HandMode");
					this.lbIsAutoMode.BackColor = SystemColors.Control;
				}
				if (this.Main.VC.Status0.PowerEnabled == 0)
				{
					this.lbIsAutoMode.Text = this.Main.Rm.GetString("EMGMode");
					this.lbIsAutoMode.BackColor = Color.Red;
				}
				if (this.Main.VC.ErrorSys.Num != 0)
				{
					if (this.Main.VC.ErrorSys.Warning == 0)
					{
						this.lbError.BackColor = Color.Red;
						this.lbError.Text = this.Main.Rm.GetString("ErrorMode");
					}
					else
					{
						this.lbError.BackColor = Color.Yellow;
						this.lbError.Text = "WarningMode";
					}
				}
				else
				{
					this.lbError.BackColor = Color.Lime;
					this.lbError.Text = this.Main.Rm.GetString("NoErrorMode");
				}
			}
			else
			{
				this.lbIsOnlineMode.Text = this.Main.Rm.GetString("OfflineMode");
				this.lbIsOnlineMode.BackColor = Color.Red;
				this.lbIsAutoMode.Text = string.Empty;
				this.lbIsAutoMode.BackColor = SystemColors.Control;
				this.lbError.BackColor = SystemColors.Control;
				this.lbError.Text = string.Empty;
			}
		}

		public void UpdateValues()
		{
			string empty = string.Empty;
			this.lbChannelName.Text = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName);
			if (this.Main.VC.Result.IONIO <= 0)
			{
				this.lbResultHeadline.Text = string.Empty;
				this.lbIONIO.Text = this.Main.Rm.GetString("NotValid");
				this.lbIONIO.BackColor = Color.Yellow;
				this.lbNIOReason.Text = string.Empty;
				this.lbTime.Text = this.Main.Rm.GetString("PointOfTime") + ": " + this.Main.Rm.GetString("NotValid");
			}
			else
			{
				empty = "  " + this.Main.Rm.GetString("ScrewID") + ": " + this.Main.CommonFunctions.ByteToString(this.Main.VC.Result.ScrewID);
				if (this.Main.VC.Result.Prog.Info.ProgNum == 0)
				{
					this.lbResultHeadline.Text = this.Main.Rm.GetString("FrictionTest") + empty;
				}
				else
				{
					this.lbResultHeadline.Text = this.Main.Rm.GetString("Abr_Program") + " " + this.Main.VC.Result.Prog.Info.ProgNum.ToString() + ": " + this.Main.CommonFunctions.UShortToString(this.Main.VC.Result.Prog.Info.Name) + empty;
				}
				if (this.Main.VC.Result.IONIO == 1)
				{
					this.lbIONIO.Text = " " + this.Main.Rm.GetString("OK");
					this.lbIONIO.BackColor = Color.Lime;
					this.lbNIOReason.Text = string.Empty;
				}
				else
				{
					this.lbIONIO.Text = this.Main.Rm.GetString("NOK");
					this.lbIONIO.BackColor = Color.Red;
					this.lbNIOReason.Text = this.Main.Rm.GetString("NIO" + this.Main.VC.Result.IONIO.ToString()) + "(" + this.Main.Rm.GetString("Step") + " " + (this.Main.VC.Result.LastStep + 1).ToString() + ")";
				}
				DateTime dateTime;
				try
				{
					dateTime = new DateTime(this.Main.VC.Result.Time.Year, this.Main.VC.Result.Time.Month, this.Main.VC.Result.Time.Day, this.Main.VC.Result.Time.Hour, this.Main.VC.Result.Time.Minute, this.Main.VC.Result.Time.Second);
				}
				catch
				{
					dateTime = new DateTime(1, 1, 1, 0, 0, 0);
				}
				this.lbTime.Text = this.Main.Rm.GetString("PointOfTime") + ": " + dateTime.ToString(Settings.Default.TimeSet);
			}
			if ((this.Main.VC.Result.Valid & 1) > 0)
			{
				this.lbResult1.Text = ((1f + this.Main.CommonFunctions.GetResFactor(this.Main.VC.Result.Prog.Info.ResultParam1) * (this.Main.TorqueConvert - 1f)) * this.Main.VC.Result.Res1).ToString("f" + this.Main.CommonFunctions.GetResDigits(this.Main.VC.Result.Prog.Info.ResultParam1).ToString());
			}
			else
			{
				this.lbResult1.Text = this.Main.Rm.GetString("NotValid");
			}
			if ((this.Main.VC.Result.Valid & 2) > 0)
			{
				this.lbResult2.Text = ((1f + this.Main.CommonFunctions.GetResFactor(this.Main.VC.Result.Prog.Info.ResultParam2) * (this.Main.TorqueConvert - 1f)) * this.Main.VC.Result.Res2).ToString("f" + this.Main.CommonFunctions.GetResDigits(this.Main.VC.Result.Prog.Info.ResultParam2).ToString());
			}
			else
			{
				this.lbResult2.Text = this.Main.Rm.GetString("NotValid");
			}
			if ((this.Main.VC.Result.Valid & 4) > 0)
			{
				this.lbResult3.Text = ((1f + this.Main.CommonFunctions.GetResFactor(this.Main.VC.Result.Prog.Info.ResultParam3) * (this.Main.TorqueConvert - 1f)) * this.Main.VC.Result.Res3).ToString("f" + this.Main.CommonFunctions.GetResDigits(this.Main.VC.Result.Prog.Info.ResultParam3).ToString());
			}
			else
			{
				this.lbResult3.Text = this.Main.Rm.GetString("NotValid");
			}
			if (this.Main.VC.Result.Prog.Info.ProgNum == 0)
			{
				this.lbResName1.Text = this.Main.Rm.GetString("FrictionTorque");
				this.lbResName2.Text = this.Main.Rm.GetString("RightAngle");
				this.lbResName3.Text = this.Main.Rm.GetString("LeftAngle");
			}
			else
			{
				empty = ((this.Main.VC.Result.ResultStep1 >= 0) ? (" (" + this.Main.Rm.GetString("Step") + " " + (this.Main.VC.Result.ResultStep1 + 1).ToString() + ")") : string.Empty);
				this.lbResName1.Text = this.Main.CommonFunctions.GetResName(this.Main.VC.Result.Prog.Info.ResultParam1) + empty;
				empty = ((this.Main.VC.Result.ResultStep2 >= 0) ? (" (" + this.Main.Rm.GetString("Step") + " " + (this.Main.VC.Result.ResultStep2 + 1).ToString() + ")") : string.Empty);
				this.lbResName2.Text = this.Main.CommonFunctions.GetResName(this.Main.VC.Result.Prog.Info.ResultParam2) + empty;
				empty = ((this.Main.VC.Result.ResultStep3 >= 0) ? (" (" + this.Main.Rm.GetString("Step") + " " + (this.Main.VC.Result.ResultStep3 + 1).ToString() + ")") : string.Empty);
				this.lbResName3.Text = this.Main.CommonFunctions.GetResName(this.Main.VC.Result.Prog.Info.ResultParam3) + empty;
			}
			this.lbResUnit1.Text = this.Main.CommonFunctions.GetResUnit(this.Main.VC.Result.Prog.Info.ResultParam1, this.Main.TorqueUnitName);
			this.lbResUnit2.Text = this.Main.CommonFunctions.GetResUnit(this.Main.VC.Result.Prog.Info.ResultParam2, this.Main.TorqueUnitName);
			this.lbResUnit3.Text = this.Main.CommonFunctions.GetResUnit(this.Main.VC.Result.Prog.Info.ResultParam3, this.Main.TorqueUnitName);
			this.lbCycleNumber.Text = this.Main.Rm.GetString("CycleNumber") + ": " + this.Main.VC.Result.Cycle.ToString();
			this.lbScrewTime.Text = this.Main.Rm.GetString("ScrewTime") + ": " + this.Main.VC.Result.ScrewDuration.ToString("f" + 2.ToString()) + "s";
		}

		public void LivingSign(bool isLiving)
		{
			if (!this.Main.IsOnlineMode)
			{
				this.lbLivingSign.BackColor = Color.Yellow;
				this.lbLivingSign.Text = this.Main.Rm.GetString("Robot");
			}
			else if (isLiving)
			{
				this.lbLivingSign.BackColor = Color.Lime;
				this.lbLivingSign.Text = this.Main.Rm.GetString("Robot");
			}
			else
			{
				this.lbLivingSign.BackColor = Color.Red;
				this.lbLivingSign.Text = this.Main.Rm.GetString("Robot");
			}
		}

		private void btClose_Click(object sender, EventArgs e)
		{
			this.Main.Show();
			base.Hide();
		}

		private void ResultMiniDisplayForm_Resize(object sender, EventArgs e)
		{
			Size size = base.Size;
			if (size.Height != this.OldHeight)
			{
				base.Size = new Size(400 * base.Size.Height / 300, base.Size.Height);
			}
			else
			{
				base.Size = new Size(base.Size.Width, 300 * base.Size.Width / 400);
			}
			this.lbChannelName.Location = new Point(8 * (base.Size.Width - 7) / 393, 5 * (base.Size.Height - 26) / 274);
			this.lbChannelName.Size = new Size(350 * (base.Size.Width - 7) / 393, 29 * (base.Size.Height - 26) / 274);
			this.lbChannelName.Font = new Font(this.btClose.Font.Name, 20f * ((float)base.Size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			Button button = this.btClose;
			int x = 360 * (base.Size.Width - 7) / 393;
			int height = base.Size.Height;
			button.Location = new Point(x, 0);
			this.btClose.Size = new Size(32 * (base.Size.Width - 7) / 393, 32 * (base.Size.Height - 26) / 274);
			this.btClose.Font = new Font(this.btClose.Font.Name, 16f * ((float)base.Size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			this.lbResultHeadline.Location = new Point(8 * (base.Size.Width - 7) / 393, 38 * (base.Size.Height - 26) / 274);
			this.lbResultHeadline.Size = new Size(376 * (base.Size.Width - 7) / 393, 34 * (base.Size.Height - 26) / 274);
			this.lbResultHeadline.Font = new Font(this.btClose.Font.Name, 14f * ((float)base.Size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			this.lbCycleNumber.Location = new Point(8 * (base.Size.Width - 7) / 393, 76 * (base.Size.Height - 26) / 274);
			this.lbCycleNumber.Size = new Size(160 * (base.Size.Width - 7) / 393, 21 * (base.Size.Height - 26) / 274);
			this.lbCycleNumber.Font = new Font(this.btClose.Font.Name, 14f * ((float)base.Size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			this.lbTime.Location = new Point(176 * (base.Size.Width - 7) / 393, 76 * (base.Size.Height - 26) / 274);
			this.lbTime.Size = new Size(208 * (base.Size.Width - 7) / 393, 21 * (base.Size.Height - 26) / 274);
			this.lbTime.Font = new Font(this.btClose.Font.Name, 14f * ((float)base.Size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			this.lbIONIO.Location = new Point(8 * (base.Size.Width - 7) / 393, 104 * (base.Size.Height - 26) / 274);
			this.lbIONIO.Size = new Size(96 * (base.Size.Width - 7) / 393, 52 * (base.Size.Height - 26) / 274);
			this.lbIONIO.Font = new Font(this.btClose.Font.Name, 36f * ((float)base.Size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			this.lbScrewTime.Location = new Point(112 * (base.Size.Width - 7) / 393, 104 * (base.Size.Height - 26) / 274);
			this.lbScrewTime.Size = new Size(264 * (base.Size.Width - 7) / 393, 24 * (base.Size.Height - 26) / 274);
			this.lbScrewTime.Font = new Font(this.btClose.Font.Name, 15f * ((float)base.Size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			this.lbNIOReason.Location = new Point(112 * (base.Size.Width - 7) / 393, 136 * (base.Size.Height - 26) / 274);
			this.lbNIOReason.Size = new Size(264 * (base.Size.Width - 7) / 393, 18 * (base.Size.Height - 26) / 274);
			this.lbNIOReason.Font = new Font(this.btClose.Font.Name, 12f * ((float)base.Size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			this.lbResName1.Location = new Point(8 * (base.Size.Width - 7) / 393, 162 * (base.Size.Height - 26) / 274);
			this.lbResName1.Size = new Size(216 * (base.Size.Width - 7) / 393, 24 * (base.Size.Height - 26) / 274);
			this.lbResName1.Font = new Font(this.btClose.Font.Name, 15f * ((float)base.Size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			this.lbResName2.Location = new Point(8 * (base.Size.Width - 7) / 393, 190 * (base.Size.Height - 26) / 274);
			this.lbResName2.Size = new Size(216 * (base.Size.Width - 7) / 393, 24 * (base.Size.Height - 26) / 274);
			this.lbResName2.Font = new Font(this.btClose.Font.Name, 15f * ((float)base.Size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			this.lbResName3.Location = new Point(8 * (base.Size.Width - 7) / 393, 218 * (base.Size.Height - 26) / 274);
			this.lbResName3.Size = new Size(216 * (base.Size.Width - 7) / 393, 24 * (base.Size.Height - 26) / 274);
			this.lbResName3.Font = new Font(this.btClose.Font.Name, 15f * ((float)base.Size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			Label label = this.lbResult1;
			int x2 = 224 * (base.Size.Width - 7) / 393;
			size = base.Size;
			label.Location = new Point(x2, 162 * (size.Height - 26) / 274);
			Label label2 = this.lbResult1;
			size = base.Size;
			int width = 96 * (size.Width - 7) / 393;
			size = base.Size;
			label2.Size = new Size(width, 24 * (size.Height - 26) / 274);
			Label label3 = this.lbResult1;
			string name = this.btClose.Font.Name;
			size = base.Size;
			label3.Font = new Font(name, 15f * ((float)size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			Label label4 = this.lbResult2;
			size = base.Size;
			int x3 = 224 * (size.Width - 7) / 393;
			size = base.Size;
			label4.Location = new Point(x3, 190 * (size.Height - 26) / 274);
			Label label5 = this.lbResult2;
			size = base.Size;
			int width2 = 96 * (size.Width - 7) / 393;
			size = base.Size;
			label5.Size = new Size(width2, 24 * (size.Height - 26) / 274);
			Label label6 = this.lbResult2;
			string name2 = this.btClose.Font.Name;
			size = base.Size;
			label6.Font = new Font(name2, 15f * ((float)size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			Label label7 = this.lbResult3;
			size = base.Size;
			int x4 = 224 * (size.Width - 7) / 393;
			size = base.Size;
			label7.Location = new Point(x4, 218 * (size.Height - 26) / 274);
			Label label8 = this.lbResult3;
			size = base.Size;
			int width3 = 96 * (size.Width - 7) / 393;
			size = base.Size;
			label8.Size = new Size(width3, 24 * (size.Height - 26) / 274);
			Label label9 = this.lbResult3;
			string name3 = this.btClose.Font.Name;
			size = base.Size;
			label9.Font = new Font(name3, 15f * ((float)size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			Label label10 = this.lbResUnit1;
			size = base.Size;
			int x5 = 328 * (size.Width - 7) / 393;
			size = base.Size;
			label10.Location = new Point(x5, 162 * (size.Height - 26) / 274);
			Label label11 = this.lbResUnit1;
			size = base.Size;
			int width4 = 56 * (size.Width - 7) / 393;
			size = base.Size;
			label11.Size = new Size(width4, 24 * (size.Height - 26) / 274);
			Label label12 = this.lbResUnit1;
			string name4 = this.btClose.Font.Name;
			size = base.Size;
			label12.Font = new Font(name4, 15f * ((float)size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			Label label13 = this.lbResUnit2;
			size = base.Size;
			int x6 = 328 * (size.Width - 7) / 393;
			size = base.Size;
			label13.Location = new Point(x6, 190 * (size.Height - 26) / 274);
			Label label14 = this.lbResUnit2;
			size = base.Size;
			int width5 = 56 * (size.Width - 7) / 393;
			size = base.Size;
			label14.Size = new Size(width5, 24 * (size.Height - 26) / 274);
			Label label15 = this.lbResUnit2;
			string name5 = this.btClose.Font.Name;
			size = base.Size;
			label15.Font = new Font(name5, 15f * ((float)size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			Label label16 = this.lbResUnit3;
			size = base.Size;
			int x7 = 328 * (size.Width - 7) / 393;
			size = base.Size;
			label16.Location = new Point(x7, 218 * (size.Height - 26) / 274);
			Label label17 = this.lbResUnit3;
			size = base.Size;
			int width6 = 56 * (size.Width - 7) / 393;
			size = base.Size;
			label17.Size = new Size(width6, 24 * (size.Height - 26) / 274);
			Label label18 = this.lbResUnit3;
			string name6 = this.btClose.Font.Name;
			size = base.Size;
			label18.Font = new Font(name6, 15f * ((float)size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			Label label19 = this.lbWeber;
			size = base.Size;
			int x8 = 8 * (size.Width - 7) / 393;
			size = base.Size;
			label19.Location = new Point(x8, 248 * (size.Height - 26) / 274);
			Label label20 = this.lbWeber;
			size = base.Size;
			int width7 = 160 * (size.Width - 7) / 393;
			size = base.Size;
			label20.Size = new Size(width7, 22 * (size.Height - 26) / 274);
			Label label21 = this.lbWeber;
			string name7 = this.btClose.Font.Name;
			size = base.Size;
			label21.Font = new Font(name7, 18f * ((float)size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			Label label22 = this.lbError;
			size = base.Size;
			int x9 = 216 * (size.Width - 7) / 393;
			size = base.Size;
			label22.Location = new Point(x9, 248 * (size.Height - 26) / 274);
			Label label23 = this.lbError;
			size = base.Size;
			int width8 = 50 * (size.Width - 7) / 393;
			size = base.Size;
			label23.Size = new Size(width8, 22 * (size.Height - 26) / 274);
			Label label24 = this.lbError;
			string name8 = this.btClose.Font.Name;
			size = base.Size;
			label24.Font = new Font(name8, 13f * ((float)size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			Label label25 = this.lbLivingSign;
			size = base.Size;
			int x10 = 216 * (size.Width - 7) / 393;
			size = base.Size;
			label25.Location = new Point(x10, 248 * (size.Height - 26) / 274);
			Label label26 = this.lbLivingSign;
			size = base.Size;
			int width9 = 50 * (size.Width - 7) / 393;
			size = base.Size;
			label26.Size = new Size(width9, 22 * (size.Height - 26) / 274);
			Label label27 = this.lbLivingSign;
			string name9 = this.btClose.Font.Name;
			size = base.Size;
			label27.Font = new Font(name9, 13f * ((float)size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			Label label28 = this.lbIsAutoMode;
			size = base.Size;
			int x11 = 272 * (size.Width - 7) / 393;
			size = base.Size;
			label28.Location = new Point(x11, 248 * (size.Height - 26) / 274);
			Label label29 = this.lbIsAutoMode;
			size = base.Size;
			int width10 = 50 * (size.Width - 7) / 393;
			size = base.Size;
			label29.Size = new Size(width10, 22 * (size.Height - 26) / 274);
			Label label30 = this.lbIsAutoMode;
			string name10 = this.btClose.Font.Name;
			size = base.Size;
			label30.Font = new Font(name10, 13f * ((float)size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			Label label31 = this.lbIsOnlineMode;
			size = base.Size;
			int x12 = 328 * (size.Width - 7) / 393;
			size = base.Size;
			label31.Location = new Point(x12, 248 * (size.Height - 26) / 274);
			Label label32 = this.lbIsOnlineMode;
			size = base.Size;
			int width11 = 60 * (size.Width - 7) / 393;
			size = base.Size;
			label32.Size = new Size(width11, 22 * (size.Height - 26) / 274);
			Label label33 = this.lbIsOnlineMode;
			string name11 = this.btClose.Font.Name;
			size = base.Size;
			label33.Font = new Font(name11, 13f * ((float)size.Width - 7f) / 393f, GraphicsUnit.Pixel);
			size = base.Size;
			this.OldHeight = size.Height;
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.MenEna();
		}
	}
}
