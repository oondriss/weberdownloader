using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class TestIOForm : Form
	{
		private MainForm Main;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Panel panel1;

		private Label lbDI1;

		private Label lbDI2;

		private Label lbDI3;

		private Label lbDI4;

		private Label lbDI5;

		private Label lbDI6;

		private Label lbDI7;

		private Label lbDI8;

		private Label lbDI15;

		private Label lbDI14;

		private Label lbDI13;

		private Label lbDI12;

		private Label lbDI11;

		private Label lbDI10;

		private Label lbDI9;

		private Panel panel3;

		private Panel panel4;

		private Panel panel5;

		private Button btDO1;

		private Button btDO2;

		private Button btDO3;

		private Button btDO4;

		private Button btDO5;

		private Button btDO15;

		private Button btDO14;

		private Button btDO13;

		private Button btDO12;

		private Button btDO11;

		private Button btDO10;

		private Button btDO9;

		private Label lbShowNact;

		private Label lbShowExtAna;

		private Label lbShowADepth;

		private Label lbShowTorque;

		private Label lbTorque;

		private Label lbNact;

		private Label lbExtAna;

		private Label lbADepth;

		private Label lbShowAngle;

		private Label lbAngle;

		private Button btDO6;

		private Button btDO7;

		private Button btDO8;

		private Panel panel2;

		private Label lbShowISRCount;

		private Label lbShowHexSwitch;

		private Label lbShowGradCount;

		private Label lbISRCount;

		private Label lbHexSwitch;

		private Label lbGradCount;

		private Label lbEnc2;

		private Label lbEnc1;

		private Label lbEnc0;

		private Label lbShowEnc2;

		private Label lbShowEnc1;

		private Label lbShowEnc0;

		private Label lbShowAI0;

		private Label lbAI0;

		private Label lbShowAI3;

		private Label lbShowAI2;

		private Label lbShowAI1;

		private Label lbAI3;

		private Label lbAI2;

		private Label lbAI1;

		private Label lbDI0;

		private Button btDO0;

		private System.Windows.Forms.Timer timerUpdate;

		private IContainer components;

		private Panel panel6;

		private Label lbUnitAI0;

		private Label lbUnitAI1;

		private Label lbUnitAI3;

		private Label lbUnitAI2;

		private Panel panel7;

		private Label lbUnitAO2;

		private Label lbUnitAO3;

		private Label lbUnitAO1;

		private Label lbUnitAO0;

		private Label lbAO3;

		private Label lbAO2;

		private Label lbAO1;

		private Label lbAO0;

		private NumberEdit1 nEAO0;

		private NumberEdit1 nEAO3;

		private NumberEdit1 nEAO1;

		private NumberEdit1 nEAO2;

		private Label lbUnitNact;

		private Label lbUnitADepth;

		private Label lbUnitTorque;

		private Label lbUnitAngle;

		private Panel panel9;

		private Panel panel10;

		private Button btSetAO;

		private Button btResetEnc0;

		private Button btResetEnc1;

		private Button btResetEnc2;

		private Label lbShowBattery;

		private Label lbBattery;

		private Label lbShowAIError;

		private Label lbAIError;

		private Label lbShowEncError;

		private Label lbEncError;

		private Button bt6;

		private Button bt5;

		private Label lbUnitRedTorque;

		private Label lbShowRedTorque;

		private Label lbRedTorque;

		private Label lbRedAngle;

		private Label lbShowRedAngle;

		private Label lbUnitRedAngle;

		private Button btBrowser;

		private Button btPLCInterface;

		private Button btMotorSensor;

		private Button btIOTest;

		private Button btResetEncError;

		public TestIOForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.timerUpdate.Interval = 500;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			this.pnMenu = new Panel();
			this.btBrowser = new Button();
			this.bt6 = new Button();
			this.bt5 = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.panel1 = new Panel();
			this.lbDI8 = new Label();
			this.lbDI7 = new Label();
			this.lbDI6 = new Label();
			this.lbDI5 = new Label();
			this.lbDI4 = new Label();
			this.lbDI3 = new Label();
			this.lbDI2 = new Label();
			this.lbDI1 = new Label();
			this.lbDI13 = new Label();
			this.lbDI15 = new Label();
			this.lbDI10 = new Label();
			this.lbDI14 = new Label();
			this.lbDI0 = new Label();
			this.lbDI9 = new Label();
			this.lbDI12 = new Label();
			this.lbDI11 = new Label();
			this.panel3 = new Panel();
			this.lbUnitRedTorque = new Label();
			this.lbShowRedTorque = new Label();
			this.lbRedTorque = new Label();
			this.lbUnitADepth = new Label();
			this.lbUnitTorque = new Label();
			this.lbShowExtAna = new Label();
			this.lbShowADepth = new Label();
			this.lbShowTorque = new Label();
			this.lbTorque = new Label();
			this.lbExtAna = new Label();
			this.lbADepth = new Label();
			this.lbShowAI3 = new Label();
			this.lbShowAI2 = new Label();
			this.lbShowAI1 = new Label();
			this.lbAI3 = new Label();
			this.lbAI2 = new Label();
			this.lbAI1 = new Label();
			this.lbShowAI0 = new Label();
			this.lbShowNact = new Label();
			this.lbAI0 = new Label();
			this.lbNact = new Label();
			this.panel4 = new Panel();
			this.btResetEnc2 = new Button();
			this.btResetEnc1 = new Button();
			this.btResetEnc0 = new Button();
			this.lbShowEnc2 = new Label();
			this.lbShowEnc1 = new Label();
			this.lbShowEnc0 = new Label();
			this.lbEnc2 = new Label();
			this.lbEnc1 = new Label();
			this.lbEnc0 = new Label();
			this.lbUnitAngle = new Label();
			this.lbShowAngle = new Label();
			this.lbAngle = new Label();
			this.panel5 = new Panel();
			this.btDO8 = new Button();
			this.btDO7 = new Button();
			this.btDO6 = new Button();
			this.btDO5 = new Button();
			this.btDO4 = new Button();
			this.btDO3 = new Button();
			this.btDO2 = new Button();
			this.btDO1 = new Button();
			this.btDO0 = new Button();
			this.btDO15 = new Button();
			this.btDO14 = new Button();
			this.btDO13 = new Button();
			this.btDO12 = new Button();
			this.btDO11 = new Button();
			this.btDO10 = new Button();
			this.btDO9 = new Button();
			this.panel2 = new Panel();
			this.btResetEncError = new Button();
			this.lbShowEncError = new Label();
			this.lbEncError = new Label();
			this.lbShowBattery = new Label();
			this.lbBattery = new Label();
			this.lbShowAIError = new Label();
			this.lbAIError = new Label();
			this.lbShowISRCount = new Label();
			this.lbShowHexSwitch = new Label();
			this.lbShowGradCount = new Label();
			this.lbISRCount = new Label();
			this.lbHexSwitch = new Label();
			this.lbGradCount = new Label();
			this.timerUpdate = new System.Windows.Forms.Timer(this.components);
			this.panel6 = new Panel();
			this.lbUnitAI2 = new Label();
			this.lbUnitAI3 = new Label();
			this.lbUnitAI1 = new Label();
			this.lbUnitAI0 = new Label();
			this.panel7 = new Panel();
			this.btSetAO = new Button();
			this.nEAO2 = new NumberEdit1();
			this.nEAO1 = new NumberEdit1();
			this.nEAO3 = new NumberEdit1();
			this.nEAO0 = new NumberEdit1();
			this.lbUnitAO2 = new Label();
			this.lbUnitAO3 = new Label();
			this.lbUnitAO1 = new Label();
			this.lbUnitAO0 = new Label();
			this.lbAO3 = new Label();
			this.lbAO2 = new Label();
			this.lbAO1 = new Label();
			this.lbAO0 = new Label();
			this.lbUnitNact = new Label();
			this.panel9 = new Panel();
			this.lbRedAngle = new Label();
			this.lbShowRedAngle = new Label();
			this.lbUnitRedAngle = new Label();
			this.panel10 = new Panel();
			this.btPLCInterface = new Button();
			this.btMotorSensor = new Button();
			this.btIOTest = new Button();
			this.pnMenu.SuspendLayout();
			this.panel1.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panel9.SuspendLayout();
			this.panel10.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btPLCInterface);
			this.pnMenu.Controls.Add(this.btMotorSensor);
			this.pnMenu.Controls.Add(this.btIOTest);
			this.pnMenu.Controls.Add(this.btBrowser);
			this.pnMenu.Controls.Add(this.bt6);
			this.pnMenu.Controls.Add(this.bt5);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btBrowser.Enabled = false;
			this.btBrowser.Location = new Point(3, 323);
			this.btBrowser.Name = "btBrowser";
			this.btBrowser.Size = new Size(74, 62);
			this.btBrowser.TabIndex = 5;
			this.btBrowser.Click += this.btBrowser_Click;
			this.bt6.Enabled = false;
			this.bt6.Location = new Point(3, 451);
			this.bt6.Name = "bt6";
			this.bt6.Size = new Size(74, 62);
			this.bt6.TabIndex = 7;
			this.bt5.Enabled = false;
			this.bt5.Location = new Point(3, 387);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(74, 62);
			this.bt5.TabIndex = 6;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btHelp.Enter += this.Start_Input;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.btBack.Enter += this.Start_Input;
			this.panel1.BorderStyle = BorderStyle.Fixed3D;
			this.panel1.Controls.Add(this.lbDI8);
			this.panel1.Controls.Add(this.lbDI7);
			this.panel1.Controls.Add(this.lbDI6);
			this.panel1.Controls.Add(this.lbDI5);
			this.panel1.Controls.Add(this.lbDI4);
			this.panel1.Controls.Add(this.lbDI3);
			this.panel1.Controls.Add(this.lbDI2);
			this.panel1.Controls.Add(this.lbDI1);
			this.panel1.Controls.Add(this.lbDI13);
			this.panel1.Controls.Add(this.lbDI15);
			this.panel1.Controls.Add(this.lbDI10);
			this.panel1.Controls.Add(this.lbDI14);
			this.panel1.Controls.Add(this.lbDI0);
			this.panel1.Controls.Add(this.lbDI9);
			this.panel1.Controls.Add(this.lbDI12);
			this.panel1.Controls.Add(this.lbDI11);
			this.panel1.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.panel1.Location = new Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new Size(72, 522);
			this.panel1.TabIndex = 1;
			this.lbDI8.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI8.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI8.Location = new Point(10, 264);
			this.lbDI8.Name = "lbDI8";
			this.lbDI8.Size = new Size(48, 23);
			this.lbDI8.TabIndex = 7;
			this.lbDI8.Text = "DI8";
			this.lbDI8.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI7.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI7.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI7.Location = new Point(10, 232);
			this.lbDI7.Name = "lbDI7";
			this.lbDI7.Size = new Size(48, 23);
			this.lbDI7.TabIndex = 6;
			this.lbDI7.Text = "DI7";
			this.lbDI7.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI6.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI6.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI6.Location = new Point(10, 200);
			this.lbDI6.Name = "lbDI6";
			this.lbDI6.Size = new Size(48, 23);
			this.lbDI6.TabIndex = 5;
			this.lbDI6.Text = "DI6";
			this.lbDI6.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI5.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI5.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI5.Location = new Point(10, 168);
			this.lbDI5.Name = "lbDI5";
			this.lbDI5.Size = new Size(48, 23);
			this.lbDI5.TabIndex = 4;
			this.lbDI5.Text = "DI5";
			this.lbDI5.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI4.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI4.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI4.Location = new Point(10, 136);
			this.lbDI4.Name = "lbDI4";
			this.lbDI4.Size = new Size(48, 23);
			this.lbDI4.TabIndex = 3;
			this.lbDI4.Text = "DI4";
			this.lbDI4.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI3.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI3.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI3.Location = new Point(10, 104);
			this.lbDI3.Name = "lbDI3";
			this.lbDI3.Size = new Size(48, 23);
			this.lbDI3.TabIndex = 2;
			this.lbDI3.Text = "DI3";
			this.lbDI3.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI2.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI2.Location = new Point(10, 72);
			this.lbDI2.Name = "lbDI2";
			this.lbDI2.Size = new Size(48, 23);
			this.lbDI2.TabIndex = 1;
			this.lbDI2.Text = "DI2";
			this.lbDI2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI1.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI1.Location = new Point(10, 40);
			this.lbDI1.Name = "lbDI1";
			this.lbDI1.Size = new Size(48, 23);
			this.lbDI1.TabIndex = 0;
			this.lbDI1.Text = "DI1";
			this.lbDI1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI13.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI13.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI13.Location = new Point(10, 424);
			this.lbDI13.Name = "lbDI13";
			this.lbDI13.Size = new Size(48, 23);
			this.lbDI13.TabIndex = 4;
			this.lbDI13.Text = "DI13";
			this.lbDI13.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI15.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI15.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI15.Location = new Point(10, 488);
			this.lbDI15.Name = "lbDI15";
			this.lbDI15.Size = new Size(48, 23);
			this.lbDI15.TabIndex = 6;
			this.lbDI15.Text = "DI15";
			this.lbDI15.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI10.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI10.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI10.Location = new Point(10, 328);
			this.lbDI10.Name = "lbDI10";
			this.lbDI10.Size = new Size(48, 23);
			this.lbDI10.TabIndex = 1;
			this.lbDI10.Text = "DI10";
			this.lbDI10.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI14.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI14.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI14.Location = new Point(10, 456);
			this.lbDI14.Name = "lbDI14";
			this.lbDI14.Size = new Size(48, 23);
			this.lbDI14.TabIndex = 5;
			this.lbDI14.Text = "DI14";
			this.lbDI14.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI0.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI0.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI0.Location = new Point(10, 8);
			this.lbDI0.Name = "lbDI0";
			this.lbDI0.Size = new Size(48, 23);
			this.lbDI0.TabIndex = 7;
			this.lbDI0.Text = "DI0";
			this.lbDI0.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI9.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI9.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI9.Location = new Point(10, 296);
			this.lbDI9.Name = "lbDI9";
			this.lbDI9.Size = new Size(48, 23);
			this.lbDI9.TabIndex = 0;
			this.lbDI9.Text = "DI9";
			this.lbDI9.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI12.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI12.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI12.Location = new Point(10, 392);
			this.lbDI12.Name = "lbDI12";
			this.lbDI12.Size = new Size(48, 23);
			this.lbDI12.TabIndex = 3;
			this.lbDI12.Text = "DI12";
			this.lbDI12.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDI11.BorderStyle = BorderStyle.Fixed3D;
			this.lbDI11.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDI11.Location = new Point(10, 360);
			this.lbDI11.Name = "lbDI11";
			this.lbDI11.Size = new Size(48, 23);
			this.lbDI11.TabIndex = 2;
			this.lbDI11.Text = "DI11";
			this.lbDI11.TextAlign = ContentAlignment.MiddleLeft;
			this.panel3.BorderStyle = BorderStyle.Fixed3D;
			this.panel3.Controls.Add(this.lbUnitRedTorque);
			this.panel3.Controls.Add(this.lbShowRedTorque);
			this.panel3.Controls.Add(this.lbRedTorque);
			this.panel3.Controls.Add(this.lbUnitADepth);
			this.panel3.Controls.Add(this.lbUnitTorque);
			this.panel3.Controls.Add(this.lbShowExtAna);
			this.panel3.Controls.Add(this.lbShowADepth);
			this.panel3.Controls.Add(this.lbShowTorque);
			this.panel3.Controls.Add(this.lbTorque);
			this.panel3.Controls.Add(this.lbExtAna);
			this.panel3.Controls.Add(this.lbADepth);
			this.panel3.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.panel3.Location = new Point(408, 0);
			this.panel3.Name = "panel3";
			this.panel3.Size = new Size(296, 136);
			this.panel3.TabIndex = 6;
			this.lbUnitRedTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitRedTorque.Location = new Point(224, 40);
			this.lbUnitRedTorque.Name = "lbUnitRedTorque";
			this.lbUnitRedTorque.Size = new Size(56, 23);
			this.lbUnitRedTorque.TabIndex = 27;
			this.lbUnitRedTorque.Text = "Nm";
			this.lbUnitRedTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowRedTorque.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowRedTorque.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowRedTorque.Location = new Point(136, 40);
			this.lbShowRedTorque.Name = "lbShowRedTorque";
			this.lbShowRedTorque.Size = new Size(80, 23);
			this.lbShowRedTorque.TabIndex = 26;
			this.lbShowRedTorque.Text = "0";
			this.lbShowRedTorque.TextAlign = ContentAlignment.MiddleRight;
			this.lbRedTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbRedTorque.Location = new Point(8, 40);
			this.lbRedTorque.Name = "lbRedTorque";
			this.lbRedTorque.Size = new Size(120, 23);
			this.lbRedTorque.TabIndex = 25;
			this.lbRedTorque.Text = "Red. Moment";
			this.lbRedTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitADepth.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitADepth.Location = new Point(224, 72);
			this.lbUnitADepth.Name = "lbUnitADepth";
			this.lbUnitADepth.Size = new Size(56, 23);
			this.lbUnitADepth.TabIndex = 24;
			this.lbUnitADepth.Text = "mm";
			this.lbUnitADepth.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitTorque.Location = new Point(224, 8);
			this.lbUnitTorque.Name = "lbUnitTorque";
			this.lbUnitTorque.Size = new Size(56, 23);
			this.lbUnitTorque.TabIndex = 23;
			this.lbUnitTorque.Text = "Nm";
			this.lbUnitTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowExtAna.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowExtAna.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowExtAna.Location = new Point(136, 104);
			this.lbShowExtAna.Name = "lbShowExtAna";
			this.lbShowExtAna.Size = new Size(80, 23);
			this.lbShowExtAna.TabIndex = 10;
			this.lbShowExtAna.Text = "0";
			this.lbShowExtAna.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowADepth.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowADepth.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowADepth.Location = new Point(136, 72);
			this.lbShowADepth.Name = "lbShowADepth";
			this.lbShowADepth.Size = new Size(80, 23);
			this.lbShowADepth.TabIndex = 9;
			this.lbShowADepth.Text = "0";
			this.lbShowADepth.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowTorque.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowTorque.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowTorque.Location = new Point(136, 8);
			this.lbShowTorque.Name = "lbShowTorque";
			this.lbShowTorque.Size = new Size(80, 23);
			this.lbShowTorque.TabIndex = 8;
			this.lbShowTorque.Text = "0";
			this.lbShowTorque.TextAlign = ContentAlignment.MiddleRight;
			this.lbTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTorque.Location = new Point(8, 8);
			this.lbTorque.Name = "lbTorque";
			this.lbTorque.Size = new Size(120, 23);
			this.lbTorque.TabIndex = 3;
			this.lbTorque.Text = "Moment";
			this.lbTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.lbExtAna.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbExtAna.Location = new Point(8, 104);
			this.lbExtAna.Name = "lbExtAna";
			this.lbExtAna.Size = new Size(120, 23);
			this.lbExtAna.TabIndex = 1;
			this.lbExtAna.Text = "Ext. Analog";
			this.lbExtAna.TextAlign = ContentAlignment.MiddleLeft;
			this.lbADepth.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbADepth.Location = new Point(8, 72);
			this.lbADepth.Name = "lbADepth";
			this.lbADepth.Size = new Size(120, 23);
			this.lbADepth.TabIndex = 0;
			this.lbADepth.Text = "Ana. Tiefe";
			this.lbADepth.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowAI3.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowAI3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowAI3.Location = new Point(64, 104);
			this.lbShowAI3.Name = "lbShowAI3";
			this.lbShowAI3.Size = new Size(80, 23);
			this.lbShowAI3.TabIndex = 18;
			this.lbShowAI3.Text = "0";
			this.lbShowAI3.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowAI2.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowAI2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowAI2.Location = new Point(64, 72);
			this.lbShowAI2.Name = "lbShowAI2";
			this.lbShowAI2.Size = new Size(80, 23);
			this.lbShowAI2.TabIndex = 17;
			this.lbShowAI2.Text = "0";
			this.lbShowAI2.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowAI1.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowAI1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowAI1.Location = new Point(64, 40);
			this.lbShowAI1.Name = "lbShowAI1";
			this.lbShowAI1.Size = new Size(80, 23);
			this.lbShowAI1.TabIndex = 16;
			this.lbShowAI1.Text = "0";
			this.lbShowAI1.TextAlign = ContentAlignment.MiddleRight;
			this.lbAI3.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAI3.Location = new Point(8, 104);
			this.lbAI3.Name = "lbAI3";
			this.lbAI3.Size = new Size(48, 23);
			this.lbAI3.TabIndex = 15;
			this.lbAI3.Text = "AI3";
			this.lbAI3.TextAlign = ContentAlignment.MiddleLeft;
			this.lbAI2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAI2.Location = new Point(8, 72);
			this.lbAI2.Name = "lbAI2";
			this.lbAI2.Size = new Size(48, 23);
			this.lbAI2.TabIndex = 14;
			this.lbAI2.Text = "AI2";
			this.lbAI2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbAI1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAI1.Location = new Point(8, 40);
			this.lbAI1.Name = "lbAI1";
			this.lbAI1.Size = new Size(48, 23);
			this.lbAI1.TabIndex = 13;
			this.lbAI1.Text = "AI1";
			this.lbAI1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowAI0.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowAI0.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowAI0.Location = new Point(64, 8);
			this.lbShowAI0.Name = "lbShowAI0";
			this.lbShowAI0.Size = new Size(80, 23);
			this.lbShowAI0.TabIndex = 12;
			this.lbShowAI0.Text = "0";
			this.lbShowAI0.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowNact.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowNact.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowNact.Location = new Point(136, 8);
			this.lbShowNact.Name = "lbShowNact";
			this.lbShowNact.Size = new Size(80, 23);
			this.lbShowNact.TabIndex = 11;
			this.lbShowNact.Text = "0";
			this.lbShowNact.TextAlign = ContentAlignment.MiddleRight;
			this.lbAI0.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAI0.Location = new Point(8, 8);
			this.lbAI0.Name = "lbAI0";
			this.lbAI0.Size = new Size(48, 23);
			this.lbAI0.TabIndex = 4;
			this.lbAI0.Text = "AI0";
			this.lbAI0.TextAlign = ContentAlignment.MiddleLeft;
			this.lbNact.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbNact.Location = new Point(8, 8);
			this.lbNact.Name = "lbNact";
			this.lbNact.Size = new Size(120, 32);
			this.lbNact.TabIndex = 2;
			this.lbNact.Text = "Solldrehzahl";
			this.panel4.BorderStyle = BorderStyle.Fixed3D;
			this.panel4.Controls.Add(this.btResetEnc2);
			this.panel4.Controls.Add(this.btResetEnc1);
			this.panel4.Controls.Add(this.btResetEnc0);
			this.panel4.Controls.Add(this.lbShowEnc2);
			this.panel4.Controls.Add(this.lbShowEnc1);
			this.panel4.Controls.Add(this.lbShowEnc0);
			this.panel4.Controls.Add(this.lbEnc2);
			this.panel4.Controls.Add(this.lbEnc1);
			this.panel4.Controls.Add(this.lbEnc0);
			this.panel4.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.panel4.Location = new Point(160, 312);
			this.panel4.Name = "panel4";
			this.panel4.Size = new Size(248, 104);
			this.panel4.TabIndex = 5;
			this.btResetEnc2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btResetEnc2.Location = new Point(152, 72);
			this.btResetEnc2.Name = "btResetEnc2";
			this.btResetEnc2.Size = new Size(80, 23);
			this.btResetEnc2.TabIndex = 2;
			this.btResetEnc2.Text = "Reset";
			this.btResetEnc2.Click += this.btResetEnc2_Click;
			this.btResetEnc2.Enter += this.Start_Input;
			this.btResetEnc1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btResetEnc1.Location = new Point(152, 40);
			this.btResetEnc1.Name = "btResetEnc1";
			this.btResetEnc1.Size = new Size(80, 23);
			this.btResetEnc1.TabIndex = 1;
			this.btResetEnc1.Text = "Reset";
			this.btResetEnc1.Click += this.btResetEnc1_Click;
			this.btResetEnc1.Enter += this.Start_Input;
			this.btResetEnc0.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btResetEnc0.Location = new Point(152, 8);
			this.btResetEnc0.Name = "btResetEnc0";
			this.btResetEnc0.Size = new Size(80, 23);
			this.btResetEnc0.TabIndex = 0;
			this.btResetEnc0.Text = "Reset";
			this.btResetEnc0.Click += this.btResetEnc0_Click;
			this.btResetEnc0.Enter += this.Start_Input;
			this.lbShowEnc2.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowEnc2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowEnc2.Location = new Point(64, 72);
			this.lbShowEnc2.Name = "lbShowEnc2";
			this.lbShowEnc2.Size = new Size(80, 23);
			this.lbShowEnc2.TabIndex = 10;
			this.lbShowEnc2.Text = "0";
			this.lbShowEnc2.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowEnc1.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowEnc1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowEnc1.Location = new Point(64, 40);
			this.lbShowEnc1.Name = "lbShowEnc1";
			this.lbShowEnc1.Size = new Size(80, 23);
			this.lbShowEnc1.TabIndex = 9;
			this.lbShowEnc1.Text = "0";
			this.lbShowEnc1.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowEnc0.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowEnc0.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowEnc0.Location = new Point(64, 8);
			this.lbShowEnc0.Name = "lbShowEnc0";
			this.lbShowEnc0.Size = new Size(80, 23);
			this.lbShowEnc0.TabIndex = 8;
			this.lbShowEnc0.Text = "0";
			this.lbShowEnc0.TextAlign = ContentAlignment.MiddleRight;
			this.lbEnc2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbEnc2.Location = new Point(8, 72);
			this.lbEnc2.Name = "lbEnc2";
			this.lbEnc2.Size = new Size(48, 23);
			this.lbEnc2.TabIndex = 2;
			this.lbEnc2.Text = "Enc2";
			this.lbEnc2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbEnc1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbEnc1.Location = new Point(8, 40);
			this.lbEnc1.Name = "lbEnc1";
			this.lbEnc1.Size = new Size(48, 23);
			this.lbEnc1.TabIndex = 1;
			this.lbEnc1.Text = "Enc1";
			this.lbEnc1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbEnc0.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbEnc0.Location = new Point(8, 8);
			this.lbEnc0.Name = "lbEnc0";
			this.lbEnc0.Size = new Size(48, 23);
			this.lbEnc0.TabIndex = 0;
			this.lbEnc0.Text = "Enc0";
			this.lbEnc0.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitAngle.Location = new Point(224, 8);
			this.lbUnitAngle.Name = "lbUnitAngle";
			this.lbUnitAngle.Size = new Size(56, 23);
			this.lbUnitAngle.TabIndex = 22;
			this.lbUnitAngle.Text = "°";
			this.lbShowAngle.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowAngle.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowAngle.Location = new Point(136, 8);
			this.lbShowAngle.Name = "lbShowAngle";
			this.lbShowAngle.Size = new Size(80, 23);
			this.lbShowAngle.TabIndex = 11;
			this.lbShowAngle.Text = "0";
			this.lbShowAngle.TextAlign = ContentAlignment.MiddleRight;
			this.lbAngle.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAngle.Location = new Point(8, 8);
			this.lbAngle.Name = "lbAngle";
			this.lbAngle.Size = new Size(120, 23);
			this.lbAngle.TabIndex = 3;
			this.lbAngle.Text = "Winkel";
			this.lbAngle.TextAlign = ContentAlignment.MiddleLeft;
			this.panel5.BorderStyle = BorderStyle.Fixed3D;
			this.panel5.Controls.Add(this.btDO8);
			this.panel5.Controls.Add(this.btDO7);
			this.panel5.Controls.Add(this.btDO6);
			this.panel5.Controls.Add(this.btDO5);
			this.panel5.Controls.Add(this.btDO4);
			this.panel5.Controls.Add(this.btDO3);
			this.panel5.Controls.Add(this.btDO2);
			this.panel5.Controls.Add(this.btDO1);
			this.panel5.Controls.Add(this.btDO0);
			this.panel5.Controls.Add(this.btDO15);
			this.panel5.Controls.Add(this.btDO14);
			this.panel5.Controls.Add(this.btDO13);
			this.panel5.Controls.Add(this.btDO12);
			this.panel5.Controls.Add(this.btDO11);
			this.panel5.Controls.Add(this.btDO10);
			this.panel5.Controls.Add(this.btDO9);
			this.panel5.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.panel5.Location = new Point(72, 0);
			this.panel5.Name = "panel5";
			this.panel5.Size = new Size(88, 522);
			this.panel5.TabIndex = 2;
			this.btDO8.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO8.Location = new Point(10, 264);
			this.btDO8.Name = "btDO8";
			this.btDO8.Size = new Size(64, 23);
			this.btDO8.TabIndex = 8;
			this.btDO8.Tag = "8";
			this.btDO8.Text = "DO8";
			this.btDO8.Click += this.btDO_Click;
			this.btDO8.Enter += this.Start_Input;
			this.btDO7.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO7.Location = new Point(10, 232);
			this.btDO7.Name = "btDO7";
			this.btDO7.Size = new Size(64, 23);
			this.btDO7.TabIndex = 7;
			this.btDO7.Tag = "7";
			this.btDO7.Text = "DO7";
			this.btDO7.Click += this.btDO_Click;
			this.btDO7.Enter += this.Start_Input;
			this.btDO6.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO6.Location = new Point(10, 200);
			this.btDO6.Name = "btDO6";
			this.btDO6.Size = new Size(64, 23);
			this.btDO6.TabIndex = 6;
			this.btDO6.Tag = "6";
			this.btDO6.Text = "DO6";
			this.btDO6.Click += this.btDO_Click;
			this.btDO6.Enter += this.Start_Input;
			this.btDO5.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO5.Location = new Point(10, 168);
			this.btDO5.Name = "btDO5";
			this.btDO5.Size = new Size(64, 23);
			this.btDO5.TabIndex = 5;
			this.btDO5.Tag = "5";
			this.btDO5.Text = "DO5";
			this.btDO5.Click += this.btDO_Click;
			this.btDO5.Enter += this.Start_Input;
			this.btDO4.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO4.Location = new Point(10, 136);
			this.btDO4.Name = "btDO4";
			this.btDO4.Size = new Size(64, 23);
			this.btDO4.TabIndex = 4;
			this.btDO4.Tag = "4";
			this.btDO4.Text = "DO4";
			this.btDO4.Click += this.btDO_Click;
			this.btDO4.Enter += this.Start_Input;
			this.btDO3.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO3.Location = new Point(10, 104);
			this.btDO3.Name = "btDO3";
			this.btDO3.Size = new Size(64, 23);
			this.btDO3.TabIndex = 3;
			this.btDO3.Tag = "3";
			this.btDO3.Text = "DO3";
			this.btDO3.Click += this.btDO_Click;
			this.btDO3.Enter += this.Start_Input;
			this.btDO2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO2.Location = new Point(10, 72);
			this.btDO2.Name = "btDO2";
			this.btDO2.Size = new Size(64, 23);
			this.btDO2.TabIndex = 2;
			this.btDO2.Tag = "2";
			this.btDO2.Text = "DO2";
			this.btDO2.Click += this.btDO_Click;
			this.btDO2.Enter += this.Start_Input;
			this.btDO1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO1.Location = new Point(10, 40);
			this.btDO1.Name = "btDO1";
			this.btDO1.Size = new Size(64, 23);
			this.btDO1.TabIndex = 1;
			this.btDO1.Tag = "1";
			this.btDO1.Text = "DO1";
			this.btDO1.Click += this.btDO_Click;
			this.btDO1.Enter += this.Start_Input;
			this.btDO0.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO0.Location = new Point(10, 8);
			this.btDO0.Name = "btDO0";
			this.btDO0.Size = new Size(64, 23);
			this.btDO0.TabIndex = 0;
			this.btDO0.Tag = "0";
			this.btDO0.Text = "DO0";
			this.btDO0.Click += this.btDO_Click;
			this.btDO0.Enter += this.Start_Input;
			this.btDO15.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO15.Location = new Point(10, 488);
			this.btDO15.Name = "btDO15";
			this.btDO15.Size = new Size(64, 23);
			this.btDO15.TabIndex = 15;
			this.btDO15.Tag = "15";
			this.btDO15.Text = "DO15";
			this.btDO15.Click += this.btDO_Click;
			this.btDO15.Enter += this.Start_Input;
			this.btDO14.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO14.Location = new Point(10, 456);
			this.btDO14.Name = "btDO14";
			this.btDO14.Size = new Size(64, 23);
			this.btDO14.TabIndex = 14;
			this.btDO14.Tag = "14";
			this.btDO14.Text = "DO14";
			this.btDO14.Click += this.btDO_Click;
			this.btDO14.Enter += this.Start_Input;
			this.btDO13.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO13.Location = new Point(10, 424);
			this.btDO13.Name = "btDO13";
			this.btDO13.Size = new Size(64, 23);
			this.btDO13.TabIndex = 13;
			this.btDO13.Tag = "13";
			this.btDO13.Text = "DO13";
			this.btDO13.Click += this.btDO_Click;
			this.btDO13.Enter += this.Start_Input;
			this.btDO12.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO12.Location = new Point(10, 392);
			this.btDO12.Name = "btDO12";
			this.btDO12.Size = new Size(64, 23);
			this.btDO12.TabIndex = 12;
			this.btDO12.Tag = "12";
			this.btDO12.Text = "DO12";
			this.btDO12.Click += this.btDO_Click;
			this.btDO12.Enter += this.Start_Input;
			this.btDO11.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO11.Location = new Point(10, 360);
			this.btDO11.Name = "btDO11";
			this.btDO11.Size = new Size(64, 23);
			this.btDO11.TabIndex = 11;
			this.btDO11.Tag = "11";
			this.btDO11.Text = "DO11";
			this.btDO11.Click += this.btDO_Click;
			this.btDO11.Enter += this.Start_Input;
			this.btDO10.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO10.Location = new Point(10, 328);
			this.btDO10.Name = "btDO10";
			this.btDO10.Size = new Size(64, 23);
			this.btDO10.TabIndex = 10;
			this.btDO10.Tag = "10";
			this.btDO10.Text = "DO10";
			this.btDO10.Click += this.btDO_Click;
			this.btDO10.Enter += this.Start_Input;
			this.btDO9.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDO9.Location = new Point(10, 296);
			this.btDO9.Name = "btDO9";
			this.btDO9.Size = new Size(64, 23);
			this.btDO9.TabIndex = 9;
			this.btDO9.Tag = "9";
			this.btDO9.Text = "DO9";
			this.btDO9.Click += this.btDO_Click;
			this.btDO9.Enter += this.Start_Input;
			this.panel2.BorderStyle = BorderStyle.Fixed3D;
			this.panel2.Controls.Add(this.btResetEncError);
			this.panel2.Controls.Add(this.lbShowEncError);
			this.panel2.Controls.Add(this.lbEncError);
			this.panel2.Controls.Add(this.lbShowBattery);
			this.panel2.Controls.Add(this.lbBattery);
			this.panel2.Controls.Add(this.lbShowAIError);
			this.panel2.Controls.Add(this.lbAIError);
			this.panel2.Controls.Add(this.lbShowISRCount);
			this.panel2.Controls.Add(this.lbShowHexSwitch);
			this.panel2.Controls.Add(this.lbShowGradCount);
			this.panel2.Controls.Add(this.lbISRCount);
			this.panel2.Controls.Add(this.lbHexSwitch);
			this.panel2.Controls.Add(this.lbGradCount);
			this.panel2.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.panel2.Location = new Point(160, 416);
			this.panel2.Name = "panel2";
			this.panel2.Size = new Size(544, 104);
			this.panel2.TabIndex = 9;
			this.btResetEncError.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btResetEncError.Location = new Point(448, 40);
			this.btResetEncError.Name = "btResetEncError";
			this.btResetEncError.Size = new Size(80, 23);
			this.btResetEncError.TabIndex = 0;
			this.btResetEncError.Text = "Reset";
			this.btResetEncError.Click += this.btResetEncError_Click;
			this.btResetEncError.Enter += this.Start_Input;
			this.lbShowEncError.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowEncError.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowEncError.Location = new Point(392, 40);
			this.lbShowEncError.Name = "lbShowEncError";
			this.lbShowEncError.Size = new Size(48, 23);
			this.lbShowEncError.TabIndex = 24;
			this.lbShowEncError.Text = "0";
			this.lbShowEncError.TextAlign = ContentAlignment.MiddleRight;
			this.lbEncError.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbEncError.Location = new Point(264, 40);
			this.lbEncError.Name = "lbEncError";
			this.lbEncError.Size = new Size(120, 23);
			this.lbEncError.TabIndex = 23;
			this.lbEncError.Text = "Enc Fehler";
			this.lbEncError.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowBattery.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowBattery.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowBattery.Location = new Point(392, 72);
			this.lbShowBattery.Name = "lbShowBattery";
			this.lbShowBattery.Size = new Size(48, 23);
			this.lbShowBattery.TabIndex = 14;
			this.lbShowBattery.Text = "0";
			this.lbShowBattery.TextAlign = ContentAlignment.MiddleRight;
			this.lbBattery.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbBattery.Location = new Point(264, 72);
			this.lbBattery.Name = "lbBattery";
			this.lbBattery.Size = new Size(120, 23);
			this.lbBattery.TabIndex = 13;
			this.lbBattery.Text = "Batterie";
			this.lbBattery.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowAIError.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowAIError.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowAIError.Location = new Point(392, 8);
			this.lbShowAIError.Name = "lbShowAIError";
			this.lbShowAIError.Size = new Size(48, 23);
			this.lbShowAIError.TabIndex = 12;
			this.lbShowAIError.Text = "0";
			this.lbShowAIError.TextAlign = ContentAlignment.MiddleRight;
			this.lbAIError.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAIError.Location = new Point(264, 8);
			this.lbAIError.Name = "lbAIError";
			this.lbAIError.Size = new Size(120, 23);
			this.lbAIError.TabIndex = 11;
			this.lbAIError.Text = "AI Fehler";
			this.lbAIError.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowISRCount.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowISRCount.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowISRCount.Location = new Point(136, 72);
			this.lbShowISRCount.Name = "lbShowISRCount";
			this.lbShowISRCount.Size = new Size(104, 23);
			this.lbShowISRCount.TabIndex = 10;
			this.lbShowISRCount.Text = "0";
			this.lbShowISRCount.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowHexSwitch.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowHexSwitch.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowHexSwitch.Location = new Point(136, 40);
			this.lbShowHexSwitch.Name = "lbShowHexSwitch";
			this.lbShowHexSwitch.Size = new Size(104, 23);
			this.lbShowHexSwitch.TabIndex = 9;
			this.lbShowHexSwitch.Text = "0";
			this.lbShowHexSwitch.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowGradCount.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowGradCount.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowGradCount.Location = new Point(136, 8);
			this.lbShowGradCount.Name = "lbShowGradCount";
			this.lbShowGradCount.Size = new Size(104, 23);
			this.lbShowGradCount.TabIndex = 8;
			this.lbShowGradCount.Text = "0";
			this.lbShowGradCount.TextAlign = ContentAlignment.MiddleRight;
			this.lbISRCount.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbISRCount.Location = new Point(8, 72);
			this.lbISRCount.Name = "lbISRCount";
			this.lbISRCount.Size = new Size(120, 23);
			this.lbISRCount.TabIndex = 2;
			this.lbISRCount.Text = "Life Sign";
			this.lbISRCount.TextAlign = ContentAlignment.MiddleLeft;
			this.lbHexSwitch.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbHexSwitch.Location = new Point(8, 40);
			this.lbHexSwitch.Name = "lbHexSwitch";
			this.lbHexSwitch.Size = new Size(120, 23);
			this.lbHexSwitch.TabIndex = 1;
			this.lbHexSwitch.Text = "Drehschalter";
			this.lbHexSwitch.TextAlign = ContentAlignment.MiddleLeft;
			this.lbGradCount.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbGradCount.Location = new Point(8, 8);
			this.lbGradCount.Name = "lbGradCount";
			this.lbGradCount.Size = new Size(120, 23);
			this.lbGradCount.TabIndex = 0;
			this.lbGradCount.Text = "Grad Count";
			this.lbGradCount.TextAlign = ContentAlignment.MiddleLeft;
			this.timerUpdate.Interval = 500;
			this.timerUpdate.Tick += this.timerUpdate_Tick;
			this.panel6.BorderStyle = BorderStyle.Fixed3D;
			this.panel6.Controls.Add(this.lbUnitAI2);
			this.panel6.Controls.Add(this.lbUnitAI3);
			this.panel6.Controls.Add(this.lbUnitAI1);
			this.panel6.Controls.Add(this.lbUnitAI0);
			this.panel6.Controls.Add(this.lbShowAI3);
			this.panel6.Controls.Add(this.lbShowAI2);
			this.panel6.Controls.Add(this.lbShowAI1);
			this.panel6.Controls.Add(this.lbAI3);
			this.panel6.Controls.Add(this.lbAI2);
			this.panel6.Controls.Add(this.lbAI1);
			this.panel6.Controls.Add(this.lbShowAI0);
			this.panel6.Controls.Add(this.lbAI0);
			this.panel6.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.panel6.Location = new Point(160, 0);
			this.panel6.Name = "panel6";
			this.panel6.Size = new Size(248, 136);
			this.panel6.TabIndex = 3;
			this.lbUnitAI2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitAI2.Location = new Point(152, 72);
			this.lbUnitAI2.Name = "lbUnitAI2";
			this.lbUnitAI2.Size = new Size(40, 23);
			this.lbUnitAI2.TabIndex = 22;
			this.lbUnitAI2.Text = "V";
			this.lbUnitAI2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitAI3.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitAI3.Location = new Point(152, 104);
			this.lbUnitAI3.Name = "lbUnitAI3";
			this.lbUnitAI3.Size = new Size(40, 23);
			this.lbUnitAI3.TabIndex = 21;
			this.lbUnitAI3.Text = "V";
			this.lbUnitAI3.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitAI1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitAI1.Location = new Point(152, 40);
			this.lbUnitAI1.Name = "lbUnitAI1";
			this.lbUnitAI1.Size = new Size(40, 23);
			this.lbUnitAI1.TabIndex = 20;
			this.lbUnitAI1.Text = "V";
			this.lbUnitAI1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitAI0.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitAI0.Location = new Point(152, 8);
			this.lbUnitAI0.Name = "lbUnitAI0";
			this.lbUnitAI0.Size = new Size(40, 23);
			this.lbUnitAI0.TabIndex = 19;
			this.lbUnitAI0.Text = "V";
			this.lbUnitAI0.TextAlign = ContentAlignment.MiddleLeft;
			this.panel7.BorderStyle = BorderStyle.Fixed3D;
			this.panel7.Controls.Add(this.btSetAO);
			this.panel7.Controls.Add(this.nEAO2);
			this.panel7.Controls.Add(this.nEAO1);
			this.panel7.Controls.Add(this.nEAO3);
			this.panel7.Controls.Add(this.nEAO0);
			this.panel7.Controls.Add(this.lbUnitAO2);
			this.panel7.Controls.Add(this.lbUnitAO3);
			this.panel7.Controls.Add(this.lbUnitAO1);
			this.panel7.Controls.Add(this.lbUnitAO0);
			this.panel7.Controls.Add(this.lbAO3);
			this.panel7.Controls.Add(this.lbAO2);
			this.panel7.Controls.Add(this.lbAO1);
			this.panel7.Controls.Add(this.lbAO0);
			this.panel7.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.panel7.Location = new Point(160, 136);
			this.panel7.Name = "panel7";
			this.panel7.Size = new Size(248, 176);
			this.panel7.TabIndex = 4;
			this.btSetAO.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btSetAO.Location = new Point(64, 144);
			this.btSetAO.Name = "btSetAO";
			this.btSetAO.Size = new Size(80, 23);
			this.btSetAO.TabIndex = 4;
			this.btSetAO.Text = "Setzen";
			this.btSetAO.Click += this.btSetAO_Click;
			this.btSetAO.Enter += this.Start_Input;
			this.nEAO2.BackColor = Color.White;
			this.nEAO2.DecimalNum = 2;
			this.nEAO2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAO2.ForeColor = SystemColors.ControlText;
			this.nEAO2.Location = new Point(64, 69);
			this.nEAO2.MaxValue = 10f;
			this.nEAO2.MinValue = -10f;
			this.nEAO2.Name = "nEAO2";
			this.nEAO2.Size = new Size(80, 28);
			this.nEAO2.TabIndex = 2;
			this.nEAO2.Text = "0,00";
			this.nEAO2.TextAlign = HorizontalAlignment.Right;
			this.nEAO2.Value = 0f;
			this.nEAO2.Enter += this.Start_Input;
			this.nEAO2.MouseDown += this.StartInput;
			this.nEAO1.BackColor = Color.White;
			this.nEAO1.DecimalNum = 2;
			this.nEAO1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAO1.ForeColor = SystemColors.ControlText;
			this.nEAO1.Location = new Point(64, 37);
			this.nEAO1.MaxValue = 10f;
			this.nEAO1.MinValue = -10f;
			this.nEAO1.Name = "nEAO1";
			this.nEAO1.Size = new Size(80, 28);
			this.nEAO1.TabIndex = 1;
			this.nEAO1.Text = "0,00";
			this.nEAO1.TextAlign = HorizontalAlignment.Right;
			this.nEAO1.Value = 0f;
			this.nEAO1.Enter += this.Start_Input;
			this.nEAO1.MouseDown += this.StartInput;
			this.nEAO3.BackColor = Color.White;
			this.nEAO3.DecimalNum = 2;
			this.nEAO3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAO3.ForeColor = SystemColors.ControlText;
			this.nEAO3.Location = new Point(64, 101);
			this.nEAO3.MaxValue = 10f;
			this.nEAO3.MinValue = -10f;
			this.nEAO3.Name = "nEAO3";
			this.nEAO3.Size = new Size(80, 28);
			this.nEAO3.TabIndex = 3;
			this.nEAO3.Text = "0,00";
			this.nEAO3.TextAlign = HorizontalAlignment.Right;
			this.nEAO3.Value = 0f;
			this.nEAO3.Enter += this.Start_Input;
			this.nEAO3.MouseDown += this.StartInput;
			this.nEAO0.BackColor = Color.White;
			this.nEAO0.DecimalNum = 2;
			this.nEAO0.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAO0.ForeColor = SystemColors.ControlText;
			this.nEAO0.Location = new Point(64, 5);
			this.nEAO0.MaxValue = 10f;
			this.nEAO0.MinValue = -10f;
			this.nEAO0.Name = "nEAO0";
			this.nEAO0.Size = new Size(80, 28);
			this.nEAO0.TabIndex = 0;
			this.nEAO0.Text = "0,00";
			this.nEAO0.TextAlign = HorizontalAlignment.Right;
			this.nEAO0.Value = 0f;
			this.nEAO0.Enter += this.Start_Input;
			this.nEAO0.MouseDown += this.StartInput;
			this.lbUnitAO2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitAO2.Location = new Point(152, 72);
			this.lbUnitAO2.Name = "lbUnitAO2";
			this.lbUnitAO2.Size = new Size(40, 23);
			this.lbUnitAO2.TabIndex = 22;
			this.lbUnitAO2.Text = "V";
			this.lbUnitAO2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitAO3.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitAO3.Location = new Point(152, 104);
			this.lbUnitAO3.Name = "lbUnitAO3";
			this.lbUnitAO3.Size = new Size(40, 23);
			this.lbUnitAO3.TabIndex = 21;
			this.lbUnitAO3.Text = "V";
			this.lbUnitAO3.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitAO1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitAO1.Location = new Point(152, 40);
			this.lbUnitAO1.Name = "lbUnitAO1";
			this.lbUnitAO1.Size = new Size(40, 23);
			this.lbUnitAO1.TabIndex = 20;
			this.lbUnitAO1.Text = "V";
			this.lbUnitAO1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitAO0.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitAO0.Location = new Point(152, 8);
			this.lbUnitAO0.Name = "lbUnitAO0";
			this.lbUnitAO0.Size = new Size(40, 23);
			this.lbUnitAO0.TabIndex = 19;
			this.lbUnitAO0.Text = "V";
			this.lbUnitAO0.TextAlign = ContentAlignment.MiddleLeft;
			this.lbAO3.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAO3.Location = new Point(8, 104);
			this.lbAO3.Name = "lbAO3";
			this.lbAO3.Size = new Size(48, 23);
			this.lbAO3.TabIndex = 15;
			this.lbAO3.Text = "AO3";
			this.lbAO3.TextAlign = ContentAlignment.MiddleLeft;
			this.lbAO2.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAO2.Location = new Point(8, 72);
			this.lbAO2.Name = "lbAO2";
			this.lbAO2.Size = new Size(48, 23);
			this.lbAO2.TabIndex = 14;
			this.lbAO2.Text = "AO2";
			this.lbAO2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbAO1.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAO1.Location = new Point(8, 40);
			this.lbAO1.Name = "lbAO1";
			this.lbAO1.Size = new Size(48, 23);
			this.lbAO1.TabIndex = 13;
			this.lbAO1.Text = "AO1";
			this.lbAO1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbAO0.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAO0.Location = new Point(8, 8);
			this.lbAO0.Name = "lbAO0";
			this.lbAO0.Size = new Size(48, 23);
			this.lbAO0.TabIndex = 4;
			this.lbAO0.Text = "AO0";
			this.lbAO0.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitNact.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitNact.Location = new Point(224, 8);
			this.lbUnitNact.Name = "lbUnitNact";
			this.lbUnitNact.Size = new Size(56, 23);
			this.lbUnitNact.TabIndex = 25;
			this.lbUnitNact.Text = "1/min";
			this.lbUnitNact.TextAlign = ContentAlignment.MiddleLeft;
			this.panel9.BorderStyle = BorderStyle.Fixed3D;
			this.panel9.Controls.Add(this.lbRedAngle);
			this.panel9.Controls.Add(this.lbShowRedAngle);
			this.panel9.Controls.Add(this.lbUnitRedAngle);
			this.panel9.Controls.Add(this.lbAngle);
			this.panel9.Controls.Add(this.lbShowAngle);
			this.panel9.Controls.Add(this.lbUnitAngle);
			this.panel9.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.panel9.Location = new Point(408, 312);
			this.panel9.Name = "panel9";
			this.panel9.Size = new Size(296, 104);
			this.panel9.TabIndex = 8;
			this.lbRedAngle.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbRedAngle.Location = new Point(8, 39);
			this.lbRedAngle.Name = "lbRedAngle";
			this.lbRedAngle.Size = new Size(120, 23);
			this.lbRedAngle.TabIndex = 23;
			this.lbRedAngle.Text = "Red. Winkel";
			this.lbRedAngle.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowRedAngle.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowRedAngle.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowRedAngle.Location = new Point(136, 39);
			this.lbShowRedAngle.Name = "lbShowRedAngle";
			this.lbShowRedAngle.Size = new Size(80, 23);
			this.lbShowRedAngle.TabIndex = 24;
			this.lbShowRedAngle.Text = "0";
			this.lbShowRedAngle.TextAlign = ContentAlignment.MiddleRight;
			this.lbUnitRedAngle.Location = new Point(224, 39);
			this.lbUnitRedAngle.Name = "lbUnitRedAngle";
			this.lbUnitRedAngle.Size = new Size(56, 23);
			this.lbUnitRedAngle.TabIndex = 25;
			this.lbUnitRedAngle.Text = "°";
			this.panel10.BorderStyle = BorderStyle.Fixed3D;
			this.panel10.Controls.Add(this.lbUnitNact);
			this.panel10.Controls.Add(this.lbShowNact);
			this.panel10.Controls.Add(this.lbNact);
			this.panel10.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.panel10.Location = new Point(408, 136);
			this.panel10.Name = "panel10";
			this.panel10.Size = new Size(296, 176);
			this.panel10.TabIndex = 7;
			this.btPLCInterface.Location = new Point(3, 259);
			this.btPLCInterface.Name = "btPLCInterface";
			this.btPLCInterface.Size = new Size(74, 62);
			this.btPLCInterface.TabIndex = 10;
			this.btPLCInterface.Text = "SPS I/O";
			this.btPLCInterface.Click += this.btPLCInterface_Click;
			this.btMotorSensor.Location = new Point(3, 131);
			this.btMotorSensor.Name = "btMotorSensor";
			this.btMotorSensor.Size = new Size(74, 62);
			this.btMotorSensor.TabIndex = 8;
			this.btMotorSensor.Text = "Motor Reibwert Sensor";
			this.btMotorSensor.Click += this.btMotorSensor_Click;
			this.btIOTest.Enabled = false;
			this.btIOTest.Location = new Point(3, 195);
			this.btIOTest.Name = "btIOTest";
			this.btIOTest.Size = new Size(74, 62);
			this.btIOTest.TabIndex = 9;
			this.btIOTest.Text = "I/O";
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.panel10);
			base.Controls.Add(this.panel9);
			base.Controls.Add(this.panel7);
			base.Controls.Add(this.panel6);
			base.Controls.Add(this.panel2);
			base.Controls.Add(this.panel5);
			base.Controls.Add(this.panel1);
			base.Controls.Add(this.pnMenu);
			base.Controls.Add(this.panel3);
			base.Controls.Add(this.panel4);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "TestIOForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Test/IO";
			base.Activated += this.TestIOForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel6.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.panel7.PerformLayout();
			this.panel9.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public bool ShowWindow()
		{
			this.Main.ActivationBrowserGrantedBy = this;
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadIO"));
			if (!this.Main.VC.ReceiveVarBlock(40))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive TestDataRawInBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.MenEna();
			Cursor.Current = Cursors.Default;
			this.Main.VC.TestDataRawOut.Command = 1;
			this.Main.VC.TestDataRawOut.DO16 = 0;
			this.SendTestBlock();
			this.Main.VC.TestDataRawOut.Command = 3;
			this.Main.VC.TestDataRawOut.Uo0 = 0f;
			this.Main.VC.TestDataRawOut.Uo1 = 0f;
			this.Main.VC.TestDataRawOut.Uo2 = 0f;
			this.Main.VC.TestDataRawOut.Uo3 = 0f;
			this.lbUnitTorque.Text = this.Main.TorqueUnitName;
			this.SendTestBlock();
			this.UpdateValues();
			this.timerUpdate.Enabled = true;
			base.Show();
			Application.DoEvents();
			this.Main.StatusBarText(string.Empty);
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuTest") + "/" + this.Main.Rm.GetString("TestIO");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btIOTest.Text = this.Main.Rm.GetString("IOTest");
			this.btMotorSensor.Text = this.Main.Rm.GetString("IntegratedTests");
			this.btPLCInterface.Text = this.Main.Rm.GetString("PLC_IO");
			this.btSetAO.Text = this.Main.Rm.GetString("Set");
			this.btResetEnc0.Text = this.Main.Rm.GetString("Reset");
			this.btResetEnc1.Text = this.Main.Rm.GetString("Reset");
			this.btResetEnc2.Text = this.Main.Rm.GetString("Reset");
			this.btResetEncError.Text = this.Main.Rm.GetString("Reset");
			this.lbAIError.Text = this.Main.Rm.GetString("AIError");
			this.lbEncError.Text = this.Main.Rm.GetString("EncError");
			this.lbHexSwitch.Text = this.Main.Rm.GetString("HexSwitch");
			this.lbBattery.Text = this.Main.Rm.GetString("Battery");
			this.lbAngle.Text = this.Main.Rm.GetString("Angle");
			this.lbRedAngle.Text = this.Main.Rm.GetString("RedAngle");
			this.lbUnitNact.Text = this.Main.Rm.GetString("RpmUnit");
			this.lbNact.Text = this.Main.Rm.GetString("GetRpm");
			this.lbExtAna.Text = this.Main.Rm.GetString("AnaSignal");
			this.lbADepth.Text = this.Main.Rm.GetString("AnaDepth");
			this.lbTorque.Text = this.Main.Rm.GetString("Torque");
			this.lbRedTorque.Text = this.Main.Rm.GetString("RedTorque");
			this.lbUnitAI0.Text = this.Main.Rm.GetString("Voltage");
			this.lbUnitAI1.Text = this.Main.Rm.GetString("Voltage");
			this.lbUnitAI2.Text = this.Main.Rm.GetString("Voltage");
			this.lbUnitAI3.Text = this.Main.Rm.GetString("Voltage");
			this.lbUnitAO0.Text = this.Main.Rm.GetString("Voltage");
			this.lbUnitAO1.Text = this.Main.Rm.GetString("Voltage");
			this.lbUnitAO2.Text = this.Main.Rm.GetString("Voltage");
			this.lbUnitAO3.Text = this.Main.Rm.GetString("Voltage");
			this.lbUnitADepth.Text = this.Main.Rm.GetString("Milimeter");
			this.lbUnitAngle.Text = this.Main.Rm.GetString("Degree");
			this.lbUnitRedAngle.Text = this.Main.Rm.GetString("Degree");
			this.lbUnitTorque.Text = this.Main.TorqueUnitName;
			this.lbUnitRedTorque.Text = this.Main.TorqueUnitName;
		}

		private void MenEna()
		{
			bool enabled = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_TestIOForm)
			{
				enabled = true;
			}
			if (!this.Main.Usb_Key_Access())
			{
				enabled = true;
			}
			else
			{
				this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_TestIOForm, false);
			}
			if (!this.Main.MenuTest1.WritePermission)
			{
				enabled = false;
			}
			this.nEAO0.Enabled = enabled;
			this.nEAO1.Enabled = enabled;
			this.nEAO2.Enabled = enabled;
			this.nEAO3.Enabled = enabled;
			this.btDO0.Enabled = enabled;
			this.btDO1.Enabled = enabled;
			this.btDO2.Enabled = enabled;
			this.btDO3.Enabled = enabled;
			this.btDO4.Enabled = enabled;
			this.btDO5.Enabled = enabled;
			this.btDO6.Enabled = enabled;
			this.btDO7.Enabled = enabled;
			this.btDO8.Enabled = enabled;
			this.btDO9.Enabled = enabled;
			this.btDO10.Enabled = false;
			this.btDO11.Enabled = false;
			this.btDO12.Enabled = false;
			this.btDO13.Enabled = false;
			this.btDO14.Enabled = false;
			this.btDO15.Enabled = false;
			this.btSetAO.Enabled = enabled;
			this.btResetEnc0.Enabled = enabled;
			this.btResetEnc1.Enabled = enabled;
			this.btResetEnc2.Enabled = enabled;
			this.btResetEncError.Enabled = enabled;
			this.nEAO0.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEAO1.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEAO2.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEAO3.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
		}

		private void UpdateValues()
		{
			if ((this.Main.VC.TestDataRawIn.DI & 1) > 0)
			{
				this.lbDI0.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI0.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 2) > 0)
			{
				this.lbDI1.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI1.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 4) > 0)
			{
				this.lbDI2.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI2.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 8) > 0)
			{
				this.lbDI3.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI3.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 0x10) > 0)
			{
				this.lbDI4.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI4.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 0x20) > 0)
			{
				this.lbDI5.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI5.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 0x40) > 0)
			{
				this.lbDI6.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI6.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 0x80) > 0)
			{
				this.lbDI7.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI7.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 0x100) > 0)
			{
				this.lbDI8.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI8.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 0x200) > 0)
			{
				this.lbDI9.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI9.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 0x400) > 0)
			{
				this.lbDI10.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI10.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 0x800) > 0)
			{
				this.lbDI11.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI11.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 0x1000) > 0)
			{
				this.lbDI12.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI12.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 0x2000) > 0)
			{
				this.lbDI13.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI13.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 0x4000) > 0)
			{
				this.lbDI14.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI14.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DI & 0x8000) > 0)
			{
				this.lbDI15.BackColor = Color.Lime;
			}
			else
			{
				this.lbDI15.BackColor = Color.Red;
			}
			this.lbShowTorque.Text = (this.Main.VC.TestDataRawIn.Torque1 * this.Main.TorqueConvert).ToString();
			this.lbShowRedTorque.Text = (this.Main.VC.TestDataRawIn.Torque2 * this.Main.TorqueConvert).ToString();
			this.lbShowADepth.Text = this.Main.VC.TestDataRawIn.ADepth.ToString();
			this.lbShowExtAna.Text = this.Main.VC.TestDataRawIn.ExtAna.ToString();
			this.lbShowNact.Text = this.Main.VC.TestDataRawIn.Nact.ToString();
			this.lbShowAI0.Text = this.Main.VC.TestDataRawIn.Ui0.ToString();
			this.lbShowAI1.Text = this.Main.VC.TestDataRawIn.Ui1.ToString();
			this.lbShowAI2.Text = this.Main.VC.TestDataRawIn.Ui2.ToString();
			this.lbShowAI3.Text = this.Main.VC.TestDataRawIn.Ui3.ToString();
			this.lbShowEnc0.Text = this.Main.VC.TestDataRawIn.Enc0.ToString();
			this.lbShowEnc1.Text = this.Main.VC.TestDataRawIn.Enc1.ToString();
			this.lbShowEnc2.Text = this.Main.VC.TestDataRawIn.Enc3.ToString();
			this.lbShowAngle.Text = this.Main.VC.TestDataRawIn.Angle1.ToString();
			this.lbShowRedAngle.Text = this.Main.VC.TestDataRawIn.Angle2.ToString();
			this.lbShowGradCount.Text = this.Main.VC.TestDataRawIn.GRADCount.ToString();
			this.lbShowHexSwitch.Text = "0x" + this.Main.VC.TestDataRawIn.HexSwitch.ToString("x") + " (" + this.Main.VC.TestDataRawIn.HexSwitch.ToString() + ")";
			this.lbShowISRCount.Text = this.Main.VC.TestDataRawIn.ISRCount.ToString();
			this.lbShowAIError.Text = this.Main.VC.TestDataRawIn.UErr.ToString("x");
			this.lbShowEncError.Text = this.Main.VC.TestDataRawIn.EncErr.ToString("x");
			if (this.Main.VC.TestDataRawIn.BatteryOk > 0)
			{
				this.lbShowBattery.Text = this.Main.Rm.GetString("OK");
				this.lbShowBattery.BackColor = SystemColors.Control;
			}
			else
			{
				this.lbShowBattery.Text = this.Main.Rm.GetString("Empty");
				this.lbShowBattery.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 1) > 0)
			{
				this.btDO0.BackColor = Color.Lime;
			}
			else
			{
				this.btDO0.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 2) > 0)
			{
				this.btDO1.BackColor = Color.Lime;
			}
			else
			{
				this.btDO1.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 4) > 0)
			{
				this.btDO2.BackColor = Color.Lime;
			}
			else
			{
				this.btDO2.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 8) > 0)
			{
				this.btDO3.BackColor = Color.Lime;
			}
			else
			{
				this.btDO3.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 0x10) > 0)
			{
				this.btDO4.BackColor = Color.Lime;
			}
			else
			{
				this.btDO4.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 0x20) > 0)
			{
				this.btDO5.BackColor = Color.Lime;
			}
			else
			{
				this.btDO5.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 0x40) > 0)
			{
				this.btDO6.BackColor = Color.Lime;
			}
			else
			{
				this.btDO6.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 0x80) > 0)
			{
				this.btDO7.BackColor = Color.Lime;
			}
			else
			{
				this.btDO7.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 0x100) > 0)
			{
				this.btDO8.BackColor = Color.Lime;
			}
			else
			{
				this.btDO8.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 0x200) > 0)
			{
				this.btDO9.BackColor = Color.Lime;
			}
			else
			{
				this.btDO9.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 0x400) > 0)
			{
				this.btDO10.BackColor = Color.Lime;
			}
			else
			{
				this.btDO10.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 0x800) > 0)
			{
				this.btDO11.BackColor = Color.Lime;
			}
			else
			{
				this.btDO11.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 0x1000) > 0)
			{
				this.btDO12.BackColor = Color.Lime;
			}
			else
			{
				this.btDO12.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 0x2000) > 0)
			{
				this.btDO13.BackColor = Color.Lime;
			}
			else
			{
				this.btDO13.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 0x4000) > 0)
			{
				this.btDO14.BackColor = Color.Lime;
			}
			else
			{
				this.btDO14.BackColor = Color.Red;
			}
			if ((this.Main.VC.TestDataRawIn.DO & 0x8000) > 0)
			{
				this.btDO15.BackColor = Color.Lime;
			}
			else
			{
				this.btDO15.BackColor = Color.Red;
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.Main.VC.TestDataRawOut.Command = 1;
			this.Main.VC.TestDataRawOut.DO16 = 0;
			this.SendTestBlock();
			this.timerUpdate.Enabled = false;
			base.Hide();
			if (sender != null)
			{
				this.Main.MenuTest1.Back();
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_3_2_IO_Anzeige";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_3_2_IO_Anzeige");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void timerUpdate_Tick(object sender, EventArgs e)
		{
			this.timerUpdate.Enabled = false;
			if (this.Main.IsOnlineMode)
			{
				if (!this.Main.VC.ReceiveVarBlock(40))
				{
					MessageBox.Show("Could not receive TestDataRawInBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					this.btBack_Click(null, null);
				}
				else
				{
					this.UpdateValues();
					this.timerUpdate.Enabled = true;
				}
			}
		}

		private void btDO_Click(object sender, EventArgs e)
		{
			int num = int.Parse(((Button)sender).Tag.ToString());
			int num2 = 0;
			switch (num)
			{
			case 0:
				num2 = 1;
				break;
			case 1:
				num2 = 2;
				break;
			case 2:
				num2 = 4;
				break;
			case 3:
				num2 = 8;
				break;
			case 4:
				num2 = 16;
				break;
			case 5:
				num2 = 32;
				break;
			case 6:
				num2 = 64;
				break;
			case 7:
				num2 = 128;
				break;
			case 8:
				num2 = 256;
				break;
			case 9:
				num2 = 512;
				break;
			case 10:
				num2 = 1024;
				break;
			case 11:
				num2 = 2048;
				break;
			case 12:
				num2 = 4096;
				break;
			case 13:
				num2 = 8192;
				break;
			case 14:
				num2 = 16384;
				break;
			case 15:
				num2 = 32768;
				break;
			default:
				num2 = 0;
				break;
			}
			this.Main.VC.TestDataRawOut.Command = 2;
			this.Main.VC.TestDataRawOut.DONr = (byte)num;
			if ((this.Main.VC.TestDataRawIn.DO & num2) > 0)
			{
				this.Main.VC.TestDataRawOut.DOState = 0;
			}
			else
			{
				this.Main.VC.TestDataRawOut.DOState = 1;
			}
			this.SendTestBlock();
			this.UpdateValues();
		}

		private void btSetAO_Click(object sender, EventArgs e)
		{
			this.Main.VC.TestDataRawOut.Command = 3;
			this.Main.VC.TestDataRawOut.Uo0 = this.nEAO0.Value;
			this.Main.VC.TestDataRawOut.Uo1 = this.nEAO1.Value;
			this.Main.VC.TestDataRawOut.Uo2 = this.nEAO2.Value;
			this.Main.VC.TestDataRawOut.Uo3 = this.nEAO3.Value;
			this.SendTestBlock();
		}

		private void btResetEnc0_Click(object sender, EventArgs e)
		{
			this.Main.VC.TestDataRawOut.Command = 4;
			this.Main.VC.TestDataRawOut.ResetEnc0 = 1;
			this.Main.VC.TestDataRawOut.ResetEnc1 = 0;
			this.Main.VC.TestDataRawOut.ResetEnc2 = 0;
			this.Main.VC.TestDataRawOut.ResetEncErr = 0;
			this.SendTestBlock();
		}

		private void btResetEnc1_Click(object sender, EventArgs e)
		{
			this.Main.VC.TestDataRawOut.Command = 4;
			this.Main.VC.TestDataRawOut.ResetEnc0 = 0;
			this.Main.VC.TestDataRawOut.ResetEnc1 = 1;
			this.Main.VC.TestDataRawOut.ResetEnc2 = 0;
			this.Main.VC.TestDataRawOut.ResetEncErr = 0;
			this.SendTestBlock();
		}

		private void btResetEnc2_Click(object sender, EventArgs e)
		{
			this.Main.VC.TestDataRawOut.Command = 4;
			this.Main.VC.TestDataRawOut.ResetEnc0 = 0;
			this.Main.VC.TestDataRawOut.ResetEnc1 = 0;
			this.Main.VC.TestDataRawOut.ResetEnc2 = 1;
			this.Main.VC.TestDataRawOut.ResetEncErr = 0;
			this.SendTestBlock();
		}

		private void btResetEncError_Click(object sender, EventArgs e)
		{
			this.Main.VC.TestDataRawOut.Command = 4;
			this.Main.VC.TestDataRawOut.ResetEnc0 = 0;
			this.Main.VC.TestDataRawOut.ResetEnc1 = 0;
			this.Main.VC.TestDataRawOut.ResetEnc2 = 0;
			this.Main.VC.TestDataRawOut.ResetEncErr = 1;
			this.SendTestBlock();
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
			this.BrowserShow();
		}

		private void btMotorSensor_Click(object sender, EventArgs e)
		{
			this.btBack_Click(null, EventArgs.Empty);
			this.Main.MenuTest1.ShowMotorSensor();
		}

		private void btPLCInterface_Click(object sender, EventArgs e)
		{
			this.btBack_Click(null, EventArgs.Empty);
			this.Main.MenuTest1.ShowPLCInterface();
		}

		private void SendTestBlock()
		{
			int num = 0;
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("SendIO"));
				if (!this.Main.VC.SendVarBlock(41))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not send TestDataRawOutBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.Main.StatusBarText(this.Main.Rm.GetString("WaitForAck"));
					while (this.Main.VC.TestDataRawOut.Command != 0)
					{
						if (num <= 5 && this.Main.VC.ReceiveVarBlock(41))
						{
							Thread.Sleep(50);
							num++;
							continue;
						}
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						break;
					}
				}
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
				this.Main.SettingsChangedReset();
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
				this.Main.SettingsChangedReset();
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		private void TestIOForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}
	}
}
