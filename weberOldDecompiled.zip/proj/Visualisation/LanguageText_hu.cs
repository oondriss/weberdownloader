using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Visualisation
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class LanguageText_hu
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(LanguageText_hu.resourceMan, null))
				{
					ResourceManager resourceManager = LanguageText_hu.resourceMan = new ResourceManager("Visualisation.LanguageText_hu", typeof(LanguageText_hu).Assembly);
				}
				return LanguageText_hu.resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return LanguageText_hu.resourceCulture;
			}
			set
			{
				LanguageText_hu.resourceCulture = value;
			}
		}

		internal static string Abr_Program => LanguageText_hu.ResourceManager.GetString("Abr_Program", LanguageText_hu.resourceCulture);

		internal static string AbrAnaDepth => LanguageText_hu.ResourceManager.GetString("AbrAnaDepth", LanguageText_hu.resourceCulture);

		internal static string AbrAnaSignal => LanguageText_hu.ResourceManager.GetString("AbrAnaSignal", LanguageText_hu.resourceCulture);

		internal static string AbrAngle => LanguageText_hu.ResourceManager.GetString("AbrAngle", LanguageText_hu.resourceCulture);

		internal static string AbrDelayTorque => LanguageText_hu.ResourceManager.GetString("AbrDelayTorque", LanguageText_hu.resourceCulture);

		internal static string AbrDepthGrad => LanguageText_hu.ResourceManager.GetString("AbrDepthGrad", LanguageText_hu.resourceCulture);

		internal static string AbrFilteredTorque => LanguageText_hu.ResourceManager.GetString("AbrFilteredTorque", LanguageText_hu.resourceCulture);

		internal static string AbrGradient => LanguageText_hu.ResourceManager.GetString("AbrGradient", LanguageText_hu.resourceCulture);

		internal static string AbrM360Follow => LanguageText_hu.ResourceManager.GetString("AbrM360Follow", LanguageText_hu.resourceCulture);

		internal static string AbrMaxTorque => LanguageText_hu.ResourceManager.GetString("AbrMaxTorque", LanguageText_hu.resourceCulture);

		internal static string AbrNumber => LanguageText_hu.ResourceManager.GetString("AbrNumber", LanguageText_hu.resourceCulture);

		internal static string AbrTime => LanguageText_hu.ResourceManager.GetString("AbrTime", LanguageText_hu.resourceCulture);

		internal static string AbrTorque => LanguageText_hu.ResourceManager.GetString("AbrTorque", LanguageText_hu.resourceCulture);

		internal static string AccessCheck => LanguageText_hu.ResourceManager.GetString("AccessCheck", LanguageText_hu.resourceCulture);

		internal static string AccessRequest => LanguageText_hu.ResourceManager.GetString("AccessRequest", LanguageText_hu.resourceCulture);

		internal static string Actualize => LanguageText_hu.ResourceManager.GetString("Actualize", LanguageText_hu.resourceCulture);

		internal static string AddEntry => LanguageText_hu.ResourceManager.GetString("AddEntry", LanguageText_hu.resourceCulture);

		internal static string AIError => LanguageText_hu.ResourceManager.GetString("AIError", LanguageText_hu.resourceCulture);

		internal static string All => LanguageText_hu.ResourceManager.GetString("All", LanguageText_hu.resourceCulture);

		internal static string AllFiles => LanguageText_hu.ResourceManager.GetString("AllFiles", LanguageText_hu.resourceCulture);

		internal static string AnaDepth => LanguageText_hu.ResourceManager.GetString("AnaDepth", LanguageText_hu.resourceCulture);

		internal static string Anagenbediener => LanguageText_hu.ResourceManager.GetString("Anagenbediener", LanguageText_hu.resourceCulture);

		internal static string Analysis => LanguageText_hu.ResourceManager.GetString("Analysis", LanguageText_hu.resourceCulture);

		internal static string AnaOutput => LanguageText_hu.ResourceManager.GetString("AnaOutput", LanguageText_hu.resourceCulture);

		internal static string AnaSignal => LanguageText_hu.ResourceManager.GetString("AnaSignal", LanguageText_hu.resourceCulture);

		internal static string AnaSigOffset => LanguageText_hu.ResourceManager.GetString("AnaSigOffset", LanguageText_hu.resourceCulture);

		internal static string AnaSigScale => LanguageText_hu.ResourceManager.GetString("AnaSigScale", LanguageText_hu.resourceCulture);

		internal static string Angle => LanguageText_hu.ResourceManager.GetString("Angle", LanguageText_hu.resourceCulture);

		internal static string AngleRedundantTolerance => LanguageText_hu.ResourceManager.GetString("AngleRedundantTolerance", LanguageText_hu.resourceCulture);

		internal static string AngleSensorInvers => LanguageText_hu.ResourceManager.GetString("AngleSensorInvers", LanguageText_hu.resourceCulture);

		internal static string AngleSensorScale => LanguageText_hu.ResourceManager.GetString("AngleSensorScale", LanguageText_hu.resourceCulture);

		internal static string AngleTorqueSensor => LanguageText_hu.ResourceManager.GetString("AngleTorqueSensor", LanguageText_hu.resourceCulture);

		internal static string Apply => LanguageText_hu.ResourceManager.GetString("Apply", LanguageText_hu.resourceCulture);

		internal static string ApplyEntry => LanguageText_hu.ResourceManager.GetString("ApplyEntry", LanguageText_hu.resourceCulture);

		internal static string AutoCurveAbort => LanguageText_hu.ResourceManager.GetString("AutoCurveAbort", LanguageText_hu.resourceCulture);

		internal static string Automatic => LanguageText_hu.ResourceManager.GetString("Automatic", LanguageText_hu.resourceCulture);

		internal static string AutoMode => LanguageText_hu.ResourceManager.GetString("AutoMode", LanguageText_hu.resourceCulture);

		internal static string AvailableValueNumber => LanguageText_hu.ResourceManager.GetString("AvailableValueNumber", LanguageText_hu.resourceCulture);

		internal static string Back => LanguageText_hu.ResourceManager.GetString("Back", LanguageText_hu.resourceCulture);

		internal static string Backup => LanguageText_hu.ResourceManager.GetString("Backup", LanguageText_hu.resourceCulture);

		internal static string Backup205000 => LanguageText_hu.ResourceManager.GetString("Backup205000", LanguageText_hu.resourceCulture);

		internal static string Backup205001 => LanguageText_hu.ResourceManager.GetString("Backup205001", LanguageText_hu.resourceCulture);

		internal static string Backup205002 => LanguageText_hu.ResourceManager.GetString("Backup205002", LanguageText_hu.resourceCulture);

		internal static string Backup205003 => LanguageText_hu.ResourceManager.GetString("Backup205003", LanguageText_hu.resourceCulture);

		internal static string Battery => LanguageText_hu.ResourceManager.GetString("Battery", LanguageText_hu.resourceCulture);

		internal static string Baudrate => LanguageText_hu.ResourceManager.GetString("Baudrate", LanguageText_hu.resourceCulture);

		internal static string bt0 => LanguageText_hu.ResourceManager.GetString("bt0", LanguageText_hu.resourceCulture);

		internal static string bt1 => LanguageText_hu.ResourceManager.GetString("bt1", LanguageText_hu.resourceCulture);

		internal static string bt2 => LanguageText_hu.ResourceManager.GetString("bt2", LanguageText_hu.resourceCulture);

		internal static string bt3 => LanguageText_hu.ResourceManager.GetString("bt3", LanguageText_hu.resourceCulture);

		internal static string bt4 => LanguageText_hu.ResourceManager.GetString("bt4", LanguageText_hu.resourceCulture);

		internal static string bt5 => LanguageText_hu.ResourceManager.GetString("bt5", LanguageText_hu.resourceCulture);

		internal static string bt6 => LanguageText_hu.ResourceManager.GetString("bt6", LanguageText_hu.resourceCulture);

		internal static string bt7 => LanguageText_hu.ResourceManager.GetString("bt7", LanguageText_hu.resourceCulture);

		internal static string bt8 => LanguageText_hu.ResourceManager.GetString("bt8", LanguageText_hu.resourceCulture);

		internal static string bt9 => LanguageText_hu.ResourceManager.GetString("bt9", LanguageText_hu.resourceCulture);

		internal static string btA => LanguageText_hu.ResourceManager.GetString("btA", LanguageText_hu.resourceCulture);

		internal static string btActivate => LanguageText_hu.ResourceManager.GetString("btActivate", LanguageText_hu.resourceCulture);

		internal static string btApply => LanguageText_hu.ResourceManager.GetString("btApply", LanguageText_hu.resourceCulture);

		internal static string btAutomaticHide => LanguageText_hu.ResourceManager.GetString("btAutomaticHide", LanguageText_hu.resourceCulture);

		internal static string btB => LanguageText_hu.ResourceManager.GetString("btB", LanguageText_hu.resourceCulture);

		internal static string btBackspace => LanguageText_hu.ResourceManager.GetString("btBackspace", LanguageText_hu.resourceCulture);

		internal static string btC => LanguageText_hu.ResourceManager.GetString("btC", LanguageText_hu.resourceCulture);

		internal static string btCancel => LanguageText_hu.ResourceManager.GetString("btCancel", LanguageText_hu.resourceCulture);

		internal static string btChangeDefaultDir => LanguageText_hu.ResourceManager.GetString("btChangeDefaultDir", LanguageText_hu.resourceCulture);

		internal static string btD => LanguageText_hu.ResourceManager.GetString("btD", LanguageText_hu.resourceCulture);

		internal static string btE => LanguageText_hu.ResourceManager.GetString("btE", LanguageText_hu.resourceCulture);

		internal static string btErase => LanguageText_hu.ResourceManager.GetString("btErase", LanguageText_hu.resourceCulture);

		internal static string btF => LanguageText_hu.ResourceManager.GetString("btF", LanguageText_hu.resourceCulture);

		internal static string btG => LanguageText_hu.ResourceManager.GetString("btG", LanguageText_hu.resourceCulture);

		internal static string btH => LanguageText_hu.ResourceManager.GetString("btH", LanguageText_hu.resourceCulture);

		internal static string btHide => LanguageText_hu.ResourceManager.GetString("btHide", LanguageText_hu.resourceCulture);

		internal static string btI => LanguageText_hu.ResourceManager.GetString("btI", LanguageText_hu.resourceCulture);

		internal static string btIdAscii => LanguageText_hu.ResourceManager.GetString("btIdAscii", LanguageText_hu.resourceCulture);

		internal static string btIdHex => LanguageText_hu.ResourceManager.GetString("btIdHex", LanguageText_hu.resourceCulture);

		internal static string btJ => LanguageText_hu.ResourceManager.GetString("btJ", LanguageText_hu.resourceCulture);

		internal static string btK => LanguageText_hu.ResourceManager.GetString("btK", LanguageText_hu.resourceCulture);

		internal static string btL => LanguageText_hu.ResourceManager.GetString("btL", LanguageText_hu.resourceCulture);

		internal static string btLoad => LanguageText_hu.ResourceManager.GetString("btLoad", LanguageText_hu.resourceCulture);

		internal static string btM => LanguageText_hu.ResourceManager.GetString("btM", LanguageText_hu.resourceCulture);

		internal static string btMinusDown => LanguageText_hu.ResourceManager.GetString("btMinusDown", LanguageText_hu.resourceCulture);

		internal static string btMinusUp => LanguageText_hu.ResourceManager.GetString("btMinusUp", LanguageText_hu.resourceCulture);

		internal static string btN => LanguageText_hu.ResourceManager.GetString("btN", LanguageText_hu.resourceCulture);

		internal static string btNOID => LanguageText_hu.ResourceManager.GetString("btNOID", LanguageText_hu.resourceCulture);

		internal static string btO => LanguageText_hu.ResourceManager.GetString("btO", LanguageText_hu.resourceCulture);

		internal static string btP => LanguageText_hu.ResourceManager.GetString("btP", LanguageText_hu.resourceCulture);

		internal static string btQ => LanguageText_hu.ResourceManager.GetString("btQ", LanguageText_hu.resourceCulture);

		internal static string btR => LanguageText_hu.ResourceManager.GetString("btR", LanguageText_hu.resourceCulture);

		internal static string btRes1 => LanguageText_hu.ResourceManager.GetString("btRes1", LanguageText_hu.resourceCulture);

		internal static string btRes2 => LanguageText_hu.ResourceManager.GetString("btRes2", LanguageText_hu.resourceCulture);

		internal static string btRes3 => LanguageText_hu.ResourceManager.GetString("btRes3", LanguageText_hu.resourceCulture);

		internal static string btS => LanguageText_hu.ResourceManager.GetString("btS", LanguageText_hu.resourceCulture);

		internal static string btShift => LanguageText_hu.ResourceManager.GetString("btShift", LanguageText_hu.resourceCulture);

		internal static string btSpace => LanguageText_hu.ResourceManager.GetString("btSpace", LanguageText_hu.resourceCulture);

		internal static string btT => LanguageText_hu.ResourceManager.GetString("btT", LanguageText_hu.resourceCulture);

		internal static string btTeach => LanguageText_hu.ResourceManager.GetString("btTeach", LanguageText_hu.resourceCulture);

		internal static string btU => LanguageText_hu.ResourceManager.GetString("btU", LanguageText_hu.resourceCulture);

		internal static string btV => LanguageText_hu.ResourceManager.GetString("btV", LanguageText_hu.resourceCulture);

		internal static string btW => LanguageText_hu.ResourceManager.GetString("btW", LanguageText_hu.resourceCulture);

		internal static string btX => LanguageText_hu.ResourceManager.GetString("btX", LanguageText_hu.resourceCulture);

		internal static string btY => LanguageText_hu.ResourceManager.GetString("btY", LanguageText_hu.resourceCulture);

		internal static string btZ => LanguageText_hu.ResourceManager.GetString("btZ", LanguageText_hu.resourceCulture);

		internal static string CalculateCurves => LanguageText_hu.ResourceManager.GetString("CalculateCurves", LanguageText_hu.resourceCulture);

		internal static string CalDisable => LanguageText_hu.ResourceManager.GetString("CalDisable", LanguageText_hu.resourceCulture);

		internal static string CalibrationSignal => LanguageText_hu.ResourceManager.GetString("CalibrationSignal", LanguageText_hu.resourceCulture);

		internal static string Cancel => LanguageText_hu.ResourceManager.GetString("Cancel", LanguageText_hu.resourceCulture);

		internal static string Changed => LanguageText_hu.ResourceManager.GetString("Changed", LanguageText_hu.resourceCulture);

		internal static string ChangeEntry => LanguageText_hu.ResourceManager.GetString("ChangeEntry", LanguageText_hu.resourceCulture);

		internal static string ChangePassCode => LanguageText_hu.ResourceManager.GetString("ChangePassCode", LanguageText_hu.resourceCulture);

		internal static string ChangesLog => LanguageText_hu.ResourceManager.GetString("ChangesLog", LanguageText_hu.resourceCulture);

		internal static string chBEmtyPrograms => LanguageText_hu.ResourceManager.GetString("chBEmtyPrograms", LanguageText_hu.resourceCulture);

		internal static string chBProgPreview => LanguageText_hu.ResourceManager.GetString("chBProgPreview", LanguageText_hu.resourceCulture);

		internal static string chbProgramSpecific => LanguageText_hu.ResourceManager.GetString("chbProgramSpecific", LanguageText_hu.resourceCulture);

		internal static string chBUseDefaultDir => LanguageText_hu.ResourceManager.GetString("chBUseDefaultDir", LanguageText_hu.resourceCulture);

		internal static string CheckFrictionTestStart => LanguageText_hu.ResourceManager.GetString("CheckFrictionTestStart", LanguageText_hu.resourceCulture);

		internal static string CheckHandStart => LanguageText_hu.ResourceManager.GetString("CheckHandStart", LanguageText_hu.resourceCulture);

		internal static string CheckParameter => LanguageText_hu.ResourceManager.GetString("CheckParameter", LanguageText_hu.resourceCulture);

		internal static string CheckRight => LanguageText_hu.ResourceManager.GetString("CheckRight", LanguageText_hu.resourceCulture);

		internal static string Close => LanguageText_hu.ResourceManager.GetString("Close", LanguageText_hu.resourceCulture);

		internal static string ControllerName => LanguageText_hu.ResourceManager.GetString("ControllerName", LanguageText_hu.resourceCulture);

		internal static string ControllerTime => LanguageText_hu.ResourceManager.GetString("ControllerTime", LanguageText_hu.resourceCulture);

		internal static string CopyProgram => LanguageText_hu.ResourceManager.GetString("CopyProgram", LanguageText_hu.resourceCulture);

		internal static string CountPassMax => LanguageText_hu.ResourceManager.GetString("CountPassMax", LanguageText_hu.resourceCulture);

		internal static string CreatedUsers => LanguageText_hu.ResourceManager.GetString("CreatedUsers", LanguageText_hu.resourceCulture);

		internal static string CumulStats => LanguageText_hu.ResourceManager.GetString("CumulStats", LanguageText_hu.resourceCulture);

		internal static string CursorsCannotSwitch => LanguageText_hu.ResourceManager.GetString("CursorsCannotSwitch", LanguageText_hu.resourceCulture);

		internal static string CurveDisplay => LanguageText_hu.ResourceManager.GetString("CurveDisplay", LanguageText_hu.resourceCulture);

		internal static string CurveLoad => LanguageText_hu.ResourceManager.GetString("CurveLoad", LanguageText_hu.resourceCulture);

		internal static string CurvePrint => LanguageText_hu.ResourceManager.GetString("CurvePrint", LanguageText_hu.resourceCulture);

		internal static string CurveResultKind => LanguageText_hu.ResourceManager.GetString("CurveResultKind", LanguageText_hu.resourceCulture);

		internal static string CurveResultNumber => LanguageText_hu.ResourceManager.GetString("CurveResultNumber", LanguageText_hu.resourceCulture);

		internal static string Curves => LanguageText_hu.ResourceManager.GetString("Curves", LanguageText_hu.resourceCulture);

		internal static string CurveSave => LanguageText_hu.ResourceManager.GetString("CurveSave", LanguageText_hu.resourceCulture);

		internal static string CurveSelection => LanguageText_hu.ResourceManager.GetString("CurveSelection", LanguageText_hu.resourceCulture);

		internal static string CurvesZoomedIn => LanguageText_hu.ResourceManager.GetString("CurvesZoomedIn", LanguageText_hu.resourceCulture);

		internal static string CurvesZoomedOut => LanguageText_hu.ResourceManager.GetString("CurvesZoomedOut", LanguageText_hu.resourceCulture);

		internal static string CustomCounter => LanguageText_hu.ResourceManager.GetString("CustomCounter", LanguageText_hu.resourceCulture);

		internal static string Cycle => LanguageText_hu.ResourceManager.GetString("Cycle", LanguageText_hu.resourceCulture);

		internal static string CycleCounter => LanguageText_hu.ResourceManager.GetString("CycleCounter", LanguageText_hu.resourceCulture);

		internal static string CycleNumber => LanguageText_hu.ResourceManager.GetString("CycleNumber", LanguageText_hu.resourceCulture);

		internal static string CycleSave => LanguageText_hu.ResourceManager.GetString("CycleSave", LanguageText_hu.resourceCulture);

		internal static string CylinderPressureScale => LanguageText_hu.ResourceManager.GetString("CylinderPressureScale", LanguageText_hu.resourceCulture);

		internal static string Czech => LanguageText_hu.ResourceManager.GetString("Czech", LanguageText_hu.resourceCulture);

		internal static string DateTime => LanguageText_hu.ResourceManager.GetString("DateTime", LanguageText_hu.resourceCulture);

		internal static string DeblockController => LanguageText_hu.ResourceManager.GetString("DeblockController", LanguageText_hu.resourceCulture);

		internal static string DeclForBackupSave => LanguageText_hu.ResourceManager.GetString("DeclForBackupSave", LanguageText_hu.resourceCulture);

		internal static string DeclForSpSave => LanguageText_hu.ResourceManager.GetString("DeclForSpSave", LanguageText_hu.resourceCulture);

		internal static string Degree => LanguageText_hu.ResourceManager.GetString("Degree", LanguageText_hu.resourceCulture);

		internal static string DelayTorque => LanguageText_hu.ResourceManager.GetString("DelayTorque", LanguageText_hu.resourceCulture);

		internal static string DeleteCounter => LanguageText_hu.ResourceManager.GetString("DeleteCounter", LanguageText_hu.resourceCulture);

		internal static string DeleteCustomCounter => LanguageText_hu.ResourceManager.GetString("DeleteCustomCounter", LanguageText_hu.resourceCulture);

		internal static string DeleteEntry => LanguageText_hu.ResourceManager.GetString("DeleteEntry", LanguageText_hu.resourceCulture);

		internal static string DeleteJob => LanguageText_hu.ResourceManager.GetString("DeleteJob", LanguageText_hu.resourceCulture);

		internal static string DeleteLastResults => LanguageText_hu.ResourceManager.GetString("DeleteLastResults", LanguageText_hu.resourceCulture);

		internal static string DeleteProgram => LanguageText_hu.ResourceManager.GetString("DeleteProgram", LanguageText_hu.resourceCulture);

		internal static string DeleteRecursiveStat => LanguageText_hu.ResourceManager.GetString("DeleteRecursiveStat", LanguageText_hu.resourceCulture);

		internal static string DeleteStep => LanguageText_hu.ResourceManager.GetString("DeleteStep", LanguageText_hu.resourceCulture);

		internal static string DeleteValues => LanguageText_hu.ResourceManager.GetString("DeleteValues", LanguageText_hu.resourceCulture);

		internal static string DepthFilterTime => LanguageText_hu.ResourceManager.GetString("DepthFilterTime", LanguageText_hu.resourceCulture);

		internal static string DepthGrad => LanguageText_hu.ResourceManager.GetString("DepthGrad", LanguageText_hu.resourceCulture);

		internal static string DepthGradLength => LanguageText_hu.ResourceManager.GetString("DepthGradLength", LanguageText_hu.resourceCulture);

		internal static string DepthSensor => LanguageText_hu.ResourceManager.GetString("DepthSensor", LanguageText_hu.resourceCulture);

		internal static string DepthSensorInvers => LanguageText_hu.ResourceManager.GetString("DepthSensorInvers", LanguageText_hu.resourceCulture);

		internal static string DGAddress => LanguageText_hu.ResourceManager.GetString("DGAddress", LanguageText_hu.resourceCulture);

		internal static string DHCP => LanguageText_hu.ResourceManager.GetString("DHCP", LanguageText_hu.resourceCulture);

		internal static string DigitalSignal => LanguageText_hu.ResourceManager.GetString("DigitalSignal", LanguageText_hu.resourceCulture);

		internal static string DigitOut => LanguageText_hu.ResourceManager.GetString("DigitOut", LanguageText_hu.resourceCulture);

		internal static string DigSigAtEnd => LanguageText_hu.ResourceManager.GetString("DigSigAtEnd", LanguageText_hu.resourceCulture);

		internal static string DigSigRunning => LanguageText_hu.ResourceManager.GetString("DigSigRunning", LanguageText_hu.resourceCulture);

		internal static string DiscardChanges => LanguageText_hu.ResourceManager.GetString("DiscardChanges", LanguageText_hu.resourceCulture);

		internal static string DisplaySpindlePressureAsKN => LanguageText_hu.ResourceManager.GetString("DisplaySpindlePressureAsKN", LanguageText_hu.resourceCulture);

		internal static string Done => LanguageText_hu.ResourceManager.GetString("Done", LanguageText_hu.resourceCulture);

		internal static string DriveUnit => LanguageText_hu.ResourceManager.GetString("DriveUnit", LanguageText_hu.resourceCulture);

		internal static string DriveUnitInvers => LanguageText_hu.ResourceManager.GetString("DriveUnitInvers", LanguageText_hu.resourceCulture);

		internal static string Driving => LanguageText_hu.ResourceManager.GetString("Driving", LanguageText_hu.resourceCulture);

		internal static string DrivingStep => LanguageText_hu.ResourceManager.GetString("DrivingStep", LanguageText_hu.resourceCulture);

		internal static string EditCancel => LanguageText_hu.ResourceManager.GetString("EditCancel", LanguageText_hu.resourceCulture);

		internal static string EditEntry => LanguageText_hu.ResourceManager.GetString("EditEntry", LanguageText_hu.resourceCulture);

		internal static string EditProgram => LanguageText_hu.ResourceManager.GetString("EditProgram", LanguageText_hu.resourceCulture);

		internal static string EditStep => LanguageText_hu.ResourceManager.GetString("EditStep", LanguageText_hu.resourceCulture);

		internal static string EMGMode => LanguageText_hu.ResourceManager.GetString("EMGMode", LanguageText_hu.resourceCulture);

		internal static string Empty => LanguageText_hu.ResourceManager.GetString("Empty", LanguageText_hu.resourceCulture);

		internal static string EmptyString => LanguageText_hu.ResourceManager.GetString("EmptyString", LanguageText_hu.resourceCulture);

		internal static string EncError => LanguageText_hu.ResourceManager.GetString("EncError", LanguageText_hu.resourceCulture);

		internal static string English => LanguageText_hu.ResourceManager.GetString("English", LanguageText_hu.resourceCulture);

		internal static string Error1000 => LanguageText_hu.ResourceManager.GetString("Error1000", LanguageText_hu.resourceCulture);

		internal static string Error1001 => LanguageText_hu.ResourceManager.GetString("Error1001", LanguageText_hu.resourceCulture);

		internal static string Error1002 => LanguageText_hu.ResourceManager.GetString("Error1002", LanguageText_hu.resourceCulture);

		internal static string Error1003 => LanguageText_hu.ResourceManager.GetString("Error1003", LanguageText_hu.resourceCulture);

		internal static string Error1004 => LanguageText_hu.ResourceManager.GetString("Error1004", LanguageText_hu.resourceCulture);

		internal static string Error1005 => LanguageText_hu.ResourceManager.GetString("Error1005", LanguageText_hu.resourceCulture);

		internal static string Error1006 => LanguageText_hu.ResourceManager.GetString("Error1006", LanguageText_hu.resourceCulture);

		internal static string Error1007 => LanguageText_hu.ResourceManager.GetString("Error1007", LanguageText_hu.resourceCulture);

		internal static string Error1008 => LanguageText_hu.ResourceManager.GetString("Error1008", LanguageText_hu.resourceCulture);

		internal static string Error1009 => LanguageText_hu.ResourceManager.GetString("Error1009", LanguageText_hu.resourceCulture);

		internal static string Error1010 => LanguageText_hu.ResourceManager.GetString("Error1010", LanguageText_hu.resourceCulture);

		internal static string Error1011 => LanguageText_hu.ResourceManager.GetString("Error1011", LanguageText_hu.resourceCulture);

		internal static string Error1012 => LanguageText_hu.ResourceManager.GetString("Error1012", LanguageText_hu.resourceCulture);

		internal static string Error1013 => LanguageText_hu.ResourceManager.GetString("Error1013", LanguageText_hu.resourceCulture);

		internal static string Error1014 => LanguageText_hu.ResourceManager.GetString("Error1014", LanguageText_hu.resourceCulture);

		internal static string Error1015 => LanguageText_hu.ResourceManager.GetString("Error1015", LanguageText_hu.resourceCulture);

		internal static string Error1016 => LanguageText_hu.ResourceManager.GetString("Error1016", LanguageText_hu.resourceCulture);

		internal static string Error1017 => LanguageText_hu.ResourceManager.GetString("Error1017", LanguageText_hu.resourceCulture);

		internal static string Error1018 => LanguageText_hu.ResourceManager.GetString("Error1018", LanguageText_hu.resourceCulture);

		internal static string Error1019 => LanguageText_hu.ResourceManager.GetString("Error1019", LanguageText_hu.resourceCulture);

		internal static string Error1020 => LanguageText_hu.ResourceManager.GetString("Error1020", LanguageText_hu.resourceCulture);

		internal static string Error1021 => LanguageText_hu.ResourceManager.GetString("Error1021", LanguageText_hu.resourceCulture);

		internal static string Error1022 => LanguageText_hu.ResourceManager.GetString("Error1022", LanguageText_hu.resourceCulture);

		internal static string Error1023 => LanguageText_hu.ResourceManager.GetString("Error1023", LanguageText_hu.resourceCulture);

		internal static string Error1024 => LanguageText_hu.ResourceManager.GetString("Error1024", LanguageText_hu.resourceCulture);

		internal static string Error1025 => LanguageText_hu.ResourceManager.GetString("Error1025", LanguageText_hu.resourceCulture);

		internal static string Error1026 => LanguageText_hu.ResourceManager.GetString("Error1026", LanguageText_hu.resourceCulture);

		internal static string Error1027 => LanguageText_hu.ResourceManager.GetString("Error1027", LanguageText_hu.resourceCulture);

		internal static string Error1028 => LanguageText_hu.ResourceManager.GetString("Error1028", LanguageText_hu.resourceCulture);

		internal static string Error1029 => LanguageText_hu.ResourceManager.GetString("Error1029", LanguageText_hu.resourceCulture);

		internal static string Error1030 => LanguageText_hu.ResourceManager.GetString("Error1030", LanguageText_hu.resourceCulture);

		internal static string Error1031 => LanguageText_hu.ResourceManager.GetString("Error1031", LanguageText_hu.resourceCulture);

		internal static string Error1032 => LanguageText_hu.ResourceManager.GetString("Error1032", LanguageText_hu.resourceCulture);

		internal static string Error1033 => LanguageText_hu.ResourceManager.GetString("Error1033", LanguageText_hu.resourceCulture);

		internal static string Error1034 => LanguageText_hu.ResourceManager.GetString("Error1034", LanguageText_hu.resourceCulture);

		internal static string Error1035 => LanguageText_hu.ResourceManager.GetString("Error1035", LanguageText_hu.resourceCulture);

		internal static string Error1036 => LanguageText_hu.ResourceManager.GetString("Error1036", LanguageText_hu.resourceCulture);

		internal static string Error1037 => LanguageText_hu.ResourceManager.GetString("Error1037", LanguageText_hu.resourceCulture);

		internal static string Error1038 => LanguageText_hu.ResourceManager.GetString("Error1038", LanguageText_hu.resourceCulture);

		internal static string Error1100 => LanguageText_hu.ResourceManager.GetString("Error1100", LanguageText_hu.resourceCulture);

		internal static string Error1101 => LanguageText_hu.ResourceManager.GetString("Error1101", LanguageText_hu.resourceCulture);

		internal static string Error1102 => LanguageText_hu.ResourceManager.GetString("Error1102", LanguageText_hu.resourceCulture);

		internal static string Error1110 => LanguageText_hu.ResourceManager.GetString("Error1110", LanguageText_hu.resourceCulture);

		internal static string Error1111 => LanguageText_hu.ResourceManager.GetString("Error1111", LanguageText_hu.resourceCulture);

		internal static string Error1112 => LanguageText_hu.ResourceManager.GetString("Error1112", LanguageText_hu.resourceCulture);

		internal static string Error1113 => LanguageText_hu.ResourceManager.GetString("Error1113", LanguageText_hu.resourceCulture);

		internal static string Error1114 => LanguageText_hu.ResourceManager.GetString("Error1114", LanguageText_hu.resourceCulture);

		internal static string Error1140 => LanguageText_hu.ResourceManager.GetString("Error1140", LanguageText_hu.resourceCulture);

		internal static string Error1141 => LanguageText_hu.ResourceManager.GetString("Error1141", LanguageText_hu.resourceCulture);

		internal static string Error1150 => LanguageText_hu.ResourceManager.GetString("Error1150", LanguageText_hu.resourceCulture);

		internal static string Error1151 => LanguageText_hu.ResourceManager.GetString("Error1151", LanguageText_hu.resourceCulture);

		internal static string Error1152 => LanguageText_hu.ResourceManager.GetString("Error1152", LanguageText_hu.resourceCulture);

		internal static string Error1153 => LanguageText_hu.ResourceManager.GetString("Error1153", LanguageText_hu.resourceCulture);

		internal static string Error1160 => LanguageText_hu.ResourceManager.GetString("Error1160", LanguageText_hu.resourceCulture);

		internal static string Error1161 => LanguageText_hu.ResourceManager.GetString("Error1161", LanguageText_hu.resourceCulture);

		internal static string Error1162 => LanguageText_hu.ResourceManager.GetString("Error1162", LanguageText_hu.resourceCulture);

		internal static string Error1163 => LanguageText_hu.ResourceManager.GetString("Error1163", LanguageText_hu.resourceCulture);

		internal static string Error1200 => LanguageText_hu.ResourceManager.GetString("Error1200", LanguageText_hu.resourceCulture);

		internal static string Error1201 => LanguageText_hu.ResourceManager.GetString("Error1201", LanguageText_hu.resourceCulture);

		internal static string Error1202 => LanguageText_hu.ResourceManager.GetString("Error1202", LanguageText_hu.resourceCulture);

		internal static string Error1203 => LanguageText_hu.ResourceManager.GetString("Error1203", LanguageText_hu.resourceCulture);

		internal static string Error1301 => LanguageText_hu.ResourceManager.GetString("Error1301", LanguageText_hu.resourceCulture);

		internal static string Error1302 => LanguageText_hu.ResourceManager.GetString("Error1302", LanguageText_hu.resourceCulture);

		internal static string Error1303 => LanguageText_hu.ResourceManager.GetString("Error1303", LanguageText_hu.resourceCulture);

		internal static string Error1304 => LanguageText_hu.ResourceManager.GetString("Error1304", LanguageText_hu.resourceCulture);

		internal static string Error1305 => LanguageText_hu.ResourceManager.GetString("Error1305", LanguageText_hu.resourceCulture);

		internal static string Error1400 => LanguageText_hu.ResourceManager.GetString("Error1400", LanguageText_hu.resourceCulture);

		internal static string Error1401 => LanguageText_hu.ResourceManager.GetString("Error1401", LanguageText_hu.resourceCulture);

		internal static string Error1402 => LanguageText_hu.ResourceManager.GetString("Error1402", LanguageText_hu.resourceCulture);

		internal static string Error1403 => LanguageText_hu.ResourceManager.GetString("Error1403", LanguageText_hu.resourceCulture);

		internal static string Error1404 => LanguageText_hu.ResourceManager.GetString("Error1404", LanguageText_hu.resourceCulture);

		internal static string Error1405 => LanguageText_hu.ResourceManager.GetString("Error1405", LanguageText_hu.resourceCulture);

		internal static string Error1406 => LanguageText_hu.ResourceManager.GetString("Error1406", LanguageText_hu.resourceCulture);

		internal static string Error1407 => LanguageText_hu.ResourceManager.GetString("Error1407", LanguageText_hu.resourceCulture);

		internal static string Error1450 => LanguageText_hu.ResourceManager.GetString("Error1450", LanguageText_hu.resourceCulture);

		internal static string Error1451 => LanguageText_hu.ResourceManager.GetString("Error1451", LanguageText_hu.resourceCulture);

		internal static string Error1600 => LanguageText_hu.ResourceManager.GetString("Error1600", LanguageText_hu.resourceCulture);

		internal static string Error1601 => LanguageText_hu.ResourceManager.GetString("Error1601", LanguageText_hu.resourceCulture);

		internal static string Error1602 => LanguageText_hu.ResourceManager.GetString("Error1602", LanguageText_hu.resourceCulture);

		internal static string Error2000 => LanguageText_hu.ResourceManager.GetString("Error2000", LanguageText_hu.resourceCulture);

		internal static string Error2001 => LanguageText_hu.ResourceManager.GetString("Error2001", LanguageText_hu.resourceCulture);

		internal static string Error2002 => LanguageText_hu.ResourceManager.GetString("Error2002", LanguageText_hu.resourceCulture);

		internal static string Error2003 => LanguageText_hu.ResourceManager.GetString("Error2003", LanguageText_hu.resourceCulture);

		internal static string Error2004 => LanguageText_hu.ResourceManager.GetString("Error2004", LanguageText_hu.resourceCulture);

		internal static string Error2005 => LanguageText_hu.ResourceManager.GetString("Error2005", LanguageText_hu.resourceCulture);

		internal static string Error2006 => LanguageText_hu.ResourceManager.GetString("Error2006", LanguageText_hu.resourceCulture);

		internal static string Error2007 => LanguageText_hu.ResourceManager.GetString("Error2007", LanguageText_hu.resourceCulture);

		internal static string Error2008 => LanguageText_hu.ResourceManager.GetString("Error2008", LanguageText_hu.resourceCulture);

		internal static string Error2009 => LanguageText_hu.ResourceManager.GetString("Error2009", LanguageText_hu.resourceCulture);

		internal static string Error2010 => LanguageText_hu.ResourceManager.GetString("Error2010", LanguageText_hu.resourceCulture);

		internal static string Error2011 => LanguageText_hu.ResourceManager.GetString("Error2011", LanguageText_hu.resourceCulture);

		internal static string Error2012 => LanguageText_hu.ResourceManager.GetString("Error2012", LanguageText_hu.resourceCulture);

		internal static string Error2013 => LanguageText_hu.ResourceManager.GetString("Error2013", LanguageText_hu.resourceCulture);

		internal static string Error2014 => LanguageText_hu.ResourceManager.GetString("Error2014", LanguageText_hu.resourceCulture);

		internal static string Error2015 => LanguageText_hu.ResourceManager.GetString("Error2015", LanguageText_hu.resourceCulture);

		internal static string Error2016 => LanguageText_hu.ResourceManager.GetString("Error2016", LanguageText_hu.resourceCulture);

		internal static string Error2017 => LanguageText_hu.ResourceManager.GetString("Error2017", LanguageText_hu.resourceCulture);

		internal static string Error2018 => LanguageText_hu.ResourceManager.GetString("Error2018", LanguageText_hu.resourceCulture);

		internal static string Error2019 => LanguageText_hu.ResourceManager.GetString("Error2019", LanguageText_hu.resourceCulture);

		internal static string Error2020 => LanguageText_hu.ResourceManager.GetString("Error2020", LanguageText_hu.resourceCulture);

		internal static string Error2021 => LanguageText_hu.ResourceManager.GetString("Error2021", LanguageText_hu.resourceCulture);

		internal static string Error2022 => LanguageText_hu.ResourceManager.GetString("Error2022", LanguageText_hu.resourceCulture);

		internal static string Error2100 => LanguageText_hu.ResourceManager.GetString("Error2100", LanguageText_hu.resourceCulture);

		internal static string Error5000 => LanguageText_hu.ResourceManager.GetString("Error5000", LanguageText_hu.resourceCulture);

		internal static string ErrorCode => LanguageText_hu.ResourceManager.GetString("ErrorCode", LanguageText_hu.resourceCulture);

		internal static string ErrorLog => LanguageText_hu.ResourceManager.GetString("ErrorLog", LanguageText_hu.resourceCulture);

		internal static string ErrorMode => LanguageText_hu.ResourceManager.GetString("ErrorMode", LanguageText_hu.resourceCulture);

		internal static string ErrorNumber => LanguageText_hu.ResourceManager.GetString("ErrorNumber", LanguageText_hu.resourceCulture);

		internal static string ErrorQuitEMG => LanguageText_hu.ResourceManager.GetString("ErrorQuitEMG", LanguageText_hu.resourceCulture);

		internal static string EuropeanTime => LanguageText_hu.ResourceManager.GetString("EuropeanTime", LanguageText_hu.resourceCulture);

		internal static string Even => LanguageText_hu.ResourceManager.GetString("Even", LanguageText_hu.resourceCulture);

		internal static string Exit => LanguageText_hu.ResourceManager.GetString("Exit", LanguageText_hu.resourceCulture);

		internal static string Expertenebene => LanguageText_hu.ResourceManager.GetString("Expertenebene", LanguageText_hu.resourceCulture);

		internal static string Export => LanguageText_hu.ResourceManager.GetString("Export", LanguageText_hu.resourceCulture);

		internal static string ExportLastResults => LanguageText_hu.ResourceManager.GetString("ExportLastResults", LanguageText_hu.resourceCulture);

		internal static string ExportLogbook => LanguageText_hu.ResourceManager.GetString("ExportLogbook", LanguageText_hu.resourceCulture);

		internal static string FileOperation => LanguageText_hu.ResourceManager.GetString("FileOperation", LanguageText_hu.resourceCulture);

		internal static string FileOperationMenu => LanguageText_hu.ResourceManager.GetString("FileOperationMenu", LanguageText_hu.resourceCulture);

		internal static string FilteredTorque => LanguageText_hu.ResourceManager.GetString("FilteredTorque", LanguageText_hu.resourceCulture);

		internal static string Finalizing => LanguageText_hu.ResourceManager.GetString("Finalizing", LanguageText_hu.resourceCulture);

		internal static string FinalizingStep => LanguageText_hu.ResourceManager.GetString("FinalizingStep", LanguageText_hu.resourceCulture);

		internal static string ForceSignals => LanguageText_hu.ResourceManager.GetString("ForceSignals", LanguageText_hu.resourceCulture);

		internal static string French => LanguageText_hu.ResourceManager.GetString("French", LanguageText_hu.resourceCulture);

		internal static string FrictionSpeed => LanguageText_hu.ResourceManager.GetString("FrictionSpeed", LanguageText_hu.resourceCulture);

		internal static string FrictionTest => LanguageText_hu.ResourceManager.GetString("FrictionTest", LanguageText_hu.resourceCulture);

		internal static string FrictionTestEMG => LanguageText_hu.ResourceManager.GetString("FrictionTestEMG", LanguageText_hu.resourceCulture);

		internal static string FrictionTestStartup => LanguageText_hu.ResourceManager.GetString("FrictionTestStartup", LanguageText_hu.resourceCulture);

		internal static string FrictionTorque => LanguageText_hu.ResourceManager.GetString("FrictionTorque", LanguageText_hu.resourceCulture);

		internal static string FromAbove => LanguageText_hu.ResourceManager.GetString("FromAbove", LanguageText_hu.resourceCulture);

		internal static string FromAboveOverload => LanguageText_hu.ResourceManager.GetString("FromAboveOverload", LanguageText_hu.resourceCulture);

		internal static string gBAnaSignal => LanguageText_hu.ResourceManager.GetString("gBAnaSignal", LanguageText_hu.resourceCulture);

		internal static string gBDateTime => LanguageText_hu.ResourceManager.GetString("gBDateTime", LanguageText_hu.resourceCulture);

		internal static string gBError => LanguageText_hu.ResourceManager.GetString("gBError", LanguageText_hu.resourceCulture);

		internal static string gBIdentity => LanguageText_hu.ResourceManager.GetString("gBIdentity", LanguageText_hu.resourceCulture);

		internal static string gBIP => LanguageText_hu.ResourceManager.GetString("gBIP", LanguageText_hu.resourceCulture);

		internal static string gBJawOpenAutomatic => LanguageText_hu.ResourceManager.GetString("gBJawOpenAutomatic", LanguageText_hu.resourceCulture);

		internal static string gBLoadBackup => LanguageText_hu.ResourceManager.GetString("gBLoadBackup", LanguageText_hu.resourceCulture);

		internal static string gBPressure => LanguageText_hu.ResourceManager.GetString("gBPressure", LanguageText_hu.resourceCulture);

		internal static string gBRedundantSensor => LanguageText_hu.ResourceManager.GetString("gBRedundantSensor", LanguageText_hu.resourceCulture);

		internal static string gBResultDisplay => LanguageText_hu.ResourceManager.GetString("gBResultDisplay", LanguageText_hu.resourceCulture);

		internal static string gBRs232 => LanguageText_hu.ResourceManager.GetString("gBRs232", LanguageText_hu.resourceCulture);

		internal static string gBSaveBackup => LanguageText_hu.ResourceManager.GetString("gBSaveBackup", LanguageText_hu.resourceCulture);

		internal static string gBSpindle => LanguageText_hu.ResourceManager.GetString("gBSpindle", LanguageText_hu.resourceCulture);

		internal static string GearFactor => LanguageText_hu.ResourceManager.GetString("GearFactor", LanguageText_hu.resourceCulture);

		internal static string German => LanguageText_hu.ResourceManager.GetString("German", LanguageText_hu.resourceCulture);

		internal static string GetCurve => LanguageText_hu.ResourceManager.GetString("GetCurve", LanguageText_hu.resourceCulture);

		internal static string GetRpm => LanguageText_hu.ResourceManager.GetString("GetRpm", LanguageText_hu.resourceCulture);

		internal static string GoWithoutPassCode => LanguageText_hu.ResourceManager.GetString("GoWithoutPassCode", LanguageText_hu.resourceCulture);

		internal static string GradFilter => LanguageText_hu.ResourceManager.GetString("GradFilter", LanguageText_hu.resourceCulture);

		internal static string Gradient => LanguageText_hu.ResourceManager.GetString("Gradient", LanguageText_hu.resourceCulture);

		internal static string GradientLength => LanguageText_hu.ResourceManager.GetString("GradientLength", LanguageText_hu.resourceCulture);

		internal static string HandMode => LanguageText_hu.ResourceManager.GetString("HandMode", LanguageText_hu.resourceCulture);

		internal static string HandStart => LanguageText_hu.ResourceManager.GetString("HandStart", LanguageText_hu.resourceCulture);

		internal static string HandStartIsInitiated => LanguageText_hu.ResourceManager.GetString("HandStartIsInitiated", LanguageText_hu.resourceCulture);

		internal static string Help => LanguageText_hu.ResourceManager.GetString("Help", LanguageText_hu.resourceCulture);

		internal static string HexSwitch => LanguageText_hu.ResourceManager.GetString("HexSwitch", LanguageText_hu.resourceCulture);

		internal static string Hold => LanguageText_hu.ResourceManager.GetString("Hold", LanguageText_hu.resourceCulture);

		internal static string Holder => LanguageText_hu.ResourceManager.GetString("Holder", LanguageText_hu.resourceCulture);

		internal static string HolderPressureScale => LanguageText_hu.ResourceManager.GetString("HolderPressureScale", LanguageText_hu.resourceCulture);

		internal static string Hungarian => LanguageText_hu.ResourceManager.GetString("Hungarian", LanguageText_hu.resourceCulture);

		internal static string IdentServer => LanguageText_hu.ResourceManager.GetString("IdentServer", LanguageText_hu.resourceCulture);

		internal static string Increment => LanguageText_hu.ResourceManager.GetString("Increment", LanguageText_hu.resourceCulture);

		internal static string Inputs => LanguageText_hu.ResourceManager.GetString("Inputs", LanguageText_hu.resourceCulture);

		internal static string InsertProgram => LanguageText_hu.ResourceManager.GetString("InsertProgram", LanguageText_hu.resourceCulture);

		internal static string InsertStep => LanguageText_hu.ResourceManager.GetString("InsertStep", LanguageText_hu.resourceCulture);

		internal static string Instandhaltung => LanguageText_hu.ResourceManager.GetString("Instandhaltung", LanguageText_hu.resourceCulture);

		internal static string IntegratedTests => LanguageText_hu.ResourceManager.GetString("IntegratedTests", LanguageText_hu.resourceCulture);

		internal static string IONumber => LanguageText_hu.ResourceManager.GetString("IONumber", LanguageText_hu.resourceCulture);

		internal static string IOTest => LanguageText_hu.ResourceManager.GetString("IOTest", LanguageText_hu.resourceCulture);

		internal static string IPAddress => LanguageText_hu.ResourceManager.GetString("IPAddress", LanguageText_hu.resourceCulture);

		internal static string IpOfC50S => LanguageText_hu.ResourceManager.GetString("IpOfC50S", LanguageText_hu.resourceCulture);

		internal static string Italian => LanguageText_hu.ResourceManager.GetString("Italian", LanguageText_hu.resourceCulture);

		internal static string JumpAlwaysTo => LanguageText_hu.ResourceManager.GetString("JumpAlwaysTo", LanguageText_hu.resourceCulture);

		internal static string JumpNokTo => LanguageText_hu.ResourceManager.GetString("JumpNokTo", LanguageText_hu.resourceCulture);

		internal static string JumpOkTo => LanguageText_hu.ResourceManager.GetString("JumpOkTo", LanguageText_hu.resourceCulture);

		internal static string JumpTo => LanguageText_hu.ResourceManager.GetString("JumpTo", LanguageText_hu.resourceCulture);

		internal static string KeyPad => LanguageText_hu.ResourceManager.GetString("KeyPad", LanguageText_hu.resourceCulture);

		internal static string KiloNewton => LanguageText_hu.ResourceManager.GetString("KiloNewton", LanguageText_hu.resourceCulture);

		internal static string Kind => LanguageText_hu.ResourceManager.GetString("Kind", LanguageText_hu.resourceCulture);

		internal static string Language => LanguageText_hu.ResourceManager.GetString("Language", LanguageText_hu.resourceCulture);

		internal static string LastDoneStep => LanguageText_hu.ResourceManager.GetString("LastDoneStep", LanguageText_hu.resourceCulture);

		internal static string LastNIO => LanguageText_hu.ResourceManager.GetString("LastNIO", LanguageText_hu.resourceCulture);

		internal static string LastResults => LanguageText_hu.ResourceManager.GetString("LastResults", LanguageText_hu.resourceCulture);

		internal static string lbJawOpenDepthGradMax => LanguageText_hu.ResourceManager.GetString("lbJawOpenDepthGradMax", LanguageText_hu.resourceCulture);

		internal static string lbJawOpenDepthGradMin => LanguageText_hu.ResourceManager.GetString("lbJawOpenDepthGradMin", LanguageText_hu.resourceCulture);

		internal static string lbJawOpenDistance => LanguageText_hu.ResourceManager.GetString("lbJawOpenDistance", LanguageText_hu.resourceCulture);

		internal static string LeftAngle => LanguageText_hu.ResourceManager.GetString("LeftAngle", LanguageText_hu.resourceCulture);

		internal static string LevelAdministrator => LanguageText_hu.ResourceManager.GetString("LevelAdministrator", LanguageText_hu.resourceCulture);

		internal static string LevelProgramer => LanguageText_hu.ResourceManager.GetString("LevelProgramer", LanguageText_hu.resourceCulture);

		internal static string LevelUser => LanguageText_hu.ResourceManager.GetString("LevelUser", LanguageText_hu.resourceCulture);

		internal static string LivingMonitor => LanguageText_hu.ResourceManager.GetString("LivingMonitor", LanguageText_hu.resourceCulture);

		internal static string LivingSign => LanguageText_hu.ResourceManager.GetString("LivingSign", LanguageText_hu.resourceCulture);

		internal static string LoadCurveData => LanguageText_hu.ResourceManager.GetString("LoadCurveData", LanguageText_hu.resourceCulture);

		internal static string LoadCurveDataFromFile => LanguageText_hu.ResourceManager.GetString("LoadCurveDataFromFile", LanguageText_hu.resourceCulture);

		internal static string LoadCustBackup => LanguageText_hu.ResourceManager.GetString("LoadCustBackup", LanguageText_hu.resourceCulture);

		internal static string LoadCustBackupFromCF => LanguageText_hu.ResourceManager.GetString("LoadCustBackupFromCF", LanguageText_hu.resourceCulture);

		internal static string LoadCustBackupSecQuery => LanguageText_hu.ResourceManager.GetString("LoadCustBackupSecQuery", LanguageText_hu.resourceCulture);

		internal static string LoadCycleCount => LanguageText_hu.ResourceManager.GetString("LoadCycleCount", LanguageText_hu.resourceCulture);

		internal static string LoadFromFile => LanguageText_hu.ResourceManager.GetString("LoadFromFile", LanguageText_hu.resourceCulture);

		internal static string LoadIO => LanguageText_hu.ResourceManager.GetString("LoadIO", LanguageText_hu.resourceCulture);

		internal static string LoadLastNIOResults => LanguageText_hu.ResourceManager.GetString("LoadLastNIOResults", LanguageText_hu.resourceCulture);

		internal static string LoadLastResults => LanguageText_hu.ResourceManager.GetString("LoadLastResults", LanguageText_hu.resourceCulture);

		internal static string LoadLogBookData => LanguageText_hu.ResourceManager.GetString("LoadLogBookData", LanguageText_hu.resourceCulture);

		internal static string LoadPLCIO => LanguageText_hu.ResourceManager.GetString("LoadPLCIO", LanguageText_hu.resourceCulture);

		internal static string LoadPProgFromFile => LanguageText_hu.ResourceManager.GetString("LoadPProgFromFile", LanguageText_hu.resourceCulture);

		internal static string LoadProcessInfo => LanguageText_hu.ResourceManager.GetString("LoadProcessInfo", LanguageText_hu.resourceCulture);

		internal static string LoadProgramData => LanguageText_hu.ResourceManager.GetString("LoadProgramData", LanguageText_hu.resourceCulture);

		internal static string LoadProgramDataLocally => LanguageText_hu.ResourceManager.GetString("LoadProgramDataLocally", LanguageText_hu.resourceCulture);

		internal static string LoadRecursiveStat => LanguageText_hu.ResourceManager.GetString("LoadRecursiveStat", LanguageText_hu.resourceCulture);

		internal static string LoadResults => LanguageText_hu.ResourceManager.GetString("LoadResults", LanguageText_hu.resourceCulture);

		internal static string LoadSingleProgFromFile => LanguageText_hu.ResourceManager.GetString("LoadSingleProgFromFile", LanguageText_hu.resourceCulture);

		internal static string LoadSpindleConst => LanguageText_hu.ResourceManager.GetString("LoadSpindleConst", LanguageText_hu.resourceCulture);

		internal static string LoadSpindleDataLocally => LanguageText_hu.ResourceManager.GetString("LoadSpindleDataLocally", LanguageText_hu.resourceCulture);

		internal static string LoadSystemConst => LanguageText_hu.ResourceManager.GetString("LoadSystemConst", LanguageText_hu.resourceCulture);

		internal static string LoadWebBackupSecQuery => LanguageText_hu.ResourceManager.GetString("LoadWebBackupSecQuery", LanguageText_hu.resourceCulture);

		internal static string LoadWeberBackup => LanguageText_hu.ResourceManager.GetString("LoadWeberBackup", LanguageText_hu.resourceCulture);

		internal static string LoadWeberBackupFromCF => LanguageText_hu.ResourceManager.GetString("LoadWeberBackupFromCF", LanguageText_hu.resourceCulture);

		internal static string LocalTime => LanguageText_hu.ResourceManager.GetString("LocalTime", LanguageText_hu.resourceCulture);

		internal static string LogBook => LanguageText_hu.ResourceManager.GetString("LogBook", LanguageText_hu.resourceCulture);

		internal static string LogBookMessage100000 => LanguageText_hu.ResourceManager.GetString("LogBookMessage100000", LanguageText_hu.resourceCulture);

		internal static string LogBookMessage200000 => LanguageText_hu.ResourceManager.GetString("LogBookMessage200000", LanguageText_hu.resourceCulture);

		internal static string LogBookMessage300000 => LanguageText_hu.ResourceManager.GetString("LogBookMessage300000", LanguageText_hu.resourceCulture);

		internal static string LogBookMessage300001 => LanguageText_hu.ResourceManager.GetString("LogBookMessage300001", LanguageText_hu.resourceCulture);

		internal static string LogBookTable => LanguageText_hu.ResourceManager.GetString("LogBookTable", LanguageText_hu.resourceCulture);

		internal static string Login => LanguageText_hu.ResourceManager.GetString("Login", LanguageText_hu.resourceCulture);

		internal static string LowerLimit => LanguageText_hu.ResourceManager.GetString("LowerLimit", LanguageText_hu.resourceCulture);

		internal static string M1FilterTime => LanguageText_hu.ResourceManager.GetString("M1FilterTime", LanguageText_hu.resourceCulture);

		internal static string M360Follow => LanguageText_hu.ResourceManager.GetString("M360Follow", LanguageText_hu.resourceCulture);

		internal static string MachineCounter => LanguageText_hu.ResourceManager.GetString("MachineCounter", LanguageText_hu.resourceCulture);

		internal static string MachineVisu => LanguageText_hu.ResourceManager.GetString("MachineVisu", LanguageText_hu.resourceCulture);

		internal static string MakeNewEntry => LanguageText_hu.ResourceManager.GetString("MakeNewEntry", LanguageText_hu.resourceCulture);

		internal static string Max => LanguageText_hu.ResourceManager.GetString("Max", LanguageText_hu.resourceCulture);

		internal static string MaxFrictionTorque => LanguageText_hu.ResourceManager.GetString("MaxFrictionTorque", LanguageText_hu.resourceCulture);

		internal static string MaxRpm => LanguageText_hu.ResourceManager.GetString("MaxRpm", LanguageText_hu.resourceCulture);

		internal static string MaxSaveCurveNum => LanguageText_hu.ResourceManager.GetString("MaxSaveCurveNum", LanguageText_hu.resourceCulture);

		internal static string MaxScrewTime => LanguageText_hu.ResourceManager.GetString("MaxScrewTime", LanguageText_hu.resourceCulture);

		internal static string MaxTorque => LanguageText_hu.ResourceManager.GetString("MaxTorque", LanguageText_hu.resourceCulture);

		internal static string MbAccessByAnother => LanguageText_hu.ResourceManager.GetString("MbAccessByAnother", LanguageText_hu.resourceCulture);

		internal static string MbAccessNotPossible => LanguageText_hu.ResourceManager.GetString("MbAccessNotPossible", LanguageText_hu.resourceCulture);

		internal static string MbAccessRequestTwice => LanguageText_hu.ResourceManager.GetString("MbAccessRequestTwice", LanguageText_hu.resourceCulture);

		internal static string MBackup => LanguageText_hu.ResourceManager.GetString("MBackup", LanguageText_hu.resourceCulture);

		internal static string MbAddNoFrictionTest => LanguageText_hu.ResourceManager.GetString("MbAddNoFrictionTest", LanguageText_hu.resourceCulture);

		internal static string MbAddNoManual => LanguageText_hu.ResourceManager.GetString("MbAddNoManual", LanguageText_hu.resourceCulture);

		internal static string MbAddNoTest => LanguageText_hu.ResourceManager.GetString("MbAddNoTest", LanguageText_hu.resourceCulture);

		internal static string MbAddParamViewOnly => LanguageText_hu.ResourceManager.GetString("MbAddParamViewOnly", LanguageText_hu.resourceCulture);

		internal static string MbAutomaticIsActive1 => LanguageText_hu.ResourceManager.GetString("MbAutomaticIsActive1", LanguageText_hu.resourceCulture);

		internal static string MbAutomaticIsActive2 => LanguageText_hu.ResourceManager.GetString("MbAutomaticIsActive2", LanguageText_hu.resourceCulture);

		internal static string mbChangingcBDisplaySpindlePressureAsKN => LanguageText_hu.ResourceManager.GetString("mbChangingcBDisplaySpindlePressureAsKN", LanguageText_hu.resourceCulture);

		internal static string MbComandTimeOut => LanguageText_hu.ResourceManager.GetString("MbComandTimeOut", LanguageText_hu.resourceCulture);

		internal static string MbCreateDefaultPasscode => LanguageText_hu.ResourceManager.GetString("MbCreateDefaultPasscode", LanguageText_hu.resourceCulture);

		internal static string MbCurveLoadFailure => LanguageText_hu.ResourceManager.GetString("MbCurveLoadFailure", LanguageText_hu.resourceCulture);

		internal static string MbCurveSaveFailure => LanguageText_hu.ResourceManager.GetString("MbCurveSaveFailure", LanguageText_hu.resourceCulture);

		internal static string MbDay_s => LanguageText_hu.ResourceManager.GetString("MbDay_s", LanguageText_hu.resourceCulture);

		internal static string MbDeleteCounterFailure => LanguageText_hu.ResourceManager.GetString("MbDeleteCounterFailure", LanguageText_hu.resourceCulture);

		internal static string MbDeleteCustomCounter => LanguageText_hu.ResourceManager.GetString("MbDeleteCustomCounter", LanguageText_hu.resourceCulture);

		internal static string MbDeleteLastResFailure => LanguageText_hu.ResourceManager.GetString("MbDeleteLastResFailure", LanguageText_hu.resourceCulture);

		internal static string MbDeleteLastResults => LanguageText_hu.ResourceManager.GetString("MbDeleteLastResults", LanguageText_hu.resourceCulture);

		internal static string MbDeleteProg => LanguageText_hu.ResourceManager.GetString("MbDeleteProg", LanguageText_hu.resourceCulture);

		internal static string MbDeleteRecStatFailure => LanguageText_hu.ResourceManager.GetString("MbDeleteRecStatFailure", LanguageText_hu.resourceCulture);

		internal static string MbDeleteRecursiveStat => LanguageText_hu.ResourceManager.GetString("MbDeleteRecursiveStat", LanguageText_hu.resourceCulture);

		internal static string MbDeleteStatAfterProgChange => LanguageText_hu.ResourceManager.GetString("MbDeleteStatAfterProgChange", LanguageText_hu.resourceCulture);

		internal static string MbDeleteStepIsJumpTarget => LanguageText_hu.ResourceManager.GetString("MbDeleteStepIsJumpTarget", LanguageText_hu.resourceCulture);

		internal static string MbDoubleEntryCodeFound => LanguageText_hu.ResourceManager.GetString("MbDoubleEntryCodeFound", LanguageText_hu.resourceCulture);

		internal static string MbEmptyProgram => LanguageText_hu.ResourceManager.GetString("MbEmptyProgram", LanguageText_hu.resourceCulture);

		internal static string mBError => LanguageText_hu.ResourceManager.GetString("mBError", LanguageText_hu.resourceCulture);

		internal static string MbErrorQuitFailure => LanguageText_hu.ResourceManager.GetString("MbErrorQuitFailure", LanguageText_hu.resourceCulture);

		internal static string MbExit => LanguageText_hu.ResourceManager.GetString("MbExit", LanguageText_hu.resourceCulture);

		internal static string mBExitSaveSettings => LanguageText_hu.ResourceManager.GetString("mBExitSaveSettings", LanguageText_hu.resourceCulture);

		internal static string mBExitSecurityQuery => LanguageText_hu.ResourceManager.GetString("mBExitSecurityQuery", LanguageText_hu.resourceCulture);

		internal static string MbGotNoConnection => LanguageText_hu.ResourceManager.GetString("MbGotNoConnection", LanguageText_hu.resourceCulture);

		internal static string MbHandstartIsActive => LanguageText_hu.ResourceManager.GetString("MbHandstartIsActive", LanguageText_hu.resourceCulture);

		internal static string MbHandstartNotTwice => LanguageText_hu.ResourceManager.GetString("MbHandstartNotTwice", LanguageText_hu.resourceCulture);

		internal static string MbhError => LanguageText_hu.ResourceManager.GetString("MbhError", LanguageText_hu.resourceCulture);

		internal static string MbhHint => LanguageText_hu.ResourceManager.GetString("MbhHint", LanguageText_hu.resourceCulture);

		internal static string MbhNoAccess => LanguageText_hu.ResourceManager.GetString("MbhNoAccess", LanguageText_hu.resourceCulture);

		internal static string MbHour_s => LanguageText_hu.ResourceManager.GetString("MbHour_s", LanguageText_hu.resourceCulture);

		internal static string MbhSecurityQuery => LanguageText_hu.ResourceManager.GetString("MbhSecurityQuery", LanguageText_hu.resourceCulture);

		internal static string MbhViewOnlyMode => LanguageText_hu.ResourceManager.GetString("MbhViewOnlyMode", LanguageText_hu.resourceCulture);

		internal static string mBInternalError => LanguageText_hu.ResourceManager.GetString("mBInternalError", LanguageText_hu.resourceCulture);

		internal static string MbInvalidUsbKey => LanguageText_hu.ResourceManager.GetString("MbInvalidUsbKey", LanguageText_hu.resourceCulture);

		internal static string MbIPChange => LanguageText_hu.ResourceManager.GetString("MbIPChange", LanguageText_hu.resourceCulture);

		internal static string MbKeyLockActive => LanguageText_hu.ResourceManager.GetString("MbKeyLockActive", LanguageText_hu.resourceCulture);

		internal static string MbLoadCustBackupFailure => LanguageText_hu.ResourceManager.GetString("MbLoadCustBackupFailure", LanguageText_hu.resourceCulture);

		internal static string MbLoadWeberBackupFailure => LanguageText_hu.ResourceManager.GetString("MbLoadWeberBackupFailure", LanguageText_hu.resourceCulture);

		internal static string MbLocationError => LanguageText_hu.ResourceManager.GetString("MbLocationError", LanguageText_hu.resourceCulture);

		internal static string MbLogbookWriteFailure => LanguageText_hu.ResourceManager.GetString("MbLogbookWriteFailure", LanguageText_hu.resourceCulture);

		internal static string MbMaxPasscodeNum1 => LanguageText_hu.ResourceManager.GetString("MbMaxPasscodeNum1", LanguageText_hu.resourceCulture);

		internal static string MbMaxPasscodeNum2 => LanguageText_hu.ResourceManager.GetString("MbMaxPasscodeNum2", LanguageText_hu.resourceCulture);

		internal static string MbNoAccess => LanguageText_hu.ResourceManager.GetString("MbNoAccess", LanguageText_hu.resourceCulture);

		internal static string MbNoAccessCauseAuto => LanguageText_hu.ResourceManager.GetString("MbNoAccessCauseAuto", LanguageText_hu.resourceCulture);

		internal static string MbNoConnection => LanguageText_hu.ResourceManager.GetString("MbNoConnection", LanguageText_hu.resourceCulture);

		internal static string MbNoTestCauseAuto => LanguageText_hu.ResourceManager.GetString("MbNoTestCauseAuto", LanguageText_hu.resourceCulture);

		internal static string mBNotReceiveCurve => LanguageText_hu.ResourceManager.GetString("mBNotReceiveCurve", LanguageText_hu.resourceCulture);

		internal static string MbOfflineMode => LanguageText_hu.ResourceManager.GetString("MbOfflineMode", LanguageText_hu.resourceCulture);

		internal static string MbOldPasswordWrong => LanguageText_hu.ResourceManager.GetString("MbOldPasswordWrong", LanguageText_hu.resourceCulture);

		internal static string MbOldPProgLoad => LanguageText_hu.ResourceManager.GetString("MbOldPProgLoad", LanguageText_hu.resourceCulture);

		internal static string MbOldProgLoad => LanguageText_hu.ResourceManager.GetString("MbOldProgLoad", LanguageText_hu.resourceCulture);

		internal static string MbOverwriteProg => LanguageText_hu.ResourceManager.GetString("MbOverwriteProg", LanguageText_hu.resourceCulture);

		internal static string MbPasscodeFailure1 => LanguageText_hu.ResourceManager.GetString("MbPasscodeFailure1", LanguageText_hu.resourceCulture);

		internal static string MbPasscodeFailure2 => LanguageText_hu.ResourceManager.GetString("MbPasscodeFailure2", LanguageText_hu.resourceCulture);

		internal static string MbPasscodeFailure3 => LanguageText_hu.ResourceManager.GetString("MbPasscodeFailure3", LanguageText_hu.resourceCulture);

		internal static string MbPasscodeFailure4 => LanguageText_hu.ResourceManager.GetString("MbPasscodeFailure4", LanguageText_hu.resourceCulture);

		internal static string MbPasswordIsExpired => LanguageText_hu.ResourceManager.GetString("MbPasswordIsExpired", LanguageText_hu.resourceCulture);

		internal static string MbPasswordSavedOnUsbKey => LanguageText_hu.ResourceManager.GetString("MbPasswordSavedOnUsbKey", LanguageText_hu.resourceCulture);

		internal static string MbPasswordsNotEqual => LanguageText_hu.ResourceManager.GetString("MbPasswordsNotEqual", LanguageText_hu.resourceCulture);

		internal static string MbPasswordWillExpire => LanguageText_hu.ResourceManager.GetString("MbPasswordWillExpire", LanguageText_hu.resourceCulture);

		internal static string MbPasswordWrongLength => LanguageText_hu.ResourceManager.GetString("MbPasswordWrongLength", LanguageText_hu.resourceCulture);

		internal static string MbPProgCopyFailure => LanguageText_hu.ResourceManager.GetString("MbPProgCopyFailure", LanguageText_hu.resourceCulture);

		internal static string MbPProgLoadFromFileFailure => LanguageText_hu.ResourceManager.GetString("MbPProgLoadFromFileFailure", LanguageText_hu.resourceCulture);

		internal static string MbPProgSaveToFileFailure => LanguageText_hu.ResourceManager.GetString("MbPProgSaveToFileFailure", LanguageText_hu.resourceCulture);

		internal static string MbProgramCopyFailure => LanguageText_hu.ResourceManager.GetString("MbProgramCopyFailure", LanguageText_hu.resourceCulture);

		internal static string MbProgramEmptySaveAnyway => LanguageText_hu.ResourceManager.GetString("MbProgramEmptySaveAnyway", LanguageText_hu.resourceCulture);

		internal static string MbReconnectUsbKey => LanguageText_hu.ResourceManager.GetString("MbReconnectUsbKey", LanguageText_hu.resourceCulture);

		internal static string MbSaveCustBackupFailure => LanguageText_hu.ResourceManager.GetString("MbSaveCustBackupFailure", LanguageText_hu.resourceCulture);

		internal static string MbSaveDataLocally => LanguageText_hu.ResourceManager.GetString("MbSaveDataLocally", LanguageText_hu.resourceCulture);

		internal static string MbSavedProgramDataToFile => LanguageText_hu.ResourceManager.GetString("MbSavedProgramDataToFile", LanguageText_hu.resourceCulture);

		internal static string MbSavedSpindleDataToFile => LanguageText_hu.ResourceManager.GetString("MbSavedSpindleDataToFile", LanguageText_hu.resourceCulture);

		internal static string MbSaveNotVerifiedData => LanguageText_hu.ResourceManager.GetString("MbSaveNotVerifiedData", LanguageText_hu.resourceCulture);

		internal static string MbSavePasscodeFailure => LanguageText_hu.ResourceManager.GetString("MbSavePasscodeFailure", LanguageText_hu.resourceCulture);

		internal static string MbSaveProgFailure => LanguageText_hu.ResourceManager.GetString("MbSaveProgFailure", LanguageText_hu.resourceCulture);

		internal static string MbSaveProgOnCPUFailure => LanguageText_hu.ResourceManager.GetString("MbSaveProgOnCPUFailure", LanguageText_hu.resourceCulture);

		internal static string MbSaveSpConstFailure => LanguageText_hu.ResourceManager.GetString("MbSaveSpConstFailure", LanguageText_hu.resourceCulture);

		internal static string MbSaveSysConstFailure => LanguageText_hu.ResourceManager.GetString("MbSaveSysConstFailure", LanguageText_hu.resourceCulture);

		internal static string MbSaveWeberBackupFailure => LanguageText_hu.ResourceManager.GetString("MbSaveWeberBackupFailure", LanguageText_hu.resourceCulture);

		internal static string MbShortNameFailure1 => LanguageText_hu.ResourceManager.GetString("MbShortNameFailure1", LanguageText_hu.resourceCulture);

		internal static string MbShortNameFailure2 => LanguageText_hu.ResourceManager.GetString("MbShortNameFailure2", LanguageText_hu.resourceCulture);

		internal static string MbShortNameFailure3 => LanguageText_hu.ResourceManager.GetString("MbShortNameFailure3", LanguageText_hu.resourceCulture);

		internal static string MbSpindleCopyFailure => LanguageText_hu.ResourceManager.GetString("MbSpindleCopyFailure", LanguageText_hu.resourceCulture);

		internal static string MbSpindleLoadFromFileFailure => LanguageText_hu.ResourceManager.GetString("MbSpindleLoadFromFileFailure", LanguageText_hu.resourceCulture);

		internal static string MbSpindleSaveToFileFailure => LanguageText_hu.ResourceManager.GetString("MbSpindleSaveToFileFailure", LanguageText_hu.resourceCulture);

		internal static string MbStepCopyFailure => LanguageText_hu.ResourceManager.GetString("MbStepCopyFailure", LanguageText_hu.resourceCulture);

		internal static string MbUsbKeyReadFailure => LanguageText_hu.ResourceManager.GetString("MbUsbKeyReadFailure", LanguageText_hu.resourceCulture);

		internal static string MbUsbKeySaveFailure => LanguageText_hu.ResourceManager.GetString("MbUsbKeySaveFailure", LanguageText_hu.resourceCulture);

		internal static string MbWrongPassword => LanguageText_hu.ResourceManager.GetString("MbWrongPassword", LanguageText_hu.resourceCulture);

		internal static string mBWrongUnitTorqueInGetcurve => LanguageText_hu.ResourceManager.GetString("mBWrongUnitTorqueInGetcurve", LanguageText_hu.resourceCulture);

		internal static string MCheckParameter => LanguageText_hu.ResourceManager.GetString("MCheckParameter", LanguageText_hu.resourceCulture);

		internal static string MCurveDisplay => LanguageText_hu.ResourceManager.GetString("MCurveDisplay", LanguageText_hu.resourceCulture);

		internal static string MCurveSelection => LanguageText_hu.ResourceManager.GetString("MCurveSelection", LanguageText_hu.resourceCulture);

		internal static string MCycleCounter => LanguageText_hu.ResourceManager.GetString("MCycleCounter", LanguageText_hu.resourceCulture);

		internal static string MDelay => LanguageText_hu.ResourceManager.GetString("MDelay", LanguageText_hu.resourceCulture);

		internal static string Mean => LanguageText_hu.ResourceManager.GetString("Mean", LanguageText_hu.resourceCulture);

		internal static string MEditStep => LanguageText_hu.ResourceManager.GetString("MEditStep", LanguageText_hu.resourceCulture);

		internal static string MenuAnalysis => LanguageText_hu.ResourceManager.GetString("MenuAnalysis", LanguageText_hu.resourceCulture);

		internal static string MenuParameter => LanguageText_hu.ResourceManager.GetString("MenuParameter", LanguageText_hu.resourceCulture);

		internal static string MenuStatistics => LanguageText_hu.ResourceManager.GetString("MenuStatistics", LanguageText_hu.resourceCulture);

		internal static string MenuTest => LanguageText_hu.ResourceManager.GetString("MenuTest", LanguageText_hu.resourceCulture);

		internal static string Message => LanguageText_hu.ResourceManager.GetString("Message", LanguageText_hu.resourceCulture);

		internal static string MHandStart => LanguageText_hu.ResourceManager.GetString("MHandStart", LanguageText_hu.resourceCulture);

		internal static string mIEnglish => LanguageText_hu.ResourceManager.GetString("mIEnglish", LanguageText_hu.resourceCulture);

		internal static string mIGerman => LanguageText_hu.ResourceManager.GetString("mIGerman", LanguageText_hu.resourceCulture);

		internal static string mIInfo => LanguageText_hu.ResourceManager.GetString("mIInfo", LanguageText_hu.resourceCulture);

		internal static string mILanguage => LanguageText_hu.ResourceManager.GetString("mILanguage", LanguageText_hu.resourceCulture);

		internal static string Milimeter => LanguageText_hu.ResourceManager.GetString("Milimeter", LanguageText_hu.resourceCulture);

		internal static string Milisecond => LanguageText_hu.ResourceManager.GetString("Milisecond", LanguageText_hu.resourceCulture);

		internal static string MillimeterPerSec => LanguageText_hu.ResourceManager.GetString("MillimeterPerSec", LanguageText_hu.resourceCulture);

		internal static string Min => LanguageText_hu.ResourceManager.GetString("Min", LanguageText_hu.resourceCulture);

		internal static string MiniDisplay => LanguageText_hu.ResourceManager.GetString("MiniDisplay", LanguageText_hu.resourceCulture);

		internal static string Minimize => LanguageText_hu.ResourceManager.GetString("Minimize", LanguageText_hu.resourceCulture);

		internal static string mISettings => LanguageText_hu.ResourceManager.GetString("mISettings", LanguageText_hu.resourceCulture);

		internal static string MLastNIO => LanguageText_hu.ResourceManager.GetString("MLastNIO", LanguageText_hu.resourceCulture);

		internal static string MLogBook => LanguageText_hu.ResourceManager.GetString("MLogBook", LanguageText_hu.resourceCulture);

		internal static string MOptPrgParam => LanguageText_hu.ResourceManager.GetString("MOptPrgParam", LanguageText_hu.resourceCulture);

		internal static string Motor => LanguageText_hu.ResourceManager.GetString("Motor", LanguageText_hu.resourceCulture);

		internal static string MPasscodeManager => LanguageText_hu.ResourceManager.GetString("MPasscodeManager", LanguageText_hu.resourceCulture);

		internal static string MPrintSelection => LanguageText_hu.ResourceManager.GetString("MPrintSelection", LanguageText_hu.resourceCulture);

		internal static string MProgramOverview => LanguageText_hu.ResourceManager.GetString("MProgramOverview", LanguageText_hu.resourceCulture);

		internal static string MSpindleConstants => LanguageText_hu.ResourceManager.GetString("MSpindleConstants", LanguageText_hu.resourceCulture);

		internal static string MStepOverview => LanguageText_hu.ResourceManager.GetString("MStepOverview", LanguageText_hu.resourceCulture);

		internal static string MStepResults => LanguageText_hu.ResourceManager.GetString("MStepResults", LanguageText_hu.resourceCulture);

		internal static string MSystemConstants => LanguageText_hu.ResourceManager.GetString("MSystemConstants", LanguageText_hu.resourceCulture);

		internal static string MVisualisationParam => LanguageText_hu.ResourceManager.GetString("MVisualisationParam", LanguageText_hu.resourceCulture);

		internal static string Name => LanguageText_hu.ResourceManager.GetString("Name", LanguageText_hu.resourceCulture);

		internal static string Negative => LanguageText_hu.ResourceManager.GetString("Negative", LanguageText_hu.resourceCulture);

		internal static string NegOverload => LanguageText_hu.ResourceManager.GetString("NegOverload", LanguageText_hu.resourceCulture);

		internal static string NewEntry => LanguageText_hu.ResourceManager.GetString("NewEntry", LanguageText_hu.resourceCulture);

		internal static string NewValue => LanguageText_hu.ResourceManager.GetString("NewValue", LanguageText_hu.resourceCulture);

		internal static string Next50Curves => LanguageText_hu.ResourceManager.GetString("Next50Curves", LanguageText_hu.resourceCulture);

		internal static string NIO10 => LanguageText_hu.ResourceManager.GetString("NIO10", LanguageText_hu.resourceCulture);

		internal static string NIO10001 => LanguageText_hu.ResourceManager.GetString("NIO10001", LanguageText_hu.resourceCulture);

		internal static string NIO10002 => LanguageText_hu.ResourceManager.GetString("NIO10002", LanguageText_hu.resourceCulture);

		internal static string NIO10003 => LanguageText_hu.ResourceManager.GetString("NIO10003", LanguageText_hu.resourceCulture);

		internal static string NIO10004 => LanguageText_hu.ResourceManager.GetString("NIO10004", LanguageText_hu.resourceCulture);

		internal static string NIO11 => LanguageText_hu.ResourceManager.GetString("NIO11", LanguageText_hu.resourceCulture);

		internal static string NIO110 => LanguageText_hu.ResourceManager.GetString("NIO110", LanguageText_hu.resourceCulture);

		internal static string NIO12 => LanguageText_hu.ResourceManager.GetString("NIO12", LanguageText_hu.resourceCulture);

		internal static string NIO13 => LanguageText_hu.ResourceManager.GetString("NIO13", LanguageText_hu.resourceCulture);

		internal static string NIO30 => LanguageText_hu.ResourceManager.GetString("NIO30", LanguageText_hu.resourceCulture);

		internal static string NIO31 => LanguageText_hu.ResourceManager.GetString("NIO31", LanguageText_hu.resourceCulture);

		internal static string NIO40 => LanguageText_hu.ResourceManager.GetString("NIO40", LanguageText_hu.resourceCulture);

		internal static string NIO41 => LanguageText_hu.ResourceManager.GetString("NIO41", LanguageText_hu.resourceCulture);

		internal static string NIO50 => LanguageText_hu.ResourceManager.GetString("NIO50", LanguageText_hu.resourceCulture);

		internal static string NIO51 => LanguageText_hu.ResourceManager.GetString("NIO51", LanguageText_hu.resourceCulture);

		internal static string NIO60 => LanguageText_hu.ResourceManager.GetString("NIO60", LanguageText_hu.resourceCulture);

		internal static string NIO61 => LanguageText_hu.ResourceManager.GetString("NIO61", LanguageText_hu.resourceCulture);

		internal static string NIO70 => LanguageText_hu.ResourceManager.GetString("NIO70", LanguageText_hu.resourceCulture);

		internal static string NIO71 => LanguageText_hu.ResourceManager.GetString("NIO71", LanguageText_hu.resourceCulture);

		internal static string NIO75 => LanguageText_hu.ResourceManager.GetString("NIO75", LanguageText_hu.resourceCulture);

		internal static string NIO76 => LanguageText_hu.ResourceManager.GetString("NIO76", LanguageText_hu.resourceCulture);

		internal static string NIO80 => LanguageText_hu.ResourceManager.GetString("NIO80", LanguageText_hu.resourceCulture);

		internal static string NIO81 => LanguageText_hu.ResourceManager.GetString("NIO81", LanguageText_hu.resourceCulture);

		internal static string NIO90 => LanguageText_hu.ResourceManager.GetString("NIO90", LanguageText_hu.resourceCulture);

		internal static string NIO91 => LanguageText_hu.ResourceManager.GetString("NIO91", LanguageText_hu.resourceCulture);

		internal static string NIO92 => LanguageText_hu.ResourceManager.GetString("NIO92", LanguageText_hu.resourceCulture);

		internal static string NIO93 => LanguageText_hu.ResourceManager.GetString("NIO93", LanguageText_hu.resourceCulture);

		internal static string NIO94 => LanguageText_hu.ResourceManager.GetString("NIO94", LanguageText_hu.resourceCulture);

		internal static string NIO95 => LanguageText_hu.ResourceManager.GetString("NIO95", LanguageText_hu.resourceCulture);

		internal static string NIO96 => LanguageText_hu.ResourceManager.GetString("NIO96", LanguageText_hu.resourceCulture);

		internal static string NIO97 => LanguageText_hu.ResourceManager.GetString("NIO97", LanguageText_hu.resourceCulture);

		internal static string NIO98 => LanguageText_hu.ResourceManager.GetString("NIO98", LanguageText_hu.resourceCulture);

		internal static string NIO99 => LanguageText_hu.ResourceManager.GetString("NIO99", LanguageText_hu.resourceCulture);

		internal static string NIONumber => LanguageText_hu.ResourceManager.GetString("NIONumber", LanguageText_hu.resourceCulture);

		internal static string NIOReason => LanguageText_hu.ResourceManager.GetString("NIOReason", LanguageText_hu.resourceCulture);

		internal static string No => LanguageText_hu.ResourceManager.GetString("No", LanguageText_hu.resourceCulture);

		internal static string NoData => LanguageText_hu.ResourceManager.GetString("NoData", LanguageText_hu.resourceCulture);

		internal static string NoErrorMode => LanguageText_hu.ResourceManager.GetString("NoErrorMode", LanguageText_hu.resourceCulture);

		internal static string NOK => LanguageText_hu.ResourceManager.GetString("NOK", LanguageText_hu.resourceCulture);

		internal static string None => LanguageText_hu.ResourceManager.GetString("None", LanguageText_hu.resourceCulture);

		internal static string NoParity => LanguageText_hu.ResourceManager.GetString("NoParity", LanguageText_hu.resourceCulture);

		internal static string NoSelection => LanguageText_hu.ResourceManager.GetString("NoSelection", LanguageText_hu.resourceCulture);

		internal static string NoSignal => LanguageText_hu.ResourceManager.GetString("NoSignal", LanguageText_hu.resourceCulture);

		internal static string NotValid => LanguageText_hu.ResourceManager.GetString("NotValid", LanguageText_hu.resourceCulture);

		internal static string Number => LanguageText_hu.ResourceManager.GetString("Number", LanguageText_hu.resourceCulture);

		internal static string NumberPad => LanguageText_hu.ResourceManager.GetString("NumberPad", LanguageText_hu.resourceCulture);

		internal static string Odd => LanguageText_hu.ResourceManager.GetString("Odd", LanguageText_hu.resourceCulture);

		internal static string Off => LanguageText_hu.ResourceManager.GetString("Off", LanguageText_hu.resourceCulture);

		internal static string OfflineMode => LanguageText_hu.ResourceManager.GetString("OfflineMode", LanguageText_hu.resourceCulture);

		internal static string OffsetTeachValue => LanguageText_hu.ResourceManager.GetString("OffsetTeachValue", LanguageText_hu.resourceCulture);

		internal static string OffsetVoltageMax => LanguageText_hu.ResourceManager.GetString("OffsetVoltageMax", LanguageText_hu.resourceCulture);

		internal static string OffsetVoltageMin => LanguageText_hu.ResourceManager.GetString("OffsetVoltageMin", LanguageText_hu.resourceCulture);

		internal static string OfStep => LanguageText_hu.ResourceManager.GetString("OfStep", LanguageText_hu.resourceCulture);

		internal static string OK => LanguageText_hu.ResourceManager.GetString("OK", LanguageText_hu.resourceCulture);

		internal static string OKNOK => LanguageText_hu.ResourceManager.GetString("OKNOK", LanguageText_hu.resourceCulture);

		internal static string OldPassCode => LanguageText_hu.ResourceManager.GetString("OldPassCode", LanguageText_hu.resourceCulture);

		internal static string OldValue => LanguageText_hu.ResourceManager.GetString("OldValue", LanguageText_hu.resourceCulture);

		internal static string On => LanguageText_hu.ResourceManager.GetString("On", LanguageText_hu.resourceCulture);

		internal static string OnlineMode => LanguageText_hu.ResourceManager.GetString("OnlineMode", LanguageText_hu.resourceCulture);

		internal static string OnlyIO => LanguageText_hu.ResourceManager.GetString("OnlyIO", LanguageText_hu.resourceCulture);

		internal static string OptPrgParam => LanguageText_hu.ResourceManager.GetString("OptPrgParam", LanguageText_hu.resourceCulture);

		internal static string Organisation => LanguageText_hu.ResourceManager.GetString("Organisation", LanguageText_hu.resourceCulture);

		internal static string OrganizingStep => LanguageText_hu.ResourceManager.GetString("OrganizingStep", LanguageText_hu.resourceCulture);

		internal static string OutOfRange => LanguageText_hu.ResourceManager.GetString("OutOfRange", LanguageText_hu.resourceCulture);

		internal static string Outputs => LanguageText_hu.ResourceManager.GetString("Outputs", LanguageText_hu.resourceCulture);

		internal static string PaintCurve => LanguageText_hu.ResourceManager.GetString("PaintCurve", LanguageText_hu.resourceCulture);

		internal static string Parameter => LanguageText_hu.ResourceManager.GetString("Parameter", LanguageText_hu.resourceCulture);

		internal static string Parity => LanguageText_hu.ResourceManager.GetString("Parity", LanguageText_hu.resourceCulture);

		internal static string PasscodeLevel => LanguageText_hu.ResourceManager.GetString("PasscodeLevel", LanguageText_hu.resourceCulture);

		internal static string PasscodeManager => LanguageText_hu.ResourceManager.GetString("PasscodeManager", LanguageText_hu.resourceCulture);

		internal static string Password => LanguageText_hu.ResourceManager.GetString("Password", LanguageText_hu.resourceCulture);

		internal static string PasswordInput => LanguageText_hu.ResourceManager.GetString("PasswordInput", LanguageText_hu.resourceCulture);

		internal static string Percent => LanguageText_hu.ResourceManager.GetString("Percent", LanguageText_hu.resourceCulture);

		internal static string PLC_IO => LanguageText_hu.ResourceManager.GetString("PLC_IO", LanguageText_hu.resourceCulture);

		internal static string PointOfTime => LanguageText_hu.ResourceManager.GetString("PointOfTime", LanguageText_hu.resourceCulture);

		internal static string Positive => LanguageText_hu.ResourceManager.GetString("Positive", LanguageText_hu.resourceCulture);

		internal static string PosOverload => LanguageText_hu.ResourceManager.GetString("PosOverload", LanguageText_hu.resourceCulture);

		internal static string PowerEnabled => LanguageText_hu.ResourceManager.GetString("PowerEnabled", LanguageText_hu.resourceCulture);

		internal static string Pressure => LanguageText_hu.ResourceManager.GetString("Pressure", LanguageText_hu.resourceCulture);

		internal static string PressureCylinder => LanguageText_hu.ResourceManager.GetString("PressureCylinder", LanguageText_hu.resourceCulture);

		internal static string PressureSpindle => LanguageText_hu.ResourceManager.GetString("PressureSpindle", LanguageText_hu.resourceCulture);

		internal static string Print => LanguageText_hu.ResourceManager.GetString("Print", LanguageText_hu.resourceCulture);

		internal static string ProcessInputs => LanguageText_hu.ResourceManager.GetString("ProcessInputs", LanguageText_hu.resourceCulture);

		internal static string ProcessRunning => LanguageText_hu.ResourceManager.GetString("ProcessRunning", LanguageText_hu.resourceCulture);

		internal static string Program => LanguageText_hu.ResourceManager.GetString("Program", LanguageText_hu.resourceCulture);

		internal static string ProgramChange201000 => LanguageText_hu.ResourceManager.GetString("ProgramChange201000", LanguageText_hu.resourceCulture);

		internal static string ProgramChange201001 => LanguageText_hu.ResourceManager.GetString("ProgramChange201001", LanguageText_hu.resourceCulture);

		internal static string ProgramChange201002 => LanguageText_hu.ResourceManager.GetString("ProgramChange201002", LanguageText_hu.resourceCulture);

		internal static string ProgramChange201003 => LanguageText_hu.ResourceManager.GetString("ProgramChange201003", LanguageText_hu.resourceCulture);

		internal static string ProgramChange201004 => LanguageText_hu.ResourceManager.GetString("ProgramChange201004", LanguageText_hu.resourceCulture);

		internal static string ProgramChange201005 => LanguageText_hu.ResourceManager.GetString("ProgramChange201005", LanguageText_hu.resourceCulture);

		internal static string ProgramChange201006 => LanguageText_hu.ResourceManager.GetString("ProgramChange201006", LanguageText_hu.resourceCulture);

		internal static string ProgramChange201007 => LanguageText_hu.ResourceManager.GetString("ProgramChange201007", LanguageText_hu.resourceCulture);

		internal static string ProgramChange201008 => LanguageText_hu.ResourceManager.GetString("ProgramChange201008", LanguageText_hu.resourceCulture);

		internal static string ProgramChange201009 => LanguageText_hu.ResourceManager.GetString("ProgramChange201009", LanguageText_hu.resourceCulture);

		internal static string ProgramChange207000 => LanguageText_hu.ResourceManager.GetString("ProgramChange207000", LanguageText_hu.resourceCulture);

		internal static string ProgramChange207001 => LanguageText_hu.ResourceManager.GetString("ProgramChange207001", LanguageText_hu.resourceCulture);

		internal static string ProgramChange207003 => LanguageText_hu.ResourceManager.GetString("ProgramChange207003", LanguageText_hu.resourceCulture);

		internal static string ProgramNumber => LanguageText_hu.ResourceManager.GetString("ProgramNumber", LanguageText_hu.resourceCulture);

		internal static string Programs => LanguageText_hu.ResourceManager.GetString("Programs", LanguageText_hu.resourceCulture);

		internal static string Quit => LanguageText_hu.ResourceManager.GetString("Quit", LanguageText_hu.resourceCulture);

		internal static string Ramp => LanguageText_hu.ResourceManager.GetString("Ramp", LanguageText_hu.resourceCulture);

		internal static string Range => LanguageText_hu.ResourceManager.GetString("Range", LanguageText_hu.resourceCulture);

		internal static string ReadyToStart => LanguageText_hu.ResourceManager.GetString("ReadyToStart", LanguageText_hu.resourceCulture);

		internal static string RecentDateTime => LanguageText_hu.ResourceManager.GetString("RecentDateTime", LanguageText_hu.resourceCulture);

		internal static string Reconnect => LanguageText_hu.ResourceManager.GetString("Reconnect", LanguageText_hu.resourceCulture);

		internal static string ReconnectToController => LanguageText_hu.ResourceManager.GetString("ReconnectToController", LanguageText_hu.resourceCulture);

		internal static string RecursiveStatMode => LanguageText_hu.ResourceManager.GetString("RecursiveStatMode", LanguageText_hu.resourceCulture);

		internal static string RedAngle => LanguageText_hu.ResourceManager.GetString("RedAngle", LanguageText_hu.resourceCulture);

		internal static string RedTorque => LanguageText_hu.ResourceManager.GetString("RedTorque", LanguageText_hu.resourceCulture);

		internal static string RedundantSensorActive => LanguageText_hu.ResourceManager.GetString("RedundantSensorActive", LanguageText_hu.resourceCulture);

		internal static string relatedTo => LanguageText_hu.ResourceManager.GetString("relatedTo", LanguageText_hu.resourceCulture);

		internal static string RelativeTorque => LanguageText_hu.ResourceManager.GetString("RelativeTorque", LanguageText_hu.resourceCulture);

		internal static string Release => LanguageText_hu.ResourceManager.GetString("Release", LanguageText_hu.resourceCulture);

		internal static string ReleaseSpeed => LanguageText_hu.ResourceManager.GetString("ReleaseSpeed", LanguageText_hu.resourceCulture);

		internal static string RelTorqueStep => LanguageText_hu.ResourceManager.GetString("RelTorqueStep", LanguageText_hu.resourceCulture);

		internal static string RemainedCurves => LanguageText_hu.ResourceManager.GetString("RemainedCurves", LanguageText_hu.resourceCulture);

		internal static string RepeatPassCode => LanguageText_hu.ResourceManager.GetString("RepeatPassCode", LanguageText_hu.resourceCulture);

		internal static string Reset => LanguageText_hu.ResourceManager.GetString("Reset", LanguageText_hu.resourceCulture);

		internal static string ResetADepth => LanguageText_hu.ResourceManager.GetString("ResetADepth", LanguageText_hu.resourceCulture);

		internal static string ResetAngle => LanguageText_hu.ResourceManager.GetString("ResetAngle", LanguageText_hu.resourceCulture);

		internal static string Result => LanguageText_hu.ResourceManager.GetString("Result", LanguageText_hu.resourceCulture);

		internal static string ResultDisplay => LanguageText_hu.ResourceManager.GetString("ResultDisplay", LanguageText_hu.resourceCulture);

		internal static string Results => LanguageText_hu.ResourceManager.GetString("Results", LanguageText_hu.resourceCulture);

		internal static string RightAngle => LanguageText_hu.ResourceManager.GetString("RightAngle", LanguageText_hu.resourceCulture);

		internal static string Robot => LanguageText_hu.ResourceManager.GetString("Robot", LanguageText_hu.resourceCulture);

		internal static string RoundsPerMinute => LanguageText_hu.ResourceManager.GetString("RoundsPerMinute", LanguageText_hu.resourceCulture);

		internal static string RpmTest => LanguageText_hu.ResourceManager.GetString("RpmTest", LanguageText_hu.resourceCulture);

		internal static string RpmUnit => LanguageText_hu.ResourceManager.GetString("RpmUnit", LanguageText_hu.resourceCulture);

		internal static string RS232PrintMode => LanguageText_hu.ResourceManager.GetString("RS232PrintMode", LanguageText_hu.resourceCulture);

		internal static string SampleSize => LanguageText_hu.ResourceManager.GetString("SampleSize", LanguageText_hu.resourceCulture);

		internal static string SampleStatistic => LanguageText_hu.ResourceManager.GetString("SampleStatistic", LanguageText_hu.resourceCulture);

		internal static string SaveCurveDataToFile => LanguageText_hu.ResourceManager.GetString("SaveCurveDataToFile", LanguageText_hu.resourceCulture);

		internal static string SaveCustBackup => LanguageText_hu.ResourceManager.GetString("SaveCustBackup", LanguageText_hu.resourceCulture);

		internal static string SaveCustBackupOnCF => LanguageText_hu.ResourceManager.GetString("SaveCustBackupOnCF", LanguageText_hu.resourceCulture);

		internal static string SaveCustBackupSecQuery => LanguageText_hu.ResourceManager.GetString("SaveCustBackupSecQuery", LanguageText_hu.resourceCulture);

		internal static string SavePasscodesOnCPU => LanguageText_hu.ResourceManager.GetString("SavePasscodesOnCPU", LanguageText_hu.resourceCulture);

		internal static string SavePProgToFile => LanguageText_hu.ResourceManager.GetString("SavePProgToFile", LanguageText_hu.resourceCulture);

		internal static string SaveProgOnCPU => LanguageText_hu.ResourceManager.GetString("SaveProgOnCPU", LanguageText_hu.resourceCulture);

		internal static string SaveProgramData => LanguageText_hu.ResourceManager.GetString("SaveProgramData", LanguageText_hu.resourceCulture);

		internal static string SaveProgramDataLocally => LanguageText_hu.ResourceManager.GetString("SaveProgramDataLocally", LanguageText_hu.resourceCulture);

		internal static string SaveSingleProgToFile => LanguageText_hu.ResourceManager.GetString("SaveSingleProgToFile", LanguageText_hu.resourceCulture);

		internal static string SaveSpindleConstOnCPU => LanguageText_hu.ResourceManager.GetString("SaveSpindleConstOnCPU", LanguageText_hu.resourceCulture);

		internal static string SaveSpindleDataLocally => LanguageText_hu.ResourceManager.GetString("SaveSpindleDataLocally", LanguageText_hu.resourceCulture);

		internal static string SaveSystemConstOnCPU => LanguageText_hu.ResourceManager.GetString("SaveSystemConstOnCPU", LanguageText_hu.resourceCulture);

		internal static string SaveToFile => LanguageText_hu.ResourceManager.GetString("SaveToFile", LanguageText_hu.resourceCulture);

		internal static string SaveVisuParam => LanguageText_hu.ResourceManager.GetString("SaveVisuParam", LanguageText_hu.resourceCulture);

		internal static string SaveWebBackupSecQuery => LanguageText_hu.ResourceManager.GetString("SaveWebBackupSecQuery", LanguageText_hu.resourceCulture);

		internal static string SaveWeberBackup => LanguageText_hu.ResourceManager.GetString("SaveWeberBackup", LanguageText_hu.resourceCulture);

		internal static string SaveWeberBackupOnCF => LanguageText_hu.ResourceManager.GetString("SaveWeberBackupOnCF", LanguageText_hu.resourceCulture);

		internal static string ScrewID => LanguageText_hu.ResourceManager.GetString("ScrewID", LanguageText_hu.resourceCulture);

		internal static string ScrewProgramFiles => LanguageText_hu.ResourceManager.GetString("ScrewProgramFiles", LanguageText_hu.resourceCulture);

		internal static string ScrewPrograms => LanguageText_hu.ResourceManager.GetString("ScrewPrograms", LanguageText_hu.resourceCulture);

		internal static string ScrewTime => LanguageText_hu.ResourceManager.GetString("ScrewTime", LanguageText_hu.resourceCulture);

		internal static string Second => LanguageText_hu.ResourceManager.GetString("Second", LanguageText_hu.resourceCulture);

		internal static string SelectAll => LanguageText_hu.ResourceManager.GetString("SelectAll", LanguageText_hu.resourceCulture);

		internal static string SelectedKind => LanguageText_hu.ResourceManager.GetString("SelectedKind", LanguageText_hu.resourceCulture);

		internal static string SelectedXAxis => LanguageText_hu.ResourceManager.GetString("SelectedXAxis", LanguageText_hu.resourceCulture);

		internal static string SelectedYAxis => LanguageText_hu.ResourceManager.GetString("SelectedYAxis", LanguageText_hu.resourceCulture);

		internal static string SelectNone => LanguageText_hu.ResourceManager.GetString("SelectNone", LanguageText_hu.resourceCulture);

		internal static string SelValidNumber => LanguageText_hu.ResourceManager.GetString("SelValidNumber", LanguageText_hu.resourceCulture);

		internal static string SendIO => LanguageText_hu.ResourceManager.GetString("SendIO", LanguageText_hu.resourceCulture);

		internal static string SendPasscodes => LanguageText_hu.ResourceManager.GetString("SendPasscodes", LanguageText_hu.resourceCulture);

		internal static string SendSpindleConstants => LanguageText_hu.ResourceManager.GetString("SendSpindleConstants", LanguageText_hu.resourceCulture);

		internal static string SendSystemConstants => LanguageText_hu.ResourceManager.GetString("SendSystemConstants", LanguageText_hu.resourceCulture);

		internal static string SensorTest => LanguageText_hu.ResourceManager.GetString("SensorTest", LanguageText_hu.resourceCulture);

		internal static string Set => LanguageText_hu.ResourceManager.GetString("Set", LanguageText_hu.resourceCulture);

		internal static string SetAnaOut => LanguageText_hu.ResourceManager.GetString("SetAnaOut", LanguageText_hu.resourceCulture);

		internal static string SetDigOut => LanguageText_hu.ResourceManager.GetString("SetDigOut", LanguageText_hu.resourceCulture);

		internal static string SetOff => LanguageText_hu.ResourceManager.GetString("SetOff", LanguageText_hu.resourceCulture);

		internal static string SetOn => LanguageText_hu.ResourceManager.GetString("SetOn", LanguageText_hu.resourceCulture);

		internal static string SetRight => LanguageText_hu.ResourceManager.GetString("SetRight", LanguageText_hu.resourceCulture);

		internal static string SetRpm => LanguageText_hu.ResourceManager.GetString("SetRpm", LanguageText_hu.resourceCulture);

		internal static string Settings => LanguageText_hu.ResourceManager.GetString("Settings", LanguageText_hu.resourceCulture);

		internal static string ShortName => LanguageText_hu.ResourceManager.GetString("ShortName", LanguageText_hu.resourceCulture);

		internal static string SignalQuit => LanguageText_hu.ResourceManager.GetString("SignalQuit", LanguageText_hu.resourceCulture);

		internal static string Slovak => LanguageText_hu.ResourceManager.GetString("Slovak", LanguageText_hu.resourceCulture);

		internal static string Spain => LanguageText_hu.ResourceManager.GetString("Spain", LanguageText_hu.resourceCulture);

		internal static string SpChange100010 => LanguageText_hu.ResourceManager.GetString("SpChange100010", LanguageText_hu.resourceCulture);

		internal static string SpChange203000 => LanguageText_hu.ResourceManager.GetString("SpChange203000", LanguageText_hu.resourceCulture);

		internal static string SpChange203001 => LanguageText_hu.ResourceManager.GetString("SpChange203001", LanguageText_hu.resourceCulture);

		internal static string SpChange203002 => LanguageText_hu.ResourceManager.GetString("SpChange203002", LanguageText_hu.resourceCulture);

		internal static string SpChange203003 => LanguageText_hu.ResourceManager.GetString("SpChange203003", LanguageText_hu.resourceCulture);

		internal static string SpChange203004 => LanguageText_hu.ResourceManager.GetString("SpChange203004", LanguageText_hu.resourceCulture);

		internal static string SpChange203005 => LanguageText_hu.ResourceManager.GetString("SpChange203005", LanguageText_hu.resourceCulture);

		internal static string SpChange203006 => LanguageText_hu.ResourceManager.GetString("SpChange203006", LanguageText_hu.resourceCulture);

		internal static string SpChange203007 => LanguageText_hu.ResourceManager.GetString("SpChange203007", LanguageText_hu.resourceCulture);

		internal static string SpChange203008 => LanguageText_hu.ResourceManager.GetString("SpChange203008", LanguageText_hu.resourceCulture);

		internal static string SpChange203009 => LanguageText_hu.ResourceManager.GetString("SpChange203009", LanguageText_hu.resourceCulture);

		internal static string SpChange203010 => LanguageText_hu.ResourceManager.GetString("SpChange203010", LanguageText_hu.resourceCulture);

		internal static string SpChange203011 => LanguageText_hu.ResourceManager.GetString("SpChange203011", LanguageText_hu.resourceCulture);

		internal static string SpChange203012 => LanguageText_hu.ResourceManager.GetString("SpChange203012", LanguageText_hu.resourceCulture);

		internal static string SpChange203013 => LanguageText_hu.ResourceManager.GetString("SpChange203013", LanguageText_hu.resourceCulture);

		internal static string SpChange203014 => LanguageText_hu.ResourceManager.GetString("SpChange203014", LanguageText_hu.resourceCulture);

		internal static string SpChange203015 => LanguageText_hu.ResourceManager.GetString("SpChange203015", LanguageText_hu.resourceCulture);

		internal static string SpChange203016 => LanguageText_hu.ResourceManager.GetString("SpChange203016", LanguageText_hu.resourceCulture);

		internal static string SpChange203017 => LanguageText_hu.ResourceManager.GetString("SpChange203017", LanguageText_hu.resourceCulture);

		internal static string SpChange203018 => LanguageText_hu.ResourceManager.GetString("SpChange203018", LanguageText_hu.resourceCulture);

		internal static string SpChange203019 => LanguageText_hu.ResourceManager.GetString("SpChange203019", LanguageText_hu.resourceCulture);

		internal static string SpChange203020 => LanguageText_hu.ResourceManager.GetString("SpChange203020", LanguageText_hu.resourceCulture);

		internal static string SpChange203021 => LanguageText_hu.ResourceManager.GetString("SpChange203021", LanguageText_hu.resourceCulture);

		internal static string SpChange203022 => LanguageText_hu.ResourceManager.GetString("SpChange203022", LanguageText_hu.resourceCulture);

		internal static string SpChange203023 => LanguageText_hu.ResourceManager.GetString("SpChange203023", LanguageText_hu.resourceCulture);

		internal static string SpChange203024 => LanguageText_hu.ResourceManager.GetString("SpChange203024", LanguageText_hu.resourceCulture);

		internal static string SpChange203025 => LanguageText_hu.ResourceManager.GetString("SpChange203025", LanguageText_hu.resourceCulture);

		internal static string SpChange203026 => LanguageText_hu.ResourceManager.GetString("SpChange203026", LanguageText_hu.resourceCulture);

		internal static string SpChange203027 => LanguageText_hu.ResourceManager.GetString("SpChange203027", LanguageText_hu.resourceCulture);

		internal static string SpChange203028 => LanguageText_hu.ResourceManager.GetString("SpChange203028", LanguageText_hu.resourceCulture);

		internal static string SpChange203029 => LanguageText_hu.ResourceManager.GetString("SpChange203029", LanguageText_hu.resourceCulture);

		internal static string SpChange203030 => LanguageText_hu.ResourceManager.GetString("SpChange203030", LanguageText_hu.resourceCulture);

		internal static string SpChange207001 => LanguageText_hu.ResourceManager.GetString("SpChange207001", LanguageText_hu.resourceCulture);

		internal static string SpChange207002 => LanguageText_hu.ResourceManager.GetString("SpChange207002", LanguageText_hu.resourceCulture);

		internal static string SpChange207003 => LanguageText_hu.ResourceManager.GetString("SpChange207003", LanguageText_hu.resourceCulture);

		internal static string SpindleConstants => LanguageText_hu.ResourceManager.GetString("SpindleConstants", LanguageText_hu.resourceCulture);

		internal static string SpindleConstFiles => LanguageText_hu.ResourceManager.GetString("SpindleConstFiles", LanguageText_hu.resourceCulture);

		internal static string SpindlePressureScale => LanguageText_hu.ResourceManager.GetString("SpindlePressureScale", LanguageText_hu.resourceCulture);

		internal static string SpindleTorque => LanguageText_hu.ResourceManager.GetString("SpindleTorque", LanguageText_hu.resourceCulture);

		internal static string StandardDeviation => LanguageText_hu.ResourceManager.GetString("StandardDeviation", LanguageText_hu.resourceCulture);

		internal static string StartCycleSave => LanguageText_hu.ResourceManager.GetString("StartCycleSave", LanguageText_hu.resourceCulture);

		internal static string StartFrictionTest => LanguageText_hu.ResourceManager.GetString("StartFrictionTest", LanguageText_hu.resourceCulture);

		internal static string StartProgram => LanguageText_hu.ResourceManager.GetString("StartProgram", LanguageText_hu.resourceCulture);

		internal static string StartSignal => LanguageText_hu.ResourceManager.GetString("StartSignal", LanguageText_hu.resourceCulture);

		internal static string StartStepResExport => LanguageText_hu.ResourceManager.GetString("StartStepResExport", LanguageText_hu.resourceCulture);

		internal static string StartTest => LanguageText_hu.ResourceManager.GetString("StartTest", LanguageText_hu.resourceCulture);

		internal static string StatDelete204000 => LanguageText_hu.ResourceManager.GetString("StatDelete204000", LanguageText_hu.resourceCulture);

		internal static string StatDelete204001 => LanguageText_hu.ResourceManager.GetString("StatDelete204001", LanguageText_hu.resourceCulture);

		internal static string StatDelete204002 => LanguageText_hu.ResourceManager.GetString("StatDelete204002", LanguageText_hu.resourceCulture);

		internal static string State => LanguageText_hu.ResourceManager.GetString("State", LanguageText_hu.resourceCulture);

		internal static string StationName => LanguageText_hu.ResourceManager.GetString("StationName", LanguageText_hu.resourceCulture);

		internal static string StatisticCumul => LanguageText_hu.ResourceManager.GetString("StatisticCumul", LanguageText_hu.resourceCulture);

		internal static string Statistics => LanguageText_hu.ResourceManager.GetString("Statistics", LanguageText_hu.resourceCulture);

		internal static string StatisticSample => LanguageText_hu.ResourceManager.GetString("StatisticSample", LanguageText_hu.resourceCulture);

		internal static string StatisticsLastRes => LanguageText_hu.ResourceManager.GetString("StatisticsLastRes", LanguageText_hu.resourceCulture);

		internal static string Step => LanguageText_hu.ResourceManager.GetString("Step", LanguageText_hu.resourceCulture);

		internal static string StepFinish => LanguageText_hu.ResourceManager.GetString("StepFinish", LanguageText_hu.resourceCulture);

		internal static string StepKind => LanguageText_hu.ResourceManager.GetString("StepKind", LanguageText_hu.resourceCulture);

		internal static string StepKindChoice => LanguageText_hu.ResourceManager.GetString("StepKindChoice", LanguageText_hu.resourceCulture);

		internal static string StepResults => LanguageText_hu.ResourceManager.GetString("StepResults", LanguageText_hu.resourceCulture);

		internal static string Steps => LanguageText_hu.ResourceManager.GetString("Steps", LanguageText_hu.resourceCulture);

		internal static string StepTmin => LanguageText_hu.ResourceManager.GetString("StepTmin", LanguageText_hu.resourceCulture);

		internal static string StepTplus => LanguageText_hu.ResourceManager.GetString("StepTplus", LanguageText_hu.resourceCulture);

		internal static string Stop => LanguageText_hu.ResourceManager.GetString("Stop", LanguageText_hu.resourceCulture);

		internal static string StopNok => LanguageText_hu.ResourceManager.GetString("StopNok", LanguageText_hu.resourceCulture);

		internal static string StopOk => LanguageText_hu.ResourceManager.GetString("StopOk", LanguageText_hu.resourceCulture);

		internal static string StopStepResExport => LanguageText_hu.ResourceManager.GetString("StopStepResExport", LanguageText_hu.resourceCulture);

		internal static string storageFilenameFormat => LanguageText_hu.ResourceManager.GetString("storageFilenameFormat", LanguageText_hu.resourceCulture);

		internal static string StorageNumber => LanguageText_hu.ResourceManager.GetString("StorageNumber", LanguageText_hu.resourceCulture);

		internal static string StorageSignals => LanguageText_hu.ResourceManager.GetString("StorageSignals", LanguageText_hu.resourceCulture);

		internal static string StoreAndBack => LanguageText_hu.ResourceManager.GetString("StoreAndBack", LanguageText_hu.resourceCulture);

		internal static string Straßenführer => LanguageText_hu.ResourceManager.GetString("Straßenführer", LanguageText_hu.resourceCulture);

		internal static string SubnetMask => LanguageText_hu.ResourceManager.GetString("SubnetMask", LanguageText_hu.resourceCulture);

		internal static string SyncOut => LanguageText_hu.ResourceManager.GetString("SyncOut", LanguageText_hu.resourceCulture);

		internal static string SyncSignal => LanguageText_hu.ResourceManager.GetString("SyncSignal", LanguageText_hu.resourceCulture);

		internal static string SysChange202000 => LanguageText_hu.ResourceManager.GetString("SysChange202000", LanguageText_hu.resourceCulture);

		internal static string SysChange202001 => LanguageText_hu.ResourceManager.GetString("SysChange202001", LanguageText_hu.resourceCulture);

		internal static string SysChange202002 => LanguageText_hu.ResourceManager.GetString("SysChange202002", LanguageText_hu.resourceCulture);

		internal static string SysChange202003 => LanguageText_hu.ResourceManager.GetString("SysChange202003", LanguageText_hu.resourceCulture);

		internal static string SysChange202004 => LanguageText_hu.ResourceManager.GetString("SysChange202004", LanguageText_hu.resourceCulture);

		internal static string SysChange202005 => LanguageText_hu.ResourceManager.GetString("SysChange202005", LanguageText_hu.resourceCulture);

		internal static string SysChange202006 => LanguageText_hu.ResourceManager.GetString("SysChange202006", LanguageText_hu.resourceCulture);

		internal static string SysChange202007 => LanguageText_hu.ResourceManager.GetString("SysChange202007", LanguageText_hu.resourceCulture);

		internal static string SysChange202008 => LanguageText_hu.ResourceManager.GetString("SysChange202008", LanguageText_hu.resourceCulture);

		internal static string SysChange202009 => LanguageText_hu.ResourceManager.GetString("SysChange202009", LanguageText_hu.resourceCulture);

		internal static string SysChange202010 => LanguageText_hu.ResourceManager.GetString("SysChange202010", LanguageText_hu.resourceCulture);

		internal static string SysChange202011 => LanguageText_hu.ResourceManager.GetString("SysChange202011", LanguageText_hu.resourceCulture);

		internal static string SysChange202012 => LanguageText_hu.ResourceManager.GetString("SysChange202012", LanguageText_hu.resourceCulture);

		internal static string SysChange202013 => LanguageText_hu.ResourceManager.GetString("SysChange202013", LanguageText_hu.resourceCulture);

		internal static string SysChange202014 => LanguageText_hu.ResourceManager.GetString("SysChange202014", LanguageText_hu.resourceCulture);

		internal static string SysChange202015 => LanguageText_hu.ResourceManager.GetString("SysChange202015", LanguageText_hu.resourceCulture);

		internal static string SysChange202016 => LanguageText_hu.ResourceManager.GetString("SysChange202016", LanguageText_hu.resourceCulture);

		internal static string SysChange202017 => LanguageText_hu.ResourceManager.GetString("SysChange202017", LanguageText_hu.resourceCulture);

		internal static string SysChange202018 => LanguageText_hu.ResourceManager.GetString("SysChange202018", LanguageText_hu.resourceCulture);

		internal static string SystemConstants => LanguageText_hu.ResourceManager.GetString("SystemConstants", LanguageText_hu.resourceCulture);

		internal static string SystemID => LanguageText_hu.ResourceManager.GetString("SystemID", LanguageText_hu.resourceCulture);

		internal static string SystemOK => LanguageText_hu.ResourceManager.GetString("SystemOK", LanguageText_hu.resourceCulture);

		internal static string Target => LanguageText_hu.ResourceManager.GetString("Target", LanguageText_hu.resourceCulture);

		internal static string TargetRight => LanguageText_hu.ResourceManager.GetString("TargetRight", LanguageText_hu.resourceCulture);

		internal static string TeachSignal => LanguageText_hu.ResourceManager.GetString("TeachSignal", LanguageText_hu.resourceCulture);

		internal static string Test => LanguageText_hu.ResourceManager.GetString("Test", LanguageText_hu.resourceCulture);

		internal static string TestIO => LanguageText_hu.ResourceManager.GetString("TestIO", LanguageText_hu.resourceCulture);

		internal static string TestMFS => LanguageText_hu.ResourceManager.GetString("TestMFS", LanguageText_hu.resourceCulture);

		internal static string TestSPSIO => LanguageText_hu.ResourceManager.GetString("TestSPSIO", LanguageText_hu.resourceCulture);

		internal static string Time => LanguageText_hu.ResourceManager.GetString("Time", LanguageText_hu.resourceCulture);

		internal static string TimeDateFormat => LanguageText_hu.ResourceManager.GetString("TimeDateFormat", LanguageText_hu.resourceCulture);

		internal static string TimeSet => LanguageText_hu.ResourceManager.GetString("TimeSet", LanguageText_hu.resourceCulture);

		internal static string TimeSynchronize => LanguageText_hu.ResourceManager.GetString("TimeSynchronize", LanguageText_hu.resourceCulture);

		internal static string TM1 => LanguageText_hu.ResourceManager.GetString("TM1", LanguageText_hu.resourceCulture);

		internal static string TM2 => LanguageText_hu.ResourceManager.GetString("TM2", LanguageText_hu.resourceCulture);

		internal static string TN => LanguageText_hu.ResourceManager.GetString("TN", LanguageText_hu.resourceCulture);

		internal static string ToggleCursor => LanguageText_hu.ResourceManager.GetString("ToggleCursor", LanguageText_hu.resourceCulture);

		internal static string TopAll => LanguageText_hu.ResourceManager.GetString("TopAll", LanguageText_hu.resourceCulture);

		internal static string TopTen => LanguageText_hu.ResourceManager.GetString("TopTen", LanguageText_hu.resourceCulture);

		internal static string Torque => LanguageText_hu.ResourceManager.GetString("Torque", LanguageText_hu.resourceCulture);

		internal static string Torqueftlb => LanguageText_hu.ResourceManager.GetString("Torqueftlb", LanguageText_hu.resourceCulture);

		internal static string Torqueinlb => LanguageText_hu.ResourceManager.GetString("Torqueinlb", LanguageText_hu.resourceCulture);

		internal static string Torqueinoz => LanguageText_hu.ResourceManager.GetString("Torqueinoz", LanguageText_hu.resourceCulture);

		internal static string Torquekgcm => LanguageText_hu.ResourceManager.GetString("Torquekgcm", LanguageText_hu.resourceCulture);

		internal static string Torquekgm => LanguageText_hu.ResourceManager.GetString("Torquekgm", LanguageText_hu.resourceCulture);

		internal static string TorqueNcm => LanguageText_hu.ResourceManager.GetString("TorqueNcm", LanguageText_hu.resourceCulture);

		internal static string TorqueNm => LanguageText_hu.ResourceManager.GetString("TorqueNm", LanguageText_hu.resourceCulture);

		internal static string TorqueRedundantTime => LanguageText_hu.ResourceManager.GetString("TorqueRedundantTime", LanguageText_hu.resourceCulture);

		internal static string TorqueRedundantTolerance => LanguageText_hu.ResourceManager.GetString("TorqueRedundantTolerance", LanguageText_hu.resourceCulture);

		internal static string TorqueSensorInvers => LanguageText_hu.ResourceManager.GetString("TorqueSensorInvers", LanguageText_hu.resourceCulture);

		internal static string TorqueSensorScale => LanguageText_hu.ResourceManager.GetString("TorqueSensorScale", LanguageText_hu.resourceCulture);

		internal static string TorqueSensorTolerance => LanguageText_hu.ResourceManager.GetString("TorqueSensorTolerance", LanguageText_hu.resourceCulture);

		internal static string TorqueUnitChoose => LanguageText_hu.ResourceManager.GetString("TorqueUnitChoose", LanguageText_hu.resourceCulture);

		internal static string TreshTorque => LanguageText_hu.ResourceManager.GetString("TreshTorque", LanguageText_hu.resourceCulture);

		internal static string Type => LanguageText_hu.ResourceManager.GetString("Type", LanguageText_hu.resourceCulture);

		internal static string Unit => LanguageText_hu.ResourceManager.GetString("Unit", LanguageText_hu.resourceCulture);

		internal static string UnitBar => LanguageText_hu.ResourceManager.GetString("UnitBar", LanguageText_hu.resourceCulture);

		internal static string UpperLimit => LanguageText_hu.ResourceManager.GetString("UpperLimit", LanguageText_hu.resourceCulture);

		internal static string UsbPasswordInput => LanguageText_hu.ResourceManager.GetString("UsbPasswordInput", LanguageText_hu.resourceCulture);

		internal static string UsedKeyboard => LanguageText_hu.ResourceManager.GetString("UsedKeyboard", LanguageText_hu.resourceCulture);

		internal static string UsedValueNumber => LanguageText_hu.ResourceManager.GetString("UsedValueNumber", LanguageText_hu.resourceCulture);

		internal static string UseLanguageSettings => LanguageText_hu.ResourceManager.GetString("UseLanguageSettings", LanguageText_hu.resourceCulture);

		internal static string User => LanguageText_hu.ResourceManager.GetString("User", LanguageText_hu.resourceCulture);

		internal static string UserLoggedIn => LanguageText_hu.ResourceManager.GetString("UserLoggedIn", LanguageText_hu.resourceCulture);

		internal static string UserLoggedOut => LanguageText_hu.ResourceManager.GetString("UserLoggedOut", LanguageText_hu.resourceCulture);

		internal static string UserRights => LanguageText_hu.ResourceManager.GetString("UserRights", LanguageText_hu.resourceCulture);

		internal static string USTime => LanguageText_hu.ResourceManager.GetString("USTime", LanguageText_hu.resourceCulture);

		internal static string Valid => LanguageText_hu.ResourceManager.GetString("Valid", LanguageText_hu.resourceCulture);

		internal static string Value => LanguageText_hu.ResourceManager.GetString("Value", LanguageText_hu.resourceCulture);

		internal static string ValueRange => LanguageText_hu.ResourceManager.GetString("ValueRange", LanguageText_hu.resourceCulture);

		internal static string ValuesNotApplied => LanguageText_hu.ResourceManager.GetString("ValuesNotApplied", LanguageText_hu.resourceCulture);

		internal static string VersionController => LanguageText_hu.ResourceManager.GetString("VersionController", LanguageText_hu.resourceCulture);

		internal static string VersionInfo => LanguageText_hu.ResourceManager.GetString("VersionInfo", LanguageText_hu.resourceCulture);

		internal static string VersionVisu => LanguageText_hu.ResourceManager.GetString("VersionVisu", LanguageText_hu.resourceCulture);

		internal static string Visualisation => LanguageText_hu.ResourceManager.GetString("Visualisation", LanguageText_hu.resourceCulture);

		internal static string VisuParam => LanguageText_hu.ResourceManager.GetString("VisuParam", LanguageText_hu.resourceCulture);

		internal static string Voltage => LanguageText_hu.ResourceManager.GetString("Voltage", LanguageText_hu.resourceCulture);

		internal static string WaitForAck => LanguageText_hu.ResourceManager.GetString("WaitForAck", LanguageText_hu.resourceCulture);

		internal static string Warning => LanguageText_hu.ResourceManager.GetString("Warning", LanguageText_hu.resourceCulture);

		internal static string WarningMode => LanguageText_hu.ResourceManager.GetString("WarningMode", LanguageText_hu.resourceCulture);

		internal static string WarningNumber => LanguageText_hu.ResourceManager.GetString("WarningNumber", LanguageText_hu.resourceCulture);

		internal static string WasReset => LanguageText_hu.ResourceManager.GetString("WasReset", LanguageText_hu.resourceCulture);

		internal static string WasSet => LanguageText_hu.ResourceManager.GetString("WasSet", LanguageText_hu.resourceCulture);

		internal static string Weber => LanguageText_hu.ResourceManager.GetString("Weber", LanguageText_hu.resourceCulture);

		internal static string WeberCurveFormat => LanguageText_hu.ResourceManager.GetString("WeberCurveFormat", LanguageText_hu.resourceCulture);

		internal static string WN => LanguageText_hu.ResourceManager.GetString("WN", LanguageText_hu.resourceCulture);

		internal static string WriteLastNIOTable => LanguageText_hu.ResourceManager.GetString("WriteLastNIOTable", LanguageText_hu.resourceCulture);

		internal static string WriteLastResultsTable => LanguageText_hu.ResourceManager.GetString("WriteLastResultsTable", LanguageText_hu.resourceCulture);

		internal static string WriteLogbookData => LanguageText_hu.ResourceManager.GetString("WriteLogbookData", LanguageText_hu.resourceCulture);

		internal static string WriteLogBookTable => LanguageText_hu.ResourceManager.GetString("WriteLogBookTable", LanguageText_hu.resourceCulture);

		internal static string WriteStepResults => LanguageText_hu.ResourceManager.GetString("WriteStepResults", LanguageText_hu.resourceCulture);

		internal static string Xmax => LanguageText_hu.ResourceManager.GetString("Xmax", LanguageText_hu.resourceCulture);

		internal static string Xmin => LanguageText_hu.ResourceManager.GetString("Xmin", LanguageText_hu.resourceCulture);

		internal static string XmlExport => LanguageText_hu.ResourceManager.GetString("XmlExport", LanguageText_hu.resourceCulture);

		internal static string Yes => LanguageText_hu.ResourceManager.GetString("Yes", LanguageText_hu.resourceCulture);

		internal static string ZoomIn => LanguageText_hu.ResourceManager.GetString("ZoomIn", LanguageText_hu.resourceCulture);

		internal static string ZoomOut => LanguageText_hu.ResourceManager.GetString("ZoomOut", LanguageText_hu.resourceCulture);

		internal LanguageText_hu()
		{
		}
	}
}
