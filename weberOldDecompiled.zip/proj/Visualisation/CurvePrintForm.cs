using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class CurvePrintForm : Form
	{
		public const int NOMODE = 0;

		public const int PRINTMODE = 1;

		public const int EXPORTMODE = 2;

		public const int SAVEMODE = 3;

		public const int XML_EXPORT_MODE = 4;

		public const int CYCLESAVEMODE_NORMAL = 5;

		public const int CYCLESAVEMODE_EXPORT = 6;

		public const int CYCLESAVEMODE_XML_EXPORT = 7;

		public const int LOADMODE = 8;

		public const int DISPLAY_FIFO_BUFFER = 9;

		public const int DISPLAY_CURVE_BUFFER = 10;

		public const int SET_FIFO_BUFFER_ACTIVE = 11;

		public const int KIND_ALL = 0;

		public const int KIND_IO = 1;

		public const int KIND_NIO = 2;

		private MainForm Main;

		private int Mode;

		public int CurvesToStore;

		private bool initializing;

		private Button btPrint;

		private Button btExport;

		private Button btCancel;

		private Button btSave;

		private Button btLoad;

		private GroupBox gBExport;

		private Button btCycleSave;

		private GroupBox gBCycleSave;

		private ComboBox cBResultKind;

		private Label lbResultKind;

		private Label lbResultNumber;

		private NumberEdit1 nEResultNumber;

		private Label lbRemainedCurves;

		private Label lbShowRemainedCurves;

		private Button btDeleteJob;

		private ComboBox cBSave;

		private Button bt_XML_Export;

		private Label lbTargetDirectory;

		private Label lbOutputDirectory;

		private CheckBox chBFIFO_Buffer;

		private Button btDirectoryFIFO;

		private Label lbDirectoryFIFO;

		private NumberEdit1 nEResultNumberFIFO;

		private Label lbShowRemainedCurvesFIFO;

		private Label lbRemainedCurvesFIFO;

		private ComboBox cBSaveFIFO;

		private Button btOK;

		private Button btDirectory;

		private Button btDisplayAutoCurves;

		private Container components;

		public CurvePrintForm(MainForm main)
		{
			this.Main = main;
			this.Mode = 0;
			this.InitializeComponent();
			this.nEResultNumber.Value = Settings.Default.CurrentSaveCurveNum;
			if (Settings.Default.Curve_StoringFIFO_Directory.Length == 0)
			{
				Settings.Default.Curve_StoringToFIFO_active = false;
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.btPrint = new System.Windows.Forms.Button();
			this.btExport = new System.Windows.Forms.Button();
			this.btCancel = new System.Windows.Forms.Button();
			this.btSave = new System.Windows.Forms.Button();
			this.btLoad = new System.Windows.Forms.Button();
			this.gBExport = new System.Windows.Forms.GroupBox();
			this.bt_XML_Export = new System.Windows.Forms.Button();
			this.gBCycleSave = new System.Windows.Forms.GroupBox();
			this.cBSaveFIFO = new System.Windows.Forms.ComboBox();
			this.btDisplayAutoCurves = new System.Windows.Forms.Button();
			this.lbShowRemainedCurvesFIFO = new System.Windows.Forms.Label();
			this.btDirectory = new System.Windows.Forms.Button();
			this.lbRemainedCurvesFIFO = new System.Windows.Forms.Label();
			this.lbResultKind = new System.Windows.Forms.Label();
			this.nEResultNumberFIFO = new Visualisation.NumberEdit1();
			this.cBResultKind = new System.Windows.Forms.ComboBox();
			this.lbDirectoryFIFO = new System.Windows.Forms.Label();
			this.lbOutputDirectory = new System.Windows.Forms.Label();
			this.btDirectoryFIFO = new System.Windows.Forms.Button();
			this.lbTargetDirectory = new System.Windows.Forms.Label();
			this.cBSave = new System.Windows.Forms.ComboBox();
			this.btDeleteJob = new System.Windows.Forms.Button();
			this.lbShowRemainedCurves = new System.Windows.Forms.Label();
			this.nEResultNumber = new Visualisation.NumberEdit1();
			this.lbRemainedCurves = new System.Windows.Forms.Label();
			this.lbResultNumber = new System.Windows.Forms.Label();
			this.btCycleSave = new System.Windows.Forms.Button();
			this.chBFIFO_Buffer = new System.Windows.Forms.CheckBox();
			this.btOK = new System.Windows.Forms.Button();
			this.gBExport.SuspendLayout();
			this.gBCycleSave.SuspendLayout();
			this.SuspendLayout();
			// 
			// btPrint
			// 
			this.btPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.btPrint.Location = new System.Drawing.Point(252, 24);
			this.btPrint.Name = "btPrint";
			this.btPrint.Size = new System.Drawing.Size(112, 64);
			this.btPrint.TabIndex = 2;
			this.btPrint.Text = "Print";
			// 
			// btExport
			// 
			this.btExport.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.btExport.Location = new System.Drawing.Point(370, 24);
			this.btExport.Name = "btExport";
			this.btExport.Size = new System.Drawing.Size(112, 64);
			this.btExport.TabIndex = 3;
			this.btExport.Text = "Export";
			this.btExport.Click += new System.EventHandler(this.btExport_Click_1);
			// 
			// btCancel
			// 
			this.btCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.btCancel.Location = new System.Drawing.Point(378, 422);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new System.Drawing.Size(112, 64);
			this.btCancel.TabIndex = 0;
			this.btCancel.Text = "Abbrechen";
			// 
			// btSave
			// 
			this.btSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.btSave.Location = new System.Drawing.Point(16, 24);
			this.btSave.Name = "btSave";
			this.btSave.Size = new System.Drawing.Size(112, 64);
			this.btSave.TabIndex = 0;
			this.btSave.Text = "Save";
			this.btSave.Click += new System.EventHandler(this.btSave_Click_1);
			// 
			// btLoad
			// 
			this.btLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.btLoad.Location = new System.Drawing.Point(134, 24);
			this.btLoad.Name = "btLoad";
			this.btLoad.Size = new System.Drawing.Size(112, 64);
			this.btLoad.TabIndex = 1;
			this.btLoad.Text = "Load";
			// 
			// gBExport
			// 
			this.gBExport.Controls.Add(this.bt_XML_Export);
			this.gBExport.Controls.Add(this.btPrint);
			this.gBExport.Controls.Add(this.btExport);
			this.gBExport.Controls.Add(this.btSave);
			this.gBExport.Controls.Add(this.btLoad);
			this.gBExport.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.gBExport.Location = new System.Drawing.Point(8, 8);
			this.gBExport.Name = "gBExport";
			this.gBExport.Size = new System.Drawing.Size(614, 116);
			this.gBExport.TabIndex = 7;
			this.gBExport.TabStop = false;
			this.gBExport.Text = "Kurvendateien";
			// 
			// bt_XML_Export
			// 
			this.bt_XML_Export.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.bt_XML_Export.Location = new System.Drawing.Point(488, 24);
			this.bt_XML_Export.Name = "bt_XML_Export";
			this.bt_XML_Export.Size = new System.Drawing.Size(112, 64);
			this.bt_XML_Export.TabIndex = 4;
			this.bt_XML_Export.Text = "XML Export";
			this.bt_XML_Export.Click += new System.EventHandler(this.bt_XML_Export_Click_1);
			// 
			// gBCycleSave
			// 
			this.gBCycleSave.Controls.Add(this.cBSaveFIFO);
			this.gBCycleSave.Controls.Add(this.btDisplayAutoCurves);
			this.gBCycleSave.Controls.Add(this.lbShowRemainedCurvesFIFO);
			this.gBCycleSave.Controls.Add(this.btDirectory);
			this.gBCycleSave.Controls.Add(this.lbRemainedCurvesFIFO);
			this.gBCycleSave.Controls.Add(this.lbResultKind);
			this.gBCycleSave.Controls.Add(this.nEResultNumberFIFO);
			this.gBCycleSave.Controls.Add(this.cBResultKind);
			this.gBCycleSave.Controls.Add(this.lbDirectoryFIFO);
			this.gBCycleSave.Controls.Add(this.lbOutputDirectory);
			this.gBCycleSave.Controls.Add(this.btDirectoryFIFO);
			this.gBCycleSave.Controls.Add(this.lbTargetDirectory);
			this.gBCycleSave.Controls.Add(this.cBSave);
			this.gBCycleSave.Controls.Add(this.btDeleteJob);
			this.gBCycleSave.Controls.Add(this.lbShowRemainedCurves);
			this.gBCycleSave.Controls.Add(this.nEResultNumber);
			this.gBCycleSave.Controls.Add(this.lbRemainedCurves);
			this.gBCycleSave.Controls.Add(this.lbResultNumber);
			this.gBCycleSave.Controls.Add(this.btCycleSave);
			this.gBCycleSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.gBCycleSave.Location = new System.Drawing.Point(8, 152);
			this.gBCycleSave.Name = "gBCycleSave";
			this.gBCycleSave.Size = new System.Drawing.Size(614, 261);
			this.gBCycleSave.TabIndex = 8;
			this.gBCycleSave.TabStop = false;
			this.gBCycleSave.Text = "Automatisches Speichern";
			// 
			// cBSaveFIFO
			// 
			this.cBSaveFIFO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cBSaveFIFO.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.cBSaveFIFO.Location = new System.Drawing.Point(266, 198);
			this.cBSaveFIFO.MaxDropDownItems = 3;
			this.cBSaveFIFO.Name = "cBSaveFIFO";
			this.cBSaveFIFO.Size = new System.Drawing.Size(272, 26);
			this.cBSaveFIFO.TabIndex = 26;
			// 
			// btDisplayAutoCurves
			// 
			this.btDisplayAutoCurves.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.btDisplayAutoCurves.Location = new System.Drawing.Point(252, 24);
			this.btDisplayAutoCurves.Name = "btDisplayAutoCurves";
			this.btDisplayAutoCurves.Size = new System.Drawing.Size(112, 64);
			this.btDisplayAutoCurves.TabIndex = 20;
			this.btDisplayAutoCurves.Text = "Anzeigen";
			// 
			// lbShowRemainedCurvesFIFO
			// 
			this.lbShowRemainedCurvesFIFO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbShowRemainedCurvesFIFO.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbShowRemainedCurvesFIFO.Location = new System.Drawing.Point(158, 198);
			this.lbShowRemainedCurvesFIFO.Name = "lbShowRemainedCurvesFIFO";
			this.lbShowRemainedCurvesFIFO.Size = new System.Drawing.Size(72, 28);
			this.lbShowRemainedCurvesFIFO.TabIndex = 21;
			this.lbShowRemainedCurvesFIFO.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// btDirectory
			// 
			this.btDirectory.Location = new System.Drawing.Point(16, 117);
			this.btDirectory.Name = "btDirectory";
			this.btDirectory.Size = new System.Drawing.Size(42, 27);
			this.btDirectory.TabIndex = 16;
			this.btDirectory.Text = "...";
			this.btDirectory.UseVisualStyleBackColor = true;
			// 
			// lbRemainedCurvesFIFO
			// 
			this.lbRemainedCurvesFIFO.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbRemainedCurvesFIFO.Location = new System.Drawing.Point(8, 179);
			this.lbRemainedCurvesFIFO.Name = "lbRemainedCurvesFIFO";
			this.lbRemainedCurvesFIFO.Size = new System.Drawing.Size(150, 67);
			this.lbRemainedCurvesFIFO.TabIndex = 22;
			this.lbRemainedCurvesFIFO.Text = "Aktuelle Anzahl der Kurven im Ringspeicher";
			this.lbRemainedCurvesFIFO.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbResultKind
			// 
			this.lbResultKind.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbResultKind.Location = new System.Drawing.Point(263, 152);
			this.lbResultKind.Name = "lbResultKind";
			this.lbResultKind.Size = new System.Drawing.Size(144, 23);
			this.lbResultKind.TabIndex = 7;
			this.lbResultKind.Text = "Art";
			this.lbResultKind.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// nEResultNumberFIFO
			// 
			this.nEResultNumberFIFO.BackColor = System.Drawing.Color.White;
			this.nEResultNumberFIFO.DecimalNum = 0;
			this.nEResultNumberFIFO.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.nEResultNumberFIFO.ForeColor = System.Drawing.SystemColors.ControlText;
			this.nEResultNumberFIFO.Location = new System.Drawing.Point(158, 144);
			this.nEResultNumberFIFO.MaxValue = 3000F;
			this.nEResultNumberFIFO.MinValue = 10F;
			this.nEResultNumberFIFO.Name = "nEResultNumberFIFO";
			this.nEResultNumberFIFO.Size = new System.Drawing.Size(72, 24);
			this.nEResultNumberFIFO.TabIndex = 19;
			this.nEResultNumberFIFO.Text = "3000";
			this.nEResultNumberFIFO.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.nEResultNumberFIFO.Value = 3000F;
			// 
			// cBResultKind
			// 
			this.cBResultKind.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cBResultKind.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.cBResultKind.Location = new System.Drawing.Point(413, 147);
			this.cBResultKind.Name = "cBResultKind";
			this.cBResultKind.Size = new System.Drawing.Size(121, 26);
			this.cBResultKind.TabIndex = 2;
			// 
			// lbDirectoryFIFO
			// 
			this.lbDirectoryFIFO.AutoSize = true;
			this.lbDirectoryFIFO.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbDirectoryFIFO.Location = new System.Drawing.Point(64, 115);
			this.lbDirectoryFIFO.Name = "lbDirectoryFIFO";
			this.lbDirectoryFIFO.Size = new System.Drawing.Size(108, 20);
			this.lbDirectoryFIFO.TabIndex = 17;
			this.lbDirectoryFIFO.Text = "Verzeichnis";
			this.lbDirectoryFIFO.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbOutputDirectory
			// 
			this.lbOutputDirectory.AutoSize = true;
			this.lbOutputDirectory.Location = new System.Drawing.Point(6, 93);
			this.lbOutputDirectory.Name = "lbOutputDirectory";
			this.lbOutputDirectory.Size = new System.Drawing.Size(81, 17);
			this.lbOutputDirectory.TabIndex = 15;
			this.lbOutputDirectory.Text = "Verzeichnis";
			// 
			// btDirectoryFIFO
			// 
			this.btDirectoryFIFO.Location = new System.Drawing.Point(16, 117);
			this.btDirectoryFIFO.Name = "btDirectoryFIFO";
			this.btDirectoryFIFO.Size = new System.Drawing.Size(42, 27);
			this.btDirectoryFIFO.TabIndex = 1;
			this.btDirectoryFIFO.Text = "...";
			this.btDirectoryFIFO.UseVisualStyleBackColor = true;
			// 
			// lbTargetDirectory
			// 
			this.lbTargetDirectory.AutoSize = true;
			this.lbTargetDirectory.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbTargetDirectory.Location = new System.Drawing.Point(63, 117);
			this.lbTargetDirectory.Name = "lbTargetDirectory";
			this.lbTargetDirectory.Size = new System.Drawing.Size(108, 20);
			this.lbTargetDirectory.TabIndex = 14;
			this.lbTargetDirectory.Text = "Verzeichnis";
			// 
			// cBSave
			// 
			this.cBSave.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cBSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.cBSave.Location = new System.Drawing.Point(266, 198);
			this.cBSave.MaxDropDownItems = 3;
			this.cBSave.Name = "cBSave";
			this.cBSave.Size = new System.Drawing.Size(272, 26);
			this.cBSave.TabIndex = 3;
			// 
			// btDeleteJob
			// 
			this.btDeleteJob.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.btDeleteJob.Location = new System.Drawing.Point(134, 24);
			this.btDeleteJob.Name = "btDeleteJob";
			this.btDeleteJob.Size = new System.Drawing.Size(112, 64);
			this.btDeleteJob.TabIndex = 5;
			this.btDeleteJob.Text = "Auftrag löschen";
			// 
			// lbShowRemainedCurves
			// 
			this.lbShowRemainedCurves.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbShowRemainedCurves.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbShowRemainedCurves.Location = new System.Drawing.Point(158, 198);
			this.lbShowRemainedCurves.Name = "lbShowRemainedCurves";
			this.lbShowRemainedCurves.Size = new System.Drawing.Size(72, 28);
			this.lbShowRemainedCurves.TabIndex = 1;
			this.lbShowRemainedCurves.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// nEResultNumber
			// 
			this.nEResultNumber.BackColor = System.Drawing.Color.White;
			this.nEResultNumber.DecimalNum = 0;
			this.nEResultNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.nEResultNumber.ForeColor = System.Drawing.SystemColors.ControlText;
			this.nEResultNumber.Location = new System.Drawing.Point(158, 145);
			this.nEResultNumber.MaxValue = 100000F;
			this.nEResultNumber.MinValue = 0F;
			this.nEResultNumber.Name = "nEResultNumber";
			this.nEResultNumber.Size = new System.Drawing.Size(72, 24);
			this.nEResultNumber.TabIndex = 0;
			this.nEResultNumber.Text = "65500";
			this.nEResultNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.nEResultNumber.Value = 65500F;
			// 
			// lbRemainedCurves
			// 
			this.lbRemainedCurves.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbRemainedCurves.Location = new System.Drawing.Point(6, 184);
			this.lbRemainedCurves.Name = "lbRemainedCurves";
			this.lbRemainedCurves.Size = new System.Drawing.Size(150, 58);
			this.lbRemainedCurves.TabIndex = 9;
			this.lbRemainedCurves.Text = "Anzahl der noch zu speichernden Kurven";
			this.lbRemainedCurves.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbResultNumber
			// 
			this.lbResultNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.lbResultNumber.Location = new System.Drawing.Point(6, 148);
			this.lbResultNumber.Name = "lbResultNumber";
			this.lbResultNumber.Size = new System.Drawing.Size(144, 23);
			this.lbResultNumber.TabIndex = 8;
			this.lbResultNumber.Text = "Anzahl";
			this.lbResultNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// btCycleSave
			// 
			this.btCycleSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.btCycleSave.Location = new System.Drawing.Point(16, 24);
			this.btCycleSave.Name = "btCycleSave";
			this.btCycleSave.Size = new System.Drawing.Size(112, 64);
			this.btCycleSave.TabIndex = 4;
			this.btCycleSave.Text = "Speichern";
			// 
			// chBFIFO_Buffer
			// 
			this.chBFIFO_Buffer.AutoSize = true;
			this.chBFIFO_Buffer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.chBFIFO_Buffer.Location = new System.Drawing.Point(17, 130);
			this.chBFIFO_Buffer.Name = "chBFIFO_Buffer";
			this.chBFIFO_Buffer.Size = new System.Drawing.Size(91, 24);
			this.chBFIFO_Buffer.TabIndex = 0;
			this.chBFIFO_Buffer.Text = "Activate";
			this.chBFIFO_Buffer.UseVisualStyleBackColor = true;
			// 
			// btOK
			// 
			this.btOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.btOK.Location = new System.Drawing.Point(142, 424);
			this.btOK.Name = "btOK";
			this.btOK.Size = new System.Drawing.Size(112, 64);
			this.btOK.TabIndex = 18;
			this.btOK.Text = "OK";
			// 
			// CurvePrintForm
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(636, 500);
			this.ControlBox = false;
			this.Controls.Add(this.btOK);
			this.Controls.Add(this.chBFIFO_Buffer);
			this.Controls.Add(this.gBCycleSave);
			this.Controls.Add(this.gBExport);
			this.Controls.Add(this.btCancel);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "CurvePrintForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "CurvePrint";
			this.gBExport.ResumeLayout(false);
			this.gBCycleSave.ResumeLayout(false);
			this.gBCycleSave.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		public void ShowWindow()
		{
			this.initializing = true;
			this.nEResultNumber.MaxValue = Settings.Default.MaxSavCurveNum;
			this.nEResultNumberFIFO.Value = (float)Settings.Default.Curve_StoringFIFO_maxCount;
			this.nEResultNumberFIFO.MaxValue = (float)Settings.Default.Curve_StoringFIFO_SettingMaxCount;
			this.lbTargetDirectory.Text = Settings.Default._CurveAutoExportDefaultDirectory;
			if (this.lbTargetDirectory.Text.Length == 0)
			{
				this.lbTargetDirectory.Text = "--";
			}
			this.chBFIFO_Buffer.Checked = Settings.Default.Curve_StoringToFIFO_active;
			this.lbDirectoryFIFO.Text = Settings.Default.Curve_StoringFIFO_Directory;
			if (this.lbDirectoryFIFO.Text.Length == 0)
			{
				this.lbDirectoryFIFO.Text = "--";
			}
			this.cBResultKind.Enabled = true;
			this.chBFIFO_Buffer.Enabled = true;
			this.btDirectoryFIFO.Enabled = true;
			if (this.lbTargetDirectory.Text.Length == 0)
			{
				this.btDisplayAutoCurves.Enabled = false;
			}
			else
			{
				this.btDisplayAutoCurves.Enabled = true;
			}
			this.hideControls(Settings.Default.Curve_StoringToFIFO_active);
			this.initializing = false;
			if (this.Main.CurveFifo.CurveFiles == null)
			{
				this.lbShowRemainedCurvesFIFO.Text = "0";
			}
			else
			{
				this.lbShowRemainedCurvesFIFO.Text = this.Main.CurveFifo.CurveFiles.Count().ToString();
			}
			base.ShowDialog();
		}

		public void SetLanguageTexts()
		{
			this.initializing = true;
			this.Text = this.Main.Rm.GetString("FileOperationMenu");
			this.btExport.Text = this.Main.Rm.GetString("Export");
			this.bt_XML_Export.Text = this.Main.Rm.GetString("XmlExport");
			this.btPrint.Text = this.Main.Rm.GetString("CurvePrint");
			this.gBCycleSave.Text = this.Main.Rm.GetString("CycleSave");
			this.gBExport.Text = this.Main.Rm.GetString("lbCurrentCurve");
			this.btSave.Text = this.Main.Rm.GetString("CurveSave");
			this.lbResultKind.Text = this.Main.Rm.GetString("CurveResultKind");
			this.btCycleSave.Text = this.Main.Rm.GetString("StartCycleSave");
			this.lbResultNumber.Text = this.Main.Rm.GetString("CurveResultNumber");
			this.lbRemainedCurves.Text = this.Main.Rm.GetString("RemainedCurves");
			this.lbRemainedCurvesFIFO.Text = this.Main.Rm.GetString("RemainedCurvesFIFO");
			this.lbOutputDirectory.Text = this.Main.Rm.GetString("OutputInDirectory");
			this.btDisplayAutoCurves.Text = this.Main.Rm.GetString("CurveDisplay");
			this.chBFIFO_Buffer.Text = this.Main.Rm.GetString("ActiveteFIFO_Buffer");
			this.cBResultKind.Items.Clear();
			this.cBResultKind.Items.Add(this.Main.Rm.GetString("All"));
			this.cBResultKind.Items.Add(this.Main.Rm.GetString("OK"));
			this.cBResultKind.Items.Add(this.Main.Rm.GetString("NOK"));
			this.cBResultKind.SelectedIndex = Settings.Default.CurvePrintType;
			this.btLoad.Text = this.Main.Rm.GetString("CurveLoad");
			this.btCancel.Text = this.Main.Rm.GetString("Close");
			this.btDeleteJob.Text = this.Main.Rm.GetString("DeleteJob");
			this.cBSave.Items.Clear();
			this.cBSave.Items.Add(this.Main.Rm.GetString("WeberCurveFormat") + string.Empty);
			this.cBSave.Items.Add(this.Main.Rm.GetString("Export") + string.Empty);
			this.cBSave.Items.Add(this.Main.Rm.GetString("XmlExport") + string.Empty);
			this.cBSave.SelectedIndex = 0;
			this.cBSaveFIFO.Items.Clear();
			this.cBSaveFIFO.Items.Add(this.Main.Rm.GetString("WeberCurveFormat") + string.Empty);
			this.cBSaveFIFO.SelectedIndex = 0;
			this.cBSaveFIFO.Enabled = false;
			this.initializing = false;
		}

		public void MenEna(int num)
		{
			this.lbShowRemainedCurves.Text = num.ToString();
			if (num > 0)
			{
				this.btCycleSave.Enabled = false;
				this.cBResultKind.Enabled = false;
				this.nEResultNumber.Enabled = false;
				this.cBSave.Enabled = false;
			}
			else
			{
				this.btCycleSave.Enabled = true;
				this.cBResultKind.Enabled = true;
				this.nEResultNumber.Enabled = true;
				this.cBSave.Enabled = true;
			}
			this.cBSaveFIFO.Enabled = false;
		}

		public int GetMode()
		{
			return this.Mode;
		}

		public int GetResultNumber()
		{
			return (int)this.nEResultNumber.Value;
		}

		public int GetResultKind()
		{
			return this.cBResultKind.SelectedIndex;
		}

		private void btPrint_Click(object sender, EventArgs e)
		{
			this.Mode = 1;
			base.Close();
		}

		private void btExport_Click(object sender, EventArgs e)
		{
			this.Mode = 2;
			base.Close();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.Mode = 0;
			base.Close();
		}

		private void btSave_Click(object sender, EventArgs e)
		{
			this.Mode = 3;
			base.Close();
		}

		private void btCycleSave_Click(object sender, EventArgs e)
		{
			string empty = string.Empty;
			if (!this.nEResultNumber.IsOK)
			{
				empty = this.lbResultNumber.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEResultNumber.MinValue.ToString() + " - " + this.nEResultNumber.MaxValue.ToString();
				MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + empty, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				switch (this.cBSave.SelectedIndex)
				{
				case 0:
					this.Mode = 5;
					break;
				case 1:
					this.Mode = 6;
					break;
				case 2:
					this.Mode = 7;
					break;
				default:
					this.Mode = 5;
					break;
				}
				Settings.Default.Curve_StoringToFIFO_active = false;
				Settings.Default.Curve_StoringFIFO_Directory = this.lbDirectoryFIFO.Text;
				Settings.Default.Save();
				Settings.Default.CurvePrintType = this.cBResultKind.SelectedIndex;
				Settings.Default.CurrentSaveCurveNum = this.nEResultNumber.Value;
				Settings.Default._CurveAutoExportDefaultDirectory = this.lbTargetDirectory.Text;
				base.Close();
			}
		}

		private void btOK_Click(object sender, EventArgs e)
		{
			if (this.chBFIFO_Buffer.Checked)
			{
				if (!this.nEResultNumberFIFO.IsOK)
				{
					string str = this.nEResultNumberFIFO.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEResultNumberFIFO.MinValue.ToString() + " - " + this.nEResultNumberFIFO.MaxValue.ToString();
					MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + str, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}
				Settings.Default.Curve_StoringFIFO_maxCount = (int)this.nEResultNumberFIFO.Value;
			}
			else
			{
				if (!this.nEResultNumber.IsOK)
				{
					string str2 = this.lbResultNumber.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEResultNumber.MinValue.ToString() + " - " + this.nEResultNumber.MaxValue.ToString();
					MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + str2, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}
				Settings.Default.CurrentSaveCurveNum = this.nEResultNumber.Value;
			}
			Settings.Default.Curve_StoringFIFO_maxCount = (int)this.nEResultNumberFIFO.Value;
			Settings.Default.Curve_StoringToFIFO_active = this.chBFIFO_Buffer.Checked;
			Settings.Default.Curve_StoringFIFO_Directory = this.lbDirectoryFIFO.Text;
			Settings.Default.CurvePrintType = this.cBResultKind.SelectedIndex;
			Settings.Default._CurveAutoExportDefaultDirectory = this.lbTargetDirectory.Text;
			Settings.Default.Save();
			if (Settings.Default.Curve_StoringToFIFO_active)
			{
				this.Mode = 11;
			}
			else
			{
				this.Mode = 0;
			}
			base.Close();
		}

		private void btLoad_Click(object sender, EventArgs e)
		{
			this.Mode = 8;
			base.Close();
		}

		private void btDirectoryFIFO_Click(object sender, EventArgs e)
		{
			FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
			folderBrowserDialog.SelectedPath = Settings.Default.Curve_StoringFIFO_Directory;
			folderBrowserDialog.Description = this.Main.Rm.GetString("MbLocationForFIFO");
			if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
			{
				this.lbDirectoryFIFO.Text = folderBrowserDialog.SelectedPath;
				Settings.Default.Curve_StoringFIFO_Directory = folderBrowserDialog.SelectedPath;
				this.Main.CurveFifo.GetNewCurveInfo(this.lbDirectoryFIFO.Text);
				if (this.Main.CurveFifo.CurveFiles == null)
				{
					this.lbShowRemainedCurvesFIFO.Text = "0";
				}
				else
				{
					this.lbShowRemainedCurvesFIFO.Text = this.Main.CurveFifo.CurveFiles.Count().ToString();
				}
			}
		}

		private void btDirectory_Click(object sender, EventArgs e)
		{
			FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
			folderBrowserDialog.SelectedPath = Settings.Default._CurveAutoExportDefaultDirectory;
			folderBrowserDialog.Description = this.Main.Rm.GetString("MbLocationForFIFO");
			if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
			{
				this.lbTargetDirectory.Text = folderBrowserDialog.SelectedPath;
				Settings.Default._CurveAutoExportDefaultDirectory = folderBrowserDialog.SelectedPath;
			}
		}

		private void btDisplayAutoCurves_Click(object sender, EventArgs e)
		{
			if (this.chBFIFO_Buffer.Checked)
			{
				Settings.Default.Curve_StoringToFIFO_active = this.chBFIFO_Buffer.Checked;
				Settings.Default.Curve_StoringFIFO_Directory = this.lbDirectoryFIFO.Text;
				Settings.Default.CurvePrintType = this.cBResultKind.SelectedIndex;
				Settings.Default.Save();
				this.Mode = 9;
				base.Close();
			}
			else
			{
				this.Mode = 10;
				base.Close();
			}
		}

		private void hideControls(bool isFifoBuffer)
		{
			if (isFifoBuffer)
			{
				this.lbResultNumber.Text = this.Main.Rm.GetString("MaxNumber");
				this.gBCycleSave.Text = this.Main.Rm.GetString("FIFO_Buffer");
				this.btDirectoryFIFO.Visible = true;
				this.lbDirectoryFIFO.Visible = true;
				this.nEResultNumberFIFO.Visible = true;
				this.lbRemainedCurvesFIFO.Visible = true;
				this.lbShowRemainedCurvesFIFO.Visible = true;
				this.cBSaveFIFO.Visible = true;
				this.btCycleSave.Visible = false;
				this.btDeleteJob.Visible = false;
				this.lbTargetDirectory.Visible = false;
				this.lbRemainedCurves.Visible = false;
				this.btDirectory.Visible = false;
				this.cBSave.Visible = false;
			}
			else
			{
				this.lbResultNumber.Text = this.Main.Rm.GetString("CurveResultNumber");
				this.gBCycleSave.Text = this.Main.Rm.GetString("CycleSave");
				this.btDirectoryFIFO.Visible = false;
				this.lbDirectoryFIFO.Visible = false;
				this.nEResultNumberFIFO.Visible = false;
				this.lbRemainedCurvesFIFO.Visible = false;
				this.lbShowRemainedCurvesFIFO.Visible = false;
				this.cBSaveFIFO.Visible = false;
				this.btCycleSave.Visible = true;
				this.btDeleteJob.Visible = true;
				this.lbTargetDirectory.Visible = true;
				this.lbRemainedCurves.Visible = true;
				this.btDirectory.Visible = true;
				this.cBSave.Visible = true;
			}
		}

		private void chBFIFO_Buffer_CheckedChanged(object sender, EventArgs e)
		{
			if (!this.initializing)
			{
				this.hideControls(this.chBFIFO_Buffer.Checked);
				if (this.chBFIFO_Buffer.Checked && (Settings.Default.Curve_StoringFIFO_Directory.Length == 0 || !Directory.Exists(Settings.Default.Curve_StoringFIFO_Directory)))
				{
					this.btDirectoryFIFO_Click(null, EventArgs.Empty);
					if (!Directory.Exists(this.lbDirectoryFIFO.Text))
					{
						this.initializing = true;
						this.chBFIFO_Buffer.Checked = false;
						this.initializing = false;
					}
				}
				if (this.chBFIFO_Buffer.Checked && this.Main.CurveDisplay1.IsAutomaticCurveModeActive())
				{
					DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbActivatingFifoBuffer"), this.Main.Rm.GetString("FIFO_Buffer"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
					if (dialogResult == DialogResult.Yes)
					{
						this.Main.CurveDisplay1.ResetCycleSaveMode();
					}
					else
					{
						this.chBFIFO_Buffer.Checked = false;
					}
				}
			}
		}

		private void Start_Input(object sender, EventArgs e)
		{
			this.Main.TextInput(sender);
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			this.Main.TextInput(sender);
		}

		private void btDeleteJob_Click(object sender, EventArgs e)
		{
			this.Main.CurveDisplay1.ResetCycleSaveMode();
			this.lbShowRemainedCurves.Text = "0";
			this.MenEna(0);
		}

		private void bt_XML_Export_Click(object sender, EventArgs e)
		{
			this.Mode = 4;
			base.Close();
		}

		public void Cancel()
		{
			if (base.Visible)
			{
				this.Mode = 0;
				base.Close();
			}
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
		}

		private void CurvePrintForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			this.Main.SettingsChangedReset();
			if (this.Mode != 0)
			{
				this.CurvesToStore = int.Parse(this.nEResultNumber.Value.ToString());
				Settings.Default.CurrentSaveCurveNum = this.nEResultNumber.Value;
				Settings.Default.CurvePrintType = this.cBResultKind.SelectedIndex;
				Settings.Default.Save();
			}
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (msg.WParam.ToInt32() == 27)
			{
				base.Close();
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}

		private void cBResultKind_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

		private void cBResultKindFIFO_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

		private void btSave_Click_1(object sender, EventArgs e)
		{

		}

		private void btExport_Click_1(object sender, EventArgs e)
		{

		}

		private void bt_XML_Export_Click_1(object sender, EventArgs e)
		{

		}
	}
}
