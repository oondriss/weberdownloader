using EnterpriseDT.Net.Ftp;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows.Forms;

namespace Visualisation
{
	public class FtpClass
	{
		private const string FTP_LOGIN = "powerto";

		private const string FTP_PASSWORD = "the$people";

		private const string ftpProcessProg1 = "ProcessProg1.dat";

		private const string ftpProcessProg2 = "ProcessProg2.dat";

		private const string SpindleConst1 = "SpindleConst1.dat";

		private const string SpindleConst2 = "SpindleConst2.dat";

		private const string SysConst1 = "SysConst1.dat";

		private const string SysConst2 = "SysConst2.dat";

		private const string ID_Table = "ID_Table.csv";

		private const string PLC_Config = "PLC_Config.txt";

		private const string ID_Table_Backup = "ID_Table_Backup.csv";

		private const string PLC_Config_Backup = "PLC_Config_Backup.txt";

		private const string LogbookTXT = "Logbook.txt";

		private const string Logfile = "Logfile.txt";

		private const string LogfileCSV = "Logfile.csv";

		private const string Logfile_backup = "Logfile_Backup.txt";

		private const string NetConf = "NetConf.reg";

		private const string LogfileX = "Logfile*";

		private const string LogbookX = "Logbook*";

		private const string PLC_ConfigX = "PLC_Config*";

		private const string ID_TableX = "ID_Table*";

		private const string SysConstX = "SysConst*";

		private const string SpindleConstX = "SpindleConst*";

		private const string PProgXXX = "PProg*";

		private const string CompoXXX = "Compo*";

		private const string MaintXXX = "Maint*";

		private FTPConnection ftpConnection1;

		public string DefaultDirectory = "";

		public int NumberOfFiles = 100;

		private List<string> completeFileList = new List<string>(new string[10]
		{
			"PProg*",
			"SpindleConst*",
			"SysConst*",
			"Compo*",
			"Maint*",
			"ID_Table*",
			"PLC_Config*",
			"NetConf.reg",
			"Logbook*",
			"Logfile.csv"
		});

		private List<string> fileList = new List<string>(new string[10]
		{
			"PProg*",
			"SpindleConst*",
			"SysConst*",
			"Compo*",
			"Maint*",
			"ID_Table*",
			"PLC_Config*",
			"NetConf.reg",
			"Logbook*",
			"Logfile.csv"
		});

		private List<DirectoryClass> directoryList = new List<DirectoryClass>();

		private MainForm Main;

		private string currentlyProcessedFile = "";

		private WebClientTimeOut request;

		private FileStream fileOutput;

		private byte[] fileData;

		private bool downloadDataError;

		private List<string> upload_filenames;

		private ManualResetEvent wait;

		public List<string> CompleteFileList => this.completeFileList;

		public bool Halt
		{
			get;
			set;
		}

		public string CurrentlyProcessedFile => this.currentlyProcessedFile;

		public FtpClass(MainForm main)
		{
			this.ftpConnection1 = new FTPConnection();
			this.ftpConnection1.AutoLogin = true;
			this.ftpConnection1.ConnectMode = FTPConnectMode.PASV;
			this.ftpConnection1.DeleteOnFailure = true;
			this.ftpConnection1.EventsEnabled = true;
			this.ftpConnection1.ParsingCulture = new CultureInfo("");
			this.ftpConnection1.ServerAddress = null;
			this.ftpConnection1.ServerPort = 21;
			this.ftpConnection1.StrictReturnCodes = true;
			this.ftpConnection1.Timeout = 0;
			this.ftpConnection1.TransferBufferSize = 4096;
			this.ftpConnection1.TransferNotifyInterval = 4096L;
			this.ftpConnection1.TransferType = FTPTransferType.BINARY;
			this.ftpConnection1.UserName = "powerto";
			this.ftpConnection1.Password = "the$people";
			this.Main = main;
		}

		public int DownloadFilesFTP(string ipAddress, string stationName, bool bDirectoryForController)
		{
			int num = 0;
			string defaultDirectory = this.DefaultDirectory;
			string text = "/Param/";
			string ftpDirectory = "ftp://" + ipAddress + text;
			List<string> ftpDirectory2 = this.getFtpDirectory("powerto", "the$people", ftpDirectory);
			this.directoryToStructure(ftpDirectory2);
			this.NumberOfFiles = ftpDirectory2.Count + 12;
			if (bDirectoryForController && !Directory.Exists(defaultDirectory))
			{
				try
				{
					Directory.CreateDirectory(defaultDirectory);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
					return 0;
				}
			}
			try
			{
				foreach (DirectoryClass directory in this.directoryList)
				{
					this.Main.BeginInvoke(new MethodInvoker(this.Main.IncrementDownloadProgressBar));
					if (this.downloadFile(directory.Filename, stationName, ipAddress, text, defaultDirectory))
					{
						num++;
					}
				}
			}
			catch (Exception)
			{
			}
			text = "/Param/Maint/";
			ftpDirectory = "ftp://" + ipAddress + text;
			ftpDirectory2 = this.getFtpDirectory("powerto", "the$people", ftpDirectory);
			this.directoryToStructure(ftpDirectory2);
			this.NumberOfFiles += ftpDirectory2.Count;
			try
			{
				foreach (DirectoryClass directory2 in this.directoryList)
				{
					this.Main.BeginInvoke(new MethodInvoker(this.Main.IncrementDownloadProgressBar));
					if (this.downloadFile(directory2.Filename, stationName, ipAddress, text, defaultDirectory))
					{
						num++;
					}
				}
			}
			catch (Exception)
			{
			}
			text = "/3S/PLC/ProjectFiles/Appdata/";
			ftpDirectory = "ftp://" + ipAddress + text;
			this.Main.BeginInvoke(new MethodInvoker(this.Main.IncrementDownloadProgressBar));
			if (this.downloadFile("PLC_Config.txt", stationName, ipAddress, text, defaultDirectory))
			{
				num++;
			}
			this.Main.BeginInvoke(new MethodInvoker(this.Main.IncrementDownloadProgressBar));
			if (this.downloadFile("PLC_Config_Backup.txt", stationName, ipAddress, text, defaultDirectory))
			{
				num++;
			}
			this.Main.BeginInvoke(new MethodInvoker(this.Main.IncrementDownloadProgressBar));
			if (this.downloadFile("ID_Table.csv", stationName, ipAddress, text, defaultDirectory))
			{
				num++;
			}
			this.Main.BeginInvoke(new MethodInvoker(this.Main.IncrementDownloadProgressBar));
			if (this.downloadFile("ID_Table_Backup.csv", stationName, ipAddress, text, defaultDirectory))
			{
				num++;
			}
			this.Main.BeginInvoke(new MethodInvoker(this.Main.IncrementDownloadProgressBar));
			if (this.downloadFile("Logfile_Backup.txt", stationName, ipAddress, text, defaultDirectory))
			{
				num++;
			}
			this.Main.BeginInvoke(new MethodInvoker(this.Main.IncrementDownloadProgressBar));
			if (this.downloadFile("Logfile.txt", stationName, ipAddress, text, defaultDirectory))
			{
				num++;
			}
			text = "/Data/";
			ftpDirectory = "ftp://" + ipAddress + text;
			this.Main.BeginInvoke(new MethodInvoker(this.Main.IncrementDownloadProgressBar));
			if (this.downloadFile("Logbook.txt", stationName, ipAddress, text, defaultDirectory))
			{
				num++;
			}
			this.Main.BeginInvoke(new MethodInvoker(this.Main.IncrementDownloadProgressBar));
			if (this.downloadFile("Logfile.csv", stationName, ipAddress, text, defaultDirectory))
			{
				num++;
			}
			text = "/WINCE/";
			ftpDirectory = "ftp://" + ipAddress + text;
			this.Main.BeginInvoke(new MethodInvoker(this.Main.IncrementDownloadProgressBar));
			if (this.downloadFile("NetConf.reg", stationName, ipAddress, text, defaultDirectory))
			{
				num++;
			}
			this.Main.BeginInvoke(new MethodInvoker(this.Main.MaxDownloadProgressBar));
			return num;
		}

		private bool downloadFile(string _filename, string stationName, string ipAddress, string ftpfilepath, string inputfilepath)
		{
			while (this.Halt)
			{
				Thread.Sleep(100);
			}
			string text = text = "ftp://" + ipAddress + ftpfilepath;
			string str = "";
			bool result = false;
			for (int i = 0; i < 5; i++)
			{
				try
				{
					this.request = new WebClientTimeOut();
					this.request.Credentials = new NetworkCredential("powerto", "the$people");
					this.request.DownloadDataCompleted += delegate(object sender, DownloadDataCompletedEventArgs e)
					{
						try
						{
							this.fileData = new byte[e.Result.Length];
							Array.Copy(e.Result, this.fileData, e.Result.Length);
						}
						catch (Exception)
						{
							this.downloadDataError = true;
						}
					};
					this.currentlyProcessedFile = _filename;
					this.downloadDataError = false;
					this.fileData = null;
					this.request.DownloadDataAsync(new Uri(text + _filename));
					string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(_filename);
					string extension = Path.GetExtension(_filename);
					string text2 = inputfilepath + str;
					if (!text2.EndsWith("\\"))
					{
						text2 += "\\";
					}
					if (!Directory.Exists(text2))
					{
						Directory.CreateDirectory(text2);
					}
					text2 = text2 + fileNameWithoutExtension + extension;
					do
					{
						Thread.Sleep(50);
					}
					while ((this.fileData == null || this.fileData.Length == 0) && !this.downloadDataError);
					if (this.downloadDataError)
					{
						if (this.request != null)
						{
							this.request.Dispose();
						}
						if (this.fileOutput != null)
						{
							this.fileOutput.Close();
							this.fileOutput.Dispose();
							this.fileOutput = null;
						}
						result = false;
						goto end_IL_0033;
					}
					this.fileOutput = File.Create(text2);
					this.fileOutput.Write(this.fileData, 0, this.fileData.Length);
					this.fileOutput.Close();
					this.fileOutput.Dispose();
					this.fileOutput = null;
					Thread.Sleep(100);
					this.request.Dispose();
					this.request = null;
					return true;
					end_IL_0033:;
				}
				catch (Exception)
				{
					if (this.request != null)
					{
						this.request.Dispose();
					}
					if (this.fileOutput != null)
					{
						this.fileOutput.Close();
						this.fileOutput.Dispose();
						this.fileOutput = null;
					}
					result = false;
				}
			}
			return result;
		}

		public void Cancel()
		{
			if (this.request != null)
			{
				this.request.CancelAsync();
				this.request = null;
			}
		}

		public bool IsInFileList(string filename)
		{
			foreach (string file in this.fileList)
			{
				if (file.Contains("*") && file.IndexOf('*') == file.Length - 1)
				{
					return true;
				}
				if (file == filename)
				{
					return true;
				}
			}
			return false;
		}

		public bool IsInCompleteFileList(string filename, out string partitialFileName)
		{
			partitialFileName = "";
			if (filename == "Logfile.csv")
			{
				partitialFileName = "Logfile.csv";
			}
			foreach (string completeFile in this.completeFileList)
			{
				if (completeFile.Contains("*") && completeFile.IndexOf('*') == completeFile.Length - 1)
				{
					string text = completeFile.Remove(completeFile.IndexOf('*')).ToLower();
					if (filename.ToLower().StartsWith(text))
					{
						partitialFileName = text;
						return true;
					}
				}
				if (completeFile == filename)
				{
					partitialFileName = completeFile.ToLower();
					return true;
				}
			}
			return false;
		}

		public int UploadFilesToStation(List<string> filenames, string ipAddress, string stationName, bool bDirectoryForController)
		{
			int num = 0;
			this.upload_filenames = filenames;
			string defaultDirectory = this.DefaultDirectory;
			string str = "/Param/";
			string text = "ftp://" + ipAddress + str;
			this.NumberOfFiles = this.upload_filenames.Count + 1;
			if (bDirectoryForController && !Directory.Exists(defaultDirectory))
			{
				Directory.CreateDirectory(defaultDirectory);
			}
			try
			{
				foreach (string upload_filename in this.upload_filenames)
				{
					this.currentlyProcessedFile = Path.GetFileName(upload_filename);
					this.Main.BeginInvoke(new MethodInvoker(this.Main.IncrementDownloadProgressBar));
					if (this.uploadFileToStation(upload_filename, ipAddress))
					{
						num++;
					}
				}
			}
			catch (Exception)
			{
			}
			this.Main.BeginInvoke(new MethodInvoker(this.Main.MaxDownloadProgressBar));
			return num;
		}

		private bool uploadFileToStation(string fileName, string stationIP)
		{
			while (this.Halt)
			{
				Thread.Sleep(100);
			}
			try
			{
				new FileInfo(fileName);
				FtpState ftpState = new FtpState();
				string filepathForFile = this.getFilepathForFile(Path.GetFileName(fileName));
				string requestUriString = "ftp://" + stationIP + filepathForFile + Path.GetFileName(fileName);
				FtpWebRequest ftpWebRequest = (FtpWebRequest)WebRequest.Create(requestUriString);
				ftpWebRequest.Method = "STOR";
				ftpWebRequest.Credentials = new NetworkCredential("powerto", "the$people");
				ftpState.Request = ftpWebRequest;
				ftpState.FileName = fileName;
				ManualResetEvent operationComplete = ftpState.OperationComplete;
				ftpWebRequest.UseBinary = true;
				ftpWebRequest.KeepAlive = false;
				ftpWebRequest.Method = "STOR";
				FileInfo fileInfo = new FileInfo(fileName);
				ftpWebRequest.ContentLength = fileInfo.Length;
				ftpWebRequest.BeginGetRequestStream(FtpClass.EndGetStreamCallback, ftpState);
				operationComplete.WaitOne();
				if (ftpState.OperationException != null)
				{
					throw ftpState.OperationException;
				}
				Console.WriteLine("The operation completed - {0}", ftpState.StatusDescription);
				return true;
			}
			catch (Exception)
			{
				return false;
			}
		}

		private static void EndGetStreamCallback(IAsyncResult ar)
		{
			FtpState ftpState = (FtpState)ar.AsyncState;
			Stream stream = null;
			try
			{
				stream = ftpState.Request.EndGetRequestStream(ar);
				int num = 0;
				FileStream fileStream = File.OpenRead(ftpState.FileName);
				byte[] array = new byte[fileStream.Length];
				num = fileStream.Read(array, 0, array.Length);
				stream.Write(array, 0, num);
				stream.Close();
				ftpState.Request.BeginGetResponse(FtpClass.EndGetResponseCallback, ftpState);
			}
			catch (Exception operationException)
			{
				Console.WriteLine("Could not get the request stream.");
				ftpState.OperationException = operationException;
				ftpState.OperationComplete.Set();
			}
		}

		private static void EndGetResponseCallback(IAsyncResult ar)
		{
			FtpState ftpState = (FtpState)ar.AsyncState;
			FtpWebResponse ftpWebResponse = null;
			try
			{
				ftpWebResponse = (FtpWebResponse)ftpState.Request.EndGetResponse(ar);
				ftpWebResponse.Close();
				ftpState.StatusDescription = ftpWebResponse.StatusDescription;
				ftpState.OperationComplete.Set();
			}
			catch (Exception operationException)
			{
				Console.WriteLine("Error getting response.");
				ftpState.OperationException = operationException;
				ftpState.OperationComplete.Set();
			}
		}

		private bool filenameFits(string filename, string variableFilename)
		{
			bool result = true;
			bool flag = false;
			filename = filename.ToLower();
			variableFilename = variableFilename.ToLower();
			int num = 0;
			string text = filename;
			int num2 = 0;
			bool result2;
			while (true)
			{
				if (num2 < text.Length)
				{
					char c = text[num2];
					if (num >= variableFilename.Length)
					{
						return false;
					}
					if (flag)
					{
						if (c == variableFilename[num])
						{
							flag = false;
							num++;
						}
					}
					else if (c == variableFilename[num] || '?' == variableFilename[num])
					{
						num++;
					}
					else
					{
						if ('*' == variableFilename[num])
						{
							result2 = true;
							break;
						}
						if (c != variableFilename[num])
						{
							return false;
						}
					}
					num2++;
					continue;
				}
				return result;
			}
			return result2;
		}

		private string getFilepathForFile(string filename)
		{
			if (this.filenameFits(filename, "PProg*"))
			{
				return "/Param/";
			}
			if (this.filenameFits(filename, "Compo*"))
			{
				return "/Param/Maint/";
			}
			if (this.filenameFits(filename, "Maint*"))
			{
				return "/Param/";
			}
			switch (filename)
			{
			case "ProcessProg1.dat":
				return "/Param/";
			case "ProcessProg2.dat":
				return "/Param/";
			case "SpindleConst1.dat":
				return "/Param/";
			case "SpindleConst2.dat":
				return "/Param/";
			case "SysConst1.dat":
				return "/Param/";
			case "SysConst2.dat":
				return "/Param/";
			case "ID_Table.csv":
				return "/3S/PLC/ProjectFiles/Appdata/";
			case "PLC_Config.txt":
				return "/3S/PLC/ProjectFiles/Appdata/";
			case "ID_Table_Backup.csv":
				return "/3S/PLC/ProjectFiles/Appdata/";
			case "PLC_Config_Backup.txt":
				return "/3S/PLC/ProjectFiles/Appdata/";
			case "NetConf.reg":
				return "/WINCE/";
			case "Logfile.csv":
				return "/Data/";
			case "Logbook.txt":
				return "/Data/";
			default:
				return "";
			}
		}

		private bool directoryToStructure(List<string> directory)
		{
			bool result = true;
			this.directoryList.Clear();
			char[] separator = new char[1]
			{
				' '
			};
			for (int i = 0; i < directory.Count; i++)
			{
				string[] array = directory[i].Split(separator);
				if (array.Length == 4 && this.IsInFileList(array[3]))
				{
					DirectoryClass directoryClass = new DirectoryClass();
					try
					{
						directoryClass.Size = int.Parse(array[2]);
					}
					catch (Exception)
					{
						continue;
					}
					directoryClass.Filename = array[3];
					try
					{
						directoryClass.Date_Time = DateTime.Parse(array[0] + "_" + array[1]);
					}
					catch (Exception)
					{
						directoryClass.Date_Time = DateTime.Now;
						result = false;
					}
					array[1].Replace(":", "-");
					directoryClass.Date_Time_String = array[0] + "_" + array[1];
					this.directoryList.Add(directoryClass);
				}
			}
			return result;
		}

		private List<string> getFtpDirectory(string user, string password, string ftpDirectory)
		{
			List<string> list = new List<string>();
			for (int i = 0; i < 5; i++)
			{
				WebResponse webResponse = null;
				StreamReader streamReader = null;
				try
				{
					FtpWebRequest ftpWebRequest = (FtpWebRequest)WebRequest.Create(new Uri(ftpDirectory));
					ftpWebRequest.UseBinary = true;
					ftpWebRequest.Credentials = new NetworkCredential(user, password);
					ftpWebRequest.Method = "LIST";
					webResponse = ftpWebRequest.GetResponse();
					streamReader = new StreamReader(webResponse.GetResponseStream());
					for (string text = streamReader.ReadLine(); text != null; text = streamReader.ReadLine())
					{
						string a = "";
						while (a != text)
						{
							a = text;
							text = text.Replace("  ", " ");
						}
						list.Add(text);
					}
					streamReader.Close();
					webResponse.Close();
					return list;
				}
				catch (Exception)
				{
					streamReader?.Close();
					webResponse?.Close();
				}
			}
			return list;
		}
	}
}
