using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using WUSB_KeyVerwaltung;

namespace Visualisation
{
	public class USB_ChangePasswordForm : Form
	{
		public const int PASSWORD_CHANGED = 1;

		public const int USER_CANCELED = 3;

		public const int USER_OK = 2;

		public const int SYSTEM_ABORTED = 4;

		private IContainer components;

		private Label lbNewPassword;

		private Label lbRepeatPassword;

		private Button btCancel;

		private Button btLogin;

		private Label lbOldPassword;

		private NumberEdit1 nEOldPassword;

		private NumberEdit1 nENewPassword;

		private NumberEdit1 nERepeatPassword;

		private MainForm Main;

		private int lengthOfPassword;

		private string oldPasscode_Md5;

		private string newPassword;

		private int result = 3;

		public string NewPassword
		{
			get
			{
				this.newPassword = ((int)float.Parse(this.newPassword)).ToString("0000");
				return this.newPassword;
			}
		}

		public int Result => this.result;

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.lbNewPassword = new Label();
			this.lbRepeatPassword = new Label();
			this.btCancel = new Button();
			this.btLogin = new Button();
			this.lbOldPassword = new Label();
			this.nEOldPassword = new NumberEdit1();
			this.nENewPassword = new NumberEdit1();
			this.nERepeatPassword = new NumberEdit1();
			base.SuspendLayout();
			this.lbNewPassword.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbNewPassword.Location = new Point(15, 80);
			this.lbNewPassword.Name = "lbNewPassword";
			this.lbNewPassword.Size = new Size(140, 23);
			this.lbNewPassword.TabIndex = 7;
			this.lbNewPassword.Text = "Neues Kennwort";
			this.lbNewPassword.TextAlign = ContentAlignment.MiddleLeft;
			this.lbRepeatPassword.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbRepeatPassword.Location = new Point(15, 125);
			this.lbRepeatPassword.Name = "lbRepeatPassword";
			this.lbRepeatPassword.Size = new Size(140, 23);
			this.lbRepeatPassword.TabIndex = 9;
			this.lbRepeatPassword.Text = "Wiederholen";
			this.lbRepeatPassword.TextAlign = ContentAlignment.MiddleLeft;
			this.btCancel.Location = new Point(163, 170);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(112, 56);
			this.btCancel.TabIndex = 4;
			this.btCancel.Text = "Abbrechen";
			this.btCancel.Click += this.btCancel_Click;
			this.btLogin.Location = new Point(23, 170);
			this.btLogin.Name = "btLogin";
			this.btLogin.Size = new Size(112, 56);
			this.btLogin.TabIndex = 3;
			this.btLogin.Text = "Enter";
			this.btLogin.Click += this.btLogin_Click;
			this.lbOldPassword.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbOldPassword.Location = new Point(15, 35);
			this.lbOldPassword.Name = "lbOldPassword";
			this.lbOldPassword.Size = new Size(140, 23);
			this.lbOldPassword.TabIndex = 17;
			this.lbOldPassword.Text = "Altes Kennwort";
			this.lbOldPassword.TextAlign = ContentAlignment.MiddleLeft;
			this.nEOldPassword.BackColor = Color.White;
			this.nEOldPassword.DecimalNum = 0;
			this.nEOldPassword.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEOldPassword.ForeColor = SystemColors.ControlText;
			this.nEOldPassword.Location = new Point(163, 32);
			this.nEOldPassword.MaxValue = 9999f;
			this.nEOldPassword.MinValue = 0f;
			this.nEOldPassword.Name = "nEOldPassword";
			this.nEOldPassword.PasswordChar = '*';
			this.nEOldPassword.Size = new Size(120, 28);
			this.nEOldPassword.TabIndex = 18;
			this.nEOldPassword.Text = "0";
			this.nEOldPassword.TextAlign = HorizontalAlignment.Right;
			this.nEOldPassword.Value = 0f;
			this.nEOldPassword.Enter += this.StartInput;
			this.nEOldPassword.MouseDown += this.StartInput;
			this.nENewPassword.BackColor = Color.White;
			this.nENewPassword.DecimalNum = 0;
			this.nENewPassword.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nENewPassword.ForeColor = SystemColors.ControlText;
			this.nENewPassword.Location = new Point(161, 77);
			this.nENewPassword.MaxValue = 9999f;
			this.nENewPassword.MinValue = 0f;
			this.nENewPassword.Name = "nENewPassword";
			this.nENewPassword.PasswordChar = '*';
			this.nENewPassword.Size = new Size(120, 28);
			this.nENewPassword.TabIndex = 19;
			this.nENewPassword.Text = "0";
			this.nENewPassword.TextAlign = HorizontalAlignment.Right;
			this.nENewPassword.Value = 0f;
			this.nENewPassword.Enter += this.StartInput;
			this.nENewPassword.MouseDown += this.StartInput;
			this.nERepeatPassword.BackColor = Color.White;
			this.nERepeatPassword.DecimalNum = 0;
			this.nERepeatPassword.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nERepeatPassword.ForeColor = SystemColors.ControlText;
			this.nERepeatPassword.Location = new Point(161, 125);
			this.nERepeatPassword.MaxValue = 9999f;
			this.nERepeatPassword.MinValue = 0f;
			this.nERepeatPassword.Name = "nERepeatPassword";
			this.nERepeatPassword.PasswordChar = '*';
			this.nERepeatPassword.Size = new Size(120, 28);
			this.nERepeatPassword.TabIndex = 20;
			this.nERepeatPassword.Text = "0";
			this.nERepeatPassword.TextAlign = HorizontalAlignment.Right;
			this.nERepeatPassword.Value = 0f;
			this.nERepeatPassword.Enter += this.StartInput;
			this.nERepeatPassword.MouseDown += this.StartInput;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(306, 237);
			base.Controls.Add(this.nERepeatPassword);
			base.Controls.Add(this.nENewPassword);
			base.Controls.Add(this.nEOldPassword);
			base.Controls.Add(this.lbOldPassword);
			base.Controls.Add(this.btCancel);
			base.Controls.Add(this.btLogin);
			base.Controls.Add(this.lbRepeatPassword);
			base.Controls.Add(this.lbNewPassword);
			base.FormBorderStyle = FormBorderStyle.FixedSingle;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "USB_ChangePasswordForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.CenterParent;
			this.Text = "USB_ChangePasswordForm";
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public USB_ChangePasswordForm(MainForm _Main, int _lengthOfPassword, string _oldPasscode_Md5)
		{
			this.oldPasscode_Md5 = _oldPasscode_Md5;
			this.lengthOfPassword = _lengthOfPassword;
			this.Main = _Main;
			this.InitializeComponent();
			this.SetLanguageTexts();
			this.nENewPassword.Text = "";
			this.nEOldPassword.Text = "";
			this.nERepeatPassword.Text = "";
		}

		private void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("ChangePassCode");
			this.btCancel.Text = this.Main.Rm.GetString("Cancel");
			this.btLogin.Text = this.Main.Rm.GetString("btApply");
			this.lbOldPassword.Text = this.Main.Rm.GetString("OldPassCode");
			this.lbNewPassword.Text = this.Main.Rm.GetString("ChangePassCode");
			this.lbRepeatPassword.Text = this.Main.Rm.GetString("RepeatPassCode");
		}

		private void USB_PasswordForm_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == '\r')
			{
				this.btLogin_Click(null, EventArgs.Empty);
			}
		}

		private void btLogin_Click(object sender, EventArgs e)
		{
			if (MD5HashClass.MD5Hash(this.nEOldPassword.Value.ToString("0000")) != this.oldPasscode_Md5)
			{
				MessageBox.Show(this, this.Main.Rm.GetString("MbOldPasswordWrong"), this.Main.Rm.GetString("Password"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else if (this.Main.NumberPadCharacters != this.lengthOfPassword)
			{
				MessageBox.Show(this, this.Main.Rm.GetString("MbPasswordWrongLength") + " " + this.lengthOfPassword.ToString(), this.Main.Rm.GetString("Password"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else if (this.nENewPassword.Text != this.nERepeatPassword.Text)
			{
				MessageBox.Show(this, this.Main.Rm.GetString("MbPasswordsNotEqual"), this.Main.Rm.GetString("Password"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else
			{
				this.newPassword = this.nENewPassword.Text;
				this.result = 1;
				base.Close();
			}
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.result = 3;
			base.Close();
		}

		public void Cancel()
		{
			this.result = 4;
			base.Close();
		}

		private void Start_Input(object sender, EventArgs e)
		{
			this.Main.TextInput(sender);
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			this.Main.TextInput(sender);
			NumberEdit1 numberEdit = sender as NumberEdit1;
			numberEdit.Text = numberEdit.Value.ToString("0000");
		}

		private void StartInput(object sender, EventArgs e)
		{
		}
	}
}
