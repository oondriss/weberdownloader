using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class LogBookForm : Form
	{
		private MainForm Main;

		private int PrintPos;

		private DataTable LogData;

		private DataGridTableStyle Ts;

		private string[] ColumnName;

		private DataGrid_Specific_Class LogGrid;

		private Panel pnMenu;

		private Button btBack;

		private Button btTopTen;

		private Button btHelp;

		private Button btLoad;

		private Button bt3;

		private Button btPrint;

		private PrintDocument printDocument;

		private PrintDialog printDialog;

		private Button btExport;

		private SaveFileDialog SFD;

		private Label label1;

		private Button btBrowser;

		private Container components;

		private bool fistTimeInitialiseationDone;

		public LogBookForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.LogGrid = new DataGrid_Specific_Class(1, base.Controls);
			this.PrintPos = 0;
			this.LogData = new DataTable("LogBook");
			this.ColumnName = new string[6];
			this.ColumnName[0] = "Number";
			this.ColumnName[1] = "Date";
			this.ColumnName[2] = "Message";
			this.ColumnName[3] = "ErrorCode";
			this.ColumnName[4] = "Kind";
			this.ColumnName[5] = "Cycle";
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[0], typeof(int)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[1], typeof(string)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[2], typeof(string)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[3], typeof(uint)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[4], typeof(string)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[5], typeof(uint)));
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btBrowser = new Button();
			this.btPrint = new Button();
			this.btExport = new Button();
			this.btLoad = new Button();
			this.bt3 = new Button();
			this.btTopTen = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.printDocument = new PrintDocument();
			this.printDialog = new PrintDialog();
			this.SFD = new SaveFileDialog();
			this.label1 = new Label();
			this.pnMenu.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btBrowser);
			this.pnMenu.Controls.Add(this.btPrint);
			this.pnMenu.Controls.Add(this.btExport);
			this.pnMenu.Controls.Add(this.btLoad);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.btTopTen);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btBrowser.Enabled = false;
			this.btBrowser.Location = new Point(3, 323);
			this.btBrowser.Name = "btBrowser";
			this.btBrowser.Size = new Size(74, 62);
			this.btBrowser.TabIndex = 11;
			this.btBrowser.Click += this.btBrowser_Click;
			this.btPrint.Location = new Point(3, 451);
			this.btPrint.Name = "btPrint";
			this.btPrint.Size = new Size(74, 62);
			this.btPrint.TabIndex = 7;
			this.btPrint.Text = "Print";
			this.btPrint.Click += this.btPrint_Click;
			this.btExport.Location = new Point(3, 387);
			this.btExport.Name = "btExport";
			this.btExport.Size = new Size(74, 62);
			this.btExport.TabIndex = 6;
			this.btExport.Text = "Export";
			this.btExport.Click += this.btExport_Click;
			this.btLoad.Location = new Point(3, 195);
			this.btLoad.Name = "btLoad";
			this.btLoad.Size = new Size(74, 62);
			this.btLoad.TabIndex = 5;
			this.btLoad.Text = "Load again";
			this.btLoad.Click += this.btLoad_Click;
			this.bt3.Enabled = false;
			this.bt3.Location = new Point(3, 259);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 4;
			this.btTopTen.Location = new Point(3, 131);
			this.btTopTen.Name = "btTopTen";
			this.btTopTen.Size = new Size(74, 62);
			this.btTopTen.TabIndex = 2;
			this.btTopTen.Text = "Top Ten";
			this.btTopTen.Click += this.btTopTen_Click;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.printDocument.PrintPage += this.printDocument_PrintPage;
			this.printDialog.Document = this.printDocument;
			this.SFD.Filter = "Error Files|*.txt|All Files|*.*";
			this.label1.AutoSize = true;
			this.label1.Location = new Point(12, 259);
			this.label1.Name = "label1";
			this.label1.Size = new Size(655, 15);
			this.label1.TabIndex = 2;
			this.label1.Text = "DataGrid LogGrid will not be displayed in Editor due to introduction of derived class DataGrid_Specific_Class (DataGrid defined there!)";
			this.label1.Visible = false;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.label1);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.Name = "LogBookForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Auswertung/FehlerLogbuch";
			base.Activated += this.LogBookForm_Activated;
			this.pnMenu.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public bool ShowWindow()
		{
			this.Main.ActivationBrowserGrantedBy = this;
			if (!this.Main.IsOnlineMode)
			{
				base.Show();
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadLogBookData"));
			if (!this.Main.VC.ReceiveVarBlock(86))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive LogBookSysBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("WriteLogBookTable"));
			this.makeDataSet();
			base.Show();
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuAnalysis") + "/" + this.Main.Rm.GetString("ErrorLog");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btPrint.Text = this.Main.Rm.GetString("Print");
			this.btExport.Text = this.Main.Rm.GetString("ExportLogbook");
			this.printDocument.DocumentName = this.Main.Rm.GetString("ErrorLog_");
			this.btTopTen.Text = this.Main.Rm.GetString("TopTen");
			this.btLoad.Text = this.Main.Rm.GetString("btLoad");
			this.SFD.Filter = this.Main.Rm.GetString("ErrorLog") + "|*.txt|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
		}

		public int Count(bool requestController)
		{
			if (!this.Main.IsOnlineMode)
			{
				return 0;
			}
			if (requestController)
			{
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadLogBookData"));
				if (!this.Main.VC.ReceiveVarBlock(86))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not receive LogBookSysBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return 0;
				}
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
			}
			uint position = this.Main.VC.PlcLogBookSys.Position;
			uint length = this.Main.VC.PlcLogBookSys.Length;
			int num = (int)(this.Main.VC.PlcLogBookSys.Position - 1);
			int num2 = 0;
			for (int i = 0; i < this.Main.VC.PlcLogBookSys.Length; i++)
			{
				if (num < 0)
				{
					num = 2499;
				}
				WSP1_VarComm.PlcLogMessageStruct plcLogMessageStruct = this.Main.VC.PlcLogBookSys.plcLogMessBuffer[num];
				if (plcLogMessageStruct.Type != 16 && plcLogMessageStruct.Type != 18)
				{
					num--;
				}
				else if (plcLogMessageStruct.Type == 19)
				{
					num--;
				}
				else
				{
					num--;
					num2++;
				}
			}
			return num2;
		}

		private void makeDataSet()
		{
			string empty = string.Empty;
			string empty2 = string.Empty;
			string empty3 = string.Empty;
			int num = this.ColumnName.Length;
			int[] array = new int[num];
			for (int i = 0; i < num; i++)
			{
				array[i] = 0;
			}
			this.LogData.Clear();
			Graphics graphics = this.LogGrid.CreateGraphics();
			uint position = this.Main.VC.PlcLogBookSys.Position;
			uint length = this.Main.VC.PlcLogBookSys.Length;
			int num2 = (int)(this.Main.VC.PlcLogBookSys.Position - 1);
			int num3 = 0;
			for (int i = 0; i < this.Main.VC.PlcLogBookSys.Length; i++)
			{
				if (num2 < 0)
				{
					num2 = 3999;
				}
				WSP1_VarComm.PlcLogMessageStruct plcLogMessageStruct = this.Main.VC.PlcLogBookSys.plcLogMessBuffer[num2];
				DataRow row = this.LogData.NewRow();
				this.LogData.Rows.Add(row);
				this.LogData.Rows[num3][this.ColumnName[0]] = num3 + 1;
				string text = "A" + this.LogData.Rows[num3][this.ColumnName[0]].ToString();
				int num4 = (int)Math.Ceiling((double)graphics.MeasureString(text, this.LogGrid.Font).Width);
				if (num4 > array[0])
				{
					array[0] = num4;
				}
				DateTime dateTime;
				try
				{
					dateTime = new DateTime(plcLogMessageStruct.Time.Year, plcLogMessageStruct.Time.Month, plcLogMessageStruct.Time.Day, plcLogMessageStruct.Time.Hour, plcLogMessageStruct.Time.Minute, plcLogMessageStruct.Time.Second);
				}
				catch
				{
					dateTime = new DateTime(1, 1, 1, 0, 0, 0);
				}
				string text2 = dateTime.ToString(Settings.Default.TimeSet);
				this.LogData.Rows[num3][this.ColumnName[1]] = text2;
				text = "AA" + text2;
				num4 = (int)Math.Ceiling((double)graphics.MeasureString(text, this.LogGrid.Font).Width);
				if (num4 > array[1])
				{
					array[1] = num4;
				}
				switch (plcLogMessageStruct.Type)
				{
				case 16:
				case 17:
				case 18:
					text = this.Main.GetVisuError(plcLogMessageStruct.Code);
					break;
				case 19:
					text = this.Main.Rm.GetString("LogBookMessage100000");
					break;
				default:
					text = string.Empty;
					break;
				}
				this.LogData.Rows[num3][this.ColumnName[2]] = text;
				num4 = (int)Math.Ceiling((double)graphics.MeasureString(text + "AAAAA", this.LogGrid.Font).Width);
				if (num4 > array[2])
				{
					array[2] = num4;
				}
				this.LogData.Rows[num3][this.ColumnName[3]] = plcLogMessageStruct.Code;
				num4 = (int)Math.Ceiling((double)graphics.MeasureString(this.LogData.Rows[num3][this.ColumnName[3]].ToString() + "A", this.LogGrid.Font).Width);
				if (num4 > array[3])
				{
					array[3] = num4;
				}
				string text3 = "";
				text3 = ((plcLogMessageStruct.Type != 16) ? ((plcLogMessageStruct.Type != 17) ? ((plcLogMessageStruct.Type != 19) ? this.Main.Rm.GetString("Occured") : "") : this.Main.Rm.GetString("Acknowledged")) : this.Main.Rm.GetString("Occured"));
				this.LogData.Rows[num3][this.ColumnName[4]] = text3;
				text = "A" + this.LogData.Rows[num3]["Kind"].ToString();
				num4 = (int)Math.Ceiling((double)graphics.MeasureString(text, this.LogGrid.Font).Width);
				if (num4 > array[4])
				{
					array[4] = num4;
				}
				this.LogData.Rows[num3][this.ColumnName[5]] = plcLogMessageStruct.cycNum;
				text = "A" + this.LogData.Rows[num3]["Cycle"].ToString();
				num4 = (int)Math.Ceiling((double)graphics.MeasureString(text, this.LogGrid.Font).Width);
				if (num4 > array[5])
				{
					array[5] = num4;
				}
				num2--;
				num3++;
			}
			this.LogGrid.DataSource = this.LogData;
			this.LogGrid.Columns[0].HeaderText = this.Main.Rm.GetString("AbrNumber");
			this.LogGrid.Columns[1].HeaderText = this.Main.Rm.GetString("DateTime");
			this.LogGrid.Columns[2].HeaderText = this.Main.Rm.GetString("Message");
			this.LogGrid.Columns[3].HeaderText = this.Main.Rm.GetString("ErrorCode");
			this.LogGrid.Columns[4].HeaderText = this.Main.Rm.GetString("Kind");
			this.LogGrid.Columns[5].HeaderText = this.Main.Rm.GetString("Cycle");
			this.LogGrid.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
			if (!this.fistTimeInitialiseationDone)
			{
				for (int i = 0; i < num; i++)
				{
					if (i == 2)
					{
						array[i] = 400;
					}
					else
					{
						int num4 = (int)Math.Ceiling((double)graphics.MeasureString(this.LogGrid.Columns[i].HeaderText + new string('a', 1), this.LogGrid.Font).Width);
						if (num4 > array[i])
						{
							array[i] = num4;
						}
					}
					this.LogGrid.Columns[i].Width = array[i];
				}
			}
			this.fistTimeInitialiseationDone = true;
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_2_5_Fehler_Liste";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_2_5_Fehler_Liste");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void LogBookForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void btPrint_Click(object sender, EventArgs e)
		{
			if (this.printDialog.ShowDialog() == DialogResult.OK)
			{
				this.printDocument.DefaultPageSettings.Margins.Bottom = 50;
				this.printDocument.DefaultPageSettings.Margins.Left = 50;
				this.printDocument.DefaultPageSettings.Margins.Right = 50;
				this.printDocument.DefaultPageSettings.Margins.Top = 50;
				this.printDocument.Print();
			}
		}

		private void printDocument_PrintPage(object sender, PrintPageEventArgs e)
		{
			float num = 0f;
			float num2 = 0f;
			float num3 = 0f;
			float num4 = 0f;
			int count = this.LogData.Columns.Count;
			float[] array = new float[count + 1];
			string empty = string.Empty;
			DateTime now = DateTime.Now;
			Graphics graphics = e.Graphics;
			float num5 = (float)e.MarginBounds.Left;
			float x = (float)e.MarginBounds.Right;
			float num6 = (float)e.MarginBounds.Bottom;
			float num7 = (float)e.MarginBounds.Top;
			Font font = new Font("Arial", 11f, FontStyle.Bold);
			Pen pen = new Pen(Brushes.Black);
			for (int i = 0; i < count; i++)
			{
				array[i] = (float)this.LogGrid.Columns[i].Width;
				num += array[i];
			}
			num3 = (float)e.MarginBounds.Width / num;
			Font font2 = new Font("Arial Unicode MS", 11f * num3, GraphicsUnit.Pixel);
			num = num5;
			for (int i = 0; i <= count; i++)
			{
				num4 = num;
				num += array[i] * num3;
				array[i] = num4;
			}
			num2 = num7;
			if (this.PrintPos <= 0)
			{
				empty = this.Main.Rm.GetString("ErrorLog_") + " (" + now.ToString(Settings.Default.TimeSet) + "):";
				graphics.DrawString(empty, font, Brushes.Black, new RectangleF((float)e.MarginBounds.Left, num2, (float)e.MarginBounds.Width, (float)e.MarginBounds.Bottom - num2));
				num2 += font.GetHeight();
				this.PrintPos = -1;
			}
			num7 = num2;
			num = num5;
			graphics.DrawLine(pen, num5, num2, x, num2);
			for (int i = this.PrintPos; i < this.LogData.Rows.Count; i++)
			{
				if (i == -1)
				{
					for (int j = 0; j < count; j++)
					{
						string headerText = this.LogGrid.Columns[j].HeaderText;
						graphics.DrawString(headerText, font2, Brushes.Black, array[j], num2);
					}
				}
				else
				{
					for (int j = 0; j < count; j++)
					{
						string headerText = this.LogData.Rows[i][this.ColumnName[j]].ToString();
						SizeF sizeF = default(SizeF);
						sizeF = graphics.MeasureString(headerText, font2);
						if (j == 2 && (double)array[j] < (double)sizeF.Width * 0.43)
						{
							string[] array2 = headerText.Split(' ');
							string text = "";
							string[] array3 = array2;
							foreach (string str in array3)
							{
								if ((double)array[j] < (double)graphics.MeasureString(text + str, font2).Width * 0.43)
								{
									graphics.DrawString(text, font2, Brushes.Black, array[j], num2);
									text = "";
									num2 += font2.GetHeight();
								}
								text = text + str + " ";
							}
							graphics.DrawString(text, font2, Brushes.Black, array[j], num2);
						}
						else
						{
							graphics.DrawString(headerText, font2, Brushes.Black, array[j], num2);
						}
					}
				}
				num2 += font2.GetHeight();
				graphics.DrawLine(pen, num5, num2, x, num2);
				if (num2 > num6)
				{
					if (this.LogData.Rows.Count - i > 1)
					{
						this.PrintPos = i + 1;
					}
					break;
				}
				this.PrintPos = 0;
			}
			graphics.DrawLine(pen, num, num7, num, num2);
			for (int i = 0; i <= count; i++)
			{
				graphics.DrawLine(pen, array[i], num7, array[i], num2);
			}
			font2.Dispose();
			font.Dispose();
			if (this.PrintPos > 0)
			{
				e.HasMorePages = true;
			}
		}

		private void btExport_Click(object sender, EventArgs e)
		{
			string empty = string.Empty;
			CultureInfo invariantCulture = CultureInfo.InvariantCulture;
			DialogResult dialogResult = this.SFD.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				try
				{
					StreamWriter streamWriter = new StreamWriter(this.SFD.FileName);
					empty = this.LogGrid.Columns[0].HeaderText;
					for (int i = 1; i < this.ColumnName.GetLength(0); i++)
					{
						empty = empty + ";" + this.LogGrid.Columns[i].HeaderText;
					}
					streamWriter.WriteLine(empty);
					for (int j = 0; j < this.LogData.Rows.Count; j++)
					{
						empty = this.LogData.Rows[j][0].ToString();
						for (int i = 1; i < this.ColumnName.GetLength(0); i++)
						{
							empty = empty + ";" + this.LogData.Rows[j][i].ToString();
						}
						streamWriter.WriteLine(empty);
					}
					streamWriter.Close();
					streamWriter.Dispose();
				}
				catch (Exception ex)
				{
					MessageBox.Show("Could not open file! " + ex.Message, "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btTopTen_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.TopTen1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void btLoad_Click(object sender, EventArgs e)
		{
			if (this.Main.IsOnlineMode)
			{
				if (!this.Main.VC.ReceiveVarBlock(86))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not receive PLC LogBookSysBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.makeDataSet();
				}
			}
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}
	}
}
