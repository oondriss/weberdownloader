using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;
using WSPKurve;

namespace Visualisation
{
	public class VisualisationParamForm : Form
	{
		private MainForm Main;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private RadioButton rBen;

		private RadioButton rBde;

		private RadioButton rBfr;

		private RadioButton rBit;

		private RadioButton rBes;

		private CheckBox chBKeyboard;

		private GroupBox gBTimeSet;

		private RadioButton rBTimeEuropean;

		private RadioButton rBTimeUS;

		private Button btCancel;

		private GroupBox gBlang;

		private Button bt4;

		private Button bt5;

		private Button bt1;

		private Button bt2;

		private Button bt3;

		private RadioButton rBcz;

		private NumberEdit1 nEMaxSaveCurveNum;

		private Label lbMaxSaveCurveNum;

		private CheckBox chBIntegratedMachineVisu;

		private CheckBox chBIntegratedHelp;

		private RadioButton rBhu;

		private RadioButton rBsk;

		private Container components;

		private bool initInProgress = true;

		private CheckBox chBUsbKeyActivated;

		private Label lbMasterPassword1;

		private Label lbMasterPassword2;

		private Label lbMasterPassword3;

		private NumberEdit1 nEMaxFifoBuffer;

		private Label lbMaxFifoBuffer;

		private CheckBox chBDisplayStepsInCurves;

		private bool masterPassword1;

		private bool masterPassword2;

		private bool masterPassword3;

		private byte recentPasscodeLevel;

		private string recentActualUser = "";

		public VisualisationParamForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btCancel = new Button();
			this.bt4 = new Button();
			this.btHelp = new Button();
			this.bt5 = new Button();
			this.bt1 = new Button();
			this.btBack = new Button();
			this.bt2 = new Button();
			this.bt3 = new Button();
			this.gBlang = new GroupBox();
			this.rBhu = new RadioButton();
			this.rBsk = new RadioButton();
			this.rBcz = new RadioButton();
			this.rBes = new RadioButton();
			this.rBit = new RadioButton();
			this.rBfr = new RadioButton();
			this.rBde = new RadioButton();
			this.rBen = new RadioButton();
			this.chBKeyboard = new CheckBox();
			this.gBTimeSet = new GroupBox();
			this.rBTimeUS = new RadioButton();
			this.rBTimeEuropean = new RadioButton();
			this.lbMaxSaveCurveNum = new Label();
			this.nEMaxSaveCurveNum = new NumberEdit1();
			this.chBIntegratedMachineVisu = new CheckBox();
			this.chBIntegratedHelp = new CheckBox();
			this.chBDisplayStepsInCurves = new CheckBox();
			this.chBUsbKeyActivated = new CheckBox();
			this.lbMasterPassword1 = new Label();
			this.lbMasterPassword2 = new Label();
			this.lbMasterPassword3 = new Label();
			this.nEMaxFifoBuffer = new NumberEdit1();
			this.lbMaxFifoBuffer = new Label();
			this.pnMenu.SuspendLayout();
			this.gBlang.SuspendLayout();
			this.gBTimeSet.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.bt4);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.bt5);
			this.pnMenu.Controls.Add(this.bt1);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 2;
			this.btCancel.Text = "Abbruch";
			this.btCancel.Click += this.btCancel_Click;
			this.bt4.Enabled = false;
			this.bt4.Location = new Point(3, 323);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(74, 62);
			this.bt4.TabIndex = 6;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.bt5.Enabled = false;
			this.bt5.Location = new Point(3, 387);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(74, 62);
			this.bt5.TabIndex = 7;
			this.bt1.Enabled = false;
			this.bt1.Location = new Point(3, 131);
			this.bt1.Name = "bt1";
			this.bt1.Size = new Size(74, 62);
			this.bt1.TabIndex = 3;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Speichern + Zurück";
			this.btBack.Click += this.btBack_Click;
			this.bt2.Enabled = false;
			this.bt2.Location = new Point(3, 195);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 4;
			this.bt3.Enabled = false;
			this.bt3.Location = new Point(3, 259);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 5;
			this.gBlang.Controls.Add(this.rBhu);
			this.gBlang.Controls.Add(this.rBsk);
			this.gBlang.Controls.Add(this.rBcz);
			this.gBlang.Controls.Add(this.rBes);
			this.gBlang.Controls.Add(this.rBit);
			this.gBlang.Controls.Add(this.rBfr);
			this.gBlang.Controls.Add(this.rBde);
			this.gBlang.Controls.Add(this.rBen);
			this.gBlang.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBlang.Location = new Point(64, 56);
			this.gBlang.Name = "gBlang";
			this.gBlang.Size = new Size(168, 357);
			this.gBlang.TabIndex = 1;
			this.gBlang.TabStop = false;
			this.gBlang.Text = "Sprache";
			this.rBhu.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.rBhu.Location = new Point(16, 272);
			this.rBhu.Name = "rBhu";
			this.rBhu.Size = new Size(136, 24);
			this.rBhu.TabIndex = 7;
			this.rBhu.Text = "Ungarisch";
			this.rBhu.CheckedChanged += this.settingsChanged;
			this.rBsk.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.rBsk.Location = new Point(16, 232);
			this.rBsk.Name = "rBsk";
			this.rBsk.Size = new Size(136, 24);
			this.rBsk.TabIndex = 6;
			this.rBsk.Text = "Slowakisch";
			this.rBsk.CheckedChanged += this.settingsChanged;
			this.rBcz.Enabled = false;
			this.rBcz.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.rBcz.Location = new Point(16, 192);
			this.rBcz.Name = "rBcz";
			this.rBcz.Size = new Size(136, 24);
			this.rBcz.TabIndex = 5;
			this.rBcz.Text = "Tschechisch";
			this.rBcz.CheckedChanged += this.settingsChanged;
			this.rBes.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.rBes.Location = new Point(16, 314);
			this.rBes.Name = "rBes";
			this.rBes.Size = new Size(136, 24);
			this.rBes.TabIndex = 4;
			this.rBes.Text = "Spanisch";
			this.rBes.CheckedChanged += this.settingsChanged;
			this.rBit.Enabled = false;
			this.rBit.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.rBit.Location = new Point(16, 152);
			this.rBit.Name = "rBit";
			this.rBit.Size = new Size(136, 24);
			this.rBit.TabIndex = 3;
			this.rBit.Text = "Italienisch";
			this.rBit.CheckedChanged += this.settingsChanged;
			this.rBfr.Enabled = false;
			this.rBfr.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.rBfr.Location = new Point(16, 112);
			this.rBfr.Name = "rBfr";
			this.rBfr.Size = new Size(136, 24);
			this.rBfr.TabIndex = 2;
			this.rBfr.Text = "Französisch";
			this.rBfr.CheckedChanged += this.settingsChanged;
			this.rBde.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.rBde.Location = new Point(16, 72);
			this.rBde.Name = "rBde";
			this.rBde.Size = new Size(136, 24);
			this.rBde.TabIndex = 1;
			this.rBde.Text = "Deutsch";
			this.rBde.CheckedChanged += this.settingsChanged;
			this.rBen.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.rBen.Location = new Point(16, 32);
			this.rBen.Name = "rBen";
			this.rBen.Size = new Size(136, 24);
			this.rBen.TabIndex = 0;
			this.rBen.Text = "Englisch";
			this.rBen.CheckedChanged += this.settingsChanged;
			this.chBKeyboard.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBKeyboard.Location = new Point(296, 57);
			this.chBKeyboard.Name = "chBKeyboard";
			this.chBKeyboard.Size = new Size(352, 24);
			this.chBKeyboard.TabIndex = 2;
			this.chBKeyboard.Text = "Virtuelles Keyboard verwenden";
			this.chBKeyboard.CheckedChanged += this.settingsChanged;
			this.gBTimeSet.Controls.Add(this.rBTimeUS);
			this.gBTimeSet.Controls.Add(this.rBTimeEuropean);
			this.gBTimeSet.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBTimeSet.Location = new Point(288, 206);
			this.gBTimeSet.Name = "gBTimeSet";
			this.gBTimeSet.Size = new Size(376, 120);
			this.gBTimeSet.TabIndex = 3;
			this.gBTimeSet.TabStop = false;
			this.gBTimeSet.Text = "Datums- und Zeitanzeige";
			this.rBTimeUS.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.rBTimeUS.Location = new Point(16, 72);
			this.rBTimeUS.Name = "rBTimeUS";
			this.rBTimeUS.Size = new Size(344, 24);
			this.rBTimeUS.TabIndex = 1;
			this.rBTimeUS.Text = "USA (12/24/2000 23:59:59)";
			this.rBTimeUS.CheckedChanged += this.settingsChanged;
			this.rBTimeEuropean.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.rBTimeEuropean.Location = new Point(16, 32);
			this.rBTimeEuropean.Name = "rBTimeEuropean";
			this.rBTimeEuropean.Size = new Size(344, 24);
			this.rBTimeEuropean.TabIndex = 0;
			this.rBTimeEuropean.Text = "Europäisch (24.12.2000 23:59:59)";
			this.rBTimeEuropean.CheckedChanged += this.settingsChanged;
			this.lbMaxSaveCurveNum.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMaxSaveCurveNum.Location = new Point(296, 94);
			this.lbMaxSaveCurveNum.Name = "lbMaxSaveCurveNum";
			this.lbMaxSaveCurveNum.Size = new Size(272, 48);
			this.lbMaxSaveCurveNum.TabIndex = 6;
			this.lbMaxSaveCurveNum.Text = "Max. einstellbare Anzahl bei automatischer Kurvenabspeicherung";
			this.nEMaxSaveCurveNum.BackColor = Color.White;
			this.nEMaxSaveCurveNum.DecimalNum = 0;
			this.nEMaxSaveCurveNum.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMaxSaveCurveNum.ForeColor = SystemColors.ControlText;
			this.nEMaxSaveCurveNum.Location = new Point(576, 100);
			this.nEMaxSaveCurveNum.MaxValue = 65535f;
			this.nEMaxSaveCurveNum.MinValue = 0f;
			this.nEMaxSaveCurveNum.Name = "nEMaxSaveCurveNum";
			this.nEMaxSaveCurveNum.Size = new Size(80, 28);
			this.nEMaxSaveCurveNum.TabIndex = 5;
			this.nEMaxSaveCurveNum.Text = "0";
			this.nEMaxSaveCurveNum.TextAlign = HorizontalAlignment.Right;
			this.nEMaxSaveCurveNum.Value = 0f;
			this.nEMaxSaveCurveNum.Enter += this.Start_Input;
			this.nEMaxSaveCurveNum.MouseDown += this.StartInput;
			this.chBIntegratedMachineVisu.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBIntegratedMachineVisu.Location = new Point(296, 346);
			this.chBIntegratedMachineVisu.Name = "chBIntegratedMachineVisu";
			this.chBIntegratedMachineVisu.Size = new Size(352, 24);
			this.chBIntegratedMachineVisu.TabIndex = 7;
			this.chBIntegratedMachineVisu.Text = "Integrierte Maschinen Visualisierung";
			this.chBIntegratedMachineVisu.CheckedChanged += this.settingsChanged;
			this.chBIntegratedHelp.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBIntegratedHelp.Location = new Point(296, 384);
			this.chBIntegratedHelp.Name = "chBIntegratedHelp";
			this.chBIntegratedHelp.Size = new Size(352, 24);
			this.chBIntegratedHelp.TabIndex = 8;
			this.chBIntegratedHelp.Text = "Integrierte Hilfe";
			this.chBIntegratedHelp.CheckedChanged += this.settingsChanged;
			this.chBDisplayStepsInCurves.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBDisplayStepsInCurves.Location = new Point(296, 422);
			this.chBDisplayStepsInCurves.Name = "chBDisplayStepsInCurves";
			this.chBDisplayStepsInCurves.Size = new Size(352, 24);
			this.chBDisplayStepsInCurves.TabIndex = 10;
			this.chBDisplayStepsInCurves.Text = "Anzeige der Stufen mit den Kurven";
			this.chBDisplayStepsInCurves.CheckedChanged += this.settingsChanged;
			this.chBUsbKeyActivated.AutoSize = true;
			this.chBUsbKeyActivated.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.chBUsbKeyActivated.Location = new Point(296, 461);
			this.chBUsbKeyActivated.Name = "chBUsbKeyActivated";
			this.chBUsbKeyActivated.Size = new Size(141, 22);
			this.chBUsbKeyActivated.TabIndex = 11;
			this.chBUsbKeyActivated.Text = "USB-Key aktivieren";
			this.chBUsbKeyActivated.UseVisualStyleBackColor = true;
			this.chBUsbKeyActivated.CheckedChanged += this.settingsChanged;
			this.lbMasterPassword1.AutoSize = true;
			this.lbMasterPassword1.Location = new Point(11, 475);
			this.lbMasterPassword1.MinimumSize = new Size(100, 50);
			this.lbMasterPassword1.Name = "lbMasterPassword1";
			this.lbMasterPassword1.Size = new Size(100, 50);
			this.lbMasterPassword1.TabIndex = 12;
			this.lbMasterPassword1.Click += this.lbMasterPassword1_Click;
			this.lbMasterPassword2.AutoSize = true;
			this.lbMasterPassword2.Location = new Point(301, 9);
			this.lbMasterPassword2.MinimumSize = new Size(150, 50);
			this.lbMasterPassword2.Name = "lbMasterPassword2";
			this.lbMasterPassword2.Size = new Size(150, 50);
			this.lbMasterPassword2.TabIndex = 13;
			this.lbMasterPassword2.Click += this.lbMasterPassword2_Click;
			this.lbMasterPassword3.AutoSize = true;
			this.lbMasterPassword3.Location = new Point(584, 466);
			this.lbMasterPassword3.MinimumSize = new Size(100, 50);
			this.lbMasterPassword3.Name = "lbMasterPassword3";
			this.lbMasterPassword3.Size = new Size(100, 50);
			this.lbMasterPassword3.TabIndex = 14;
			this.lbMasterPassword3.Click += this.lbMasterPassword3_Click;
			this.nEMaxFifoBuffer.BackColor = Color.White;
			this.nEMaxFifoBuffer.DecimalNum = 0;
			this.nEMaxFifoBuffer.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMaxFifoBuffer.ForeColor = SystemColors.ControlText;
			this.nEMaxFifoBuffer.Location = new Point(576, 150);
			this.nEMaxFifoBuffer.MaxValue = 3000f;
			this.nEMaxFifoBuffer.MinValue = 10f;
			this.nEMaxFifoBuffer.Name = "nEMaxFifoBuffer";
			this.nEMaxFifoBuffer.Size = new Size(80, 28);
			this.nEMaxFifoBuffer.TabIndex = 15;
			this.nEMaxFifoBuffer.Text = "100";
			this.nEMaxFifoBuffer.TextAlign = HorizontalAlignment.Right;
			this.nEMaxFifoBuffer.Value = 100f;
			this.nEMaxFifoBuffer.Enter += this.Start_Input;
			this.nEMaxFifoBuffer.MouseDown += this.StartInput;
			this.lbMaxFifoBuffer.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMaxFifoBuffer.Location = new Point(296, 144);
			this.lbMaxFifoBuffer.Name = "lbMaxFifoBuffer";
			this.lbMaxFifoBuffer.Size = new Size(272, 48);
			this.lbMaxFifoBuffer.TabIndex = 16;
			this.lbMaxFifoBuffer.Text = "Max. einstellbare Anzahl für Kurven-Ringpuffer";
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.nEMaxFifoBuffer);
			base.Controls.Add(this.lbMaxFifoBuffer);
			base.Controls.Add(this.lbMasterPassword3);
			base.Controls.Add(this.lbMasterPassword2);
			base.Controls.Add(this.lbMasterPassword1);
			base.Controls.Add(this.chBUsbKeyActivated);
			base.Controls.Add(this.chBDisplayStepsInCurves);
			base.Controls.Add(this.chBIntegratedHelp);
			base.Controls.Add(this.chBIntegratedMachineVisu);
			base.Controls.Add(this.nEMaxSaveCurveNum);
			base.Controls.Add(this.lbMaxSaveCurveNum);
			base.Controls.Add(this.gBTimeSet);
			base.Controls.Add(this.chBKeyboard);
			base.Controls.Add(this.gBlang);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "VisualisationParamForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "CustomerSettingsForm";
			base.Activated += this.VisualisationParamForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBlang.ResumeLayout(false);
			this.gBTimeSet.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public void ShowWindow()
		{
			this.Main.ResetBrowserGrantedBy();
			if (this.Main.IsOnlineMode)
			{
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadSpindleConst"));
				if (!this.Main.VC.ReceiveVarBlock(11))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not receive SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
			}
			this.Initialize();
			this.MenEna();
			this.initInProgress = true;
			base.Show();
			this.initInProgress = false;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MSystemConstants") + "/" + this.Main.Rm.GetString("MVisualisationParam");
			this.gBTimeSet.Text = this.Main.Rm.GetString("TimeDateFormat");
			this.gBlang.Text = this.Main.Rm.GetString("Language");
			this.chBKeyboard.Text = this.Main.Rm.GetString("UsedKeyboard");
			this.chBDisplayStepsInCurves.Text = this.Main.Rm.GetString("DisplayStepsInCurves");
			this.chBIntegratedHelp.Text = this.Main.Rm.GetString("DisplayIntegratedHelp");
			this.chBIntegratedMachineVisu.Text = this.Main.Rm.GetString("DisplayIntegratedMachineVisu");
			this.rBde.Text = this.Main.Rm.GetString("German");
			this.rBen.Text = this.Main.Rm.GetString("English");
			this.rBes.Text = this.Main.Rm.GetString("Spain");
			this.rBfr.Text = this.Main.Rm.GetString("French");
			this.rBit.Text = this.Main.Rm.GetString("Italian");
			this.rBcz.Text = this.Main.Rm.GetString("Czech");
			this.rBsk.Text = this.Main.Rm.GetString("Slovak");
			this.rBhu.Text = this.Main.Rm.GetString("Hungarian");
			this.rBTimeEuropean.Text = this.Main.Rm.GetString("EuropeanTime") + " (24.12.2012 23:59:59)";
			this.rBTimeUS.Text = this.Main.Rm.GetString("USTime") + " (12/24/2012 23:59:59)";
			this.lbMaxSaveCurveNum.Text = this.Main.Rm.GetString("MaxSaveCurveNum");
			this.lbMaxFifoBuffer.Text = this.Main.Rm.GetString("MaxFifoBufferNum");
			this.btBack.Text = this.Main.Rm.GetString("StoreAndBack");
			this.btCancel.Text = this.Main.Rm.GetString("btCancel");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
		}

		private void MenEna()
		{
			bool flag = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_VisualisationParamForm)
			{
				flag = true;
			}
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_VisualisationParamForm, false);
			if (this.Main.PassCodeLevel >= 5 && !this.Main.ViewOnlyMode)
			{
				this.chBUsbKeyActivated.Visible = true;
			}
			else
			{
				this.chBUsbKeyActivated.Visible = false;
			}
			this.nEMaxSaveCurveNum.Enabled = flag;
			this.nEMaxSaveCurveNum.Visible = flag;
			this.lbMaxSaveCurveNum.Visible = flag;
			this.nEMaxFifoBuffer.Enabled = flag;
			this.lbMaxFifoBuffer.Enabled = flag;
			this.chBKeyboard.Enabled = flag;
			this.chBIntegratedHelp.Enabled = flag;
			this.chBIntegratedMachineVisu.Enabled = flag;
			this.chBDisplayStepsInCurves.Enabled = flag;
			if (this.Main.IsOfflineVersion)
			{
				flag = true;
			}
			this.btBack.Enabled = flag;
			this.rBde.Enabled = flag;
			this.rBen.Enabled = flag;
			this.rBes.Enabled = flag;
			this.rBfr.Enabled = flag;
			this.rBhu.Enabled = flag;
			this.rBit.Enabled = flag;
			this.rBsk.Enabled = flag;
			this.rBTimeEuropean.Enabled = flag;
			this.rBTimeUS.Enabled = flag;
		}

		private void Initialize()
		{
			this.masterPassword1 = false;
			this.masterPassword2 = false;
			this.masterPassword3 = false;
			this.initInProgress = true;
			switch (Settings.Default.Language)
			{
			case 0:
				this.rBen.Checked = true;
				break;
			case 1:
				this.rBde.Checked = true;
				break;
			case 2:
				this.rBfr.Checked = true;
				break;
			case 3:
				this.rBit.Checked = true;
				break;
			case 4:
				this.rBes.Checked = true;
				break;
			case 5:
				this.rBcz.Checked = true;
				break;
			case 6:
				this.rBsk.Checked = true;
				break;
			case 7:
				this.rBhu.Checked = true;
				break;
			default:
				MessageBox.Show("Wrong language in Initialize() of VisualisationParam", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.rBen.Checked = true;
				break;
			}
			switch (Settings.Default.TimeSet)
			{
			case "dd'.'MM'.'yyyy HH':'mm':'ss":
				this.rBTimeEuropean.Checked = true;
				break;
			case "MM'/'dd'/'yyyy HH':'mm':'ss":
				this.rBTimeUS.Checked = true;
				break;
			default:
				MessageBox.Show("Wrong timeSet in Initialize() of VisualisationParam", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.rBTimeEuropean.Checked = true;
				break;
			}
			if (Settings.Default.SoftKeyBoardIsUsed)
			{
				this.chBKeyboard.Checked = true;
			}
			else
			{
				this.chBKeyboard.Checked = false;
			}
			if (Settings.Default.IntegratedHelp)
			{
				this.chBIntegratedHelp.Checked = true;
			}
			else
			{
				this.chBIntegratedHelp.Checked = false;
			}
			if (Settings.Default.IntegratedMachineVisu)
			{
				this.chBIntegratedMachineVisu.Checked = true;
			}
			else
			{
				this.chBIntegratedMachineVisu.Checked = false;
			}
			this.nEMaxSaveCurveNum.Value = Settings.Default.MaxSavCurveNum;
			this.nEMaxFifoBuffer.Value = (float)Settings.Default.Curve_StoringFIFO_SettingMaxCount;
			this.chBDisplayStepsInCurves.Checked = Settings.Default.DisplayStepsInCurves;
			if (this.Main.VC.SpConst.UsbKeyActivated != 0)
			{
				this.chBUsbKeyActivated.Checked = true;
			}
			else
			{
				this.chBUsbKeyActivated.Checked = false;
			}
			this.initInProgress = false;
		}

		private void resetMasterPassword()
		{
			if (this.masterPassword3)
			{
				this.Main.PassCodeLevel = this.recentPasscodeLevel;
				this.Main.ActualUser = this.recentActualUser;
				this.Main.ShowCurrentUserAccessState(0, false);
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			if (!this.nEMaxSaveCurveNum.IsOK)
			{
				string str = this.lbMaxSaveCurveNum.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMaxSaveCurveNum.MinValue.ToString() + " - " + this.nEMaxSaveCurveNum.MaxValue.ToString() + "\n";
				MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + str, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return;
			}
			if (!this.nEMaxFifoBuffer.IsOK)
			{
				string str2 = this.lbMaxFifoBuffer.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEMaxFifoBuffer.MinValue.ToString() + " - " + this.nEMaxFifoBuffer.MaxValue.ToString() + "\n";
				MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + str2, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return;
			}
			this.resetMasterPassword();
			this.pnMenu.Enabled = false;
			this.ApplyValues();
			Settings.Default.Save();
			this.Main.StatusBarText(this.Main.Rm.GetString("UseLanguageSettings"));
			this.Main.MakeVisualSettings();
			this.Main.SetAllLanguageTexts();
			this.Main.StatusBarText(string.Empty);
			if (this.Main.IsOnlineMode)
			{
				if (this.Main.VC.SpConst.UsbKeyActivated != 0 && !this.chBUsbKeyActivated.Checked)
				{
					goto IL_0271;
				}
				if (this.Main.VC.SpConst.UsbKeyActivated == 0 && this.chBUsbKeyActivated.Checked)
				{
					goto IL_0271;
				}
			}
			goto IL_04b1;
			IL_04b1:
			base.Hide();
			return;
			IL_0271:
			if (!this.chBUsbKeyActivated.Checked)
			{
				this.Main.VC.SpConst.UsbKeyActivated = 0;
				Settings.Default.UserLevel_BrowserForm = 0;
			}
			else
			{
				this.Main.VC.SpConst.UsbKeyActivated = 1;
				Settings.Default.UserLevel_BrowserForm = 1;
			}
			Settings.Default.Save();
			this.Main.LevelAssignment1.ApplyValuesToWSP();
			this.Main.StatusBarText(this.Main.Rm.GetString("SendSpindleConstants"));
			if (!this.Main.VC.SendVarBlock(11))
			{
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show("Could not send SpConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.pnMenu.Enabled = true;
				this.pnMenu.Select();
				return;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("SaveSpindleConstOnCPU"));
			if (!this.Main.SaveOnController(2, false))
			{
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show(this.Main.Rm.GetString("MbSaveSpConstFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.pnMenu.Enabled = true;
				this.pnMenu.Select();
				return;
			}
			this.Main.ExitExclusiveBlock1();
			this.Main.MakeLogbookEntry(202020u, 3, (this.Main.VC.SpConst.UsbKeyActivated != 0) ? 0f : 1f, (float)(int)this.Main.VC.SpConst.UsbKeyActivated, 0u, 0, byte.MaxValue);
			this.Main.WriteLogbookData(true);
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			this.Main.ResetPasscodeLevel();
			MessageBox.Show(this.Main.Rm.GetString("MbUsbKeyChangedRestartVisu"), this.Main.Rm.GetString("MbhHint"));
			this.Main.CloseWithoutQuery();
			goto IL_04b1;
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_3_2_Visualisierungsparameter";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_3_2_Visualisierungsparameter");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.resetMasterPassword();
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		private void ApplyValues()
		{
			if (this.rBen.Checked)
			{
				Settings.Default.Language = 0;
			}
			else if (this.rBde.Checked)
			{
				Settings.Default.Language = 1;
			}
			else if (this.rBfr.Checked)
			{
				Settings.Default.Language = 2;
			}
			else if (this.rBit.Checked)
			{
				Settings.Default.Language = 3;
			}
			else if (this.rBes.Checked)
			{
				Settings.Default.Language = 4;
			}
			else if (this.rBcz.Checked)
			{
				Settings.Default.Language = 5;
			}
			else if (this.rBsk.Checked)
			{
				Settings.Default.Language = 6;
			}
			else if (this.rBhu.Checked)
			{
				Settings.Default.Language = 7;
			}
			Settings.Default.SoftKeyBoardIsUsed = this.chBKeyboard.Checked;
			Settings.Default.IntegratedMachineVisu = this.chBIntegratedMachineVisu.Checked;
			Settings.Default.IntegratedHelp = this.chBIntegratedHelp.Checked;
			if (this.rBTimeEuropean.Checked)
			{
				Settings.Default.TimeSet = "dd'.'MM'.'yyyy HH':'mm':'ss";
			}
			if (this.rBTimeUS.Checked)
			{
				Settings.Default.TimeSet = "MM'/'dd'/'yyyy HH':'mm':'ss";
			}
			Settings.Default.MaxSavCurveNum = this.nEMaxSaveCurveNum.Value;
			Settings.Default.Curve_StoringFIFO_SettingMaxCount = (int)this.nEMaxFifoBuffer.Value;
			C_Curve c_Curve = this.Main.CurveDisplay1.C_Curve1;
			Settings @default = Settings.Default;
			bool displayStepsInCurves = @default.DisplayStepsInCurves = this.chBDisplayStepsInCurves.Checked;
			c_Curve.DisplayStepsInCurves = displayStepsInCurves;
		}

		private void VisualisationParamForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void cBDisplaySpindlePressureAsKN_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void chBJawOpeningViaDigitalOutSync1_CheckedChanged(object sender, EventArgs e)
		{
		}

		public void KeyArrived()
		{
			if (this.Main.GetExclusiveBlock1())
			{
				this.Main.ProcessProgram.UploadAllProgDataFromController();
				this.Main.ProcessProgram.InitializeTempProgStruct();
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadSystemConst"));
				this.Main.VC.ReceiveVarBlock(12);
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
			}
			this.MenEna();
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.initInProgress)
			{
				this.Main.SettingsChanged();
			}
		}

		private void lbMasterPassword1_Click(object sender, EventArgs e)
		{
			if (this.Main.Usb_Key_Access() && this.Main.PassCodeLevel < 5)
			{
				if (this.masterPassword2 || this.masterPassword3)
				{
					this.masterPassword3 = (this.masterPassword2 = false);
				}
				else
				{
					this.masterPassword1 = true;
				}
			}
		}

		private void lbMasterPassword2_Click(object sender, EventArgs e)
		{
			if (this.masterPassword3 || !this.masterPassword1)
			{
				this.masterPassword3 = false;
			}
			else
			{
				this.masterPassword2 = true;
			}
		}

		private void lbMasterPassword3_Click(object sender, EventArgs e)
		{
			if (!this.masterPassword2 || !this.masterPassword1)
			{
				this.masterPassword2 = (this.masterPassword1 = false);
			}
			else
			{
				this.masterPassword3 = true;
				this.masterPassword2 = (this.masterPassword1 = false);
				this.recentActualUser = this.Main.ActualUser;
				this.recentPasscodeLevel = this.Main.PassCodeLevel;
				this.Main.PasswordInput1.ShowWindow(false);
				if (this.Main.PasswordInput1.AccessMode == 0 && this.Main.PassCodeLevel >= 5)
				{
					this.MenEna();
				}
			}
		}

		private void rBen_CheckedChanged(object sender, EventArgs e)
		{
		}
	}
}
