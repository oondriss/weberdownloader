using System;

namespace Visualisation
{
	public class DirectoryClass
	{
		public DateTime Date_Time;

		public string Date_Time_String;

		public int Size;

		public string Filename;
	}
}
