using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class PasscodeManagerForm : Form
	{
		private const int MODE_NONE = 0;

		private const int MODE_EDIT = 1;

		private const int MODE_NEW_ENTRY = 2;

		private MainForm Main;

		private int Mode;

		public S_Passcode[] UserData;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private ListBox listBoxName;

		private Container components;

		private Button btNewEntry;

		private Button btDeleteEntry;

		private Button btChangeEntry;

		private Button bt2;

		private Button bt1;

		private Panel pnWork;

		private Button btCancel;

		private GroupBox gBEditPassCode;

		private NumberEdit1 nEPasscode;

		private Button btEditCancel;

		private Button btApply;

		private Label lbLevel;

		private Label lbPassword;

		private Label lbShortName;

		private ComboBox cBLevel;

		private TextBox tBShortName;

		private Label lbAction;

		private Label lbUser;

		private bool bInitialize;

		public PasscodeManagerForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.nEPasscode.MaxLength = 4;
			this.tBShortName.MaxLength = 4;
			this.Mode = 0;
			this.UserData = new S_Passcode[20];
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btCancel = new Button();
			this.bt2 = new Button();
			this.bt1 = new Button();
			this.btNewEntry = new Button();
			this.btDeleteEntry = new Button();
			this.btChangeEntry = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.pnWork = new Panel();
			this.gBEditPassCode = new GroupBox();
			this.nEPasscode = new NumberEdit1();
			this.btEditCancel = new Button();
			this.btApply = new Button();
			this.lbLevel = new Label();
			this.lbPassword = new Label();
			this.lbShortName = new Label();
			this.cBLevel = new ComboBox();
			this.tBShortName = new TextBox();
			this.lbAction = new Label();
			this.lbUser = new Label();
			this.listBoxName = new ListBox();
			this.pnMenu.SuspendLayout();
			this.pnWork.SuspendLayout();
			this.gBEditPassCode.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.bt1);
			this.pnMenu.Controls.Add(this.btNewEntry);
			this.pnMenu.Controls.Add(this.btDeleteEntry);
			this.pnMenu.Controls.Add(this.btChangeEntry);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 5;
			this.btCancel.Text = "Abbruch";
			this.btCancel.Click += this.btCancel_Click;
			this.btCancel.Enter += this.Start_Input;
			this.bt2.Enabled = false;
			this.bt2.Location = new Point(3, 387);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 7;
			this.bt1.Enabled = false;
			this.bt1.Location = new Point(3, 323);
			this.bt1.Name = "bt1";
			this.bt1.Size = new Size(74, 62);
			this.bt1.TabIndex = 6;
			this.btNewEntry.Location = new Point(3, 259);
			this.btNewEntry.Name = "btNewEntry";
			this.btNewEntry.Size = new Size(74, 62);
			this.btNewEntry.TabIndex = 4;
			this.btNewEntry.Text = "Neuer Eintrag";
			this.btNewEntry.Click += this.btNewEntry_Click;
			this.btNewEntry.Enter += this.Start_Input;
			this.btDeleteEntry.Location = new Point(3, 195);
			this.btDeleteEntry.Name = "btDeleteEntry";
			this.btDeleteEntry.Size = new Size(74, 62);
			this.btDeleteEntry.TabIndex = 3;
			this.btDeleteEntry.Text = "Eintrag löschen";
			this.btDeleteEntry.Click += this.btDeleteEntry_Click;
			this.btDeleteEntry.Enter += this.Start_Input;
			this.btChangeEntry.Location = new Point(3, 131);
			this.btChangeEntry.Name = "btChangeEntry";
			this.btChangeEntry.Size = new Size(74, 62);
			this.btChangeEntry.TabIndex = 2;
			this.btChangeEntry.Text = "Eintrag bearbeiten";
			this.btChangeEntry.Click += this.btChangeEntry_Click;
			this.btChangeEntry.Enter += this.Start_Input;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btHelp.Enter += this.Start_Input;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Speichern + Zurück";
			this.btBack.Click += this.btBack_Click;
			this.btBack.Enter += this.Start_Input;
			this.pnWork.Controls.Add(this.gBEditPassCode);
			this.pnWork.Controls.Add(this.lbUser);
			this.pnWork.Controls.Add(this.listBoxName);
			this.pnWork.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnWork.Location = new Point(0, 0);
			this.pnWork.Name = "pnWork";
			this.pnWork.Size = new Size(709, 522);
			this.pnWork.TabIndex = 1;
			this.gBEditPassCode.Controls.Add(this.nEPasscode);
			this.gBEditPassCode.Controls.Add(this.btEditCancel);
			this.gBEditPassCode.Controls.Add(this.btApply);
			this.gBEditPassCode.Controls.Add(this.lbLevel);
			this.gBEditPassCode.Controls.Add(this.lbPassword);
			this.gBEditPassCode.Controls.Add(this.lbShortName);
			this.gBEditPassCode.Controls.Add(this.cBLevel);
			this.gBEditPassCode.Controls.Add(this.tBShortName);
			this.gBEditPassCode.Controls.Add(this.lbAction);
			this.gBEditPassCode.Location = new Point(272, 8);
			this.gBEditPassCode.Name = "gBEditPassCode";
			this.gBEditPassCode.Size = new Size(408, 280);
			this.gBEditPassCode.TabIndex = 1;
			this.gBEditPassCode.TabStop = false;
			this.nEPasscode.BackColor = Color.White;
			this.nEPasscode.DecimalNum = 0;
			this.nEPasscode.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEPasscode.ForeColor = Color.Red;
			this.nEPasscode.Location = new Point(168, 109);
			this.nEPasscode.MaxLength = 5;
			this.nEPasscode.MaxValue = 9999f;
			this.nEPasscode.MinValue = 1f;
			this.nEPasscode.Name = "nEPasscode";
			this.nEPasscode.Size = new Size(200, 28);
			this.nEPasscode.TabIndex = 1;
			this.nEPasscode.Text = "0";
			this.nEPasscode.Value = 0f;
			this.nEPasscode.TextChanged += this.settingsChanged;
			this.nEPasscode.Enter += this.Start_Input;
			this.nEPasscode.MouseDown += this.StartInput;
			this.btEditCancel.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btEditCancel.Location = new Point(272, 200);
			this.btEditCancel.Name = "btEditCancel";
			this.btEditCancel.Size = new Size(112, 56);
			this.btEditCancel.TabIndex = 4;
			this.btEditCancel.Text = "Änderungen verwerfen";
			this.btEditCancel.Click += this.btEditCancel_Click;
			this.btEditCancel.Enter += this.Start_Input;
			this.btApply.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btApply.Location = new Point(144, 200);
			this.btApply.Name = "btApply";
			this.btApply.Size = new Size(112, 56);
			this.btApply.TabIndex = 3;
			this.btApply.Text = "Änderungen uebernehmen";
			this.btApply.Click += this.btApply_Click;
			this.btApply.Enter += this.Start_Input;
			this.lbLevel.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbLevel.Location = new Point(16, 152);
			this.lbLevel.Name = "lbLevel";
			this.lbLevel.Size = new Size(144, 23);
			this.lbLevel.TabIndex = 19;
			this.lbLevel.Text = "Ebene";
			this.lbLevel.TextAlign = ContentAlignment.MiddleLeft;
			this.lbPassword.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbPassword.Location = new Point(16, 112);
			this.lbPassword.Name = "lbPassword";
			this.lbPassword.Size = new Size(144, 23);
			this.lbPassword.TabIndex = 18;
			this.lbPassword.Text = "Kennwort";
			this.lbPassword.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShortName.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShortName.Location = new Point(16, 72);
			this.lbShortName.Name = "lbShortName";
			this.lbShortName.Size = new Size(144, 23);
			this.lbShortName.TabIndex = 16;
			this.lbShortName.Text = "Namenskürzel";
			this.lbShortName.TextAlign = ContentAlignment.MiddleLeft;
			this.cBLevel.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBLevel.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBLevel.Items.AddRange(new object[3]
			{
				"Bediener",
				"Programmierer",
				"Administrator"
			});
			this.cBLevel.Location = new Point(168, 149);
			this.cBLevel.Name = "cBLevel";
			this.cBLevel.Size = new Size(216, 28);
			this.cBLevel.TabIndex = 2;
			this.cBLevel.SelectedIndexChanged += this.settingsChanged;
			this.tBShortName.BackColor = Color.White;
			this.tBShortName.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.tBShortName.Location = new Point(168, 69);
			this.tBShortName.MaxLength = 2;
			this.tBShortName.Name = "tBShortName";
			this.tBShortName.Size = new Size(200, 28);
			this.tBShortName.TabIndex = 0;
			this.tBShortName.Text = "textBox1";
			this.tBShortName.TextChanged += this.settingsChanged;
			this.tBShortName.Enter += this.Start_Input;
			this.tBShortName.MouseDown += this.StartInput;
			this.lbAction.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAction.Location = new Point(16, 24);
			this.lbAction.Name = "lbAction";
			this.lbAction.Size = new Size(248, 23);
			this.lbAction.TabIndex = 13;
			this.lbAction.Text = "Aktion";
			this.lbAction.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUser.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUser.Location = new Point(40, 32);
			this.lbUser.Name = "lbUser";
			this.lbUser.Size = new Size(200, 23);
			this.lbUser.TabIndex = 10;
			this.lbUser.Text = "Angelegte Benutzer";
			this.listBoxName.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.listBoxName.ItemHeight = 20;
			this.listBoxName.Location = new Point(80, 64);
			this.listBoxName.Name = "listBoxName";
			this.listBoxName.Size = new Size(72, 384);
			this.listBoxName.TabIndex = 0;
			this.listBoxName.SelectedIndexChanged += this.listBoxName_SelectedIndexChanged;
			this.listBoxName.Enter += this.Start_Input;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.pnWork);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "PasscodeManagerForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen/Systemkonstanten/Passwortverwaltung";
			base.Activated += this.PasscodeManagerForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.pnWork.ResumeLayout(false);
			this.gBEditPassCode.ResumeLayout(false);
			this.gBEditPassCode.PerformLayout();
			base.ResumeLayout(false);
		}

		public void ShowWindow()
		{
			this.Main.ResetBrowserGrantedBy();
			this.Initialize();
			base.Show();
		}

		public void SetLanguageTexts()
		{
			this.bInitialize = true;
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MSystemConstants") + "/" + this.Main.Rm.GetString("MPasscodeManager");
			this.lbLevel.Text = this.Main.Rm.GetString("PasscodeLevel");
			this.lbPassword.Text = this.Main.Rm.GetString("Password");
			this.lbShortName.Text = this.Main.Rm.GetString("ShortName");
			this.lbUser.Text = this.Main.Rm.GetString("CreatedUsers");
			this.btApply.Text = this.Main.Rm.GetString("ApplyEntry");
			this.btBack.Text = this.Main.Rm.GetString("StoreAndBack");
			this.btCancel.Text = this.Main.Rm.GetString("btCancel");
			this.btChangeEntry.Text = this.Main.Rm.GetString("ChangeEntry");
			this.btDeleteEntry.Text = this.Main.Rm.GetString("DeleteEntry");
			this.btEditCancel.Text = this.Main.Rm.GetString("EditCancel");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btNewEntry.Text = this.Main.Rm.GetString("NewEntry");
			this.cBLevel.Items.Clear();
			for (int i = 0; i < 4; i++)
			{
				string accessLevelDefinition = this.Main.C_global.GetAccessLevelDefinition(i);
				if (accessLevelDefinition == null)
				{
					break;
				}
				this.cBLevel.Items.Add(this.Main.Rm.GetString(accessLevelDefinition));
			}
			this.cBLevel.SelectedIndex = 0;
			this.bInitialize = false;
		}

		private void MenEna()
		{
			this.tBShortName.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEPasscode.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			switch (this.Mode)
			{
			case 1:
				this.btBack.Enabled = false;
				this.tBShortName.Enabled = false;
				this.nEPasscode.Enabled = true;
				this.cBLevel.Enabled = true;
				this.btApply.Text = this.Main.Rm.GetString("ApplyEntry");
				this.btEditCancel.Text = this.Main.Rm.GetString("EditCancel");
				this.btApply.Visible = true;
				this.btEditCancel.Visible = true;
				this.btDeleteEntry.Enabled = false;
				this.btChangeEntry.Enabled = false;
				this.btNewEntry.Enabled = false;
				this.listBoxName.Enabled = false;
				this.lbAction.Text = this.Main.Rm.GetString("EditEntry");
				break;
			case 2:
				this.btBack.Enabled = false;
				this.tBShortName.Enabled = true;
				this.nEPasscode.Enabled = true;
				this.cBLevel.Enabled = true;
				this.btApply.Text = this.Main.Rm.GetString("AddEntry");
				this.btEditCancel.Text = this.Main.Rm.GetString("Cancel");
				this.btApply.Visible = true;
				this.btEditCancel.Visible = true;
				this.btDeleteEntry.Enabled = false;
				this.btChangeEntry.Enabled = false;
				this.btNewEntry.Enabled = false;
				this.listBoxName.Enabled = false;
				this.lbAction.Text = this.Main.Rm.GetString("MakeNewEntry");
				break;
			default:
				this.btBack.Enabled = true;
				this.tBShortName.Enabled = false;
				this.nEPasscode.Enabled = false;
				this.cBLevel.Enabled = false;
				this.btApply.Visible = false;
				this.btEditCancel.Visible = false;
				this.btDeleteEntry.Enabled = true;
				if (this.listBoxName.SelectedIndex < 0)
				{
					this.btChangeEntry.Enabled = false;
				}
				else
				{
					this.btChangeEntry.Enabled = true;
				}
				this.btNewEntry.Enabled = true;
				this.listBoxName.Enabled = true;
				this.lbAction.Text = string.Empty;
				break;
			}
		}

		private void Initialize()
		{
			this.listBoxName.Items.Clear();
			for (int i = 0; i < 20; i++)
			{
				string text = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.PassCodes[i].Name);
				if (text == string.Empty)
				{
					this.UserData[i].shortName = string.Empty;
					this.UserData[i].passcode = 0u;
					this.UserData[i].level = 0;
				}
				else
				{
					this.listBoxName.Items.Add(text);
					this.UserData[i].shortName = text;
					this.UserData[i].passcode = this.Main.VC.SysConst.PassCodes[i].Code;
					this.UserData[i].level = this.Main.VC.SysConst.PassCodes[i].Level;
				}
			}
			if (this.listBoxName.Items.Count == 0)
			{
				this.listBoxName.Items.Add("XY");
				this.UserData[0].shortName = "XY";
				this.UserData[0].passcode = 3u;
				this.UserData[0].level = 3;
			}
			this.listBoxName.SelectedIndex = 0;
			this.tBShortName.Text = this.UserData[0].shortName;
			this.nEPasscode.Value = (float)(double)this.UserData[0].passcode;
			if (this.UserData[0].level > 0)
			{
				this.cBLevel.SelectedIndex = this.UserData[0].level - 1;
			}
			else
			{
				this.cBLevel.SelectedIndex = 0;
			}
			this.MenEna();
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			bool flag = false;
			bool flag2 = false;
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				goto IL_04c3;
			}
			int num = 0;
			while (num < this.listBoxName.Items.Count)
			{
				if (this.UserData[num].level != 4)
				{
					num++;
					continue;
				}
				flag2 = true;
				break;
			}
			if (!flag2)
			{
				DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbCreateDefaultPasscode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
				if (dialogResult != DialogResult.Cancel)
				{
					for (num = 0; num < 20; num++)
					{
						this.UserData[num].shortName = string.Empty;
						this.UserData[num].passcode = 0u;
						this.UserData[num].level = 0;
						this.listBoxName.Items.Clear();
					}
					this.UserData[0].shortName = "XY";
					this.UserData[0].passcode = 3u;
					this.UserData[0].level = 4;
					this.listBoxName.Items.Add("XY");
					goto IL_0161;
				}
				return;
			}
			goto IL_0161;
			IL_04c3:
			this.Main.LoggingFinished(true);
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			base.Hide();
			return;
			IL_0161:
			this.pnMenu.Enabled = false;
			for (num = 0; num < 20; num++)
			{
				this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.PassCodes[num].Name);
				if (this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.PassCodes[num].Name) != this.UserData[num].shortName)
				{
					flag = true;
				}
				if (this.Main.VC.SysConst.PassCodes[num].Code != this.UserData[num].passcode)
				{
					flag = true;
				}
				if (this.Main.VC.SysConst.PassCodes[num].Level != this.UserData[num].level)
				{
					flag = true;
				}
				if (this.UserData[num].shortName == string.Empty)
				{
					this.Main.CommonFunctions.StringToUShort(ref this.Main.VC.SysConst.PassCodes[num].Name, string.Empty, 5);
					this.Main.VC.SysConst.PassCodes[num].Code = 0u;
					this.Main.VC.SysConst.PassCodes[num].Level = 0;
				}
				else
				{
					this.Main.CommonFunctions.StringToUShort(ref this.Main.VC.SysConst.PassCodes[num].Name, this.UserData[num].shortName, 5);
					this.Main.VC.SysConst.PassCodes[num].Code = this.UserData[num].passcode;
					this.Main.VC.SysConst.PassCodes[num].Level = this.UserData[num].level;
				}
			}
			if (flag)
			{
				this.Main.MakeLogbookEntry(202018u, 3, 0f, 0f, 0u, 0, byte.MaxValue);
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("SendPasscodes"));
			Cursor.Current = Cursors.WaitCursor;
			if (!this.Main.VC.SendVarBlock(12))
			{
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show("Could not send SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.pnMenu.Enabled = true;
				this.pnMenu.Select();
				return;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("SavePasscodesOnCPU"));
			if (!this.Main.SaveOnController(1, false))
			{
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show(this.Main.Rm.GetString("MbSavePasscodeFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.pnMenu.Enabled = true;
				this.pnMenu.Select();
				return;
			}
			this.Main.WriteLogbookData(true);
			goto IL_04c3;
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_3_1_Passwortverwaltung";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_3_1_Passwortverwaltung");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btChangeEntry_Click(object sender, EventArgs e)
		{
			this.Mode = 1;
			this.MenEna();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			if (this.Mode != 2 && this.Mode != 1)
			{
				int num = (this.listBoxName.SelectedIndex >= 0) ? this.listBoxName.SelectedIndex : 0;
				this.tBShortName.Text = this.UserData[num].shortName;
				this.nEPasscode.Value = (float)(double)this.UserData[num].passcode;
				this.cBLevel.SelectedIndex = this.UserData[num].level - 1;
				this.Mode = 0;
				this.MenEna();
				this.pnMenu.Enabled = false;
				this.Main.LoggingFinished(true);
				base.Hide();
			}
			else
			{
				this.Mode = 0;
				this.MenEna();
			}
		}

		private void listBoxName_SelectedIndexChanged(object sender, EventArgs e)
		{
			int num = (this.listBoxName.SelectedIndex >= 0) ? this.listBoxName.SelectedIndex : 0;
			if (this.Mode == 0)
			{
				this.tBShortName.Text = this.UserData[num].shortName;
				this.nEPasscode.Value = (float)(double)this.UserData[num].passcode;
				this.cBLevel.SelectedIndex = this.UserData[num].level - 1;
			}
		}

		private void btApply_Click(object sender, EventArgs e)
		{
			string text = this.tBShortName.Text;
			if (this.Mode == 1 || text.Length == 4)
			{
				for (int i = 0; i < 4 && i < text.Length; i++)
				{
					if (!char.IsLetter(text, i))
					{
						MessageBox.Show(this.Main.Rm.GetString("MbShortNameFailure1"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
						return;
					}
				}
				if (this.nEPasscode.Value == 0f)
				{
					MessageBox.Show(this.Main.Rm.GetString("MbPasscodeFailure4"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					text = this.nEPasscode.Value.ToString();
					if (text.Length < 5 && text.Length > 0)
					{
						for (int i = 0; i < text.Length; i++)
						{
							if (!char.IsNumber(text, i))
							{
								MessageBox.Show(this.Main.Rm.GetString("MbPasscodeFailure1"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
								return;
							}
						}
						for (int i = 0; i < this.listBoxName.Items.Count; i++)
						{
							if (i == this.listBoxName.SelectedIndex && this.Mode == 1)
							{
								continue;
							}
							if (!(this.tBShortName.Text == this.UserData[i].shortName) && !(this.tBShortName.Text == "XX"))
							{
								continue;
							}
							MessageBox.Show(this.Main.Rm.GetString("MbShortNameFailure3"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
							return;
						}
						for (int i = 0; i < this.listBoxName.Items.Count; i++)
						{
							if (i == this.listBoxName.SelectedIndex && this.Mode == 1)
							{
								continue;
							}
							if ((uint)this.nEPasscode.Value != this.UserData[i].passcode && this.nEPasscode.Value != 14142f)
							{
								continue;
							}
							MessageBox.Show(this.Main.Rm.GetString("MbPasscodeFailure3"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
							return;
						}
						switch (this.Mode)
						{
						case 2:
							this.listBoxName.Items.Add(this.tBShortName.Text);
							this.listBoxName.SelectedIndex = this.listBoxName.Items.Count - 1;
							break;
						case 1:
						{
							int selectedIndex = this.listBoxName.SelectedIndex;
							this.listBoxName.Items.RemoveAt(selectedIndex);
							this.listBoxName.Items.Insert(selectedIndex, this.tBShortName.Text);
							this.listBoxName.SelectedIndex = selectedIndex;
							break;
						}
						default:
							MessageBox.Show("Wrong Mode in btApplyClick() of PasscodeManager", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							break;
						}
						this.UserData[this.listBoxName.SelectedIndex].shortName = this.tBShortName.Text;
						this.UserData[this.listBoxName.SelectedIndex].passcode = (uint)this.nEPasscode.Value;
						this.UserData[this.listBoxName.SelectedIndex].level = (byte)(this.cBLevel.SelectedIndex + 1);
						this.Mode = 0;
						this.MenEna();
					}
					else
					{
						MessageBox.Show(this.Main.Rm.GetString("MbPasscodeFailure2") + ": 1 - " + 4.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
			}
			else
			{
				MessageBox.Show(this.Main.Rm.GetString("MbShortNameFailure2") + ": " + 4.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		private void btEditCancel_Click(object sender, EventArgs e)
		{
			int num = (this.listBoxName.SelectedIndex >= 0) ? this.listBoxName.SelectedIndex : 0;
			this.tBShortName.Text = this.UserData[num].shortName;
			this.nEPasscode.Value = (float)(double)this.UserData[num].passcode;
			this.cBLevel.SelectedIndex = this.UserData[num].level - 1;
			this.Mode = 0;
			this.MenEna();
		}

		private void btDeleteEntry_Click(object sender, EventArgs e)
		{
			int selectedIndex = this.listBoxName.SelectedIndex;
			if (this.listBoxName.SelectedIndex == -1)
			{
				MessageBox.Show(this.Main.Rm.GetString("NoSelection"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				string b = this.listBoxName.Items[this.listBoxName.SelectedIndex].ToString();
				int num = 0;
				bool flag = false;
				for (int i = 0; i < 20; i++)
				{
					if (this.UserData[i].shortName == b && this.UserData[i].level == 4)
					{
						flag = true;
					}
					if (this.UserData[i].level == 4)
					{
						num++;
					}
				}
				if (num <= 1 && flag)
				{
					MessageBox.Show(this.Main.Rm.GetString("MbLastAdminDeleteNotAllowed"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.listBoxName.Items.RemoveAt(this.listBoxName.SelectedIndex);
					int i;
					for (i = selectedIndex; i < this.listBoxName.Items.Count; i++)
					{
						this.UserData[i].shortName = this.UserData[i + 1].shortName;
						this.UserData[i].passcode = this.UserData[i + 1].passcode;
						this.UserData[i].level = this.UserData[i + 1].level;
					}
					this.UserData[i].shortName = string.Empty;
					this.UserData[i].passcode = 0u;
					this.UserData[i].level = 0;
					if (selectedIndex >= this.listBoxName.Items.Count)
					{
						this.listBoxName.SelectedIndex = this.listBoxName.Items.Count - 1;
					}
					else
					{
						this.listBoxName.SelectedIndex = selectedIndex;
					}
					selectedIndex = ((this.listBoxName.SelectedIndex >= 0) ? this.listBoxName.SelectedIndex : 0);
					this.tBShortName.Text = this.UserData[selectedIndex].shortName;
					this.nEPasscode.Text = this.UserData[selectedIndex].passcode.ToString();
					this.cBLevel.SelectedIndex = this.UserData[selectedIndex].level - 1;
					this.MenEna();
				}
			}
		}

		private void btNewEntry_Click(object sender, EventArgs e)
		{
			if (this.listBoxName.Items.Count >= 20)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbMaxPasscodeNum1") + ": " + 20.ToString() + "\n" + this.Main.Rm.GetString("MbMaxPasscodeNum2"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.tBShortName.Text = string.Empty;
				this.nEPasscode.Value = 0f;
				this.cBLevel.SelectedIndex = 0;
				this.Mode = 2;
				this.MenEna();
			}
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void PasscodeManagerForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
			this.Main.DisplayCurrentUser();
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.bInitialize)
			{
				this.Main.SettingsChanged();
			}
		}
	}
}
