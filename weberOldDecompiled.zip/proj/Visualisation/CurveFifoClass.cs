using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class CurveFifoClass
	{
		private MainForm Main;

		private int currentIndex;

		private bool errorOnWritingCurves;

		public string DirectoryName = "";

		private string[] curveFilesUnsorted;

		private IOrderedEnumerable<string> curveFiles;

		private DateTime recentPaintAt = DateTime.MinValue;

		public bool ErrorOnWritingCurves => this.errorOnWritingCurves;

		public int CurrentIndex => this.currentIndex;

		public string[] CurveFilesUnsorted
		{
			get
			{
				try
				{
					if (this.curveFilesUnsorted == null)
					{
						this.curveFilesUnsorted = Directory.GetFiles(this.DirectoryName, "*.wcrv");
					}
					this.errorOnWritingCurves = false;
					return this.curveFilesUnsorted;
				}
				catch (Exception)
				{
					this.errorOnWritingCurves = true;
					this.curveFilesUnsorted = new string[0];
					return this.curveFilesUnsorted;
				}
			}
		}

		public IOrderedEnumerable<string> CurveFiles
		{
			get
			{
				try
				{
					if (this.curveFiles == null)
					{
						this.curveFiles = from d in Directory.GetFiles(Settings.Default.Curve_StoringFIFO_Directory, "*.wcrv")
						orderby new FileInfo(d).CreationTime
						select d;
					}
					this.errorOnWritingCurves = false;
					return this.curveFiles;
				}
				catch (Exception)
				{
					this.errorOnWritingCurves = true;
					return null;
				}
			}
		}

		public void GetNewCurveInfo(string directory)
		{
			try
			{
				this.DirectoryName = directory;
				this.curveFilesUnsorted = Directory.GetFiles(this.DirectoryName, "*.wcrv");
				this.curveFiles = from d in Directory.GetFiles(Settings.Default.Curve_StoringFIFO_Directory, "*.wcrv")
				orderby new FileInfo(d).CreationTime
				select d;
				this.errorOnWritingCurves = false;
			}
			catch (Exception)
			{
				this.errorOnWritingCurves = true;
			}
		}

		public CurveFifoClass(MainForm main)
		{
			this.Main = main;
			this.currentIndex = 0;
		}

		public void ActivateFifo()
		{
		}

		public void GenerateCurve()
		{
			int resultKind = this.Main.CurveDisplay1.CurvePrint1.GetResultKind();
			switch (resultKind)
			{
			case 2:
				if (this.Main.VC.Result.IONIO > 1)
				{
					break;
				}
				goto default;
			default:
				if (resultKind != 1)
				{
					return;
				}
				if (this.Main.VC.Result.IONIO != 1)
				{
					return;
				}
				break;
			case 0:
				break;
			}
			try
			{
				this.Main.CurveDisplay1.AutoSaveCurve(true);
				this.errorOnWritingCurves = false;
			}
			catch (Exception)
			{
				this.errorOnWritingCurves = true;
			}
			try
			{
				this.curveFiles = from d in Directory.GetFiles(Settings.Default.Curve_StoringFIFO_Directory, "*.wcrv")
				orderby new FileInfo(d).CreationTime
				select d;
				if (this.curveFiles.Count() > Settings.Default.Curve_StoringFIFO_maxCount)
				{
					string path = this.curveFiles.ElementAt(0).ToString();
					File.Delete(path);
					this.curveFiles = from d in Directory.GetFiles(Settings.Default.Curve_StoringFIFO_Directory, "*.wcrv")
					orderby new FileInfo(d).CreationTime
					select d;
				}
				this.errorOnWritingCurves = false;
			}
			catch (Exception)
			{
				this.errorOnWritingCurves = true;
			}
		}

		public int Show(int index)
		{
			if (this.curveFiles == null)
			{
				return -1;
			}
			if (index < 0)
			{
				this.currentIndex = 0;
			}
			else if (index >= this.curveFiles.Count())
			{
				this.currentIndex = this.curveFiles.Count() - 1;
			}
			else
			{
				this.currentIndex = index;
			}
			string filename = this.curveFiles.ElementAt(this.currentIndex).ToString();
			if (!this.Main.CurveDisplay1.LoadCurve(filename))
			{
				this.curveFiles = from d in Directory.GetFiles(Settings.Default.Curve_StoringFIFO_Directory, "*.wcrv")
				orderby new FileInfo(d).CreationTime
				select d;
				return -1;
			}
			this.Main.CurveDisplay1.ActualizeData();
			this.Main.CurveDisplay1.C_Curve1.StepInfoIncluded = true;
			TimeSpan timeSpan = DateTime.Now - this.recentPaintAt;
			if (timeSpan < TimeSpan.FromMilliseconds(1000.0))
			{
				Thread.Sleep(timeSpan);
			}
			this.Main.CurveDisplay1.C_Curve1.Repaint(false, false, false);
			this.recentPaintAt = DateTime.Now;
			return this.currentIndex;
		}

		public int Show(string directory, string fileNameWithoutExtension)
		{
			if (fileNameWithoutExtension != null && fileNameWithoutExtension.Length != 0 && directory != null && directory.Length != 0)
			{
				try
				{
					this.DirectoryName = directory;
					string filename = directory + "\\" + fileNameWithoutExtension + ".wcrv";
					TimeSpan t = DateTime.Now - this.recentPaintAt;
					if (!this.Main.CurveDisplay1.LoadCurve(filename))
					{
						if (t < TimeSpan.FromMilliseconds(1000.0))
						{
							Thread.Sleep(700);
						}
						this.Main.CurveDisplay1.C_Curve1.Repaint(false, false, true);
						return -1;
					}
					this.Main.CurveDisplay1.ActualizeData();
					this.Main.CurveDisplay1.C_Curve1.StepInfoIncluded = true;
					if (t < TimeSpan.FromMilliseconds(1000.0))
					{
						Thread.Sleep(700);
					}
					this.Main.CurveDisplay1.C_Curve1.Repaint(false, false, false);
					this.recentPaintAt = DateTime.Now;
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message, "");
				}
				return 0;
			}
			return -1;
		}

		public void ReadCurve()
		{
		}
	}
}
