using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Visualisation
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	[CompilerGenerated]
	[DebuggerNonUserCode]
	internal class LanguageText_en
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(LanguageText_en.resourceMan, null))
				{
					ResourceManager resourceManager = LanguageText_en.resourceMan = new ResourceManager("Visualisation.LanguageText_en", typeof(LanguageText_en).Assembly);
				}
				return LanguageText_en.resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return LanguageText_en.resourceCulture;
			}
			set
			{
				LanguageText_en.resourceCulture = value;
			}
		}

		internal static string Abr_Program => LanguageText_en.ResourceManager.GetString("Abr_Program", LanguageText_en.resourceCulture);

		internal static string AbrAnaDepth => LanguageText_en.ResourceManager.GetString("AbrAnaDepth", LanguageText_en.resourceCulture);

		internal static string AbrAnaSignal => LanguageText_en.ResourceManager.GetString("AbrAnaSignal", LanguageText_en.resourceCulture);

		internal static string AbrAngle => LanguageText_en.ResourceManager.GetString("AbrAngle", LanguageText_en.resourceCulture);

		internal static string AbrDelayTorque => LanguageText_en.ResourceManager.GetString("AbrDelayTorque", LanguageText_en.resourceCulture);

		internal static string AbrDepthGrad => LanguageText_en.ResourceManager.GetString("AbrDepthGrad", LanguageText_en.resourceCulture);

		internal static string AbrFilteredTorque => LanguageText_en.ResourceManager.GetString("AbrFilteredTorque", LanguageText_en.resourceCulture);

		internal static string AbrGradient => LanguageText_en.ResourceManager.GetString("AbrGradient", LanguageText_en.resourceCulture);

		internal static string AbrM360Follow => LanguageText_en.ResourceManager.GetString("AbrM360Follow", LanguageText_en.resourceCulture);

		internal static string AbrMaxTorque => LanguageText_en.ResourceManager.GetString("AbrMaxTorque", LanguageText_en.resourceCulture);

		internal static string AbrNumber => LanguageText_en.ResourceManager.GetString("AbrNumber", LanguageText_en.resourceCulture);

		internal static string AbrTime => LanguageText_en.ResourceManager.GetString("AbrTime", LanguageText_en.resourceCulture);

		internal static string AbrTorque => LanguageText_en.ResourceManager.GetString("AbrTorque", LanguageText_en.resourceCulture);

		internal static string AccessCheck => LanguageText_en.ResourceManager.GetString("AccessCheck", LanguageText_en.resourceCulture);

		internal static string AccessRequest => LanguageText_en.ResourceManager.GetString("AccessRequest", LanguageText_en.resourceCulture);

		internal static string Actualize => LanguageText_en.ResourceManager.GetString("Actualize", LanguageText_en.resourceCulture);

		internal static string AddEntry => LanguageText_en.ResourceManager.GetString("AddEntry", LanguageText_en.resourceCulture);

		internal static string AIError => LanguageText_en.ResourceManager.GetString("AIError", LanguageText_en.resourceCulture);

		internal static string All => LanguageText_en.ResourceManager.GetString("All", LanguageText_en.resourceCulture);

		internal static string AllFiles => LanguageText_en.ResourceManager.GetString("AllFiles", LanguageText_en.resourceCulture);

		internal static string AnaDepth => LanguageText_en.ResourceManager.GetString("AnaDepth", LanguageText_en.resourceCulture);

		internal static string Analysis => LanguageText_en.ResourceManager.GetString("Analysis", LanguageText_en.resourceCulture);

		internal static string AnaOutput => LanguageText_en.ResourceManager.GetString("AnaOutput", LanguageText_en.resourceCulture);

		internal static string AnaSignal => LanguageText_en.ResourceManager.GetString("AnaSignal", LanguageText_en.resourceCulture);

		internal static string AnaSigOffset => LanguageText_en.ResourceManager.GetString("AnaSigOffset", LanguageText_en.resourceCulture);

		internal static string AnaSigScale => LanguageText_en.ResourceManager.GetString("AnaSigScale", LanguageText_en.resourceCulture);

		internal static string Angle => LanguageText_en.ResourceManager.GetString("Angle", LanguageText_en.resourceCulture);

		internal static string AngleRedundantTolerance => LanguageText_en.ResourceManager.GetString("AngleRedundantTolerance", LanguageText_en.resourceCulture);

		internal static string AngleSensorInvers => LanguageText_en.ResourceManager.GetString("AngleSensorInvers", LanguageText_en.resourceCulture);

		internal static string AngleSensorScale => LanguageText_en.ResourceManager.GetString("AngleSensorScale", LanguageText_en.resourceCulture);

		internal static string AngleTorqueSensor => LanguageText_en.ResourceManager.GetString("AngleTorqueSensor", LanguageText_en.resourceCulture);

		internal static string Apply => LanguageText_en.ResourceManager.GetString("Apply", LanguageText_en.resourceCulture);

		internal static string ApplyEntry => LanguageText_en.ResourceManager.GetString("ApplyEntry", LanguageText_en.resourceCulture);

		internal static string AutoCurveAbort => LanguageText_en.ResourceManager.GetString("AutoCurveAbort", LanguageText_en.resourceCulture);

		internal static string Automatic => LanguageText_en.ResourceManager.GetString("Automatic", LanguageText_en.resourceCulture);

		internal static string AutoMode => LanguageText_en.ResourceManager.GetString("AutoMode", LanguageText_en.resourceCulture);

		internal static string AvailableValueNumber => LanguageText_en.ResourceManager.GetString("AvailableValueNumber", LanguageText_en.resourceCulture);

		internal static string Back => LanguageText_en.ResourceManager.GetString("Back", LanguageText_en.resourceCulture);

		internal static string Backup => LanguageText_en.ResourceManager.GetString("Backup", LanguageText_en.resourceCulture);

		internal static string Backup205000 => LanguageText_en.ResourceManager.GetString("Backup205000", LanguageText_en.resourceCulture);

		internal static string Backup205001 => LanguageText_en.ResourceManager.GetString("Backup205001", LanguageText_en.resourceCulture);

		internal static string Backup205002 => LanguageText_en.ResourceManager.GetString("Backup205002", LanguageText_en.resourceCulture);

		internal static string Backup205003 => LanguageText_en.ResourceManager.GetString("Backup205003", LanguageText_en.resourceCulture);

		internal static string Battery => LanguageText_en.ResourceManager.GetString("Battery", LanguageText_en.resourceCulture);

		internal static string Baudrate => LanguageText_en.ResourceManager.GetString("Baudrate", LanguageText_en.resourceCulture);

		internal static string bt0 => LanguageText_en.ResourceManager.GetString("bt0", LanguageText_en.resourceCulture);

		internal static string bt1 => LanguageText_en.ResourceManager.GetString("bt1", LanguageText_en.resourceCulture);

		internal static string bt2 => LanguageText_en.ResourceManager.GetString("bt2", LanguageText_en.resourceCulture);

		internal static string bt3 => LanguageText_en.ResourceManager.GetString("bt3", LanguageText_en.resourceCulture);

		internal static string bt4 => LanguageText_en.ResourceManager.GetString("bt4", LanguageText_en.resourceCulture);

		internal static string bt5 => LanguageText_en.ResourceManager.GetString("bt5", LanguageText_en.resourceCulture);

		internal static string bt6 => LanguageText_en.ResourceManager.GetString("bt6", LanguageText_en.resourceCulture);

		internal static string bt7 => LanguageText_en.ResourceManager.GetString("bt7", LanguageText_en.resourceCulture);

		internal static string bt8 => LanguageText_en.ResourceManager.GetString("bt8", LanguageText_en.resourceCulture);

		internal static string bt9 => LanguageText_en.ResourceManager.GetString("bt9", LanguageText_en.resourceCulture);

		internal static string btA => LanguageText_en.ResourceManager.GetString("btA", LanguageText_en.resourceCulture);

		internal static string btApply => LanguageText_en.ResourceManager.GetString("btApply", LanguageText_en.resourceCulture);

		internal static string btB => LanguageText_en.ResourceManager.GetString("btB", LanguageText_en.resourceCulture);

		internal static string btBackspace => LanguageText_en.ResourceManager.GetString("btBackspace", LanguageText_en.resourceCulture);

		internal static string btC => LanguageText_en.ResourceManager.GetString("btC", LanguageText_en.resourceCulture);

		internal static string btCancel => LanguageText_en.ResourceManager.GetString("btCancel", LanguageText_en.resourceCulture);

		internal static string btChangeDefaultDir => LanguageText_en.ResourceManager.GetString("btChangeDefaultDir", LanguageText_en.resourceCulture);

		internal static string btD => LanguageText_en.ResourceManager.GetString("btD", LanguageText_en.resourceCulture);

		internal static string btE => LanguageText_en.ResourceManager.GetString("btE", LanguageText_en.resourceCulture);

		internal static string btErase => LanguageText_en.ResourceManager.GetString("btErase", LanguageText_en.resourceCulture);

		internal static string btF => LanguageText_en.ResourceManager.GetString("btF", LanguageText_en.resourceCulture);

		internal static string btG => LanguageText_en.ResourceManager.GetString("btG", LanguageText_en.resourceCulture);

		internal static string btH => LanguageText_en.ResourceManager.GetString("btH", LanguageText_en.resourceCulture);

		internal static string btI => LanguageText_en.ResourceManager.GetString("btI", LanguageText_en.resourceCulture);

		internal static string btJ => LanguageText_en.ResourceManager.GetString("btJ", LanguageText_en.resourceCulture);

		internal static string btK => LanguageText_en.ResourceManager.GetString("btK", LanguageText_en.resourceCulture);

		internal static string btL => LanguageText_en.ResourceManager.GetString("btL", LanguageText_en.resourceCulture);

		internal static string btLoad => LanguageText_en.ResourceManager.GetString("btLoad", LanguageText_en.resourceCulture);

		internal static string btM => LanguageText_en.ResourceManager.GetString("btM", LanguageText_en.resourceCulture);

		internal static string btMinusDown => LanguageText_en.ResourceManager.GetString("btMinusDown", LanguageText_en.resourceCulture);

		internal static string btMinusUp => LanguageText_en.ResourceManager.GetString("btMinusUp", LanguageText_en.resourceCulture);

		internal static string btN => LanguageText_en.ResourceManager.GetString("btN", LanguageText_en.resourceCulture);

		internal static string btO => LanguageText_en.ResourceManager.GetString("btO", LanguageText_en.resourceCulture);

		internal static string btP => LanguageText_en.ResourceManager.GetString("btP", LanguageText_en.resourceCulture);

		internal static string btQ => LanguageText_en.ResourceManager.GetString("btQ", LanguageText_en.resourceCulture);

		internal static string btR => LanguageText_en.ResourceManager.GetString("btR", LanguageText_en.resourceCulture);

		internal static string btRes1 => LanguageText_en.ResourceManager.GetString("btRes1", LanguageText_en.resourceCulture);

		internal static string btRes2 => LanguageText_en.ResourceManager.GetString("btRes2", LanguageText_en.resourceCulture);

		internal static string btRes3 => LanguageText_en.ResourceManager.GetString("btRes3", LanguageText_en.resourceCulture);

		internal static string btS => LanguageText_en.ResourceManager.GetString("btS", LanguageText_en.resourceCulture);

		internal static string btShift => LanguageText_en.ResourceManager.GetString("btShift", LanguageText_en.resourceCulture);

		internal static string btSpace => LanguageText_en.ResourceManager.GetString("btSpace", LanguageText_en.resourceCulture);

		internal static string btT => LanguageText_en.ResourceManager.GetString("btT", LanguageText_en.resourceCulture);

		internal static string btTeach => LanguageText_en.ResourceManager.GetString("btTeach", LanguageText_en.resourceCulture);

		internal static string btU => LanguageText_en.ResourceManager.GetString("btU", LanguageText_en.resourceCulture);

		internal static string btV => LanguageText_en.ResourceManager.GetString("btV", LanguageText_en.resourceCulture);

		internal static string btW => LanguageText_en.ResourceManager.GetString("btW", LanguageText_en.resourceCulture);

		internal static string btX => LanguageText_en.ResourceManager.GetString("btX", LanguageText_en.resourceCulture);

		internal static string btY => LanguageText_en.ResourceManager.GetString("btY", LanguageText_en.resourceCulture);

		internal static string btZ => LanguageText_en.ResourceManager.GetString("btZ", LanguageText_en.resourceCulture);

		internal static string CalculateCurves => LanguageText_en.ResourceManager.GetString("CalculateCurves", LanguageText_en.resourceCulture);

		internal static string CalDisable => LanguageText_en.ResourceManager.GetString("CalDisable", LanguageText_en.resourceCulture);

		internal static string CalibrationSignal => LanguageText_en.ResourceManager.GetString("CalibrationSignal", LanguageText_en.resourceCulture);

		internal static string Cancel => LanguageText_en.ResourceManager.GetString("Cancel", LanguageText_en.resourceCulture);

		internal static string Changed => LanguageText_en.ResourceManager.GetString("Changed", LanguageText_en.resourceCulture);

		internal static string ChangeEntry => LanguageText_en.ResourceManager.GetString("ChangeEntry", LanguageText_en.resourceCulture);

		internal static string ChangesLog => LanguageText_en.ResourceManager.GetString("ChangesLog", LanguageText_en.resourceCulture);

		internal static string chBEmtyPrograms => LanguageText_en.ResourceManager.GetString("chBEmtyPrograms", LanguageText_en.resourceCulture);

		internal static string chBProgPreview => LanguageText_en.ResourceManager.GetString("chBProgPreview", LanguageText_en.resourceCulture);

		internal static string chBUseDefaultDir => LanguageText_en.ResourceManager.GetString("chBUseDefaultDir", LanguageText_en.resourceCulture);

		internal static string CheckFrictionTestStart => LanguageText_en.ResourceManager.GetString("CheckFrictionTestStart", LanguageText_en.resourceCulture);

		internal static string CheckHandStart => LanguageText_en.ResourceManager.GetString("CheckHandStart", LanguageText_en.resourceCulture);

		internal static string CheckParameter => LanguageText_en.ResourceManager.GetString("CheckParameter", LanguageText_en.resourceCulture);

		internal static string CheckRight => LanguageText_en.ResourceManager.GetString("CheckRight", LanguageText_en.resourceCulture);

		internal static string Close => LanguageText_en.ResourceManager.GetString("Close", LanguageText_en.resourceCulture);

		internal static string ControllerName => LanguageText_en.ResourceManager.GetString("ControllerName", LanguageText_en.resourceCulture);

		internal static string ControllerTime => LanguageText_en.ResourceManager.GetString("ControllerTime", LanguageText_en.resourceCulture);

		internal static string CopyProgram => LanguageText_en.ResourceManager.GetString("CopyProgram", LanguageText_en.resourceCulture);

		internal static string CountPassMax => LanguageText_en.ResourceManager.GetString("CountPassMax", LanguageText_en.resourceCulture);

		internal static string CreatedUsers => LanguageText_en.ResourceManager.GetString("CreatedUsers", LanguageText_en.resourceCulture);

		internal static string CumulStats => LanguageText_en.ResourceManager.GetString("CumulStats", LanguageText_en.resourceCulture);

		internal static string CursorsCannotSwitch => LanguageText_en.ResourceManager.GetString("CursorsCannotSwitch", LanguageText_en.resourceCulture);

		internal static string CurveDisplay => LanguageText_en.ResourceManager.GetString("CurveDisplay", LanguageText_en.resourceCulture);

		internal static string CurveLoad => LanguageText_en.ResourceManager.GetString("CurveLoad", LanguageText_en.resourceCulture);

		internal static string CurvePrint => LanguageText_en.ResourceManager.GetString("CurvePrint", LanguageText_en.resourceCulture);

		internal static string CurveResultKind => LanguageText_en.ResourceManager.GetString("CurveResultKind", LanguageText_en.resourceCulture);

		internal static string CurveResultNumber => LanguageText_en.ResourceManager.GetString("CurveResultNumber", LanguageText_en.resourceCulture);

		internal static string CurveSave => LanguageText_en.ResourceManager.GetString("CurveSave", LanguageText_en.resourceCulture);

		internal static string CurveSelection => LanguageText_en.ResourceManager.GetString("CurveSelection", LanguageText_en.resourceCulture);

		internal static string CurvesZoomedIn => LanguageText_en.ResourceManager.GetString("CurvesZoomedIn", LanguageText_en.resourceCulture);

		internal static string CurvesZoomedOut => LanguageText_en.ResourceManager.GetString("CurvesZoomedOut", LanguageText_en.resourceCulture);

		internal static string CustomCounter => LanguageText_en.ResourceManager.GetString("CustomCounter", LanguageText_en.resourceCulture);

		internal static string Cycle => LanguageText_en.ResourceManager.GetString("Cycle", LanguageText_en.resourceCulture);

		internal static string CycleCounter => LanguageText_en.ResourceManager.GetString("CycleCounter", LanguageText_en.resourceCulture);

		internal static string CycleNumber => LanguageText_en.ResourceManager.GetString("CycleNumber", LanguageText_en.resourceCulture);

		internal static string CycleSave => LanguageText_en.ResourceManager.GetString("CycleSave", LanguageText_en.resourceCulture);

		internal static string Czech => LanguageText_en.ResourceManager.GetString("Czech", LanguageText_en.resourceCulture);

		internal static string DateTime => LanguageText_en.ResourceManager.GetString("DateTime", LanguageText_en.resourceCulture);

		internal static string DeblockController => LanguageText_en.ResourceManager.GetString("DeblockController", LanguageText_en.resourceCulture);

		internal static string DeclForSpSave => LanguageText_en.ResourceManager.GetString("DeclForSpSave", LanguageText_en.resourceCulture);

		internal static string Degree => LanguageText_en.ResourceManager.GetString("Degree", LanguageText_en.resourceCulture);

		internal static string DelayTorque => LanguageText_en.ResourceManager.GetString("DelayTorque", LanguageText_en.resourceCulture);

		internal static string DeleteCounter => LanguageText_en.ResourceManager.GetString("DeleteCounter", LanguageText_en.resourceCulture);

		internal static string DeleteCustomCounter => LanguageText_en.ResourceManager.GetString("DeleteCustomCounter", LanguageText_en.resourceCulture);

		internal static string DeleteEntry => LanguageText_en.ResourceManager.GetString("DeleteEntry", LanguageText_en.resourceCulture);

		internal static string DeleteJob => LanguageText_en.ResourceManager.GetString("DeleteJob", LanguageText_en.resourceCulture);

		internal static string DeleteLastResults => LanguageText_en.ResourceManager.GetString("DeleteLastResults", LanguageText_en.resourceCulture);

		internal static string DeleteProgram => LanguageText_en.ResourceManager.GetString("DeleteProgram", LanguageText_en.resourceCulture);

		internal static string DeleteRecursiveStat => LanguageText_en.ResourceManager.GetString("DeleteRecursiveStat", LanguageText_en.resourceCulture);

		internal static string DeleteStep => LanguageText_en.ResourceManager.GetString("DeleteStep", LanguageText_en.resourceCulture);

		internal static string DeleteValues => LanguageText_en.ResourceManager.GetString("DeleteValues", LanguageText_en.resourceCulture);

		internal static string DepthFilterTime => LanguageText_en.ResourceManager.GetString("DepthFilterTime", LanguageText_en.resourceCulture);

		internal static string DepthGrad => LanguageText_en.ResourceManager.GetString("DepthGrad", LanguageText_en.resourceCulture);

		internal static string DepthGradLength => LanguageText_en.ResourceManager.GetString("DepthGradLength", LanguageText_en.resourceCulture);

		internal static string DepthSensor => LanguageText_en.ResourceManager.GetString("DepthSensor", LanguageText_en.resourceCulture);

		internal static string DepthSensorInvers => LanguageText_en.ResourceManager.GetString("DepthSensorInvers", LanguageText_en.resourceCulture);

		internal static string DGAddress => LanguageText_en.ResourceManager.GetString("DGAddress", LanguageText_en.resourceCulture);

		internal static string DHCP => LanguageText_en.ResourceManager.GetString("DHCP", LanguageText_en.resourceCulture);

		internal static string DigitalSignal => LanguageText_en.ResourceManager.GetString("DigitalSignal", LanguageText_en.resourceCulture);

		internal static string DigitOut => LanguageText_en.ResourceManager.GetString("DigitOut", LanguageText_en.resourceCulture);

		internal static string DigSigAtEnd => LanguageText_en.ResourceManager.GetString("DigSigAtEnd", LanguageText_en.resourceCulture);

		internal static string DigSigRunning => LanguageText_en.ResourceManager.GetString("DigSigRunning", LanguageText_en.resourceCulture);

		internal static string DiscardChanges => LanguageText_en.ResourceManager.GetString("DiscardChanges", LanguageText_en.resourceCulture);

		internal static string Done => LanguageText_en.ResourceManager.GetString("Done", LanguageText_en.resourceCulture);

		internal static string DriveUnit => LanguageText_en.ResourceManager.GetString("DriveUnit", LanguageText_en.resourceCulture);

		internal static string DriveUnitInvers => LanguageText_en.ResourceManager.GetString("DriveUnitInvers", LanguageText_en.resourceCulture);

		internal static string Driving => LanguageText_en.ResourceManager.GetString("Driving", LanguageText_en.resourceCulture);

		internal static string DrivingStep => LanguageText_en.ResourceManager.GetString("DrivingStep", LanguageText_en.resourceCulture);

		internal static string EditCancel => LanguageText_en.ResourceManager.GetString("EditCancel", LanguageText_en.resourceCulture);

		internal static string EditEntry => LanguageText_en.ResourceManager.GetString("EditEntry", LanguageText_en.resourceCulture);

		internal static string EditProgram => LanguageText_en.ResourceManager.GetString("EditProgram", LanguageText_en.resourceCulture);

		internal static string EditStep => LanguageText_en.ResourceManager.GetString("EditStep", LanguageText_en.resourceCulture);

		internal static string EMGMode => LanguageText_en.ResourceManager.GetString("EMGMode", LanguageText_en.resourceCulture);

		internal static string Empty => LanguageText_en.ResourceManager.GetString("Empty", LanguageText_en.resourceCulture);

		internal static string EmptyString => LanguageText_en.ResourceManager.GetString("EmptyString", LanguageText_en.resourceCulture);

		internal static string EncError => LanguageText_en.ResourceManager.GetString("EncError", LanguageText_en.resourceCulture);

		internal static string English => LanguageText_en.ResourceManager.GetString("English", LanguageText_en.resourceCulture);

		internal static string Error1000 => LanguageText_en.ResourceManager.GetString("Error1000", LanguageText_en.resourceCulture);

		internal static string Error1001 => LanguageText_en.ResourceManager.GetString("Error1001", LanguageText_en.resourceCulture);

		internal static string Error1002 => LanguageText_en.ResourceManager.GetString("Error1002", LanguageText_en.resourceCulture);

		internal static string Error1003 => LanguageText_en.ResourceManager.GetString("Error1003", LanguageText_en.resourceCulture);

		internal static string Error1004 => LanguageText_en.ResourceManager.GetString("Error1004", LanguageText_en.resourceCulture);

		internal static string Error1005 => LanguageText_en.ResourceManager.GetString("Error1005", LanguageText_en.resourceCulture);

		internal static string Error1006 => LanguageText_en.ResourceManager.GetString("Error1006", LanguageText_en.resourceCulture);

		internal static string Error1007 => LanguageText_en.ResourceManager.GetString("Error1007", LanguageText_en.resourceCulture);

		internal static string Error1008 => LanguageText_en.ResourceManager.GetString("Error1008", LanguageText_en.resourceCulture);

		internal static string Error1009 => LanguageText_en.ResourceManager.GetString("Error1009", LanguageText_en.resourceCulture);

		internal static string Error1010 => LanguageText_en.ResourceManager.GetString("Error1010", LanguageText_en.resourceCulture);

		internal static string Error1011 => LanguageText_en.ResourceManager.GetString("Error1011", LanguageText_en.resourceCulture);

		internal static string Error1012 => LanguageText_en.ResourceManager.GetString("Error1012", LanguageText_en.resourceCulture);

		internal static string Error1013 => LanguageText_en.ResourceManager.GetString("Error1013", LanguageText_en.resourceCulture);

		internal static string Error1014 => LanguageText_en.ResourceManager.GetString("Error1014", LanguageText_en.resourceCulture);

		internal static string Error1015 => LanguageText_en.ResourceManager.GetString("Error1015", LanguageText_en.resourceCulture);

		internal static string Error1016 => LanguageText_en.ResourceManager.GetString("Error1016", LanguageText_en.resourceCulture);

		internal static string Error1017 => LanguageText_en.ResourceManager.GetString("Error1017", LanguageText_en.resourceCulture);

		internal static string Error1018 => LanguageText_en.ResourceManager.GetString("Error1018", LanguageText_en.resourceCulture);

		internal static string Error1019 => LanguageText_en.ResourceManager.GetString("Error1019", LanguageText_en.resourceCulture);

		internal static string Error1020 => LanguageText_en.ResourceManager.GetString("Error1020", LanguageText_en.resourceCulture);

		internal static string Error1021 => LanguageText_en.ResourceManager.GetString("Error1021", LanguageText_en.resourceCulture);

		internal static string Error1022 => LanguageText_en.ResourceManager.GetString("Error1022", LanguageText_en.resourceCulture);

		internal static string Error1023 => LanguageText_en.ResourceManager.GetString("Error1023", LanguageText_en.resourceCulture);

		internal static string Error1024 => LanguageText_en.ResourceManager.GetString("Error1024", LanguageText_en.resourceCulture);

		internal static string Error1025 => LanguageText_en.ResourceManager.GetString("Error1025", LanguageText_en.resourceCulture);

		internal static string Error1026 => LanguageText_en.ResourceManager.GetString("Error1026", LanguageText_en.resourceCulture);

		internal static string Error1027 => LanguageText_en.ResourceManager.GetString("Error1027", LanguageText_en.resourceCulture);

		internal static string Error1028 => LanguageText_en.ResourceManager.GetString("Error1028", LanguageText_en.resourceCulture);

		internal static string Error1029 => LanguageText_en.ResourceManager.GetString("Error1029", LanguageText_en.resourceCulture);

		internal static string Error1030 => LanguageText_en.ResourceManager.GetString("Error1030", LanguageText_en.resourceCulture);

		internal static string Error1031 => LanguageText_en.ResourceManager.GetString("Error1031", LanguageText_en.resourceCulture);

		internal static string Error1032 => LanguageText_en.ResourceManager.GetString("Error1032", LanguageText_en.resourceCulture);

		internal static string Error1033 => LanguageText_en.ResourceManager.GetString("Error1033", LanguageText_en.resourceCulture);

		internal static string Error1034 => LanguageText_en.ResourceManager.GetString("Error1034", LanguageText_en.resourceCulture);

		internal static string Error1035 => LanguageText_en.ResourceManager.GetString("Error1035", LanguageText_en.resourceCulture);

		internal static string Error1036 => LanguageText_en.ResourceManager.GetString("Error1036", LanguageText_en.resourceCulture);

		internal static string Error1037 => LanguageText_en.ResourceManager.GetString("Error1037", LanguageText_en.resourceCulture);

		internal static string Error1038 => LanguageText_en.ResourceManager.GetString("Error1038", LanguageText_en.resourceCulture);

		internal static string Error1100 => LanguageText_en.ResourceManager.GetString("Error1100", LanguageText_en.resourceCulture);

		internal static string Error1101 => LanguageText_en.ResourceManager.GetString("Error1101", LanguageText_en.resourceCulture);

		internal static string Error1102 => LanguageText_en.ResourceManager.GetString("Error1102", LanguageText_en.resourceCulture);

		internal static string Error1110 => LanguageText_en.ResourceManager.GetString("Error1110", LanguageText_en.resourceCulture);

		internal static string Error1111 => LanguageText_en.ResourceManager.GetString("Error1111", LanguageText_en.resourceCulture);

		internal static string Error1112 => LanguageText_en.ResourceManager.GetString("Error1112", LanguageText_en.resourceCulture);

		internal static string Error1113 => LanguageText_en.ResourceManager.GetString("Error1113", LanguageText_en.resourceCulture);

		internal static string Error1114 => LanguageText_en.ResourceManager.GetString("Error1114", LanguageText_en.resourceCulture);

		internal static string Error1140 => LanguageText_en.ResourceManager.GetString("Error1140", LanguageText_en.resourceCulture);

		internal static string Error1141 => LanguageText_en.ResourceManager.GetString("Error1141", LanguageText_en.resourceCulture);

		internal static string Error1150 => LanguageText_en.ResourceManager.GetString("Error1150", LanguageText_en.resourceCulture);

		internal static string Error1151 => LanguageText_en.ResourceManager.GetString("Error1151", LanguageText_en.resourceCulture);

		internal static string Error1152 => LanguageText_en.ResourceManager.GetString("Error1152", LanguageText_en.resourceCulture);

		internal static string Error1153 => LanguageText_en.ResourceManager.GetString("Error1153", LanguageText_en.resourceCulture);

		internal static string Error1160 => LanguageText_en.ResourceManager.GetString("Error1160", LanguageText_en.resourceCulture);

		internal static string Error1161 => LanguageText_en.ResourceManager.GetString("Error1161", LanguageText_en.resourceCulture);

		internal static string Error1162 => LanguageText_en.ResourceManager.GetString("Error1162", LanguageText_en.resourceCulture);

		internal static string Error1163 => LanguageText_en.ResourceManager.GetString("Error1163", LanguageText_en.resourceCulture);

		internal static string Error1200 => LanguageText_en.ResourceManager.GetString("Error1200", LanguageText_en.resourceCulture);

		internal static string Error1201 => LanguageText_en.ResourceManager.GetString("Error1201", LanguageText_en.resourceCulture);

		internal static string Error1202 => LanguageText_en.ResourceManager.GetString("Error1202", LanguageText_en.resourceCulture);

		internal static string Error1203 => LanguageText_en.ResourceManager.GetString("Error1203", LanguageText_en.resourceCulture);

		internal static string Error1301 => LanguageText_en.ResourceManager.GetString("Error1301", LanguageText_en.resourceCulture);

		internal static string Error1302 => LanguageText_en.ResourceManager.GetString("Error1302", LanguageText_en.resourceCulture);

		internal static string Error1303 => LanguageText_en.ResourceManager.GetString("Error1303", LanguageText_en.resourceCulture);

		internal static string Error1304 => LanguageText_en.ResourceManager.GetString("Error1304", LanguageText_en.resourceCulture);

		internal static string Error1305 => LanguageText_en.ResourceManager.GetString("Error1305", LanguageText_en.resourceCulture);

		internal static string Error1400 => LanguageText_en.ResourceManager.GetString("Error1400", LanguageText_en.resourceCulture);

		internal static string Error1401 => LanguageText_en.ResourceManager.GetString("Error1401", LanguageText_en.resourceCulture);

		internal static string Error1402 => LanguageText_en.ResourceManager.GetString("Error1402", LanguageText_en.resourceCulture);

		internal static string Error1403 => LanguageText_en.ResourceManager.GetString("Error1403", LanguageText_en.resourceCulture);

		internal static string Error1404 => LanguageText_en.ResourceManager.GetString("Error1404", LanguageText_en.resourceCulture);

		internal static string Error1405 => LanguageText_en.ResourceManager.GetString("Error1405", LanguageText_en.resourceCulture);

		internal static string Error1406 => LanguageText_en.ResourceManager.GetString("Error1406", LanguageText_en.resourceCulture);

		internal static string Error1407 => LanguageText_en.ResourceManager.GetString("Error1407", LanguageText_en.resourceCulture);

		internal static string Error1450 => LanguageText_en.ResourceManager.GetString("Error1450", LanguageText_en.resourceCulture);

		internal static string Error1451 => LanguageText_en.ResourceManager.GetString("Error1451", LanguageText_en.resourceCulture);

		internal static string Error1600 => LanguageText_en.ResourceManager.GetString("Error1600", LanguageText_en.resourceCulture);

		internal static string Error1601 => LanguageText_en.ResourceManager.GetString("Error1601", LanguageText_en.resourceCulture);

		internal static string Error1602 => LanguageText_en.ResourceManager.GetString("Error1602", LanguageText_en.resourceCulture);

		internal static string Error2000 => LanguageText_en.ResourceManager.GetString("Error2000", LanguageText_en.resourceCulture);

		internal static string Error2001 => LanguageText_en.ResourceManager.GetString("Error2001", LanguageText_en.resourceCulture);

		internal static string Error2002 => LanguageText_en.ResourceManager.GetString("Error2002", LanguageText_en.resourceCulture);

		internal static string Error2003 => LanguageText_en.ResourceManager.GetString("Error2003", LanguageText_en.resourceCulture);

		internal static string Error2004 => LanguageText_en.ResourceManager.GetString("Error2004", LanguageText_en.resourceCulture);

		internal static string Error2005 => LanguageText_en.ResourceManager.GetString("Error2005", LanguageText_en.resourceCulture);

		internal static string Error2006 => LanguageText_en.ResourceManager.GetString("Error2006", LanguageText_en.resourceCulture);

		internal static string Error2007 => LanguageText_en.ResourceManager.GetString("Error2007", LanguageText_en.resourceCulture);

		internal static string Error2008 => LanguageText_en.ResourceManager.GetString("Error2008", LanguageText_en.resourceCulture);

		internal static string Error2009 => LanguageText_en.ResourceManager.GetString("Error2009", LanguageText_en.resourceCulture);

		internal static string Error2010 => LanguageText_en.ResourceManager.GetString("Error2010", LanguageText_en.resourceCulture);

		internal static string Error2011 => LanguageText_en.ResourceManager.GetString("Error2011", LanguageText_en.resourceCulture);

		internal static string Error2012 => LanguageText_en.ResourceManager.GetString("Error2012", LanguageText_en.resourceCulture);

		internal static string Error2013 => LanguageText_en.ResourceManager.GetString("Error2013", LanguageText_en.resourceCulture);

		internal static string Error2014 => LanguageText_en.ResourceManager.GetString("Error2014", LanguageText_en.resourceCulture);

		internal static string Error2015 => LanguageText_en.ResourceManager.GetString("Error2015", LanguageText_en.resourceCulture);

		internal static string Error2016 => LanguageText_en.ResourceManager.GetString("Error2016", LanguageText_en.resourceCulture);

		internal static string Error2017 => LanguageText_en.ResourceManager.GetString("Error2017", LanguageText_en.resourceCulture);

		internal static string Error2018 => LanguageText_en.ResourceManager.GetString("Error2018", LanguageText_en.resourceCulture);

		internal static string Error2019 => LanguageText_en.ResourceManager.GetString("Error2019", LanguageText_en.resourceCulture);

		internal static string Error2020 => LanguageText_en.ResourceManager.GetString("Error2020", LanguageText_en.resourceCulture);

		internal static string Error2021 => LanguageText_en.ResourceManager.GetString("Error2021", LanguageText_en.resourceCulture);

		internal static string Error2022 => LanguageText_en.ResourceManager.GetString("Error2022", LanguageText_en.resourceCulture);

		internal static string Error2100 => LanguageText_en.ResourceManager.GetString("Error2100", LanguageText_en.resourceCulture);

		internal static string Error5000 => LanguageText_en.ResourceManager.GetString("Error5000", LanguageText_en.resourceCulture);

		internal static string ErrorCode => LanguageText_en.ResourceManager.GetString("ErrorCode", LanguageText_en.resourceCulture);

		internal static string ErrorLog => LanguageText_en.ResourceManager.GetString("ErrorLog", LanguageText_en.resourceCulture);

		internal static string ErrorMode => LanguageText_en.ResourceManager.GetString("ErrorMode", LanguageText_en.resourceCulture);

		internal static string ErrorNumber => LanguageText_en.ResourceManager.GetString("ErrorNumber", LanguageText_en.resourceCulture);

		internal static string ErrorQuitEMG => LanguageText_en.ResourceManager.GetString("ErrorQuitEMG", LanguageText_en.resourceCulture);

		internal static string EuropeanTime => LanguageText_en.ResourceManager.GetString("EuropeanTime", LanguageText_en.resourceCulture);

		internal static string Even => LanguageText_en.ResourceManager.GetString("Even", LanguageText_en.resourceCulture);

		internal static string Exit => LanguageText_en.ResourceManager.GetString("Exit", LanguageText_en.resourceCulture);

		internal static string Export => LanguageText_en.ResourceManager.GetString("Export", LanguageText_en.resourceCulture);

		internal static string ExportLastResults => LanguageText_en.ResourceManager.GetString("ExportLastResults", LanguageText_en.resourceCulture);

		internal static string ExportLogbook => LanguageText_en.ResourceManager.GetString("ExportLogbook", LanguageText_en.resourceCulture);

		internal static string FileOperation => LanguageText_en.ResourceManager.GetString("FileOperation", LanguageText_en.resourceCulture);

		internal static string FileOperationMenu => LanguageText_en.ResourceManager.GetString("FileOperationMenu", LanguageText_en.resourceCulture);

		internal static string FilteredTorque => LanguageText_en.ResourceManager.GetString("FilteredTorque", LanguageText_en.resourceCulture);

		internal static string Finalizing => LanguageText_en.ResourceManager.GetString("Finalizing", LanguageText_en.resourceCulture);

		internal static string FinalizingStep => LanguageText_en.ResourceManager.GetString("FinalizingStep", LanguageText_en.resourceCulture);

		internal static string ForceSignals => LanguageText_en.ResourceManager.GetString("ForceSignals", LanguageText_en.resourceCulture);

		internal static string French => LanguageText_en.ResourceManager.GetString("French", LanguageText_en.resourceCulture);

		internal static string FrictionSpeed => LanguageText_en.ResourceManager.GetString("FrictionSpeed", LanguageText_en.resourceCulture);

		internal static string FrictionTest => LanguageText_en.ResourceManager.GetString("FrictionTest", LanguageText_en.resourceCulture);

		internal static string FrictionTestEMG => LanguageText_en.ResourceManager.GetString("FrictionTestEMG", LanguageText_en.resourceCulture);

		internal static string FrictionTestStartup => LanguageText_en.ResourceManager.GetString("FrictionTestStartup", LanguageText_en.resourceCulture);

		internal static string FrictionTorque => LanguageText_en.ResourceManager.GetString("FrictionTorque", LanguageText_en.resourceCulture);

		internal static string FromAbove => LanguageText_en.ResourceManager.GetString("FromAbove", LanguageText_en.resourceCulture);

		internal static string FromAboveOverload => LanguageText_en.ResourceManager.GetString("FromAboveOverload", LanguageText_en.resourceCulture);

		internal static string gBAnaSignal => LanguageText_en.ResourceManager.GetString("gBAnaSignal", LanguageText_en.resourceCulture);

		internal static string gBDateTime => LanguageText_en.ResourceManager.GetString("gBDateTime", LanguageText_en.resourceCulture);

		internal static string gBError => LanguageText_en.ResourceManager.GetString("gBError", LanguageText_en.resourceCulture);

		internal static string gBIdentity => LanguageText_en.ResourceManager.GetString("gBIdentity", LanguageText_en.resourceCulture);

		internal static string gBIP => LanguageText_en.ResourceManager.GetString("gBIP", LanguageText_en.resourceCulture);

		internal static string gBLoadBackup => LanguageText_en.ResourceManager.GetString("gBLoadBackup", LanguageText_en.resourceCulture);

		internal static string gBPressure => LanguageText_en.ResourceManager.GetString("gBPressure", LanguageText_en.resourceCulture);

		internal static string gBRedundantSensor => LanguageText_en.ResourceManager.GetString("gBRedundantSensor", LanguageText_en.resourceCulture);

		internal static string gBResultDisplay => LanguageText_en.ResourceManager.GetString("gBResultDisplay", LanguageText_en.resourceCulture);

		internal static string gBRs232 => LanguageText_en.ResourceManager.GetString("gBRs232", LanguageText_en.resourceCulture);

		internal static string gBSaveBackup => LanguageText_en.ResourceManager.GetString("gBSaveBackup", LanguageText_en.resourceCulture);

		internal static string gBSpindle => LanguageText_en.ResourceManager.GetString("gBSpindle", LanguageText_en.resourceCulture);

		internal static string GearFactor => LanguageText_en.ResourceManager.GetString("GearFactor", LanguageText_en.resourceCulture);

		internal static string German => LanguageText_en.ResourceManager.GetString("German", LanguageText_en.resourceCulture);

		internal static string GetCurve => LanguageText_en.ResourceManager.GetString("GetCurve", LanguageText_en.resourceCulture);

		internal static string GetRpm => LanguageText_en.ResourceManager.GetString("GetRpm", LanguageText_en.resourceCulture);

		internal static string GoWithoutPassCode => LanguageText_en.ResourceManager.GetString("GoWithoutPassCode", LanguageText_en.resourceCulture);

		internal static string GradFilter => LanguageText_en.ResourceManager.GetString("GradFilter", LanguageText_en.resourceCulture);

		internal static string Gradient => LanguageText_en.ResourceManager.GetString("Gradient", LanguageText_en.resourceCulture);

		internal static string GradientLength => LanguageText_en.ResourceManager.GetString("GradientLength", LanguageText_en.resourceCulture);

		internal static string HandMode => LanguageText_en.ResourceManager.GetString("HandMode", LanguageText_en.resourceCulture);

		internal static string HandStart => LanguageText_en.ResourceManager.GetString("HandStart", LanguageText_en.resourceCulture);

		internal static string HandStartIsInitiated => LanguageText_en.ResourceManager.GetString("HandStartIsInitiated", LanguageText_en.resourceCulture);

		internal static string Help => LanguageText_en.ResourceManager.GetString("Help", LanguageText_en.resourceCulture);

		internal static string HexSwitch => LanguageText_en.ResourceManager.GetString("HexSwitch", LanguageText_en.resourceCulture);

		internal static string Hold => LanguageText_en.ResourceManager.GetString("Hold", LanguageText_en.resourceCulture);

		internal static string Holder => LanguageText_en.ResourceManager.GetString("Holder", LanguageText_en.resourceCulture);

		internal static string HolderPressureScale => LanguageText_en.ResourceManager.GetString("HolderPressureScale", LanguageText_en.resourceCulture);

		internal static string IdentServer => LanguageText_en.ResourceManager.GetString("IdentServer", LanguageText_en.resourceCulture);

		internal static string Increment => LanguageText_en.ResourceManager.GetString("Increment", LanguageText_en.resourceCulture);

		internal static string Inputs => LanguageText_en.ResourceManager.GetString("Inputs", LanguageText_en.resourceCulture);

		internal static string InsertProgram => LanguageText_en.ResourceManager.GetString("InsertProgram", LanguageText_en.resourceCulture);

		internal static string InsertStep => LanguageText_en.ResourceManager.GetString("InsertStep", LanguageText_en.resourceCulture);

		internal static string IntegratedTests => LanguageText_en.ResourceManager.GetString("IntegratedTests", LanguageText_en.resourceCulture);

		internal static string IONumber => LanguageText_en.ResourceManager.GetString("IONumber", LanguageText_en.resourceCulture);

		internal static string IOTest => LanguageText_en.ResourceManager.GetString("IOTest", LanguageText_en.resourceCulture);

		internal static string IPAddress => LanguageText_en.ResourceManager.GetString("IPAddress", LanguageText_en.resourceCulture);

		internal static string Italian => LanguageText_en.ResourceManager.GetString("Italian", LanguageText_en.resourceCulture);

		internal static string JumpAlwaysTo => LanguageText_en.ResourceManager.GetString("JumpAlwaysTo", LanguageText_en.resourceCulture);

		internal static string JumpNokTo => LanguageText_en.ResourceManager.GetString("JumpNokTo", LanguageText_en.resourceCulture);

		internal static string JumpOkTo => LanguageText_en.ResourceManager.GetString("JumpOkTo", LanguageText_en.resourceCulture);

		internal static string JumpTo => LanguageText_en.ResourceManager.GetString("JumpTo", LanguageText_en.resourceCulture);

		internal static string KeyPad => LanguageText_en.ResourceManager.GetString("KeyPad", LanguageText_en.resourceCulture);

		internal static string Kind => LanguageText_en.ResourceManager.GetString("Kind", LanguageText_en.resourceCulture);

		internal static string Language => LanguageText_en.ResourceManager.GetString("Language", LanguageText_en.resourceCulture);

		internal static string LastDoneStep => LanguageText_en.ResourceManager.GetString("LastDoneStep", LanguageText_en.resourceCulture);

		internal static string LastNIO => LanguageText_en.ResourceManager.GetString("LastNIO", LanguageText_en.resourceCulture);

		internal static string LastResults => LanguageText_en.ResourceManager.GetString("LastResults", LanguageText_en.resourceCulture);

		internal static string LeftAngle => LanguageText_en.ResourceManager.GetString("LeftAngle", LanguageText_en.resourceCulture);

		internal static string LevelAdministrator => LanguageText_en.ResourceManager.GetString("LevelAdministrator", LanguageText_en.resourceCulture);

		internal static string LevelProgramer => LanguageText_en.ResourceManager.GetString("LevelProgramer", LanguageText_en.resourceCulture);

		internal static string LevelUser => LanguageText_en.ResourceManager.GetString("LevelUser", LanguageText_en.resourceCulture);

		internal static string LivingMonitor => LanguageText_en.ResourceManager.GetString("LivingMonitor", LanguageText_en.resourceCulture);

		internal static string LivingSign => LanguageText_en.ResourceManager.GetString("LivingSign", LanguageText_en.resourceCulture);

		internal static string LoadCurveData => LanguageText_en.ResourceManager.GetString("LoadCurveData", LanguageText_en.resourceCulture);

		internal static string LoadCurveDataFromFile => LanguageText_en.ResourceManager.GetString("LoadCurveDataFromFile", LanguageText_en.resourceCulture);

		internal static string LoadCustBackup => LanguageText_en.ResourceManager.GetString("LoadCustBackup", LanguageText_en.resourceCulture);

		internal static string LoadCustBackupFromCF => LanguageText_en.ResourceManager.GetString("LoadCustBackupFromCF", LanguageText_en.resourceCulture);

		internal static string LoadCustBackupSecQuery => LanguageText_en.ResourceManager.GetString("LoadCustBackupSecQuery", LanguageText_en.resourceCulture);

		internal static string LoadCycleCount => LanguageText_en.ResourceManager.GetString("LoadCycleCount", LanguageText_en.resourceCulture);

		internal static string LoadFromFile => LanguageText_en.ResourceManager.GetString("LoadFromFile", LanguageText_en.resourceCulture);

		internal static string LoadIO => LanguageText_en.ResourceManager.GetString("LoadIO", LanguageText_en.resourceCulture);

		internal static string LoadLastNIOResults => LanguageText_en.ResourceManager.GetString("LoadLastNIOResults", LanguageText_en.resourceCulture);

		internal static string LoadLastResults => LanguageText_en.ResourceManager.GetString("LoadLastResults", LanguageText_en.resourceCulture);

		internal static string LoadLogBookData => LanguageText_en.ResourceManager.GetString("LoadLogBookData", LanguageText_en.resourceCulture);

		internal static string LoadPLCIO => LanguageText_en.ResourceManager.GetString("LoadPLCIO", LanguageText_en.resourceCulture);

		internal static string LoadPProgFromFile => LanguageText_en.ResourceManager.GetString("LoadPProgFromFile", LanguageText_en.resourceCulture);

		internal static string LoadProcessInfo => LanguageText_en.ResourceManager.GetString("LoadProcessInfo", LanguageText_en.resourceCulture);

		internal static string LoadProgramData => LanguageText_en.ResourceManager.GetString("LoadProgramData", LanguageText_en.resourceCulture);

		internal static string LoadProgramDataLocally => LanguageText_en.ResourceManager.GetString("LoadProgramDataLocally", LanguageText_en.resourceCulture);

		internal static string LoadRecursiveStat => LanguageText_en.ResourceManager.GetString("LoadRecursiveStat", LanguageText_en.resourceCulture);

		internal static string LoadResults => LanguageText_en.ResourceManager.GetString("LoadResults", LanguageText_en.resourceCulture);

		internal static string LoadSingleProgFromFile => LanguageText_en.ResourceManager.GetString("LoadSingleProgFromFile", LanguageText_en.resourceCulture);

		internal static string LoadSpindleConst => LanguageText_en.ResourceManager.GetString("LoadSpindleConst", LanguageText_en.resourceCulture);

		internal static string LoadSpindleDataLocally => LanguageText_en.ResourceManager.GetString("LoadSpindleDataLocally", LanguageText_en.resourceCulture);

		internal static string LoadSystemConst => LanguageText_en.ResourceManager.GetString("LoadSystemConst", LanguageText_en.resourceCulture);

		internal static string LoadWebBackupSecQuery => LanguageText_en.ResourceManager.GetString("LoadWebBackupSecQuery", LanguageText_en.resourceCulture);

		internal static string LoadWeberBackup => LanguageText_en.ResourceManager.GetString("LoadWeberBackup", LanguageText_en.resourceCulture);

		internal static string LoadWeberBackupFromCF => LanguageText_en.ResourceManager.GetString("LoadWeberBackupFromCF", LanguageText_en.resourceCulture);

		internal static string LocalTime => LanguageText_en.ResourceManager.GetString("LocalTime", LanguageText_en.resourceCulture);

		internal static string LogBook => LanguageText_en.ResourceManager.GetString("LogBook", LanguageText_en.resourceCulture);

		internal static string LogBookMessage100000 => LanguageText_en.ResourceManager.GetString("LogBookMessage100000", LanguageText_en.resourceCulture);

		internal static string LogBookMessage200000 => LanguageText_en.ResourceManager.GetString("LogBookMessage200000", LanguageText_en.resourceCulture);

		internal static string LogBookMessage300000 => LanguageText_en.ResourceManager.GetString("LogBookMessage300000", LanguageText_en.resourceCulture);

		internal static string LogBookMessage300001 => LanguageText_en.ResourceManager.GetString("LogBookMessage300001", LanguageText_en.resourceCulture);

		internal static string LogBookTable => LanguageText_en.ResourceManager.GetString("LogBookTable", LanguageText_en.resourceCulture);

		internal static string Login => LanguageText_en.ResourceManager.GetString("Login", LanguageText_en.resourceCulture);

		internal static string LowerLimit => LanguageText_en.ResourceManager.GetString("LowerLimit", LanguageText_en.resourceCulture);

		internal static string M1FilterTime => LanguageText_en.ResourceManager.GetString("M1FilterTime", LanguageText_en.resourceCulture);

		internal static string M360Follow => LanguageText_en.ResourceManager.GetString("M360Follow", LanguageText_en.resourceCulture);

		internal static string MachineCounter => LanguageText_en.ResourceManager.GetString("MachineCounter", LanguageText_en.resourceCulture);

		internal static string MachineVisu => LanguageText_en.ResourceManager.GetString("MachineVisu", LanguageText_en.resourceCulture);

		internal static string MakeNewEntry => LanguageText_en.ResourceManager.GetString("MakeNewEntry", LanguageText_en.resourceCulture);

		internal static string Max => LanguageText_en.ResourceManager.GetString("Max", LanguageText_en.resourceCulture);

		internal static string MaxFrictionTorque => LanguageText_en.ResourceManager.GetString("MaxFrictionTorque", LanguageText_en.resourceCulture);

		internal static string MaxRpm => LanguageText_en.ResourceManager.GetString("MaxRpm", LanguageText_en.resourceCulture);

		internal static string MaxSaveCurveNum => LanguageText_en.ResourceManager.GetString("MaxSaveCurveNum", LanguageText_en.resourceCulture);

		internal static string MaxScrewTime => LanguageText_en.ResourceManager.GetString("MaxScrewTime", LanguageText_en.resourceCulture);

		internal static string MaxTorque => LanguageText_en.ResourceManager.GetString("MaxTorque", LanguageText_en.resourceCulture);

		internal static string MbAccessByAnother => LanguageText_en.ResourceManager.GetString("MbAccessByAnother", LanguageText_en.resourceCulture);

		internal static string MbAccessNotPossible => LanguageText_en.ResourceManager.GetString("MbAccessNotPossible", LanguageText_en.resourceCulture);

		internal static string MbAccessRequestTwice => LanguageText_en.ResourceManager.GetString("MbAccessRequestTwice", LanguageText_en.resourceCulture);

		internal static string MBackup => LanguageText_en.ResourceManager.GetString("MBackup", LanguageText_en.resourceCulture);

		internal static string MbAddNoFrictionTest => LanguageText_en.ResourceManager.GetString("MbAddNoFrictionTest", LanguageText_en.resourceCulture);

		internal static string MbAddNoManual => LanguageText_en.ResourceManager.GetString("MbAddNoManual", LanguageText_en.resourceCulture);

		internal static string MbAddNoTest => LanguageText_en.ResourceManager.GetString("MbAddNoTest", LanguageText_en.resourceCulture);

		internal static string MbAddParamViewOnly => LanguageText_en.ResourceManager.GetString("MbAddParamViewOnly", LanguageText_en.resourceCulture);

		internal static string MbAutomaticIsActive1 => LanguageText_en.ResourceManager.GetString("MbAutomaticIsActive1", LanguageText_en.resourceCulture);

		internal static string MbAutomaticIsActive2 => LanguageText_en.ResourceManager.GetString("MbAutomaticIsActive2", LanguageText_en.resourceCulture);

		internal static string MbComandTimeOut => LanguageText_en.ResourceManager.GetString("MbComandTimeOut", LanguageText_en.resourceCulture);

		internal static string MbCreateDefaultPasscode => LanguageText_en.ResourceManager.GetString("MbCreateDefaultPasscode", LanguageText_en.resourceCulture);

		internal static string MbCurveLoadFailure => LanguageText_en.ResourceManager.GetString("MbCurveLoadFailure", LanguageText_en.resourceCulture);

		internal static string MbCurveSaveFailure => LanguageText_en.ResourceManager.GetString("MbCurveSaveFailure", LanguageText_en.resourceCulture);

		internal static string MbDeleteCounterFailure => LanguageText_en.ResourceManager.GetString("MbDeleteCounterFailure", LanguageText_en.resourceCulture);

		internal static string MbDeleteCustomCounter => LanguageText_en.ResourceManager.GetString("MbDeleteCustomCounter", LanguageText_en.resourceCulture);

		internal static string MbDeleteLastResFailure => LanguageText_en.ResourceManager.GetString("MbDeleteLastResFailure", LanguageText_en.resourceCulture);

		internal static string MbDeleteLastResults => LanguageText_en.ResourceManager.GetString("MbDeleteLastResults", LanguageText_en.resourceCulture);

		internal static string MbDeleteProg => LanguageText_en.ResourceManager.GetString("MbDeleteProg", LanguageText_en.resourceCulture);

		internal static string MbDeleteRecStatFailure => LanguageText_en.ResourceManager.GetString("MbDeleteRecStatFailure", LanguageText_en.resourceCulture);

		internal static string MbDeleteRecursiveStat => LanguageText_en.ResourceManager.GetString("MbDeleteRecursiveStat", LanguageText_en.resourceCulture);

		internal static string MbDeleteStatAfterProgChange => LanguageText_en.ResourceManager.GetString("MbDeleteStatAfterProgChange", LanguageText_en.resourceCulture);

		internal static string MbDoubleEntryCodeFound => LanguageText_en.ResourceManager.GetString("MbDoubleEntryCodeFound", LanguageText_en.resourceCulture);

		internal static string MbEmptyProgram => LanguageText_en.ResourceManager.GetString("MbEmptyProgram", LanguageText_en.resourceCulture);

		internal static string MbErrorQuitFailure => LanguageText_en.ResourceManager.GetString("MbErrorQuitFailure", LanguageText_en.resourceCulture);

		internal static string MbExit => LanguageText_en.ResourceManager.GetString("MbExit", LanguageText_en.resourceCulture);

		internal static string MbGotNoConnection => LanguageText_en.ResourceManager.GetString("MbGotNoConnection", LanguageText_en.resourceCulture);

		internal static string MbHandstartIsActive => LanguageText_en.ResourceManager.GetString("MbHandstartIsActive", LanguageText_en.resourceCulture);

		internal static string MbHandstartNotTwice => LanguageText_en.ResourceManager.GetString("MbHandstartNotTwice", LanguageText_en.resourceCulture);

		internal static string MbhError => LanguageText_en.ResourceManager.GetString("MbhError", LanguageText_en.resourceCulture);

		internal static string MbhHint => LanguageText_en.ResourceManager.GetString("MbhHint", LanguageText_en.resourceCulture);

		internal static string MbhNoAccess => LanguageText_en.ResourceManager.GetString("MbhNoAccess", LanguageText_en.resourceCulture);

		internal static string MbhSecurityQuery => LanguageText_en.ResourceManager.GetString("MbhSecurityQuery", LanguageText_en.resourceCulture);

		internal static string MbhViewOnlyMode => LanguageText_en.ResourceManager.GetString("MbhViewOnlyMode", LanguageText_en.resourceCulture);

		internal static string MbIPChange => LanguageText_en.ResourceManager.GetString("MbIPChange", LanguageText_en.resourceCulture);

		internal static string MbKeyLockActive => LanguageText_en.ResourceManager.GetString("MbKeyLockActive", LanguageText_en.resourceCulture);

		internal static string MbLoadCustBackupFailure => LanguageText_en.ResourceManager.GetString("MbLoadCustBackupFailure", LanguageText_en.resourceCulture);

		internal static string MbLoadWeberBackupFailure => LanguageText_en.ResourceManager.GetString("MbLoadWeberBackupFailure", LanguageText_en.resourceCulture);

		internal static string MbLocationError => LanguageText_en.ResourceManager.GetString("MbLocationError", LanguageText_en.resourceCulture);

		internal static string MbLogbookWriteFailure => LanguageText_en.ResourceManager.GetString("MbLogbookWriteFailure", LanguageText_en.resourceCulture);

		internal static string MbMaxPasscodeNum1 => LanguageText_en.ResourceManager.GetString("MbMaxPasscodeNum1", LanguageText_en.resourceCulture);

		internal static string MbMaxPasscodeNum2 => LanguageText_en.ResourceManager.GetString("MbMaxPasscodeNum2", LanguageText_en.resourceCulture);

		internal static string MbNoAccess => LanguageText_en.ResourceManager.GetString("MbNoAccess", LanguageText_en.resourceCulture);

		internal static string MbNoAccessCauseAuto => LanguageText_en.ResourceManager.GetString("MbNoAccessCauseAuto", LanguageText_en.resourceCulture);

		internal static string MbNoConnection => LanguageText_en.ResourceManager.GetString("MbNoConnection", LanguageText_en.resourceCulture);

		internal static string MbNoTestCauseAuto => LanguageText_en.ResourceManager.GetString("MbNoTestCauseAuto", LanguageText_en.resourceCulture);

		internal static string MbOfflineMode => LanguageText_en.ResourceManager.GetString("MbOfflineMode", LanguageText_en.resourceCulture);

		internal static string MbOldPProgLoad => LanguageText_en.ResourceManager.GetString("MbOldPProgLoad", LanguageText_en.resourceCulture);

		internal static string MbOldProgLoad => LanguageText_en.ResourceManager.GetString("MbOldProgLoad", LanguageText_en.resourceCulture);

		internal static string MbOverwriteProg => LanguageText_en.ResourceManager.GetString("MbOverwriteProg", LanguageText_en.resourceCulture);

		internal static string MbPasscodeFailure1 => LanguageText_en.ResourceManager.GetString("MbPasscodeFailure1", LanguageText_en.resourceCulture);

		internal static string MbPasscodeFailure2 => LanguageText_en.ResourceManager.GetString("MbPasscodeFailure2", LanguageText_en.resourceCulture);

		internal static string MbPasscodeFailure3 => LanguageText_en.ResourceManager.GetString("MbPasscodeFailure3", LanguageText_en.resourceCulture);

		internal static string MbPasscodeFailure4 => LanguageText_en.ResourceManager.GetString("MbPasscodeFailure4", LanguageText_en.resourceCulture);

		internal static string MbPProgCopyFailure => LanguageText_en.ResourceManager.GetString("MbPProgCopyFailure", LanguageText_en.resourceCulture);

		internal static string MbPProgLoadFromFileFailure => LanguageText_en.ResourceManager.GetString("MbPProgLoadFromFileFailure", LanguageText_en.resourceCulture);

		internal static string MbPProgSaveToFileFailure => LanguageText_en.ResourceManager.GetString("MbPProgSaveToFileFailure", LanguageText_en.resourceCulture);

		internal static string MbProgramCopyFailure => LanguageText_en.ResourceManager.GetString("MbProgramCopyFailure", LanguageText_en.resourceCulture);

		internal static string MbProgramEmptySaveAnyway => LanguageText_en.ResourceManager.GetString("MbProgramEmptySaveAnyway", LanguageText_en.resourceCulture);

		internal static string MbSaveCustBackupFailure => LanguageText_en.ResourceManager.GetString("MbSaveCustBackupFailure", LanguageText_en.resourceCulture);

		internal static string MbSaveDataLocally => LanguageText_en.ResourceManager.GetString("MbSaveDataLocally", LanguageText_en.resourceCulture);

		internal static string MbSavedProgramDataToFile => LanguageText_en.ResourceManager.GetString("MbSavedProgramDataToFile", LanguageText_en.resourceCulture);

		internal static string MbSavedSpindleDataToFile => LanguageText_en.ResourceManager.GetString("MbSavedSpindleDataToFile", LanguageText_en.resourceCulture);

		internal static string MbSaveNotVerifiedData => LanguageText_en.ResourceManager.GetString("MbSaveNotVerifiedData", LanguageText_en.resourceCulture);

		internal static string MbSavePasscodeFailure => LanguageText_en.ResourceManager.GetString("MbSavePasscodeFailure", LanguageText_en.resourceCulture);

		internal static string MbSaveProgFailure => LanguageText_en.ResourceManager.GetString("MbSaveProgFailure", LanguageText_en.resourceCulture);

		internal static string MbSaveProgOnCPUFailure => LanguageText_en.ResourceManager.GetString("MbSaveProgOnCPUFailure", LanguageText_en.resourceCulture);

		internal static string MbSaveSpConstFailure => LanguageText_en.ResourceManager.GetString("MbSaveSpConstFailure", LanguageText_en.resourceCulture);

		internal static string MbSaveSysConstFailure => LanguageText_en.ResourceManager.GetString("MbSaveSysConstFailure", LanguageText_en.resourceCulture);

		internal static string MbSaveWeberBackupFailure => LanguageText_en.ResourceManager.GetString("MbSaveWeberBackupFailure", LanguageText_en.resourceCulture);

		internal static string MbShortNameFailure1 => LanguageText_en.ResourceManager.GetString("MbShortNameFailure1", LanguageText_en.resourceCulture);

		internal static string MbShortNameFailure2 => LanguageText_en.ResourceManager.GetString("MbShortNameFailure2", LanguageText_en.resourceCulture);

		internal static string MbShortNameFailure3 => LanguageText_en.ResourceManager.GetString("MbShortNameFailure3", LanguageText_en.resourceCulture);

		internal static string MbSpindleCopyFailure => LanguageText_en.ResourceManager.GetString("MbSpindleCopyFailure", LanguageText_en.resourceCulture);

		internal static string MbSpindleLoadFromFileFailure => LanguageText_en.ResourceManager.GetString("MbSpindleLoadFromFileFailure", LanguageText_en.resourceCulture);

		internal static string MbSpindleSaveToFileFailure => LanguageText_en.ResourceManager.GetString("MbSpindleSaveToFileFailure", LanguageText_en.resourceCulture);

		internal static string MbStepCopyFailure => LanguageText_en.ResourceManager.GetString("MbStepCopyFailure", LanguageText_en.resourceCulture);

		internal static string MbWrongPassword => LanguageText_en.ResourceManager.GetString("MbWrongPassword", LanguageText_en.resourceCulture);

		internal static string MCheckParameter => LanguageText_en.ResourceManager.GetString("MCheckParameter", LanguageText_en.resourceCulture);

		internal static string MCurveDisplay => LanguageText_en.ResourceManager.GetString("MCurveDisplay", LanguageText_en.resourceCulture);

		internal static string MCurveSelection => LanguageText_en.ResourceManager.GetString("MCurveSelection", LanguageText_en.resourceCulture);

		internal static string MCycleCounter => LanguageText_en.ResourceManager.GetString("MCycleCounter", LanguageText_en.resourceCulture);

		internal static string MDelay => LanguageText_en.ResourceManager.GetString("MDelay", LanguageText_en.resourceCulture);

		internal static string Mean => LanguageText_en.ResourceManager.GetString("Mean", LanguageText_en.resourceCulture);

		internal static string MEditStep => LanguageText_en.ResourceManager.GetString("MEditStep", LanguageText_en.resourceCulture);

		internal static string MenuAnalysis => LanguageText_en.ResourceManager.GetString("MenuAnalysis", LanguageText_en.resourceCulture);

		internal static string MenuParameter => LanguageText_en.ResourceManager.GetString("MenuParameter", LanguageText_en.resourceCulture);

		internal static string MenuStatistics => LanguageText_en.ResourceManager.GetString("MenuStatistics", LanguageText_en.resourceCulture);

		internal static string MenuTest => LanguageText_en.ResourceManager.GetString("MenuTest", LanguageText_en.resourceCulture);

		internal static string Message => LanguageText_en.ResourceManager.GetString("Message", LanguageText_en.resourceCulture);

		internal static string MHandStart => LanguageText_en.ResourceManager.GetString("MHandStart", LanguageText_en.resourceCulture);

		internal static string Milimeter => LanguageText_en.ResourceManager.GetString("Milimeter", LanguageText_en.resourceCulture);

		internal static string Milisecond => LanguageText_en.ResourceManager.GetString("Milisecond", LanguageText_en.resourceCulture);

		internal static string Min => LanguageText_en.ResourceManager.GetString("Min", LanguageText_en.resourceCulture);

		internal static string MiniDisplay => LanguageText_en.ResourceManager.GetString("MiniDisplay", LanguageText_en.resourceCulture);

		internal static string Minimize => LanguageText_en.ResourceManager.GetString("Minimize", LanguageText_en.resourceCulture);

		internal static string MLastNIO => LanguageText_en.ResourceManager.GetString("MLastNIO", LanguageText_en.resourceCulture);

		internal static string MLogBook => LanguageText_en.ResourceManager.GetString("MLogBook", LanguageText_en.resourceCulture);

		internal static string MOptPrgParam => LanguageText_en.ResourceManager.GetString("MOptPrgParam", LanguageText_en.resourceCulture);

		internal static string Motor => LanguageText_en.ResourceManager.GetString("Motor", LanguageText_en.resourceCulture);

		internal static string MPasscodeManager => LanguageText_en.ResourceManager.GetString("MPasscodeManager", LanguageText_en.resourceCulture);

		internal static string MPrintSelection => LanguageText_en.ResourceManager.GetString("MPrintSelection", LanguageText_en.resourceCulture);

		internal static string MProgramOverview => LanguageText_en.ResourceManager.GetString("MProgramOverview", LanguageText_en.resourceCulture);

		internal static string MSpindleConstants => LanguageText_en.ResourceManager.GetString("MSpindleConstants", LanguageText_en.resourceCulture);

		internal static string MStepOverview => LanguageText_en.ResourceManager.GetString("MStepOverview", LanguageText_en.resourceCulture);

		internal static string MStepResults => LanguageText_en.ResourceManager.GetString("MStepResults", LanguageText_en.resourceCulture);

		internal static string MSystemConstants => LanguageText_en.ResourceManager.GetString("MSystemConstants", LanguageText_en.resourceCulture);

		internal static string MVisualisationParam => LanguageText_en.ResourceManager.GetString("MVisualisationParam", LanguageText_en.resourceCulture);

		internal static string Name => LanguageText_en.ResourceManager.GetString("Name", LanguageText_en.resourceCulture);

		internal static string Negative => LanguageText_en.ResourceManager.GetString("Negative", LanguageText_en.resourceCulture);

		internal static string NegOverload => LanguageText_en.ResourceManager.GetString("NegOverload", LanguageText_en.resourceCulture);

		internal static string NewEntry => LanguageText_en.ResourceManager.GetString("NewEntry", LanguageText_en.resourceCulture);

		internal static string NewValue => LanguageText_en.ResourceManager.GetString("NewValue", LanguageText_en.resourceCulture);

		internal static string Next50Curves => LanguageText_en.ResourceManager.GetString("Next50Curves", LanguageText_en.resourceCulture);

		internal static string NIO10 => LanguageText_en.ResourceManager.GetString("NIO10", LanguageText_en.resourceCulture);

		internal static string NIO10001 => LanguageText_en.ResourceManager.GetString("NIO10001", LanguageText_en.resourceCulture);

		internal static string NIO10002 => LanguageText_en.ResourceManager.GetString("NIO10002", LanguageText_en.resourceCulture);

		internal static string NIO10003 => LanguageText_en.ResourceManager.GetString("NIO10003", LanguageText_en.resourceCulture);

		internal static string NIO10004 => LanguageText_en.ResourceManager.GetString("NIO10004", LanguageText_en.resourceCulture);

		internal static string NIO11 => LanguageText_en.ResourceManager.GetString("NIO11", LanguageText_en.resourceCulture);

		internal static string NIO110 => LanguageText_en.ResourceManager.GetString("NIO110", LanguageText_en.resourceCulture);

		internal static string NIO12 => LanguageText_en.ResourceManager.GetString("NIO12", LanguageText_en.resourceCulture);

		internal static string NIO13 => LanguageText_en.ResourceManager.GetString("NIO13", LanguageText_en.resourceCulture);

		internal static string NIO30 => LanguageText_en.ResourceManager.GetString("NIO30", LanguageText_en.resourceCulture);

		internal static string NIO31 => LanguageText_en.ResourceManager.GetString("NIO31", LanguageText_en.resourceCulture);

		internal static string NIO40 => LanguageText_en.ResourceManager.GetString("NIO40", LanguageText_en.resourceCulture);

		internal static string NIO41 => LanguageText_en.ResourceManager.GetString("NIO41", LanguageText_en.resourceCulture);

		internal static string NIO50 => LanguageText_en.ResourceManager.GetString("NIO50", LanguageText_en.resourceCulture);

		internal static string NIO51 => LanguageText_en.ResourceManager.GetString("NIO51", LanguageText_en.resourceCulture);

		internal static string NIO60 => LanguageText_en.ResourceManager.GetString("NIO60", LanguageText_en.resourceCulture);

		internal static string NIO61 => LanguageText_en.ResourceManager.GetString("NIO61", LanguageText_en.resourceCulture);

		internal static string NIO70 => LanguageText_en.ResourceManager.GetString("NIO70", LanguageText_en.resourceCulture);

		internal static string NIO71 => LanguageText_en.ResourceManager.GetString("NIO71", LanguageText_en.resourceCulture);

		internal static string NIO75 => LanguageText_en.ResourceManager.GetString("NIO75", LanguageText_en.resourceCulture);

		internal static string NIO76 => LanguageText_en.ResourceManager.GetString("NIO76", LanguageText_en.resourceCulture);

		internal static string NIO80 => LanguageText_en.ResourceManager.GetString("NIO80", LanguageText_en.resourceCulture);

		internal static string NIO81 => LanguageText_en.ResourceManager.GetString("NIO81", LanguageText_en.resourceCulture);

		internal static string NIO90 => LanguageText_en.ResourceManager.GetString("NIO90", LanguageText_en.resourceCulture);

		internal static string NIO91 => LanguageText_en.ResourceManager.GetString("NIO91", LanguageText_en.resourceCulture);

		internal static string NIO92 => LanguageText_en.ResourceManager.GetString("NIO92", LanguageText_en.resourceCulture);

		internal static string NIO93 => LanguageText_en.ResourceManager.GetString("NIO93", LanguageText_en.resourceCulture);

		internal static string NIO94 => LanguageText_en.ResourceManager.GetString("NIO94", LanguageText_en.resourceCulture);

		internal static string NIO95 => LanguageText_en.ResourceManager.GetString("NIO95", LanguageText_en.resourceCulture);

		internal static string NIO96 => LanguageText_en.ResourceManager.GetString("NIO96", LanguageText_en.resourceCulture);

		internal static string NIO97 => LanguageText_en.ResourceManager.GetString("NIO97", LanguageText_en.resourceCulture);

		internal static string NIO98 => LanguageText_en.ResourceManager.GetString("NIO98", LanguageText_en.resourceCulture);

		internal static string NIO99 => LanguageText_en.ResourceManager.GetString("NIO99", LanguageText_en.resourceCulture);

		internal static string NIONumber => LanguageText_en.ResourceManager.GetString("NIONumber", LanguageText_en.resourceCulture);

		internal static string NIOReason => LanguageText_en.ResourceManager.GetString("NIOReason", LanguageText_en.resourceCulture);

		internal static string No => LanguageText_en.ResourceManager.GetString("No", LanguageText_en.resourceCulture);

		internal static string NoData => LanguageText_en.ResourceManager.GetString("NoData", LanguageText_en.resourceCulture);

		internal static string NoErrorMode => LanguageText_en.ResourceManager.GetString("NoErrorMode", LanguageText_en.resourceCulture);

		internal static string NOK => LanguageText_en.ResourceManager.GetString("NOK", LanguageText_en.resourceCulture);

		internal static string None => LanguageText_en.ResourceManager.GetString("None", LanguageText_en.resourceCulture);

		internal static string NoParity => LanguageText_en.ResourceManager.GetString("NoParity", LanguageText_en.resourceCulture);

		internal static string NoSelection => LanguageText_en.ResourceManager.GetString("NoSelection", LanguageText_en.resourceCulture);

		internal static string NoSignal => LanguageText_en.ResourceManager.GetString("NoSignal", LanguageText_en.resourceCulture);

		internal static string NotValid => LanguageText_en.ResourceManager.GetString("NotValid", LanguageText_en.resourceCulture);

		internal static string Number => LanguageText_en.ResourceManager.GetString("Number", LanguageText_en.resourceCulture);

		internal static string NumberPad => LanguageText_en.ResourceManager.GetString("NumberPad", LanguageText_en.resourceCulture);

		internal static string Odd => LanguageText_en.ResourceManager.GetString("Odd", LanguageText_en.resourceCulture);

		internal static string Off => LanguageText_en.ResourceManager.GetString("Off", LanguageText_en.resourceCulture);

		internal static string OfflineMode => LanguageText_en.ResourceManager.GetString("OfflineMode", LanguageText_en.resourceCulture);

		internal static string OffsetTeachValue => LanguageText_en.ResourceManager.GetString("OffsetTeachValue", LanguageText_en.resourceCulture);

		internal static string OffsetVoltageMax => LanguageText_en.ResourceManager.GetString("OffsetVoltageMax", LanguageText_en.resourceCulture);

		internal static string OffsetVoltageMin => LanguageText_en.ResourceManager.GetString("OffsetVoltageMin", LanguageText_en.resourceCulture);

		internal static string OfStep => LanguageText_en.ResourceManager.GetString("OfStep", LanguageText_en.resourceCulture);

		internal static string OK => LanguageText_en.ResourceManager.GetString("OK", LanguageText_en.resourceCulture);

		internal static string OKNOK => LanguageText_en.ResourceManager.GetString("OKNOK", LanguageText_en.resourceCulture);

		internal static string OldValue => LanguageText_en.ResourceManager.GetString("OldValue", LanguageText_en.resourceCulture);

		internal static string On => LanguageText_en.ResourceManager.GetString("On", LanguageText_en.resourceCulture);

		internal static string OnlineMode => LanguageText_en.ResourceManager.GetString("OnlineMode", LanguageText_en.resourceCulture);

		internal static string OnlyIO => LanguageText_en.ResourceManager.GetString("OnlyIO", LanguageText_en.resourceCulture);

		internal static string OptPrgParam => LanguageText_en.ResourceManager.GetString("OptPrgParam", LanguageText_en.resourceCulture);

		internal static string Organisation => LanguageText_en.ResourceManager.GetString("Organisation", LanguageText_en.resourceCulture);

		internal static string OrganizingStep => LanguageText_en.ResourceManager.GetString("OrganizingStep", LanguageText_en.resourceCulture);

		internal static string OutOfRange => LanguageText_en.ResourceManager.GetString("OutOfRange", LanguageText_en.resourceCulture);

		internal static string Outputs => LanguageText_en.ResourceManager.GetString("Outputs", LanguageText_en.resourceCulture);

		internal static string PaintCurve => LanguageText_en.ResourceManager.GetString("PaintCurve", LanguageText_en.resourceCulture);

		internal static string Parity => LanguageText_en.ResourceManager.GetString("Parity", LanguageText_en.resourceCulture);

		internal static string PasscodeLevel => LanguageText_en.ResourceManager.GetString("PasscodeLevel", LanguageText_en.resourceCulture);

		internal static string PasscodeManager => LanguageText_en.ResourceManager.GetString("PasscodeManager", LanguageText_en.resourceCulture);

		internal static string Password => LanguageText_en.ResourceManager.GetString("Password", LanguageText_en.resourceCulture);

		internal static string PasswordInput => LanguageText_en.ResourceManager.GetString("PasswordInput", LanguageText_en.resourceCulture);

		internal static string Percent => LanguageText_en.ResourceManager.GetString("Percent", LanguageText_en.resourceCulture);

		internal static string PLC_IO => LanguageText_en.ResourceManager.GetString("PLC_IO", LanguageText_en.resourceCulture);

		internal static string PointOfTime => LanguageText_en.ResourceManager.GetString("PointOfTime", LanguageText_en.resourceCulture);

		internal static string Positive => LanguageText_en.ResourceManager.GetString("Positive", LanguageText_en.resourceCulture);

		internal static string PosOverload => LanguageText_en.ResourceManager.GetString("PosOverload", LanguageText_en.resourceCulture);

		internal static string PowerEnabled => LanguageText_en.ResourceManager.GetString("PowerEnabled", LanguageText_en.resourceCulture);

		internal static string Pressure => LanguageText_en.ResourceManager.GetString("Pressure", LanguageText_en.resourceCulture);

		internal static string PressureSpindle => LanguageText_en.ResourceManager.GetString("PressureSpindle", LanguageText_en.resourceCulture);

		internal static string Print => LanguageText_en.ResourceManager.GetString("Print", LanguageText_en.resourceCulture);

		internal static string ProcessInputs => LanguageText_en.ResourceManager.GetString("ProcessInputs", LanguageText_en.resourceCulture);

		internal static string ProcessRunning => LanguageText_en.ResourceManager.GetString("ProcessRunning", LanguageText_en.resourceCulture);

		internal static string Program => LanguageText_en.ResourceManager.GetString("Program", LanguageText_en.resourceCulture);

		internal static string ProgramChange201000 => LanguageText_en.ResourceManager.GetString("ProgramChange201000", LanguageText_en.resourceCulture);

		internal static string ProgramChange201001 => LanguageText_en.ResourceManager.GetString("ProgramChange201001", LanguageText_en.resourceCulture);

		internal static string ProgramChange201002 => LanguageText_en.ResourceManager.GetString("ProgramChange201002", LanguageText_en.resourceCulture);

		internal static string ProgramChange201003 => LanguageText_en.ResourceManager.GetString("ProgramChange201003", LanguageText_en.resourceCulture);

		internal static string ProgramChange201004 => LanguageText_en.ResourceManager.GetString("ProgramChange201004", LanguageText_en.resourceCulture);

		internal static string ProgramChange201005 => LanguageText_en.ResourceManager.GetString("ProgramChange201005", LanguageText_en.resourceCulture);

		internal static string ProgramChange201006 => LanguageText_en.ResourceManager.GetString("ProgramChange201006", LanguageText_en.resourceCulture);

		internal static string ProgramChange201007 => LanguageText_en.ResourceManager.GetString("ProgramChange201007", LanguageText_en.resourceCulture);

		internal static string ProgramChange201008 => LanguageText_en.ResourceManager.GetString("ProgramChange201008", LanguageText_en.resourceCulture);

		internal static string ProgramChange201009 => LanguageText_en.ResourceManager.GetString("ProgramChange201009", LanguageText_en.resourceCulture);

		internal static string ProgramNumber => LanguageText_en.ResourceManager.GetString("ProgramNumber", LanguageText_en.resourceCulture);

		internal static string Programs => LanguageText_en.ResourceManager.GetString("Programs", LanguageText_en.resourceCulture);

		internal static string Quit => LanguageText_en.ResourceManager.GetString("Quit", LanguageText_en.resourceCulture);

		internal static string Ramp => LanguageText_en.ResourceManager.GetString("Ramp", LanguageText_en.resourceCulture);

		internal static string Range => LanguageText_en.ResourceManager.GetString("Range", LanguageText_en.resourceCulture);

		internal static string ReadyToStart => LanguageText_en.ResourceManager.GetString("ReadyToStart", LanguageText_en.resourceCulture);

		internal static string RecentDateTime => LanguageText_en.ResourceManager.GetString("RecentDateTime", LanguageText_en.resourceCulture);

		internal static string Reconnect => LanguageText_en.ResourceManager.GetString("Reconnect", LanguageText_en.resourceCulture);

		internal static string ReconnectToController => LanguageText_en.ResourceManager.GetString("ReconnectToController", LanguageText_en.resourceCulture);

		internal static string RecursiveStatMode => LanguageText_en.ResourceManager.GetString("RecursiveStatMode", LanguageText_en.resourceCulture);

		internal static string RedAngle => LanguageText_en.ResourceManager.GetString("RedAngle", LanguageText_en.resourceCulture);

		internal static string RedTorque => LanguageText_en.ResourceManager.GetString("RedTorque", LanguageText_en.resourceCulture);

		internal static string RedundantSensorActive => LanguageText_en.ResourceManager.GetString("RedundantSensorActive", LanguageText_en.resourceCulture);

		internal static string relatedTo => LanguageText_en.ResourceManager.GetString("relatedTo", LanguageText_en.resourceCulture);

		internal static string RelativeTorque => LanguageText_en.ResourceManager.GetString("RelativeTorque", LanguageText_en.resourceCulture);

		internal static string Release => LanguageText_en.ResourceManager.GetString("Release", LanguageText_en.resourceCulture);

		internal static string ReleaseSpeed => LanguageText_en.ResourceManager.GetString("ReleaseSpeed", LanguageText_en.resourceCulture);

		internal static string RelTorqueStep => LanguageText_en.ResourceManager.GetString("RelTorqueStep", LanguageText_en.resourceCulture);

		internal static string RemainedCurves => LanguageText_en.ResourceManager.GetString("RemainedCurves", LanguageText_en.resourceCulture);

		internal static string Reset => LanguageText_en.ResourceManager.GetString("Reset", LanguageText_en.resourceCulture);

		internal static string ResetADepth => LanguageText_en.ResourceManager.GetString("ResetADepth", LanguageText_en.resourceCulture);

		internal static string ResetAngle => LanguageText_en.ResourceManager.GetString("ResetAngle", LanguageText_en.resourceCulture);

		internal static string Result => LanguageText_en.ResourceManager.GetString("Result", LanguageText_en.resourceCulture);

		internal static string ResultDisplay => LanguageText_en.ResourceManager.GetString("ResultDisplay", LanguageText_en.resourceCulture);

		internal static string Results => LanguageText_en.ResourceManager.GetString("Results", LanguageText_en.resourceCulture);

		internal static string RightAngle => LanguageText_en.ResourceManager.GetString("RightAngle", LanguageText_en.resourceCulture);

		internal static string Robot => LanguageText_en.ResourceManager.GetString("Robot", LanguageText_en.resourceCulture);

		internal static string RoundsPerMinute => LanguageText_en.ResourceManager.GetString("RoundsPerMinute", LanguageText_en.resourceCulture);

		internal static string RpmTest => LanguageText_en.ResourceManager.GetString("RpmTest", LanguageText_en.resourceCulture);

		internal static string RpmUnit => LanguageText_en.ResourceManager.GetString("RpmUnit", LanguageText_en.resourceCulture);

		internal static string RS232PrintMode => LanguageText_en.ResourceManager.GetString("RS232PrintMode", LanguageText_en.resourceCulture);

		internal static string SampleSize => LanguageText_en.ResourceManager.GetString("SampleSize", LanguageText_en.resourceCulture);

		internal static string SampleStatistic => LanguageText_en.ResourceManager.GetString("SampleStatistic", LanguageText_en.resourceCulture);

		internal static string SaveCurveDataToFile => LanguageText_en.ResourceManager.GetString("SaveCurveDataToFile", LanguageText_en.resourceCulture);

		internal static string SaveCustBackup => LanguageText_en.ResourceManager.GetString("SaveCustBackup", LanguageText_en.resourceCulture);

		internal static string SaveCustBackupOnCF => LanguageText_en.ResourceManager.GetString("SaveCustBackupOnCF", LanguageText_en.resourceCulture);

		internal static string SaveCustBackupSecQuery => LanguageText_en.ResourceManager.GetString("SaveCustBackupSecQuery", LanguageText_en.resourceCulture);

		internal static string SavePasscodesOnCPU => LanguageText_en.ResourceManager.GetString("SavePasscodesOnCPU", LanguageText_en.resourceCulture);

		internal static string SavePProgToFile => LanguageText_en.ResourceManager.GetString("SavePProgToFile", LanguageText_en.resourceCulture);

		internal static string SaveProgOnCPU => LanguageText_en.ResourceManager.GetString("SaveProgOnCPU", LanguageText_en.resourceCulture);

		internal static string SaveProgramData => LanguageText_en.ResourceManager.GetString("SaveProgramData", LanguageText_en.resourceCulture);

		internal static string SaveProgramDataLocally => LanguageText_en.ResourceManager.GetString("SaveProgramDataLocally", LanguageText_en.resourceCulture);

		internal static string SaveSingleProgToFile => LanguageText_en.ResourceManager.GetString("SaveSingleProgToFile", LanguageText_en.resourceCulture);

		internal static string SaveSpindleConstOnCPU => LanguageText_en.ResourceManager.GetString("SaveSpindleConstOnCPU", LanguageText_en.resourceCulture);

		internal static string SaveSpindleDataLocally => LanguageText_en.ResourceManager.GetString("SaveSpindleDataLocally", LanguageText_en.resourceCulture);

		internal static string SaveSystemConstOnCPU => LanguageText_en.ResourceManager.GetString("SaveSystemConstOnCPU", LanguageText_en.resourceCulture);

		internal static string SaveToFile => LanguageText_en.ResourceManager.GetString("SaveToFile", LanguageText_en.resourceCulture);

		internal static string SaveVisuParam => LanguageText_en.ResourceManager.GetString("SaveVisuParam", LanguageText_en.resourceCulture);

		internal static string SaveWebBackupSecQuery => LanguageText_en.ResourceManager.GetString("SaveWebBackupSecQuery", LanguageText_en.resourceCulture);

		internal static string SaveWeberBackup => LanguageText_en.ResourceManager.GetString("SaveWeberBackup", LanguageText_en.resourceCulture);

		internal static string SaveWeberBackupOnCF => LanguageText_en.ResourceManager.GetString("SaveWeberBackupOnCF", LanguageText_en.resourceCulture);

		internal static string ScrewID => LanguageText_en.ResourceManager.GetString("ScrewID", LanguageText_en.resourceCulture);

		internal static string ScrewProgramFiles => LanguageText_en.ResourceManager.GetString("ScrewProgramFiles", LanguageText_en.resourceCulture);

		internal static string ScrewPrograms => LanguageText_en.ResourceManager.GetString("ScrewPrograms", LanguageText_en.resourceCulture);

		internal static string ScrewTime => LanguageText_en.ResourceManager.GetString("ScrewTime", LanguageText_en.resourceCulture);

		internal static string Second => LanguageText_en.ResourceManager.GetString("Second", LanguageText_en.resourceCulture);

		internal static string SelectAll => LanguageText_en.ResourceManager.GetString("SelectAll", LanguageText_en.resourceCulture);

		internal static string SelectedKind => LanguageText_en.ResourceManager.GetString("SelectedKind", LanguageText_en.resourceCulture);

		internal static string SelectedXAxis => LanguageText_en.ResourceManager.GetString("SelectedXAxis", LanguageText_en.resourceCulture);

		internal static string SelectedYAxis => LanguageText_en.ResourceManager.GetString("SelectedYAxis", LanguageText_en.resourceCulture);

		internal static string SelectNone => LanguageText_en.ResourceManager.GetString("SelectNone", LanguageText_en.resourceCulture);

		internal static string SelValidNumber => LanguageText_en.ResourceManager.GetString("SelValidNumber", LanguageText_en.resourceCulture);

		internal static string SendIO => LanguageText_en.ResourceManager.GetString("SendIO", LanguageText_en.resourceCulture);

		internal static string SendPasscodes => LanguageText_en.ResourceManager.GetString("SendPasscodes", LanguageText_en.resourceCulture);

		internal static string SendSpindleConstants => LanguageText_en.ResourceManager.GetString("SendSpindleConstants", LanguageText_en.resourceCulture);

		internal static string SendSystemConstants => LanguageText_en.ResourceManager.GetString("SendSystemConstants", LanguageText_en.resourceCulture);

		internal static string SensorTest => LanguageText_en.ResourceManager.GetString("SensorTest", LanguageText_en.resourceCulture);

		internal static string Set => LanguageText_en.ResourceManager.GetString("Set", LanguageText_en.resourceCulture);

		internal static string SetAnaOut => LanguageText_en.ResourceManager.GetString("SetAnaOut", LanguageText_en.resourceCulture);

		internal static string SetDigOut => LanguageText_en.ResourceManager.GetString("SetDigOut", LanguageText_en.resourceCulture);

		internal static string SetOff => LanguageText_en.ResourceManager.GetString("SetOff", LanguageText_en.resourceCulture);

		internal static string SetOn => LanguageText_en.ResourceManager.GetString("SetOn", LanguageText_en.resourceCulture);

		internal static string SetRight => LanguageText_en.ResourceManager.GetString("SetRight", LanguageText_en.resourceCulture);

		internal static string SetRpm => LanguageText_en.ResourceManager.GetString("SetRpm", LanguageText_en.resourceCulture);

		internal static string Settings => LanguageText_en.ResourceManager.GetString("Settings", LanguageText_en.resourceCulture);

		internal static string ShortName => LanguageText_en.ResourceManager.GetString("ShortName", LanguageText_en.resourceCulture);

		internal static string SignalQuit => LanguageText_en.ResourceManager.GetString("SignalQuit", LanguageText_en.resourceCulture);

		internal static string Spain => LanguageText_en.ResourceManager.GetString("Spain", LanguageText_en.resourceCulture);

		internal static string SpChange100010 => LanguageText_en.ResourceManager.GetString("SpChange100010", LanguageText_en.resourceCulture);

		internal static string SpChange203000 => LanguageText_en.ResourceManager.GetString("SpChange203000", LanguageText_en.resourceCulture);

		internal static string SpChange203001 => LanguageText_en.ResourceManager.GetString("SpChange203001", LanguageText_en.resourceCulture);

		internal static string SpChange203002 => LanguageText_en.ResourceManager.GetString("SpChange203002", LanguageText_en.resourceCulture);

		internal static string SpChange203003 => LanguageText_en.ResourceManager.GetString("SpChange203003", LanguageText_en.resourceCulture);

		internal static string SpChange203004 => LanguageText_en.ResourceManager.GetString("SpChange203004", LanguageText_en.resourceCulture);

		internal static string SpChange203005 => LanguageText_en.ResourceManager.GetString("SpChange203005", LanguageText_en.resourceCulture);

		internal static string SpChange203006 => LanguageText_en.ResourceManager.GetString("SpChange203006", LanguageText_en.resourceCulture);

		internal static string SpChange203007 => LanguageText_en.ResourceManager.GetString("SpChange203007", LanguageText_en.resourceCulture);

		internal static string SpChange203008 => LanguageText_en.ResourceManager.GetString("SpChange203008", LanguageText_en.resourceCulture);

		internal static string SpChange203009 => LanguageText_en.ResourceManager.GetString("SpChange203009", LanguageText_en.resourceCulture);

		internal static string SpChange203010 => LanguageText_en.ResourceManager.GetString("SpChange203010", LanguageText_en.resourceCulture);

		internal static string SpChange203011 => LanguageText_en.ResourceManager.GetString("SpChange203011", LanguageText_en.resourceCulture);

		internal static string SpChange203012 => LanguageText_en.ResourceManager.GetString("SpChange203012", LanguageText_en.resourceCulture);

		internal static string SpChange203013 => LanguageText_en.ResourceManager.GetString("SpChange203013", LanguageText_en.resourceCulture);

		internal static string SpChange203014 => LanguageText_en.ResourceManager.GetString("SpChange203014", LanguageText_en.resourceCulture);

		internal static string SpChange203015 => LanguageText_en.ResourceManager.GetString("SpChange203015", LanguageText_en.resourceCulture);

		internal static string SpChange203016 => LanguageText_en.ResourceManager.GetString("SpChange203016", LanguageText_en.resourceCulture);

		internal static string SpChange203017 => LanguageText_en.ResourceManager.GetString("SpChange203017", LanguageText_en.resourceCulture);

		internal static string SpChange203018 => LanguageText_en.ResourceManager.GetString("SpChange203018", LanguageText_en.resourceCulture);

		internal static string SpChange203019 => LanguageText_en.ResourceManager.GetString("SpChange203019", LanguageText_en.resourceCulture);

		internal static string SpChange203020 => LanguageText_en.ResourceManager.GetString("SpChange203020", LanguageText_en.resourceCulture);

		internal static string SpChange203021 => LanguageText_en.ResourceManager.GetString("SpChange203021", LanguageText_en.resourceCulture);

		internal static string SpChange203022 => LanguageText_en.ResourceManager.GetString("SpChange203022", LanguageText_en.resourceCulture);

		internal static string SpChange203023 => LanguageText_en.ResourceManager.GetString("SpChange203023", LanguageText_en.resourceCulture);

		internal static string SpChange203024 => LanguageText_en.ResourceManager.GetString("SpChange203024", LanguageText_en.resourceCulture);

		internal static string SpChange203025 => LanguageText_en.ResourceManager.GetString("SpChange203025", LanguageText_en.resourceCulture);

		internal static string SpChange203026 => LanguageText_en.ResourceManager.GetString("SpChange203026", LanguageText_en.resourceCulture);

		internal static string SpChange203027 => LanguageText_en.ResourceManager.GetString("SpChange203027", LanguageText_en.resourceCulture);

		internal static string SpChange203028 => LanguageText_en.ResourceManager.GetString("SpChange203028", LanguageText_en.resourceCulture);

		internal static string SpChange203029 => LanguageText_en.ResourceManager.GetString("SpChange203029", LanguageText_en.resourceCulture);

		internal static string SpChange203030 => LanguageText_en.ResourceManager.GetString("SpChange203030", LanguageText_en.resourceCulture);

		internal static string SpindleConstants => LanguageText_en.ResourceManager.GetString("SpindleConstants", LanguageText_en.resourceCulture);

		internal static string SpindleConstFiles => LanguageText_en.ResourceManager.GetString("SpindleConstFiles", LanguageText_en.resourceCulture);

		internal static string SpindlePressureScale => LanguageText_en.ResourceManager.GetString("SpindlePressureScale", LanguageText_en.resourceCulture);

		internal static string SpindleTorque => LanguageText_en.ResourceManager.GetString("SpindleTorque", LanguageText_en.resourceCulture);

		internal static string StandardDeviation => LanguageText_en.ResourceManager.GetString("StandardDeviation", LanguageText_en.resourceCulture);

		internal static string StartCycleSave => LanguageText_en.ResourceManager.GetString("StartCycleSave", LanguageText_en.resourceCulture);

		internal static string StartFrictionTest => LanguageText_en.ResourceManager.GetString("StartFrictionTest", LanguageText_en.resourceCulture);

		internal static string StartProgram => LanguageText_en.ResourceManager.GetString("StartProgram", LanguageText_en.resourceCulture);

		internal static string StartSignal => LanguageText_en.ResourceManager.GetString("StartSignal", LanguageText_en.resourceCulture);

		internal static string StartStepResExport => LanguageText_en.ResourceManager.GetString("StartStepResExport", LanguageText_en.resourceCulture);

		internal static string StartTest => LanguageText_en.ResourceManager.GetString("StartTest", LanguageText_en.resourceCulture);

		internal static string StatDelete204000 => LanguageText_en.ResourceManager.GetString("StatDelete204000", LanguageText_en.resourceCulture);

		internal static string StatDelete204001 => LanguageText_en.ResourceManager.GetString("StatDelete204001", LanguageText_en.resourceCulture);

		internal static string StatDelete204002 => LanguageText_en.ResourceManager.GetString("StatDelete204002", LanguageText_en.resourceCulture);

		internal static string StatisticCumul => LanguageText_en.ResourceManager.GetString("StatisticCumul", LanguageText_en.resourceCulture);

		internal static string Statistics => LanguageText_en.ResourceManager.GetString("Statistics", LanguageText_en.resourceCulture);

		internal static string StatisticSample => LanguageText_en.ResourceManager.GetString("StatisticSample", LanguageText_en.resourceCulture);

		internal static string StatisticsLastRes => LanguageText_en.ResourceManager.GetString("StatisticsLastRes", LanguageText_en.resourceCulture);

		internal static string Step => LanguageText_en.ResourceManager.GetString("Step", LanguageText_en.resourceCulture);

		internal static string StepFinish => LanguageText_en.ResourceManager.GetString("StepFinish", LanguageText_en.resourceCulture);

		internal static string StepKind => LanguageText_en.ResourceManager.GetString("StepKind", LanguageText_en.resourceCulture);

		internal static string StepKindChoice => LanguageText_en.ResourceManager.GetString("StepKindChoice", LanguageText_en.resourceCulture);

		internal static string StepResults => LanguageText_en.ResourceManager.GetString("StepResults", LanguageText_en.resourceCulture);

		internal static string Steps => LanguageText_en.ResourceManager.GetString("Steps", LanguageText_en.resourceCulture);

		internal static string StepTmin => LanguageText_en.ResourceManager.GetString("StepTmin", LanguageText_en.resourceCulture);

		internal static string StepTplus => LanguageText_en.ResourceManager.GetString("StepTplus", LanguageText_en.resourceCulture);

		internal static string Stop => LanguageText_en.ResourceManager.GetString("Stop", LanguageText_en.resourceCulture);

		internal static string StopNok => LanguageText_en.ResourceManager.GetString("StopNok", LanguageText_en.resourceCulture);

		internal static string StopOk => LanguageText_en.ResourceManager.GetString("StopOk", LanguageText_en.resourceCulture);

		internal static string StopStepResExport => LanguageText_en.ResourceManager.GetString("StopStepResExport", LanguageText_en.resourceCulture);

		internal static string StorageNumber => LanguageText_en.ResourceManager.GetString("StorageNumber", LanguageText_en.resourceCulture);

		internal static string StorageSignals => LanguageText_en.ResourceManager.GetString("StorageSignals", LanguageText_en.resourceCulture);

		internal static string StoreAndBack => LanguageText_en.ResourceManager.GetString("StoreAndBack", LanguageText_en.resourceCulture);

		internal static string SubnetMask => LanguageText_en.ResourceManager.GetString("SubnetMask", LanguageText_en.resourceCulture);

		internal static string SyncOut => LanguageText_en.ResourceManager.GetString("SyncOut", LanguageText_en.resourceCulture);

		internal static string SyncSignal => LanguageText_en.ResourceManager.GetString("SyncSignal", LanguageText_en.resourceCulture);

		internal static string SysChange202000 => LanguageText_en.ResourceManager.GetString("SysChange202000", LanguageText_en.resourceCulture);

		internal static string SysChange202001 => LanguageText_en.ResourceManager.GetString("SysChange202001", LanguageText_en.resourceCulture);

		internal static string SysChange202002 => LanguageText_en.ResourceManager.GetString("SysChange202002", LanguageText_en.resourceCulture);

		internal static string SysChange202003 => LanguageText_en.ResourceManager.GetString("SysChange202003", LanguageText_en.resourceCulture);

		internal static string SysChange202004 => LanguageText_en.ResourceManager.GetString("SysChange202004", LanguageText_en.resourceCulture);

		internal static string SysChange202005 => LanguageText_en.ResourceManager.GetString("SysChange202005", LanguageText_en.resourceCulture);

		internal static string SysChange202006 => LanguageText_en.ResourceManager.GetString("SysChange202006", LanguageText_en.resourceCulture);

		internal static string SysChange202007 => LanguageText_en.ResourceManager.GetString("SysChange202007", LanguageText_en.resourceCulture);

		internal static string SysChange202008 => LanguageText_en.ResourceManager.GetString("SysChange202008", LanguageText_en.resourceCulture);

		internal static string SysChange202009 => LanguageText_en.ResourceManager.GetString("SysChange202009", LanguageText_en.resourceCulture);

		internal static string SysChange202010 => LanguageText_en.ResourceManager.GetString("SysChange202010", LanguageText_en.resourceCulture);

		internal static string SysChange202011 => LanguageText_en.ResourceManager.GetString("SysChange202011", LanguageText_en.resourceCulture);

		internal static string SysChange202012 => LanguageText_en.ResourceManager.GetString("SysChange202012", LanguageText_en.resourceCulture);

		internal static string SysChange202013 => LanguageText_en.ResourceManager.GetString("SysChange202013", LanguageText_en.resourceCulture);

		internal static string SysChange202014 => LanguageText_en.ResourceManager.GetString("SysChange202014", LanguageText_en.resourceCulture);

		internal static string SysChange202015 => LanguageText_en.ResourceManager.GetString("SysChange202015", LanguageText_en.resourceCulture);

		internal static string SysChange202016 => LanguageText_en.ResourceManager.GetString("SysChange202016", LanguageText_en.resourceCulture);

		internal static string SysChange202017 => LanguageText_en.ResourceManager.GetString("SysChange202017", LanguageText_en.resourceCulture);

		internal static string SysChange202018 => LanguageText_en.ResourceManager.GetString("SysChange202018", LanguageText_en.resourceCulture);

		internal static string SystemConstants => LanguageText_en.ResourceManager.GetString("SystemConstants", LanguageText_en.resourceCulture);

		internal static string SystemID => LanguageText_en.ResourceManager.GetString("SystemID", LanguageText_en.resourceCulture);

		internal static string SystemOK => LanguageText_en.ResourceManager.GetString("SystemOK", LanguageText_en.resourceCulture);

		internal static string Target => LanguageText_en.ResourceManager.GetString("Target", LanguageText_en.resourceCulture);

		internal static string TargetRight => LanguageText_en.ResourceManager.GetString("TargetRight", LanguageText_en.resourceCulture);

		internal static string TeachSignal => LanguageText_en.ResourceManager.GetString("TeachSignal", LanguageText_en.resourceCulture);

		internal static string Test => LanguageText_en.ResourceManager.GetString("Test", LanguageText_en.resourceCulture);

		internal static string TestIO => LanguageText_en.ResourceManager.GetString("TestIO", LanguageText_en.resourceCulture);

		internal static string TestMFS => LanguageText_en.ResourceManager.GetString("TestMFS", LanguageText_en.resourceCulture);

		internal static string TestSPSIO => LanguageText_en.ResourceManager.GetString("TestSPSIO", LanguageText_en.resourceCulture);

		internal static string Time => LanguageText_en.ResourceManager.GetString("Time", LanguageText_en.resourceCulture);

		internal static string TimeDateFormat => LanguageText_en.ResourceManager.GetString("TimeDateFormat", LanguageText_en.resourceCulture);

		internal static string TimeSet => LanguageText_en.ResourceManager.GetString("TimeSet", LanguageText_en.resourceCulture);

		internal static string TimeSynchronize => LanguageText_en.ResourceManager.GetString("TimeSynchronize", LanguageText_en.resourceCulture);

		internal static string TM1 => LanguageText_en.ResourceManager.GetString("TM1", LanguageText_en.resourceCulture);

		internal static string TM2 => LanguageText_en.ResourceManager.GetString("TM2", LanguageText_en.resourceCulture);

		internal static string TN => LanguageText_en.ResourceManager.GetString("TN", LanguageText_en.resourceCulture);

		internal static string ToggleCursor => LanguageText_en.ResourceManager.GetString("ToggleCursor", LanguageText_en.resourceCulture);

		internal static string TopAll => LanguageText_en.ResourceManager.GetString("TopAll", LanguageText_en.resourceCulture);

		internal static string TopTen => LanguageText_en.ResourceManager.GetString("TopTen", LanguageText_en.resourceCulture);

		internal static string Torque => LanguageText_en.ResourceManager.GetString("Torque", LanguageText_en.resourceCulture);

		internal static string Torqueftlb => LanguageText_en.ResourceManager.GetString("Torqueftlb", LanguageText_en.resourceCulture);

		internal static string Torqueinlb => LanguageText_en.ResourceManager.GetString("Torqueinlb", LanguageText_en.resourceCulture);

		internal static string Torqueinoz => LanguageText_en.ResourceManager.GetString("Torqueinoz", LanguageText_en.resourceCulture);

		internal static string Torquekgcm => LanguageText_en.ResourceManager.GetString("Torquekgcm", LanguageText_en.resourceCulture);

		internal static string Torquekgm => LanguageText_en.ResourceManager.GetString("Torquekgm", LanguageText_en.resourceCulture);

		internal static string TorqueNcm => LanguageText_en.ResourceManager.GetString("TorqueNcm", LanguageText_en.resourceCulture);

		internal static string TorqueNm => LanguageText_en.ResourceManager.GetString("TorqueNm", LanguageText_en.resourceCulture);

		internal static string TorqueRedundantTime => LanguageText_en.ResourceManager.GetString("TorqueRedundantTime", LanguageText_en.resourceCulture);

		internal static string TorqueRedundantTolerance => LanguageText_en.ResourceManager.GetString("TorqueRedundantTolerance", LanguageText_en.resourceCulture);

		internal static string TorqueSensorInvers => LanguageText_en.ResourceManager.GetString("TorqueSensorInvers", LanguageText_en.resourceCulture);

		internal static string TorqueSensorScale => LanguageText_en.ResourceManager.GetString("TorqueSensorScale", LanguageText_en.resourceCulture);

		internal static string TorqueSensorTolerance => LanguageText_en.ResourceManager.GetString("TorqueSensorTolerance", LanguageText_en.resourceCulture);

		internal static string TorqueUnitChoose => LanguageText_en.ResourceManager.GetString("TorqueUnitChoose", LanguageText_en.resourceCulture);

		internal static string TreshTorque => LanguageText_en.ResourceManager.GetString("TreshTorque", LanguageText_en.resourceCulture);

		internal static string Type => LanguageText_en.ResourceManager.GetString("Type", LanguageText_en.resourceCulture);

		internal static string Unit => LanguageText_en.ResourceManager.GetString("Unit", LanguageText_en.resourceCulture);

		internal static string UnitBar => LanguageText_en.ResourceManager.GetString("UnitBar", LanguageText_en.resourceCulture);

		internal static string UpperLimit => LanguageText_en.ResourceManager.GetString("UpperLimit", LanguageText_en.resourceCulture);

		internal static string UsedKeyboard => LanguageText_en.ResourceManager.GetString("UsedKeyboard", LanguageText_en.resourceCulture);

		internal static string UsedValueNumber => LanguageText_en.ResourceManager.GetString("UsedValueNumber", LanguageText_en.resourceCulture);

		internal static string UseLanguageSettings => LanguageText_en.ResourceManager.GetString("UseLanguageSettings", LanguageText_en.resourceCulture);

		internal static string User => LanguageText_en.ResourceManager.GetString("User", LanguageText_en.resourceCulture);

		internal static string UserRights => LanguageText_en.ResourceManager.GetString("UserRights", LanguageText_en.resourceCulture);

		internal static string USTime => LanguageText_en.ResourceManager.GetString("USTime", LanguageText_en.resourceCulture);

		internal static string Valid => LanguageText_en.ResourceManager.GetString("Valid", LanguageText_en.resourceCulture);

		internal static string Value => LanguageText_en.ResourceManager.GetString("Value", LanguageText_en.resourceCulture);

		internal static string ValueRange => LanguageText_en.ResourceManager.GetString("ValueRange", LanguageText_en.resourceCulture);

		internal static string ValuesNotApplied => LanguageText_en.ResourceManager.GetString("ValuesNotApplied", LanguageText_en.resourceCulture);

		internal static string VersionController => LanguageText_en.ResourceManager.GetString("VersionController", LanguageText_en.resourceCulture);

		internal static string VersionInfo => LanguageText_en.ResourceManager.GetString("VersionInfo", LanguageText_en.resourceCulture);

		internal static string VersionVisu => LanguageText_en.ResourceManager.GetString("VersionVisu", LanguageText_en.resourceCulture);

		internal static string Visualisation => LanguageText_en.ResourceManager.GetString("Visualisation", LanguageText_en.resourceCulture);

		internal static string VisuParam => LanguageText_en.ResourceManager.GetString("VisuParam", LanguageText_en.resourceCulture);

		internal static string Voltage => LanguageText_en.ResourceManager.GetString("Voltage", LanguageText_en.resourceCulture);

		internal static string WaitForAck => LanguageText_en.ResourceManager.GetString("WaitForAck", LanguageText_en.resourceCulture);

		internal static string Warning => LanguageText_en.ResourceManager.GetString("Warning", LanguageText_en.resourceCulture);

		internal static string WarningMode => LanguageText_en.ResourceManager.GetString("WarningMode", LanguageText_en.resourceCulture);

		internal static string WarningNumber => LanguageText_en.ResourceManager.GetString("WarningNumber", LanguageText_en.resourceCulture);

		internal static string WasReset => LanguageText_en.ResourceManager.GetString("WasReset", LanguageText_en.resourceCulture);

		internal static string WasSet => LanguageText_en.ResourceManager.GetString("WasSet", LanguageText_en.resourceCulture);

		internal static string WeberCurveFormat => LanguageText_en.ResourceManager.GetString("WeberCurveFormat", LanguageText_en.resourceCulture);

		internal static string WN => LanguageText_en.ResourceManager.GetString("WN", LanguageText_en.resourceCulture);

		internal static string WriteLastNIOTable => LanguageText_en.ResourceManager.GetString("WriteLastNIOTable", LanguageText_en.resourceCulture);

		internal static string WriteLastResultsTable => LanguageText_en.ResourceManager.GetString("WriteLastResultsTable", LanguageText_en.resourceCulture);

		internal static string WriteLogbookData => LanguageText_en.ResourceManager.GetString("WriteLogbookData", LanguageText_en.resourceCulture);

		internal static string WriteLogBookTable => LanguageText_en.ResourceManager.GetString("WriteLogBookTable", LanguageText_en.resourceCulture);

		internal static string WriteStepResults => LanguageText_en.ResourceManager.GetString("WriteStepResults", LanguageText_en.resourceCulture);

		internal static string Xmax => LanguageText_en.ResourceManager.GetString("Xmax", LanguageText_en.resourceCulture);

		internal static string Xmin => LanguageText_en.ResourceManager.GetString("Xmin", LanguageText_en.resourceCulture);

		internal static string XmlExport => LanguageText_en.ResourceManager.GetString("XmlExport", LanguageText_en.resourceCulture);

		internal static string Yes => LanguageText_en.ResourceManager.GetString("Yes", LanguageText_en.resourceCulture);

		internal static string ZoomIn => LanguageText_en.ResourceManager.GetString("ZoomIn", LanguageText_en.resourceCulture);

		internal static string ZoomOut => LanguageText_en.ResourceManager.GetString("ZoomOut", LanguageText_en.resourceCulture);

		internal LanguageText_en()
		{
		}
	}
}
