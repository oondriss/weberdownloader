using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Visualisation
{
	[DebuggerNonUserCode]
	[CompilerGenerated]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	internal class LanguageText_sk
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(LanguageText_sk.resourceMan, null))
				{
					ResourceManager resourceManager = LanguageText_sk.resourceMan = new ResourceManager("Visualisation.LanguageText_sk", typeof(LanguageText_sk).Assembly);
				}
				return LanguageText_sk.resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return LanguageText_sk.resourceCulture;
			}
			set
			{
				LanguageText_sk.resourceCulture = value;
			}
		}

		internal static string Abr_Program => LanguageText_sk.ResourceManager.GetString("Abr_Program", LanguageText_sk.resourceCulture);

		internal static string AbrAnaDepth => LanguageText_sk.ResourceManager.GetString("AbrAnaDepth", LanguageText_sk.resourceCulture);

		internal static string AbrAnaSignal => LanguageText_sk.ResourceManager.GetString("AbrAnaSignal", LanguageText_sk.resourceCulture);

		internal static string AbrAngle => LanguageText_sk.ResourceManager.GetString("AbrAngle", LanguageText_sk.resourceCulture);

		internal static string AbrDelayTorque => LanguageText_sk.ResourceManager.GetString("AbrDelayTorque", LanguageText_sk.resourceCulture);

		internal static string AbrDepthGrad => LanguageText_sk.ResourceManager.GetString("AbrDepthGrad", LanguageText_sk.resourceCulture);

		internal static string AbrFilteredTorque => LanguageText_sk.ResourceManager.GetString("AbrFilteredTorque", LanguageText_sk.resourceCulture);

		internal static string AbrGradient => LanguageText_sk.ResourceManager.GetString("AbrGradient", LanguageText_sk.resourceCulture);

		internal static string AbrM360Follow => LanguageText_sk.ResourceManager.GetString("AbrM360Follow", LanguageText_sk.resourceCulture);

		internal static string AbrMaxTorque => LanguageText_sk.ResourceManager.GetString("AbrMaxTorque", LanguageText_sk.resourceCulture);

		internal static string AbrNumber => LanguageText_sk.ResourceManager.GetString("AbrNumber", LanguageText_sk.resourceCulture);

		internal static string AbrTime => LanguageText_sk.ResourceManager.GetString("AbrTime", LanguageText_sk.resourceCulture);

		internal static string AbrTorque => LanguageText_sk.ResourceManager.GetString("AbrTorque", LanguageText_sk.resourceCulture);

		internal static string AccessCheck => LanguageText_sk.ResourceManager.GetString("AccessCheck", LanguageText_sk.resourceCulture);

		internal static string AccessRequest => LanguageText_sk.ResourceManager.GetString("AccessRequest", LanguageText_sk.resourceCulture);

		internal static string Actualize => LanguageText_sk.ResourceManager.GetString("Actualize", LanguageText_sk.resourceCulture);

		internal static string AddEntry => LanguageText_sk.ResourceManager.GetString("AddEntry", LanguageText_sk.resourceCulture);

		internal static string AIError => LanguageText_sk.ResourceManager.GetString("AIError", LanguageText_sk.resourceCulture);

		internal static string All => LanguageText_sk.ResourceManager.GetString("All", LanguageText_sk.resourceCulture);

		internal static string AllFiles => LanguageText_sk.ResourceManager.GetString("AllFiles", LanguageText_sk.resourceCulture);

		internal static string AnaDepth => LanguageText_sk.ResourceManager.GetString("AnaDepth", LanguageText_sk.resourceCulture);

		internal static string Anagenbediener => LanguageText_sk.ResourceManager.GetString("Anagenbediener", LanguageText_sk.resourceCulture);

		internal static string Analysis => LanguageText_sk.ResourceManager.GetString("Analysis", LanguageText_sk.resourceCulture);

		internal static string AnaOutput => LanguageText_sk.ResourceManager.GetString("AnaOutput", LanguageText_sk.resourceCulture);

		internal static string AnaSignal => LanguageText_sk.ResourceManager.GetString("AnaSignal", LanguageText_sk.resourceCulture);

		internal static string AnaSigOffset => LanguageText_sk.ResourceManager.GetString("AnaSigOffset", LanguageText_sk.resourceCulture);

		internal static string AnaSigScale => LanguageText_sk.ResourceManager.GetString("AnaSigScale", LanguageText_sk.resourceCulture);

		internal static string Angle => LanguageText_sk.ResourceManager.GetString("Angle", LanguageText_sk.resourceCulture);

		internal static string AngleRedundantTolerance => LanguageText_sk.ResourceManager.GetString("AngleRedundantTolerance", LanguageText_sk.resourceCulture);

		internal static string AngleSensorInvers => LanguageText_sk.ResourceManager.GetString("AngleSensorInvers", LanguageText_sk.resourceCulture);

		internal static string AngleSensorScale => LanguageText_sk.ResourceManager.GetString("AngleSensorScale", LanguageText_sk.resourceCulture);

		internal static string AngleTorqueSensor => LanguageText_sk.ResourceManager.GetString("AngleTorqueSensor", LanguageText_sk.resourceCulture);

		internal static string Apply => LanguageText_sk.ResourceManager.GetString("Apply", LanguageText_sk.resourceCulture);

		internal static string ApplyEntry => LanguageText_sk.ResourceManager.GetString("ApplyEntry", LanguageText_sk.resourceCulture);

		internal static string AutoCurveAbort => LanguageText_sk.ResourceManager.GetString("AutoCurveAbort", LanguageText_sk.resourceCulture);

		internal static string Automatic => LanguageText_sk.ResourceManager.GetString("Automatic", LanguageText_sk.resourceCulture);

		internal static string AutoMode => LanguageText_sk.ResourceManager.GetString("AutoMode", LanguageText_sk.resourceCulture);

		internal static string AvailableValueNumber => LanguageText_sk.ResourceManager.GetString("AvailableValueNumber", LanguageText_sk.resourceCulture);

		internal static string Back => LanguageText_sk.ResourceManager.GetString("Back", LanguageText_sk.resourceCulture);

		internal static string Backup => LanguageText_sk.ResourceManager.GetString("Backup", LanguageText_sk.resourceCulture);

		internal static string Backup205000 => LanguageText_sk.ResourceManager.GetString("Backup205000", LanguageText_sk.resourceCulture);

		internal static string Backup205001 => LanguageText_sk.ResourceManager.GetString("Backup205001", LanguageText_sk.resourceCulture);

		internal static string Backup205002 => LanguageText_sk.ResourceManager.GetString("Backup205002", LanguageText_sk.resourceCulture);

		internal static string Backup205003 => LanguageText_sk.ResourceManager.GetString("Backup205003", LanguageText_sk.resourceCulture);

		internal static string Battery => LanguageText_sk.ResourceManager.GetString("Battery", LanguageText_sk.resourceCulture);

		internal static string Baudrate => LanguageText_sk.ResourceManager.GetString("Baudrate", LanguageText_sk.resourceCulture);

		internal static string bt0 => LanguageText_sk.ResourceManager.GetString("bt0", LanguageText_sk.resourceCulture);

		internal static string bt1 => LanguageText_sk.ResourceManager.GetString("bt1", LanguageText_sk.resourceCulture);

		internal static string bt2 => LanguageText_sk.ResourceManager.GetString("bt2", LanguageText_sk.resourceCulture);

		internal static string bt3 => LanguageText_sk.ResourceManager.GetString("bt3", LanguageText_sk.resourceCulture);

		internal static string bt4 => LanguageText_sk.ResourceManager.GetString("bt4", LanguageText_sk.resourceCulture);

		internal static string bt5 => LanguageText_sk.ResourceManager.GetString("bt5", LanguageText_sk.resourceCulture);

		internal static string bt6 => LanguageText_sk.ResourceManager.GetString("bt6", LanguageText_sk.resourceCulture);

		internal static string bt7 => LanguageText_sk.ResourceManager.GetString("bt7", LanguageText_sk.resourceCulture);

		internal static string bt8 => LanguageText_sk.ResourceManager.GetString("bt8", LanguageText_sk.resourceCulture);

		internal static string bt9 => LanguageText_sk.ResourceManager.GetString("bt9", LanguageText_sk.resourceCulture);

		internal static string btA => LanguageText_sk.ResourceManager.GetString("btA", LanguageText_sk.resourceCulture);

		internal static string btActivate => LanguageText_sk.ResourceManager.GetString("btActivate", LanguageText_sk.resourceCulture);

		internal static string btApply => LanguageText_sk.ResourceManager.GetString("btApply", LanguageText_sk.resourceCulture);

		internal static string btAutomaticHide => LanguageText_sk.ResourceManager.GetString("btAutomaticHide", LanguageText_sk.resourceCulture);

		internal static string btB => LanguageText_sk.ResourceManager.GetString("btB", LanguageText_sk.resourceCulture);

		internal static string btBackspace => LanguageText_sk.ResourceManager.GetString("btBackspace", LanguageText_sk.resourceCulture);

		internal static string btC => LanguageText_sk.ResourceManager.GetString("btC", LanguageText_sk.resourceCulture);

		internal static string btCancel => LanguageText_sk.ResourceManager.GetString("btCancel", LanguageText_sk.resourceCulture);

		internal static string btChangeDefaultDir => LanguageText_sk.ResourceManager.GetString("btChangeDefaultDir", LanguageText_sk.resourceCulture);

		internal static string btD => LanguageText_sk.ResourceManager.GetString("btD", LanguageText_sk.resourceCulture);

		internal static string btE => LanguageText_sk.ResourceManager.GetString("btE", LanguageText_sk.resourceCulture);

		internal static string btErase => LanguageText_sk.ResourceManager.GetString("btErase", LanguageText_sk.resourceCulture);

		internal static string btF => LanguageText_sk.ResourceManager.GetString("btF", LanguageText_sk.resourceCulture);

		internal static string btG => LanguageText_sk.ResourceManager.GetString("btG", LanguageText_sk.resourceCulture);

		internal static string btH => LanguageText_sk.ResourceManager.GetString("btH", LanguageText_sk.resourceCulture);

		internal static string btHide => LanguageText_sk.ResourceManager.GetString("btHide", LanguageText_sk.resourceCulture);

		internal static string btI => LanguageText_sk.ResourceManager.GetString("btI", LanguageText_sk.resourceCulture);

		internal static string btIdAscii => LanguageText_sk.ResourceManager.GetString("btIdAscii", LanguageText_sk.resourceCulture);

		internal static string btIdHex => LanguageText_sk.ResourceManager.GetString("btIdHex", LanguageText_sk.resourceCulture);

		internal static string btJ => LanguageText_sk.ResourceManager.GetString("btJ", LanguageText_sk.resourceCulture);

		internal static string btK => LanguageText_sk.ResourceManager.GetString("btK", LanguageText_sk.resourceCulture);

		internal static string btL => LanguageText_sk.ResourceManager.GetString("btL", LanguageText_sk.resourceCulture);

		internal static string btLoad => LanguageText_sk.ResourceManager.GetString("btLoad", LanguageText_sk.resourceCulture);

		internal static string btM => LanguageText_sk.ResourceManager.GetString("btM", LanguageText_sk.resourceCulture);

		internal static string btMinusDown => LanguageText_sk.ResourceManager.GetString("btMinusDown", LanguageText_sk.resourceCulture);

		internal static string btMinusUp => LanguageText_sk.ResourceManager.GetString("btMinusUp", LanguageText_sk.resourceCulture);

		internal static string btN => LanguageText_sk.ResourceManager.GetString("btN", LanguageText_sk.resourceCulture);

		internal static string btNOID => LanguageText_sk.ResourceManager.GetString("btNOID", LanguageText_sk.resourceCulture);

		internal static string btO => LanguageText_sk.ResourceManager.GetString("btO", LanguageText_sk.resourceCulture);

		internal static string btP => LanguageText_sk.ResourceManager.GetString("btP", LanguageText_sk.resourceCulture);

		internal static string btQ => LanguageText_sk.ResourceManager.GetString("btQ", LanguageText_sk.resourceCulture);

		internal static string btR => LanguageText_sk.ResourceManager.GetString("btR", LanguageText_sk.resourceCulture);

		internal static string btRes1 => LanguageText_sk.ResourceManager.GetString("btRes1", LanguageText_sk.resourceCulture);

		internal static string btRes2 => LanguageText_sk.ResourceManager.GetString("btRes2", LanguageText_sk.resourceCulture);

		internal static string btRes3 => LanguageText_sk.ResourceManager.GetString("btRes3", LanguageText_sk.resourceCulture);

		internal static string btS => LanguageText_sk.ResourceManager.GetString("btS", LanguageText_sk.resourceCulture);

		internal static string btShift => LanguageText_sk.ResourceManager.GetString("btShift", LanguageText_sk.resourceCulture);

		internal static string btSpace => LanguageText_sk.ResourceManager.GetString("btSpace", LanguageText_sk.resourceCulture);

		internal static string btT => LanguageText_sk.ResourceManager.GetString("btT", LanguageText_sk.resourceCulture);

		internal static string btTeach => LanguageText_sk.ResourceManager.GetString("btTeach", LanguageText_sk.resourceCulture);

		internal static string btU => LanguageText_sk.ResourceManager.GetString("btU", LanguageText_sk.resourceCulture);

		internal static string btV => LanguageText_sk.ResourceManager.GetString("btV", LanguageText_sk.resourceCulture);

		internal static string btW => LanguageText_sk.ResourceManager.GetString("btW", LanguageText_sk.resourceCulture);

		internal static string btX => LanguageText_sk.ResourceManager.GetString("btX", LanguageText_sk.resourceCulture);

		internal static string btY => LanguageText_sk.ResourceManager.GetString("btY", LanguageText_sk.resourceCulture);

		internal static string btZ => LanguageText_sk.ResourceManager.GetString("btZ", LanguageText_sk.resourceCulture);

		internal static string CalculateCurves => LanguageText_sk.ResourceManager.GetString("CalculateCurves", LanguageText_sk.resourceCulture);

		internal static string CalDisable => LanguageText_sk.ResourceManager.GetString("CalDisable", LanguageText_sk.resourceCulture);

		internal static string CalibrationSignal => LanguageText_sk.ResourceManager.GetString("CalibrationSignal", LanguageText_sk.resourceCulture);

		internal static string Cancel => LanguageText_sk.ResourceManager.GetString("Cancel", LanguageText_sk.resourceCulture);

		internal static string Changed => LanguageText_sk.ResourceManager.GetString("Changed", LanguageText_sk.resourceCulture);

		internal static string ChangeEntry => LanguageText_sk.ResourceManager.GetString("ChangeEntry", LanguageText_sk.resourceCulture);

		internal static string ChangePassCode => LanguageText_sk.ResourceManager.GetString("ChangePassCode", LanguageText_sk.resourceCulture);

		internal static string ChangesLog => LanguageText_sk.ResourceManager.GetString("ChangesLog", LanguageText_sk.resourceCulture);

		internal static string chBEmtyPrograms => LanguageText_sk.ResourceManager.GetString("chBEmtyPrograms", LanguageText_sk.resourceCulture);

		internal static string chBProgPreview => LanguageText_sk.ResourceManager.GetString("chBProgPreview", LanguageText_sk.resourceCulture);

		internal static string chbProgramSpecific => LanguageText_sk.ResourceManager.GetString("chbProgramSpecific", LanguageText_sk.resourceCulture);

		internal static string chBUseDefaultDir => LanguageText_sk.ResourceManager.GetString("chBUseDefaultDir", LanguageText_sk.resourceCulture);

		internal static string CheckFrictionTestStart => LanguageText_sk.ResourceManager.GetString("CheckFrictionTestStart", LanguageText_sk.resourceCulture);

		internal static string CheckHandStart => LanguageText_sk.ResourceManager.GetString("CheckHandStart", LanguageText_sk.resourceCulture);

		internal static string CheckParameter => LanguageText_sk.ResourceManager.GetString("CheckParameter", LanguageText_sk.resourceCulture);

		internal static string CheckRight => LanguageText_sk.ResourceManager.GetString("CheckRight", LanguageText_sk.resourceCulture);

		internal static string Close => LanguageText_sk.ResourceManager.GetString("Close", LanguageText_sk.resourceCulture);

		internal static string ControllerName => LanguageText_sk.ResourceManager.GetString("ControllerName", LanguageText_sk.resourceCulture);

		internal static string ControllerTime => LanguageText_sk.ResourceManager.GetString("ControllerTime", LanguageText_sk.resourceCulture);

		internal static string CopyProgram => LanguageText_sk.ResourceManager.GetString("CopyProgram", LanguageText_sk.resourceCulture);

		internal static string CountPassMax => LanguageText_sk.ResourceManager.GetString("CountPassMax", LanguageText_sk.resourceCulture);

		internal static string CreatedUsers => LanguageText_sk.ResourceManager.GetString("CreatedUsers", LanguageText_sk.resourceCulture);

		internal static string CumulStats => LanguageText_sk.ResourceManager.GetString("CumulStats", LanguageText_sk.resourceCulture);

		internal static string CursorsCannotSwitch => LanguageText_sk.ResourceManager.GetString("CursorsCannotSwitch", LanguageText_sk.resourceCulture);

		internal static string CurveDisplay => LanguageText_sk.ResourceManager.GetString("CurveDisplay", LanguageText_sk.resourceCulture);

		internal static string CurveLoad => LanguageText_sk.ResourceManager.GetString("CurveLoad", LanguageText_sk.resourceCulture);

		internal static string CurvePrint => LanguageText_sk.ResourceManager.GetString("CurvePrint", LanguageText_sk.resourceCulture);

		internal static string CurveResultKind => LanguageText_sk.ResourceManager.GetString("CurveResultKind", LanguageText_sk.resourceCulture);

		internal static string CurveResultNumber => LanguageText_sk.ResourceManager.GetString("CurveResultNumber", LanguageText_sk.resourceCulture);

		internal static string Curves => LanguageText_sk.ResourceManager.GetString("Curves", LanguageText_sk.resourceCulture);

		internal static string CurveSave => LanguageText_sk.ResourceManager.GetString("CurveSave", LanguageText_sk.resourceCulture);

		internal static string CurveSelection => LanguageText_sk.ResourceManager.GetString("CurveSelection", LanguageText_sk.resourceCulture);

		internal static string CurvesZoomedIn => LanguageText_sk.ResourceManager.GetString("CurvesZoomedIn", LanguageText_sk.resourceCulture);

		internal static string CurvesZoomedOut => LanguageText_sk.ResourceManager.GetString("CurvesZoomedOut", LanguageText_sk.resourceCulture);

		internal static string CustomCounter => LanguageText_sk.ResourceManager.GetString("CustomCounter", LanguageText_sk.resourceCulture);

		internal static string Cycle => LanguageText_sk.ResourceManager.GetString("Cycle", LanguageText_sk.resourceCulture);

		internal static string CycleCounter => LanguageText_sk.ResourceManager.GetString("CycleCounter", LanguageText_sk.resourceCulture);

		internal static string CycleNumber => LanguageText_sk.ResourceManager.GetString("CycleNumber", LanguageText_sk.resourceCulture);

		internal static string CycleSave => LanguageText_sk.ResourceManager.GetString("CycleSave", LanguageText_sk.resourceCulture);

		internal static string CylinderPressureScale => LanguageText_sk.ResourceManager.GetString("CylinderPressureScale", LanguageText_sk.resourceCulture);

		internal static string Czech => LanguageText_sk.ResourceManager.GetString("Czech", LanguageText_sk.resourceCulture);

		internal static string DateTime => LanguageText_sk.ResourceManager.GetString("DateTime", LanguageText_sk.resourceCulture);

		internal static string DeblockController => LanguageText_sk.ResourceManager.GetString("DeblockController", LanguageText_sk.resourceCulture);

		internal static string DeclForBackupSave => LanguageText_sk.ResourceManager.GetString("DeclForBackupSave", LanguageText_sk.resourceCulture);

		internal static string DeclForSpSave => LanguageText_sk.ResourceManager.GetString("DeclForSpSave", LanguageText_sk.resourceCulture);

		internal static string Degree => LanguageText_sk.ResourceManager.GetString("Degree", LanguageText_sk.resourceCulture);

		internal static string DelayTorque => LanguageText_sk.ResourceManager.GetString("DelayTorque", LanguageText_sk.resourceCulture);

		internal static string DeleteCounter => LanguageText_sk.ResourceManager.GetString("DeleteCounter", LanguageText_sk.resourceCulture);

		internal static string DeleteCustomCounter => LanguageText_sk.ResourceManager.GetString("DeleteCustomCounter", LanguageText_sk.resourceCulture);

		internal static string DeleteEntry => LanguageText_sk.ResourceManager.GetString("DeleteEntry", LanguageText_sk.resourceCulture);

		internal static string DeleteJob => LanguageText_sk.ResourceManager.GetString("DeleteJob", LanguageText_sk.resourceCulture);

		internal static string DeleteLastResults => LanguageText_sk.ResourceManager.GetString("DeleteLastResults", LanguageText_sk.resourceCulture);

		internal static string DeleteProgram => LanguageText_sk.ResourceManager.GetString("DeleteProgram", LanguageText_sk.resourceCulture);

		internal static string DeleteRecursiveStat => LanguageText_sk.ResourceManager.GetString("DeleteRecursiveStat", LanguageText_sk.resourceCulture);

		internal static string DeleteStep => LanguageText_sk.ResourceManager.GetString("DeleteStep", LanguageText_sk.resourceCulture);

		internal static string DeleteValues => LanguageText_sk.ResourceManager.GetString("DeleteValues", LanguageText_sk.resourceCulture);

		internal static string DepthFilterTime => LanguageText_sk.ResourceManager.GetString("DepthFilterTime", LanguageText_sk.resourceCulture);

		internal static string DepthGrad => LanguageText_sk.ResourceManager.GetString("DepthGrad", LanguageText_sk.resourceCulture);

		internal static string DepthGradLength => LanguageText_sk.ResourceManager.GetString("DepthGradLength", LanguageText_sk.resourceCulture);

		internal static string DepthSensor => LanguageText_sk.ResourceManager.GetString("DepthSensor", LanguageText_sk.resourceCulture);

		internal static string DepthSensorInvers => LanguageText_sk.ResourceManager.GetString("DepthSensorInvers", LanguageText_sk.resourceCulture);

		internal static string DGAddress => LanguageText_sk.ResourceManager.GetString("DGAddress", LanguageText_sk.resourceCulture);

		internal static string DHCP => LanguageText_sk.ResourceManager.GetString("DHCP", LanguageText_sk.resourceCulture);

		internal static string DigitalSignal => LanguageText_sk.ResourceManager.GetString("DigitalSignal", LanguageText_sk.resourceCulture);

		internal static string DigitOut => LanguageText_sk.ResourceManager.GetString("DigitOut", LanguageText_sk.resourceCulture);

		internal static string DigSigAtEnd => LanguageText_sk.ResourceManager.GetString("DigSigAtEnd", LanguageText_sk.resourceCulture);

		internal static string DigSigRunning => LanguageText_sk.ResourceManager.GetString("DigSigRunning", LanguageText_sk.resourceCulture);

		internal static string DiscardChanges => LanguageText_sk.ResourceManager.GetString("DiscardChanges", LanguageText_sk.resourceCulture);

		internal static string DisplaySpindlePressureAsKN => LanguageText_sk.ResourceManager.GetString("DisplaySpindlePressureAsKN", LanguageText_sk.resourceCulture);

		internal static string Done => LanguageText_sk.ResourceManager.GetString("Done", LanguageText_sk.resourceCulture);

		internal static string DriveUnit => LanguageText_sk.ResourceManager.GetString("DriveUnit", LanguageText_sk.resourceCulture);

		internal static string DriveUnitInvers => LanguageText_sk.ResourceManager.GetString("DriveUnitInvers", LanguageText_sk.resourceCulture);

		internal static string Driving => LanguageText_sk.ResourceManager.GetString("Driving", LanguageText_sk.resourceCulture);

		internal static string DrivingStep => LanguageText_sk.ResourceManager.GetString("DrivingStep", LanguageText_sk.resourceCulture);

		internal static string EditCancel => LanguageText_sk.ResourceManager.GetString("EditCancel", LanguageText_sk.resourceCulture);

		internal static string EditEntry => LanguageText_sk.ResourceManager.GetString("EditEntry", LanguageText_sk.resourceCulture);

		internal static string EditProgram => LanguageText_sk.ResourceManager.GetString("EditProgram", LanguageText_sk.resourceCulture);

		internal static string EditStep => LanguageText_sk.ResourceManager.GetString("EditStep", LanguageText_sk.resourceCulture);

		internal static string EMGMode => LanguageText_sk.ResourceManager.GetString("EMGMode", LanguageText_sk.resourceCulture);

		internal static string Empty => LanguageText_sk.ResourceManager.GetString("Empty", LanguageText_sk.resourceCulture);

		internal static string EmptyString => LanguageText_sk.ResourceManager.GetString("EmptyString", LanguageText_sk.resourceCulture);

		internal static string EncError => LanguageText_sk.ResourceManager.GetString("EncError", LanguageText_sk.resourceCulture);

		internal static string English => LanguageText_sk.ResourceManager.GetString("English", LanguageText_sk.resourceCulture);

		internal static string Error1000 => LanguageText_sk.ResourceManager.GetString("Error1000", LanguageText_sk.resourceCulture);

		internal static string Error1001 => LanguageText_sk.ResourceManager.GetString("Error1001", LanguageText_sk.resourceCulture);

		internal static string Error1002 => LanguageText_sk.ResourceManager.GetString("Error1002", LanguageText_sk.resourceCulture);

		internal static string Error1003 => LanguageText_sk.ResourceManager.GetString("Error1003", LanguageText_sk.resourceCulture);

		internal static string Error1004 => LanguageText_sk.ResourceManager.GetString("Error1004", LanguageText_sk.resourceCulture);

		internal static string Error1005 => LanguageText_sk.ResourceManager.GetString("Error1005", LanguageText_sk.resourceCulture);

		internal static string Error1006 => LanguageText_sk.ResourceManager.GetString("Error1006", LanguageText_sk.resourceCulture);

		internal static string Error1007 => LanguageText_sk.ResourceManager.GetString("Error1007", LanguageText_sk.resourceCulture);

		internal static string Error1008 => LanguageText_sk.ResourceManager.GetString("Error1008", LanguageText_sk.resourceCulture);

		internal static string Error1009 => LanguageText_sk.ResourceManager.GetString("Error1009", LanguageText_sk.resourceCulture);

		internal static string Error1010 => LanguageText_sk.ResourceManager.GetString("Error1010", LanguageText_sk.resourceCulture);

		internal static string Error1011 => LanguageText_sk.ResourceManager.GetString("Error1011", LanguageText_sk.resourceCulture);

		internal static string Error1012 => LanguageText_sk.ResourceManager.GetString("Error1012", LanguageText_sk.resourceCulture);

		internal static string Error1013 => LanguageText_sk.ResourceManager.GetString("Error1013", LanguageText_sk.resourceCulture);

		internal static string Error1014 => LanguageText_sk.ResourceManager.GetString("Error1014", LanguageText_sk.resourceCulture);

		internal static string Error1015 => LanguageText_sk.ResourceManager.GetString("Error1015", LanguageText_sk.resourceCulture);

		internal static string Error1016 => LanguageText_sk.ResourceManager.GetString("Error1016", LanguageText_sk.resourceCulture);

		internal static string Error1017 => LanguageText_sk.ResourceManager.GetString("Error1017", LanguageText_sk.resourceCulture);

		internal static string Error1018 => LanguageText_sk.ResourceManager.GetString("Error1018", LanguageText_sk.resourceCulture);

		internal static string Error1019 => LanguageText_sk.ResourceManager.GetString("Error1019", LanguageText_sk.resourceCulture);

		internal static string Error1020 => LanguageText_sk.ResourceManager.GetString("Error1020", LanguageText_sk.resourceCulture);

		internal static string Error1021 => LanguageText_sk.ResourceManager.GetString("Error1021", LanguageText_sk.resourceCulture);

		internal static string Error1022 => LanguageText_sk.ResourceManager.GetString("Error1022", LanguageText_sk.resourceCulture);

		internal static string Error1023 => LanguageText_sk.ResourceManager.GetString("Error1023", LanguageText_sk.resourceCulture);

		internal static string Error1024 => LanguageText_sk.ResourceManager.GetString("Error1024", LanguageText_sk.resourceCulture);

		internal static string Error1025 => LanguageText_sk.ResourceManager.GetString("Error1025", LanguageText_sk.resourceCulture);

		internal static string Error1026 => LanguageText_sk.ResourceManager.GetString("Error1026", LanguageText_sk.resourceCulture);

		internal static string Error1027 => LanguageText_sk.ResourceManager.GetString("Error1027", LanguageText_sk.resourceCulture);

		internal static string Error1028 => LanguageText_sk.ResourceManager.GetString("Error1028", LanguageText_sk.resourceCulture);

		internal static string Error1029 => LanguageText_sk.ResourceManager.GetString("Error1029", LanguageText_sk.resourceCulture);

		internal static string Error1030 => LanguageText_sk.ResourceManager.GetString("Error1030", LanguageText_sk.resourceCulture);

		internal static string Error1031 => LanguageText_sk.ResourceManager.GetString("Error1031", LanguageText_sk.resourceCulture);

		internal static string Error1032 => LanguageText_sk.ResourceManager.GetString("Error1032", LanguageText_sk.resourceCulture);

		internal static string Error1033 => LanguageText_sk.ResourceManager.GetString("Error1033", LanguageText_sk.resourceCulture);

		internal static string Error1034 => LanguageText_sk.ResourceManager.GetString("Error1034", LanguageText_sk.resourceCulture);

		internal static string Error1035 => LanguageText_sk.ResourceManager.GetString("Error1035", LanguageText_sk.resourceCulture);

		internal static string Error1036 => LanguageText_sk.ResourceManager.GetString("Error1036", LanguageText_sk.resourceCulture);

		internal static string Error1037 => LanguageText_sk.ResourceManager.GetString("Error1037", LanguageText_sk.resourceCulture);

		internal static string Error1038 => LanguageText_sk.ResourceManager.GetString("Error1038", LanguageText_sk.resourceCulture);

		internal static string Error1100 => LanguageText_sk.ResourceManager.GetString("Error1100", LanguageText_sk.resourceCulture);

		internal static string Error1101 => LanguageText_sk.ResourceManager.GetString("Error1101", LanguageText_sk.resourceCulture);

		internal static string Error1102 => LanguageText_sk.ResourceManager.GetString("Error1102", LanguageText_sk.resourceCulture);

		internal static string Error1110 => LanguageText_sk.ResourceManager.GetString("Error1110", LanguageText_sk.resourceCulture);

		internal static string Error1111 => LanguageText_sk.ResourceManager.GetString("Error1111", LanguageText_sk.resourceCulture);

		internal static string Error1112 => LanguageText_sk.ResourceManager.GetString("Error1112", LanguageText_sk.resourceCulture);

		internal static string Error1113 => LanguageText_sk.ResourceManager.GetString("Error1113", LanguageText_sk.resourceCulture);

		internal static string Error1114 => LanguageText_sk.ResourceManager.GetString("Error1114", LanguageText_sk.resourceCulture);

		internal static string Error1140 => LanguageText_sk.ResourceManager.GetString("Error1140", LanguageText_sk.resourceCulture);

		internal static string Error1141 => LanguageText_sk.ResourceManager.GetString("Error1141", LanguageText_sk.resourceCulture);

		internal static string Error1150 => LanguageText_sk.ResourceManager.GetString("Error1150", LanguageText_sk.resourceCulture);

		internal static string Error1151 => LanguageText_sk.ResourceManager.GetString("Error1151", LanguageText_sk.resourceCulture);

		internal static string Error1152 => LanguageText_sk.ResourceManager.GetString("Error1152", LanguageText_sk.resourceCulture);

		internal static string Error1153 => LanguageText_sk.ResourceManager.GetString("Error1153", LanguageText_sk.resourceCulture);

		internal static string Error1160 => LanguageText_sk.ResourceManager.GetString("Error1160", LanguageText_sk.resourceCulture);

		internal static string Error1161 => LanguageText_sk.ResourceManager.GetString("Error1161", LanguageText_sk.resourceCulture);

		internal static string Error1162 => LanguageText_sk.ResourceManager.GetString("Error1162", LanguageText_sk.resourceCulture);

		internal static string Error1163 => LanguageText_sk.ResourceManager.GetString("Error1163", LanguageText_sk.resourceCulture);

		internal static string Error1200 => LanguageText_sk.ResourceManager.GetString("Error1200", LanguageText_sk.resourceCulture);

		internal static string Error1201 => LanguageText_sk.ResourceManager.GetString("Error1201", LanguageText_sk.resourceCulture);

		internal static string Error1202 => LanguageText_sk.ResourceManager.GetString("Error1202", LanguageText_sk.resourceCulture);

		internal static string Error1203 => LanguageText_sk.ResourceManager.GetString("Error1203", LanguageText_sk.resourceCulture);

		internal static string Error1301 => LanguageText_sk.ResourceManager.GetString("Error1301", LanguageText_sk.resourceCulture);

		internal static string Error1302 => LanguageText_sk.ResourceManager.GetString("Error1302", LanguageText_sk.resourceCulture);

		internal static string Error1303 => LanguageText_sk.ResourceManager.GetString("Error1303", LanguageText_sk.resourceCulture);

		internal static string Error1304 => LanguageText_sk.ResourceManager.GetString("Error1304", LanguageText_sk.resourceCulture);

		internal static string Error1305 => LanguageText_sk.ResourceManager.GetString("Error1305", LanguageText_sk.resourceCulture);

		internal static string Error1400 => LanguageText_sk.ResourceManager.GetString("Error1400", LanguageText_sk.resourceCulture);

		internal static string Error1401 => LanguageText_sk.ResourceManager.GetString("Error1401", LanguageText_sk.resourceCulture);

		internal static string Error1402 => LanguageText_sk.ResourceManager.GetString("Error1402", LanguageText_sk.resourceCulture);

		internal static string Error1403 => LanguageText_sk.ResourceManager.GetString("Error1403", LanguageText_sk.resourceCulture);

		internal static string Error1404 => LanguageText_sk.ResourceManager.GetString("Error1404", LanguageText_sk.resourceCulture);

		internal static string Error1405 => LanguageText_sk.ResourceManager.GetString("Error1405", LanguageText_sk.resourceCulture);

		internal static string Error1406 => LanguageText_sk.ResourceManager.GetString("Error1406", LanguageText_sk.resourceCulture);

		internal static string Error1407 => LanguageText_sk.ResourceManager.GetString("Error1407", LanguageText_sk.resourceCulture);

		internal static string Error1450 => LanguageText_sk.ResourceManager.GetString("Error1450", LanguageText_sk.resourceCulture);

		internal static string Error1451 => LanguageText_sk.ResourceManager.GetString("Error1451", LanguageText_sk.resourceCulture);

		internal static string Error1600 => LanguageText_sk.ResourceManager.GetString("Error1600", LanguageText_sk.resourceCulture);

		internal static string Error1601 => LanguageText_sk.ResourceManager.GetString("Error1601", LanguageText_sk.resourceCulture);

		internal static string Error1602 => LanguageText_sk.ResourceManager.GetString("Error1602", LanguageText_sk.resourceCulture);

		internal static string Error2000 => LanguageText_sk.ResourceManager.GetString("Error2000", LanguageText_sk.resourceCulture);

		internal static string Error2001 => LanguageText_sk.ResourceManager.GetString("Error2001", LanguageText_sk.resourceCulture);

		internal static string Error2002 => LanguageText_sk.ResourceManager.GetString("Error2002", LanguageText_sk.resourceCulture);

		internal static string Error2003 => LanguageText_sk.ResourceManager.GetString("Error2003", LanguageText_sk.resourceCulture);

		internal static string Error2004 => LanguageText_sk.ResourceManager.GetString("Error2004", LanguageText_sk.resourceCulture);

		internal static string Error2005 => LanguageText_sk.ResourceManager.GetString("Error2005", LanguageText_sk.resourceCulture);

		internal static string Error2006 => LanguageText_sk.ResourceManager.GetString("Error2006", LanguageText_sk.resourceCulture);

		internal static string Error2007 => LanguageText_sk.ResourceManager.GetString("Error2007", LanguageText_sk.resourceCulture);

		internal static string Error2008 => LanguageText_sk.ResourceManager.GetString("Error2008", LanguageText_sk.resourceCulture);

		internal static string Error2009 => LanguageText_sk.ResourceManager.GetString("Error2009", LanguageText_sk.resourceCulture);

		internal static string Error2010 => LanguageText_sk.ResourceManager.GetString("Error2010", LanguageText_sk.resourceCulture);

		internal static string Error2011 => LanguageText_sk.ResourceManager.GetString("Error2011", LanguageText_sk.resourceCulture);

		internal static string Error2012 => LanguageText_sk.ResourceManager.GetString("Error2012", LanguageText_sk.resourceCulture);

		internal static string Error2013 => LanguageText_sk.ResourceManager.GetString("Error2013", LanguageText_sk.resourceCulture);

		internal static string Error2014 => LanguageText_sk.ResourceManager.GetString("Error2014", LanguageText_sk.resourceCulture);

		internal static string Error2015 => LanguageText_sk.ResourceManager.GetString("Error2015", LanguageText_sk.resourceCulture);

		internal static string Error2016 => LanguageText_sk.ResourceManager.GetString("Error2016", LanguageText_sk.resourceCulture);

		internal static string Error2017 => LanguageText_sk.ResourceManager.GetString("Error2017", LanguageText_sk.resourceCulture);

		internal static string Error2018 => LanguageText_sk.ResourceManager.GetString("Error2018", LanguageText_sk.resourceCulture);

		internal static string Error2019 => LanguageText_sk.ResourceManager.GetString("Error2019", LanguageText_sk.resourceCulture);

		internal static string Error2020 => LanguageText_sk.ResourceManager.GetString("Error2020", LanguageText_sk.resourceCulture);

		internal static string Error2021 => LanguageText_sk.ResourceManager.GetString("Error2021", LanguageText_sk.resourceCulture);

		internal static string Error2022 => LanguageText_sk.ResourceManager.GetString("Error2022", LanguageText_sk.resourceCulture);

		internal static string Error2100 => LanguageText_sk.ResourceManager.GetString("Error2100", LanguageText_sk.resourceCulture);

		internal static string Error5000 => LanguageText_sk.ResourceManager.GetString("Error5000", LanguageText_sk.resourceCulture);

		internal static string ErrorCode => LanguageText_sk.ResourceManager.GetString("ErrorCode", LanguageText_sk.resourceCulture);

		internal static string ErrorLog => LanguageText_sk.ResourceManager.GetString("ErrorLog", LanguageText_sk.resourceCulture);

		internal static string ErrorMode => LanguageText_sk.ResourceManager.GetString("ErrorMode", LanguageText_sk.resourceCulture);

		internal static string ErrorNumber => LanguageText_sk.ResourceManager.GetString("ErrorNumber", LanguageText_sk.resourceCulture);

		internal static string ErrorQuitEMG => LanguageText_sk.ResourceManager.GetString("ErrorQuitEMG", LanguageText_sk.resourceCulture);

		internal static string EuropeanTime => LanguageText_sk.ResourceManager.GetString("EuropeanTime", LanguageText_sk.resourceCulture);

		internal static string Even => LanguageText_sk.ResourceManager.GetString("Even", LanguageText_sk.resourceCulture);

		internal static string Exit => LanguageText_sk.ResourceManager.GetString("Exit", LanguageText_sk.resourceCulture);

		internal static string Expertenebene => LanguageText_sk.ResourceManager.GetString("Expertenebene", LanguageText_sk.resourceCulture);

		internal static string Export => LanguageText_sk.ResourceManager.GetString("Export", LanguageText_sk.resourceCulture);

		internal static string ExportLastResults => LanguageText_sk.ResourceManager.GetString("ExportLastResults", LanguageText_sk.resourceCulture);

		internal static string ExportLogbook => LanguageText_sk.ResourceManager.GetString("ExportLogbook", LanguageText_sk.resourceCulture);

		internal static string FileOperation => LanguageText_sk.ResourceManager.GetString("FileOperation", LanguageText_sk.resourceCulture);

		internal static string FileOperationMenu => LanguageText_sk.ResourceManager.GetString("FileOperationMenu", LanguageText_sk.resourceCulture);

		internal static string FilteredTorque => LanguageText_sk.ResourceManager.GetString("FilteredTorque", LanguageText_sk.resourceCulture);

		internal static string Finalizing => LanguageText_sk.ResourceManager.GetString("Finalizing", LanguageText_sk.resourceCulture);

		internal static string FinalizingStep => LanguageText_sk.ResourceManager.GetString("FinalizingStep", LanguageText_sk.resourceCulture);

		internal static string ForceSignals => LanguageText_sk.ResourceManager.GetString("ForceSignals", LanguageText_sk.resourceCulture);

		internal static string French => LanguageText_sk.ResourceManager.GetString("French", LanguageText_sk.resourceCulture);

		internal static string FrictionSpeed => LanguageText_sk.ResourceManager.GetString("FrictionSpeed", LanguageText_sk.resourceCulture);

		internal static string FrictionTest => LanguageText_sk.ResourceManager.GetString("FrictionTest", LanguageText_sk.resourceCulture);

		internal static string FrictionTestEMG => LanguageText_sk.ResourceManager.GetString("FrictionTestEMG", LanguageText_sk.resourceCulture);

		internal static string FrictionTestStartup => LanguageText_sk.ResourceManager.GetString("FrictionTestStartup", LanguageText_sk.resourceCulture);

		internal static string FrictionTorque => LanguageText_sk.ResourceManager.GetString("FrictionTorque", LanguageText_sk.resourceCulture);

		internal static string FromAbove => LanguageText_sk.ResourceManager.GetString("FromAbove", LanguageText_sk.resourceCulture);

		internal static string FromAboveOverload => LanguageText_sk.ResourceManager.GetString("FromAboveOverload", LanguageText_sk.resourceCulture);

		internal static string gBAnaSignal => LanguageText_sk.ResourceManager.GetString("gBAnaSignal", LanguageText_sk.resourceCulture);

		internal static string gBDateTime => LanguageText_sk.ResourceManager.GetString("gBDateTime", LanguageText_sk.resourceCulture);

		internal static string gBError => LanguageText_sk.ResourceManager.GetString("gBError", LanguageText_sk.resourceCulture);

		internal static string gBIdentity => LanguageText_sk.ResourceManager.GetString("gBIdentity", LanguageText_sk.resourceCulture);

		internal static string gBIP => LanguageText_sk.ResourceManager.GetString("gBIP", LanguageText_sk.resourceCulture);

		internal static string gBJawOpenAutomatic => LanguageText_sk.ResourceManager.GetString("gBJawOpenAutomatic", LanguageText_sk.resourceCulture);

		internal static string gBLoadBackup => LanguageText_sk.ResourceManager.GetString("gBLoadBackup", LanguageText_sk.resourceCulture);

		internal static string gBPressure => LanguageText_sk.ResourceManager.GetString("gBPressure", LanguageText_sk.resourceCulture);

		internal static string gBRedundantSensor => LanguageText_sk.ResourceManager.GetString("gBRedundantSensor", LanguageText_sk.resourceCulture);

		internal static string gBResultDisplay => LanguageText_sk.ResourceManager.GetString("gBResultDisplay", LanguageText_sk.resourceCulture);

		internal static string gBRs232 => LanguageText_sk.ResourceManager.GetString("gBRs232", LanguageText_sk.resourceCulture);

		internal static string gBSaveBackup => LanguageText_sk.ResourceManager.GetString("gBSaveBackup", LanguageText_sk.resourceCulture);

		internal static string gBSpindle => LanguageText_sk.ResourceManager.GetString("gBSpindle", LanguageText_sk.resourceCulture);

		internal static string GearFactor => LanguageText_sk.ResourceManager.GetString("GearFactor", LanguageText_sk.resourceCulture);

		internal static string German => LanguageText_sk.ResourceManager.GetString("German", LanguageText_sk.resourceCulture);

		internal static string GetCurve => LanguageText_sk.ResourceManager.GetString("GetCurve", LanguageText_sk.resourceCulture);

		internal static string GetRpm => LanguageText_sk.ResourceManager.GetString("GetRpm", LanguageText_sk.resourceCulture);

		internal static string GoWithoutPassCode => LanguageText_sk.ResourceManager.GetString("GoWithoutPassCode", LanguageText_sk.resourceCulture);

		internal static string GradFilter => LanguageText_sk.ResourceManager.GetString("GradFilter", LanguageText_sk.resourceCulture);

		internal static string Gradient => LanguageText_sk.ResourceManager.GetString("Gradient", LanguageText_sk.resourceCulture);

		internal static string GradientLength => LanguageText_sk.ResourceManager.GetString("GradientLength", LanguageText_sk.resourceCulture);

		internal static string HandMode => LanguageText_sk.ResourceManager.GetString("HandMode", LanguageText_sk.resourceCulture);

		internal static string HandStart => LanguageText_sk.ResourceManager.GetString("HandStart", LanguageText_sk.resourceCulture);

		internal static string HandStartIsInitiated => LanguageText_sk.ResourceManager.GetString("HandStartIsInitiated", LanguageText_sk.resourceCulture);

		internal static string Help => LanguageText_sk.ResourceManager.GetString("Help", LanguageText_sk.resourceCulture);

		internal static string HexSwitch => LanguageText_sk.ResourceManager.GetString("HexSwitch", LanguageText_sk.resourceCulture);

		internal static string Hold => LanguageText_sk.ResourceManager.GetString("Hold", LanguageText_sk.resourceCulture);

		internal static string Holder => LanguageText_sk.ResourceManager.GetString("Holder", LanguageText_sk.resourceCulture);

		internal static string HolderPressureScale => LanguageText_sk.ResourceManager.GetString("HolderPressureScale", LanguageText_sk.resourceCulture);

		internal static string Hungarian => LanguageText_sk.ResourceManager.GetString("Hungarian", LanguageText_sk.resourceCulture);

		internal static string IdentServer => LanguageText_sk.ResourceManager.GetString("IdentServer", LanguageText_sk.resourceCulture);

		internal static string Increment => LanguageText_sk.ResourceManager.GetString("Increment", LanguageText_sk.resourceCulture);

		internal static string Inputs => LanguageText_sk.ResourceManager.GetString("Inputs", LanguageText_sk.resourceCulture);

		internal static string InsertProgram => LanguageText_sk.ResourceManager.GetString("InsertProgram", LanguageText_sk.resourceCulture);

		internal static string InsertStep => LanguageText_sk.ResourceManager.GetString("InsertStep", LanguageText_sk.resourceCulture);

		internal static string Instandhaltung => LanguageText_sk.ResourceManager.GetString("Instandhaltung", LanguageText_sk.resourceCulture);

		internal static string IntegratedTests => LanguageText_sk.ResourceManager.GetString("IntegratedTests", LanguageText_sk.resourceCulture);

		internal static string IONumber => LanguageText_sk.ResourceManager.GetString("IONumber", LanguageText_sk.resourceCulture);

		internal static string IOTest => LanguageText_sk.ResourceManager.GetString("IOTest", LanguageText_sk.resourceCulture);

		internal static string IPAddress => LanguageText_sk.ResourceManager.GetString("IPAddress", LanguageText_sk.resourceCulture);

		internal static string IpOfC50S => LanguageText_sk.ResourceManager.GetString("IpOfC50S", LanguageText_sk.resourceCulture);

		internal static string Italian => LanguageText_sk.ResourceManager.GetString("Italian", LanguageText_sk.resourceCulture);

		internal static string JumpAlwaysTo => LanguageText_sk.ResourceManager.GetString("JumpAlwaysTo", LanguageText_sk.resourceCulture);

		internal static string JumpNokTo => LanguageText_sk.ResourceManager.GetString("JumpNokTo", LanguageText_sk.resourceCulture);

		internal static string JumpOkTo => LanguageText_sk.ResourceManager.GetString("JumpOkTo", LanguageText_sk.resourceCulture);

		internal static string JumpTo => LanguageText_sk.ResourceManager.GetString("JumpTo", LanguageText_sk.resourceCulture);

		internal static string KeyPad => LanguageText_sk.ResourceManager.GetString("KeyPad", LanguageText_sk.resourceCulture);

		internal static string KiloNewton => LanguageText_sk.ResourceManager.GetString("KiloNewton", LanguageText_sk.resourceCulture);

		internal static string Kind => LanguageText_sk.ResourceManager.GetString("Kind", LanguageText_sk.resourceCulture);

		internal static string Language => LanguageText_sk.ResourceManager.GetString("Language", LanguageText_sk.resourceCulture);

		internal static string LastDoneStep => LanguageText_sk.ResourceManager.GetString("LastDoneStep", LanguageText_sk.resourceCulture);

		internal static string LastNIO => LanguageText_sk.ResourceManager.GetString("LastNIO", LanguageText_sk.resourceCulture);

		internal static string LastResults => LanguageText_sk.ResourceManager.GetString("LastResults", LanguageText_sk.resourceCulture);

		internal static string lbJawOpenDepthGradMax => LanguageText_sk.ResourceManager.GetString("lbJawOpenDepthGradMax", LanguageText_sk.resourceCulture);

		internal static string lbJawOpenDepthGradMin => LanguageText_sk.ResourceManager.GetString("lbJawOpenDepthGradMin", LanguageText_sk.resourceCulture);

		internal static string lbJawOpenDistance => LanguageText_sk.ResourceManager.GetString("lbJawOpenDistance", LanguageText_sk.resourceCulture);

		internal static string LeftAngle => LanguageText_sk.ResourceManager.GetString("LeftAngle", LanguageText_sk.resourceCulture);

		internal static string LevelAdministrator => LanguageText_sk.ResourceManager.GetString("LevelAdministrator", LanguageText_sk.resourceCulture);

		internal static string LevelProgramer => LanguageText_sk.ResourceManager.GetString("LevelProgramer", LanguageText_sk.resourceCulture);

		internal static string LevelUser => LanguageText_sk.ResourceManager.GetString("LevelUser", LanguageText_sk.resourceCulture);

		internal static string LivingMonitor => LanguageText_sk.ResourceManager.GetString("LivingMonitor", LanguageText_sk.resourceCulture);

		internal static string LivingSign => LanguageText_sk.ResourceManager.GetString("LivingSign", LanguageText_sk.resourceCulture);

		internal static string LoadCurveData => LanguageText_sk.ResourceManager.GetString("LoadCurveData", LanguageText_sk.resourceCulture);

		internal static string LoadCurveDataFromFile => LanguageText_sk.ResourceManager.GetString("LoadCurveDataFromFile", LanguageText_sk.resourceCulture);

		internal static string LoadCustBackup => LanguageText_sk.ResourceManager.GetString("LoadCustBackup", LanguageText_sk.resourceCulture);

		internal static string LoadCustBackupFromCF => LanguageText_sk.ResourceManager.GetString("LoadCustBackupFromCF", LanguageText_sk.resourceCulture);

		internal static string LoadCustBackupSecQuery => LanguageText_sk.ResourceManager.GetString("LoadCustBackupSecQuery", LanguageText_sk.resourceCulture);

		internal static string LoadCycleCount => LanguageText_sk.ResourceManager.GetString("LoadCycleCount", LanguageText_sk.resourceCulture);

		internal static string LoadFromFile => LanguageText_sk.ResourceManager.GetString("LoadFromFile", LanguageText_sk.resourceCulture);

		internal static string LoadIO => LanguageText_sk.ResourceManager.GetString("LoadIO", LanguageText_sk.resourceCulture);

		internal static string LoadLastNIOResults => LanguageText_sk.ResourceManager.GetString("LoadLastNIOResults", LanguageText_sk.resourceCulture);

		internal static string LoadLastResults => LanguageText_sk.ResourceManager.GetString("LoadLastResults", LanguageText_sk.resourceCulture);

		internal static string LoadLogBookData => LanguageText_sk.ResourceManager.GetString("LoadLogBookData", LanguageText_sk.resourceCulture);

		internal static string LoadPLCIO => LanguageText_sk.ResourceManager.GetString("LoadPLCIO", LanguageText_sk.resourceCulture);

		internal static string LoadPProgFromFile => LanguageText_sk.ResourceManager.GetString("LoadPProgFromFile", LanguageText_sk.resourceCulture);

		internal static string LoadProcessInfo => LanguageText_sk.ResourceManager.GetString("LoadProcessInfo", LanguageText_sk.resourceCulture);

		internal static string LoadProgramData => LanguageText_sk.ResourceManager.GetString("LoadProgramData", LanguageText_sk.resourceCulture);

		internal static string LoadProgramDataLocally => LanguageText_sk.ResourceManager.GetString("LoadProgramDataLocally", LanguageText_sk.resourceCulture);

		internal static string LoadRecursiveStat => LanguageText_sk.ResourceManager.GetString("LoadRecursiveStat", LanguageText_sk.resourceCulture);

		internal static string LoadResults => LanguageText_sk.ResourceManager.GetString("LoadResults", LanguageText_sk.resourceCulture);

		internal static string LoadSingleProgFromFile => LanguageText_sk.ResourceManager.GetString("LoadSingleProgFromFile", LanguageText_sk.resourceCulture);

		internal static string LoadSpindleConst => LanguageText_sk.ResourceManager.GetString("LoadSpindleConst", LanguageText_sk.resourceCulture);

		internal static string LoadSpindleDataLocally => LanguageText_sk.ResourceManager.GetString("LoadSpindleDataLocally", LanguageText_sk.resourceCulture);

		internal static string LoadSystemConst => LanguageText_sk.ResourceManager.GetString("LoadSystemConst", LanguageText_sk.resourceCulture);

		internal static string LoadWebBackupSecQuery => LanguageText_sk.ResourceManager.GetString("LoadWebBackupSecQuery", LanguageText_sk.resourceCulture);

		internal static string LoadWeberBackup => LanguageText_sk.ResourceManager.GetString("LoadWeberBackup", LanguageText_sk.resourceCulture);

		internal static string LoadWeberBackupFromCF => LanguageText_sk.ResourceManager.GetString("LoadWeberBackupFromCF", LanguageText_sk.resourceCulture);

		internal static string LocalTime => LanguageText_sk.ResourceManager.GetString("LocalTime", LanguageText_sk.resourceCulture);

		internal static string LogBook => LanguageText_sk.ResourceManager.GetString("LogBook", LanguageText_sk.resourceCulture);

		internal static string LogBookMessage100000 => LanguageText_sk.ResourceManager.GetString("LogBookMessage100000", LanguageText_sk.resourceCulture);

		internal static string LogBookMessage200000 => LanguageText_sk.ResourceManager.GetString("LogBookMessage200000", LanguageText_sk.resourceCulture);

		internal static string LogBookMessage300000 => LanguageText_sk.ResourceManager.GetString("LogBookMessage300000", LanguageText_sk.resourceCulture);

		internal static string LogBookMessage300001 => LanguageText_sk.ResourceManager.GetString("LogBookMessage300001", LanguageText_sk.resourceCulture);

		internal static string LogBookTable => LanguageText_sk.ResourceManager.GetString("LogBookTable", LanguageText_sk.resourceCulture);

		internal static string Login => LanguageText_sk.ResourceManager.GetString("Login", LanguageText_sk.resourceCulture);

		internal static string LowerLimit => LanguageText_sk.ResourceManager.GetString("LowerLimit", LanguageText_sk.resourceCulture);

		internal static string M1FilterTime => LanguageText_sk.ResourceManager.GetString("M1FilterTime", LanguageText_sk.resourceCulture);

		internal static string M360Follow => LanguageText_sk.ResourceManager.GetString("M360Follow", LanguageText_sk.resourceCulture);

		internal static string MachineCounter => LanguageText_sk.ResourceManager.GetString("MachineCounter", LanguageText_sk.resourceCulture);

		internal static string MachineVisu => LanguageText_sk.ResourceManager.GetString("MachineVisu", LanguageText_sk.resourceCulture);

		internal static string MakeNewEntry => LanguageText_sk.ResourceManager.GetString("MakeNewEntry", LanguageText_sk.resourceCulture);

		internal static string Max => LanguageText_sk.ResourceManager.GetString("Max", LanguageText_sk.resourceCulture);

		internal static string MaxFrictionTorque => LanguageText_sk.ResourceManager.GetString("MaxFrictionTorque", LanguageText_sk.resourceCulture);

		internal static string MaxRpm => LanguageText_sk.ResourceManager.GetString("MaxRpm", LanguageText_sk.resourceCulture);

		internal static string MaxSaveCurveNum => LanguageText_sk.ResourceManager.GetString("MaxSaveCurveNum", LanguageText_sk.resourceCulture);

		internal static string MaxScrewTime => LanguageText_sk.ResourceManager.GetString("MaxScrewTime", LanguageText_sk.resourceCulture);

		internal static string MaxTorque => LanguageText_sk.ResourceManager.GetString("MaxTorque", LanguageText_sk.resourceCulture);

		internal static string MbAccessByAnother => LanguageText_sk.ResourceManager.GetString("MbAccessByAnother", LanguageText_sk.resourceCulture);

		internal static string MbAccessNotPossible => LanguageText_sk.ResourceManager.GetString("MbAccessNotPossible", LanguageText_sk.resourceCulture);

		internal static string MbAccessRequestTwice => LanguageText_sk.ResourceManager.GetString("MbAccessRequestTwice", LanguageText_sk.resourceCulture);

		internal static string MBackup => LanguageText_sk.ResourceManager.GetString("MBackup", LanguageText_sk.resourceCulture);

		internal static string MbAddNoFrictionTest => LanguageText_sk.ResourceManager.GetString("MbAddNoFrictionTest", LanguageText_sk.resourceCulture);

		internal static string MbAddNoManual => LanguageText_sk.ResourceManager.GetString("MbAddNoManual", LanguageText_sk.resourceCulture);

		internal static string MbAddNoTest => LanguageText_sk.ResourceManager.GetString("MbAddNoTest", LanguageText_sk.resourceCulture);

		internal static string MbAddParamViewOnly => LanguageText_sk.ResourceManager.GetString("MbAddParamViewOnly", LanguageText_sk.resourceCulture);

		internal static string MbAutomaticIsActive1 => LanguageText_sk.ResourceManager.GetString("MbAutomaticIsActive1", LanguageText_sk.resourceCulture);

		internal static string MbAutomaticIsActive2 => LanguageText_sk.ResourceManager.GetString("MbAutomaticIsActive2", LanguageText_sk.resourceCulture);

		internal static string mbChangingcBDisplaySpindlePressureAsKN => LanguageText_sk.ResourceManager.GetString("mbChangingcBDisplaySpindlePressureAsKN", LanguageText_sk.resourceCulture);

		internal static string MbComandTimeOut => LanguageText_sk.ResourceManager.GetString("MbComandTimeOut", LanguageText_sk.resourceCulture);

		internal static string MbCreateDefaultPasscode => LanguageText_sk.ResourceManager.GetString("MbCreateDefaultPasscode", LanguageText_sk.resourceCulture);

		internal static string MbCurveLoadFailure => LanguageText_sk.ResourceManager.GetString("MbCurveLoadFailure", LanguageText_sk.resourceCulture);

		internal static string MbCurveSaveFailure => LanguageText_sk.ResourceManager.GetString("MbCurveSaveFailure", LanguageText_sk.resourceCulture);

		internal static string MbDay_s => LanguageText_sk.ResourceManager.GetString("MbDay_s", LanguageText_sk.resourceCulture);

		internal static string MbDeleteCounterFailure => LanguageText_sk.ResourceManager.GetString("MbDeleteCounterFailure", LanguageText_sk.resourceCulture);

		internal static string MbDeleteCustomCounter => LanguageText_sk.ResourceManager.GetString("MbDeleteCustomCounter", LanguageText_sk.resourceCulture);

		internal static string MbDeleteLastResFailure => LanguageText_sk.ResourceManager.GetString("MbDeleteLastResFailure", LanguageText_sk.resourceCulture);

		internal static string MbDeleteLastResults => LanguageText_sk.ResourceManager.GetString("MbDeleteLastResults", LanguageText_sk.resourceCulture);

		internal static string MbDeleteProg => LanguageText_sk.ResourceManager.GetString("MbDeleteProg", LanguageText_sk.resourceCulture);

		internal static string MbDeleteRecStatFailure => LanguageText_sk.ResourceManager.GetString("MbDeleteRecStatFailure", LanguageText_sk.resourceCulture);

		internal static string MbDeleteRecursiveStat => LanguageText_sk.ResourceManager.GetString("MbDeleteRecursiveStat", LanguageText_sk.resourceCulture);

		internal static string MbDeleteStatAfterProgChange => LanguageText_sk.ResourceManager.GetString("MbDeleteStatAfterProgChange", LanguageText_sk.resourceCulture);

		internal static string MbDeleteStepIsJumpTarget => LanguageText_sk.ResourceManager.GetString("MbDeleteStepIsJumpTarget", LanguageText_sk.resourceCulture);

		internal static string MbDoubleEntryCodeFound => LanguageText_sk.ResourceManager.GetString("MbDoubleEntryCodeFound", LanguageText_sk.resourceCulture);

		internal static string MbEmptyProgram => LanguageText_sk.ResourceManager.GetString("MbEmptyProgram", LanguageText_sk.resourceCulture);

		internal static string mBError => LanguageText_sk.ResourceManager.GetString("mBError", LanguageText_sk.resourceCulture);

		internal static string MbErrorQuitFailure => LanguageText_sk.ResourceManager.GetString("MbErrorQuitFailure", LanguageText_sk.resourceCulture);

		internal static string MbExit => LanguageText_sk.ResourceManager.GetString("MbExit", LanguageText_sk.resourceCulture);

		internal static string mBExitSaveSettings => LanguageText_sk.ResourceManager.GetString("mBExitSaveSettings", LanguageText_sk.resourceCulture);

		internal static string mBExitSecurityQuery => LanguageText_sk.ResourceManager.GetString("mBExitSecurityQuery", LanguageText_sk.resourceCulture);

		internal static string MbGotNoConnection => LanguageText_sk.ResourceManager.GetString("MbGotNoConnection", LanguageText_sk.resourceCulture);

		internal static string MbHandstartIsActive => LanguageText_sk.ResourceManager.GetString("MbHandstartIsActive", LanguageText_sk.resourceCulture);

		internal static string MbHandstartNotTwice => LanguageText_sk.ResourceManager.GetString("MbHandstartNotTwice", LanguageText_sk.resourceCulture);

		internal static string MbhError => LanguageText_sk.ResourceManager.GetString("MbhError", LanguageText_sk.resourceCulture);

		internal static string MbhHint => LanguageText_sk.ResourceManager.GetString("MbhHint", LanguageText_sk.resourceCulture);

		internal static string MbhNoAccess => LanguageText_sk.ResourceManager.GetString("MbhNoAccess", LanguageText_sk.resourceCulture);

		internal static string MbHour_s => LanguageText_sk.ResourceManager.GetString("MbHour_s", LanguageText_sk.resourceCulture);

		internal static string MbhSecurityQuery => LanguageText_sk.ResourceManager.GetString("MbhSecurityQuery", LanguageText_sk.resourceCulture);

		internal static string MbhViewOnlyMode => LanguageText_sk.ResourceManager.GetString("MbhViewOnlyMode", LanguageText_sk.resourceCulture);

		internal static string mBInternalError => LanguageText_sk.ResourceManager.GetString("mBInternalError", LanguageText_sk.resourceCulture);

		internal static string MbInvalidUsbKey => LanguageText_sk.ResourceManager.GetString("MbInvalidUsbKey", LanguageText_sk.resourceCulture);

		internal static string MbIPChange => LanguageText_sk.ResourceManager.GetString("MbIPChange", LanguageText_sk.resourceCulture);

		internal static string MbKeyLockActive => LanguageText_sk.ResourceManager.GetString("MbKeyLockActive", LanguageText_sk.resourceCulture);

		internal static string MbLoadCustBackupFailure => LanguageText_sk.ResourceManager.GetString("MbLoadCustBackupFailure", LanguageText_sk.resourceCulture);

		internal static string MbLoadWeberBackupFailure => LanguageText_sk.ResourceManager.GetString("MbLoadWeberBackupFailure", LanguageText_sk.resourceCulture);

		internal static string MbLocationError => LanguageText_sk.ResourceManager.GetString("MbLocationError", LanguageText_sk.resourceCulture);

		internal static string MbLogbookWriteFailure => LanguageText_sk.ResourceManager.GetString("MbLogbookWriteFailure", LanguageText_sk.resourceCulture);

		internal static string MbMaxPasscodeNum1 => LanguageText_sk.ResourceManager.GetString("MbMaxPasscodeNum1", LanguageText_sk.resourceCulture);

		internal static string MbMaxPasscodeNum2 => LanguageText_sk.ResourceManager.GetString("MbMaxPasscodeNum2", LanguageText_sk.resourceCulture);

		internal static string MbNoAccess => LanguageText_sk.ResourceManager.GetString("MbNoAccess", LanguageText_sk.resourceCulture);

		internal static string MbNoAccessCauseAuto => LanguageText_sk.ResourceManager.GetString("MbNoAccessCauseAuto", LanguageText_sk.resourceCulture);

		internal static string MbNoConnection => LanguageText_sk.ResourceManager.GetString("MbNoConnection", LanguageText_sk.resourceCulture);

		internal static string MbNoTestCauseAuto => LanguageText_sk.ResourceManager.GetString("MbNoTestCauseAuto", LanguageText_sk.resourceCulture);

		internal static string mBNotReceiveCurve => LanguageText_sk.ResourceManager.GetString("mBNotReceiveCurve", LanguageText_sk.resourceCulture);

		internal static string MbOfflineMode => LanguageText_sk.ResourceManager.GetString("MbOfflineMode", LanguageText_sk.resourceCulture);

		internal static string MbOldPasswordWrong => LanguageText_sk.ResourceManager.GetString("MbOldPasswordWrong", LanguageText_sk.resourceCulture);

		internal static string MbOldPProgLoad => LanguageText_sk.ResourceManager.GetString("MbOldPProgLoad", LanguageText_sk.resourceCulture);

		internal static string MbOldProgLoad => LanguageText_sk.ResourceManager.GetString("MbOldProgLoad", LanguageText_sk.resourceCulture);

		internal static string MbOverwriteProg => LanguageText_sk.ResourceManager.GetString("MbOverwriteProg", LanguageText_sk.resourceCulture);

		internal static string MbPasscodeFailure1 => LanguageText_sk.ResourceManager.GetString("MbPasscodeFailure1", LanguageText_sk.resourceCulture);

		internal static string MbPasscodeFailure2 => LanguageText_sk.ResourceManager.GetString("MbPasscodeFailure2", LanguageText_sk.resourceCulture);

		internal static string MbPasscodeFailure3 => LanguageText_sk.ResourceManager.GetString("MbPasscodeFailure3", LanguageText_sk.resourceCulture);

		internal static string MbPasscodeFailure4 => LanguageText_sk.ResourceManager.GetString("MbPasscodeFailure4", LanguageText_sk.resourceCulture);

		internal static string MbPasswordIsExpired => LanguageText_sk.ResourceManager.GetString("MbPasswordIsExpired", LanguageText_sk.resourceCulture);

		internal static string MbPasswordSavedOnUsbKey => LanguageText_sk.ResourceManager.GetString("MbPasswordSavedOnUsbKey", LanguageText_sk.resourceCulture);

		internal static string MbPasswordsNotEqual => LanguageText_sk.ResourceManager.GetString("MbPasswordsNotEqual", LanguageText_sk.resourceCulture);

		internal static string MbPasswordWillExpire => LanguageText_sk.ResourceManager.GetString("MbPasswordWillExpire", LanguageText_sk.resourceCulture);

		internal static string MbPasswordWrongLength => LanguageText_sk.ResourceManager.GetString("MbPasswordWrongLength", LanguageText_sk.resourceCulture);

		internal static string MbPProgCopyFailure => LanguageText_sk.ResourceManager.GetString("MbPProgCopyFailure", LanguageText_sk.resourceCulture);

		internal static string MbPProgLoadFromFileFailure => LanguageText_sk.ResourceManager.GetString("MbPProgLoadFromFileFailure", LanguageText_sk.resourceCulture);

		internal static string MbPProgSaveToFileFailure => LanguageText_sk.ResourceManager.GetString("MbPProgSaveToFileFailure", LanguageText_sk.resourceCulture);

		internal static string MbProgramCopyFailure => LanguageText_sk.ResourceManager.GetString("MbProgramCopyFailure", LanguageText_sk.resourceCulture);

		internal static string MbProgramEmptySaveAnyway => LanguageText_sk.ResourceManager.GetString("MbProgramEmptySaveAnyway", LanguageText_sk.resourceCulture);

		internal static string MbReconnectUsbKey => LanguageText_sk.ResourceManager.GetString("MbReconnectUsbKey", LanguageText_sk.resourceCulture);

		internal static string MbSaveCustBackupFailure => LanguageText_sk.ResourceManager.GetString("MbSaveCustBackupFailure", LanguageText_sk.resourceCulture);

		internal static string MbSaveDataLocally => LanguageText_sk.ResourceManager.GetString("MbSaveDataLocally", LanguageText_sk.resourceCulture);

		internal static string MbSavedProgramDataToFile => LanguageText_sk.ResourceManager.GetString("MbSavedProgramDataToFile", LanguageText_sk.resourceCulture);

		internal static string MbSavedSpindleDataToFile => LanguageText_sk.ResourceManager.GetString("MbSavedSpindleDataToFile", LanguageText_sk.resourceCulture);

		internal static string MbSaveNotVerifiedData => LanguageText_sk.ResourceManager.GetString("MbSaveNotVerifiedData", LanguageText_sk.resourceCulture);

		internal static string MbSavePasscodeFailure => LanguageText_sk.ResourceManager.GetString("MbSavePasscodeFailure", LanguageText_sk.resourceCulture);

		internal static string MbSaveProgFailure => LanguageText_sk.ResourceManager.GetString("MbSaveProgFailure", LanguageText_sk.resourceCulture);

		internal static string MbSaveProgOnCPUFailure => LanguageText_sk.ResourceManager.GetString("MbSaveProgOnCPUFailure", LanguageText_sk.resourceCulture);

		internal static string MbSaveSpConstFailure => LanguageText_sk.ResourceManager.GetString("MbSaveSpConstFailure", LanguageText_sk.resourceCulture);

		internal static string MbSaveSysConstFailure => LanguageText_sk.ResourceManager.GetString("MbSaveSysConstFailure", LanguageText_sk.resourceCulture);

		internal static string MbSaveWeberBackupFailure => LanguageText_sk.ResourceManager.GetString("MbSaveWeberBackupFailure", LanguageText_sk.resourceCulture);

		internal static string MbShortNameFailure1 => LanguageText_sk.ResourceManager.GetString("MbShortNameFailure1", LanguageText_sk.resourceCulture);

		internal static string MbShortNameFailure2 => LanguageText_sk.ResourceManager.GetString("MbShortNameFailure2", LanguageText_sk.resourceCulture);

		internal static string MbShortNameFailure3 => LanguageText_sk.ResourceManager.GetString("MbShortNameFailure3", LanguageText_sk.resourceCulture);

		internal static string MbSpindleCopyFailure => LanguageText_sk.ResourceManager.GetString("MbSpindleCopyFailure", LanguageText_sk.resourceCulture);

		internal static string MbSpindleLoadFromFileFailure => LanguageText_sk.ResourceManager.GetString("MbSpindleLoadFromFileFailure", LanguageText_sk.resourceCulture);

		internal static string MbSpindleSaveToFileFailure => LanguageText_sk.ResourceManager.GetString("MbSpindleSaveToFileFailure", LanguageText_sk.resourceCulture);

		internal static string MbStepCopyFailure => LanguageText_sk.ResourceManager.GetString("MbStepCopyFailure", LanguageText_sk.resourceCulture);

		internal static string MbUsbKeyReadFailure => LanguageText_sk.ResourceManager.GetString("MbUsbKeyReadFailure", LanguageText_sk.resourceCulture);

		internal static string MbUsbKeySaveFailure => LanguageText_sk.ResourceManager.GetString("MbUsbKeySaveFailure", LanguageText_sk.resourceCulture);

		internal static string MbWrongPassword => LanguageText_sk.ResourceManager.GetString("MbWrongPassword", LanguageText_sk.resourceCulture);

		internal static string mBWrongUnitTorqueInGetcurve => LanguageText_sk.ResourceManager.GetString("mBWrongUnitTorqueInGetcurve", LanguageText_sk.resourceCulture);

		internal static string MCheckParameter => LanguageText_sk.ResourceManager.GetString("MCheckParameter", LanguageText_sk.resourceCulture);

		internal static string MCurveDisplay => LanguageText_sk.ResourceManager.GetString("MCurveDisplay", LanguageText_sk.resourceCulture);

		internal static string MCurveSelection => LanguageText_sk.ResourceManager.GetString("MCurveSelection", LanguageText_sk.resourceCulture);

		internal static string MCycleCounter => LanguageText_sk.ResourceManager.GetString("MCycleCounter", LanguageText_sk.resourceCulture);

		internal static string MDelay => LanguageText_sk.ResourceManager.GetString("MDelay", LanguageText_sk.resourceCulture);

		internal static string Mean => LanguageText_sk.ResourceManager.GetString("Mean", LanguageText_sk.resourceCulture);

		internal static string MEditStep => LanguageText_sk.ResourceManager.GetString("MEditStep", LanguageText_sk.resourceCulture);

		internal static string MenuAnalysis => LanguageText_sk.ResourceManager.GetString("MenuAnalysis", LanguageText_sk.resourceCulture);

		internal static string MenuParameter => LanguageText_sk.ResourceManager.GetString("MenuParameter", LanguageText_sk.resourceCulture);

		internal static string MenuStatistics => LanguageText_sk.ResourceManager.GetString("MenuStatistics", LanguageText_sk.resourceCulture);

		internal static string MenuTest => LanguageText_sk.ResourceManager.GetString("MenuTest", LanguageText_sk.resourceCulture);

		internal static string Message => LanguageText_sk.ResourceManager.GetString("Message", LanguageText_sk.resourceCulture);

		internal static string MHandStart => LanguageText_sk.ResourceManager.GetString("MHandStart", LanguageText_sk.resourceCulture);

		internal static string mIEnglish => LanguageText_sk.ResourceManager.GetString("mIEnglish", LanguageText_sk.resourceCulture);

		internal static string mIGerman => LanguageText_sk.ResourceManager.GetString("mIGerman", LanguageText_sk.resourceCulture);

		internal static string mIInfo => LanguageText_sk.ResourceManager.GetString("mIInfo", LanguageText_sk.resourceCulture);

		internal static string mILanguage => LanguageText_sk.ResourceManager.GetString("mILanguage", LanguageText_sk.resourceCulture);

		internal static string Milimeter => LanguageText_sk.ResourceManager.GetString("Milimeter", LanguageText_sk.resourceCulture);

		internal static string Milisecond => LanguageText_sk.ResourceManager.GetString("Milisecond", LanguageText_sk.resourceCulture);

		internal static string MillimeterPerSec => LanguageText_sk.ResourceManager.GetString("MillimeterPerSec", LanguageText_sk.resourceCulture);

		internal static string Min => LanguageText_sk.ResourceManager.GetString("Min", LanguageText_sk.resourceCulture);

		internal static string MiniDisplay => LanguageText_sk.ResourceManager.GetString("MiniDisplay", LanguageText_sk.resourceCulture);

		internal static string Minimize => LanguageText_sk.ResourceManager.GetString("Minimize", LanguageText_sk.resourceCulture);

		internal static string mISettings => LanguageText_sk.ResourceManager.GetString("mISettings", LanguageText_sk.resourceCulture);

		internal static string MLastNIO => LanguageText_sk.ResourceManager.GetString("MLastNIO", LanguageText_sk.resourceCulture);

		internal static string MLogBook => LanguageText_sk.ResourceManager.GetString("MLogBook", LanguageText_sk.resourceCulture);

		internal static string MOptPrgParam => LanguageText_sk.ResourceManager.GetString("MOptPrgParam", LanguageText_sk.resourceCulture);

		internal static string Motor => LanguageText_sk.ResourceManager.GetString("Motor", LanguageText_sk.resourceCulture);

		internal static string MPasscodeManager => LanguageText_sk.ResourceManager.GetString("MPasscodeManager", LanguageText_sk.resourceCulture);

		internal static string MPrintSelection => LanguageText_sk.ResourceManager.GetString("MPrintSelection", LanguageText_sk.resourceCulture);

		internal static string MProgramOverview => LanguageText_sk.ResourceManager.GetString("MProgramOverview", LanguageText_sk.resourceCulture);

		internal static string MSpindleConstants => LanguageText_sk.ResourceManager.GetString("MSpindleConstants", LanguageText_sk.resourceCulture);

		internal static string MStepOverview => LanguageText_sk.ResourceManager.GetString("MStepOverview", LanguageText_sk.resourceCulture);

		internal static string MStepResults => LanguageText_sk.ResourceManager.GetString("MStepResults", LanguageText_sk.resourceCulture);

		internal static string MSystemConstants => LanguageText_sk.ResourceManager.GetString("MSystemConstants", LanguageText_sk.resourceCulture);

		internal static string MVisualisationParam => LanguageText_sk.ResourceManager.GetString("MVisualisationParam", LanguageText_sk.resourceCulture);

		internal static string Name => LanguageText_sk.ResourceManager.GetString("Name", LanguageText_sk.resourceCulture);

		internal static string Negative => LanguageText_sk.ResourceManager.GetString("Negative", LanguageText_sk.resourceCulture);

		internal static string NegOverload => LanguageText_sk.ResourceManager.GetString("NegOverload", LanguageText_sk.resourceCulture);

		internal static string NewEntry => LanguageText_sk.ResourceManager.GetString("NewEntry", LanguageText_sk.resourceCulture);

		internal static string NewValue => LanguageText_sk.ResourceManager.GetString("NewValue", LanguageText_sk.resourceCulture);

		internal static string Next50Curves => LanguageText_sk.ResourceManager.GetString("Next50Curves", LanguageText_sk.resourceCulture);

		internal static string NIO10 => LanguageText_sk.ResourceManager.GetString("NIO10", LanguageText_sk.resourceCulture);

		internal static string NIO10001 => LanguageText_sk.ResourceManager.GetString("NIO10001", LanguageText_sk.resourceCulture);

		internal static string NIO10002 => LanguageText_sk.ResourceManager.GetString("NIO10002", LanguageText_sk.resourceCulture);

		internal static string NIO10003 => LanguageText_sk.ResourceManager.GetString("NIO10003", LanguageText_sk.resourceCulture);

		internal static string NIO10004 => LanguageText_sk.ResourceManager.GetString("NIO10004", LanguageText_sk.resourceCulture);

		internal static string NIO11 => LanguageText_sk.ResourceManager.GetString("NIO11", LanguageText_sk.resourceCulture);

		internal static string NIO110 => LanguageText_sk.ResourceManager.GetString("NIO110", LanguageText_sk.resourceCulture);

		internal static string NIO12 => LanguageText_sk.ResourceManager.GetString("NIO12", LanguageText_sk.resourceCulture);

		internal static string NIO13 => LanguageText_sk.ResourceManager.GetString("NIO13", LanguageText_sk.resourceCulture);

		internal static string NIO30 => LanguageText_sk.ResourceManager.GetString("NIO30", LanguageText_sk.resourceCulture);

		internal static string NIO31 => LanguageText_sk.ResourceManager.GetString("NIO31", LanguageText_sk.resourceCulture);

		internal static string NIO40 => LanguageText_sk.ResourceManager.GetString("NIO40", LanguageText_sk.resourceCulture);

		internal static string NIO41 => LanguageText_sk.ResourceManager.GetString("NIO41", LanguageText_sk.resourceCulture);

		internal static string NIO50 => LanguageText_sk.ResourceManager.GetString("NIO50", LanguageText_sk.resourceCulture);

		internal static string NIO51 => LanguageText_sk.ResourceManager.GetString("NIO51", LanguageText_sk.resourceCulture);

		internal static string NIO60 => LanguageText_sk.ResourceManager.GetString("NIO60", LanguageText_sk.resourceCulture);

		internal static string NIO61 => LanguageText_sk.ResourceManager.GetString("NIO61", LanguageText_sk.resourceCulture);

		internal static string NIO70 => LanguageText_sk.ResourceManager.GetString("NIO70", LanguageText_sk.resourceCulture);

		internal static string NIO71 => LanguageText_sk.ResourceManager.GetString("NIO71", LanguageText_sk.resourceCulture);

		internal static string NIO75 => LanguageText_sk.ResourceManager.GetString("NIO75", LanguageText_sk.resourceCulture);

		internal static string NIO76 => LanguageText_sk.ResourceManager.GetString("NIO76", LanguageText_sk.resourceCulture);

		internal static string NIO80 => LanguageText_sk.ResourceManager.GetString("NIO80", LanguageText_sk.resourceCulture);

		internal static string NIO81 => LanguageText_sk.ResourceManager.GetString("NIO81", LanguageText_sk.resourceCulture);

		internal static string NIO90 => LanguageText_sk.ResourceManager.GetString("NIO90", LanguageText_sk.resourceCulture);

		internal static string NIO91 => LanguageText_sk.ResourceManager.GetString("NIO91", LanguageText_sk.resourceCulture);

		internal static string NIO92 => LanguageText_sk.ResourceManager.GetString("NIO92", LanguageText_sk.resourceCulture);

		internal static string NIO93 => LanguageText_sk.ResourceManager.GetString("NIO93", LanguageText_sk.resourceCulture);

		internal static string NIO94 => LanguageText_sk.ResourceManager.GetString("NIO94", LanguageText_sk.resourceCulture);

		internal static string NIO95 => LanguageText_sk.ResourceManager.GetString("NIO95", LanguageText_sk.resourceCulture);

		internal static string NIO96 => LanguageText_sk.ResourceManager.GetString("NIO96", LanguageText_sk.resourceCulture);

		internal static string NIO97 => LanguageText_sk.ResourceManager.GetString("NIO97", LanguageText_sk.resourceCulture);

		internal static string NIO98 => LanguageText_sk.ResourceManager.GetString("NIO98", LanguageText_sk.resourceCulture);

		internal static string NIO99 => LanguageText_sk.ResourceManager.GetString("NIO99", LanguageText_sk.resourceCulture);

		internal static string NIONumber => LanguageText_sk.ResourceManager.GetString("NIONumber", LanguageText_sk.resourceCulture);

		internal static string NIOReason => LanguageText_sk.ResourceManager.GetString("NIOReason", LanguageText_sk.resourceCulture);

		internal static string No => LanguageText_sk.ResourceManager.GetString("No", LanguageText_sk.resourceCulture);

		internal static string NoData => LanguageText_sk.ResourceManager.GetString("NoData", LanguageText_sk.resourceCulture);

		internal static string NoErrorMode => LanguageText_sk.ResourceManager.GetString("NoErrorMode", LanguageText_sk.resourceCulture);

		internal static string NOK => LanguageText_sk.ResourceManager.GetString("NOK", LanguageText_sk.resourceCulture);

		internal static string None => LanguageText_sk.ResourceManager.GetString("None", LanguageText_sk.resourceCulture);

		internal static string NoParity => LanguageText_sk.ResourceManager.GetString("NoParity", LanguageText_sk.resourceCulture);

		internal static string NoSelection => LanguageText_sk.ResourceManager.GetString("NoSelection", LanguageText_sk.resourceCulture);

		internal static string NoSignal => LanguageText_sk.ResourceManager.GetString("NoSignal", LanguageText_sk.resourceCulture);

		internal static string NotValid => LanguageText_sk.ResourceManager.GetString("NotValid", LanguageText_sk.resourceCulture);

		internal static string Number => LanguageText_sk.ResourceManager.GetString("Number", LanguageText_sk.resourceCulture);

		internal static string NumberPad => LanguageText_sk.ResourceManager.GetString("NumberPad", LanguageText_sk.resourceCulture);

		internal static string Odd => LanguageText_sk.ResourceManager.GetString("Odd", LanguageText_sk.resourceCulture);

		internal static string Off => LanguageText_sk.ResourceManager.GetString("Off", LanguageText_sk.resourceCulture);

		internal static string OfflineMode => LanguageText_sk.ResourceManager.GetString("OfflineMode", LanguageText_sk.resourceCulture);

		internal static string OffsetTeachValue => LanguageText_sk.ResourceManager.GetString("OffsetTeachValue", LanguageText_sk.resourceCulture);

		internal static string OffsetVoltageMax => LanguageText_sk.ResourceManager.GetString("OffsetVoltageMax", LanguageText_sk.resourceCulture);

		internal static string OffsetVoltageMin => LanguageText_sk.ResourceManager.GetString("OffsetVoltageMin", LanguageText_sk.resourceCulture);

		internal static string OfStep => LanguageText_sk.ResourceManager.GetString("OfStep", LanguageText_sk.resourceCulture);

		internal static string OK => LanguageText_sk.ResourceManager.GetString("OK", LanguageText_sk.resourceCulture);

		internal static string OKNOK => LanguageText_sk.ResourceManager.GetString("OKNOK", LanguageText_sk.resourceCulture);

		internal static string OldPassCode => LanguageText_sk.ResourceManager.GetString("OldPassCode", LanguageText_sk.resourceCulture);

		internal static string OldValue => LanguageText_sk.ResourceManager.GetString("OldValue", LanguageText_sk.resourceCulture);

		internal static string On => LanguageText_sk.ResourceManager.GetString("On", LanguageText_sk.resourceCulture);

		internal static string OnlineMode => LanguageText_sk.ResourceManager.GetString("OnlineMode", LanguageText_sk.resourceCulture);

		internal static string OnlyIO => LanguageText_sk.ResourceManager.GetString("OnlyIO", LanguageText_sk.resourceCulture);

		internal static string OptPrgParam => LanguageText_sk.ResourceManager.GetString("OptPrgParam", LanguageText_sk.resourceCulture);

		internal static string Organisation => LanguageText_sk.ResourceManager.GetString("Organisation", LanguageText_sk.resourceCulture);

		internal static string OrganizingStep => LanguageText_sk.ResourceManager.GetString("OrganizingStep", LanguageText_sk.resourceCulture);

		internal static string OutOfRange => LanguageText_sk.ResourceManager.GetString("OutOfRange", LanguageText_sk.resourceCulture);

		internal static string Outputs => LanguageText_sk.ResourceManager.GetString("Outputs", LanguageText_sk.resourceCulture);

		internal static string PaintCurve => LanguageText_sk.ResourceManager.GetString("PaintCurve", LanguageText_sk.resourceCulture);

		internal static string Parameter => LanguageText_sk.ResourceManager.GetString("Parameter", LanguageText_sk.resourceCulture);

		internal static string Parity => LanguageText_sk.ResourceManager.GetString("Parity", LanguageText_sk.resourceCulture);

		internal static string PasscodeLevel => LanguageText_sk.ResourceManager.GetString("PasscodeLevel", LanguageText_sk.resourceCulture);

		internal static string PasscodeManager => LanguageText_sk.ResourceManager.GetString("PasscodeManager", LanguageText_sk.resourceCulture);

		internal static string Password => LanguageText_sk.ResourceManager.GetString("Password", LanguageText_sk.resourceCulture);

		internal static string PasswordInput => LanguageText_sk.ResourceManager.GetString("PasswordInput", LanguageText_sk.resourceCulture);

		internal static string Percent => LanguageText_sk.ResourceManager.GetString("Percent", LanguageText_sk.resourceCulture);

		internal static string PLC_IO => LanguageText_sk.ResourceManager.GetString("PLC_IO", LanguageText_sk.resourceCulture);

		internal static string PointOfTime => LanguageText_sk.ResourceManager.GetString("PointOfTime", LanguageText_sk.resourceCulture);

		internal static string Positive => LanguageText_sk.ResourceManager.GetString("Positive", LanguageText_sk.resourceCulture);

		internal static string PosOverload => LanguageText_sk.ResourceManager.GetString("PosOverload", LanguageText_sk.resourceCulture);

		internal static string PowerEnabled => LanguageText_sk.ResourceManager.GetString("PowerEnabled", LanguageText_sk.resourceCulture);

		internal static string Pressure => LanguageText_sk.ResourceManager.GetString("Pressure", LanguageText_sk.resourceCulture);

		internal static string PressureCylinder => LanguageText_sk.ResourceManager.GetString("PressureCylinder", LanguageText_sk.resourceCulture);

		internal static string PressureSpindle => LanguageText_sk.ResourceManager.GetString("PressureSpindle", LanguageText_sk.resourceCulture);

		internal static string Print => LanguageText_sk.ResourceManager.GetString("Print", LanguageText_sk.resourceCulture);

		internal static string ProcessInputs => LanguageText_sk.ResourceManager.GetString("ProcessInputs", LanguageText_sk.resourceCulture);

		internal static string ProcessRunning => LanguageText_sk.ResourceManager.GetString("ProcessRunning", LanguageText_sk.resourceCulture);

		internal static string Program => LanguageText_sk.ResourceManager.GetString("Program", LanguageText_sk.resourceCulture);

		internal static string ProgramChange201000 => LanguageText_sk.ResourceManager.GetString("ProgramChange201000", LanguageText_sk.resourceCulture);

		internal static string ProgramChange201001 => LanguageText_sk.ResourceManager.GetString("ProgramChange201001", LanguageText_sk.resourceCulture);

		internal static string ProgramChange201002 => LanguageText_sk.ResourceManager.GetString("ProgramChange201002", LanguageText_sk.resourceCulture);

		internal static string ProgramChange201003 => LanguageText_sk.ResourceManager.GetString("ProgramChange201003", LanguageText_sk.resourceCulture);

		internal static string ProgramChange201004 => LanguageText_sk.ResourceManager.GetString("ProgramChange201004", LanguageText_sk.resourceCulture);

		internal static string ProgramChange201005 => LanguageText_sk.ResourceManager.GetString("ProgramChange201005", LanguageText_sk.resourceCulture);

		internal static string ProgramChange201006 => LanguageText_sk.ResourceManager.GetString("ProgramChange201006", LanguageText_sk.resourceCulture);

		internal static string ProgramChange201007 => LanguageText_sk.ResourceManager.GetString("ProgramChange201007", LanguageText_sk.resourceCulture);

		internal static string ProgramChange201008 => LanguageText_sk.ResourceManager.GetString("ProgramChange201008", LanguageText_sk.resourceCulture);

		internal static string ProgramChange201009 => LanguageText_sk.ResourceManager.GetString("ProgramChange201009", LanguageText_sk.resourceCulture);

		internal static string ProgramChange207000 => LanguageText_sk.ResourceManager.GetString("ProgramChange207000", LanguageText_sk.resourceCulture);

		internal static string ProgramChange207001 => LanguageText_sk.ResourceManager.GetString("ProgramChange207001", LanguageText_sk.resourceCulture);

		internal static string ProgramChange207003 => LanguageText_sk.ResourceManager.GetString("ProgramChange207003", LanguageText_sk.resourceCulture);

		internal static string ProgramNumber => LanguageText_sk.ResourceManager.GetString("ProgramNumber", LanguageText_sk.resourceCulture);

		internal static string Programs => LanguageText_sk.ResourceManager.GetString("Programs", LanguageText_sk.resourceCulture);

		internal static string Quit => LanguageText_sk.ResourceManager.GetString("Quit", LanguageText_sk.resourceCulture);

		internal static string Ramp => LanguageText_sk.ResourceManager.GetString("Ramp", LanguageText_sk.resourceCulture);

		internal static string Range => LanguageText_sk.ResourceManager.GetString("Range", LanguageText_sk.resourceCulture);

		internal static string ReadyToStart => LanguageText_sk.ResourceManager.GetString("ReadyToStart", LanguageText_sk.resourceCulture);

		internal static string RecentDateTime => LanguageText_sk.ResourceManager.GetString("RecentDateTime", LanguageText_sk.resourceCulture);

		internal static string Reconnect => LanguageText_sk.ResourceManager.GetString("Reconnect", LanguageText_sk.resourceCulture);

		internal static string ReconnectToController => LanguageText_sk.ResourceManager.GetString("ReconnectToController", LanguageText_sk.resourceCulture);

		internal static string RecursiveStatMode => LanguageText_sk.ResourceManager.GetString("RecursiveStatMode", LanguageText_sk.resourceCulture);

		internal static string RedAngle => LanguageText_sk.ResourceManager.GetString("RedAngle", LanguageText_sk.resourceCulture);

		internal static string RedTorque => LanguageText_sk.ResourceManager.GetString("RedTorque", LanguageText_sk.resourceCulture);

		internal static string RedundantSensorActive => LanguageText_sk.ResourceManager.GetString("RedundantSensorActive", LanguageText_sk.resourceCulture);

		internal static string relatedTo => LanguageText_sk.ResourceManager.GetString("relatedTo", LanguageText_sk.resourceCulture);

		internal static string RelativeTorque => LanguageText_sk.ResourceManager.GetString("RelativeTorque", LanguageText_sk.resourceCulture);

		internal static string Release => LanguageText_sk.ResourceManager.GetString("Release", LanguageText_sk.resourceCulture);

		internal static string ReleaseSpeed => LanguageText_sk.ResourceManager.GetString("ReleaseSpeed", LanguageText_sk.resourceCulture);

		internal static string RelTorqueStep => LanguageText_sk.ResourceManager.GetString("RelTorqueStep", LanguageText_sk.resourceCulture);

		internal static string RemainedCurves => LanguageText_sk.ResourceManager.GetString("RemainedCurves", LanguageText_sk.resourceCulture);

		internal static string RepeatPassCode => LanguageText_sk.ResourceManager.GetString("RepeatPassCode", LanguageText_sk.resourceCulture);

		internal static string Reset => LanguageText_sk.ResourceManager.GetString("Reset", LanguageText_sk.resourceCulture);

		internal static string ResetADepth => LanguageText_sk.ResourceManager.GetString("ResetADepth", LanguageText_sk.resourceCulture);

		internal static string ResetAngle => LanguageText_sk.ResourceManager.GetString("ResetAngle", LanguageText_sk.resourceCulture);

		internal static string Result => LanguageText_sk.ResourceManager.GetString("Result", LanguageText_sk.resourceCulture);

		internal static string ResultDisplay => LanguageText_sk.ResourceManager.GetString("ResultDisplay", LanguageText_sk.resourceCulture);

		internal static string Results => LanguageText_sk.ResourceManager.GetString("Results", LanguageText_sk.resourceCulture);

		internal static string RightAngle => LanguageText_sk.ResourceManager.GetString("RightAngle", LanguageText_sk.resourceCulture);

		internal static string Robot => LanguageText_sk.ResourceManager.GetString("Robot", LanguageText_sk.resourceCulture);

		internal static string RoundsPerMinute => LanguageText_sk.ResourceManager.GetString("RoundsPerMinute", LanguageText_sk.resourceCulture);

		internal static string RpmTest => LanguageText_sk.ResourceManager.GetString("RpmTest", LanguageText_sk.resourceCulture);

		internal static string RpmUnit => LanguageText_sk.ResourceManager.GetString("RpmUnit", LanguageText_sk.resourceCulture);

		internal static string RS232PrintMode => LanguageText_sk.ResourceManager.GetString("RS232PrintMode", LanguageText_sk.resourceCulture);

		internal static string SampleSize => LanguageText_sk.ResourceManager.GetString("SampleSize", LanguageText_sk.resourceCulture);

		internal static string SampleStatistic => LanguageText_sk.ResourceManager.GetString("SampleStatistic", LanguageText_sk.resourceCulture);

		internal static string SaveCurveDataToFile => LanguageText_sk.ResourceManager.GetString("SaveCurveDataToFile", LanguageText_sk.resourceCulture);

		internal static string SaveCustBackup => LanguageText_sk.ResourceManager.GetString("SaveCustBackup", LanguageText_sk.resourceCulture);

		internal static string SaveCustBackupOnCF => LanguageText_sk.ResourceManager.GetString("SaveCustBackupOnCF", LanguageText_sk.resourceCulture);

		internal static string SaveCustBackupSecQuery => LanguageText_sk.ResourceManager.GetString("SaveCustBackupSecQuery", LanguageText_sk.resourceCulture);

		internal static string SavePasscodesOnCPU => LanguageText_sk.ResourceManager.GetString("SavePasscodesOnCPU", LanguageText_sk.resourceCulture);

		internal static string SavePProgToFile => LanguageText_sk.ResourceManager.GetString("SavePProgToFile", LanguageText_sk.resourceCulture);

		internal static string SaveProgOnCPU => LanguageText_sk.ResourceManager.GetString("SaveProgOnCPU", LanguageText_sk.resourceCulture);

		internal static string SaveProgramData => LanguageText_sk.ResourceManager.GetString("SaveProgramData", LanguageText_sk.resourceCulture);

		internal static string SaveProgramDataLocally => LanguageText_sk.ResourceManager.GetString("SaveProgramDataLocally", LanguageText_sk.resourceCulture);

		internal static string SaveSingleProgToFile => LanguageText_sk.ResourceManager.GetString("SaveSingleProgToFile", LanguageText_sk.resourceCulture);

		internal static string SaveSpindleConstOnCPU => LanguageText_sk.ResourceManager.GetString("SaveSpindleConstOnCPU", LanguageText_sk.resourceCulture);

		internal static string SaveSpindleDataLocally => LanguageText_sk.ResourceManager.GetString("SaveSpindleDataLocally", LanguageText_sk.resourceCulture);

		internal static string SaveSystemConstOnCPU => LanguageText_sk.ResourceManager.GetString("SaveSystemConstOnCPU", LanguageText_sk.resourceCulture);

		internal static string SaveToFile => LanguageText_sk.ResourceManager.GetString("SaveToFile", LanguageText_sk.resourceCulture);

		internal static string SaveVisuParam => LanguageText_sk.ResourceManager.GetString("SaveVisuParam", LanguageText_sk.resourceCulture);

		internal static string SaveWebBackupSecQuery => LanguageText_sk.ResourceManager.GetString("SaveWebBackupSecQuery", LanguageText_sk.resourceCulture);

		internal static string SaveWeberBackup => LanguageText_sk.ResourceManager.GetString("SaveWeberBackup", LanguageText_sk.resourceCulture);

		internal static string SaveWeberBackupOnCF => LanguageText_sk.ResourceManager.GetString("SaveWeberBackupOnCF", LanguageText_sk.resourceCulture);

		internal static string ScrewID => LanguageText_sk.ResourceManager.GetString("ScrewID", LanguageText_sk.resourceCulture);

		internal static string ScrewProgramFiles => LanguageText_sk.ResourceManager.GetString("ScrewProgramFiles", LanguageText_sk.resourceCulture);

		internal static string ScrewPrograms => LanguageText_sk.ResourceManager.GetString("ScrewPrograms", LanguageText_sk.resourceCulture);

		internal static string ScrewTime => LanguageText_sk.ResourceManager.GetString("ScrewTime", LanguageText_sk.resourceCulture);

		internal static string Second => LanguageText_sk.ResourceManager.GetString("Second", LanguageText_sk.resourceCulture);

		internal static string SelectAll => LanguageText_sk.ResourceManager.GetString("SelectAll", LanguageText_sk.resourceCulture);

		internal static string SelectedKind => LanguageText_sk.ResourceManager.GetString("SelectedKind", LanguageText_sk.resourceCulture);

		internal static string SelectedXAxis => LanguageText_sk.ResourceManager.GetString("SelectedXAxis", LanguageText_sk.resourceCulture);

		internal static string SelectedYAxis => LanguageText_sk.ResourceManager.GetString("SelectedYAxis", LanguageText_sk.resourceCulture);

		internal static string SelectNone => LanguageText_sk.ResourceManager.GetString("SelectNone", LanguageText_sk.resourceCulture);

		internal static string SelValidNumber => LanguageText_sk.ResourceManager.GetString("SelValidNumber", LanguageText_sk.resourceCulture);

		internal static string SendIO => LanguageText_sk.ResourceManager.GetString("SendIO", LanguageText_sk.resourceCulture);

		internal static string SendPasscodes => LanguageText_sk.ResourceManager.GetString("SendPasscodes", LanguageText_sk.resourceCulture);

		internal static string SendSpindleConstants => LanguageText_sk.ResourceManager.GetString("SendSpindleConstants", LanguageText_sk.resourceCulture);

		internal static string SendSystemConstants => LanguageText_sk.ResourceManager.GetString("SendSystemConstants", LanguageText_sk.resourceCulture);

		internal static string SensorTest => LanguageText_sk.ResourceManager.GetString("SensorTest", LanguageText_sk.resourceCulture);

		internal static string Set => LanguageText_sk.ResourceManager.GetString("Set", LanguageText_sk.resourceCulture);

		internal static string SetAnaOut => LanguageText_sk.ResourceManager.GetString("SetAnaOut", LanguageText_sk.resourceCulture);

		internal static string SetDigOut => LanguageText_sk.ResourceManager.GetString("SetDigOut", LanguageText_sk.resourceCulture);

		internal static string SetOff => LanguageText_sk.ResourceManager.GetString("SetOff", LanguageText_sk.resourceCulture);

		internal static string SetOn => LanguageText_sk.ResourceManager.GetString("SetOn", LanguageText_sk.resourceCulture);

		internal static string SetRight => LanguageText_sk.ResourceManager.GetString("SetRight", LanguageText_sk.resourceCulture);

		internal static string SetRpm => LanguageText_sk.ResourceManager.GetString("SetRpm", LanguageText_sk.resourceCulture);

		internal static string Settings => LanguageText_sk.ResourceManager.GetString("Settings", LanguageText_sk.resourceCulture);

		internal static string ShortName => LanguageText_sk.ResourceManager.GetString("ShortName", LanguageText_sk.resourceCulture);

		internal static string SignalQuit => LanguageText_sk.ResourceManager.GetString("SignalQuit", LanguageText_sk.resourceCulture);

		internal static string Slovak => LanguageText_sk.ResourceManager.GetString("Slovak", LanguageText_sk.resourceCulture);

		internal static string Spain => LanguageText_sk.ResourceManager.GetString("Spain", LanguageText_sk.resourceCulture);

		internal static string SpChange100010 => LanguageText_sk.ResourceManager.GetString("SpChange100010", LanguageText_sk.resourceCulture);

		internal static string SpChange203000 => LanguageText_sk.ResourceManager.GetString("SpChange203000", LanguageText_sk.resourceCulture);

		internal static string SpChange203001 => LanguageText_sk.ResourceManager.GetString("SpChange203001", LanguageText_sk.resourceCulture);

		internal static string SpChange203002 => LanguageText_sk.ResourceManager.GetString("SpChange203002", LanguageText_sk.resourceCulture);

		internal static string SpChange203003 => LanguageText_sk.ResourceManager.GetString("SpChange203003", LanguageText_sk.resourceCulture);

		internal static string SpChange203004 => LanguageText_sk.ResourceManager.GetString("SpChange203004", LanguageText_sk.resourceCulture);

		internal static string SpChange203005 => LanguageText_sk.ResourceManager.GetString("SpChange203005", LanguageText_sk.resourceCulture);

		internal static string SpChange203006 => LanguageText_sk.ResourceManager.GetString("SpChange203006", LanguageText_sk.resourceCulture);

		internal static string SpChange203007 => LanguageText_sk.ResourceManager.GetString("SpChange203007", LanguageText_sk.resourceCulture);

		internal static string SpChange203008 => LanguageText_sk.ResourceManager.GetString("SpChange203008", LanguageText_sk.resourceCulture);

		internal static string SpChange203009 => LanguageText_sk.ResourceManager.GetString("SpChange203009", LanguageText_sk.resourceCulture);

		internal static string SpChange203010 => LanguageText_sk.ResourceManager.GetString("SpChange203010", LanguageText_sk.resourceCulture);

		internal static string SpChange203011 => LanguageText_sk.ResourceManager.GetString("SpChange203011", LanguageText_sk.resourceCulture);

		internal static string SpChange203012 => LanguageText_sk.ResourceManager.GetString("SpChange203012", LanguageText_sk.resourceCulture);

		internal static string SpChange203013 => LanguageText_sk.ResourceManager.GetString("SpChange203013", LanguageText_sk.resourceCulture);

		internal static string SpChange203014 => LanguageText_sk.ResourceManager.GetString("SpChange203014", LanguageText_sk.resourceCulture);

		internal static string SpChange203015 => LanguageText_sk.ResourceManager.GetString("SpChange203015", LanguageText_sk.resourceCulture);

		internal static string SpChange203016 => LanguageText_sk.ResourceManager.GetString("SpChange203016", LanguageText_sk.resourceCulture);

		internal static string SpChange203017 => LanguageText_sk.ResourceManager.GetString("SpChange203017", LanguageText_sk.resourceCulture);

		internal static string SpChange203018 => LanguageText_sk.ResourceManager.GetString("SpChange203018", LanguageText_sk.resourceCulture);

		internal static string SpChange203019 => LanguageText_sk.ResourceManager.GetString("SpChange203019", LanguageText_sk.resourceCulture);

		internal static string SpChange203020 => LanguageText_sk.ResourceManager.GetString("SpChange203020", LanguageText_sk.resourceCulture);

		internal static string SpChange203021 => LanguageText_sk.ResourceManager.GetString("SpChange203021", LanguageText_sk.resourceCulture);

		internal static string SpChange203022 => LanguageText_sk.ResourceManager.GetString("SpChange203022", LanguageText_sk.resourceCulture);

		internal static string SpChange203023 => LanguageText_sk.ResourceManager.GetString("SpChange203023", LanguageText_sk.resourceCulture);

		internal static string SpChange203024 => LanguageText_sk.ResourceManager.GetString("SpChange203024", LanguageText_sk.resourceCulture);

		internal static string SpChange203025 => LanguageText_sk.ResourceManager.GetString("SpChange203025", LanguageText_sk.resourceCulture);

		internal static string SpChange203026 => LanguageText_sk.ResourceManager.GetString("SpChange203026", LanguageText_sk.resourceCulture);

		internal static string SpChange203027 => LanguageText_sk.ResourceManager.GetString("SpChange203027", LanguageText_sk.resourceCulture);

		internal static string SpChange203028 => LanguageText_sk.ResourceManager.GetString("SpChange203028", LanguageText_sk.resourceCulture);

		internal static string SpChange203029 => LanguageText_sk.ResourceManager.GetString("SpChange203029", LanguageText_sk.resourceCulture);

		internal static string SpChange203030 => LanguageText_sk.ResourceManager.GetString("SpChange203030", LanguageText_sk.resourceCulture);

		internal static string SpChange207001 => LanguageText_sk.ResourceManager.GetString("SpChange207001", LanguageText_sk.resourceCulture);

		internal static string SpChange207002 => LanguageText_sk.ResourceManager.GetString("SpChange207002", LanguageText_sk.resourceCulture);

		internal static string SpChange207003 => LanguageText_sk.ResourceManager.GetString("SpChange207003", LanguageText_sk.resourceCulture);

		internal static string SpindleConstants => LanguageText_sk.ResourceManager.GetString("SpindleConstants", LanguageText_sk.resourceCulture);

		internal static string SpindleConstFiles => LanguageText_sk.ResourceManager.GetString("SpindleConstFiles", LanguageText_sk.resourceCulture);

		internal static string SpindlePressureScale => LanguageText_sk.ResourceManager.GetString("SpindlePressureScale", LanguageText_sk.resourceCulture);

		internal static string SpindleTorque => LanguageText_sk.ResourceManager.GetString("SpindleTorque", LanguageText_sk.resourceCulture);

		internal static string StandardDeviation => LanguageText_sk.ResourceManager.GetString("StandardDeviation", LanguageText_sk.resourceCulture);

		internal static string StartCycleSave => LanguageText_sk.ResourceManager.GetString("StartCycleSave", LanguageText_sk.resourceCulture);

		internal static string StartFrictionTest => LanguageText_sk.ResourceManager.GetString("StartFrictionTest", LanguageText_sk.resourceCulture);

		internal static string StartProgram => LanguageText_sk.ResourceManager.GetString("StartProgram", LanguageText_sk.resourceCulture);

		internal static string StartSignal => LanguageText_sk.ResourceManager.GetString("StartSignal", LanguageText_sk.resourceCulture);

		internal static string StartStepResExport => LanguageText_sk.ResourceManager.GetString("StartStepResExport", LanguageText_sk.resourceCulture);

		internal static string StartTest => LanguageText_sk.ResourceManager.GetString("StartTest", LanguageText_sk.resourceCulture);

		internal static string StatDelete204000 => LanguageText_sk.ResourceManager.GetString("StatDelete204000", LanguageText_sk.resourceCulture);

		internal static string StatDelete204001 => LanguageText_sk.ResourceManager.GetString("StatDelete204001", LanguageText_sk.resourceCulture);

		internal static string StatDelete204002 => LanguageText_sk.ResourceManager.GetString("StatDelete204002", LanguageText_sk.resourceCulture);

		internal static string State => LanguageText_sk.ResourceManager.GetString("State", LanguageText_sk.resourceCulture);

		internal static string StationName => LanguageText_sk.ResourceManager.GetString("StationName", LanguageText_sk.resourceCulture);

		internal static string StatisticCumul => LanguageText_sk.ResourceManager.GetString("StatisticCumul", LanguageText_sk.resourceCulture);

		internal static string Statistics => LanguageText_sk.ResourceManager.GetString("Statistics", LanguageText_sk.resourceCulture);

		internal static string StatisticSample => LanguageText_sk.ResourceManager.GetString("StatisticSample", LanguageText_sk.resourceCulture);

		internal static string StatisticsLastRes => LanguageText_sk.ResourceManager.GetString("StatisticsLastRes", LanguageText_sk.resourceCulture);

		internal static string Step => LanguageText_sk.ResourceManager.GetString("Step", LanguageText_sk.resourceCulture);

		internal static string StepFinish => LanguageText_sk.ResourceManager.GetString("StepFinish", LanguageText_sk.resourceCulture);

		internal static string StepKind => LanguageText_sk.ResourceManager.GetString("StepKind", LanguageText_sk.resourceCulture);

		internal static string StepKindChoice => LanguageText_sk.ResourceManager.GetString("StepKindChoice", LanguageText_sk.resourceCulture);

		internal static string StepResults => LanguageText_sk.ResourceManager.GetString("StepResults", LanguageText_sk.resourceCulture);

		internal static string Steps => LanguageText_sk.ResourceManager.GetString("Steps", LanguageText_sk.resourceCulture);

		internal static string StepTmin => LanguageText_sk.ResourceManager.GetString("StepTmin", LanguageText_sk.resourceCulture);

		internal static string StepTplus => LanguageText_sk.ResourceManager.GetString("StepTplus", LanguageText_sk.resourceCulture);

		internal static string Stop => LanguageText_sk.ResourceManager.GetString("Stop", LanguageText_sk.resourceCulture);

		internal static string StopNok => LanguageText_sk.ResourceManager.GetString("StopNok", LanguageText_sk.resourceCulture);

		internal static string StopOk => LanguageText_sk.ResourceManager.GetString("StopOk", LanguageText_sk.resourceCulture);

		internal static string StopStepResExport => LanguageText_sk.ResourceManager.GetString("StopStepResExport", LanguageText_sk.resourceCulture);

		internal static string storageFilenameFormat => LanguageText_sk.ResourceManager.GetString("storageFilenameFormat", LanguageText_sk.resourceCulture);

		internal static string StorageNumber => LanguageText_sk.ResourceManager.GetString("StorageNumber", LanguageText_sk.resourceCulture);

		internal static string StorageSignals => LanguageText_sk.ResourceManager.GetString("StorageSignals", LanguageText_sk.resourceCulture);

		internal static string StoreAndBack => LanguageText_sk.ResourceManager.GetString("StoreAndBack", LanguageText_sk.resourceCulture);

		internal static string Straßenführer => LanguageText_sk.ResourceManager.GetString("Straßenführer", LanguageText_sk.resourceCulture);

		internal static string SubnetMask => LanguageText_sk.ResourceManager.GetString("SubnetMask", LanguageText_sk.resourceCulture);

		internal static string SyncOut => LanguageText_sk.ResourceManager.GetString("SyncOut", LanguageText_sk.resourceCulture);

		internal static string SyncSignal => LanguageText_sk.ResourceManager.GetString("SyncSignal", LanguageText_sk.resourceCulture);

		internal static string SysChange202000 => LanguageText_sk.ResourceManager.GetString("SysChange202000", LanguageText_sk.resourceCulture);

		internal static string SysChange202001 => LanguageText_sk.ResourceManager.GetString("SysChange202001", LanguageText_sk.resourceCulture);

		internal static string SysChange202002 => LanguageText_sk.ResourceManager.GetString("SysChange202002", LanguageText_sk.resourceCulture);

		internal static string SysChange202003 => LanguageText_sk.ResourceManager.GetString("SysChange202003", LanguageText_sk.resourceCulture);

		internal static string SysChange202004 => LanguageText_sk.ResourceManager.GetString("SysChange202004", LanguageText_sk.resourceCulture);

		internal static string SysChange202005 => LanguageText_sk.ResourceManager.GetString("SysChange202005", LanguageText_sk.resourceCulture);

		internal static string SysChange202006 => LanguageText_sk.ResourceManager.GetString("SysChange202006", LanguageText_sk.resourceCulture);

		internal static string SysChange202007 => LanguageText_sk.ResourceManager.GetString("SysChange202007", LanguageText_sk.resourceCulture);

		internal static string SysChange202008 => LanguageText_sk.ResourceManager.GetString("SysChange202008", LanguageText_sk.resourceCulture);

		internal static string SysChange202009 => LanguageText_sk.ResourceManager.GetString("SysChange202009", LanguageText_sk.resourceCulture);

		internal static string SysChange202010 => LanguageText_sk.ResourceManager.GetString("SysChange202010", LanguageText_sk.resourceCulture);

		internal static string SysChange202011 => LanguageText_sk.ResourceManager.GetString("SysChange202011", LanguageText_sk.resourceCulture);

		internal static string SysChange202012 => LanguageText_sk.ResourceManager.GetString("SysChange202012", LanguageText_sk.resourceCulture);

		internal static string SysChange202013 => LanguageText_sk.ResourceManager.GetString("SysChange202013", LanguageText_sk.resourceCulture);

		internal static string SysChange202014 => LanguageText_sk.ResourceManager.GetString("SysChange202014", LanguageText_sk.resourceCulture);

		internal static string SysChange202015 => LanguageText_sk.ResourceManager.GetString("SysChange202015", LanguageText_sk.resourceCulture);

		internal static string SysChange202016 => LanguageText_sk.ResourceManager.GetString("SysChange202016", LanguageText_sk.resourceCulture);

		internal static string SysChange202017 => LanguageText_sk.ResourceManager.GetString("SysChange202017", LanguageText_sk.resourceCulture);

		internal static string SysChange202018 => LanguageText_sk.ResourceManager.GetString("SysChange202018", LanguageText_sk.resourceCulture);

		internal static string SystemConstants => LanguageText_sk.ResourceManager.GetString("SystemConstants", LanguageText_sk.resourceCulture);

		internal static string SystemID => LanguageText_sk.ResourceManager.GetString("SystemID", LanguageText_sk.resourceCulture);

		internal static string SystemOK => LanguageText_sk.ResourceManager.GetString("SystemOK", LanguageText_sk.resourceCulture);

		internal static string Target => LanguageText_sk.ResourceManager.GetString("Target", LanguageText_sk.resourceCulture);

		internal static string TargetRight => LanguageText_sk.ResourceManager.GetString("TargetRight", LanguageText_sk.resourceCulture);

		internal static string TeachSignal => LanguageText_sk.ResourceManager.GetString("TeachSignal", LanguageText_sk.resourceCulture);

		internal static string Test => LanguageText_sk.ResourceManager.GetString("Test", LanguageText_sk.resourceCulture);

		internal static string TestIO => LanguageText_sk.ResourceManager.GetString("TestIO", LanguageText_sk.resourceCulture);

		internal static string TestMFS => LanguageText_sk.ResourceManager.GetString("TestMFS", LanguageText_sk.resourceCulture);

		internal static string TestSPSIO => LanguageText_sk.ResourceManager.GetString("TestSPSIO", LanguageText_sk.resourceCulture);

		internal static string Time => LanguageText_sk.ResourceManager.GetString("Time", LanguageText_sk.resourceCulture);

		internal static string TimeDateFormat => LanguageText_sk.ResourceManager.GetString("TimeDateFormat", LanguageText_sk.resourceCulture);

		internal static string TimeSet => LanguageText_sk.ResourceManager.GetString("TimeSet", LanguageText_sk.resourceCulture);

		internal static string TimeSynchronize => LanguageText_sk.ResourceManager.GetString("TimeSynchronize", LanguageText_sk.resourceCulture);

		internal static string TM1 => LanguageText_sk.ResourceManager.GetString("TM1", LanguageText_sk.resourceCulture);

		internal static string TM2 => LanguageText_sk.ResourceManager.GetString("TM2", LanguageText_sk.resourceCulture);

		internal static string TN => LanguageText_sk.ResourceManager.GetString("TN", LanguageText_sk.resourceCulture);

		internal static string ToggleCursor => LanguageText_sk.ResourceManager.GetString("ToggleCursor", LanguageText_sk.resourceCulture);

		internal static string TopAll => LanguageText_sk.ResourceManager.GetString("TopAll", LanguageText_sk.resourceCulture);

		internal static string TopTen => LanguageText_sk.ResourceManager.GetString("TopTen", LanguageText_sk.resourceCulture);

		internal static string Torque => LanguageText_sk.ResourceManager.GetString("Torque", LanguageText_sk.resourceCulture);

		internal static string Torqueftlb => LanguageText_sk.ResourceManager.GetString("Torqueftlb", LanguageText_sk.resourceCulture);

		internal static string Torqueinlb => LanguageText_sk.ResourceManager.GetString("Torqueinlb", LanguageText_sk.resourceCulture);

		internal static string Torqueinoz => LanguageText_sk.ResourceManager.GetString("Torqueinoz", LanguageText_sk.resourceCulture);

		internal static string Torquekgcm => LanguageText_sk.ResourceManager.GetString("Torquekgcm", LanguageText_sk.resourceCulture);

		internal static string Torquekgm => LanguageText_sk.ResourceManager.GetString("Torquekgm", LanguageText_sk.resourceCulture);

		internal static string TorqueNcm => LanguageText_sk.ResourceManager.GetString("TorqueNcm", LanguageText_sk.resourceCulture);

		internal static string TorqueNm => LanguageText_sk.ResourceManager.GetString("TorqueNm", LanguageText_sk.resourceCulture);

		internal static string TorqueRedundantTime => LanguageText_sk.ResourceManager.GetString("TorqueRedundantTime", LanguageText_sk.resourceCulture);

		internal static string TorqueRedundantTolerance => LanguageText_sk.ResourceManager.GetString("TorqueRedundantTolerance", LanguageText_sk.resourceCulture);

		internal static string TorqueSensorInvers => LanguageText_sk.ResourceManager.GetString("TorqueSensorInvers", LanguageText_sk.resourceCulture);

		internal static string TorqueSensorScale => LanguageText_sk.ResourceManager.GetString("TorqueSensorScale", LanguageText_sk.resourceCulture);

		internal static string TorqueSensorTolerance => LanguageText_sk.ResourceManager.GetString("TorqueSensorTolerance", LanguageText_sk.resourceCulture);

		internal static string TorqueUnitChoose => LanguageText_sk.ResourceManager.GetString("TorqueUnitChoose", LanguageText_sk.resourceCulture);

		internal static string TreshTorque => LanguageText_sk.ResourceManager.GetString("TreshTorque", LanguageText_sk.resourceCulture);

		internal static string Type => LanguageText_sk.ResourceManager.GetString("Type", LanguageText_sk.resourceCulture);

		internal static string Unit => LanguageText_sk.ResourceManager.GetString("Unit", LanguageText_sk.resourceCulture);

		internal static string UnitBar => LanguageText_sk.ResourceManager.GetString("UnitBar", LanguageText_sk.resourceCulture);

		internal static string UpperLimit => LanguageText_sk.ResourceManager.GetString("UpperLimit", LanguageText_sk.resourceCulture);

		internal static string UsbPasswordInput => LanguageText_sk.ResourceManager.GetString("UsbPasswordInput", LanguageText_sk.resourceCulture);

		internal static string UsedKeyboard => LanguageText_sk.ResourceManager.GetString("UsedKeyboard", LanguageText_sk.resourceCulture);

		internal static string UsedValueNumber => LanguageText_sk.ResourceManager.GetString("UsedValueNumber", LanguageText_sk.resourceCulture);

		internal static string UseLanguageSettings => LanguageText_sk.ResourceManager.GetString("UseLanguageSettings", LanguageText_sk.resourceCulture);

		internal static string User => LanguageText_sk.ResourceManager.GetString("User", LanguageText_sk.resourceCulture);

		internal static string UserLoggedIn => LanguageText_sk.ResourceManager.GetString("UserLoggedIn", LanguageText_sk.resourceCulture);

		internal static string UserLoggedOut => LanguageText_sk.ResourceManager.GetString("UserLoggedOut", LanguageText_sk.resourceCulture);

		internal static string UserRights => LanguageText_sk.ResourceManager.GetString("UserRights", LanguageText_sk.resourceCulture);

		internal static string USTime => LanguageText_sk.ResourceManager.GetString("USTime", LanguageText_sk.resourceCulture);

		internal static string Valid => LanguageText_sk.ResourceManager.GetString("Valid", LanguageText_sk.resourceCulture);

		internal static string Value => LanguageText_sk.ResourceManager.GetString("Value", LanguageText_sk.resourceCulture);

		internal static string ValueRange => LanguageText_sk.ResourceManager.GetString("ValueRange", LanguageText_sk.resourceCulture);

		internal static string ValuesNotApplied => LanguageText_sk.ResourceManager.GetString("ValuesNotApplied", LanguageText_sk.resourceCulture);

		internal static string VersionController => LanguageText_sk.ResourceManager.GetString("VersionController", LanguageText_sk.resourceCulture);

		internal static string VersionInfo => LanguageText_sk.ResourceManager.GetString("VersionInfo", LanguageText_sk.resourceCulture);

		internal static string VersionVisu => LanguageText_sk.ResourceManager.GetString("VersionVisu", LanguageText_sk.resourceCulture);

		internal static string Visualisation => LanguageText_sk.ResourceManager.GetString("Visualisation", LanguageText_sk.resourceCulture);

		internal static string VisuParam => LanguageText_sk.ResourceManager.GetString("VisuParam", LanguageText_sk.resourceCulture);

		internal static string Voltage => LanguageText_sk.ResourceManager.GetString("Voltage", LanguageText_sk.resourceCulture);

		internal static string WaitForAck => LanguageText_sk.ResourceManager.GetString("WaitForAck", LanguageText_sk.resourceCulture);

		internal static string Warning => LanguageText_sk.ResourceManager.GetString("Warning", LanguageText_sk.resourceCulture);

		internal static string WarningMode => LanguageText_sk.ResourceManager.GetString("WarningMode", LanguageText_sk.resourceCulture);

		internal static string WarningNumber => LanguageText_sk.ResourceManager.GetString("WarningNumber", LanguageText_sk.resourceCulture);

		internal static string WasReset => LanguageText_sk.ResourceManager.GetString("WasReset", LanguageText_sk.resourceCulture);

		internal static string WasSet => LanguageText_sk.ResourceManager.GetString("WasSet", LanguageText_sk.resourceCulture);

		internal static string Weber => LanguageText_sk.ResourceManager.GetString("Weber", LanguageText_sk.resourceCulture);

		internal static string WeberCurveFormat => LanguageText_sk.ResourceManager.GetString("WeberCurveFormat", LanguageText_sk.resourceCulture);

		internal static string WN => LanguageText_sk.ResourceManager.GetString("WN", LanguageText_sk.resourceCulture);

		internal static string WriteLastNIOTable => LanguageText_sk.ResourceManager.GetString("WriteLastNIOTable", LanguageText_sk.resourceCulture);

		internal static string WriteLastResultsTable => LanguageText_sk.ResourceManager.GetString("WriteLastResultsTable", LanguageText_sk.resourceCulture);

		internal static string WriteLogbookData => LanguageText_sk.ResourceManager.GetString("WriteLogbookData", LanguageText_sk.resourceCulture);

		internal static string WriteLogBookTable => LanguageText_sk.ResourceManager.GetString("WriteLogBookTable", LanguageText_sk.resourceCulture);

		internal static string WriteStepResults => LanguageText_sk.ResourceManager.GetString("WriteStepResults", LanguageText_sk.resourceCulture);

		internal static string Xmax => LanguageText_sk.ResourceManager.GetString("Xmax", LanguageText_sk.resourceCulture);

		internal static string Xmin => LanguageText_sk.ResourceManager.GetString("Xmin", LanguageText_sk.resourceCulture);

		internal static string XmlExport => LanguageText_sk.ResourceManager.GetString("XmlExport", LanguageText_sk.resourceCulture);

		internal static string Yes => LanguageText_sk.ResourceManager.GetString("Yes", LanguageText_sk.resourceCulture);

		internal static string ZoomIn => LanguageText_sk.ResourceManager.GetString("ZoomIn", LanguageText_sk.resourceCulture);

		internal static string ZoomOut => LanguageText_sk.ResourceManager.GetString("ZoomOut", LanguageText_sk.resourceCulture);

		internal LanguageText_sk()
		{
		}
	}
}
