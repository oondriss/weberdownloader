using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Visualisation
{
	public class StepKindChoiceForm : Form
	{
		private MainForm Main;

		public ushort InsertStepType;

		private Button btOrgStep;

		private Button btDrivingStep;

		private Button btFinalizeStep;

		private Container components;

		private Button btCancel;

		public StepKindChoiceForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.btOrgStep = new Button();
			this.btDrivingStep = new Button();
			this.btFinalizeStep = new Button();
			this.btCancel = new Button();
			base.SuspendLayout();
			this.btOrgStep.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btOrgStep.Location = new Point(10, 10);
			this.btOrgStep.Name = "btOrgStep";
			this.btOrgStep.Size = new Size(180, 30);
			this.btOrgStep.TabIndex = 0;
			this.btOrgStep.Text = "Organisationsstufe";
			this.btOrgStep.Click += this.btOrgStep_Click;
			this.btDrivingStep.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDrivingStep.Location = new Point(10, 50);
			this.btDrivingStep.Name = "btDrivingStep";
			this.btDrivingStep.Size = new Size(180, 30);
			this.btDrivingStep.TabIndex = 1;
			this.btDrivingStep.Text = "Eindrehstufe";
			this.btDrivingStep.Click += this.btDrivingStep_Click;
			this.btFinalizeStep.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btFinalizeStep.Location = new Point(10, 90);
			this.btFinalizeStep.Name = "btFinalizeStep";
			this.btFinalizeStep.Size = new Size(180, 30);
			this.btFinalizeStep.TabIndex = 2;
			this.btFinalizeStep.Text = "Festziehstufe";
			this.btFinalizeStep.Click += this.btFinalizeStep_Click;
			this.btCancel.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCancel.Location = new Point(88, 128);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(102, 32);
			this.btCancel.TabIndex = 3;
			this.btCancel.Text = "Abbrechen";
			this.btCancel.Click += this.btCancel_Click;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(200, 170);
			base.ControlBox = false;
			base.Controls.Add(this.btCancel);
			base.Controls.Add(this.btFinalizeStep);
			base.Controls.Add(this.btDrivingStep);
			base.Controls.Add(this.btOrgStep);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "StepKindChoiceForm";
			base.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "Auswahl der Stufenart";
			base.ResumeLayout(false);
		}

		public void Cancel()
		{
			if (base.Visible)
			{
				this.InsertStepType = 0;
				base.Close();
			}
		}

		public void ShowWindow(int prog, int step)
		{
			base.ShowDialog();
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("StepKindChoice");
			this.btCancel.Text = this.Main.Rm.GetString("Cancel");
			this.btDrivingStep.Text = this.Main.Rm.GetString("DrivingStep");
			this.btFinalizeStep.Text = this.Main.Rm.GetString("FinalizingStep");
			this.btOrgStep.Text = this.Main.Rm.GetString("OrganizingStep");
		}

		private void btOrgStep_Click(object sender, EventArgs e)
		{
			this.InsertStepType = 1;
			base.Close();
		}

		private void btDrivingStep_Click(object sender, EventArgs e)
		{
			this.InsertStepType = 2;
			base.Close();
		}

		private void btFinalizeStep_Click(object sender, EventArgs e)
		{
			this.InsertStepType = 3;
			base.Close();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.InsertStepType = 0;
			base.Close();
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (msg.WParam.ToInt32() == 27)
			{
				this.btCancel_Click(null, EventArgs.Empty);
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}
	}
}
