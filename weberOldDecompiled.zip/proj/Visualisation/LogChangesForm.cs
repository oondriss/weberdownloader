using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class LogChangesForm : Form
	{
		private MainForm Main;

		private int PrintPos;

		private DataTable LogData;

		private DataGridTableStyle Ts;

		private string[] ColumnName;

		private DataGrid_Specific_Class LogGrid;

		private Panel pnMenu;

		private Button btBack;

		private Button bt2;

		private Button btHelp;

		private Button btLoad;

		private Button bt3;

		private Button btPrint;

		private PrintDocument printDocument;

		private PrintDialog printDialog;

		private Button btExport;

		private SaveFileDialog SFD;

		private Label label1;

		private Button btBrowser;

		private Container components;

		private bool fistTimeInitialiseationDone;

		public LogChangesForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.LogGrid = new DataGrid_Specific_Class(1, base.Controls);
			this.PrintPos = 0;
			this.LogData = new DataTable("LogBook");
			this.ColumnName = new string[8];
			this.ColumnName[0] = "Number";
			this.ColumnName[1] = "Date";
			this.ColumnName[2] = "Message";
			this.ColumnName[3] = "NewValue";
			this.ColumnName[4] = "OldValue";
			this.ColumnName[5] = "Unit";
			this.ColumnName[6] = "Cycle";
			this.ColumnName[7] = "User";
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[0], typeof(int)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[1], typeof(string)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[2], typeof(string)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[3], typeof(string)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[4], typeof(string)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[5], typeof(string)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[6], typeof(uint)));
			this.LogData.Columns.Add(new DataColumn(this.ColumnName[7], typeof(string)));
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btBrowser = new Button();
			this.btPrint = new Button();
			this.btExport = new Button();
			this.btLoad = new Button();
			this.bt3 = new Button();
			this.bt2 = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.printDocument = new PrintDocument();
			this.printDialog = new PrintDialog();
			this.SFD = new SaveFileDialog();
			this.label1 = new Label();
			this.pnMenu.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btBrowser);
			this.pnMenu.Controls.Add(this.btPrint);
			this.pnMenu.Controls.Add(this.btExport);
			this.pnMenu.Controls.Add(this.btLoad);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btBrowser.Enabled = false;
			this.btBrowser.Location = new Point(3, 323);
			this.btBrowser.Name = "btBrowser";
			this.btBrowser.Size = new Size(74, 62);
			this.btBrowser.TabIndex = 10;
			this.btBrowser.Click += this.btBrowser_Click;
			this.btPrint.Location = new Point(3, 451);
			this.btPrint.Name = "btPrint";
			this.btPrint.Size = new Size(74, 62);
			this.btPrint.TabIndex = 7;
			this.btPrint.Text = "Print";
			this.btPrint.Click += this.btPrint_Click;
			this.btExport.Location = new Point(3, 387);
			this.btExport.Name = "btExport";
			this.btExport.Size = new Size(74, 62);
			this.btExport.TabIndex = 6;
			this.btExport.Text = "Export";
			this.btExport.Click += this.btExport_Click;
			this.btLoad.Location = new Point(3, 131);
			this.btLoad.Name = "btLoad";
			this.btLoad.Size = new Size(74, 62);
			this.btLoad.TabIndex = 5;
			this.btLoad.Text = "Load again";
			this.btLoad.Click += this.btLoad_Click;
			this.bt3.Enabled = false;
			this.bt3.Location = new Point(3, 259);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 4;
			this.bt2.Enabled = false;
			this.bt2.Location = new Point(3, 195);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 3;
			///this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.printDocument.PrintPage += this.printDocument_PrintPage;
			this.printDialog.Document = this.printDocument;
			this.SFD.Filter = "LogFiles (.txt)|*.txt|All Files|*.*";
			this.label1.AutoSize = true;
			this.label1.Location = new Point(26, 242);
			this.label1.Name = "label1";
			this.label1.Size = new Size(655, 15);
			this.label1.TabIndex = 2;
			this.label1.Text = "DataGrid LogGrid will not be displayed in Editor due to introduction of derived class DataGrid_Specific_Class (DataGrid defined there!)";
			this.label1.Visible = false;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.label1);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.Name = "LogChangesForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Auswertung/AenderungsLogbuch";
			base.Activated += this.LogChangesForm_Activated;
			this.pnMenu.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public bool ShowWindow()
		{
			if (!this.Main.IsOnlineMode)
			{
				base.Show();
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.Main.ActivationBrowserGrantedBy = this;
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadLogBookData"));
			if (!this.Main.VC.ReceiveVarBlock(7))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive LogBookSysBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("WriteLogBookTable"));
			this.makeDataSet();
			base.Show();
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuAnalysis") + "/" + this.Main.Rm.GetString("ChangesLog");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btPrint.Text = this.Main.Rm.GetString("Print");
			this.btExport.Text = this.Main.Rm.GetString("ExportChangesList");
			this.printDocument.DocumentName = this.Main.Rm.GetString("ChangesLog_");
			this.btLoad.Text = this.Main.Rm.GetString("btLoad");
			this.SFD.Filter = this.Main.Rm.GetString("ChangesLog") + "|*.txt|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
		}

		public int Count(bool requestController)
		{
			if (!this.Main.IsOnlineMode)
			{
				return 0;
			}
			if (requestController)
			{
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadLogBookData"));
				if (!this.Main.VC.ReceiveVarBlock(7))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not receive LogBookSysBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return 0;
				}
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
			}
			int num = (int)(this.Main.VC.LogBookSys.Position - 1);
			uint position = this.Main.VC.LogBookSys.Position;
			uint length = this.Main.VC.LogBookSys.Length;
			num = (int)(this.Main.VC.LogBookSys.Position - 1);
			int num2 = 0;
			for (int i = 0; i < this.Main.VC.LogBookSys.Length; i++)
			{
				if (num < 0)
				{
					num = 2499;
				}
				if (this.Main.VC.LogBookSys.logMessBuffer[num].Type == 1 || (this.Main.VC.LogBookSys.logMessBuffer[num].Type == 0 && this.Main.VC.LogBookSys.logMessBuffer[num].Code != 100000))
				{
					num--;
				}
				else
				{
					num--;
					num2++;
				}
			}
			return num2;
		}

		private void makeDataSet()
		{
			string text = "";
			string text2 = "";
			string text3 = "";
			string text4 = string.Empty;
			string text5 = string.Empty;
			string text6 = string.Empty;
			int num = this.Main.VC.LogBookSys.logMessBuffer[0].userName.Length;
			int num2 = this.ColumnName.Length;
			int[] array = new int[num2];
			for (int i = 0; i < num2; i++)
			{
				array[i] = 0;
			}
			this.LogData.Clear();
			Graphics graphics = this.LogGrid.CreateGraphics();
			uint position = this.Main.VC.LogBookSys.Position;
			uint length = this.Main.VC.LogBookSys.Length;
			int num3 = (int)(this.Main.VC.LogBookSys.Position - 1);
			int num4 = 0;
			SizeF sizeF;
			for (int i = 0; i < this.Main.VC.LogBookSys.Length; i++)
			{
				if (num3 < 0)
				{
					num3 = 2499;
				}
				if (this.Main.VC.LogBookSys.logMessBuffer[num3].Type == 1 || (this.Main.VC.LogBookSys.logMessBuffer[num3].Type == 0 && this.Main.VC.LogBookSys.logMessBuffer[num3].Code != 100000))
				{
					num3--;
				}
				else
				{
					WSP1_VarComm.LogMessageStruct logMessageStruct = this.Main.VC.LogBookSys.logMessBuffer[num3];
					text = "";
					text2 = "";
					DataRow row = this.LogData.NewRow();
					this.LogData.Rows.Add(row);
					this.LogData.Rows[num4][this.ColumnName[0]] = num4 + 1;
					text3 = "A" + this.LogData.Rows[num4][this.ColumnName[0]].ToString();
					sizeF = graphics.MeasureString(text3, this.LogGrid.Font);
					int num5 = (int)Math.Ceiling((double)sizeF.Width);
					if (num5 > array[0])
					{
						array[0] = num5;
					}
					DateTime dateTime;
					try
					{
						dateTime = new DateTime(logMessageStruct.Time.Year, logMessageStruct.Time.Month, logMessageStruct.Time.Day, logMessageStruct.Time.Hour, logMessageStruct.Time.Minute, logMessageStruct.Time.Second);
					}
					catch
					{
						dateTime = new DateTime(1, 1, 1, 0, 0, 0);
					}
					string text7 = dateTime.ToString(Settings.Default.TimeSet);
					this.LogData.Rows[num4][this.ColumnName[1]] = text7;
					text3 = "AA" + text7;
					num5 = (int)Math.Ceiling((double)graphics.MeasureString(text3, this.LogGrid.Font).Width);
					if (num5 > array[1])
					{
						array[1] = num5;
					}
					int num6;
					switch (logMessageStruct.Type)
					{
					case 2:
					{
						uint code = logMessageStruct.Code;
						int progNum = (int)logMessageStruct.ProgNum;
						int num7 = logMessageStruct.Step + 1;
						switch (code)
						{
						case 201001u:
							text3 = this.Main.Rm.GetString("Program") + " " + logMessageStruct.Value1.ToString("f0") + ", " + this.Main.Rm.GetString("ProgramChange" + logMessageStruct.Code.ToString());
							text2 = "(" + logMessageStruct.Value2.ToString("f0") + ")";
							break;
						case 201005u:
						{
							string[] array2 = new string[8]
							{
								this.Main.Rm.GetString("Program"),
								" ",
								logMessageStruct.ProgNum.ToString(),
								", ",
								this.Main.Rm.GetString("Step"),
								null,
								null,
								null
							};
							string[] array3 = array2;
							num6 = logMessageStruct.Step + 1;
							array3[5] = num6.ToString();
							array2[6] = ": ";
							array2[7] = this.Main.Rm.GetString("ProgramChange" + logMessageStruct.Code.ToString());
							text3 = string.Concat(array2);
							break;
						}
						case 201006u:
							text3 = this.Main.Rm.GetString("Program") + " " + logMessageStruct.ProgNum.ToString() + ", " + this.Main.Rm.GetString("Step") + (logMessageStruct.Step + 1).ToString() + ": " + this.Main.Rm.GetString("ProgramChange" + logMessageStruct.Code.ToString());
							break;
						case 201100u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("AS-") + ")";
							break;
						case 201101u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("AS+") + ")";
							break;
						case 201102u:
							text6 = this.Main.Rm.GetString("AnaSignal");
							break;
						case 201103u:
							text6 = this.Main.Rm.GetString("CountPassMax");
							break;
						case 201104u:
						{
							string str;
							switch ((int)logMessageStruct.Value1)
							{
							case 1:
								str = this.Main.Rm.GetString("TM1") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 2:
								str = this.Main.Rm.GetString("TM2") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 3:
								str = this.Main.Rm.GetString("DigitalSignal") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 4:
								str = this.Main.Rm.GetString("JawOpen") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 5:
								str = this.Main.Rm.GetString("SyncSignal") + "2 " + this.Main.Rm.GetString("Positive");
								break;
							case -1:
								str = this.Main.Rm.GetString("TM1") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -2:
								str = this.Main.Rm.GetString("TM2") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -3:
								str = this.Main.Rm.GetString("DigitalSignal") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -4:
								str = this.Main.Rm.GetString("JawOpen") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -5:
								str = this.Main.Rm.GetString("SyncSignal") + "2 " + this.Main.Rm.GetString("Negative");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text4 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("DigSigRunning") + ")";
							text = str;
							switch ((int)logMessageStruct.Value2)
							{
							case 1:
								str = this.Main.Rm.GetString("TM1") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 2:
								str = this.Main.Rm.GetString("TM2") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 3:
								str = this.Main.Rm.GetString("DigitalSignal") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 4:
								str = this.Main.Rm.GetString("JawOpen") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 5:
								str = this.Main.Rm.GetString("SyncSignal") + "2 " + this.Main.Rm.GetString("Positive");
								break;
							case -1:
								str = this.Main.Rm.GetString("TM1") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -2:
								str = this.Main.Rm.GetString("TM2") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -3:
								str = this.Main.Rm.GetString("DigitalSignal") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -4:
								str = this.Main.Rm.GetString("JawOpen") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -5:
								str = this.Main.Rm.GetString("SyncSignal") + "2 " + this.Main.Rm.GetString("Negative");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text2 = str;
							break;
						}
						case 201105u:
						{
							string str;
							switch ((int)logMessageStruct.Value1)
							{
							case 1:
								str = this.Main.Rm.GetString("TM1") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 2:
								str = this.Main.Rm.GetString("TM2") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 3:
								str = this.Main.Rm.GetString("DigitalSignal") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 4:
								str = this.Main.Rm.GetString("JawOpen") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 5:
								str = this.Main.Rm.GetString("SyncSignal") + "2 " + this.Main.Rm.GetString("Positive");
								break;
							case -1:
								str = this.Main.Rm.GetString("TM1") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -2:
								str = this.Main.Rm.GetString("TM2") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -3:
								str = this.Main.Rm.GetString("DigitalSignal") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -4:
								str = this.Main.Rm.GetString("JawOpen") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -5:
								str = this.Main.Rm.GetString("SyncSignal") + "2 " + this.Main.Rm.GetString("Negative");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text4 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("DigSigAtEnd") + ")";
							text = str;
							switch ((int)logMessageStruct.Value2)
							{
							case 1:
								str = this.Main.Rm.GetString("TM1") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 2:
								str = this.Main.Rm.GetString("TM2") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 3:
								str = this.Main.Rm.GetString("DigitalSignal") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 4:
								str = this.Main.Rm.GetString("JawOpen") + " " + this.Main.Rm.GetString("Positive");
								break;
							case 5:
								str = this.Main.Rm.GetString("SyncSignal") + "2 " + this.Main.Rm.GetString("Positive");
								break;
							case -1:
								str = this.Main.Rm.GetString("TM1") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -2:
								str = this.Main.Rm.GetString("TM2") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -3:
								str = this.Main.Rm.GetString("DigitalSignal") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -4:
								str = this.Main.Rm.GetString("JawOpen") + " " + this.Main.Rm.GetString("Negative");
								break;
							case -5:
								str = this.Main.Rm.GetString("SyncSignal") + "2 " + this.Main.Rm.GetString("Negative");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text2 = str;
							break;
						}
						case 201106u:
						{
							string str;
							switch ((int)logMessageStruct.Value1)
							{
							case 1:
								str = this.Main.Rm.GetString("TM1") + " (" + this.Main.Rm.GetString("Positive") + ")";
								break;
							case -1:
								str = this.Main.Rm.GetString("TM1") + " (" + this.Main.Rm.GetString("Negative") + ")";
								break;
							case 2:
								str = this.Main.Rm.GetString("TM2") + " (" + this.Main.Rm.GetString("Positive") + ")";
								break;
							case -2:
								str = this.Main.Rm.GetString("TM2") + " (" + this.Main.Rm.GetString("Negative") + ")";
								break;
							case 3:
								str = this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("Positive") + ")";
								break;
							case -3:
								str = this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("Negative") + ")";
								break;
							case 4:
								str = this.Main.Rm.GetString("JawOpen") + " (" + this.Main.Rm.GetString("Positive") + ")";
								break;
							case -4:
								str = this.Main.Rm.GetString("JawOpen") + " (" + this.Main.Rm.GetString("Negative") + ")";
								break;
							case 5:
								str = this.Main.Rm.GetString("SyncSignal") + "2 (" + this.Main.Rm.GetString("Positive") + ")";
								break;
							case -5:
								str = this.Main.Rm.GetString("SyncSignal") + "2 (" + this.Main.Rm.GetString("Negative") + ")";
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text4 = this.Main.Rm.GetString("DigitalSignal");
							text = str;
							switch ((int)logMessageStruct.Value2)
							{
							case 1:
								str = this.Main.Rm.GetString("TM1") + " (" + this.Main.Rm.GetString("Positive") + ")";
								break;
							case -1:
								str = this.Main.Rm.GetString("TM1") + " (" + this.Main.Rm.GetString("Negative") + ")";
								break;
							case 2:
								str = this.Main.Rm.GetString("TM2") + " (" + this.Main.Rm.GetString("Positive") + ")";
								break;
							case -2:
								str = this.Main.Rm.GetString("TM2") + " (" + this.Main.Rm.GetString("Negative") + ")";
								break;
							case 3:
								str = this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("Positive") + ")";
								break;
							case -3:
								str = this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("Negative") + ")";
								break;
							case 4:
								str = this.Main.Rm.GetString("JawOpen") + " (" + this.Main.Rm.GetString("Positive") + ")";
								break;
							case -4:
								str = this.Main.Rm.GetString("JawOpen") + " (" + this.Main.Rm.GetString("Negative") + ")";
								break;
							case 5:
								str = this.Main.Rm.GetString("SyncSignal") + "2 (" + this.Main.Rm.GetString("Positive") + ")";
								break;
							case -5:
								str = this.Main.Rm.GetString("SyncSignal") + "2 (" + this.Main.Rm.GetString("Negative") + ")";
								break;
							default:
								this.Main.Rm.GetString("NoSelection");
								break;
							}
							text2 = str;
							break;
						}
						case 201107u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("AnaDepth");
							break;
						case 201108u:
						{
							string str;
							switch ((int)logMessageStruct.Value1)
							{
							case 0:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							case 1:
								str = this.Main.Rm.GetString("DigSigAtEnd");
								break;
							case 2:
								str = this.Main.Rm.GetString("DigSigRunning");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text4 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("Max") + ")";
							text = str;
							switch ((int)logMessageStruct.Value2)
							{
							case 0:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							case 1:
								str = this.Main.Rm.GetString("DigSigAtEnd");
								break;
							case 2:
								str = this.Main.Rm.GetString("DigSigRunning");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text2 = str;
							break;
						}
						case 201109u:
						{
							string str;
							switch ((int)logMessageStruct.Value1)
							{
							case 0:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							case 1:
								str = this.Main.Rm.GetString("DigSigAtEnd");
								break;
							case 2:
								str = this.Main.Rm.GetString("DigSigRunning");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text4 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("Min") + ")";
							text = str;
							switch ((int)logMessageStruct.Value2)
							{
							case 0:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							case 1:
								str = this.Main.Rm.GetString("DigSigAtEnd");
								break;
							case 2:
								str = this.Main.Rm.GetString("DigSigRunning");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text2 = str;
							break;
						}
						case 201110u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("AnaSignal");
							break;
						case 201111u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Angle");
							break;
						case 201112u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("FilteredTorque");
							break;
						case 201113u:
						{
							string str;
							switch ((int)logMessageStruct.Value1)
							{
							case 0:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							case 1:
								str = this.Main.Rm.GetString("DigSigAtEnd");
								break;
							case 2:
								str = this.Main.Rm.GetString("DigSigRunning");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text4 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("Min") + ")";
							text = str;
							switch ((int)logMessageStruct.Value2)
							{
							case 0:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							case 1:
								str = this.Main.Rm.GetString("DigSigAtEnd");
								break;
							case 2:
								str = this.Main.Rm.GetString("DigSigRunning");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text2 = str;
							break;
						}
						case 201114u:
						{
							string str;
							switch ((int)logMessageStruct.Value1)
							{
							case 0:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							case 1:
								str = this.Main.Rm.GetString("DigSigAtEnd");
								break;
							case 2:
								str = this.Main.Rm.GetString("DigSigRunning");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text4 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("Max") + ")";
							text = str;
							switch ((int)logMessageStruct.Value2)
							{
							case 0:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							case 1:
								str = this.Main.Rm.GetString("DigSigAtEnd");
								break;
							case 2:
								str = this.Main.Rm.GetString("DigSigRunning");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text2 = str;
							break;
						}
						case 201115u:
							text6 = this.Main.Rm.GetString("Release");
							break;
						case 201116u:
							text6 = this.Main.Rm.GetString("TreshTorque");
							break;
						case 201117u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("StepTmin");
							break;
						case 201118u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Torque");
							break;
						case 201119u:
							text6 = this.Main.Rm.GetString("Result") + "1";
							break;
						case 201120u:
							text6 = this.Main.Rm.GetString("Result") + "2";
							break;
						case 201121u:
							text6 = this.Main.Rm.GetString("Result") + "3";
							break;
						case 201153u:
							text6 = this.Main.Rm.GetString("UserRights");
							break;
						case 201122u:
							text6 = this.Main.Rm.GetString("JumpTo") + ": " + this.Main.Rm.GetString("Step");
							break;
						case 201123u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("Max") + ")";
							break;
						case 201124u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("Min") + ")";
							break;
						case 201125u:
							text6 = this.Main.Rm.GetString("DepthGrad");
							break;
						case 201126u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("L+") + ")";
							break;
						case 201127u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("L-") + ")";
							break;
						case 201128u:
							text6 = this.Main.Rm.GetString("AnaDepth");
							break;
						case 201129u:
							text6 = this.Main.Rm.GetString("MDelay");
							break;
						case 201130u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("MF+") + ")";
							break;
						case 201131u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("MF-") + ")";
							break;
						case 201132u:
							text6 = this.Main.Rm.GetString("FilteredTorque");
							break;
						case 201133u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("Max") + ")";
							break;
						case 201134u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("Min") + ")";
							break;
						case 201135u:
							text6 = this.Main.Rm.GetString("Gradient");
							break;
						case 201136u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("M+") + ")";
							break;
						case 201137u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("M-") + ")";
							break;
						case 201138u:
						{
							num6 = (int)logMessageStruct.Value1;
							string str;
							switch (num6)
							{
							case 1:
								str = this.Main.Rm.GetString("DigitOut") + "1: " + this.Main.Rm.GetString("SetOn");
								break;
							case -1:
								str = this.Main.Rm.GetString("DigitOut") + "1: " + this.Main.Rm.GetString("SetOff");
								break;
							case 2:
								str = this.Main.Rm.GetString("DigitOut") + "2: " + this.Main.Rm.GetString("SetOn");
								break;
							case -2:
								str = this.Main.Rm.GetString("DigitOut") + "2: " + this.Main.Rm.GetString("SetOff");
								break;
							case 3:
								str = this.Main.Rm.GetString("JawOpen") + ": " + this.Main.Rm.GetString("SetOn");
								break;
							case -3:
								str = this.Main.Rm.GetString("JawOpen") + ": " + this.Main.Rm.GetString("SetOff");
								break;
							case 4:
								str = this.Main.Rm.GetString("SyncOut") + "2: " + this.Main.Rm.GetString("SetOn");
								break;
							case -4:
								str = this.Main.Rm.GetString("SyncOut") + "2: " + this.Main.Rm.GetString("SetOff");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text4 = this.Main.Rm.GetString("SetDigOut");
							text = str;
							num6 = (int)logMessageStruct.Value2;
							switch (num6)
							{
							case 1:
								str = this.Main.Rm.GetString("DigitOut") + "1: " + this.Main.Rm.GetString("SetOn");
								break;
							case -1:
								str = this.Main.Rm.GetString("DigitOut") + "1: " + this.Main.Rm.GetString("SetOff");
								break;
							case 2:
								str = this.Main.Rm.GetString("DigitOut") + "2: " + this.Main.Rm.GetString("SetOn");
								break;
							case -2:
								str = this.Main.Rm.GetString("DigitOut") + "2: " + this.Main.Rm.GetString("SetOff");
								break;
							case 3:
								str = this.Main.Rm.GetString("JawOpen") + ": " + this.Main.Rm.GetString("SetOn");
								break;
							case -3:
								str = this.Main.Rm.GetString("JawOpen") + ": " + this.Main.Rm.GetString("SetOff");
								break;
							case 4:
								str = this.Main.Rm.GetString("SyncOut") + "2: " + this.Main.Rm.GetString("SetOn");
								break;
							case -4:
								str = this.Main.Rm.GetString("SyncOut") + "2: " + this.Main.Rm.GetString("SetOff");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text2 = str;
							break;
						}
						case 201140u:
							text6 = this.Main.Rm.GetString("Torque");
							break;
						case 201141u:
							text6 = this.Main.Rm.GetString("RelativeTorque");
							break;
						case 201142u:
							text6 = this.Main.Rm.GetString("RelativeTorque") + ": " + this.Main.Rm.GetString("OfStep");
							break;
						case 201143u:
							text6 = this.Main.Rm.GetString("RelativeTorque") + ": " + this.Main.Rm.GetString("relatedTo");
							break;
						case 201144u:
							text6 = this.Main.Rm.GetString("TreshTorque");
							break;
						case 201145u:
							text6 = this.Main.Rm.GetString("RoundsPerMinute");
							break;
						case 201146u:
						{
							num6 = (int)logMessageStruct.Value1;
							string str;
							switch (num6)
							{
							case 1:
								str = this.Main.Rm.GetString("Torque");
								break;
							case 3:
								str = this.Main.Rm.GetString("FilteredTorque");
								break;
							case 2:
								str = this.Main.Rm.GetString("RelativeTorque");
								break;
							case 11:
								str = this.Main.Rm.GetString("M360Follow");
								break;
							case 4:
								str = this.Main.Rm.GetString("Gradient");
								break;
							case 5:
								str = this.Main.Rm.GetString("Angle");
								break;
							case 6:
								str = this.Main.Rm.GetString("Time");
								break;
							case 7:
								str = this.Main.Rm.GetString("AnaDepth");
								break;
							case 10:
								str = this.Main.Rm.GetString("DepthGrad");
								break;
							case 8:
								str = this.Main.Rm.GetString("AnaSignal");
								break;
							case 9:
								str = this.Main.Rm.GetString("DigitalSignal");
								break;
							case 50:
								str = this.Main.Rm.GetString("Torque") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
								break;
							case 51:
								str = this.Main.Rm.GetString("FilteredTorque") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
								break;
							case 52:
								str = this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
								break;
							case 53:
								str = this.Main.Rm.GetString("AnaDepth") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
								break;
							case 55:
								str = this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
								break;
							case 54:
								str = this.Main.Rm.GetString("AnaSignal") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
								break;
							case 1000:
								str = this.Main.Rm.GetString("JumpOkTo");
								break;
							case 1001:
								str = this.Main.Rm.GetString("JumpNokTo");
								break;
							case 1002:
								str = this.Main.Rm.GetString("JumpAlwaysTo");
								break;
							case 1010:
								str = this.Main.Rm.GetString("Stop");
								break;
							case 1011:
								str = this.Main.Rm.GetString("StopOk");
								break;
							case 1012:
								str = this.Main.Rm.GetString("StopNok");
								break;
							case 1020:
								str = this.Main.Rm.GetString("ResetAngle");
								break;
							case 1030:
								str = this.Main.Rm.GetString("SetDigOut");
								break;
							case 1040:
								str = this.Main.Rm.GetString("ResetADepth");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text4 = this.Main.Rm.GetString("Target");
							text = str;
							num6 = (int)logMessageStruct.Value2;
							switch (num6)
							{
							case 1:
								str = this.Main.Rm.GetString("Torque");
								break;
							case 3:
								str = this.Main.Rm.GetString("FilteredTorque");
								break;
							case 2:
								str = this.Main.Rm.GetString("RelativeTorque");
								break;
							case 11:
								str = this.Main.Rm.GetString("M360Follow");
								break;
							case 4:
								str = this.Main.Rm.GetString("Gradient");
								break;
							case 5:
								str = this.Main.Rm.GetString("Angle");
								break;
							case 6:
								str = this.Main.Rm.GetString("Time");
								break;
							case 7:
								str = this.Main.Rm.GetString("AnaDepth");
								break;
							case 10:
								str = this.Main.Rm.GetString("DepthGrad");
								break;
							case 8:
								str = this.Main.Rm.GetString("AnaSignal");
								break;
							case 9:
								str = this.Main.Rm.GetString("DigitalSignal");
								break;
							case 50:
								str = this.Main.Rm.GetString("Torque") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
								break;
							case 51:
								str = this.Main.Rm.GetString("FilteredTorque") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
								break;
							case 52:
								str = this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
								break;
							case 53:
								str = this.Main.Rm.GetString("AnaDepth") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
								break;
							case 55:
								str = this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
								break;
							case 54:
								str = this.Main.Rm.GetString("AnaSignal") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
								break;
							case 1000:
								str = this.Main.Rm.GetString("JumpOkTo");
								break;
							case 1001:
								str = this.Main.Rm.GetString("JumpNokTo");
								break;
							case 1002:
								str = this.Main.Rm.GetString("JumpAlwaysTo");
								break;
							case 1010:
								str = this.Main.Rm.GetString("Stop");
								break;
							case 1011:
								str = this.Main.Rm.GetString("StopOk");
								break;
							case 1012:
								str = this.Main.Rm.GetString("StopNok");
								break;
							case 1020:
								str = this.Main.Rm.GetString("ResetAngle");
								break;
							case 1030:
								str = this.Main.Rm.GetString("SetDigOut");
								break;
							case 1040:
								str = this.Main.Rm.GetString("ResetADepth");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text2 = str;
							break;
						}
						case 201147u:
							text6 = this.Main.Rm.GetString("Ramp");
							break;
						case 201148u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("T+") + ")";
							break;
						case 201149u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("T-") + ")";
							break;
						case 201150u:
							text6 = this.Main.Rm.GetString("TN");
							break;
						case 201151u:
							text6 = this.Main.Rm.GetString("Time");
							break;
						case 201154u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Max") + "(" + this.Main.Rm.GetString("W+") + ")";
							break;
						case 201155u:
							text6 = this.Main.Rm.GetString("MCheckParameter") + ": " + this.Main.Rm.GetString("Min") + "(" + this.Main.Rm.GetString("W-") + ")";
							break;
						case 201156u:
							text6 = this.Main.Rm.GetString("WN");
							break;
						case 201157u:
							text6 = this.Main.Rm.GetString("Angle");
							break;
						case 201200u:
						{
							num6 = (int)logMessageStruct.Value1;
							string str;
							switch (num6)
							{
							case 1:
								str = this.Main.Rm.GetString("Torque");
								break;
							case 2:
								str = this.Main.Rm.GetString("MaxTorque");
								break;
							case 3:
								str = this.Main.Rm.GetString("FilteredTorque");
								break;
							case 4:
								str = this.Main.Rm.GetString("Gradient");
								break;
							case 5:
								str = this.Main.Rm.GetString("Angle");
								break;
							case 6:
								str = this.Main.Rm.GetString("Time");
								break;
							case 7:
								str = this.Main.Rm.GetString("AnaDepth");
								break;
							case 9:
								str = this.Main.Rm.GetString("DigitalSignal");
								break;
							case 12:
								str = this.Main.Rm.GetString("DepthGrad");
								break;
							case 10:
								str = this.Main.Rm.GetString("DelayTorque");
								break;
							case 11:
								str = this.Main.Rm.GetString("M360Follow");
								break;
							case 8:
								str = this.Main.Rm.GetString("AnaSignal");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text5 = this.Main.Rm.GetString("Result") + "1";
							text = str;
							num6 = (int)logMessageStruct.Value2;
							switch (num6)
							{
							case 1:
								str = this.Main.Rm.GetString("Torque");
								break;
							case 2:
								str = this.Main.Rm.GetString("MaxTorque");
								break;
							case 3:
								str = this.Main.Rm.GetString("FilteredTorque");
								break;
							case 4:
								str = this.Main.Rm.GetString("Gradient");
								break;
							case 5:
								str = this.Main.Rm.GetString("Angle");
								break;
							case 6:
								str = this.Main.Rm.GetString("Time");
								break;
							case 7:
								str = this.Main.Rm.GetString("AnaDepth");
								break;
							case 9:
								str = this.Main.Rm.GetString("DigitalSignal");
								break;
							case 12:
								str = this.Main.Rm.GetString("DepthGrad");
								break;
							case 10:
								str = this.Main.Rm.GetString("DelayTorque");
								break;
							case 11:
								str = this.Main.Rm.GetString("M360Follow");
								break;
							case 8:
								str = this.Main.Rm.GetString("AnaSignal");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text2 = str;
							break;
						}
						case 201201u:
						{
							num6 = (int)logMessageStruct.Value1;
							string str;
							switch (num6)
							{
							case 1:
								str = this.Main.Rm.GetString("Torque");
								break;
							case 2:
								str = this.Main.Rm.GetString("MaxTorque");
								break;
							case 3:
								str = this.Main.Rm.GetString("FilteredTorque");
								break;
							case 4:
								str = this.Main.Rm.GetString("Gradient");
								break;
							case 5:
								str = this.Main.Rm.GetString("Angle");
								break;
							case 6:
								str = this.Main.Rm.GetString("Time");
								break;
							case 7:
								str = this.Main.Rm.GetString("AnaDepth");
								break;
							case 9:
								str = this.Main.Rm.GetString("DigitalSignal");
								break;
							case 12:
								str = this.Main.Rm.GetString("DepthGrad");
								break;
							case 10:
								str = this.Main.Rm.GetString("DelayTorque");
								break;
							case 11:
								str = this.Main.Rm.GetString("M360Follow");
								break;
							case 8:
								str = this.Main.Rm.GetString("AnaSignal");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text5 = this.Main.Rm.GetString("Result") + "2";
							text = str;
							num6 = (int)logMessageStruct.Value2;
							switch (num6)
							{
							case 1:
								str = this.Main.Rm.GetString("Torque");
								break;
							case 2:
								str = this.Main.Rm.GetString("MaxTorque");
								break;
							case 3:
								str = this.Main.Rm.GetString("FilteredTorque");
								break;
							case 4:
								str = this.Main.Rm.GetString("Gradient");
								break;
							case 5:
								str = this.Main.Rm.GetString("Angle");
								break;
							case 6:
								str = this.Main.Rm.GetString("Time");
								break;
							case 7:
								str = this.Main.Rm.GetString("AnaDepth");
								break;
							case 9:
								str = this.Main.Rm.GetString("DigitalSignal");
								break;
							case 12:
								str = this.Main.Rm.GetString("DepthGrad");
								break;
							case 10:
								str = this.Main.Rm.GetString("DelayTorque");
								break;
							case 11:
								str = this.Main.Rm.GetString("M360Follow");
								break;
							case 8:
								str = this.Main.Rm.GetString("AnaSignal");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text2 = str;
							break;
						}
						case 201202u:
						{
							num6 = (int)logMessageStruct.Value1;
							string str;
							switch (num6)
							{
							case 1:
								str = this.Main.Rm.GetString("Torque");
								break;
							case 2:
								str = this.Main.Rm.GetString("MaxTorque");
								break;
							case 3:
								str = this.Main.Rm.GetString("FilteredTorque");
								break;
							case 4:
								str = this.Main.Rm.GetString("Gradient");
								break;
							case 5:
								str = this.Main.Rm.GetString("Angle");
								break;
							case 6:
								str = this.Main.Rm.GetString("Time");
								break;
							case 7:
								str = this.Main.Rm.GetString("AnaDepth");
								break;
							case 9:
								str = this.Main.Rm.GetString("DigitalSignal");
								break;
							case 12:
								str = this.Main.Rm.GetString("DepthGrad");
								break;
							case 10:
								str = this.Main.Rm.GetString("DelayTorque");
								break;
							case 11:
								str = this.Main.Rm.GetString("M360Follow");
								break;
							case 8:
								str = this.Main.Rm.GetString("AnaSignal");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text5 = this.Main.Rm.GetString("Result") + "3";
							text = str;
							num6 = (int)logMessageStruct.Value2;
							switch (num6)
							{
							case 1:
								str = this.Main.Rm.GetString("Torque");
								break;
							case 2:
								str = this.Main.Rm.GetString("MaxTorque");
								break;
							case 3:
								str = this.Main.Rm.GetString("FilteredTorque");
								break;
							case 4:
								str = this.Main.Rm.GetString("Gradient");
								break;
							case 5:
								str = this.Main.Rm.GetString("Angle");
								break;
							case 6:
								str = this.Main.Rm.GetString("Time");
								break;
							case 7:
								str = this.Main.Rm.GetString("AnaDepth");
								break;
							case 9:
								str = this.Main.Rm.GetString("DigitalSignal");
								break;
							case 12:
								str = this.Main.Rm.GetString("DepthGrad");
								break;
							case 10:
								str = this.Main.Rm.GetString("DelayTorque");
								break;
							case 11:
								str = this.Main.Rm.GetString("M360Follow");
								break;
							case 8:
								str = this.Main.Rm.GetString("AnaSignal");
								break;
							default:
								str = this.Main.Rm.GetString("NoSelection");
								break;
							}
							text2 = str;
							break;
						}
						case 201203u:
							text6 = this.Main.Rm.GetString("GradFilter");
							break;
						case 201204u:
							text6 = this.Main.Rm.GetString("GradientLength");
							break;
						case 201205u:
							text6 = this.Main.Rm.GetString("M1FilterTime");
							break;
						case 201223u:
							text6 = this.Main.Rm.GetString("DepthGradLength");
							break;
						case 201224u:
							text6 = this.Main.Rm.GetString("DepthFilterTime");
							break;
						case 201158u:
							text6 = this.Main.Rm.GetString("PressureSpindle");
							break;
						case 201206u:
							text6 = this.Main.Rm.GetString("StepTplus");
							break;
						case 201225u:
							text6 = this.Main.Rm.GetString("Holder") + " " + this.Main.Rm.GetString("Pressure");
							break;
						case 201207u:
							if ((int)logMessageStruct.Value1 == 1)
							{
								text5 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("AnaSignal");
								text = this.Main.Rm.GetString("No");
								text2 = this.Main.Rm.GetString("Yes");
							}
							else
							{
								text5 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("AnaSignal");
								text = this.Main.Rm.GetString("Yes");
								text2 = this.Main.Rm.GetString("No");
							}
							break;
						case 201208u:
							if ((int)logMessageStruct.Value1 == 1)
							{
								text5 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("DigitalSignal") + "1: ";
								text = this.Main.Rm.GetString("No");
								text2 = this.Main.Rm.GetString("Yes");
							}
							else
							{
								text5 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("DigitalSignal") + "1: ";
								text = this.Main.Rm.GetString("Yes");
								text2 = this.Main.Rm.GetString("No");
							}
							break;
						case 201209u:
							if ((int)logMessageStruct.Value1 == 1)
							{
								text5 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("DigitalSignal") + "2: ";
								text = this.Main.Rm.GetString("No");
								text2 = this.Main.Rm.GetString("Yes");
							}
							else
							{
								text5 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("DigitalSignal") + "2: ";
								text = this.Main.Rm.GetString("Yes");
								text2 = this.Main.Rm.GetString("No");
							}
							break;
						case 201210u:
							if ((int)logMessageStruct.Value1 == 1)
							{
								text5 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("JawOpen") + ": ";
								text = this.Main.Rm.GetString("No");
								text2 = this.Main.Rm.GetString("Yes");
							}
							else
							{
								text5 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("JawOpen") + ": ";
								text = this.Main.Rm.GetString("Yes");
								text2 = this.Main.Rm.GetString("No");
							}
							break;
						case 201211u:
							if ((int)logMessageStruct.Value1 == 1)
							{
								text5 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("SyncSignal") + "2: ";
								text = this.Main.Rm.GetString("No");
								text2 = this.Main.Rm.GetString("Yes");
							}
							else
							{
								text5 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("SyncSignal") + "2: ";
								text = this.Main.Rm.GetString("Yes");
								text2 = this.Main.Rm.GetString("No");
							}
							break;
						case 201212u:
							text6 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("AnaSignal");
							break;
						case 201213u:
							text6 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("DigitalSignal") + "2";
							break;
						case 201214u:
							text6 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("DigitalSignal") + "2";
							break;
						case 201215u:
							text6 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("JawOpen");
							break;
						case 201216u:
							text6 = this.Main.Rm.GetString("ForceSignals") + ": " + this.Main.Rm.GetString("SyncSignal") + "2";
							break;
						case 207000u:
							text3 = this.Main.Rm.GetString("Program") + " " + logMessageStruct.ProgNum.ToString("f0") + ", " + this.Main.Rm.GetString("ProgramChange" + logMessageStruct.Code.ToString());
							if ((int)logMessageStruct.Value1 == 1)
							{
								text = this.Main.Rm.GetString("Yes");
								text2 = this.Main.Rm.GetString("No");
							}
							else
							{
								text = this.Main.Rm.GetString("No");
								text2 = this.Main.Rm.GetString("Yes");
							}
							break;
						case 207001u:
							text3 = this.Main.Rm.GetString("Program") + " " + logMessageStruct.ProgNum.ToString("f0") + ", " + this.Main.Rm.GetString("ProgramChange" + logMessageStruct.Code.ToString());
							text = logMessageStruct.Value1.ToString();
							text2 = logMessageStruct.Value2.ToString();
							break;
						case 207003u:
							text3 = this.Main.Rm.GetString("Program") + " " + logMessageStruct.ProgNum.ToString("f0") + ", " + this.Main.Rm.GetString("ProgramChange" + logMessageStruct.Code.ToString());
							text = logMessageStruct.Value1.ToString();
							text2 = logMessageStruct.Value2.ToString();
							break;
						case 201159u:
							text3 = this.Main.Rm.GetString("loggingProgramsConverted");
							text = " ";
							text2 = logMessageStruct.Value2.ToString();
							break;
						case 201003u:
							text3 = this.Main.Rm.GetString("Program") + " " + logMessageStruct.ProgNum.ToString("f0") + ", " + this.Main.Rm.GetString("ProgramChange" + logMessageStruct.Code.ToString());
							break;
						default:
							text3 = this.Main.Rm.GetString("Program") + " " + logMessageStruct.ProgNum.ToString("f0") + ", " + this.Main.Rm.GetString("ProgramChange" + logMessageStruct.Code.ToString());
							break;
						}
						if (text6 != string.Empty)
						{
							text3 = this.Main.Rm.GetString("Program") + " " + progNum.ToString() + ", " + this.Main.Rm.GetString("Step") + num7.ToString() + ", " + text6;
							text = logMessageStruct.Value1.ToString();
							text2 = logMessageStruct.Value2.ToString();
							text6 = string.Empty;
						}
						if (text4 != string.Empty)
						{
							text3 = this.Main.Rm.GetString("Program") + " " + progNum.ToString() + ", " + this.Main.Rm.GetString("Step") + num7.ToString() + ", " + text4;
							text4 = string.Empty;
						}
						if (text5 != string.Empty)
						{
							text3 = this.Main.Rm.GetString("Program") + " " + progNum.ToString() + ", " + text5;
							text5 = string.Empty;
						}
						break;
					}
					case 3:
						switch (logMessageStruct.Code)
						{
						case 202012u:
							text3 = this.Main.Rm.GetString("SysChange" + logMessageStruct.Code.ToString());
							break;
						case 202013u:
							text3 = this.Main.Rm.GetString("SysChange" + logMessageStruct.Code.ToString());
							break;
						case 202018u:
						case 202019u:
						case 202050u:
							text3 = this.Main.Rm.GetString("SysChange" + logMessageStruct.Code.ToString());
							break;
						case 202017u:
						{
							num6 = (int)logMessageStruct.Value1;
							string text8;
							switch (num6)
							{
							case 0:
								text8 = this.Main.Rm.GetString("NoParity");
								break;
							case 1:
								text8 = this.Main.Rm.GetString("Odd");
								break;
							case 2:
								text8 = this.Main.Rm.GetString("Even");
								break;
							default:
								text8 = "NO_PARITY";
								break;
							}
							num6 = (int)logMessageStruct.Value2;
							string text9;
							switch (num6)
							{
							case 0:
								text9 = this.Main.Rm.GetString("NoParity");
								break;
							case 1:
								text9 = this.Main.Rm.GetString("Odd");
								break;
							case 2:
								text9 = this.Main.Rm.GetString("Even");
								break;
							default:
								text9 = "NO_PARITY";
								break;
							}
							text3 = this.Main.Rm.GetString("SysChange" + logMessageStruct.Code.ToString());
							text2 = text9;
							text = text8;
							break;
						}
						case 202014u:
						{
							num6 = (int)logMessageStruct.Value1;
							string @string;
							switch (num6)
							{
							case 0:
								@string = this.Main.Rm.GetString("TorqueNm");
								break;
							case 1:
								@string = this.Main.Rm.GetString("TorqueNcm");
								break;
							case 2:
								@string = this.Main.Rm.GetString("Torqueinlb");
								break;
							case 3:
								@string = this.Main.Rm.GetString("Torqueftlb");
								break;
							case 4:
								@string = this.Main.Rm.GetString("Torqueinoz");
								break;
							case 5:
								@string = this.Main.Rm.GetString("Torquekgm");
								break;
							case 6:
								@string = this.Main.Rm.GetString("Torquekgcm");
								break;
							default:
								@string = this.Main.Rm.GetString("TorqueNm");
								break;
							}
							num6 = (int)logMessageStruct.Value2;
							string string2;
							switch (num6)
							{
							case 0:
								string2 = this.Main.Rm.GetString("TorqueNm");
								break;
							case 1:
								string2 = this.Main.Rm.GetString("TorqueNcm");
								break;
							case 2:
								string2 = this.Main.Rm.GetString("Torqueinlb");
								break;
							case 3:
								string2 = this.Main.Rm.GetString("Torqueftlb");
								break;
							case 4:
								string2 = this.Main.Rm.GetString("Torqueinoz");
								break;
							case 5:
								string2 = this.Main.Rm.GetString("Torquekgm");
								break;
							case 6:
								string2 = this.Main.Rm.GetString("Torquekgcm");
								break;
							default:
								string2 = this.Main.Rm.GetString("TorqueNm");
								break;
							}
							text3 = this.Main.Rm.GetString("SysChange" + logMessageStruct.Code.ToString());
							text = @string;
							text2 = string2;
							break;
						}
						case 202015u:
							text3 = this.Main.Rm.GetString("SysChange" + logMessageStruct.Code.ToString());
							break;
						default:
							text3 = this.Main.Rm.GetString("SysChange" + logMessageStruct.Code.ToString());
							text2 = logMessageStruct.Value2.ToString();
							text = logMessageStruct.Value1.ToString();
							break;
						}
						break;
					case 4:
						switch (logMessageStruct.Code)
						{
						case 203003u:
						case 203004u:
						case 203005u:
						case 203009u:
						case 203012u:
						case 203020u:
						case 203021u:
						{
							string str = "";
							num6 = (int)logMessageStruct.Value1;
							switch (num6)
							{
							case 0:
								str += this.Main.Rm.GetString("SetOff");
								break;
							case 1:
								str += this.Main.Rm.GetString("SetOn");
								break;
							default:
								str += this.Main.Rm.GetString("SetOff");
								break;
							}
							text = str;
							str = "";
							num6 = (int)logMessageStruct.Value2;
							switch (num6)
							{
							case 0:
								str += this.Main.Rm.GetString("SetOff");
								break;
							case 1:
								str += this.Main.Rm.GetString("SetOn");
								break;
							default:
								str += this.Main.Rm.GetString("SetOff");
								break;
							}
							text2 = str;
							text3 = this.Main.Rm.GetString("SpChange" + logMessageStruct.Code.ToString());
							break;
						}
						case 203030u:
							text3 = this.Main.Rm.GetString("SpChange" + logMessageStruct.Code.ToString());
							break;
						default:
							text3 = this.Main.Rm.GetString("SpChange" + logMessageStruct.Code.ToString());
							text = logMessageStruct.Value1.ToString();
							text2 = logMessageStruct.Value2.ToString();
							break;
						}
						break;
					case 5:
						text3 = this.Main.Rm.GetString("StatDelete" + logMessageStruct.Code.ToString());
						text = logMessageStruct.Value1.ToString();
						text2 = logMessageStruct.Value2.ToString();
						break;
					case 6:
						switch (logMessageStruct.Code)
						{
						case 206001u:
							text3 = this.Main.Rm.GetString("UserLoggedIn");
							if (logMessageStruct.Value2 > 0f)
							{
								text2 = this.Main.Rm.GetString(this.Main.C_global.GetAccessLevelDefinition((int)logMessageStruct.Value2 - 1));
							}
							break;
						case 206002u:
							text3 = this.Main.Rm.GetString("UserLoggedOut");
							if (logMessageStruct.Value2 > 0f)
							{
								text = this.Main.Rm.GetString(this.Main.C_global.GetAccessLevelDefinition((int)logMessageStruct.Value2 - 1));
							}
							break;
						case 205004u:
							text3 = this.Main.Rm.GetString("Backup205004");
							if (logMessageStruct.Value1 > 0f)
							{
								text2 = logMessageStruct.Value1.ToString();
							}
							break;
						case 205005u:
							text3 = this.Main.Rm.GetString("Backup205005");
							if (logMessageStruct.Value1 > 0f)
							{
								text2 = logMessageStruct.Value1.ToString();
							}
							break;
						case 205006u:
							text3 = this.Main.Rm.GetString("Backup205006");
							if (logMessageStruct.Value1 > 0f)
							{
								text2 = logMessageStruct.Value1.ToString();
							}
							break;
						case 205007u:
							text3 = this.Main.Rm.GetString("Backup205007");
							if (logMessageStruct.Value1 > 0f)
							{
								text2 = logMessageStruct.Value1.ToString();
							}
							break;
						case 205008u:
							text3 = this.Main.Rm.GetString("Backup205008");
							if (logMessageStruct.Value1 > 0f)
							{
								text2 = logMessageStruct.Value1.ToString();
							}
							break;
						case 205009u:
							text3 = this.Main.Rm.GetString("Backup205009");
							if (logMessageStruct.Value1 > 0f)
							{
								text2 = logMessageStruct.Value1.ToString();
							}
							break;
						default:
							text3 = this.Main.Rm.GetString("Backup" + logMessageStruct.Code.ToString());
							break;
						}
						break;
					case 0:
						text3 = this.Main.Rm.GetString("LogBookMessage" + logMessageStruct.Code.ToString());
						text = "0";
						text2 = "1";
						break;
					default:
						text3 = string.Empty;
						break;
					}
					this.LogData.Rows[num4][this.ColumnName[2]] = text3;
					this.LogData.Rows[num4][this.ColumnName[3]] = text2;
					sizeF = graphics.MeasureString(text2 + "A", this.LogGrid.Font);
					num5 = (int)Math.Ceiling((double)sizeF.Width);
					if (num5 > array[3])
					{
						array[3] = num5;
					}
					this.LogData.Rows[num4][this.ColumnName[4]] = text;
					sizeF = graphics.MeasureString(text + "A", this.LogGrid.Font);
					num5 = (int)Math.Ceiling((double)sizeF.Width);
					if (num5 > array[4])
					{
						array[4] = num5;
					}
					string text10 = "";
					switch (logMessageStruct.UnitIndex)
					{
					case 20:
						text10 = this.Main.Rm.GetString("Degree");
						break;
					case 21:
						text10 = this.Main.Rm.GetString("Second");
						break;
					case 22:
						text10 = this.Main.Rm.GetString("Milimeter");
						break;
					case 23:
						text10 = this.Main.Rm.GetString("RpmUnit");
						break;
					case 24:
						text10 = this.Main.Rm.GetString("Voltage");
						break;
					case 25:
						text10 = this.Main.Rm.GetString("Percent");
						break;
					case 26:
						text10 = this.Main.Rm.GetString("Milisecond");
						break;
					case 27:
						text10 = this.Main.Rm.GetString("Increment");
						break;
					case 28:
						text10 = this.Main.Rm.GetString("Degree") + "/" + this.Main.Rm.GetString("Increment");
						break;
					case 1:
						text10 = this.Main.Rm.GetString("Degree");
						break;
					case 29:
						text10 = this.Main.Rm.GetString("TorqueNm");
						break;
					case 30:
						text10 = this.Main.Rm.GetString("TorqueNcm");
						break;
					case 31:
						text10 = this.Main.Rm.GetString("Torqueinlb");
						break;
					case 32:
						text10 = this.Main.Rm.GetString("Torqueftlb");
						break;
					case 33:
						text10 = this.Main.Rm.GetString("Torquekgm");
						break;
					case 34:
						text10 = this.Main.Rm.GetString("Torqueinoz");
						break;
					case 36:
						text10 = this.Main.Rm.GetString("Torquekgcm");
						break;
					case 37:
						text10 = this.Main.Rm.GetString("UnitBar");
						break;
					case 38:
						text10 = this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Voltage");
						break;
					case 39:
						text10 = "1/" + this.Main.Rm.GetString("Voltage");
						break;
					case 17:
						text10 = this.Main.Rm.GetString("KiloNewton");
						break;
					case 40:
						text10 = this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second");
						break;
					case 18:
						text10 = this.Main.Rm.GetString("Files");
						break;
					}
					this.LogData.Rows[num4][this.ColumnName[5]] = text10;
					sizeF = graphics.MeasureString(text10 ?? "", this.LogGrid.Font);
					num5 = (int)Math.Ceiling((double)sizeF.Width);
					if (num5 > array[5])
					{
						array[5] = num5;
					}
					this.LogData.Rows[num4][this.ColumnName[6]] = logMessageStruct.cycNum;
					string text11 = "A" + this.LogData.Rows[num4]["Cycle"].ToString();
					sizeF = graphics.MeasureString(text11, this.LogGrid.Font);
					num5 = (int)Math.Ceiling((double)sizeF.Width);
					if (num5 > array[6])
					{
						array[6] = num5;
					}
					string text12 = this.Main.CommonFunctions.UShortToString(logMessageStruct.userName);
					this.LogData.Rows[num4][this.ColumnName[7]] = text12;
					string text13 = "A" + text12;
					sizeF = graphics.MeasureString(text13, this.LogGrid.Font);
					num5 = (int)Math.Ceiling((double)sizeF.Width);
					if (num5 > array[7])
					{
						array[7] = num5;
					}
					num3--;
					num4++;
				}
			}
			if (array[3] > 90)
			{
				array[3] = 90;
			}
			if (array[4] > 90)
			{
				array[4] = 90;
			}
			this.LogGrid.DataSource = this.LogData;
			this.LogGrid.Columns[0].HeaderText = this.Main.Rm.GetString("AbrNumber");
			this.LogGrid.Columns[1].HeaderText = this.Main.Rm.GetString("DateTime");
			this.LogGrid.Columns[2].HeaderText = this.Main.Rm.GetString("Changed");
			this.LogGrid.Columns[3].HeaderText = this.Main.Rm.GetString("NewValue");
			this.LogGrid.Columns[4].HeaderText = this.Main.Rm.GetString("OldValue");
			this.LogGrid.Columns[5].HeaderText = this.Main.Rm.GetString("Unit");
			this.LogGrid.Columns[6].HeaderText = this.Main.Rm.GetString("Cycle");
			this.LogGrid.Columns[7].HeaderText = this.Main.Rm.GetString("User");
			this.LogGrid.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
			if (!this.fistTimeInitialiseationDone)
			{
				for (int i = 0; i < num2; i++)
				{
					switch (i)
					{
					case 2:
						array[i] = 270;
						break;
					case 3:
					case 4:
						array[i] = 60;
						break;
					default:
					{
						sizeF = graphics.MeasureString(this.LogGrid.Columns[i].HeaderText + "AA", this.LogGrid.Font);
						int num5 = (int)Math.Ceiling((double)sizeF.Width);
						if (num5 > array[i])
						{
							array[i] = num5;
						}
						break;
					}
					}
					this.LogGrid.Columns[i].Width = array[i];
				}
			}
			this.fistTimeInitialiseationDone = true;
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_2_4_Aenderungs_Liste";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_2_4_Aenderungs_Liste");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void LogChangesForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void btPrint_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else if (this.printDialog.ShowDialog() == DialogResult.OK)
			{
				this.printDocument.DefaultPageSettings.Margins.Bottom = 50;
				this.printDocument.DefaultPageSettings.Margins.Left = 50;
				this.printDocument.DefaultPageSettings.Margins.Right = 50;
				this.printDocument.DefaultPageSettings.Margins.Top = 50;
				this.printDocument.Print();
			}
		}

		private void printDocument_PrintPage(object sender, PrintPageEventArgs e)
		{
			float num = 0f;
			float num2 = 0f;
			float num3 = 0f;
			float num4 = 0f;
			int count = this.LogData.Columns.Count;
			float[] array = new float[count + 1];
			string empty = string.Empty;
			DateTime now = DateTime.Now;
			Graphics graphics = e.Graphics;
			float num5 = (float)e.MarginBounds.Left;
			float x = (float)e.MarginBounds.Right;
			float num6 = (float)e.MarginBounds.Bottom;
			float num7 = (float)e.MarginBounds.Top;
			Font font = new Font("Arial", 11f, FontStyle.Bold);
			Pen pen = new Pen(Brushes.Black);
			for (int i = 0; i < count; i++)
			{
				array[i] = (float)this.LogGrid.Columns[i].Width;
				num += array[i];
			}
			num3 = (float)e.MarginBounds.Width / num;
			Font font2 = new Font("Arial Unicode MS", 11f * num3, GraphicsUnit.Pixel);
			num = num5;
			for (int i = 0; i <= count; i++)
			{
				num4 = num;
				num += array[i] * num3;
				array[i] = num4;
			}
			num2 = num7;
			if (this.PrintPos <= 0)
			{
				empty = this.Main.Rm.GetString("ChangesLog_") + " (" + now.ToString(Settings.Default.TimeSet) + "):";
				graphics.DrawString(empty, font, Brushes.Black, new RectangleF((float)e.MarginBounds.Left, num2, (float)e.MarginBounds.Width, (float)e.MarginBounds.Bottom - num2));
				num2 += font.GetHeight();
				this.PrintPos = -1;
			}
			num7 = num2;
			num = num5;
			graphics.DrawLine(pen, num5, num2, x, num2);
			for (int i = this.PrintPos; i < this.LogData.Rows.Count; i++)
			{
				if (i == -1)
				{
					for (int j = 0; j < count; j++)
					{
						string headerText = this.LogGrid.Columns[j].HeaderText;
						graphics.DrawString(headerText, font2, Brushes.Black, array[j], num2);
					}
				}
				else
				{
					for (int j = 0; j < count; j++)
					{
						string headerText = this.LogData.Rows[i][this.ColumnName[j]].ToString();
						SizeF sizeF = default(SizeF);
						sizeF = graphics.MeasureString(headerText, font2);
						if (j == 2 && (double)array[j] < (double)sizeF.Width * 0.55)
						{
							string[] array2 = headerText.Split(' ');
							string text = "";
							string[] array3 = array2;
							foreach (string str in array3)
							{
								if ((double)array[j] < (double)graphics.MeasureString(text + str, font2).Width * 0.55)
								{
									graphics.DrawString(text, font2, Brushes.Black, array[j], num2);
									text = "";
									num2 += font2.GetHeight();
								}
								text = text + str + " ";
							}
							graphics.DrawString(text, font2, Brushes.Black, array[j], num2);
						}
						else
						{
							graphics.DrawString(headerText, font2, Brushes.Black, array[j], num2);
						}
					}
				}
				num2 += font2.GetHeight();
				graphics.DrawLine(pen, num5, num2, x, num2);
				if (num2 > num6)
				{
					if (this.LogData.Rows.Count - i > 1)
					{
						this.PrintPos = i + 1;
					}
					break;
				}
				this.PrintPos = 0;
			}
			graphics.DrawLine(pen, num, num7, num, num2);
			for (int i = 0; i <= count; i++)
			{
				graphics.DrawLine(pen, array[i], num7, array[i], num2);
			}
			font2.Dispose();
			font.Dispose();
			if (this.PrintPos > 0)
			{
				e.HasMorePages = true;
			}
		}

		private void btExport_Click(object sender, EventArgs e)
		{
			string empty = string.Empty;
			CultureInfo invariantCulture = CultureInfo.InvariantCulture;
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				DialogResult dialogResult = this.SFD.ShowDialog();
				if (dialogResult == DialogResult.OK)
				{
					try
					{
						StreamWriter streamWriter = new StreamWriter(this.SFD.FileName);
						empty = this.LogGrid.Columns[0].HeaderText;
						for (int i = 1; i < this.ColumnName.GetLength(0); i++)
						{
							empty = empty + ";" + this.LogGrid.Columns[i].HeaderText;
						}
						streamWriter.WriteLine(empty);
						for (int j = 0; j < this.LogData.Rows.Count; j++)
						{
							empty = this.LogData.Rows[j][0].ToString();
							for (int i = 1; i < this.ColumnName.GetLength(0); i++)
							{
								empty = empty + ";" + this.LogData.Rows[j][i].ToString();
							}
							streamWriter.WriteLine(empty);
						}
						streamWriter.Close();
						streamWriter.Dispose();
					}
					catch (Exception ex)
					{
						MessageBox.Show("Could not open file! " + ex.Message, "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
			}
		}

		private void LogGrid_MouseClick(object sender, MouseEventArgs e)
		{
		}

		private void btLoad_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else if (!this.Main.VC.ReceiveVarBlock(7))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive LogBookSysBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.makeDataSet();
			}
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}
	}
}
