using System;
using System.ComponentModel;
using System.Deployment.Application;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class BrowserForm : Form
	{
		private MainForm Main;

		private IContainer components;

		private bool browserFormShown;

		private Panel pnMenu;

		private WebBrowser browser;

		private string machineVisuUri;

		private Button btCancel;

		private Timer timerWeberButtonClick;

		private bool machineVisuActive;

		private bool browserNavigated;

		private Form activatedByForm;

		public bool MachineVisuActive => this.machineVisuActive;

		public bool BrowserNavigated => this.browserNavigated;

		public Form ActivatedByForm => this.activatedByForm;

		[DllImport("wininet.dll", SetLastError = true)]
		private static extern bool InternetSetOption(IntPtr hInternet, int dwOption, IntPtr lpBuffer, int lpdwBufferLength);

		public Control GetBrowserForm()
		{
			return this.browser;
		}

		public void HideMachineVisu()
		{
			this.machineVisuActive = false;
			this.pnMenu.Enabled = false;
			this.Main.SetMainText();
			base.SendToBack();
		}

		public BrowserForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			string str = "";
			try
			{
				string uriString = ApplicationDeployment.CurrentDeployment.ActivationUri.ToString();
				Uri uri = new Uri(uriString);
				str = uri.Authority;
			}
			catch (Exception)
			{
			}
			this.machineVisuUri = "http://" + str + ":8080/webvisu.htm";
			this.browser.ScriptErrorsSuppressed = true;
			this.browser.ScrollBarsEnabled = false;
			this.DoubleBuffered = true;
		}

		public void PrepareForShutDown()
		{
			OperatingSystem oSVersion = Environment.OSVersion;
			if (oSVersion.Platform == PlatformID.Win32NT && oSVersion.Version.Major == 5)
			{
				this.browser.Stop();
			}
		}

		public void ResetBrowserNavigated()
		{
			this.browserNavigated = false;
		}

		public void ResetBrowserSession()
		{
			BrowserForm.InternetSetOption(IntPtr.Zero, 42, IntPtr.Zero, 0);
		}

		public void BrowserNavigate()
		{
			if (!this.browserNavigated)
			{
				try
				{
					this.browser.Navigate(this.machineVisuUri, false);
					this.browserNavigated = true;
				}
				catch (Exception)
				{
				}
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
				this.components = null;
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(BrowserForm));
			this.pnMenu = new Panel();
			this.browser = new WebBrowser();
			this.btCancel = new Button();
			this.timerWeberButtonClick = new Timer(this.components);
			base.SuspendLayout();
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.browser.CausesValidation = false;
			this.browser.IsWebBrowserContextMenuEnabled = false;
			this.browser.Location = new Point(0, 0);
			this.browser.MinimumSize = new Size(20, 20);
			this.browser.Name = "browser";
			this.browser.ScrollBarsEnabled = false;
			this.browser.Size = new Size(792, 525);
			this.browser.TabIndex = 1;
			this.btCancel.BackColor = Color.White;
			//this.btCancel.BackgroundImage = (Image)componentResourceManager.GetObject("btCancel.BackgroundImage");
			this.btCancel.BackgroundImageLayout = ImageLayout.Stretch;
			this.btCancel.FlatStyle = FlatStyle.Flat;
			this.btCancel.Location = new Point(6, 8);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(112, 36);
			this.btCancel.TabIndex = 2;
			this.btCancel.TabStop = false;
			this.btCancel.UseVisualStyleBackColor = false;
			this.btCancel.Visible = false;
			this.btCancel.Click += this.btCancel_Click;
			this.timerWeberButtonClick.Interval = 500;
			this.timerWeberButtonClick.Tick += this.timerWeberButtonClick_Tick;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.btCancel);
			base.Controls.Add(this.browser);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.Name = "BrowserForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Machine Visu";
			base.ResumeLayout(false);
		}

		public void ShowWindow(Form parent)
		{
			if (Settings.Default.IntegratedMachineVisu)
			{
				try
				{
					if (this.Main.IsOnlineMode)
					{
						this.BrowserNavigate();
					}
					this.activatedByForm = parent;
					this.MenEna();
					base.Left = 0;
					base.BringToFront();
					base.Show();
					this.Main.SetMainText();
					this.Main.WeberLogoImage(3);
					this.Main.DoActivateMdiChild(this);
					this.browserFormShown = true;
				}
				catch (Exception ex)
				{
					MessageBox.Show("Browser Start failed:\n" + ex.Message, "Error");
				}
			}
		}

		public void SetLanguageTexts()
		{
			this.Text = "Machine Visu";
		}

		private void MenEna()
		{
			this.machineVisuActive = true;
			bool isOnlineMode = this.Main.IsOnlineMode;
		}

		private void MenuAnalysisForm_Activated(object sender, EventArgs e)
		{
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			msg.WParam.ToInt32();
			return base.ProcessCmdKey(ref msg, keyData);
		}

		public bool PreviousPage()
		{
			try
			{
				return this.browser.GoBack();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Browser Start failed:\n" + ex.Message, "Error");
				return false;
			}
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			if (!this.timerWeberButtonClick.Enabled)
			{
				this.timerWeberButtonClick.Enabled = true;
				this.browser.GoBack();
			}
			else if (ApplicationDeployment.IsNetworkDeployed)
			{
				Process.Start(ApplicationDeployment.CurrentDeployment.ActivationUri.ToString());
				Process.GetCurrentProcess().Kill();
			}
		}

		private void timerWeberButtonClick_Tick(object sender, EventArgs e)
		{
			this.timerWeberButtonClick.Enabled = false;
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.HideMachineVisu();
		}
	}
}
