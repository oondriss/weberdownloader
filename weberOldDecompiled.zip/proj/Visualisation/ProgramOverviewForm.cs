using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class ProgramOverviewForm : Form
	{
		private MainForm Main;

		private ProgPreview ProgPreview;

		private ProgFileOperationForm ProgramFileOperation;

		private int ActualProgStorageNumber;

		private int CopyProgNumber;

		private bool WasDataLoadedFromFile;

		private WSP1_VarComm.ProgStruct PD_save;

		private Panel pnMenu;

		private Button btDeleteProgram;

		private Button btHelp;

		private Button btInsertProgram;

		private Button btCopyProgram;

		private Button btEditProgram;

		private Button btBack;

		private IContainer components;

		private Button btCancel;

		private DataGridView dGVPrograms;

		private CheckBox chBEmtyPrograms;

		private CheckBox chBProgPreview;

		private Button btProgPreview;

		private CheckBox chBFourStepConcept;

		private Button btFileOperation;

		private System.Windows.Forms.Timer timerSerializeProgramData;

		private bool doNotChange_chBFourStepConcept;

		private bool bDeleteProgramMessageBox;

		private bool bKeyRemoved;

		private SaveFileDialog saveFileDialog;

		private Thread serializeThread;

		private FileStream serializeFs;

		private bool serializeShowMessage;

		private bool serializeUseDefaultDirectory;

		private string[] progressCharacters = new string[4]
		{
			"\\",
			"--",
			"/",
			"|"
		};

		private int serializeProgressCharacter;

		public ProgramOverviewForm(MainForm main)
		{
			this.Main = main;
			this.ProgPreview = new ProgPreview(this.Main);
			this.ProgramFileOperation = new ProgFileOperationForm(this.Main);
			this.InitializeComponent();
			this.dGVPrograms.Columns.Add("Col1", "SpNr");
			this.dGVPrograms.Columns.Add("Col2", "PrgNr");
			this.dGVPrograms.Columns.Add("Col3", "Name");
			this.dGVPrograms.Columns.Add("Col4", "Steps");
			this.ActualProgStorageNumber = 1;
			this.CopyProgNumber = 0;
			this.WasDataLoadedFromFile = false;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			this.pnMenu = new Panel();
			this.btCancel = new Button();
			this.btDeleteProgram = new Button();
			this.btHelp = new Button();
			this.btFileOperation = new Button();
			this.btEditProgram = new Button();
			this.btBack = new Button();
			this.btCopyProgram = new Button();
			this.btInsertProgram = new Button();
			this.dGVPrograms = new DataGridView();
			this.chBEmtyPrograms = new CheckBox();
			this.chBProgPreview = new CheckBox();
			this.btProgPreview = new Button();
			this.chBFourStepConcept = new CheckBox();
			this.timerSerializeProgramData = new System.Windows.Forms.Timer(this.components);
			this.pnMenu.SuspendLayout();
			((ISupportInitialize)this.dGVPrograms).BeginInit();
			base.SuspendLayout();
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.btDeleteProgram);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btFileOperation);
			this.pnMenu.Controls.Add(this.btEditProgram);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Controls.Add(this.btCopyProgram);
			this.pnMenu.Controls.Add(this.btInsertProgram);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 7;
			this.btCancel.Text = "Änderungen verwerfen";
			this.btCancel.Click += this.btCancel_Click;
			this.btDeleteProgram.Location = new Point(3, 323);
			this.btDeleteProgram.Name = "btDeleteProgram";
			this.btDeleteProgram.Size = new Size(74, 62);
			this.btDeleteProgram.TabIndex = 5;
			this.btDeleteProgram.Text = "Programm löschen";
			this.btDeleteProgram.Click += this.btDeleteProgram_Click;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btFileOperation.Location = new Point(3, 387);
			this.btFileOperation.Name = "btFileOperation";
			this.btFileOperation.Size = new Size(74, 62);
			this.btFileOperation.TabIndex = 6;
			this.btFileOperation.Text = "Datei Funktionen";
			this.btFileOperation.Click += this.btFileOperation_Click;
			this.btEditProgram.Location = new Point(3, 131);
			this.btEditProgram.Name = "btEditProgram";
			this.btEditProgram.Size = new Size(74, 62);
			this.btEditProgram.TabIndex = 2;
			this.btEditProgram.Text = "Programm bearbeiten";
			this.btEditProgram.Click += this.btEditProgram_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Speichern + Zurück";
			this.btBack.Click += this.btBack_Click;
			this.btCopyProgram.Location = new Point(3, 195);
			this.btCopyProgram.Name = "btCopyProgram";
			this.btCopyProgram.Size = new Size(74, 62);
			this.btCopyProgram.TabIndex = 3;
			this.btCopyProgram.Text = "Programm kopieren";
			this.btCopyProgram.Click += this.btCopyProgram_Click;
			this.btInsertProgram.Location = new Point(3, 259);
			this.btInsertProgram.Name = "btInsertProgram";
			this.btInsertProgram.Size = new Size(74, 62);
			this.btInsertProgram.TabIndex = 4;
			this.btInsertProgram.Text = "Programm einfügen";
			this.btInsertProgram.Click += this.btInsertProgram_Click;
			this.dGVPrograms.AllowUserToAddRows = false;
			this.dGVPrograms.AllowUserToDeleteRows = false;
			this.dGVPrograms.AllowUserToResizeRows = false;
			this.dGVPrograms.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dGVPrograms.Location = new Point(0, 0);
			this.dGVPrograms.MultiSelect = false;
			this.dGVPrograms.Name = "dGVPrograms";
			this.dGVPrograms.ReadOnly = true;
			this.dGVPrograms.RowHeadersVisible = false;
			this.dGVPrograms.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			this.dGVPrograms.Size = new Size(460, 522);
			this.dGVPrograms.TabIndex = 1;
			this.dGVPrograms.CellDoubleClick += this.dGVPrograms_CellDoubleClick;
			this.dGVPrograms.SelectionChanged += this.dGVPrograms_SelectionChanged;
			this.chBEmtyPrograms.AutoSize = true;
			this.chBEmtyPrograms.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBEmtyPrograms.Location = new Point(476, 12);
			this.chBEmtyPrograms.Name = "chBEmtyPrograms";
			this.chBEmtyPrograms.Size = new Size(200, 22);
			this.chBEmtyPrograms.TabIndex = 2;
			this.chBEmtyPrograms.Text = "Leere Programme ausblenden";
			this.chBEmtyPrograms.UseVisualStyleBackColor = true;
			this.chBEmtyPrograms.CheckedChanged += this.chBEmtyPrograms_CheckedChanged;
			this.chBProgPreview.AutoSize = true;
			this.chBProgPreview.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.chBProgPreview.Location = new Point(476, 104);
			this.chBProgPreview.Name = "chBProgPreview";
			this.chBProgPreview.Size = new Size(140, 22);
			this.chBProgPreview.TabIndex = 4;
			this.chBProgPreview.Text = "Programmvorschau";
			this.chBProgPreview.UseVisualStyleBackColor = true;
			this.chBProgPreview.Visible = false;
			this.chBProgPreview.CheckedChanged += this.chBProgPreview_CheckedChanged;
			this.btProgPreview.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.btProgPreview.Location = new Point(475, 132);
			this.btProgPreview.Name = "btProgPreview";
			this.btProgPreview.Size = new Size(227, 34);
			this.btProgPreview.TabIndex = 8;
			this.btProgPreview.Text = "Programmvorschau";
			this.btProgPreview.Click += this.btProgPreview_Click;
			this.chBFourStepConcept.AutoSize = true;
			this.chBFourStepConcept.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBFourStepConcept.Location = new Point(476, 43);
			this.chBFourStepConcept.Name = "chBFourStepConcept";
			this.chBFourStepConcept.Size = new Size(176, 22);
			this.chBFourStepConcept.TabIndex = 9;
			this.chBFourStepConcept.Text = "Programmansicht 4-stufig";
			this.chBFourStepConcept.UseVisualStyleBackColor = true;
			this.chBFourStepConcept.CheckedChanged += this.chBFourStepConcept_CheckedChanged;
			this.timerSerializeProgramData.Tick += this.timerSerializeProgramData_Tick;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.chBFourStepConcept);
			base.Controls.Add(this.btProgPreview);
			base.Controls.Add(this.chBProgPreview);
			base.Controls.Add(this.chBEmtyPrograms);
			base.Controls.Add(this.dGVPrograms);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "ProgramOverviewForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen/Programme";
			base.Activated += this.ProgramOverviewForm_Activated;
			this.pnMenu.ResumeLayout(false);
			((ISupportInitialize)this.dGVPrograms).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public bool ShowWindow()
		{
			this.Main.ResetBrowserGrantedBy();
			if (!this.Main.OpenGivenProgram)
			{
				this.Main.ProcessProgram.CopyProgStruct(ref this.Main.ProcessProgram.TempProgStruct, this.Main.VC.PProg);
			}
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else
			{
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadSpindleConst"));
				if (!this.Main.VC.ReceiveVarBlock(11))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not receive SpConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
			}
			this.WasDataLoadedFromFile = false;
			this.UpdateMenu();
			this.doNotChange_chBFourStepConcept = false;
			this.MenEna();
			base.Show();
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MProgramOverview");
			this.btBack.Text = this.Main.Rm.GetString("StoreAndBack");
			this.btCancel.Text = this.Main.Rm.GetString("DiscardChanges");
			this.btCopyProgram.Text = this.Main.Rm.GetString("CopyProgram");
			this.btDeleteProgram.Text = this.Main.Rm.GetString("DeleteProgram");
			this.btEditProgram.Text = this.Main.Rm.GetString("EditProgram");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btInsertProgram.Text = this.Main.Rm.GetString("InsertProgram");
			this.btFileOperation.Text = this.Main.Rm.GetString("FileOperation");
			this.chBEmtyPrograms.Text = this.Main.Rm.GetString("chBEmtyPrograms");
			this.chBProgPreview.Text = this.Main.Rm.GetString("chBProgPreview");
			this.chBFourStepConcept.Text = this.Main.Rm.GetString("ProgramDisplay4Step");
			this.btProgPreview.Text = this.Main.Rm.GetString("chBProgPreview");
			this.dGVPrograms.Columns[0].HeaderText = "";
			this.dGVPrograms.Columns[1].HeaderText = this.Main.Rm.GetString("Selection");
			this.dGVPrograms.Columns[2].HeaderText = this.Main.Rm.GetString("Name");
			this.dGVPrograms.Columns[3].HeaderText = this.Main.Rm.GetString("Steps");
			this.ProgPreview.SetLanguageTexts();
			this.ProgramFileOperation.SetLanguageTexts(2);
		}

		private void MenEna()
		{
			bool enabled = false;
			bool enabled2 = false;
			if (this.Main.PassCodeLevel >= 1)
			{
				enabled = true;
			}
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_ProgramOverviewForm)
			{
				enabled2 = true;
			}
			if (this.Main.ViewOnlyMode)
			{
				enabled = false;
				enabled2 = false;
			}
			if (this.Main.IsOfflineVersion)
			{
				enabled = true;
				enabled2 = true;
			}
			this.btProgPreview.Enabled = true;
			this.btBack.Enabled = enabled;
			this.Main.ShowCurrentUserAccessState(1, this.Main.ViewOnlyMode);
			if (!this.doNotChange_chBFourStepConcept)
			{
				if (this.Main.PassCodeLevel > 2 && !this.Main.ViewOnlyMode)
				{
					this.chBFourStepConcept.Enabled = true;
					this.chBFourStepConcept.Checked = false;
				}
				else if (this.Main.ViewOnlyMode || this.Main.PassCodeLevel == 0)
				{
					this.chBFourStepConcept.Enabled = true;
					this.chBFourStepConcept.Checked = false;
				}
				else
				{
					this.chBFourStepConcept.Enabled = false;
					this.chBFourStepConcept.Checked = true;
				}
			}
			this.doNotChange_chBFourStepConcept = true;
			this.btCopyProgram.Enabled = enabled2;
			if (this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber].Info.Steps != 0)
			{
				this.btCopyProgram.Enabled = enabled2;
				this.btDeleteProgram.Enabled = enabled2;
				this.btInsertProgram.Enabled = false;
				this.btEditProgram.Enabled = true;
			}
			else
			{
				Button button = this.btDeleteProgram;
				Button button2 = this.btCopyProgram;
				Button button3 = this.btInsertProgram;
				bool flag2 = button3.Enabled = false;
				bool enabled3 = button2.Enabled = flag2;
				button.Enabled = enabled3;
				this.btEditProgram.Enabled = true;
			}
			this.btFileOperation.Enabled = true;
			if (this.CopyProgNumber > 0 && this.CopyProgNumber < 1024)
			{
				this.btInsertProgram.Text = this.Main.Rm.GetString("InsertProgram") + " (" + this.CopyProgNumber.ToString() + ")";
			}
			else
			{
				this.btInsertProgram.Text = this.Main.Rm.GetString("InsertProgram");
			}
			if (this.Main._READ_ONLY_CONTROLLER)
			{
				this.btBack.Enabled = false;
			}
			else
			{
				this.btBack.Enabled = enabled;
			}
		}

		public int Count(bool loadFromWSP)
		{
			int num = 0;
			if (!this.Main.IsOnlineMode)
			{
				return 0;
			}
			if (loadFromWSP && !this.Main.ProcessProgram.UploadAllProgDataFromController())
			{
				return 0;
			}
			for (int i = 1; i < 1024; i++)
			{
				if (this.Main.ProcessProgram.TempProgStruct.Num[i].Info.Steps != 0)
				{
					num++;
				}
			}
			return num;
		}

		public void UpdateMenu()
		{
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			this.dGVPrograms.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			this.dGVPrograms.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			this.dGVPrograms.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			this.dGVPrograms.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			if (this.chBEmtyPrograms.Checked)
			{
				for (int i = 1; i < 1024; i++)
				{
					if (this.Main.ProcessProgram.TempProgStruct.Num[i].Info.Steps > 0)
					{
						num++;
					}
				}
			}
			else
			{
				num = 1023;
			}
			this.dGVPrograms.Rows.Clear();
			if (num > 0)
			{
				this.dGVPrograms.Rows.Add(num);
			}
			for (int j = 1; j < 1024; j++)
			{
				if (!this.chBEmtyPrograms.Checked || this.Main.ProcessProgram.TempProgStruct.Num[j].Info.Steps != 0)
				{
					num3++;
					if (j == this.ActualProgStorageNumber)
					{
						num2 = num3 - 1;
					}
					this.dGVPrograms.Rows[num3 - 1].Cells[0].Value = j;
					this.dGVPrograms.Rows[num3 - 1].Cells[1].Value = this.Main.ProcessProgram.TempProgStruct.Num[j].Info.ProgNum;
					this.dGVPrograms.Rows[num3 - 1].Cells[2].Value = this.Main.CommonFunctions.UShortToString(this.Main.ProcessProgram.TempProgStruct.Num[j].Info.Name);
					this.dGVPrograms.Rows[num3 - 1].Cells[3].Value = this.Main.ProcessProgram.TempProgStruct.Num[j].Info.Steps;
				}
			}
			this.dGVPrograms.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			this.dGVPrograms.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			this.dGVPrograms.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
			this.dGVPrograms.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			this.ProgPreview.UpdateMenu(this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber]);
			if (num > 0)
			{
				if (num2 > 10)
				{
					this.dGVPrograms.FirstDisplayedScrollingRowIndex = num2 - 3;
				}
				this.dGVPrograms.Rows[num2].Selected = false;
				this.dGVPrograms.Rows[num2].Selected = true;
			}
		}

		public void CloseProgramPreview()
		{
			if (this.chBProgPreview.Visible && this.chBProgPreview.Checked)
			{
				this.chBProgPreview.Checked = false;
				this.UpdatePreview();
			}
			else if (!this.chBProgPreview.Visible)
			{
				this.UpdatePreview();
			}
		}

		private void UpdatePreview()
		{
			if (this.btProgPreview.Text == this.Main.Rm.GetString("chBProgPreview"))
			{
				this.btProgPreview.Text = this.Main.Rm.GetString("chBProgPreview") + " " + this.Main.Rm.GetString("Close");
				this.ProgPreview.Show();
				this.ProgPreview.UpdateMenu(this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber]);
			}
			else
			{
				this.btProgPreview.Text = this.Main.Rm.GetString("chBProgPreview");
				this.ProgPreview.Hide();
			}
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			if (this.WasDataLoadedFromFile && this.Main.PassCodeLevel < Settings.Default.UserLevel_ProgramOverviewForm)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoAccess"), this.Main.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.pnMenu.Enabled = false;
				this.btProgPreview.Enabled = false;
				this.Main.ProcessProgram.SafeAllProgDataToController(this.WasDataLoadedFromFile);
				this.ProgPreview.Hide();
				this.chBProgPreview.Checked = false;
				base.Hide();
				this.CopyProgNumber = 0;
				this.btProgPreview.Text = this.Main.Rm.GetString("chBProgPreview");
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_1_Schraubprogramme";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_1_Schraubprogramme");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btEditProgram_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.ProgPreview.Hide();
			this.btProgPreview.Text = this.Main.Rm.GetString("chBProgPreview");
			this.chBProgPreview.Checked = false;
			this.PD_save = new WSP1_VarComm.ProgStruct();
			this.Main.ProcessProgram.CopyProg(ref this.PD_save, this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber]);
			this.Main.NewLogSection();
			if (!this.chBFourStepConcept.Checked)
			{
				if (!this.Main.StepOverview1.ShowWindow(this.ActualProgStorageNumber))
				{
					this.pnMenu.Enabled = true;
					this.UpdatePreview();
				}
			}
			else
			{
				this.Main.FourStepOverview1.Accept25_StepValues(this.ActualProgStorageNumber);
				if (!this.Main.FourStepOverview1.ShowWindow(this.ActualProgStorageNumber))
				{
					this.pnMenu.Enabled = true;
					this.UpdatePreview();
				}
			}
		}

		private void btCopyProgram_Click(object sender, EventArgs e)
		{
			this.CopyProgNumber = this.ActualProgStorageNumber;
			this.MenEna();
		}

		private void btInsertProgram_Click(object sender, EventArgs e)
		{
			if (this.CopyProgNumber != 0 && this.CopyProgNumber != this.ActualProgStorageNumber)
			{
				if (this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber].Info.Steps > 0)
				{
					DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbOverwriteProg"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
					if (dialogResult != DialogResult.Yes)
					{
						return;
					}
				}
				this.Main.SettingsChanged();
				this.Main.ProcessProgram.CopyProg(ref this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber], this.Main.ProcessProgram.TempProgStruct.Num[this.CopyProgNumber]);
				this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber].Info.ProgNum = (uint)this.ActualProgStorageNumber;
				this.Main.VC.PProgXChanged.Changed[this.ActualProgStorageNumber] = 1;
				this.Main.MakeLogbookEntry(201001u, 2, (float)this.CopyProgNumber, (float)this.ActualProgStorageNumber, 0u, 0, byte.MaxValue, 1, this.ActualProgStorageNumber);
				this.UpdateMenu();
			}
		}

		private void btDeleteProgram_Click(object sender, EventArgs e)
		{
			this.bDeleteProgramMessageBox = true;
			DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbDeleteProg"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
			this.bDeleteProgramMessageBox = false;
			if (this.bKeyRemoved)
			{
				this.bKeyRemoved = false;
				this.MenEna();
			}
			else if (dialogResult == DialogResult.Yes)
			{
				this.Main.SettingsChanged();
				this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber] = this.Main.ProcessProgram.NewInitializedProg();
				this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber].Info.ProgNum = (uint)this.ActualProgStorageNumber;
				this.Main.VC.PProgXChanged.Changed[this.ActualProgStorageNumber] = 1;
				if (this.ActualProgStorageNumber == this.CopyProgNumber)
				{
					this.CopyProgNumber = 0;
				}
				this.Main.MakeLogbookEntry(201000u, 2, 0f, 0f, this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber].Info.ProgNum, 0, byte.MaxValue, 1, this.ActualProgStorageNumber);
				this.MenEna();
				this.UpdateMenu();
			}
		}

		private void btFileOperation_Click(object sender, EventArgs e)
		{
			this.ProgramFileOperation.ShowWindow(this.ActualProgStorageNumber);
			this.Cursor = Cursors.WaitCursor;
			switch (this.ProgramFileOperation.FileOperationType)
			{
			case 1:
				if (this.Main.ProcessProgram.LoadAllProgDataFromFile(null, true))
				{
					this.Main.SettingsChanged();
					this.WasDataLoadedFromFile = true;
					for (int i = 0; i < 1024; i++)
					{
						this.Main.VC.PProgXChanged.Changed[i] = 1;
					}
					this.UpdateMenu();
					this.Main.MakeLogbookEntry(201009u, 2, 0f, 0f, 0u, 0, byte.MaxValue, 1, 0);
				}
				break;
			case 2:
				this.safeAllProgDataToFile(null, true);
				break;
			case 3:
				if (this.Main.ProcessProgram.LoadProgDataFromFile(this.ActualProgStorageNumber))
				{
					this.Main.SettingsChanged();
					this.WasDataLoadedFromFile = true;
					this.UpdateMenu();
					this.Main.MakeLogbookEntry(201008u, 2, 0f, 0f, (uint)this.ActualProgStorageNumber, 0, byte.MaxValue, 1, 0);
				}
				break;
			case 4:
				this.Main.ProcessProgram.SafeProgDataToFile(this.ActualProgStorageNumber);
				break;
			default:
				MessageBox.Show("Wrong FileOperationType in btFileOperation_Click() of ProgramOverview", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				break;
			case 0:
				break;
			}
			this.Cursor = Cursors.Default;
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.Main.VC.makeCopyPProg(ref this.Main.ProcessProgram.TempProgStruct, this.Main.VC.PProg);
			this.Main.SettingsChangedReset();
			this.Main.VC.PProgXChanged.Initialize();
			this.Main.LoggingFinished(true);
			this.ProgPreview.Hide();
			this.chBProgPreview.Checked = false;
			base.Hide();
			this.CopyProgNumber = 0;
			this.btProgPreview.Text = this.Main.Rm.GetString("chBProgPreview");
		}

		private void ProgramOverviewForm_Activated(object sender, EventArgs e)
		{
			if (this.Main.StepOverview1.WasCanceled || this.Main.FourStepOverview1.WasCanceled)
			{
				this.Main.VC.makeCopyProgStruct(ref this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber], this.PD_save);
			}
			this.MenEna();
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void chBEmtyPrograms_CheckedChanged(object sender, EventArgs e)
		{
			if (this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber].Info.Steps == 0)
			{
				this.ActualProgStorageNumber = 1;
			}
			this.UpdateMenu();
		}

		private void chBProgPreview_CheckedChanged(object sender, EventArgs e)
		{
			this.UpdatePreview();
		}

		private void btProgPreview_Click(object sender, EventArgs e)
		{
			this.UpdatePreview();
		}

		private void dGVPrograms_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			this.btEditProgram_Click(null, null);
		}

		private void dGVPrograms_SelectionChanged(object sender, EventArgs e)
		{
			try
			{
				bool enabled = false;
				if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_ProgramOverviewForm)
				{
					enabled = true;
				}
				if (this.Main.ViewOnlyMode)
				{
					enabled = false;
				}
				if (this.Main.IsOfflineVersion)
				{
					enabled = true;
				}
				this.ActualProgStorageNumber = (int)this.dGVPrograms.SelectedRows[0].Cells[0].Value;
				if (this.Main.StepOverview1.WasCanceled)
				{
					this.Main.VC.makeCopyProgStruct(ref this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber], this.PD_save);
				}
				this.ProgPreview.UpdateMenu(this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber]);
				if (this.Main.ProcessProgram.TempProgStruct.Num[this.ActualProgStorageNumber].Info.Steps == 0)
				{
					if (this.CopyProgNumber == 0)
					{
						this.btInsertProgram.Enabled = false;
					}
					else
					{
						this.btInsertProgram.Enabled = enabled;
					}
					this.btDeleteProgram.Enabled = false;
					this.btEditProgram.Enabled = true;
					this.btCopyProgram.Enabled = false;
				}
				else
				{
					this.btInsertProgram.Enabled = false;
					this.btDeleteProgram.Enabled = enabled;
					this.btEditProgram.Enabled = true;
					this.btCopyProgram.Enabled = enabled;
				}
			}
			catch
			{
			}
		}

		public void KeyArrived()
		{
			if (this.Main.PassCodeLevel > 0)
			{
				if (this.Main.GetExclusiveBlock1())
				{
					this.Main.ProcessProgram.UploadAllProgDataFromController();
					this.Main.ProcessProgram.InitializeTempProgStruct();
					this.Main.CheckParamAllowed = true;
					this.ShowWindow();
				}
				else
				{
					this.Main.CheckParamAllowed = false;
				}
			}
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void chBFourStepConcept_CheckedChanged(object sender, EventArgs e)
		{
			Settings.Default.FourStepConcept = this.chBFourStepConcept.Checked;
			Settings.Default.Save();
		}

		private string safeAllProgDataToFile(string directory, bool showMessage)
		{
			bool flag;
			string directoryS;
			if (directory == null)
			{
				flag = Settings.Default.ProgFileOperationDefaultUse;
				directoryS = Settings.Default.ProgFileOperationDefaultDirectory;
			}
			else
			{
				flag = true;
				directoryS = directory;
			}
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			FileStream fileStream = null;
			try
			{
				if (!flag)
				{
					this.saveFileDialog = new SaveFileDialog();
					this.saveFileDialog.Filter = this.Main.Rm.GetString("ScrewProgramFiles") + "|*.wprg|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
					this.saveFileDialog.FileName = this.Main.Rm.GetString("ScrewProgramFiles") + " V" + Assembly.GetExecutingAssembly().GetName().Version.ToString();
					if (this.saveFileDialog.ShowDialog() != DialogResult.OK)
					{
						return "";
					}
					fileStream = new FileStream(this.saveFileDialog.FileName, FileMode.Create);
				}
				else
				{
					fileStream = this.Main.ProcessProgram.GetNextFile(directoryS, this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) + "_ALL_PROGRAMS_", "wprg");
				}
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveProgramDataLocally"));
				Cursor.Current = Cursors.WaitCursor;
				Application.DoEvents();
				this.serializeShowMessage = showMessage;
				this.serializeUseDefaultDirectory = flag;
				this.serializeFs = fileStream;
				this.serializeProgressCharacter = 0;
				this.serializeThread = new Thread(this.serializeAllProgDataToFile);
				this.serializeThread.Start();
				this.pnMenu.Enabled = false;
				this.timerSerializeProgramData.Enabled = true;
				return "";
			}
			catch (Exception ex)
			{
				if (fileStream != null)
				{
					fileStream.Close();
					fileStream.Dispose();
				}
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				this.pnMenu.Enabled = true;
				MessageBox.Show(this.Main.Rm.GetString("MbPProgSaveToFileFailure") + ":\n" + ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return "";
			}
		}

		private void serializeAllProgDataToFile()
		{
			try
			{
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				binaryFormatter.AssemblyFormat = FormatterAssemblyStyle.Simple;
				binaryFormatter.Serialize(this.serializeFs, this.Main.ProcessProgram.TempProgStruct);
			}
			catch (Exception ex)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbPProgSaveToFileFailure") + ":\n" + ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		private void timerSerializeProgramData_Tick(object sender, EventArgs e)
		{
			if (this.serializeThread.IsAlive)
			{
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveProgramDataLocally") + " " + this.progressCharacters[this.serializeProgressCharacter]);
				Cursor.Current = Cursors.WaitCursor;
				this.serializeProgressCharacter++;
				if (this.serializeProgressCharacter >= this.progressCharacters.Length)
				{
					this.serializeProgressCharacter = 0;
				}
			}
			else
			{
				this.timerSerializeProgramData.Enabled = false;
				this.serializeFs.Close();
				this.serializeFs.Dispose();
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				this.pnMenu.Enabled = true;
				string name = this.serializeFs.Name;
				string text = this.Main.Rm.GetString("MbSavedProgramDataToFile") + "\n" + name;
				if (this.serializeUseDefaultDirectory && this.serializeShowMessage)
				{
					MessageBox.Show(text);
				}
			}
		}
	}
}
