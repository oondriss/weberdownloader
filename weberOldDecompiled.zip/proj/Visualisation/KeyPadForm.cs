using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Visualisation
{
	public class KeyPadForm : Form
	{
		private MainForm Main;

		private TextBox TB;

		private ComboBox CB;

		private int TBSelectionStart;

		private string NewText;

		private bool AreCaps;

		private TextBox tBNewValue;

		private Label lbOldValue;

		private Button btApply;

		private Button btCancel;

		private Button btBackspace;

		private Button btCapsR;

		private Button btMinus;

		private Button btP;

		private Button bt0;

		private Button btM;

		private Button btL;

		private Button btN;

		private Button btK;

		private Button btJ;

		private Button btO;

		private Button btI;

		private Button btU;

		private Button bt9;

		private Button bt8;

		private Button bt7;

		private Button btB;

		private Button btV;

		private Button btH;

		private Button btC;

		private Button btG;

		private Button btF;

		private Button btZ;

		private Button btT;

		private Button btR;

		private Button bt6;

		private Button bt5;

		private Button bt4;

		private Button btX;

		private Button btY;

		private Button btD;

		private Button btCapsL;

		private Button btS;

		private Button btA;

		private Button btE;

		private Button btW;

		private Button btQ;

		private Button bt3;

		private Button bt2;

		private Button bt1;

		private Panel pnKeys;

		private Button btSpace;

		private Button btFullStop;

		private Button btComma;

		private Button btRight;

		private Button btLeft;

		private Timer timerAutoRepeat;

		private Timer timerWaitAutoRepeat;

		private IContainer components;

		private string recentActiveControl = "";

		public string Title
		{
			get;
			set;
		}

		public void DisableComma()
		{
			this.btComma.Enabled = false;
		}

		public void DisablePoint()
		{
			this.btFullStop.Enabled = false;
		}

		public KeyPadForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.AreCaps = true;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			this.pnKeys = new Panel();
			this.btRight = new Button();
			this.btLeft = new Button();
			this.btFullStop = new Button();
			this.btComma = new Button();
			this.btBackspace = new Button();
			this.btCapsR = new Button();
			this.btMinus = new Button();
			this.btP = new Button();
			this.bt0 = new Button();
			this.btSpace = new Button();
			this.btM = new Button();
			this.btL = new Button();
			this.btN = new Button();
			this.btK = new Button();
			this.btJ = new Button();
			this.btO = new Button();
			this.btI = new Button();
			this.btU = new Button();
			this.bt9 = new Button();
			this.bt8 = new Button();
			this.bt7 = new Button();
			this.btB = new Button();
			this.btV = new Button();
			this.btH = new Button();
			this.btC = new Button();
			this.btG = new Button();
			this.btF = new Button();
			this.btZ = new Button();
			this.btT = new Button();
			this.btR = new Button();
			this.bt6 = new Button();
			this.bt5 = new Button();
			this.bt4 = new Button();
			this.tBNewValue = new TextBox();
			this.btX = new Button();
			this.btY = new Button();
			this.btD = new Button();
			this.btCapsL = new Button();
			this.btS = new Button();
			this.btA = new Button();
			this.btE = new Button();
			this.btW = new Button();
			this.btQ = new Button();
			this.bt3 = new Button();
			this.bt2 = new Button();
			this.lbOldValue = new Label();
			this.bt1 = new Button();
			this.btApply = new Button();
			this.btCancel = new Button();
			this.timerAutoRepeat = new Timer(this.components);
			this.timerWaitAutoRepeat = new Timer(this.components);
			this.pnKeys.SuspendLayout();
			base.SuspendLayout();
			this.pnKeys.Controls.Add(this.btRight);
			this.pnKeys.Controls.Add(this.btLeft);
			this.pnKeys.Controls.Add(this.btFullStop);
			this.pnKeys.Controls.Add(this.btComma);
			this.pnKeys.Controls.Add(this.btBackspace);
			this.pnKeys.Controls.Add(this.btCapsR);
			this.pnKeys.Controls.Add(this.btMinus);
			this.pnKeys.Controls.Add(this.btP);
			this.pnKeys.Controls.Add(this.bt0);
			this.pnKeys.Controls.Add(this.btSpace);
			this.pnKeys.Controls.Add(this.btM);
			this.pnKeys.Controls.Add(this.btL);
			this.pnKeys.Controls.Add(this.btN);
			this.pnKeys.Controls.Add(this.btK);
			this.pnKeys.Controls.Add(this.btJ);
			this.pnKeys.Controls.Add(this.btO);
			this.pnKeys.Controls.Add(this.btI);
			this.pnKeys.Controls.Add(this.btU);
			this.pnKeys.Controls.Add(this.bt9);
			this.pnKeys.Controls.Add(this.bt8);
			this.pnKeys.Controls.Add(this.bt7);
			this.pnKeys.Controls.Add(this.btB);
			this.pnKeys.Controls.Add(this.btV);
			this.pnKeys.Controls.Add(this.btH);
			this.pnKeys.Controls.Add(this.btC);
			this.pnKeys.Controls.Add(this.btG);
			this.pnKeys.Controls.Add(this.btF);
			this.pnKeys.Controls.Add(this.btZ);
			this.pnKeys.Controls.Add(this.btT);
			this.pnKeys.Controls.Add(this.btR);
			this.pnKeys.Controls.Add(this.bt6);
			this.pnKeys.Controls.Add(this.bt5);
			this.pnKeys.Controls.Add(this.bt4);
			this.pnKeys.Controls.Add(this.tBNewValue);
			this.pnKeys.Controls.Add(this.btX);
			this.pnKeys.Controls.Add(this.btY);
			this.pnKeys.Controls.Add(this.btD);
			this.pnKeys.Controls.Add(this.btCapsL);
			this.pnKeys.Controls.Add(this.btS);
			this.pnKeys.Controls.Add(this.btA);
			this.pnKeys.Controls.Add(this.btE);
			this.pnKeys.Controls.Add(this.btW);
			this.pnKeys.Controls.Add(this.btQ);
			this.pnKeys.Controls.Add(this.bt3);
			this.pnKeys.Controls.Add(this.bt2);
			this.pnKeys.Controls.Add(this.lbOldValue);
			this.pnKeys.Controls.Add(this.bt1);
			this.pnKeys.Controls.Add(this.btApply);
			this.pnKeys.Controls.Add(this.btCancel);
			this.pnKeys.Location = new Point(0, 0);
			this.pnKeys.MaximumSize = new Size(767, 366);
			this.pnKeys.MinimumSize = new Size(767, 366);
			this.pnKeys.Name = "pnKeys";
			this.pnKeys.Size = new Size(767, 366);
			this.pnKeys.TabIndex = 1;
			this.btRight.Font = new Font("Arial Unicode MS", 27.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.btRight.Location = new Point(685, 304);
			this.btRight.Name = "btRight";
			this.btRight.Size = new Size(80, 56);
			this.btRight.TabIndex = 47;
			this.btRight.Text = ">";
			this.btRight.Click += this.btRight_Click;
			this.btLeft.Font = new Font("Arial Unicode MS", 27.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.btLeft.Location = new Point(600, 304);
			this.btLeft.Name = "btLeft";
			this.btLeft.Size = new Size(80, 56);
			this.btLeft.TabIndex = 46;
			this.btLeft.Text = "<";
			this.btLeft.Click += this.btLeft_Click;
			this.btFullStop.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btFullStop.Location = new Point(582, 240);
			this.btFullStop.Name = "btFullStop";
			this.btFullStop.Size = new Size(56, 56);
			this.btFullStop.TabIndex = 45;
			this.btFullStop.Tag = ".";
			this.btFullStop.Text = ".";
			this.btFullStop.Click += this.textKey_Click;
			this.btFullStop.MouseDown += this.bt_MouseDown;
			this.btFullStop.MouseLeave += this.bt_MouseLeave;
			this.btFullStop.MouseUp += this.bt_MouseUp;
			this.btComma.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btComma.Location = new Point(520, 240);
			this.btComma.Name = "btComma";
			this.btComma.Size = new Size(56, 56);
			this.btComma.TabIndex = 44;
			this.btComma.Tag = ",";
			this.btComma.Text = ",";
			this.btComma.Click += this.textKey_Click;
			this.btComma.MouseDown += this.bt_MouseDown;
			this.btComma.MouseLeave += this.bt_MouseLeave;
			this.btComma.MouseUp += this.bt_MouseUp;
			this.btBackspace.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btBackspace.Location = new Point(646, 48);
			this.btBackspace.Name = "btBackspace";
			this.btBackspace.Size = new Size(84, 56);
			this.btBackspace.TabIndex = 43;
			this.btBackspace.Tag = "{BS}";
			this.btBackspace.Text = "Zurück";
			this.btBackspace.Click += this.textKey_Click;
			this.btBackspace.MouseDown += this.bt_MouseDown;
			this.btBackspace.MouseLeave += this.bt_MouseLeave;
			this.btBackspace.MouseUp += this.bt_MouseUp;
			this.btCapsR.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCapsR.Location = new Point(646, 240);
			this.btCapsR.Name = "btCapsR";
			this.btCapsR.Size = new Size(84, 56);
			this.btCapsR.TabIndex = 40;
			this.btCapsR.Text = "Cabs";
			this.btCapsR.Click += this.Cabs_Click;
			this.btMinus.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btMinus.Location = new Point(625, 176);
			this.btMinus.Name = "btMinus";
			this.btMinus.Size = new Size(56, 56);
			this.btMinus.TabIndex = 30;
			this.btMinus.Tag = "-";
			this.btMinus.Text = "-";
			this.btMinus.Click += this.textKey_Click;
			this.btMinus.MouseDown += this.bt_MouseDown;
			this.btMinus.MouseLeave += this.bt_MouseLeave;
			this.btMinus.MouseUp += this.bt_MouseUp;
			this.btP.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btP.Location = new Point(612, 112);
			this.btP.Name = "btP";
			this.btP.Size = new Size(56, 56);
			this.btP.TabIndex = 20;
			this.btP.Tag = "p";
			this.btP.Text = "p";
			this.btP.Click += this.textKey_Click;
			this.btP.MouseDown += this.bt_MouseDown;
			this.btP.MouseLeave += this.bt_MouseLeave;
			this.btP.MouseUp += this.bt_MouseUp;
			this.bt0.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt0.Location = new Point(584, 48);
			this.bt0.Name = "bt0";
			this.bt0.Size = new Size(56, 56);
			this.bt0.TabIndex = 10;
			this.bt0.Tag = "0";
			this.bt0.Text = "0";
			this.bt0.Click += this.textKey_Click;
			this.bt0.MouseDown += this.bt_MouseDown;
			this.bt0.MouseLeave += this.bt_MouseLeave;
			this.bt0.MouseUp += this.bt_MouseUp;
			this.btSpace.Font = new Font("Arial Unicode MS", 14f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btSpace.Location = new Point(128, 304);
			this.btSpace.Name = "btSpace";
			this.btSpace.Size = new Size(340, 56);
			this.btSpace.TabIndex = 39;
			this.btSpace.Text = "Space";
			this.btSpace.Click += this.textKey_Click;
			this.btSpace.MouseDown += this.bt_MouseDown;
			this.btSpace.MouseLeave += this.bt_MouseLeave;
			this.btSpace.MouseUp += this.bt_MouseUp;
			this.btM.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btM.Location = new Point(456, 240);
			this.btM.Name = "btM";
			this.btM.Size = new Size(56, 56);
			this.btM.TabIndex = 38;
			this.btM.Tag = "m";
			this.btM.Text = "m";
			this.btM.Click += this.textKey_Click;
			this.btM.MouseDown += this.bt_MouseDown;
			this.btM.MouseLeave += this.bt_MouseLeave;
			this.btM.MouseUp += this.bt_MouseUp;
			this.btL.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btL.Location = new Point(561, 176);
			this.btL.Name = "btL";
			this.btL.Size = new Size(56, 56);
			this.btL.TabIndex = 29;
			this.btL.Tag = "l";
			this.btL.Text = "l";
			this.btL.Click += this.textKey_Click;
			this.btL.MouseDown += this.bt_MouseDown;
			this.btL.MouseLeave += this.bt_MouseLeave;
			this.btL.MouseUp += this.bt_MouseUp;
			this.btN.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btN.Location = new Point(392, 240);
			this.btN.Name = "btN";
			this.btN.Size = new Size(56, 56);
			this.btN.TabIndex = 37;
			this.btN.Tag = "n";
			this.btN.Text = "n";
			this.btN.Click += this.textKey_Click;
			this.btN.MouseDown += this.bt_MouseDown;
			this.btN.MouseLeave += this.bt_MouseLeave;
			this.btN.MouseUp += this.bt_MouseUp;
			this.btK.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btK.Location = new Point(497, 176);
			this.btK.Name = "btK";
			this.btK.Size = new Size(56, 56);
			this.btK.TabIndex = 28;
			this.btK.Tag = "k";
			this.btK.Text = "k";
			this.btK.Click += this.textKey_Click;
			this.btK.MouseDown += this.bt_MouseDown;
			this.btK.MouseLeave += this.bt_MouseLeave;
			this.btK.MouseUp += this.bt_MouseUp;
			this.btJ.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btJ.Location = new Point(433, 176);
			this.btJ.Name = "btJ";
			this.btJ.Size = new Size(56, 56);
			this.btJ.TabIndex = 27;
			this.btJ.Tag = "j";
			this.btJ.Text = "j";
			this.btJ.Click += this.textKey_Click;
			this.btJ.MouseDown += this.bt_MouseDown;
			this.btJ.MouseLeave += this.bt_MouseLeave;
			this.btJ.MouseUp += this.bt_MouseUp;
			this.btO.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btO.Location = new Point(548, 112);
			this.btO.Name = "btO";
			this.btO.Size = new Size(56, 56);
			this.btO.TabIndex = 19;
			this.btO.Tag = "o";
			this.btO.Text = "o";
			this.btO.Click += this.textKey_Click;
			this.btO.MouseDown += this.bt_MouseDown;
			this.btO.MouseLeave += this.bt_MouseLeave;
			this.btO.MouseUp += this.bt_MouseUp;
			this.btI.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btI.Location = new Point(484, 112);
			this.btI.Name = "btI";
			this.btI.Size = new Size(56, 56);
			this.btI.TabIndex = 18;
			this.btI.Tag = "i";
			this.btI.Text = "i";
			this.btI.Click += this.textKey_Click;
			this.btI.MouseDown += this.bt_MouseDown;
			this.btI.MouseLeave += this.bt_MouseLeave;
			this.btI.MouseUp += this.bt_MouseUp;
			this.btU.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btU.Location = new Point(420, 112);
			this.btU.Name = "btU";
			this.btU.Size = new Size(56, 56);
			this.btU.TabIndex = 17;
			this.btU.Tag = "u";
			this.btU.Text = "u";
			this.btU.Click += this.textKey_Click;
			this.btU.MouseDown += this.bt_MouseDown;
			this.btU.MouseLeave += this.bt_MouseLeave;
			this.btU.MouseUp += this.bt_MouseUp;
			this.bt9.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt9.Location = new Point(520, 48);
			this.bt9.Name = "bt9";
			this.bt9.Size = new Size(56, 56);
			this.bt9.TabIndex = 9;
			this.bt9.Tag = "9";
			this.bt9.Text = "9";
			this.bt9.Click += this.textKey_Click;
			this.bt9.MouseDown += this.bt_MouseDown;
			this.bt9.MouseLeave += this.bt_MouseLeave;
			this.bt9.MouseUp += this.bt_MouseUp;
			this.bt8.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt8.Location = new Point(456, 48);
			this.bt8.Name = "bt8";
			this.bt8.Size = new Size(56, 56);
			this.bt8.TabIndex = 8;
			this.bt8.Tag = "8";
			this.bt8.Text = "8";
			this.bt8.Click += this.textKey_Click;
			this.bt8.MouseDown += this.bt_MouseDown;
			this.bt8.MouseLeave += this.bt_MouseLeave;
			this.bt8.MouseUp += this.bt_MouseUp;
			this.bt7.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt7.Location = new Point(392, 48);
			this.bt7.Name = "bt7";
			this.bt7.Size = new Size(56, 56);
			this.bt7.TabIndex = 7;
			this.bt7.Tag = "7";
			this.bt7.Text = "7";
			this.bt7.Click += this.textKey_Click;
			this.bt7.MouseDown += this.bt_MouseDown;
			this.bt7.MouseLeave += this.bt_MouseLeave;
			this.bt7.MouseUp += this.bt_MouseUp;
			this.btB.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btB.Location = new Point(328, 240);
			this.btB.Name = "btB";
			this.btB.Size = new Size(56, 56);
			this.btB.TabIndex = 36;
			this.btB.Tag = "b";
			this.btB.Text = "b";
			this.btB.Click += this.textKey_Click;
			this.btB.MouseDown += this.bt_MouseDown;
			this.btB.MouseLeave += this.bt_MouseLeave;
			this.btB.MouseUp += this.bt_MouseUp;
			this.btV.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btV.Location = new Point(264, 240);
			this.btV.Name = "btV";
			this.btV.Size = new Size(56, 56);
			this.btV.TabIndex = 35;
			this.btV.Tag = "v";
			this.btV.Text = "v";
			this.btV.Click += this.textKey_Click;
			this.btV.MouseDown += this.bt_MouseDown;
			this.btV.MouseLeave += this.bt_MouseLeave;
			this.btV.MouseUp += this.bt_MouseUp;
			this.btH.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btH.Location = new Point(369, 176);
			this.btH.Name = "btH";
			this.btH.Size = new Size(56, 56);
			this.btH.TabIndex = 26;
			this.btH.Tag = "h";
			this.btH.Text = "h";
			this.btH.Click += this.textKey_Click;
			this.btH.MouseDown += this.bt_MouseDown;
			this.btH.MouseLeave += this.bt_MouseLeave;
			this.btH.MouseUp += this.bt_MouseUp;
			this.btC.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btC.Location = new Point(200, 240);
			this.btC.Name = "btC";
			this.btC.Size = new Size(56, 56);
			this.btC.TabIndex = 34;
			this.btC.Tag = "c";
			this.btC.Text = "c";
			this.btC.Click += this.textKey_Click;
			this.btC.MouseDown += this.bt_MouseDown;
			this.btC.MouseLeave += this.bt_MouseLeave;
			this.btC.MouseUp += this.bt_MouseUp;
			this.btG.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btG.Location = new Point(305, 176);
			this.btG.Name = "btG";
			this.btG.Size = new Size(56, 56);
			this.btG.TabIndex = 25;
			this.btG.Tag = "g";
			this.btG.Text = "g";
			this.btG.Click += this.textKey_Click;
			this.btG.MouseDown += this.bt_MouseDown;
			this.btG.MouseLeave += this.bt_MouseLeave;
			this.btG.MouseUp += this.bt_MouseUp;
			this.btF.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btF.Location = new Point(241, 176);
			this.btF.Name = "btF";
			this.btF.Size = new Size(56, 56);
			this.btF.TabIndex = 24;
			this.btF.Tag = "f";
			this.btF.Text = "f";
			this.btF.Click += this.textKey_Click;
			this.btF.MouseDown += this.bt_MouseDown;
			this.btF.MouseLeave += this.bt_MouseLeave;
			this.btF.MouseUp += this.bt_MouseUp;
			this.btZ.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btZ.Location = new Point(356, 112);
			this.btZ.Name = "btZ";
			this.btZ.Size = new Size(56, 56);
			this.btZ.TabIndex = 16;
			this.btZ.Tag = "z";
			this.btZ.Text = "z";
			this.btZ.Click += this.textKey_Click;
			this.btZ.MouseDown += this.bt_MouseDown;
			this.btZ.MouseLeave += this.bt_MouseLeave;
			this.btZ.MouseUp += this.bt_MouseUp;
			this.btT.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btT.Location = new Point(292, 112);
			this.btT.Name = "btT";
			this.btT.Size = new Size(56, 56);
			this.btT.TabIndex = 15;
			this.btT.Tag = "t";
			this.btT.Text = "t";
			this.btT.Click += this.textKey_Click;
			this.btT.MouseDown += this.bt_MouseDown;
			this.btT.MouseLeave += this.bt_MouseLeave;
			this.btT.MouseUp += this.bt_MouseUp;
			this.btR.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btR.Location = new Point(228, 112);
			this.btR.Name = "btR";
			this.btR.Size = new Size(56, 56);
			this.btR.TabIndex = 14;
			this.btR.Tag = "r";
			this.btR.Text = "r";
			this.btR.Click += this.textKey_Click;
			this.btR.MouseDown += this.bt_MouseDown;
			this.btR.MouseLeave += this.bt_MouseLeave;
			this.btR.MouseUp += this.bt_MouseUp;
			this.bt6.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt6.Location = new Point(328, 48);
			this.bt6.Name = "bt6";
			this.bt6.Size = new Size(56, 56);
			this.bt6.TabIndex = 6;
			this.bt6.Tag = "6";
			this.bt6.Text = "6";
			this.bt6.Click += this.textKey_Click;
			this.bt6.MouseDown += this.bt_MouseDown;
			this.bt6.MouseLeave += this.bt_MouseLeave;
			this.bt6.MouseUp += this.bt_MouseUp;
			this.bt5.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt5.Location = new Point(264, 48);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(56, 56);
			this.bt5.TabIndex = 5;
			this.bt5.Tag = "5";
			this.bt5.Text = "5";
			this.bt5.Click += this.textKey_Click;
			this.bt5.MouseDown += this.bt_MouseDown;
			this.bt5.MouseLeave += this.bt_MouseLeave;
			this.bt5.MouseUp += this.bt_MouseUp;
			this.bt4.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt4.Location = new Point(200, 48);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(56, 56);
			this.bt4.TabIndex = 4;
			this.bt4.Tag = "4";
			this.bt4.Text = "4";
			this.bt4.Click += this.textKey_Click;
			this.bt4.MouseDown += this.bt_MouseDown;
			this.bt4.MouseLeave += this.bt_MouseLeave;
			this.bt4.MouseUp += this.bt_MouseUp;
			this.tBNewValue.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.tBNewValue.Location = new Point(8, 8);
			this.tBNewValue.MaxLength = 19;
			this.tBNewValue.Name = "tBNewValue";
			this.tBNewValue.Size = new Size(609, 28);
			this.tBNewValue.TabIndex = 0;
			this.tBNewValue.Text = "textBox1";
			this.tBNewValue.TextChanged += this.tBNewValue_TextChanged;
			this.tBNewValue.KeyUp += this.tBNewValue_KeyUp;
			this.tBNewValue.MouseDown += this.tBNewValue_MouseDown;
			this.btX.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btX.Location = new Point(136, 240);
			this.btX.Name = "btX";
			this.btX.Size = new Size(56, 56);
			this.btX.TabIndex = 33;
			this.btX.Tag = "x";
			this.btX.Text = "x";
			this.btX.Click += this.textKey_Click;
			this.btX.MouseDown += this.bt_MouseDown;
			this.btX.MouseLeave += this.bt_MouseLeave;
			this.btX.MouseUp += this.bt_MouseUp;
			this.btY.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btY.Location = new Point(72, 240);
			this.btY.Name = "btY";
			this.btY.Size = new Size(56, 56);
			this.btY.TabIndex = 32;
			this.btY.Tag = "y";
			this.btY.Text = "y";
			this.btY.Click += this.textKey_Click;
			this.btY.MouseDown += this.bt_MouseDown;
			this.btY.MouseLeave += this.bt_MouseLeave;
			this.btY.MouseUp += this.bt_MouseUp;
			this.btD.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btD.Location = new Point(177, 176);
			this.btD.Name = "btD";
			this.btD.Size = new Size(56, 56);
			this.btD.TabIndex = 23;
			this.btD.Tag = "d";
			this.btD.Text = "d";
			this.btD.Click += this.textKey_Click;
			this.btD.MouseDown += this.bt_MouseDown;
			this.btD.MouseLeave += this.bt_MouseLeave;
			this.btD.MouseUp += this.bt_MouseUp;
			this.btCapsL.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCapsL.Location = new Point(8, 240);
			this.btCapsL.Name = "btCapsL";
			this.btCapsL.Size = new Size(56, 56);
			this.btCapsL.TabIndex = 31;
			this.btCapsL.Text = "Cabs";
			this.btCapsL.Click += this.Cabs_Click;
			this.btS.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btS.Location = new Point(113, 176);
			this.btS.Name = "btS";
			this.btS.Size = new Size(56, 56);
			this.btS.TabIndex = 22;
			this.btS.Tag = "s";
			this.btS.Text = "s";
			this.btS.Click += this.textKey_Click;
			this.btS.MouseDown += this.bt_MouseDown;
			this.btS.MouseLeave += this.bt_MouseLeave;
			this.btS.MouseUp += this.bt_MouseUp;
			this.btA.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btA.Location = new Point(49, 176);
			this.btA.Name = "btA";
			this.btA.Size = new Size(56, 56);
			this.btA.TabIndex = 21;
			this.btA.Tag = "a";
			this.btA.Text = "a";
			this.btA.Click += this.textKey_Click;
			this.btA.MouseDown += this.bt_MouseDown;
			this.btA.MouseLeave += this.bt_MouseLeave;
			this.btA.MouseUp += this.bt_MouseUp;
			this.btE.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btE.Location = new Point(164, 112);
			this.btE.Name = "btE";
			this.btE.Size = new Size(56, 56);
			this.btE.TabIndex = 13;
			this.btE.Tag = "e";
			this.btE.Text = "e";
			this.btE.Click += this.textKey_Click;
			this.btE.MouseDown += this.bt_MouseDown;
			this.btE.MouseLeave += this.bt_MouseLeave;
			this.btE.MouseUp += this.bt_MouseUp;
			this.btW.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btW.Location = new Point(100, 112);
			this.btW.Name = "btW";
			this.btW.Size = new Size(56, 56);
			this.btW.TabIndex = 12;
			this.btW.Tag = "w";
			this.btW.Text = "w";
			this.btW.Click += this.textKey_Click;
			this.btW.MouseDown += this.bt_MouseDown;
			this.btW.MouseLeave += this.bt_MouseLeave;
			this.btW.MouseUp += this.bt_MouseUp;
			this.btQ.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btQ.Location = new Point(36, 112);
			this.btQ.Name = "btQ";
			this.btQ.Size = new Size(56, 56);
			this.btQ.TabIndex = 11;
			this.btQ.Tag = "q";
			this.btQ.Text = "q";
			this.btQ.Click += this.textKey_Click;
			this.btQ.MouseDown += this.bt_MouseDown;
			this.btQ.MouseLeave += this.bt_MouseLeave;
			this.btQ.MouseUp += this.bt_MouseUp;
			this.bt3.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt3.Location = new Point(136, 48);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(56, 56);
			this.bt3.TabIndex = 3;
			this.bt3.Tag = "3";
			this.bt3.Text = "3";
			this.bt3.Click += this.textKey_Click;
			this.bt3.MouseDown += this.bt_MouseDown;
			this.bt3.MouseLeave += this.bt_MouseLeave;
			this.bt3.MouseUp += this.bt_MouseUp;
			this.bt2.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt2.Location = new Point(72, 48);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(56, 56);
			this.bt2.TabIndex = 2;
			this.bt2.Tag = "2";
			this.bt2.Text = "2";
			this.bt2.Click += this.textKey_Click;
			this.bt2.MouseDown += this.bt_MouseDown;
			this.bt2.MouseLeave += this.bt_MouseLeave;
			this.bt2.MouseUp += this.bt_MouseUp;
			this.lbOldValue.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbOldValue.Location = new Point(625, 13);
			this.lbOldValue.Name = "lbOldValue";
			this.lbOldValue.Size = new Size(105, 23);
			this.lbOldValue.TabIndex = 8;
			this.lbOldValue.Text = "label1";
			this.lbOldValue.Visible = false;
			this.bt1.Font = new Font("Arial Unicode MS", 40f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt1.Location = new Point(8, 48);
			this.bt1.Name = "bt1";
			this.bt1.Size = new Size(56, 56);
			this.bt1.TabIndex = 1;
			this.bt1.Tag = "1";
			this.bt1.Text = "1";
			this.bt1.Click += this.textKey_Click;
			this.bt1.MouseDown += this.bt_MouseDown;
			this.bt1.MouseLeave += this.bt_MouseLeave;
			this.bt1.MouseUp += this.bt_MouseUp;
			this.btApply.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btApply.Location = new Point(478, 304);
			this.btApply.Name = "btApply";
			this.btApply.Size = new Size(110, 56);
			this.btApply.TabIndex = 42;
			this.btApply.Text = "OK";
			this.btApply.Click += this.btApply_Click;
			this.btCancel.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCancel.Location = new Point(8, 304);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(110, 56);
			this.btCancel.TabIndex = 41;
			this.btCancel.Text = "Abbrechen";
			this.btCancel.Click += this.btCancel_Click;
			this.timerAutoRepeat.Interval = 150;
			this.timerAutoRepeat.Tick += this.timerAutoRepeat_Tick;
			this.timerWaitAutoRepeat.Interval = 700;
			this.timerWaitAutoRepeat.Tick += this.timerWaitAutoRepeat_Tick;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(770, 384);
			base.ControlBox = false;
			base.Controls.Add(this.pnKeys);
			this.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			base.FormBorderStyle = FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			this.MaximumSize = new Size(776, 390);
			base.MinimizeBox = false;
			this.MinimumSize = new Size(776, 390);
			base.Name = "KeyPadForm";
			base.StartPosition = FormStartPosition.CenterScreen;
			base.FormClosing += this.KeyPadForm_FormClosing;
			this.pnKeys.ResumeLayout(false);
			this.pnKeys.PerformLayout();
			base.ResumeLayout(false);
		}

		public void ShowKeyPad(TextBox tB)
		{
			if (this.Text.Length == 0)
			{
				this.Text = this.Main.Rm.GetString("KeyPad");
			}
			if (this.Title != null && this.Title.Length > 0)
			{
				this.Text = this.Text + ": " + this.Title;
			}
			this.CB = null;
			this.TB = tB;
			this.NewText = this.TB.Text;
			this.lbOldValue.Text = this.TB.Text;
			this.tBNewValue.Text = this.TB.Text;
			this.tBNewValue.MaxLength = this.TB.MaxLength;
			this.TBSelectionStart = this.tBNewValue.Text.Length;
			this.tBNewValue.SelectionStart = this.tBNewValue.Text.Length;
			this.tBNewValue.Select();
			this.MenEna();
			base.ShowDialog();
		}

		public void ShowKeyPad(ComboBox cB)
		{
			if (this.Text.Length == 0)
			{
				this.Text = this.Main.Rm.GetString("KeyPad");
			}
			if (this.Title != null && this.Title.Length > 0)
			{
				this.Text = this.Text + ": " + this.Title;
			}
			this.TB = null;
			this.CB = cB;
			this.NewText = this.CB.Text;
			this.lbOldValue.Text = this.CB.Text;
			this.tBNewValue.Text = this.CB.Text;
			this.tBNewValue.MaxLength = this.CB.MaxLength;
			this.TBSelectionStart = this.tBNewValue.Text.Length;
			this.tBNewValue.SelectionStart = this.tBNewValue.Text.Length;
			this.tBNewValue.Select();
			this.MenEna();
			base.ShowDialog();
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("KeyPad");
			this.btCancel.Text = this.Main.Rm.GetString("btCancel");
			this.btApply.Text = this.Main.Rm.GetString("btApply");
			this.btBackspace.Text = this.Main.Rm.GetString("btBackspace");
			this.btSpace.Text = this.Main.Rm.GetString("btSpace");
			this.btSpace.Tag = " ";
			this.btCapsR.Text = this.Main.Rm.GetString("btShift");
			this.btCapsL.Text = this.Main.Rm.GetString("btShift");
		}

		private void MenEna()
		{
			if (this.AreCaps)
			{
				this.bt1.Text = this.Main.Rm.GetString("bt1").ToUpper();
				this.bt1.Tag = this.Main.Rm.GetString("bt1").ToUpper();
				this.bt2.Text = this.Main.Rm.GetString("bt2").ToUpper();
				this.bt2.Tag = this.Main.Rm.GetString("bt2").ToUpper();
				this.bt3.Text = this.Main.Rm.GetString("bt3").ToUpper();
				this.bt3.Tag = this.Main.Rm.GetString("bt3").ToUpper();
				this.bt4.Text = this.Main.Rm.GetString("bt4").ToUpper();
				this.bt4.Tag = this.Main.Rm.GetString("bt4").ToUpper();
				this.bt5.Text = this.Main.Rm.GetString("bt5").ToUpper();
				this.bt5.Tag = this.Main.Rm.GetString("bt5").ToUpper();
				this.bt6.Text = this.Main.Rm.GetString("bt6").ToUpper();
				this.bt6.Tag = this.Main.Rm.GetString("bt6").ToUpper();
				this.bt7.Text = this.Main.Rm.GetString("bt7").ToUpper();
				this.bt7.Tag = this.Main.Rm.GetString("bt7").ToUpper();
				this.bt8.Text = this.Main.Rm.GetString("bt8").ToUpper();
				this.bt8.Tag = this.Main.Rm.GetString("bt8").ToUpper();
				this.bt9.Text = this.Main.Rm.GetString("bt9").ToUpper();
				this.bt9.Tag = this.Main.Rm.GetString("bt9").ToUpper();
				this.bt0.Text = this.Main.Rm.GetString("bt0").ToUpper();
				this.bt0.Tag = this.Main.Rm.GetString("bt0").ToUpper();
				this.btA.Text = this.Main.Rm.GetString("btA").ToUpper();
				this.btA.Tag = this.Main.Rm.GetString("btA").ToUpper();
				this.btB.Text = this.Main.Rm.GetString("btB").ToUpper();
				this.btB.Tag = this.Main.Rm.GetString("btB").ToUpper();
				this.btC.Text = this.Main.Rm.GetString("btC").ToUpper();
				this.btC.Tag = this.Main.Rm.GetString("btC").ToUpper();
				this.btD.Text = this.Main.Rm.GetString("btD").ToUpper();
				this.btD.Tag = this.Main.Rm.GetString("btD").ToUpper();
				this.btE.Text = this.Main.Rm.GetString("btE").ToUpper();
				this.btE.Tag = this.Main.Rm.GetString("btE").ToUpper();
				this.btF.Text = this.Main.Rm.GetString("btF").ToUpper();
				this.btF.Tag = this.Main.Rm.GetString("btF").ToUpper();
				this.btG.Text = this.Main.Rm.GetString("btG").ToUpper();
				this.btG.Tag = this.Main.Rm.GetString("btG").ToUpper();
				this.btH.Text = this.Main.Rm.GetString("btH").ToUpper();
				this.btH.Tag = this.Main.Rm.GetString("btH").ToUpper();
				this.btI.Text = this.Main.Rm.GetString("btI").ToUpper();
				this.btI.Tag = this.Main.Rm.GetString("btI").ToUpper();
				this.btJ.Text = this.Main.Rm.GetString("btJ").ToUpper();
				this.btJ.Tag = this.Main.Rm.GetString("btJ").ToUpper();
				this.btK.Text = this.Main.Rm.GetString("btK").ToUpper();
				this.btK.Tag = this.Main.Rm.GetString("btK").ToUpper();
				this.btL.Text = this.Main.Rm.GetString("btL").ToUpper();
				this.btL.Tag = this.Main.Rm.GetString("btL").ToUpper();
				this.btM.Text = this.Main.Rm.GetString("btM").ToUpper();
				this.btM.Tag = this.Main.Rm.GetString("btM").ToUpper();
				this.btN.Text = this.Main.Rm.GetString("btN").ToUpper();
				this.btN.Tag = this.Main.Rm.GetString("btN").ToUpper();
				this.btO.Text = this.Main.Rm.GetString("btO").ToUpper();
				this.btO.Tag = this.Main.Rm.GetString("btO").ToUpper();
				this.btP.Text = this.Main.Rm.GetString("btP").ToUpper();
				this.btP.Tag = this.Main.Rm.GetString("btP").ToUpper();
				this.btQ.Text = this.Main.Rm.GetString("btQ").ToUpper();
				this.btQ.Tag = this.Main.Rm.GetString("btQ").ToUpper();
				this.btR.Text = this.Main.Rm.GetString("btR").ToUpper();
				this.btR.Tag = this.Main.Rm.GetString("btR").ToUpper();
				this.btS.Text = this.Main.Rm.GetString("btS").ToUpper();
				this.btS.Tag = this.Main.Rm.GetString("btS").ToUpper();
				this.btT.Text = this.Main.Rm.GetString("btT").ToUpper();
				this.btT.Tag = this.Main.Rm.GetString("btT").ToUpper();
				this.btU.Text = this.Main.Rm.GetString("btU").ToUpper();
				this.btU.Tag = this.Main.Rm.GetString("btU").ToUpper();
				this.btV.Text = this.Main.Rm.GetString("btV").ToUpper();
				this.btV.Tag = this.Main.Rm.GetString("btV").ToUpper();
				this.btW.Text = this.Main.Rm.GetString("btW").ToUpper();
				this.btW.Tag = this.Main.Rm.GetString("btW").ToUpper();
				this.btX.Text = this.Main.Rm.GetString("btX").ToUpper();
				this.btX.Tag = this.Main.Rm.GetString("btX").ToUpper();
				this.btY.Text = this.Main.Rm.GetString("btY").ToUpper();
				this.btY.Tag = this.Main.Rm.GetString("btY").ToUpper();
				this.btZ.Text = this.Main.Rm.GetString("btZ").ToUpper();
				this.btZ.Tag = this.Main.Rm.GetString("btZ").ToUpper();
				this.btMinus.Text = this.Main.Rm.GetString("btMinusDown");
				this.btMinus.Tag = this.Main.Rm.GetString("btMinusDown");
			}
			else
			{
				this.bt1.Text = this.Main.Rm.GetString("bt1").ToLower();
				this.bt1.Tag = this.Main.Rm.GetString("bt1").ToLower();
				this.bt2.Text = this.Main.Rm.GetString("bt2").ToLower();
				this.bt2.Tag = this.Main.Rm.GetString("bt2").ToLower();
				this.bt3.Text = this.Main.Rm.GetString("bt3").ToLower();
				this.bt3.Tag = this.Main.Rm.GetString("bt3").ToLower();
				this.bt4.Text = this.Main.Rm.GetString("bt4").ToLower();
				this.bt4.Tag = this.Main.Rm.GetString("bt4").ToLower();
				this.bt5.Text = this.Main.Rm.GetString("bt5").ToLower();
				this.bt5.Tag = this.Main.Rm.GetString("bt5").ToLower();
				this.bt6.Text = this.Main.Rm.GetString("bt6").ToLower();
				this.bt6.Tag = this.Main.Rm.GetString("bt6").ToLower();
				this.bt7.Text = this.Main.Rm.GetString("bt7").ToLower();
				this.bt7.Tag = this.Main.Rm.GetString("bt7").ToLower();
				this.bt8.Text = this.Main.Rm.GetString("bt8").ToLower();
				this.bt8.Tag = this.Main.Rm.GetString("bt8").ToLower();
				this.bt9.Text = this.Main.Rm.GetString("bt9").ToLower();
				this.bt9.Tag = this.Main.Rm.GetString("bt9").ToLower();
				this.bt0.Text = this.Main.Rm.GetString("bt0").ToLower();
				this.bt0.Tag = this.Main.Rm.GetString("bt0").ToLower();
				this.btA.Text = this.Main.Rm.GetString("btA").ToLower();
				this.btA.Tag = this.Main.Rm.GetString("btA").ToLower();
				this.btB.Text = this.Main.Rm.GetString("btB").ToLower();
				this.btB.Tag = this.Main.Rm.GetString("btB").ToLower();
				this.btC.Text = this.Main.Rm.GetString("btC").ToLower();
				this.btC.Tag = this.Main.Rm.GetString("btC").ToLower();
				this.btD.Text = this.Main.Rm.GetString("btD").ToLower();
				this.btD.Tag = this.Main.Rm.GetString("btD").ToLower();
				this.btE.Text = this.Main.Rm.GetString("btE").ToLower();
				this.btE.Tag = this.Main.Rm.GetString("btE").ToLower();
				this.btF.Text = this.Main.Rm.GetString("btF").ToLower();
				this.btF.Tag = this.Main.Rm.GetString("btF").ToLower();
				this.btG.Text = this.Main.Rm.GetString("btG").ToLower();
				this.btG.Tag = this.Main.Rm.GetString("btG").ToLower();
				this.btH.Text = this.Main.Rm.GetString("btH").ToLower();
				this.btH.Tag = this.Main.Rm.GetString("btH").ToLower();
				this.btI.Text = this.Main.Rm.GetString("btI").ToLower();
				this.btI.Tag = this.Main.Rm.GetString("btI").ToLower();
				this.btJ.Text = this.Main.Rm.GetString("btJ").ToLower();
				this.btJ.Tag = this.Main.Rm.GetString("btJ").ToLower();
				this.btK.Text = this.Main.Rm.GetString("btK").ToLower();
				this.btK.Tag = this.Main.Rm.GetString("btK").ToLower();
				this.btL.Text = this.Main.Rm.GetString("btL").ToLower();
				this.btL.Tag = this.Main.Rm.GetString("btL").ToLower();
				this.btM.Text = this.Main.Rm.GetString("btM").ToLower();
				this.btM.Tag = this.Main.Rm.GetString("btM").ToLower();
				this.btN.Text = this.Main.Rm.GetString("btN").ToLower();
				this.btN.Tag = this.Main.Rm.GetString("btN").ToLower();
				this.btO.Text = this.Main.Rm.GetString("btO").ToLower();
				this.btO.Tag = this.Main.Rm.GetString("btO").ToLower();
				this.btP.Text = this.Main.Rm.GetString("btP").ToLower();
				this.btP.Tag = this.Main.Rm.GetString("btP").ToLower();
				this.btQ.Text = this.Main.Rm.GetString("btQ").ToLower();
				this.btQ.Tag = this.Main.Rm.GetString("btQ").ToLower();
				this.btR.Text = this.Main.Rm.GetString("btR").ToLower();
				this.btR.Tag = this.Main.Rm.GetString("btR").ToLower();
				this.btS.Text = this.Main.Rm.GetString("btS").ToLower();
				this.btS.Tag = this.Main.Rm.GetString("btS").ToLower();
				this.btT.Text = this.Main.Rm.GetString("btT").ToLower();
				this.btT.Tag = this.Main.Rm.GetString("btT").ToLower();
				this.btU.Text = this.Main.Rm.GetString("btU").ToLower();
				this.btU.Tag = this.Main.Rm.GetString("btU").ToLower();
				this.btV.Text = this.Main.Rm.GetString("btV").ToLower();
				this.btV.Tag = this.Main.Rm.GetString("btV").ToLower();
				this.btW.Text = this.Main.Rm.GetString("btW").ToLower();
				this.btW.Tag = this.Main.Rm.GetString("btW").ToLower();
				this.btX.Text = this.Main.Rm.GetString("btX").ToLower();
				this.btX.Tag = this.Main.Rm.GetString("btX").ToLower();
				this.btY.Text = this.Main.Rm.GetString("btY").ToLower();
				this.btY.Tag = this.Main.Rm.GetString("btY").ToLower();
				this.btZ.Text = this.Main.Rm.GetString("btZ").ToLower();
				this.btZ.Tag = this.Main.Rm.GetString("btZ").ToLower();
				this.btMinus.Text = this.Main.Rm.GetString("btMinusUp");
				this.btMinus.Tag = this.Main.Rm.GetString("btMinusUp");
			}
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.Text = "";
			base.Close();
			Button button = this.btComma;
			Button button2 = this.btFullStop;
			bool enabled = button2.Enabled = true;
			button.Enabled = enabled;
		}

		private void btApply_Click(object sender, EventArgs e)
		{
			if (this.TB != null)
			{
				this.TB.Text = this.NewText;
			}
			else if (this.CB != null)
			{
				this.CB.Text = this.NewText;
			}
			this.Text = "";
			this.Main.SettingsChanged();
			base.Close();
			Button button = this.btComma;
			Button button2 = this.btFullStop;
			bool enabled = button2.Enabled = true;
			button.Enabled = enabled;
		}

		private void textKey_Click(object sender, EventArgs e)
		{
			try
			{
				try
				{
					this.recentActiveControl = base.ActiveControl.Tag.ToString();
				}
				catch
				{
				}
				this.tBNewValue.Focus();
				this.tBNewValue.Select(this.TBSelectionStart, 0);
				if (this.Main.CommonFunctions.GetCapsLockState())
				{
					MessageBox.Show(this.Main.Rm.GetString("MbKeyLockActive"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else if (this.recentActiveControl == "{BS}")
				{
					if (this.TBSelectionStart > 0)
					{
						string text = this.tBNewValue.Text.Remove(this.TBSelectionStart - 1, 1);
						try
						{
							this.tBNewValue.Text = text;
						}
						catch (Exception)
						{
						}
					}
				}
				else
				{
					this.tBNewValue.Text = this.tBNewValue.Text.Substring(0, this.TBSelectionStart) + this.recentActiveControl + this.tBNewValue.Text.Substring(this.TBSelectionStart);
				}
			}
			catch (Exception)
			{
			}
		}

		private void tBNewValue_TextChanged(object sender, EventArgs e)
		{
			if (this.tBNewValue.Text.Length > this.tBNewValue.MaxLength)
			{
				this.tBNewValue.Text = this.NewText;
				this.tBNewValue.SelectionStart = this.TBSelectionStart;
			}
			else if (this.tBNewValue.Text != this.NewText)
			{
				this.TextCheck();
			}
		}

		private void TextCheck()
		{
			char[] trimChars = new char[1]
			{
				' '
			};
			this.tBNewValue.Text = this.tBNewValue.Text.TrimStart(trimChars);
			if (this.tBNewValue.Text.Length < this.NewText.Length)
			{
				if (this.tBNewValue.SelectionStart == 0 && this.TBSelectionStart > 0)
				{
					this.tBNewValue.SelectionStart = this.TBSelectionStart - 1;
				}
				this.TBSelectionStart = this.tBNewValue.SelectionStart;
			}
			else if (this.tBNewValue.Text == this.NewText)
			{
				this.tBNewValue.SelectionStart = this.TBSelectionStart;
			}
			else
			{
				this.tBNewValue.SelectionStart = this.TBSelectionStart + 1;
			}
			string text = this.tBNewValue.Text;
			if (this.tBNewValue.Text.Length > 0)
			{
				for (int i = this.tBNewValue.Text.Length - 1; i < this.tBNewValue.Text.Length; i++)
				{
					if (text[i] != '-' && text[i] != '_' && text[i] != ' ' && text[i] != ',' && text[i] != '.' && (!char.IsLetterOrDigit(text, i) || text[i] == 'Ö' || text[i] == 'ö' || text[i] == 'Ä' || text[i] == 'ä' || text[i] == 'Ü' || text[i] == 'ü' || text[i] == 'ß'))
					{
						this.tBNewValue.Text = this.NewText;
						this.tBNewValue.SelectionStart = this.TBSelectionStart;
						return;
					}
				}
			}
			this.NewText = this.tBNewValue.Text;
			this.TBSelectionStart = this.tBNewValue.SelectionStart;
		}

		private void tBNewValue_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode != Keys.Left && e.KeyCode != Keys.Right)
			{
				return;
			}
			this.TBSelectionStart = this.tBNewValue.SelectionStart;
		}

		private void Cabs_Click(object sender, EventArgs e)
		{
			if (this.AreCaps)
			{
				this.AreCaps = false;
			}
			else
			{
				this.AreCaps = true;
			}
			this.MenEna();
		}

		private void tBNewValue_MouseDown(object sender, MouseEventArgs e)
		{
			this.TBSelectionStart = this.tBNewValue.SelectionStart;
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (msg.WParam.ToInt32() == 27)
			{
				base.Close();
				this.Text = "";
			}
			else if (msg.WParam.ToInt32() == 13)
			{
				this.btApply_Click(null, EventArgs.Empty);
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}

		private void KeyPadForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			this.Title = "";
		}

		private void btLeft_Click(object sender, EventArgs e)
		{
			if (this.TBSelectionStart > 0)
			{
				this.tBNewValue.SelectionStart = --this.TBSelectionStart;
			}
			this.tBNewValue.SelectionLength = 0;
			this.tBNewValue.Select();
		}

		private void btRight_Click(object sender, EventArgs e)
		{
			if (this.TBSelectionStart < this.tBNewValue.Text.Length)
			{
				this.tBNewValue.SelectionStart = ++this.TBSelectionStart;
			}
			this.tBNewValue.SelectionLength = 0;
			this.tBNewValue.Select();
		}

		private void timerWaitAutoRepeat_Tick(object sender, EventArgs e)
		{
			this.timerAutoRepeat.Start();
			this.timerWaitAutoRepeat.Stop();
		}

		private void timerAutoRepeat_Tick(object sender, EventArgs e)
		{
			this.textKey_Click(null, EventArgs.Empty);
		}

		private void bt_MouseDown(object sender, MouseEventArgs e)
		{
			this.timerWaitAutoRepeat.Start();
		}

		private void bt_MouseLeave(object sender, EventArgs e)
		{
			this.timerWaitAutoRepeat.Stop();
			this.timerAutoRepeat.Stop();
		}

		private void bt_MouseUp(object sender, MouseEventArgs e)
		{
			this.timerWaitAutoRepeat.Stop();
			this.timerAutoRepeat.Stop();
		}
	}
}
