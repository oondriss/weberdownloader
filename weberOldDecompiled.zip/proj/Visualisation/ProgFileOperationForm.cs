using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class ProgFileOperationForm : Form
	{
		public const int FILE_OPERATION_NONE = 0;

		public const int FILE_OPERATION_LOAD = 1;

		public const int FILE_OPERATION_SAVE = 2;

		public const int FILE_OPERATION_PRG_LOAD = 3;

		public const int FILE_OPERATION_PRG_SAVE = 4;

		public const int MENU_FOR_SPCONST = 1;

		public const int MENU_FOR_PPROG = 2;

		private MainForm Main;

		public int FileOperationType;

		private Button btLoad;

		private Button btSave;

		private Button btCancel;

		private Button btProgSave;

		private Button btProgLoad;

		private GroupBox gBDefaultDir;

		private Button btCangeDefautDir;

		private CheckBox chBUseDefault;

		private Container components;

		public ProgFileOperationForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.btLoad = new Button();
			this.btSave = new Button();
			this.btCancel = new Button();
			this.btProgSave = new Button();
			this.btProgLoad = new Button();
			this.gBDefaultDir = new GroupBox();
			this.btCangeDefautDir = new Button();
			this.chBUseDefault = new CheckBox();
			this.gBDefaultDir.SuspendLayout();
			base.SuspendLayout();
			this.btLoad.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btLoad.Location = new Point(8, 8);
			this.btLoad.Name = "btLoad";
			this.btLoad.Size = new Size(112, 80);
			this.btLoad.TabIndex = 0;
			this.btLoad.Text = "Laden aus Datei";
			this.btLoad.Click += this.btLoad_Click;
			this.btSave.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btSave.Location = new Point(128, 8);
			this.btSave.Name = "btSave";
			this.btSave.Size = new Size(112, 80);
			this.btSave.TabIndex = 1;
			this.btSave.Text = "Speichern in Datei";
			this.btSave.Click += this.btSave_Click;
			this.btCancel.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCancel.Location = new Point(19, 319);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(200, 40);
			this.btCancel.TabIndex = 2;
			this.btCancel.Text = "Abbrechen";
			this.btCancel.Click += this.btCancel_Click;
			this.btProgSave.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btProgSave.Location = new Point(128, 96);
			this.btProgSave.Name = "btProgSave";
			this.btProgSave.Size = new Size(112, 80);
			this.btProgSave.TabIndex = 5;
			this.btProgSave.Text = "Programm speichern";
			this.btProgSave.Click += this.btPrgSave_Click;
			this.btProgLoad.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btProgLoad.Location = new Point(8, 96);
			this.btProgLoad.Name = "btProgLoad";
			this.btProgLoad.Size = new Size(112, 80);
			this.btProgLoad.TabIndex = 4;
			this.btProgLoad.Text = "Programm laden";
			this.btProgLoad.Click += this.btPrgLoad_Click;
			this.gBDefaultDir.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.gBDefaultDir.Controls.Add(this.btCangeDefautDir);
			this.gBDefaultDir.Controls.Add(this.chBUseDefault);
			this.gBDefaultDir.FlatStyle = FlatStyle.System;
			this.gBDefaultDir.Font = new Font("Arial Unicode MS", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.gBDefaultDir.Location = new Point(9, 192);
			this.gBDefaultDir.Name = "gBDefaultDir";
			this.gBDefaultDir.Size = new Size(229, 117);
			this.gBDefaultDir.TabIndex = 7;
			this.gBDefaultDir.TabStop = false;
			this.gBDefaultDir.Text = "groupBox1";
			this.btCangeDefautDir.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCangeDefautDir.Location = new Point(10, 68);
			this.btCangeDefautDir.Name = "btCangeDefautDir";
			this.btCangeDefautDir.Size = new Size(200, 40);
			this.btCangeDefautDir.TabIndex = 6;
			this.btCangeDefautDir.Text = "Change default directory";
			this.btCangeDefautDir.Click += this.btCangeDefautDir_Click;
			this.chBUseDefault.AutoSize = true;
			this.chBUseDefault.Font = new Font("Arial Unicode MS", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.chBUseDefault.Location = new Point(14, 38);
			this.chBUseDefault.Name = "chBUseDefault";
			this.chBUseDefault.Size = new Size(131, 19);
			this.chBUseDefault.TabIndex = 5;
			this.chBUseDefault.Text = "Use Default Directory";
			this.chBUseDefault.UseVisualStyleBackColor = true;
			this.chBUseDefault.CheckedChanged += this.chBUseDefault_CheckedChanged;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(250, 392);
			base.ControlBox = false;
			base.Controls.Add(this.gBDefaultDir);
			base.Controls.Add(this.btProgSave);
			base.Controls.Add(this.btProgLoad);
			base.Controls.Add(this.btCancel);
			base.Controls.Add(this.btSave);
			base.Controls.Add(this.btLoad);
			this.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.MaximizeBox = false;
			this.MaximumSize = new Size(700, 408);
			base.MinimizeBox = false;
			this.MinimumSize = new Size(266, 408);
			base.Name = "ProgFileOperationForm";
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.CenterScreen;
			base.Load += this.ProgFileOperationForm_Load;
			this.gBDefaultDir.ResumeLayout(false);
			this.gBDefaultDir.PerformLayout();
			base.ResumeLayout(false);
		}

		private void ProgFileOperationForm_Load(object sender, EventArgs e)
		{
		}

		public void ShowWindow(int num)
		{
			this.btProgLoad.Text = this.Main.Rm.GetString("LoadSingleProgFromFile") + " " + num.ToString();
			this.btProgSave.Text = this.Main.Rm.GetString("SaveSingleProgToFile") + " " + num.ToString();
			this.gBDefaultDir.Text = Settings.Default.ProgFileOperationDefaultDirectory;
			this.chBUseDefault.Checked = Settings.Default.ProgFileOperationDefaultUse;
			this.btCangeDefautDir.Enabled = Settings.Default.ProgFileOperationDefaultUse;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_ProgramOverviewForm || this.Main.IsOfflineVersion)
			{
				this.btLoad.Enabled = true;
				this.btProgLoad.Enabled = true;
			}
			else
			{
				this.btLoad.Enabled = false;
				this.btProgLoad.Enabled = false;
			}
			base.ShowDialog();
		}

		public void Cancel()
		{
			if (base.Visible)
			{
				this.FileOperationType = 0;
				base.Hide();
			}
		}

		private void menEna()
		{
			if (Settings.Default.ProgFileOperationDefaultUse)
			{
				this.btCangeDefautDir.Enabled = true;
			}
			else
			{
				this.btCangeDefautDir.Enabled = false;
			}
		}

		public void SetLanguageTexts(int kind)
		{
			this.Text = this.Main.Rm.GetString("FileOperationMenu");
			this.btCancel.Text = this.Main.Rm.GetString("Cancel");
			this.btLoad.Text = this.Main.Rm.GetString("LoadPProgFromFile");
			this.btSave.Text = this.Main.Rm.GetString("SavePProgToFile");
			this.btCangeDefautDir.Text = this.Main.Rm.GetString("btChangeDefaultDir");
			this.chBUseDefault.Text = this.Main.Rm.GetString("chBUseDefaultDir");
		}

		private void btLoad_Click(object sender, EventArgs e)
		{
			this.FileOperationType = 1;
			base.Close();
		}

		private void btSave_Click(object sender, EventArgs e)
		{
			this.FileOperationType = 2;
			base.Close();
		}

		private void btPrgLoad_Click(object sender, EventArgs e)
		{
			this.FileOperationType = 3;
			base.Close();
		}

		private void btPrgSave_Click(object sender, EventArgs e)
		{
			this.FileOperationType = 4;
			base.Close();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.FileOperationType = 0;
			base.Close();
		}

		private void btCangeDefautDir_Click(object sender, EventArgs e)
		{
			FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
			folderBrowserDialog.SelectedPath = Settings.Default.ProgFileOperationDefaultDirectory;
			if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
			{
				this.gBDefaultDir.Text = folderBrowserDialog.SelectedPath;
				Settings.Default.ProgFileOperationDefaultDirectory = folderBrowserDialog.SelectedPath;
				Settings.Default.Save();
			}
		}

		private void chBUseDefault_CheckedChanged(object sender, EventArgs e)
		{
			if (!this.chBUseDefault.Checked)
			{
				Settings.Default.ProgFileOperationDefaultUse = false;
			}
			else
			{
				string progFileOperationDefaultDirectory = Settings.Default.ProgFileOperationDefaultDirectory;
				Settings.Default.ProgFileOperationDefaultUse = true;
				if (Settings.Default.ProgFileOperationDefaultDirectory.Length == 0)
				{
					this.btCangeDefautDir_Click(null, null);
					if (Settings.Default.ProgFileOperationDefaultDirectory.Length == 0)
					{
						this.chBUseDefault.Checked = false;
					}
				}
			}
			Settings.Default.Save();
			this.menEna();
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (msg.WParam.ToInt32() == 27)
			{
				base.Close();
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}
	}
}
