namespace Visualisation
{
	public struct S_Passcode
	{
		public string shortName;

		public uint passcode;

		public byte level;
	}
}
