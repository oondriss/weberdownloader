namespace Visualisation
{
	public class EMC_Class
	{
	}
}
