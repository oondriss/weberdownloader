using System;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Visualisation
{
	public class C_SimplePrint
	{
		public const int PRINTMARGIN = 50;

		public const string PRINT_TAB = "§t$";

		public const string PRINT_LEFT = "§z$";

		public const string PRINT_NORMAL = "§n$";

		public const string PRINT_FONT_LARGE = "§l$";

		public const string PRINT_FONT_XL = "§x$";

		public const string PRINT_BOLD = "§b$";

		public const string PRINT_ITALIC = "§i$";

		public const string PRINT_UNDERLINE = "§u$";

		public const string PRINT_NEWPAGE = "§p$";

		public StringBuilder Sb;

		public string DocName;

		private FontStyle FntStyle;

		private float FntSize;

		private Font Fnt;

		private int TabPos;

		private bool Landscape;

		private bool Wrap;

		private PrintDocument printDocument;

		private PrintDialog printDialog;

		private bool resetSettings = true;

		public C_SimplePrint()
		{
			this.Sb = new StringBuilder();
			this.DocName = "Document";
			this.FntStyle = FontStyle.Regular;
			this.FntSize = 11f;
			this.Fnt = new Font("Arial Unicode MS", this.FntSize, this.FntStyle, GraphicsUnit.Pixel);
			this.TabPos = 0;
			this.printDocument = new PrintDocument();
			this.printDialog = new PrintDialog();
			this.printDocument.PrintPage += this.printDocument_PrintPage;
			this.printDialog.Document = this.printDocument;
		}

		public void Print(bool landscape, bool wrap)
		{
			this.Landscape = landscape;
			this.Wrap = wrap;
			this.resetSettings = false;
			this.Print();
			this.resetSettings = true;
		}

		public void Print()
		{
			if (this.resetSettings)
			{
				this.Landscape = false;
				this.Wrap = false;
			}
			if (this.printDialog.ShowDialog() == DialogResult.OK)
			{
				this.printDocument.DefaultPageSettings.Margins.Bottom = 50;
				this.printDocument.DefaultPageSettings.Margins.Left = 50;
				this.printDocument.DefaultPageSettings.Margins.Right = 50;
				this.printDocument.DefaultPageSettings.Margins.Top = 50;
				this.printDocument.DocumentName = this.DocName;
				this.printDocument.DefaultPageSettings.Landscape = this.Landscape;
				this.printDocument.Print();
			}
		}

		public bool SaveFile(string filename)
		{
			StringBuilder stringBuilder = new StringBuilder();
			string empty = string.Empty;
			try
			{
				StreamWriter streamWriter = new StreamWriter(filename);
				if (this.Sb.Length == 0)
				{
					streamWriter.WriteLine("Friction Test: No Parameters!");
				}
				while (this.Sb.Length > 0)
				{
					switch (this.Sb[0])
					{
					case '§':
						empty = this.Sb[0].ToString() + this.Sb[1].ToString() + this.Sb[2].ToString();
						switch (empty)
						{
						case "§b$":
							this.FntStyle = FontStyle.Regular;
							break;
						case "§i$":
							this.FntStyle = FontStyle.Italic;
							break;
						case "§u$":
							this.FntStyle = FontStyle.Underline;
							break;
						case "§n$":
							this.FntSize = 11f;
							this.FntStyle = FontStyle.Regular;
							break;
						case "§l$":
							this.FntSize = 16f;
							break;
						case "§x$":
							this.FntSize = 20f;
							break;
						case "§t$":
							stringBuilder.Append("   ");
							this.Sb.Remove(0, 2);
							break;
						case "§p$":
							streamWriter.WriteLine(stringBuilder.ToString());
							stringBuilder.Remove(0, stringBuilder.Length);
							break;
						default:
							stringBuilder.Append(this.Sb[0].ToString());
							this.Sb.Remove(0, 1);
							break;
						case "§z$":
							break;
						}
						this.Sb.Remove(0, 3);
						break;
					case '\n':
						streamWriter.WriteLine(stringBuilder.ToString());
						stringBuilder.Remove(0, stringBuilder.Length);
						this.Sb.Remove(0, 1);
						break;
					default:
						stringBuilder.Append(this.Sb[0].ToString());
						this.Sb.Remove(0, 1);
						break;
					}
					if (this.Sb.Length == 0 && stringBuilder.Length > 0)
					{
						streamWriter.WriteLine(stringBuilder.ToString());
					}
				}
				streamWriter.Close();
				streamWriter.Dispose();
				return true;
			}
			catch (Exception ex)
			{
				MessageBox.Show("Could not open file! " + ex.Message, "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
		}

		private void printDocument_PrintPage(object sender, PrintPageEventArgs e)
		{
			StringBuilder stringBuilder = new StringBuilder();
			string empty = string.Empty;
			float num = (float)e.MarginBounds.Left + (float)(e.PageBounds.Width * this.TabPos) / 20f;
			float num2 = (float)e.MarginBounds.Top;
			Graphics graphics = e.Graphics;
			while (this.Sb.Length > 0)
			{
				switch (this.Sb[0])
				{
				case '§':
					empty = this.Sb[0].ToString() + this.Sb[1].ToString() + this.Sb[2].ToString();
					switch (empty)
					{
					case "§b$":
						this.FntStyle = FontStyle.Regular;
						break;
					case "§i$":
						this.FntStyle = FontStyle.Italic;
						break;
					case "§u$":
						this.FntStyle = FontStyle.Underline;
						break;
					case "§n$":
						this.FntSize = 11f;
						this.FntStyle = FontStyle.Regular;
						break;
					case "§l$":
						this.FntSize = 16f;
						break;
					case "§x$":
						this.FntSize = 20f;
						break;
					case "§z$":
						num = (float)e.MarginBounds.Left;
						break;
					case "§t$":
						graphics.DrawString(stringBuilder.ToString(), this.Fnt, Brushes.Black, num, num2);
						stringBuilder.Remove(0, stringBuilder.Length);
						this.TabPos = int.Parse(this.Sb[3].ToString() + this.Sb[4].ToString());
						num = (float)e.MarginBounds.Left + (float)(e.PageBounds.Width * this.TabPos) / 20f;
						this.Sb.Remove(0, 2);
						break;
					case "§p$":
						graphics.DrawString(stringBuilder.ToString(), this.Fnt, Brushes.Black, num, num2);
						this.Sb.Remove(0, 3);
						if (this.Sb.Length > 0)
						{
							e.HasMorePages = true;
						}
						return;
					default:
						stringBuilder.Append(this.Sb[0].ToString());
						this.Sb.Remove(0, 1);
						break;
					}
					this.Sb.Remove(0, 3);
					this.Fnt = new Font("Arial Unicode MS", this.FntSize, this.FntStyle, GraphicsUnit.Pixel);
					break;
				case '\n':
					graphics.DrawString(stringBuilder.ToString(), this.Fnt, Brushes.Black, num, num2);
					num2 += graphics.MeasureString(stringBuilder.ToString(), this.Fnt).Height;
					stringBuilder.Remove(0, stringBuilder.Length);
					this.Sb.Remove(0, 1);
					if (!(num2 + graphics.MeasureString("A", this.Fnt).Height > (float)e.MarginBounds.Bottom))
					{
						break;
					}
					e.HasMorePages = true;
					return;
				default:
				{
					stringBuilder.Append(this.Sb[0].ToString());
					this.Sb.Remove(0, 1);
					SizeF sizeF = e.Graphics.MeasureString(stringBuilder.ToString(), this.Fnt);
					if (this.Wrap && num + sizeF.Width > (float)(e.MarginBounds.Right - 50) && this.remainingCharacters(this.Sb.ToString()) > 10)
					{
						string value = "\n§t$05";
						this.Sb.Insert(0, value);
					}
					break;
				}
				}
				if (this.Sb.Length == 0 && stringBuilder.Length > 0)
				{
					graphics.DrawString(stringBuilder.ToString(), this.Fnt, Brushes.Black, num, num2);
				}
				else if (this.Wrap && num > (float)(e.MarginBounds.Right - 50) && this.remainingCharacters(this.Sb.ToString()) > 10)
				{
					string value2 = "\n§t$05";
					this.Sb.Insert(0, value2);
				}
			}
		}

		private int remainingCharacters(string sb)
		{
			for (int i = 0; i < sb.Length; i++)
			{
				if (sb[i] == '\n' || sb[i] == '§')
				{
					return i + 1;
				}
			}
			return sb.Length;
		}

		public void SetStyleBold()
		{
			this.Sb.Append("§b$");
		}

		public void SetStyleItalic()
		{
			this.Sb.Append("§i$");
		}

		public void SetStyleUnderline()
		{
			this.Sb.Append("§u$");
		}

		public void ResetStyle()
		{
			this.Sb.Append("§n$");
		}

		public void SetSizeLarge()
		{
			this.Sb.Append("§l$");
		}

		public void SetSizeXL()
		{
			this.Sb.Append("§x$");
		}

		public void SetNewPage()
		{
			this.Sb.Append("§p$");
		}

		public void SetNewLine()
		{
			this.Sb.Append("\n");
		}

		public void SetLeft()
		{
			this.Sb.Append("§z$");
		}

		public void SetTab(int xtab)
		{
			if (xtab >= 0)
			{
				if (xtab > 19)
				{
					xtab = 19;
				}
				this.Sb.Append("§t$");
				if (xtab < 10)
				{
					this.Sb.Append("0" + xtab.ToString());
				}
				else
				{
					this.Sb.Append(xtab.ToString());
				}
			}
		}
	}
}
