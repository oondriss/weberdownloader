using System;
using System.Runtime.InteropServices;

namespace Visualisation
{
	public class C_CommonFunctions
	{
		private MainForm Main;

		[DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
		public static extern short GetKeyState(int keyCode);

		public C_CommonFunctions(MainForm main)
		{
			this.Main = main;
		}

		public bool GetCapsLockState()
		{
			return ((ushort)C_CommonFunctions.GetKeyState(20) & 0xFFFF) != 0;
		}

		public string UShortToString(ushort[] letters)
		{
			char[] array = new char[letters.Length];
			letters.CopyTo(array, 0);
			int i;
			for (i = 0; i < letters.Length && letters[i] != 0; i++)
			{
			}
			string text = new string(array);
			return text.Remove(i, letters.Length - i);
		}

		public string ByteToString(byte[] letters)
		{
			char[] array = new char[letters.Length];
			letters.CopyTo(array, 0);
			int i;
			for (i = 0; i < letters.Length && letters[i] != 0; i++)
			{
			}
			string text = new string(array);
			return text.Remove(i, letters.Length - i);
		}

		public string ByteToAlphanumericString(byte[] letters)
		{
			char[] array = new char[letters.Length];
			letters.CopyTo(array, 0);
			for (int i = 0; i < letters.Length && letters[i] != 0; i++)
			{
			}
			string text = new string(array);
			for (int i = 0; i < text.Length; i++)
			{
				if (text[i] != '-' && text[i] != '_' && text[i] != ' ' && (!char.IsLetterOrDigit(text, i) || text[i] == 'Ö' || text[i] == 'ö' || text[i] == 'Ä' || text[i] == 'ä' || text[i] == 'Ü' || text[i] == 'ü' || text[i] == 'ß'))
				{
					text = text.Replace(text[i], ' ');
				}
			}
			return text;
		}

		public void StringToUShort(ref ushort[] array, string text, int length)
		{
			char[] array2 = new char[length];
			Array.Clear(array2, 0, length);
			for (int i = 0; i < length; i++)
			{
				if (text == null)
				{
					break;
				}
				if (i >= text.Length)
				{
					break;
				}
				array2[i] = text[i];
			}
			array2.CopyTo(array, 0);
		}

		public void StringToByte(ref byte[] array, string text, int length)
		{
			Array.Clear(array, 0, length);
			for (int i = 0; i < length - 1; i++)
			{
				if (text == null)
				{
					break;
				}
				if (i >= text.Length)
				{
					break;
				}
				char value = text[i];
				array[i] = Convert.ToByte(value);
			}
		}

		public string GetSwitchName(ushort param)
		{
			switch (param)
			{
			case 1:
				return this.Main.Rm.GetString("Torque") + string.Empty;
			case 3:
				return this.Main.Rm.GetString("FilteredTorque") + string.Empty;
			case 2:
				return this.Main.Rm.GetString("RelativeTorque") + string.Empty;
			case 11:
				return this.Main.Rm.GetString("M360Follow") + string.Empty;
			case 4:
				return this.Main.Rm.GetString("Gradient") + string.Empty;
			case 5:
				return this.Main.Rm.GetString("Angle") + string.Empty;
			case 6:
				return this.Main.Rm.GetString("Time") + string.Empty;
			case 7:
				return this.Main.Rm.GetString("AnaDepth") + string.Empty;
			case 10:
				return this.Main.Rm.GetString("DepthGrad") + string.Empty;
			case 8:
				return this.Main.Rm.GetString("AnaSignal") + string.Empty;
			case 9:
				return this.Main.Rm.GetString("DigitalSignal") + string.Empty;
			case 50:
				return this.Main.Rm.GetString("Torque") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
			case 51:
				return this.Main.Rm.GetString("FilteredTorque") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
			case 52:
				return this.Main.Rm.GetString("Gradient") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
			case 53:
				return this.Main.Rm.GetString("AnaDepth") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
			case 55:
				return this.Main.Rm.GetString("DepthGrad") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
			case 54:
				return this.Main.Rm.GetString("AnaSignal") + " (" + this.Main.Rm.GetString("FromAbove") + ")";
			case 1000:
				return this.Main.Rm.GetString("JumpOkTo") + string.Empty;
			case 1001:
				return this.Main.Rm.GetString("JumpNokTo") + string.Empty;
			case 1002:
				return this.Main.Rm.GetString("JumpAlwaysTo") + string.Empty;
			case 1010:
				return this.Main.Rm.GetString("Stop") + string.Empty;
			case 1011:
				return this.Main.Rm.GetString("StopOk") + string.Empty;
			case 1012:
				return this.Main.Rm.GetString("StopNok") + string.Empty;
			case 1020:
				return this.Main.Rm.GetString("ResetAngle") + string.Empty;
			case 1030:
				return this.Main.Rm.GetString("SetDigOut") + string.Empty;
			case 1040:
				return this.Main.Rm.GetString("ResetADepth") + string.Empty;
			default:
				return string.Empty;
			}
		}

		public string GetSwitchUnit(ushort param)
		{
			switch (param)
			{
			case 1:
				return this.Main.TorqueUnitName;
			case 3:
				return this.Main.TorqueUnitName;
			case 2:
				return this.Main.TorqueUnitName;
			case 11:
				return this.Main.TorqueUnitName;
			case 4:
				return this.Main.TorqueUnitName + "/" + this.Main.Rm.GetString("Degree");
			case 5:
				return this.Main.Rm.GetString("Degree") + string.Empty;
			case 6:
				return this.Main.Rm.GetString("Second") + string.Empty;
			case 7:
				return this.Main.Rm.GetString("Milimeter") + string.Empty;
			case 10:
				return this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second");
			case 8:
				return string.Empty;
			case 9:
				return string.Empty;
			case 50:
				return this.Main.TorqueUnitName;
			case 51:
				return this.Main.TorqueUnitName;
			case 52:
				return this.Main.TorqueUnitName + "/" + this.Main.Rm.GetString("Degree");
			case 53:
				return this.Main.Rm.GetString("Milimeter");
			case 55:
				return this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second");
			case 54:
				return string.Empty;
			default:
				return string.Empty;
			}
		}

		public string GetResName(byte result)
		{
			switch (result)
			{
			case 1:
				return this.Main.Rm.GetString("Torque");
			case 2:
				return this.Main.Rm.GetString("MaxTorque");
			case 3:
				return this.Main.Rm.GetString("FilteredTorque");
			case 4:
				return this.Main.Rm.GetString("Gradient");
			case 5:
				return this.Main.Rm.GetString("Angle");
			case 6:
				return this.Main.Rm.GetString("Time");
			case 7:
				return this.Main.Rm.GetString("AnaDepth");
			case 9:
				return this.Main.Rm.GetString("DigitalSignal");
			case 12:
				return this.Main.Rm.GetString("DepthGrad");
			case 10:
				return this.Main.Rm.GetString("DelayTorque");
			case 11:
				return this.Main.Rm.GetString("M360Follow");
			case 8:
				return this.Main.Rm.GetString("AnaSignal");
			default:
				return this.Main.Rm.GetString("NotValid");
			}
		}

		public string GetUnlocalizedResName(byte result)
		{
			switch (result)
			{
			case 1:
				return "Torque";
			case 2:
				return "MaximumTorque";
			case 3:
				return "FilteredTorque";
			case 4:
				return "TorqueGradient";
			case 5:
				return "Angle";
			case 6:
				return "Time";
			case 7:
				return "AnalogDepth";
			case 9:
				return "DigitalSignal";
			case 12:
				return "DepthGradient";
			case 10:
				return "Torque@-360°";
			case 11:
				return "DelayTorque";
			case 8:
				return "AnalogSignal";
			default:
				return "NotValid";
			}
		}

		public float GetResFactor(byte result)
		{
			switch (result)
			{
			case 1:
				return 1f;
			case 2:
				return 1f;
			case 3:
				return 1f;
			case 4:
				return 1f;
			case 5:
				return 0f;
			case 6:
				return 0f;
			case 7:
				return 0f;
			case 9:
				return 0f;
			case 12:
				return 0f;
			case 10:
				return 1f;
			case 11:
				return 1f;
			case 8:
				return 0f;
			default:
				return 0f;
			}
		}

		public string GetResUnit(byte result, string torqueUnit)
		{
			switch (result)
			{
			case 1:
				return torqueUnit;
			case 2:
				return torqueUnit;
			case 3:
				return torqueUnit;
			case 4:
				return torqueUnit + "/" + this.Main.Rm.GetString("Degree");
			case 5:
				return this.Main.Rm.GetString("Degree");
			case 6:
				return this.Main.Rm.GetString("Second");
			case 7:
				return this.Main.Rm.GetString("Milimeter");
			case 9:
				return this.Main.Rm.GetString("EmptyString");
			case 12:
				return this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second");
			case 10:
				return torqueUnit;
			case 11:
				return torqueUnit;
			case 8:
				return this.Main.Rm.GetString("EmptyString");
			default:
				return this.Main.Rm.GetString("EmptyString");
			}
		}

		public int GetResDigits(byte result)
		{
			switch (result)
			{
			case 1:
				return 2;
			case 2:
				return 2;
			case 3:
				return 2;
			case 4:
				return 4;
			case 5:
				return 1;
			case 6:
				return 2;
			case 7:
				return 1;
			case 9:
				return 0;
			case 12:
				return 4;
			case 10:
				return 2;
			case 11:
				return 2;
			case 8:
				return 2;
			default:
				return 0;
			}
		}

		public void RemoveTrailingBlanks(ref string outString, string inString)
		{
			char[] trimChars = new char[1]
			{
				' '
			};
			outString = inString.TrimEnd(trimChars);
		}
	}
}
