using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Visualisation
{
	public class MaintenanceNewEntryForm : Form
	{
		public const int _ABORTED = 1;

		public const int NEWENTRY_PERFORMED = 2;

		private MainForm Main;

		private int result = 2;

		private string maintenanceText = "";

		private uint cyclePlus;

		private byte expiryLeadsTo;

		private bool isInitializing;

		private bool textChanging;

		private IContainer components;

		private Button btCancel;

		private Button btSave;

		private TextBox tBMaintenanceText;

		private DateTimePicker dateTimePickerSchedul;

		private Label lbMaintenanceText;

		private Label lbSchedule;

		private GroupBox gBReason;

		private Label lbRemaining;

		private RadioButton rBFault;

		private RadioButton rBWarning;

		private RadioButton rBReminder;

		private Label lbNumberOf;

		private NumberEdit1 nECurrentPlus;

		private Label lbCurrentPlus;

		public string MaintenanceText
		{
			get
			{
				return this.maintenanceText;
			}
			set
			{
				this.maintenanceText = value;
			}
		}

		public int MaxlenMaintenanceText
		{
			get;
			set;
		}

		public DateTime ScheduledTime
		{
			get;
			set;
		}

		public uint CurrentCyclePlus
		{
			get;
			set;
		}

		public uint CyclePlus
		{
			set
			{
				this.cyclePlus = value;
			}
		}

		public byte ExpiryLeadsTo
		{
			get
			{
				return this.expiryLeadsTo;
			}
			set
			{
				this.expiryLeadsTo = value;
			}
		}

		public int Result => this.result;

		public bool NewEntry
		{
			get;
			set;
		}

		public MaintenanceNewEntryForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.NewEntry = false;
		}

		private void MaintenanceNewEntryForm_Load(object sender, EventArgs e)
		{
			this.tBMaintenanceText.MaxLength = this.MaxlenMaintenanceText;
			this.isInitializing = true;
			if (this.NewEntry)
			{
				this.Text = this.Main.Rm.GetString("btNewEntrie");
				this.gBReason.Enabled = true;
				TextBox textBox = this.tBMaintenanceText;
				string text2 = this.maintenanceText = (textBox.Text = "");
				this.dateTimePickerSchedul.Value = DateTime.Now;
			}
			else
			{
				this.Text = this.Main.Rm.GetString("ChangeEntry");
				this.rBFault.Checked = false;
				this.rBReminder.Checked = false;
				this.rBWarning.Checked = false;
				switch (this.expiryLeadsTo)
				{
				case 3:
					this.rBFault.Checked = true;
					break;
				case 2:
					this.rBWarning.Checked = true;
					break;
				case 1:
					this.rBReminder.Checked = true;
					break;
				}
				this.tBMaintenanceText.Text = this.maintenanceText;
				this.dateTimePickerSchedul.Value = this.ScheduledTime;
			}
			this.lbRemaining.Text = (this.MaxlenMaintenanceText - this.tBMaintenanceText.Text.Length).ToString();
			this.btSave.Enabled = false;
			this.nECurrentPlus.Value = (float)(double)this.cyclePlus;
			this.setNextMaintScheduled();
			this.rBReminder.Text = this.Main.Rm.GetString("MaintRemainder");
			this.rBWarning.Text = this.Main.Rm.GetString("MaintWarning");
			this.rBFault.Text = this.Main.Rm.GetString("MaintFault");
			this.SetLanguageTexts();
		}

		private void setNextMaintScheduled()
		{
			this.lbCurrentPlus.Text = this.Main.Rm.GetString("ScheduledAt") + " " + ((float)(double)this.Main.VC.CycleCount.Machine + this.nECurrentPlus.Value).ToString();
		}

		public void SetLanguageTexts()
		{
			this.lbMaintenanceText.Text = this.Main.Rm.GetString("EnterMaintText");
			this.lbSchedule.Text = this.Main.Rm.GetString("ScheduleNext");
			this.lbNumberOf.Text = this.Main.Rm.GetString("NextCycle");
			this.gBReason.Text = this.Main.Rm.GetString("ExpiryLeadTo");
			this.btSave.Text = this.Main.Rm.GetString("Apply");
			this.btCancel.Text = this.Main.Rm.GetString("Cancel");
		}

		private void btSave_Click(object sender, EventArgs e)
		{
			if (this.dateTimePickerSchedul.Value < DateTime.Now)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbScheduleMustInFuture"), this.Main.Rm.GetString("MaintenanceTable"));
			}
			else
			{
				this.maintenanceText = this.tBMaintenanceText.Text;
				this.ScheduledTime = this.dateTimePickerSchedul.Value;
				this.CurrentCyclePlus = this.Main.VC.CycleCount.Machine + (uint)this.nECurrentPlus.Value;
				this.result = 2;
				if (this.rBFault.Checked)
				{
					this.expiryLeadsTo = 3;
				}
				else if (this.rBWarning.Checked)
				{
					this.expiryLeadsTo = 2;
				}
				else
				{
					this.expiryLeadsTo = 1;
				}
				base.Close();
			}
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.result = 1;
			base.Close();
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (!this.isInitializing)
			{
				this.Main.TextInput(sender);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (!this.isInitializing)
			{
				this.Main.TextInput(sender);
			}
		}

		public void Cancel()
		{
			if (base.Visible)
			{
				this.result = 1;
				base.Close();
			}
		}

		private void tBMaintenanceText_TextChanged(object sender, EventArgs e)
		{
			if (!this.textChanging)
			{
				this.tBMaintenanceText.MaxLength = this.MaxlenMaintenanceText;
				this.textChanging = true;
				if (this.tBMaintenanceText.Text.Length > 5)
				{
					this.btSave.Enabled = true;
				}
				else
				{
					this.btSave.Enabled = false;
				}
				if (this.tBMaintenanceText.Text.Length > this.MaxlenMaintenanceText)
				{
					this.tBMaintenanceText.Text = this.tBMaintenanceText.Text.Remove(this.MaxlenMaintenanceText);
				}
				int num = this.MaxlenMaintenanceText - this.tBMaintenanceText.Text.Length;
				this.lbRemaining.Text = num.ToString();
				if (num <= 0)
				{
					this.lbRemaining.BackColor = Color.Red;
					this.lbRemaining.ForeColor = Color.White;
				}
				else
				{
					this.lbRemaining.BackColor = SystemColors.Control;
					this.lbRemaining.ForeColor = Color.Black;
				}
				this.btSave.Enabled = true;
				this.textChanging = false;
				this.setNextMaintScheduled();
			}
		}

		private void chBFault_CheckedChanged(object sender, EventArgs e)
		{
			this.btSave.Enabled = true;
		}

		private void dateTimePickerSchedul_ValueChanged(object sender, EventArgs e)
		{
			this.btSave.Enabled = true;
		}

		private void rBReminder_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void rBFault_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void rBWarning_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void rBWarning_Click(object sender, EventArgs e)
		{
			this.rBReminder.Checked = false;
			this.rBFault.Checked = false;
			this.rBWarning.Checked = true;
			this.btSave.Enabled = true;
		}

		private void rBFault_Click(object sender, EventArgs e)
		{
			this.rBReminder.Checked = false;
			this.rBFault.Checked = true;
			this.rBWarning.Checked = false;
			this.btSave.Enabled = true;
		}

		private void rBReminder_Click(object sender, EventArgs e)
		{
			this.rBReminder.Checked = true;
			this.rBFault.Checked = false;
			this.rBWarning.Checked = false;
			this.btSave.Enabled = true;
		}

		private void MaintenanceNewEntryForm_Shown(object sender, EventArgs e)
		{
			this.isInitializing = false;
		}

		private void btDelete_Click(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.btCancel = new Button();
			this.btSave = new Button();
			this.tBMaintenanceText = new TextBox();
			this.dateTimePickerSchedul = new DateTimePicker();
			this.lbMaintenanceText = new Label();
			this.lbSchedule = new Label();
			this.gBReason = new GroupBox();
			this.rBFault = new RadioButton();
			this.rBWarning = new RadioButton();
			this.rBReminder = new RadioButton();
			this.lbRemaining = new Label();
			this.lbNumberOf = new Label();
			this.nECurrentPlus = new NumberEdit1();
			this.lbCurrentPlus = new Label();
			this.gBReason.SuspendLayout();
			base.SuspendLayout();
			this.btCancel.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCancel.Location = new Point(166, 335);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(112, 64);
			this.btCancel.TabIndex = 3;
			this.btCancel.Text = "Abbrechen";
			this.btCancel.Click += this.btCancel_Click;
			this.btSave.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btSave.Location = new Point(29, 335);
			this.btSave.Name = "btSave";
			this.btSave.Size = new Size(112, 64);
			this.btSave.TabIndex = 2;
			this.btSave.Text = "Speichern + Zurück";
			this.btSave.Click += this.btSave_Click;
			this.tBMaintenanceText.BackColor = Color.White;
			this.tBMaintenanceText.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.tBMaintenanceText.Location = new Point(29, 47);
			this.tBMaintenanceText.MaxLength = 200;
			this.tBMaintenanceText.Multiline = true;
			this.tBMaintenanceText.Name = "tBMaintenanceText";
			this.tBMaintenanceText.Size = new Size(355, 75);
			this.tBMaintenanceText.TabIndex = 0;
			this.tBMaintenanceText.TextChanged += this.tBMaintenanceText_TextChanged;
			this.tBMaintenanceText.Enter += this.Start_Input;
			this.tBMaintenanceText.MouseDown += this.StartInput;
			this.dateTimePickerSchedul.Location = new Point(29, 170);
			this.dateTimePickerSchedul.Name = "dateTimePickerSchedul";
			this.dateTimePickerSchedul.Size = new Size(200, 20);
			this.dateTimePickerSchedul.TabIndex = 1;
			this.dateTimePickerSchedul.ValueChanged += this.dateTimePickerSchedul_ValueChanged;
			this.lbMaintenanceText.AutoSize = true;
			this.lbMaintenanceText.Location = new Point(26, 26);
			this.lbMaintenanceText.Name = "lbMaintenanceText";
			this.lbMaintenanceText.Size = new Size(89, 13);
			this.lbMaintenanceText.TabIndex = 9;
			this.lbMaintenanceText.Text = "Maintenance text";
			this.lbSchedule.AutoSize = true;
			this.lbSchedule.Location = new Point(26, 143);
			this.lbSchedule.Name = "lbSchedule";
			this.lbSchedule.Size = new Size(139, 13);
			this.lbSchedule.TabIndex = 10;
			this.lbSchedule.Text = "Schedule next maintenance";
			this.gBReason.Controls.Add(this.rBFault);
			this.gBReason.Controls.Add(this.rBWarning);
			this.gBReason.Controls.Add(this.rBReminder);
			this.gBReason.Location = new Point(29, 207);
			this.gBReason.Name = "gBReason";
			this.gBReason.Size = new Size(200, 105);
			this.gBReason.TabIndex = 12;
			this.gBReason.TabStop = false;
			this.gBReason.Text = "Reason";
			this.rBFault.AutoCheck = false;
			this.rBFault.AutoSize = true;
			this.rBFault.Location = new Point(12, 72);
			this.rBFault.Name = "rBFault";
			this.rBFault.Size = new Size(48, 17);
			this.rBFault.TabIndex = 2;
			this.rBFault.TabStop = true;
			this.rBFault.Text = "Fault";
			this.rBFault.UseVisualStyleBackColor = true;
			this.rBFault.CheckedChanged += this.rBFault_CheckedChanged;
			this.rBFault.Click += this.rBFault_Click;
			this.rBWarning.AutoCheck = false;
			this.rBWarning.AutoSize = true;
			this.rBWarning.Location = new Point(12, 47);
			this.rBWarning.Name = "rBWarning";
			this.rBWarning.Size = new Size(65, 17);
			this.rBWarning.TabIndex = 1;
			this.rBWarning.TabStop = true;
			this.rBWarning.Text = "Warning";
			this.rBWarning.UseVisualStyleBackColor = true;
			this.rBWarning.CheckedChanged += this.rBWarning_CheckedChanged;
			this.rBWarning.Click += this.rBWarning_Click;
			this.rBReminder.AutoCheck = false;
			this.rBReminder.AutoSize = true;
			this.rBReminder.Checked = true;
			this.rBReminder.Location = new Point(12, 22);
			this.rBReminder.Name = "rBReminder";
			this.rBReminder.Size = new Size(70, 17);
			this.rBReminder.TabIndex = 0;
			this.rBReminder.TabStop = true;
			this.rBReminder.Text = "Reminder";
			this.rBReminder.UseVisualStyleBackColor = true;
			this.rBReminder.CheckedChanged += this.rBReminder_CheckedChanged;
			this.rBReminder.Click += this.rBReminder_Click;
			this.lbRemaining.AutoSize = true;
			this.lbRemaining.Location = new Point(349, 26);
			this.lbRemaining.Name = "lbRemaining";
			this.lbRemaining.Size = new Size(57, 13);
			this.lbRemaining.TabIndex = 13;
			this.lbRemaining.Text = "Remaining";
			this.lbRemaining.Visible = false;
			this.lbNumberOf.Location = new Point(256, 136);
			this.lbNumberOf.Name = "lbNumberOf";
			this.lbNumberOf.Size = new Size(164, 48);
			this.lbNumberOf.TabIndex = 14;
			this.lbNumberOf.Text = "Number of cycles";
			this.lbNumberOf.TextAlign = ContentAlignment.MiddleLeft;
			this.nECurrentPlus.BackColor = Color.White;
			this.nECurrentPlus.DecimalNum = 0;
			this.nECurrentPlus.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nECurrentPlus.ForeColor = SystemColors.ControlText;
			this.nECurrentPlus.Location = new Point(259, 187);
			this.nECurrentPlus.MaxValue = 1000000f;
			this.nECurrentPlus.MinValue = 1f;
			this.nECurrentPlus.Name = "nECurrentPlus";
			this.nECurrentPlus.Size = new Size(72, 24);
			this.nECurrentPlus.TabIndex = 15;
			this.nECurrentPlus.Text = "1";
			this.nECurrentPlus.TextAlign = HorizontalAlignment.Right;
			this.nECurrentPlus.Value = 1f;
			this.nECurrentPlus.MouseClick += this.StartInput;
			this.nECurrentPlus.TextChanged += this.tBMaintenanceText_TextChanged;
			this.nECurrentPlus.Enter += this.Start_Input;
			this.lbCurrentPlus.AutoSize = true;
			this.lbCurrentPlus.Location = new Point(256, 229);
			this.lbCurrentPlus.Name = "lbCurrentPlus";
			this.lbCurrentPlus.Size = new Size(50, 13);
			this.lbCurrentPlus.TabIndex = 16;
			this.lbCurrentPlus.Text = "Current +";
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(448, 437);
			base.Controls.Add(this.lbCurrentPlus);
			base.Controls.Add(this.nECurrentPlus);
			base.Controls.Add(this.lbNumberOf);
			base.Controls.Add(this.lbRemaining);
			base.Controls.Add(this.gBReason);
			base.Controls.Add(this.lbSchedule);
			base.Controls.Add(this.lbMaintenanceText);
			base.Controls.Add(this.dateTimePickerSchedul);
			base.Controls.Add(this.tBMaintenanceText);
			base.Controls.Add(this.btSave);
			base.Controls.Add(this.btCancel);
			base.FormBorderStyle = FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "MaintenanceNewEntryForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.CenterParent;
			this.Text = "New entry";
			base.Load += this.MaintenanceNewEntryForm_Load;
			base.Shown += this.MaintenanceNewEntryForm_Shown;
			this.gBReason.ResumeLayout(false);
			this.gBReason.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}
	}
}
