namespace Visualisation
{
	public class FileWithAttrClass
	{
		public string Filename = "";

		public string Cluster = "";

		public bool Enabled = true;

		public FileWithAttrClass(string filename, string cluster, bool enabled)
		{
			this.Filename = filename;
			this.Cluster = cluster;
			this.Enabled = enabled;
		}

		public void Enable(string cluster, bool enabled)
		{
		}
	}
}
