using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Visualisation
{
	[DebuggerNonUserCode]
	[CompilerGenerated]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	internal class LanguageText_fr
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(LanguageText_fr.resourceMan, null))
				{
					ResourceManager resourceManager = LanguageText_fr.resourceMan = new ResourceManager("Visualisation.LanguageText_fr", typeof(LanguageText_fr).Assembly);
				}
				return LanguageText_fr.resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return LanguageText_fr.resourceCulture;
			}
			set
			{
				LanguageText_fr.resourceCulture = value;
			}
		}

		internal static string Abr_Program => LanguageText_fr.ResourceManager.GetString("Abr_Program", LanguageText_fr.resourceCulture);

		internal static string AbrAnaDepth => LanguageText_fr.ResourceManager.GetString("AbrAnaDepth", LanguageText_fr.resourceCulture);

		internal static string AbrAnaSignal => LanguageText_fr.ResourceManager.GetString("AbrAnaSignal", LanguageText_fr.resourceCulture);

		internal static string AbrAngle => LanguageText_fr.ResourceManager.GetString("AbrAngle", LanguageText_fr.resourceCulture);

		internal static string AbrDelayTorque => LanguageText_fr.ResourceManager.GetString("AbrDelayTorque", LanguageText_fr.resourceCulture);

		internal static string AbrDepthGrad => LanguageText_fr.ResourceManager.GetString("AbrDepthGrad", LanguageText_fr.resourceCulture);

		internal static string AbrFilteredTorque => LanguageText_fr.ResourceManager.GetString("AbrFilteredTorque", LanguageText_fr.resourceCulture);

		internal static string AbrGradient => LanguageText_fr.ResourceManager.GetString("AbrGradient", LanguageText_fr.resourceCulture);

		internal static string AbrM360Follow => LanguageText_fr.ResourceManager.GetString("AbrM360Follow", LanguageText_fr.resourceCulture);

		internal static string AbrMaxTorque => LanguageText_fr.ResourceManager.GetString("AbrMaxTorque", LanguageText_fr.resourceCulture);

		internal static string AbrNumber => LanguageText_fr.ResourceManager.GetString("AbrNumber", LanguageText_fr.resourceCulture);

		internal static string AbrTime => LanguageText_fr.ResourceManager.GetString("AbrTime", LanguageText_fr.resourceCulture);

		internal static string AbrTorque => LanguageText_fr.ResourceManager.GetString("AbrTorque", LanguageText_fr.resourceCulture);

		internal static string AccessCheck => LanguageText_fr.ResourceManager.GetString("AccessCheck", LanguageText_fr.resourceCulture);

		internal static string AccessRequest => LanguageText_fr.ResourceManager.GetString("AccessRequest", LanguageText_fr.resourceCulture);

		internal static string Actualize => LanguageText_fr.ResourceManager.GetString("Actualize", LanguageText_fr.resourceCulture);

		internal static string AddEntry => LanguageText_fr.ResourceManager.GetString("AddEntry", LanguageText_fr.resourceCulture);

		internal static string AIError => LanguageText_fr.ResourceManager.GetString("AIError", LanguageText_fr.resourceCulture);

		internal static string All => LanguageText_fr.ResourceManager.GetString("All", LanguageText_fr.resourceCulture);

		internal static string AllFiles => LanguageText_fr.ResourceManager.GetString("AllFiles", LanguageText_fr.resourceCulture);

		internal static string AnaDepth => LanguageText_fr.ResourceManager.GetString("AnaDepth", LanguageText_fr.resourceCulture);

		internal static string Analysis => LanguageText_fr.ResourceManager.GetString("Analysis", LanguageText_fr.resourceCulture);

		internal static string AnaOutput => LanguageText_fr.ResourceManager.GetString("AnaOutput", LanguageText_fr.resourceCulture);

		internal static string AnaSignal => LanguageText_fr.ResourceManager.GetString("AnaSignal", LanguageText_fr.resourceCulture);

		internal static string AnaSigOffset => LanguageText_fr.ResourceManager.GetString("AnaSigOffset", LanguageText_fr.resourceCulture);

		internal static string AnaSigScale => LanguageText_fr.ResourceManager.GetString("AnaSigScale", LanguageText_fr.resourceCulture);

		internal static string Angle => LanguageText_fr.ResourceManager.GetString("Angle", LanguageText_fr.resourceCulture);

		internal static string AngleRedundantTolerance => LanguageText_fr.ResourceManager.GetString("AngleRedundantTolerance", LanguageText_fr.resourceCulture);

		internal static string AngleSensorInvers => LanguageText_fr.ResourceManager.GetString("AngleSensorInvers", LanguageText_fr.resourceCulture);

		internal static string AngleSensorScale => LanguageText_fr.ResourceManager.GetString("AngleSensorScale", LanguageText_fr.resourceCulture);

		internal static string AngleTorqueSensor => LanguageText_fr.ResourceManager.GetString("AngleTorqueSensor", LanguageText_fr.resourceCulture);

		internal static string Apply => LanguageText_fr.ResourceManager.GetString("Apply", LanguageText_fr.resourceCulture);

		internal static string ApplyEntry => LanguageText_fr.ResourceManager.GetString("ApplyEntry", LanguageText_fr.resourceCulture);

		internal static string AutoCurveAbort => LanguageText_fr.ResourceManager.GetString("AutoCurveAbort", LanguageText_fr.resourceCulture);

		internal static string Automatic => LanguageText_fr.ResourceManager.GetString("Automatic", LanguageText_fr.resourceCulture);

		internal static string AutoMode => LanguageText_fr.ResourceManager.GetString("AutoMode", LanguageText_fr.resourceCulture);

		internal static string AvailableValueNumber => LanguageText_fr.ResourceManager.GetString("AvailableValueNumber", LanguageText_fr.resourceCulture);

		internal static string Back => LanguageText_fr.ResourceManager.GetString("Back", LanguageText_fr.resourceCulture);

		internal static string Backup => LanguageText_fr.ResourceManager.GetString("Backup", LanguageText_fr.resourceCulture);

		internal static string Backup205000 => LanguageText_fr.ResourceManager.GetString("Backup205000", LanguageText_fr.resourceCulture);

		internal static string Backup205001 => LanguageText_fr.ResourceManager.GetString("Backup205001", LanguageText_fr.resourceCulture);

		internal static string Backup205002 => LanguageText_fr.ResourceManager.GetString("Backup205002", LanguageText_fr.resourceCulture);

		internal static string Backup205003 => LanguageText_fr.ResourceManager.GetString("Backup205003", LanguageText_fr.resourceCulture);

		internal static string Battery => LanguageText_fr.ResourceManager.GetString("Battery", LanguageText_fr.resourceCulture);

		internal static string Baudrate => LanguageText_fr.ResourceManager.GetString("Baudrate", LanguageText_fr.resourceCulture);

		internal static string bt0 => LanguageText_fr.ResourceManager.GetString("bt0", LanguageText_fr.resourceCulture);

		internal static string bt1 => LanguageText_fr.ResourceManager.GetString("bt1", LanguageText_fr.resourceCulture);

		internal static string bt2 => LanguageText_fr.ResourceManager.GetString("bt2", LanguageText_fr.resourceCulture);

		internal static string bt3 => LanguageText_fr.ResourceManager.GetString("bt3", LanguageText_fr.resourceCulture);

		internal static string bt4 => LanguageText_fr.ResourceManager.GetString("bt4", LanguageText_fr.resourceCulture);

		internal static string bt5 => LanguageText_fr.ResourceManager.GetString("bt5", LanguageText_fr.resourceCulture);

		internal static string bt6 => LanguageText_fr.ResourceManager.GetString("bt6", LanguageText_fr.resourceCulture);

		internal static string bt7 => LanguageText_fr.ResourceManager.GetString("bt7", LanguageText_fr.resourceCulture);

		internal static string bt8 => LanguageText_fr.ResourceManager.GetString("bt8", LanguageText_fr.resourceCulture);

		internal static string bt9 => LanguageText_fr.ResourceManager.GetString("bt9", LanguageText_fr.resourceCulture);

		internal static string btA => LanguageText_fr.ResourceManager.GetString("btA", LanguageText_fr.resourceCulture);

		internal static string btApply => LanguageText_fr.ResourceManager.GetString("btApply", LanguageText_fr.resourceCulture);

		internal static string btB => LanguageText_fr.ResourceManager.GetString("btB", LanguageText_fr.resourceCulture);

		internal static string btBackspace => LanguageText_fr.ResourceManager.GetString("btBackspace", LanguageText_fr.resourceCulture);

		internal static string btC => LanguageText_fr.ResourceManager.GetString("btC", LanguageText_fr.resourceCulture);

		internal static string btCancel => LanguageText_fr.ResourceManager.GetString("btCancel", LanguageText_fr.resourceCulture);

		internal static string btChangeDefaultDir => LanguageText_fr.ResourceManager.GetString("btChangeDefaultDir", LanguageText_fr.resourceCulture);

		internal static string btD => LanguageText_fr.ResourceManager.GetString("btD", LanguageText_fr.resourceCulture);

		internal static string btE => LanguageText_fr.ResourceManager.GetString("btE", LanguageText_fr.resourceCulture);

		internal static string btErase => LanguageText_fr.ResourceManager.GetString("btErase", LanguageText_fr.resourceCulture);

		internal static string btF => LanguageText_fr.ResourceManager.GetString("btF", LanguageText_fr.resourceCulture);

		internal static string btG => LanguageText_fr.ResourceManager.GetString("btG", LanguageText_fr.resourceCulture);

		internal static string btH => LanguageText_fr.ResourceManager.GetString("btH", LanguageText_fr.resourceCulture);

		internal static string btI => LanguageText_fr.ResourceManager.GetString("btI", LanguageText_fr.resourceCulture);

		internal static string btJ => LanguageText_fr.ResourceManager.GetString("btJ", LanguageText_fr.resourceCulture);

		internal static string btK => LanguageText_fr.ResourceManager.GetString("btK", LanguageText_fr.resourceCulture);

		internal static string btL => LanguageText_fr.ResourceManager.GetString("btL", LanguageText_fr.resourceCulture);

		internal static string btLoad => LanguageText_fr.ResourceManager.GetString("btLoad", LanguageText_fr.resourceCulture);

		internal static string btM => LanguageText_fr.ResourceManager.GetString("btM", LanguageText_fr.resourceCulture);

		internal static string btMinusDown => LanguageText_fr.ResourceManager.GetString("btMinusDown", LanguageText_fr.resourceCulture);

		internal static string btMinusUp => LanguageText_fr.ResourceManager.GetString("btMinusUp", LanguageText_fr.resourceCulture);

		internal static string btN => LanguageText_fr.ResourceManager.GetString("btN", LanguageText_fr.resourceCulture);

		internal static string btO => LanguageText_fr.ResourceManager.GetString("btO", LanguageText_fr.resourceCulture);

		internal static string btP => LanguageText_fr.ResourceManager.GetString("btP", LanguageText_fr.resourceCulture);

		internal static string btQ => LanguageText_fr.ResourceManager.GetString("btQ", LanguageText_fr.resourceCulture);

		internal static string btR => LanguageText_fr.ResourceManager.GetString("btR", LanguageText_fr.resourceCulture);

		internal static string btRes1 => LanguageText_fr.ResourceManager.GetString("btRes1", LanguageText_fr.resourceCulture);

		internal static string btRes2 => LanguageText_fr.ResourceManager.GetString("btRes2", LanguageText_fr.resourceCulture);

		internal static string btRes3 => LanguageText_fr.ResourceManager.GetString("btRes3", LanguageText_fr.resourceCulture);

		internal static string btS => LanguageText_fr.ResourceManager.GetString("btS", LanguageText_fr.resourceCulture);

		internal static string btShift => LanguageText_fr.ResourceManager.GetString("btShift", LanguageText_fr.resourceCulture);

		internal static string btSpace => LanguageText_fr.ResourceManager.GetString("btSpace", LanguageText_fr.resourceCulture);

		internal static string btT => LanguageText_fr.ResourceManager.GetString("btT", LanguageText_fr.resourceCulture);

		internal static string btTeach => LanguageText_fr.ResourceManager.GetString("btTeach", LanguageText_fr.resourceCulture);

		internal static string btU => LanguageText_fr.ResourceManager.GetString("btU", LanguageText_fr.resourceCulture);

		internal static string btV => LanguageText_fr.ResourceManager.GetString("btV", LanguageText_fr.resourceCulture);

		internal static string btW => LanguageText_fr.ResourceManager.GetString("btW", LanguageText_fr.resourceCulture);

		internal static string btX => LanguageText_fr.ResourceManager.GetString("btX", LanguageText_fr.resourceCulture);

		internal static string btY => LanguageText_fr.ResourceManager.GetString("btY", LanguageText_fr.resourceCulture);

		internal static string btZ => LanguageText_fr.ResourceManager.GetString("btZ", LanguageText_fr.resourceCulture);

		internal static string CalculateCurves => LanguageText_fr.ResourceManager.GetString("CalculateCurves", LanguageText_fr.resourceCulture);

		internal static string CalDisable => LanguageText_fr.ResourceManager.GetString("CalDisable", LanguageText_fr.resourceCulture);

		internal static string CalibrationSignal => LanguageText_fr.ResourceManager.GetString("CalibrationSignal", LanguageText_fr.resourceCulture);

		internal static string Cancel => LanguageText_fr.ResourceManager.GetString("Cancel", LanguageText_fr.resourceCulture);

		internal static string Changed => LanguageText_fr.ResourceManager.GetString("Changed", LanguageText_fr.resourceCulture);

		internal static string ChangeEntry => LanguageText_fr.ResourceManager.GetString("ChangeEntry", LanguageText_fr.resourceCulture);

		internal static string ChangesLog => LanguageText_fr.ResourceManager.GetString("ChangesLog", LanguageText_fr.resourceCulture);

		internal static string chBEmtyPrograms => LanguageText_fr.ResourceManager.GetString("chBEmtyPrograms", LanguageText_fr.resourceCulture);

		internal static string chBProgPreview => LanguageText_fr.ResourceManager.GetString("chBProgPreview", LanguageText_fr.resourceCulture);

		internal static string chBUseDefaultDir => LanguageText_fr.ResourceManager.GetString("chBUseDefaultDir", LanguageText_fr.resourceCulture);

		internal static string CheckFrictionTestStart => LanguageText_fr.ResourceManager.GetString("CheckFrictionTestStart", LanguageText_fr.resourceCulture);

		internal static string CheckHandStart => LanguageText_fr.ResourceManager.GetString("CheckHandStart", LanguageText_fr.resourceCulture);

		internal static string CheckParameter => LanguageText_fr.ResourceManager.GetString("CheckParameter", LanguageText_fr.resourceCulture);

		internal static string CheckRight => LanguageText_fr.ResourceManager.GetString("CheckRight", LanguageText_fr.resourceCulture);

		internal static string Close => LanguageText_fr.ResourceManager.GetString("Close", LanguageText_fr.resourceCulture);

		internal static string ControllerName => LanguageText_fr.ResourceManager.GetString("ControllerName", LanguageText_fr.resourceCulture);

		internal static string ControllerTime => LanguageText_fr.ResourceManager.GetString("ControllerTime", LanguageText_fr.resourceCulture);

		internal static string CopyProgram => LanguageText_fr.ResourceManager.GetString("CopyProgram", LanguageText_fr.resourceCulture);

		internal static string CountPassMax => LanguageText_fr.ResourceManager.GetString("CountPassMax", LanguageText_fr.resourceCulture);

		internal static string CreatedUsers => LanguageText_fr.ResourceManager.GetString("CreatedUsers", LanguageText_fr.resourceCulture);

		internal static string CumulStats => LanguageText_fr.ResourceManager.GetString("CumulStats", LanguageText_fr.resourceCulture);

		internal static string CursorsCannotSwitch => LanguageText_fr.ResourceManager.GetString("CursorsCannotSwitch", LanguageText_fr.resourceCulture);

		internal static string CurveDisplay => LanguageText_fr.ResourceManager.GetString("CurveDisplay", LanguageText_fr.resourceCulture);

		internal static string CurveLoad => LanguageText_fr.ResourceManager.GetString("CurveLoad", LanguageText_fr.resourceCulture);

		internal static string CurvePrint => LanguageText_fr.ResourceManager.GetString("CurvePrint", LanguageText_fr.resourceCulture);

		internal static string CurveResultKind => LanguageText_fr.ResourceManager.GetString("CurveResultKind", LanguageText_fr.resourceCulture);

		internal static string CurveResultNumber => LanguageText_fr.ResourceManager.GetString("CurveResultNumber", LanguageText_fr.resourceCulture);

		internal static string CurveSave => LanguageText_fr.ResourceManager.GetString("CurveSave", LanguageText_fr.resourceCulture);

		internal static string CurveSelection => LanguageText_fr.ResourceManager.GetString("CurveSelection", LanguageText_fr.resourceCulture);

		internal static string CurvesZoomedIn => LanguageText_fr.ResourceManager.GetString("CurvesZoomedIn", LanguageText_fr.resourceCulture);

		internal static string CurvesZoomedOut => LanguageText_fr.ResourceManager.GetString("CurvesZoomedOut", LanguageText_fr.resourceCulture);

		internal static string CustomCounter => LanguageText_fr.ResourceManager.GetString("CustomCounter", LanguageText_fr.resourceCulture);

		internal static string Cycle => LanguageText_fr.ResourceManager.GetString("Cycle", LanguageText_fr.resourceCulture);

		internal static string CycleCounter => LanguageText_fr.ResourceManager.GetString("CycleCounter", LanguageText_fr.resourceCulture);

		internal static string CycleNumber => LanguageText_fr.ResourceManager.GetString("CycleNumber", LanguageText_fr.resourceCulture);

		internal static string CycleSave => LanguageText_fr.ResourceManager.GetString("CycleSave", LanguageText_fr.resourceCulture);

		internal static string Czech => LanguageText_fr.ResourceManager.GetString("Czech", LanguageText_fr.resourceCulture);

		internal static string DateTime => LanguageText_fr.ResourceManager.GetString("DateTime", LanguageText_fr.resourceCulture);

		internal static string DeblockController => LanguageText_fr.ResourceManager.GetString("DeblockController", LanguageText_fr.resourceCulture);

		internal static string DeclForSpSave => LanguageText_fr.ResourceManager.GetString("DeclForSpSave", LanguageText_fr.resourceCulture);

		internal static string Degree => LanguageText_fr.ResourceManager.GetString("Degree", LanguageText_fr.resourceCulture);

		internal static string DelayTorque => LanguageText_fr.ResourceManager.GetString("DelayTorque", LanguageText_fr.resourceCulture);

		internal static string DeleteCounter => LanguageText_fr.ResourceManager.GetString("DeleteCounter", LanguageText_fr.resourceCulture);

		internal static string DeleteCustomCounter => LanguageText_fr.ResourceManager.GetString("DeleteCustomCounter", LanguageText_fr.resourceCulture);

		internal static string DeleteEntry => LanguageText_fr.ResourceManager.GetString("DeleteEntry", LanguageText_fr.resourceCulture);

		internal static string DeleteJob => LanguageText_fr.ResourceManager.GetString("DeleteJob", LanguageText_fr.resourceCulture);

		internal static string DeleteLastResults => LanguageText_fr.ResourceManager.GetString("DeleteLastResults", LanguageText_fr.resourceCulture);

		internal static string DeleteProgram => LanguageText_fr.ResourceManager.GetString("DeleteProgram", LanguageText_fr.resourceCulture);

		internal static string DeleteRecursiveStat => LanguageText_fr.ResourceManager.GetString("DeleteRecursiveStat", LanguageText_fr.resourceCulture);

		internal static string DeleteStep => LanguageText_fr.ResourceManager.GetString("DeleteStep", LanguageText_fr.resourceCulture);

		internal static string DeleteValues => LanguageText_fr.ResourceManager.GetString("DeleteValues", LanguageText_fr.resourceCulture);

		internal static string DepthFilterTime => LanguageText_fr.ResourceManager.GetString("DepthFilterTime", LanguageText_fr.resourceCulture);

		internal static string DepthGrad => LanguageText_fr.ResourceManager.GetString("DepthGrad", LanguageText_fr.resourceCulture);

		internal static string DepthGradLength => LanguageText_fr.ResourceManager.GetString("DepthGradLength", LanguageText_fr.resourceCulture);

		internal static string DepthSensor => LanguageText_fr.ResourceManager.GetString("DepthSensor", LanguageText_fr.resourceCulture);

		internal static string DepthSensorInvers => LanguageText_fr.ResourceManager.GetString("DepthSensorInvers", LanguageText_fr.resourceCulture);

		internal static string DGAddress => LanguageText_fr.ResourceManager.GetString("DGAddress", LanguageText_fr.resourceCulture);

		internal static string DHCP => LanguageText_fr.ResourceManager.GetString("DHCP", LanguageText_fr.resourceCulture);

		internal static string DigitalSignal => LanguageText_fr.ResourceManager.GetString("DigitalSignal", LanguageText_fr.resourceCulture);

		internal static string DigitOut => LanguageText_fr.ResourceManager.GetString("DigitOut", LanguageText_fr.resourceCulture);

		internal static string DigSigAtEnd => LanguageText_fr.ResourceManager.GetString("DigSigAtEnd", LanguageText_fr.resourceCulture);

		internal static string DigSigRunning => LanguageText_fr.ResourceManager.GetString("DigSigRunning", LanguageText_fr.resourceCulture);

		internal static string DiscardChanges => LanguageText_fr.ResourceManager.GetString("DiscardChanges", LanguageText_fr.resourceCulture);

		internal static string Done => LanguageText_fr.ResourceManager.GetString("Done", LanguageText_fr.resourceCulture);

		internal static string DriveUnit => LanguageText_fr.ResourceManager.GetString("DriveUnit", LanguageText_fr.resourceCulture);

		internal static string DriveUnitInvers => LanguageText_fr.ResourceManager.GetString("DriveUnitInvers", LanguageText_fr.resourceCulture);

		internal static string Driving => LanguageText_fr.ResourceManager.GetString("Driving", LanguageText_fr.resourceCulture);

		internal static string DrivingStep => LanguageText_fr.ResourceManager.GetString("DrivingStep", LanguageText_fr.resourceCulture);

		internal static string EditCancel => LanguageText_fr.ResourceManager.GetString("EditCancel", LanguageText_fr.resourceCulture);

		internal static string EditEntry => LanguageText_fr.ResourceManager.GetString("EditEntry", LanguageText_fr.resourceCulture);

		internal static string EditProgram => LanguageText_fr.ResourceManager.GetString("EditProgram", LanguageText_fr.resourceCulture);

		internal static string EditStep => LanguageText_fr.ResourceManager.GetString("EditStep", LanguageText_fr.resourceCulture);

		internal static string EMGMode => LanguageText_fr.ResourceManager.GetString("EMGMode", LanguageText_fr.resourceCulture);

		internal static string Empty => LanguageText_fr.ResourceManager.GetString("Empty", LanguageText_fr.resourceCulture);

		internal static string EmptyString => LanguageText_fr.ResourceManager.GetString("EmptyString", LanguageText_fr.resourceCulture);

		internal static string EncError => LanguageText_fr.ResourceManager.GetString("EncError", LanguageText_fr.resourceCulture);

		internal static string English => LanguageText_fr.ResourceManager.GetString("English", LanguageText_fr.resourceCulture);

		internal static string Error1000 => LanguageText_fr.ResourceManager.GetString("Error1000", LanguageText_fr.resourceCulture);

		internal static string Error1001 => LanguageText_fr.ResourceManager.GetString("Error1001", LanguageText_fr.resourceCulture);

		internal static string Error1002 => LanguageText_fr.ResourceManager.GetString("Error1002", LanguageText_fr.resourceCulture);

		internal static string Error1003 => LanguageText_fr.ResourceManager.GetString("Error1003", LanguageText_fr.resourceCulture);

		internal static string Error1004 => LanguageText_fr.ResourceManager.GetString("Error1004", LanguageText_fr.resourceCulture);

		internal static string Error1005 => LanguageText_fr.ResourceManager.GetString("Error1005", LanguageText_fr.resourceCulture);

		internal static string Error1006 => LanguageText_fr.ResourceManager.GetString("Error1006", LanguageText_fr.resourceCulture);

		internal static string Error1007 => LanguageText_fr.ResourceManager.GetString("Error1007", LanguageText_fr.resourceCulture);

		internal static string Error1008 => LanguageText_fr.ResourceManager.GetString("Error1008", LanguageText_fr.resourceCulture);

		internal static string Error1009 => LanguageText_fr.ResourceManager.GetString("Error1009", LanguageText_fr.resourceCulture);

		internal static string Error1010 => LanguageText_fr.ResourceManager.GetString("Error1010", LanguageText_fr.resourceCulture);

		internal static string Error1011 => LanguageText_fr.ResourceManager.GetString("Error1011", LanguageText_fr.resourceCulture);

		internal static string Error1012 => LanguageText_fr.ResourceManager.GetString("Error1012", LanguageText_fr.resourceCulture);

		internal static string Error1013 => LanguageText_fr.ResourceManager.GetString("Error1013", LanguageText_fr.resourceCulture);

		internal static string Error1014 => LanguageText_fr.ResourceManager.GetString("Error1014", LanguageText_fr.resourceCulture);

		internal static string Error1015 => LanguageText_fr.ResourceManager.GetString("Error1015", LanguageText_fr.resourceCulture);

		internal static string Error1016 => LanguageText_fr.ResourceManager.GetString("Error1016", LanguageText_fr.resourceCulture);

		internal static string Error1017 => LanguageText_fr.ResourceManager.GetString("Error1017", LanguageText_fr.resourceCulture);

		internal static string Error1018 => LanguageText_fr.ResourceManager.GetString("Error1018", LanguageText_fr.resourceCulture);

		internal static string Error1019 => LanguageText_fr.ResourceManager.GetString("Error1019", LanguageText_fr.resourceCulture);

		internal static string Error1020 => LanguageText_fr.ResourceManager.GetString("Error1020", LanguageText_fr.resourceCulture);

		internal static string Error1021 => LanguageText_fr.ResourceManager.GetString("Error1021", LanguageText_fr.resourceCulture);

		internal static string Error1022 => LanguageText_fr.ResourceManager.GetString("Error1022", LanguageText_fr.resourceCulture);

		internal static string Error1023 => LanguageText_fr.ResourceManager.GetString("Error1023", LanguageText_fr.resourceCulture);

		internal static string Error1024 => LanguageText_fr.ResourceManager.GetString("Error1024", LanguageText_fr.resourceCulture);

		internal static string Error1025 => LanguageText_fr.ResourceManager.GetString("Error1025", LanguageText_fr.resourceCulture);

		internal static string Error1026 => LanguageText_fr.ResourceManager.GetString("Error1026", LanguageText_fr.resourceCulture);

		internal static string Error1027 => LanguageText_fr.ResourceManager.GetString("Error1027", LanguageText_fr.resourceCulture);

		internal static string Error1028 => LanguageText_fr.ResourceManager.GetString("Error1028", LanguageText_fr.resourceCulture);

		internal static string Error1029 => LanguageText_fr.ResourceManager.GetString("Error1029", LanguageText_fr.resourceCulture);

		internal static string Error1030 => LanguageText_fr.ResourceManager.GetString("Error1030", LanguageText_fr.resourceCulture);

		internal static string Error1031 => LanguageText_fr.ResourceManager.GetString("Error1031", LanguageText_fr.resourceCulture);

		internal static string Error1032 => LanguageText_fr.ResourceManager.GetString("Error1032", LanguageText_fr.resourceCulture);

		internal static string Error1033 => LanguageText_fr.ResourceManager.GetString("Error1033", LanguageText_fr.resourceCulture);

		internal static string Error1034 => LanguageText_fr.ResourceManager.GetString("Error1034", LanguageText_fr.resourceCulture);

		internal static string Error1035 => LanguageText_fr.ResourceManager.GetString("Error1035", LanguageText_fr.resourceCulture);

		internal static string Error1036 => LanguageText_fr.ResourceManager.GetString("Error1036", LanguageText_fr.resourceCulture);

		internal static string Error1037 => LanguageText_fr.ResourceManager.GetString("Error1037", LanguageText_fr.resourceCulture);

		internal static string Error1038 => LanguageText_fr.ResourceManager.GetString("Error1038", LanguageText_fr.resourceCulture);

		internal static string Error1100 => LanguageText_fr.ResourceManager.GetString("Error1100", LanguageText_fr.resourceCulture);

		internal static string Error1101 => LanguageText_fr.ResourceManager.GetString("Error1101", LanguageText_fr.resourceCulture);

		internal static string Error1102 => LanguageText_fr.ResourceManager.GetString("Error1102", LanguageText_fr.resourceCulture);

		internal static string Error1110 => LanguageText_fr.ResourceManager.GetString("Error1110", LanguageText_fr.resourceCulture);

		internal static string Error1111 => LanguageText_fr.ResourceManager.GetString("Error1111", LanguageText_fr.resourceCulture);

		internal static string Error1112 => LanguageText_fr.ResourceManager.GetString("Error1112", LanguageText_fr.resourceCulture);

		internal static string Error1113 => LanguageText_fr.ResourceManager.GetString("Error1113", LanguageText_fr.resourceCulture);

		internal static string Error1114 => LanguageText_fr.ResourceManager.GetString("Error1114", LanguageText_fr.resourceCulture);

		internal static string Error1140 => LanguageText_fr.ResourceManager.GetString("Error1140", LanguageText_fr.resourceCulture);

		internal static string Error1141 => LanguageText_fr.ResourceManager.GetString("Error1141", LanguageText_fr.resourceCulture);

		internal static string Error1150 => LanguageText_fr.ResourceManager.GetString("Error1150", LanguageText_fr.resourceCulture);

		internal static string Error1151 => LanguageText_fr.ResourceManager.GetString("Error1151", LanguageText_fr.resourceCulture);

		internal static string Error1152 => LanguageText_fr.ResourceManager.GetString("Error1152", LanguageText_fr.resourceCulture);

		internal static string Error1153 => LanguageText_fr.ResourceManager.GetString("Error1153", LanguageText_fr.resourceCulture);

		internal static string Error1160 => LanguageText_fr.ResourceManager.GetString("Error1160", LanguageText_fr.resourceCulture);

		internal static string Error1161 => LanguageText_fr.ResourceManager.GetString("Error1161", LanguageText_fr.resourceCulture);

		internal static string Error1162 => LanguageText_fr.ResourceManager.GetString("Error1162", LanguageText_fr.resourceCulture);

		internal static string Error1163 => LanguageText_fr.ResourceManager.GetString("Error1163", LanguageText_fr.resourceCulture);

		internal static string Error1200 => LanguageText_fr.ResourceManager.GetString("Error1200", LanguageText_fr.resourceCulture);

		internal static string Error1201 => LanguageText_fr.ResourceManager.GetString("Error1201", LanguageText_fr.resourceCulture);

		internal static string Error1202 => LanguageText_fr.ResourceManager.GetString("Error1202", LanguageText_fr.resourceCulture);

		internal static string Error1203 => LanguageText_fr.ResourceManager.GetString("Error1203", LanguageText_fr.resourceCulture);

		internal static string Error1301 => LanguageText_fr.ResourceManager.GetString("Error1301", LanguageText_fr.resourceCulture);

		internal static string Error1302 => LanguageText_fr.ResourceManager.GetString("Error1302", LanguageText_fr.resourceCulture);

		internal static string Error1303 => LanguageText_fr.ResourceManager.GetString("Error1303", LanguageText_fr.resourceCulture);

		internal static string Error1304 => LanguageText_fr.ResourceManager.GetString("Error1304", LanguageText_fr.resourceCulture);

		internal static string Error1305 => LanguageText_fr.ResourceManager.GetString("Error1305", LanguageText_fr.resourceCulture);

		internal static string Error1400 => LanguageText_fr.ResourceManager.GetString("Error1400", LanguageText_fr.resourceCulture);

		internal static string Error1401 => LanguageText_fr.ResourceManager.GetString("Error1401", LanguageText_fr.resourceCulture);

		internal static string Error1402 => LanguageText_fr.ResourceManager.GetString("Error1402", LanguageText_fr.resourceCulture);

		internal static string Error1403 => LanguageText_fr.ResourceManager.GetString("Error1403", LanguageText_fr.resourceCulture);

		internal static string Error1404 => LanguageText_fr.ResourceManager.GetString("Error1404", LanguageText_fr.resourceCulture);

		internal static string Error1405 => LanguageText_fr.ResourceManager.GetString("Error1405", LanguageText_fr.resourceCulture);

		internal static string Error1406 => LanguageText_fr.ResourceManager.GetString("Error1406", LanguageText_fr.resourceCulture);

		internal static string Error1407 => LanguageText_fr.ResourceManager.GetString("Error1407", LanguageText_fr.resourceCulture);

		internal static string Error1450 => LanguageText_fr.ResourceManager.GetString("Error1450", LanguageText_fr.resourceCulture);

		internal static string Error1451 => LanguageText_fr.ResourceManager.GetString("Error1451", LanguageText_fr.resourceCulture);

		internal static string Error1600 => LanguageText_fr.ResourceManager.GetString("Error1600", LanguageText_fr.resourceCulture);

		internal static string Error1601 => LanguageText_fr.ResourceManager.GetString("Error1601", LanguageText_fr.resourceCulture);

		internal static string Error1602 => LanguageText_fr.ResourceManager.GetString("Error1602", LanguageText_fr.resourceCulture);

		internal static string Error2000 => LanguageText_fr.ResourceManager.GetString("Error2000", LanguageText_fr.resourceCulture);

		internal static string Error2001 => LanguageText_fr.ResourceManager.GetString("Error2001", LanguageText_fr.resourceCulture);

		internal static string Error2002 => LanguageText_fr.ResourceManager.GetString("Error2002", LanguageText_fr.resourceCulture);

		internal static string Error2003 => LanguageText_fr.ResourceManager.GetString("Error2003", LanguageText_fr.resourceCulture);

		internal static string Error2004 => LanguageText_fr.ResourceManager.GetString("Error2004", LanguageText_fr.resourceCulture);

		internal static string Error2005 => LanguageText_fr.ResourceManager.GetString("Error2005", LanguageText_fr.resourceCulture);

		internal static string Error2006 => LanguageText_fr.ResourceManager.GetString("Error2006", LanguageText_fr.resourceCulture);

		internal static string Error2007 => LanguageText_fr.ResourceManager.GetString("Error2007", LanguageText_fr.resourceCulture);

		internal static string Error2008 => LanguageText_fr.ResourceManager.GetString("Error2008", LanguageText_fr.resourceCulture);

		internal static string Error2009 => LanguageText_fr.ResourceManager.GetString("Error2009", LanguageText_fr.resourceCulture);

		internal static string Error2010 => LanguageText_fr.ResourceManager.GetString("Error2010", LanguageText_fr.resourceCulture);

		internal static string Error2011 => LanguageText_fr.ResourceManager.GetString("Error2011", LanguageText_fr.resourceCulture);

		internal static string Error2012 => LanguageText_fr.ResourceManager.GetString("Error2012", LanguageText_fr.resourceCulture);

		internal static string Error2013 => LanguageText_fr.ResourceManager.GetString("Error2013", LanguageText_fr.resourceCulture);

		internal static string Error2014 => LanguageText_fr.ResourceManager.GetString("Error2014", LanguageText_fr.resourceCulture);

		internal static string Error2015 => LanguageText_fr.ResourceManager.GetString("Error2015", LanguageText_fr.resourceCulture);

		internal static string Error2016 => LanguageText_fr.ResourceManager.GetString("Error2016", LanguageText_fr.resourceCulture);

		internal static string Error2017 => LanguageText_fr.ResourceManager.GetString("Error2017", LanguageText_fr.resourceCulture);

		internal static string Error2018 => LanguageText_fr.ResourceManager.GetString("Error2018", LanguageText_fr.resourceCulture);

		internal static string Error2019 => LanguageText_fr.ResourceManager.GetString("Error2019", LanguageText_fr.resourceCulture);

		internal static string Error2020 => LanguageText_fr.ResourceManager.GetString("Error2020", LanguageText_fr.resourceCulture);

		internal static string Error2021 => LanguageText_fr.ResourceManager.GetString("Error2021", LanguageText_fr.resourceCulture);

		internal static string Error2022 => LanguageText_fr.ResourceManager.GetString("Error2022", LanguageText_fr.resourceCulture);

		internal static string Error2100 => LanguageText_fr.ResourceManager.GetString("Error2100", LanguageText_fr.resourceCulture);

		internal static string Error5000 => LanguageText_fr.ResourceManager.GetString("Error5000", LanguageText_fr.resourceCulture);

		internal static string ErrorCode => LanguageText_fr.ResourceManager.GetString("ErrorCode", LanguageText_fr.resourceCulture);

		internal static string ErrorLog => LanguageText_fr.ResourceManager.GetString("ErrorLog", LanguageText_fr.resourceCulture);

		internal static string ErrorMode => LanguageText_fr.ResourceManager.GetString("ErrorMode", LanguageText_fr.resourceCulture);

		internal static string ErrorNumber => LanguageText_fr.ResourceManager.GetString("ErrorNumber", LanguageText_fr.resourceCulture);

		internal static string ErrorQuitEMG => LanguageText_fr.ResourceManager.GetString("ErrorQuitEMG", LanguageText_fr.resourceCulture);

		internal static string EuropeanTime => LanguageText_fr.ResourceManager.GetString("EuropeanTime", LanguageText_fr.resourceCulture);

		internal static string Even => LanguageText_fr.ResourceManager.GetString("Even", LanguageText_fr.resourceCulture);

		internal static string Exit => LanguageText_fr.ResourceManager.GetString("Exit", LanguageText_fr.resourceCulture);

		internal static string Export => LanguageText_fr.ResourceManager.GetString("Export", LanguageText_fr.resourceCulture);

		internal static string ExportLastResults => LanguageText_fr.ResourceManager.GetString("ExportLastResults", LanguageText_fr.resourceCulture);

		internal static string ExportLogbook => LanguageText_fr.ResourceManager.GetString("ExportLogbook", LanguageText_fr.resourceCulture);

		internal static string FileOperation => LanguageText_fr.ResourceManager.GetString("FileOperation", LanguageText_fr.resourceCulture);

		internal static string FileOperationMenu => LanguageText_fr.ResourceManager.GetString("FileOperationMenu", LanguageText_fr.resourceCulture);

		internal static string FilteredTorque => LanguageText_fr.ResourceManager.GetString("FilteredTorque", LanguageText_fr.resourceCulture);

		internal static string Finalizing => LanguageText_fr.ResourceManager.GetString("Finalizing", LanguageText_fr.resourceCulture);

		internal static string FinalizingStep => LanguageText_fr.ResourceManager.GetString("FinalizingStep", LanguageText_fr.resourceCulture);

		internal static string ForceSignals => LanguageText_fr.ResourceManager.GetString("ForceSignals", LanguageText_fr.resourceCulture);

		internal static string French => LanguageText_fr.ResourceManager.GetString("French", LanguageText_fr.resourceCulture);

		internal static string FrictionSpeed => LanguageText_fr.ResourceManager.GetString("FrictionSpeed", LanguageText_fr.resourceCulture);

		internal static string FrictionTest => LanguageText_fr.ResourceManager.GetString("FrictionTest", LanguageText_fr.resourceCulture);

		internal static string FrictionTestEMG => LanguageText_fr.ResourceManager.GetString("FrictionTestEMG", LanguageText_fr.resourceCulture);

		internal static string FrictionTestStartup => LanguageText_fr.ResourceManager.GetString("FrictionTestStartup", LanguageText_fr.resourceCulture);

		internal static string FrictionTorque => LanguageText_fr.ResourceManager.GetString("FrictionTorque", LanguageText_fr.resourceCulture);

		internal static string FromAbove => LanguageText_fr.ResourceManager.GetString("FromAbove", LanguageText_fr.resourceCulture);

		internal static string FromAboveOverload => LanguageText_fr.ResourceManager.GetString("FromAboveOverload", LanguageText_fr.resourceCulture);

		internal static string gBAnaSignal => LanguageText_fr.ResourceManager.GetString("gBAnaSignal", LanguageText_fr.resourceCulture);

		internal static string gBDateTime => LanguageText_fr.ResourceManager.GetString("gBDateTime", LanguageText_fr.resourceCulture);

		internal static string gBError => LanguageText_fr.ResourceManager.GetString("gBError", LanguageText_fr.resourceCulture);

		internal static string gBIdentity => LanguageText_fr.ResourceManager.GetString("gBIdentity", LanguageText_fr.resourceCulture);

		internal static string gBIP => LanguageText_fr.ResourceManager.GetString("gBIP", LanguageText_fr.resourceCulture);

		internal static string gBLoadBackup => LanguageText_fr.ResourceManager.GetString("gBLoadBackup", LanguageText_fr.resourceCulture);

		internal static string gBPressure => LanguageText_fr.ResourceManager.GetString("gBPressure", LanguageText_fr.resourceCulture);

		internal static string gBRedundantSensor => LanguageText_fr.ResourceManager.GetString("gBRedundantSensor", LanguageText_fr.resourceCulture);

		internal static string gBResultDisplay => LanguageText_fr.ResourceManager.GetString("gBResultDisplay", LanguageText_fr.resourceCulture);

		internal static string gBRs232 => LanguageText_fr.ResourceManager.GetString("gBRs232", LanguageText_fr.resourceCulture);

		internal static string gBSaveBackup => LanguageText_fr.ResourceManager.GetString("gBSaveBackup", LanguageText_fr.resourceCulture);

		internal static string gBSpindle => LanguageText_fr.ResourceManager.GetString("gBSpindle", LanguageText_fr.resourceCulture);

		internal static string GearFactor => LanguageText_fr.ResourceManager.GetString("GearFactor", LanguageText_fr.resourceCulture);

		internal static string German => LanguageText_fr.ResourceManager.GetString("German", LanguageText_fr.resourceCulture);

		internal static string GetCurve => LanguageText_fr.ResourceManager.GetString("GetCurve", LanguageText_fr.resourceCulture);

		internal static string GetRpm => LanguageText_fr.ResourceManager.GetString("GetRpm", LanguageText_fr.resourceCulture);

		internal static string GoWithoutPassCode => LanguageText_fr.ResourceManager.GetString("GoWithoutPassCode", LanguageText_fr.resourceCulture);

		internal static string GradFilter => LanguageText_fr.ResourceManager.GetString("GradFilter", LanguageText_fr.resourceCulture);

		internal static string Gradient => LanguageText_fr.ResourceManager.GetString("Gradient", LanguageText_fr.resourceCulture);

		internal static string GradientLength => LanguageText_fr.ResourceManager.GetString("GradientLength", LanguageText_fr.resourceCulture);

		internal static string HandMode => LanguageText_fr.ResourceManager.GetString("HandMode", LanguageText_fr.resourceCulture);

		internal static string HandStart => LanguageText_fr.ResourceManager.GetString("HandStart", LanguageText_fr.resourceCulture);

		internal static string HandStartIsInitiated => LanguageText_fr.ResourceManager.GetString("HandStartIsInitiated", LanguageText_fr.resourceCulture);

		internal static string Help => LanguageText_fr.ResourceManager.GetString("Help", LanguageText_fr.resourceCulture);

		internal static string HexSwitch => LanguageText_fr.ResourceManager.GetString("HexSwitch", LanguageText_fr.resourceCulture);

		internal static string Hold => LanguageText_fr.ResourceManager.GetString("Hold", LanguageText_fr.resourceCulture);

		internal static string Holder => LanguageText_fr.ResourceManager.GetString("Holder", LanguageText_fr.resourceCulture);

		internal static string HolderPressureScale => LanguageText_fr.ResourceManager.GetString("HolderPressureScale", LanguageText_fr.resourceCulture);

		internal static string IdentServer => LanguageText_fr.ResourceManager.GetString("IdentServer", LanguageText_fr.resourceCulture);

		internal static string Increment => LanguageText_fr.ResourceManager.GetString("Increment", LanguageText_fr.resourceCulture);

		internal static string Inputs => LanguageText_fr.ResourceManager.GetString("Inputs", LanguageText_fr.resourceCulture);

		internal static string InsertProgram => LanguageText_fr.ResourceManager.GetString("InsertProgram", LanguageText_fr.resourceCulture);

		internal static string InsertStep => LanguageText_fr.ResourceManager.GetString("InsertStep", LanguageText_fr.resourceCulture);

		internal static string IntegratedTests => LanguageText_fr.ResourceManager.GetString("IntegratedTests", LanguageText_fr.resourceCulture);

		internal static string IONumber => LanguageText_fr.ResourceManager.GetString("IONumber", LanguageText_fr.resourceCulture);

		internal static string IOTest => LanguageText_fr.ResourceManager.GetString("IOTest", LanguageText_fr.resourceCulture);

		internal static string IPAddress => LanguageText_fr.ResourceManager.GetString("IPAddress", LanguageText_fr.resourceCulture);

		internal static string Italian => LanguageText_fr.ResourceManager.GetString("Italian", LanguageText_fr.resourceCulture);

		internal static string JumpAlwaysTo => LanguageText_fr.ResourceManager.GetString("JumpAlwaysTo", LanguageText_fr.resourceCulture);

		internal static string JumpNokTo => LanguageText_fr.ResourceManager.GetString("JumpNokTo", LanguageText_fr.resourceCulture);

		internal static string JumpOkTo => LanguageText_fr.ResourceManager.GetString("JumpOkTo", LanguageText_fr.resourceCulture);

		internal static string JumpTo => LanguageText_fr.ResourceManager.GetString("JumpTo", LanguageText_fr.resourceCulture);

		internal static string KeyPad => LanguageText_fr.ResourceManager.GetString("KeyPad", LanguageText_fr.resourceCulture);

		internal static string Kind => LanguageText_fr.ResourceManager.GetString("Kind", LanguageText_fr.resourceCulture);

		internal static string Language => LanguageText_fr.ResourceManager.GetString("Language", LanguageText_fr.resourceCulture);

		internal static string LastDoneStep => LanguageText_fr.ResourceManager.GetString("LastDoneStep", LanguageText_fr.resourceCulture);

		internal static string LastNIO => LanguageText_fr.ResourceManager.GetString("LastNIO", LanguageText_fr.resourceCulture);

		internal static string LastResults => LanguageText_fr.ResourceManager.GetString("LastResults", LanguageText_fr.resourceCulture);

		internal static string LeftAngle => LanguageText_fr.ResourceManager.GetString("LeftAngle", LanguageText_fr.resourceCulture);

		internal static string LevelAdministrator => LanguageText_fr.ResourceManager.GetString("LevelAdministrator", LanguageText_fr.resourceCulture);

		internal static string LevelProgramer => LanguageText_fr.ResourceManager.GetString("LevelProgramer", LanguageText_fr.resourceCulture);

		internal static string LevelUser => LanguageText_fr.ResourceManager.GetString("LevelUser", LanguageText_fr.resourceCulture);

		internal static string LivingMonitor => LanguageText_fr.ResourceManager.GetString("LivingMonitor", LanguageText_fr.resourceCulture);

		internal static string LivingSign => LanguageText_fr.ResourceManager.GetString("LivingSign", LanguageText_fr.resourceCulture);

		internal static string LoadCurveData => LanguageText_fr.ResourceManager.GetString("LoadCurveData", LanguageText_fr.resourceCulture);

		internal static string LoadCurveDataFromFile => LanguageText_fr.ResourceManager.GetString("LoadCurveDataFromFile", LanguageText_fr.resourceCulture);

		internal static string LoadCustBackup => LanguageText_fr.ResourceManager.GetString("LoadCustBackup", LanguageText_fr.resourceCulture);

		internal static string LoadCustBackupFromCF => LanguageText_fr.ResourceManager.GetString("LoadCustBackupFromCF", LanguageText_fr.resourceCulture);

		internal static string LoadCustBackupSecQuery => LanguageText_fr.ResourceManager.GetString("LoadCustBackupSecQuery", LanguageText_fr.resourceCulture);

		internal static string LoadCycleCount => LanguageText_fr.ResourceManager.GetString("LoadCycleCount", LanguageText_fr.resourceCulture);

		internal static string LoadFromFile => LanguageText_fr.ResourceManager.GetString("LoadFromFile", LanguageText_fr.resourceCulture);

		internal static string LoadIO => LanguageText_fr.ResourceManager.GetString("LoadIO", LanguageText_fr.resourceCulture);

		internal static string LoadLastNIOResults => LanguageText_fr.ResourceManager.GetString("LoadLastNIOResults", LanguageText_fr.resourceCulture);

		internal static string LoadLastResults => LanguageText_fr.ResourceManager.GetString("LoadLastResults", LanguageText_fr.resourceCulture);

		internal static string LoadLogBookData => LanguageText_fr.ResourceManager.GetString("LoadLogBookData", LanguageText_fr.resourceCulture);

		internal static string LoadPLCIO => LanguageText_fr.ResourceManager.GetString("LoadPLCIO", LanguageText_fr.resourceCulture);

		internal static string LoadPProgFromFile => LanguageText_fr.ResourceManager.GetString("LoadPProgFromFile", LanguageText_fr.resourceCulture);

		internal static string LoadProcessInfo => LanguageText_fr.ResourceManager.GetString("LoadProcessInfo", LanguageText_fr.resourceCulture);

		internal static string LoadProgramData => LanguageText_fr.ResourceManager.GetString("LoadProgramData", LanguageText_fr.resourceCulture);

		internal static string LoadProgramDataLocally => LanguageText_fr.ResourceManager.GetString("LoadProgramDataLocally", LanguageText_fr.resourceCulture);

		internal static string LoadRecursiveStat => LanguageText_fr.ResourceManager.GetString("LoadRecursiveStat", LanguageText_fr.resourceCulture);

		internal static string LoadResults => LanguageText_fr.ResourceManager.GetString("LoadResults", LanguageText_fr.resourceCulture);

		internal static string LoadSingleProgFromFile => LanguageText_fr.ResourceManager.GetString("LoadSingleProgFromFile", LanguageText_fr.resourceCulture);

		internal static string LoadSpindleConst => LanguageText_fr.ResourceManager.GetString("LoadSpindleConst", LanguageText_fr.resourceCulture);

		internal static string LoadSpindleDataLocally => LanguageText_fr.ResourceManager.GetString("LoadSpindleDataLocally", LanguageText_fr.resourceCulture);

		internal static string LoadSystemConst => LanguageText_fr.ResourceManager.GetString("LoadSystemConst", LanguageText_fr.resourceCulture);

		internal static string LoadWebBackupSecQuery => LanguageText_fr.ResourceManager.GetString("LoadWebBackupSecQuery", LanguageText_fr.resourceCulture);

		internal static string LoadWeberBackup => LanguageText_fr.ResourceManager.GetString("LoadWeberBackup", LanguageText_fr.resourceCulture);

		internal static string LoadWeberBackupFromCF => LanguageText_fr.ResourceManager.GetString("LoadWeberBackupFromCF", LanguageText_fr.resourceCulture);

		internal static string LocalTime => LanguageText_fr.ResourceManager.GetString("LocalTime", LanguageText_fr.resourceCulture);

		internal static string LogBook => LanguageText_fr.ResourceManager.GetString("LogBook", LanguageText_fr.resourceCulture);

		internal static string LogBookMessage100000 => LanguageText_fr.ResourceManager.GetString("LogBookMessage100000", LanguageText_fr.resourceCulture);

		internal static string LogBookMessage200000 => LanguageText_fr.ResourceManager.GetString("LogBookMessage200000", LanguageText_fr.resourceCulture);

		internal static string LogBookMessage300000 => LanguageText_fr.ResourceManager.GetString("LogBookMessage300000", LanguageText_fr.resourceCulture);

		internal static string LogBookMessage300001 => LanguageText_fr.ResourceManager.GetString("LogBookMessage300001", LanguageText_fr.resourceCulture);

		internal static string LogBookTable => LanguageText_fr.ResourceManager.GetString("LogBookTable", LanguageText_fr.resourceCulture);

		internal static string Login => LanguageText_fr.ResourceManager.GetString("Login", LanguageText_fr.resourceCulture);

		internal static string LowerLimit => LanguageText_fr.ResourceManager.GetString("LowerLimit", LanguageText_fr.resourceCulture);

		internal static string M1FilterTime => LanguageText_fr.ResourceManager.GetString("M1FilterTime", LanguageText_fr.resourceCulture);

		internal static string M360Follow => LanguageText_fr.ResourceManager.GetString("M360Follow", LanguageText_fr.resourceCulture);

		internal static string MachineCounter => LanguageText_fr.ResourceManager.GetString("MachineCounter", LanguageText_fr.resourceCulture);

		internal static string MachineVisu => LanguageText_fr.ResourceManager.GetString("MachineVisu", LanguageText_fr.resourceCulture);

		internal static string MakeNewEntry => LanguageText_fr.ResourceManager.GetString("MakeNewEntry", LanguageText_fr.resourceCulture);

		internal static string Max => LanguageText_fr.ResourceManager.GetString("Max", LanguageText_fr.resourceCulture);

		internal static string MaxFrictionTorque => LanguageText_fr.ResourceManager.GetString("MaxFrictionTorque", LanguageText_fr.resourceCulture);

		internal static string MaxRpm => LanguageText_fr.ResourceManager.GetString("MaxRpm", LanguageText_fr.resourceCulture);

		internal static string MaxSaveCurveNum => LanguageText_fr.ResourceManager.GetString("MaxSaveCurveNum", LanguageText_fr.resourceCulture);

		internal static string MaxScrewTime => LanguageText_fr.ResourceManager.GetString("MaxScrewTime", LanguageText_fr.resourceCulture);

		internal static string MaxTorque => LanguageText_fr.ResourceManager.GetString("MaxTorque", LanguageText_fr.resourceCulture);

		internal static string MbAccessByAnother => LanguageText_fr.ResourceManager.GetString("MbAccessByAnother", LanguageText_fr.resourceCulture);

		internal static string MbAccessNotPossible => LanguageText_fr.ResourceManager.GetString("MbAccessNotPossible", LanguageText_fr.resourceCulture);

		internal static string MbAccessRequestTwice => LanguageText_fr.ResourceManager.GetString("MbAccessRequestTwice", LanguageText_fr.resourceCulture);

		internal static string MBackup => LanguageText_fr.ResourceManager.GetString("MBackup", LanguageText_fr.resourceCulture);

		internal static string MbAddNoFrictionTest => LanguageText_fr.ResourceManager.GetString("MbAddNoFrictionTest", LanguageText_fr.resourceCulture);

		internal static string MbAddNoManual => LanguageText_fr.ResourceManager.GetString("MbAddNoManual", LanguageText_fr.resourceCulture);

		internal static string MbAddNoTest => LanguageText_fr.ResourceManager.GetString("MbAddNoTest", LanguageText_fr.resourceCulture);

		internal static string MbAddParamViewOnly => LanguageText_fr.ResourceManager.GetString("MbAddParamViewOnly", LanguageText_fr.resourceCulture);

		internal static string MbAutomaticIsActive1 => LanguageText_fr.ResourceManager.GetString("MbAutomaticIsActive1", LanguageText_fr.resourceCulture);

		internal static string MbAutomaticIsActive2 => LanguageText_fr.ResourceManager.GetString("MbAutomaticIsActive2", LanguageText_fr.resourceCulture);

		internal static string MbComandTimeOut => LanguageText_fr.ResourceManager.GetString("MbComandTimeOut", LanguageText_fr.resourceCulture);

		internal static string MbCreateDefaultPasscode => LanguageText_fr.ResourceManager.GetString("MbCreateDefaultPasscode", LanguageText_fr.resourceCulture);

		internal static string MbCurveLoadFailure => LanguageText_fr.ResourceManager.GetString("MbCurveLoadFailure", LanguageText_fr.resourceCulture);

		internal static string MbCurveSaveFailure => LanguageText_fr.ResourceManager.GetString("MbCurveSaveFailure", LanguageText_fr.resourceCulture);

		internal static string MbDeleteCounterFailure => LanguageText_fr.ResourceManager.GetString("MbDeleteCounterFailure", LanguageText_fr.resourceCulture);

		internal static string MbDeleteCustomCounter => LanguageText_fr.ResourceManager.GetString("MbDeleteCustomCounter", LanguageText_fr.resourceCulture);

		internal static string MbDeleteLastResFailure => LanguageText_fr.ResourceManager.GetString("MbDeleteLastResFailure", LanguageText_fr.resourceCulture);

		internal static string MbDeleteLastResults => LanguageText_fr.ResourceManager.GetString("MbDeleteLastResults", LanguageText_fr.resourceCulture);

		internal static string MbDeleteProg => LanguageText_fr.ResourceManager.GetString("MbDeleteProg", LanguageText_fr.resourceCulture);

		internal static string MbDeleteRecStatFailure => LanguageText_fr.ResourceManager.GetString("MbDeleteRecStatFailure", LanguageText_fr.resourceCulture);

		internal static string MbDeleteRecursiveStat => LanguageText_fr.ResourceManager.GetString("MbDeleteRecursiveStat", LanguageText_fr.resourceCulture);

		internal static string MbDeleteStatAfterProgChange => LanguageText_fr.ResourceManager.GetString("MbDeleteStatAfterProgChange", LanguageText_fr.resourceCulture);

		internal static string MbDoubleEntryCodeFound => LanguageText_fr.ResourceManager.GetString("MbDoubleEntryCodeFound", LanguageText_fr.resourceCulture);

		internal static string MbEmptyProgram => LanguageText_fr.ResourceManager.GetString("MbEmptyProgram", LanguageText_fr.resourceCulture);

		internal static string MbErrorQuitFailure => LanguageText_fr.ResourceManager.GetString("MbErrorQuitFailure", LanguageText_fr.resourceCulture);

		internal static string MbExit => LanguageText_fr.ResourceManager.GetString("MbExit", LanguageText_fr.resourceCulture);

		internal static string MbGotNoConnection => LanguageText_fr.ResourceManager.GetString("MbGotNoConnection", LanguageText_fr.resourceCulture);

		internal static string MbHandstartIsActive => LanguageText_fr.ResourceManager.GetString("MbHandstartIsActive", LanguageText_fr.resourceCulture);

		internal static string MbHandstartNotTwice => LanguageText_fr.ResourceManager.GetString("MbHandstartNotTwice", LanguageText_fr.resourceCulture);

		internal static string MbhError => LanguageText_fr.ResourceManager.GetString("MbhError", LanguageText_fr.resourceCulture);

		internal static string MbhHint => LanguageText_fr.ResourceManager.GetString("MbhHint", LanguageText_fr.resourceCulture);

		internal static string MbhNoAccess => LanguageText_fr.ResourceManager.GetString("MbhNoAccess", LanguageText_fr.resourceCulture);

		internal static string MbhSecurityQuery => LanguageText_fr.ResourceManager.GetString("MbhSecurityQuery", LanguageText_fr.resourceCulture);

		internal static string MbhViewOnlyMode => LanguageText_fr.ResourceManager.GetString("MbhViewOnlyMode", LanguageText_fr.resourceCulture);

		internal static string MbIPChange => LanguageText_fr.ResourceManager.GetString("MbIPChange", LanguageText_fr.resourceCulture);

		internal static string MbKeyLockActive => LanguageText_fr.ResourceManager.GetString("MbKeyLockActive", LanguageText_fr.resourceCulture);

		internal static string MbLoadCustBackupFailure => LanguageText_fr.ResourceManager.GetString("MbLoadCustBackupFailure", LanguageText_fr.resourceCulture);

		internal static string MbLoadWeberBackupFailure => LanguageText_fr.ResourceManager.GetString("MbLoadWeberBackupFailure", LanguageText_fr.resourceCulture);

		internal static string MbLocationError => LanguageText_fr.ResourceManager.GetString("MbLocationError", LanguageText_fr.resourceCulture);

		internal static string MbLogbookWriteFailure => LanguageText_fr.ResourceManager.GetString("MbLogbookWriteFailure", LanguageText_fr.resourceCulture);

		internal static string MbMaxPasscodeNum1 => LanguageText_fr.ResourceManager.GetString("MbMaxPasscodeNum1", LanguageText_fr.resourceCulture);

		internal static string MbMaxPasscodeNum2 => LanguageText_fr.ResourceManager.GetString("MbMaxPasscodeNum2", LanguageText_fr.resourceCulture);

		internal static string MbNoAccess => LanguageText_fr.ResourceManager.GetString("MbNoAccess", LanguageText_fr.resourceCulture);

		internal static string MbNoAccessCauseAuto => LanguageText_fr.ResourceManager.GetString("MbNoAccessCauseAuto", LanguageText_fr.resourceCulture);

		internal static string MbNoConnection => LanguageText_fr.ResourceManager.GetString("MbNoConnection", LanguageText_fr.resourceCulture);

		internal static string MbNoTestCauseAuto => LanguageText_fr.ResourceManager.GetString("MbNoTestCauseAuto", LanguageText_fr.resourceCulture);

		internal static string MbOfflineMode => LanguageText_fr.ResourceManager.GetString("MbOfflineMode", LanguageText_fr.resourceCulture);

		internal static string MbOldPProgLoad => LanguageText_fr.ResourceManager.GetString("MbOldPProgLoad", LanguageText_fr.resourceCulture);

		internal static string MbOldProgLoad => LanguageText_fr.ResourceManager.GetString("MbOldProgLoad", LanguageText_fr.resourceCulture);

		internal static string MbOverwriteProg => LanguageText_fr.ResourceManager.GetString("MbOverwriteProg", LanguageText_fr.resourceCulture);

		internal static string MbPasscodeFailure1 => LanguageText_fr.ResourceManager.GetString("MbPasscodeFailure1", LanguageText_fr.resourceCulture);

		internal static string MbPasscodeFailure2 => LanguageText_fr.ResourceManager.GetString("MbPasscodeFailure2", LanguageText_fr.resourceCulture);

		internal static string MbPasscodeFailure3 => LanguageText_fr.ResourceManager.GetString("MbPasscodeFailure3", LanguageText_fr.resourceCulture);

		internal static string MbPasscodeFailure4 => LanguageText_fr.ResourceManager.GetString("MbPasscodeFailure4", LanguageText_fr.resourceCulture);

		internal static string MbPProgCopyFailure => LanguageText_fr.ResourceManager.GetString("MbPProgCopyFailure", LanguageText_fr.resourceCulture);

		internal static string MbPProgLoadFromFileFailure => LanguageText_fr.ResourceManager.GetString("MbPProgLoadFromFileFailure", LanguageText_fr.resourceCulture);

		internal static string MbPProgSaveToFileFailure => LanguageText_fr.ResourceManager.GetString("MbPProgSaveToFileFailure", LanguageText_fr.resourceCulture);

		internal static string MbProgramCopyFailure => LanguageText_fr.ResourceManager.GetString("MbProgramCopyFailure", LanguageText_fr.resourceCulture);

		internal static string MbProgramEmptySaveAnyway => LanguageText_fr.ResourceManager.GetString("MbProgramEmptySaveAnyway", LanguageText_fr.resourceCulture);

		internal static string MbSaveCustBackupFailure => LanguageText_fr.ResourceManager.GetString("MbSaveCustBackupFailure", LanguageText_fr.resourceCulture);

		internal static string MbSaveDataLocally => LanguageText_fr.ResourceManager.GetString("MbSaveDataLocally", LanguageText_fr.resourceCulture);

		internal static string MbSavedProgramDataToFile => LanguageText_fr.ResourceManager.GetString("MbSavedProgramDataToFile", LanguageText_fr.resourceCulture);

		internal static string MbSavedSpindleDataToFile => LanguageText_fr.ResourceManager.GetString("MbSavedSpindleDataToFile", LanguageText_fr.resourceCulture);

		internal static string MbSaveNotVerifiedData => LanguageText_fr.ResourceManager.GetString("MbSaveNotVerifiedData", LanguageText_fr.resourceCulture);

		internal static string MbSavePasscodeFailure => LanguageText_fr.ResourceManager.GetString("MbSavePasscodeFailure", LanguageText_fr.resourceCulture);

		internal static string MbSaveProgFailure => LanguageText_fr.ResourceManager.GetString("MbSaveProgFailure", LanguageText_fr.resourceCulture);

		internal static string MbSaveProgOnCPUFailure => LanguageText_fr.ResourceManager.GetString("MbSaveProgOnCPUFailure", LanguageText_fr.resourceCulture);

		internal static string MbSaveSpConstFailure => LanguageText_fr.ResourceManager.GetString("MbSaveSpConstFailure", LanguageText_fr.resourceCulture);

		internal static string MbSaveSysConstFailure => LanguageText_fr.ResourceManager.GetString("MbSaveSysConstFailure", LanguageText_fr.resourceCulture);

		internal static string MbSaveWeberBackupFailure => LanguageText_fr.ResourceManager.GetString("MbSaveWeberBackupFailure", LanguageText_fr.resourceCulture);

		internal static string MbShortNameFailure1 => LanguageText_fr.ResourceManager.GetString("MbShortNameFailure1", LanguageText_fr.resourceCulture);

		internal static string MbShortNameFailure2 => LanguageText_fr.ResourceManager.GetString("MbShortNameFailure2", LanguageText_fr.resourceCulture);

		internal static string MbShortNameFailure3 => LanguageText_fr.ResourceManager.GetString("MbShortNameFailure3", LanguageText_fr.resourceCulture);

		internal static string MbSpindleCopyFailure => LanguageText_fr.ResourceManager.GetString("MbSpindleCopyFailure", LanguageText_fr.resourceCulture);

		internal static string MbSpindleLoadFromFileFailure => LanguageText_fr.ResourceManager.GetString("MbSpindleLoadFromFileFailure", LanguageText_fr.resourceCulture);

		internal static string MbSpindleSaveToFileFailure => LanguageText_fr.ResourceManager.GetString("MbSpindleSaveToFileFailure", LanguageText_fr.resourceCulture);

		internal static string MbStepCopyFailure => LanguageText_fr.ResourceManager.GetString("MbStepCopyFailure", LanguageText_fr.resourceCulture);

		internal static string MbWrongPassword => LanguageText_fr.ResourceManager.GetString("MbWrongPassword", LanguageText_fr.resourceCulture);

		internal static string MCheckParameter => LanguageText_fr.ResourceManager.GetString("MCheckParameter", LanguageText_fr.resourceCulture);

		internal static string MCurveDisplay => LanguageText_fr.ResourceManager.GetString("MCurveDisplay", LanguageText_fr.resourceCulture);

		internal static string MCurveSelection => LanguageText_fr.ResourceManager.GetString("MCurveSelection", LanguageText_fr.resourceCulture);

		internal static string MCycleCounter => LanguageText_fr.ResourceManager.GetString("MCycleCounter", LanguageText_fr.resourceCulture);

		internal static string MDelay => LanguageText_fr.ResourceManager.GetString("MDelay", LanguageText_fr.resourceCulture);

		internal static string Mean => LanguageText_fr.ResourceManager.GetString("Mean", LanguageText_fr.resourceCulture);

		internal static string MEditStep => LanguageText_fr.ResourceManager.GetString("MEditStep", LanguageText_fr.resourceCulture);

		internal static string MenuAnalysis => LanguageText_fr.ResourceManager.GetString("MenuAnalysis", LanguageText_fr.resourceCulture);

		internal static string MenuParameter => LanguageText_fr.ResourceManager.GetString("MenuParameter", LanguageText_fr.resourceCulture);

		internal static string MenuStatistics => LanguageText_fr.ResourceManager.GetString("MenuStatistics", LanguageText_fr.resourceCulture);

		internal static string MenuTest => LanguageText_fr.ResourceManager.GetString("MenuTest", LanguageText_fr.resourceCulture);

		internal static string Message => LanguageText_fr.ResourceManager.GetString("Message", LanguageText_fr.resourceCulture);

		internal static string MHandStart => LanguageText_fr.ResourceManager.GetString("MHandStart", LanguageText_fr.resourceCulture);

		internal static string Milimeter => LanguageText_fr.ResourceManager.GetString("Milimeter", LanguageText_fr.resourceCulture);

		internal static string Milisecond => LanguageText_fr.ResourceManager.GetString("Milisecond", LanguageText_fr.resourceCulture);

		internal static string Min => LanguageText_fr.ResourceManager.GetString("Min", LanguageText_fr.resourceCulture);

		internal static string MiniDisplay => LanguageText_fr.ResourceManager.GetString("MiniDisplay", LanguageText_fr.resourceCulture);

		internal static string Minimize => LanguageText_fr.ResourceManager.GetString("Minimize", LanguageText_fr.resourceCulture);

		internal static string MLastNIO => LanguageText_fr.ResourceManager.GetString("MLastNIO", LanguageText_fr.resourceCulture);

		internal static string MLogBook => LanguageText_fr.ResourceManager.GetString("MLogBook", LanguageText_fr.resourceCulture);

		internal static string MOptPrgParam => LanguageText_fr.ResourceManager.GetString("MOptPrgParam", LanguageText_fr.resourceCulture);

		internal static string Motor => LanguageText_fr.ResourceManager.GetString("Motor", LanguageText_fr.resourceCulture);

		internal static string MPasscodeManager => LanguageText_fr.ResourceManager.GetString("MPasscodeManager", LanguageText_fr.resourceCulture);

		internal static string MPrintSelection => LanguageText_fr.ResourceManager.GetString("MPrintSelection", LanguageText_fr.resourceCulture);

		internal static string MProgramOverview => LanguageText_fr.ResourceManager.GetString("MProgramOverview", LanguageText_fr.resourceCulture);

		internal static string MSpindleConstants => LanguageText_fr.ResourceManager.GetString("MSpindleConstants", LanguageText_fr.resourceCulture);

		internal static string MStepOverview => LanguageText_fr.ResourceManager.GetString("MStepOverview", LanguageText_fr.resourceCulture);

		internal static string MStepResults => LanguageText_fr.ResourceManager.GetString("MStepResults", LanguageText_fr.resourceCulture);

		internal static string MSystemConstants => LanguageText_fr.ResourceManager.GetString("MSystemConstants", LanguageText_fr.resourceCulture);

		internal static string MVisualisationParam => LanguageText_fr.ResourceManager.GetString("MVisualisationParam", LanguageText_fr.resourceCulture);

		internal static string Name => LanguageText_fr.ResourceManager.GetString("Name", LanguageText_fr.resourceCulture);

		internal static string Negative => LanguageText_fr.ResourceManager.GetString("Negative", LanguageText_fr.resourceCulture);

		internal static string NegOverload => LanguageText_fr.ResourceManager.GetString("NegOverload", LanguageText_fr.resourceCulture);

		internal static string NewEntry => LanguageText_fr.ResourceManager.GetString("NewEntry", LanguageText_fr.resourceCulture);

		internal static string NewValue => LanguageText_fr.ResourceManager.GetString("NewValue", LanguageText_fr.resourceCulture);

		internal static string Next50Curves => LanguageText_fr.ResourceManager.GetString("Next50Curves", LanguageText_fr.resourceCulture);

		internal static string NIO10 => LanguageText_fr.ResourceManager.GetString("NIO10", LanguageText_fr.resourceCulture);

		internal static string NIO10001 => LanguageText_fr.ResourceManager.GetString("NIO10001", LanguageText_fr.resourceCulture);

		internal static string NIO10002 => LanguageText_fr.ResourceManager.GetString("NIO10002", LanguageText_fr.resourceCulture);

		internal static string NIO10003 => LanguageText_fr.ResourceManager.GetString("NIO10003", LanguageText_fr.resourceCulture);

		internal static string NIO10004 => LanguageText_fr.ResourceManager.GetString("NIO10004", LanguageText_fr.resourceCulture);

		internal static string NIO11 => LanguageText_fr.ResourceManager.GetString("NIO11", LanguageText_fr.resourceCulture);

		internal static string NIO110 => LanguageText_fr.ResourceManager.GetString("NIO110", LanguageText_fr.resourceCulture);

		internal static string NIO12 => LanguageText_fr.ResourceManager.GetString("NIO12", LanguageText_fr.resourceCulture);

		internal static string NIO13 => LanguageText_fr.ResourceManager.GetString("NIO13", LanguageText_fr.resourceCulture);

		internal static string NIO30 => LanguageText_fr.ResourceManager.GetString("NIO30", LanguageText_fr.resourceCulture);

		internal static string NIO31 => LanguageText_fr.ResourceManager.GetString("NIO31", LanguageText_fr.resourceCulture);

		internal static string NIO40 => LanguageText_fr.ResourceManager.GetString("NIO40", LanguageText_fr.resourceCulture);

		internal static string NIO41 => LanguageText_fr.ResourceManager.GetString("NIO41", LanguageText_fr.resourceCulture);

		internal static string NIO50 => LanguageText_fr.ResourceManager.GetString("NIO50", LanguageText_fr.resourceCulture);

		internal static string NIO51 => LanguageText_fr.ResourceManager.GetString("NIO51", LanguageText_fr.resourceCulture);

		internal static string NIO60 => LanguageText_fr.ResourceManager.GetString("NIO60", LanguageText_fr.resourceCulture);

		internal static string NIO61 => LanguageText_fr.ResourceManager.GetString("NIO61", LanguageText_fr.resourceCulture);

		internal static string NIO70 => LanguageText_fr.ResourceManager.GetString("NIO70", LanguageText_fr.resourceCulture);

		internal static string NIO71 => LanguageText_fr.ResourceManager.GetString("NIO71", LanguageText_fr.resourceCulture);

		internal static string NIO75 => LanguageText_fr.ResourceManager.GetString("NIO75", LanguageText_fr.resourceCulture);

		internal static string NIO76 => LanguageText_fr.ResourceManager.GetString("NIO76", LanguageText_fr.resourceCulture);

		internal static string NIO80 => LanguageText_fr.ResourceManager.GetString("NIO80", LanguageText_fr.resourceCulture);

		internal static string NIO81 => LanguageText_fr.ResourceManager.GetString("NIO81", LanguageText_fr.resourceCulture);

		internal static string NIO90 => LanguageText_fr.ResourceManager.GetString("NIO90", LanguageText_fr.resourceCulture);

		internal static string NIO91 => LanguageText_fr.ResourceManager.GetString("NIO91", LanguageText_fr.resourceCulture);

		internal static string NIO92 => LanguageText_fr.ResourceManager.GetString("NIO92", LanguageText_fr.resourceCulture);

		internal static string NIO93 => LanguageText_fr.ResourceManager.GetString("NIO93", LanguageText_fr.resourceCulture);

		internal static string NIO94 => LanguageText_fr.ResourceManager.GetString("NIO94", LanguageText_fr.resourceCulture);

		internal static string NIO95 => LanguageText_fr.ResourceManager.GetString("NIO95", LanguageText_fr.resourceCulture);

		internal static string NIO96 => LanguageText_fr.ResourceManager.GetString("NIO96", LanguageText_fr.resourceCulture);

		internal static string NIO97 => LanguageText_fr.ResourceManager.GetString("NIO97", LanguageText_fr.resourceCulture);

		internal static string NIO98 => LanguageText_fr.ResourceManager.GetString("NIO98", LanguageText_fr.resourceCulture);

		internal static string NIO99 => LanguageText_fr.ResourceManager.GetString("NIO99", LanguageText_fr.resourceCulture);

		internal static string NIONumber => LanguageText_fr.ResourceManager.GetString("NIONumber", LanguageText_fr.resourceCulture);

		internal static string NIOReason => LanguageText_fr.ResourceManager.GetString("NIOReason", LanguageText_fr.resourceCulture);

		internal static string No => LanguageText_fr.ResourceManager.GetString("No", LanguageText_fr.resourceCulture);

		internal static string NoData => LanguageText_fr.ResourceManager.GetString("NoData", LanguageText_fr.resourceCulture);

		internal static string NoErrorMode => LanguageText_fr.ResourceManager.GetString("NoErrorMode", LanguageText_fr.resourceCulture);

		internal static string NOK => LanguageText_fr.ResourceManager.GetString("NOK", LanguageText_fr.resourceCulture);

		internal static string None => LanguageText_fr.ResourceManager.GetString("None", LanguageText_fr.resourceCulture);

		internal static string NoParity => LanguageText_fr.ResourceManager.GetString("NoParity", LanguageText_fr.resourceCulture);

		internal static string NoSelection => LanguageText_fr.ResourceManager.GetString("NoSelection", LanguageText_fr.resourceCulture);

		internal static string NoSignal => LanguageText_fr.ResourceManager.GetString("NoSignal", LanguageText_fr.resourceCulture);

		internal static string NotValid => LanguageText_fr.ResourceManager.GetString("NotValid", LanguageText_fr.resourceCulture);

		internal static string Number => LanguageText_fr.ResourceManager.GetString("Number", LanguageText_fr.resourceCulture);

		internal static string NumberPad => LanguageText_fr.ResourceManager.GetString("NumberPad", LanguageText_fr.resourceCulture);

		internal static string Odd => LanguageText_fr.ResourceManager.GetString("Odd", LanguageText_fr.resourceCulture);

		internal static string Off => LanguageText_fr.ResourceManager.GetString("Off", LanguageText_fr.resourceCulture);

		internal static string OfflineMode => LanguageText_fr.ResourceManager.GetString("OfflineMode", LanguageText_fr.resourceCulture);

		internal static string OffsetTeachValue => LanguageText_fr.ResourceManager.GetString("OffsetTeachValue", LanguageText_fr.resourceCulture);

		internal static string OffsetVoltageMax => LanguageText_fr.ResourceManager.GetString("OffsetVoltageMax", LanguageText_fr.resourceCulture);

		internal static string OffsetVoltageMin => LanguageText_fr.ResourceManager.GetString("OffsetVoltageMin", LanguageText_fr.resourceCulture);

		internal static string OfStep => LanguageText_fr.ResourceManager.GetString("OfStep", LanguageText_fr.resourceCulture);

		internal static string OK => LanguageText_fr.ResourceManager.GetString("OK", LanguageText_fr.resourceCulture);

		internal static string OKNOK => LanguageText_fr.ResourceManager.GetString("OKNOK", LanguageText_fr.resourceCulture);

		internal static string OldValue => LanguageText_fr.ResourceManager.GetString("OldValue", LanguageText_fr.resourceCulture);

		internal static string On => LanguageText_fr.ResourceManager.GetString("On", LanguageText_fr.resourceCulture);

		internal static string OnlineMode => LanguageText_fr.ResourceManager.GetString("OnlineMode", LanguageText_fr.resourceCulture);

		internal static string OnlyIO => LanguageText_fr.ResourceManager.GetString("OnlyIO", LanguageText_fr.resourceCulture);

		internal static string OptPrgParam => LanguageText_fr.ResourceManager.GetString("OptPrgParam", LanguageText_fr.resourceCulture);

		internal static string Organisation => LanguageText_fr.ResourceManager.GetString("Organisation", LanguageText_fr.resourceCulture);

		internal static string OrganizingStep => LanguageText_fr.ResourceManager.GetString("OrganizingStep", LanguageText_fr.resourceCulture);

		internal static string OutOfRange => LanguageText_fr.ResourceManager.GetString("OutOfRange", LanguageText_fr.resourceCulture);

		internal static string Outputs => LanguageText_fr.ResourceManager.GetString("Outputs", LanguageText_fr.resourceCulture);

		internal static string PaintCurve => LanguageText_fr.ResourceManager.GetString("PaintCurve", LanguageText_fr.resourceCulture);

		internal static string Parity => LanguageText_fr.ResourceManager.GetString("Parity", LanguageText_fr.resourceCulture);

		internal static string PasscodeLevel => LanguageText_fr.ResourceManager.GetString("PasscodeLevel", LanguageText_fr.resourceCulture);

		internal static string PasscodeManager => LanguageText_fr.ResourceManager.GetString("PasscodeManager", LanguageText_fr.resourceCulture);

		internal static string Password => LanguageText_fr.ResourceManager.GetString("Password", LanguageText_fr.resourceCulture);

		internal static string PasswordInput => LanguageText_fr.ResourceManager.GetString("PasswordInput", LanguageText_fr.resourceCulture);

		internal static string Percent => LanguageText_fr.ResourceManager.GetString("Percent", LanguageText_fr.resourceCulture);

		internal static string PLC_IO => LanguageText_fr.ResourceManager.GetString("PLC_IO", LanguageText_fr.resourceCulture);

		internal static string PointOfTime => LanguageText_fr.ResourceManager.GetString("PointOfTime", LanguageText_fr.resourceCulture);

		internal static string Positive => LanguageText_fr.ResourceManager.GetString("Positive", LanguageText_fr.resourceCulture);

		internal static string PosOverload => LanguageText_fr.ResourceManager.GetString("PosOverload", LanguageText_fr.resourceCulture);

		internal static string PowerEnabled => LanguageText_fr.ResourceManager.GetString("PowerEnabled", LanguageText_fr.resourceCulture);

		internal static string Pressure => LanguageText_fr.ResourceManager.GetString("Pressure", LanguageText_fr.resourceCulture);

		internal static string PressureSpindle => LanguageText_fr.ResourceManager.GetString("PressureSpindle", LanguageText_fr.resourceCulture);

		internal static string Print => LanguageText_fr.ResourceManager.GetString("Print", LanguageText_fr.resourceCulture);

		internal static string ProcessInputs => LanguageText_fr.ResourceManager.GetString("ProcessInputs", LanguageText_fr.resourceCulture);

		internal static string ProcessRunning => LanguageText_fr.ResourceManager.GetString("ProcessRunning", LanguageText_fr.resourceCulture);

		internal static string Program => LanguageText_fr.ResourceManager.GetString("Program", LanguageText_fr.resourceCulture);

		internal static string ProgramChange201000 => LanguageText_fr.ResourceManager.GetString("ProgramChange201000", LanguageText_fr.resourceCulture);

		internal static string ProgramChange201001 => LanguageText_fr.ResourceManager.GetString("ProgramChange201001", LanguageText_fr.resourceCulture);

		internal static string ProgramChange201002 => LanguageText_fr.ResourceManager.GetString("ProgramChange201002", LanguageText_fr.resourceCulture);

		internal static string ProgramChange201003 => LanguageText_fr.ResourceManager.GetString("ProgramChange201003", LanguageText_fr.resourceCulture);

		internal static string ProgramChange201004 => LanguageText_fr.ResourceManager.GetString("ProgramChange201004", LanguageText_fr.resourceCulture);

		internal static string ProgramChange201005 => LanguageText_fr.ResourceManager.GetString("ProgramChange201005", LanguageText_fr.resourceCulture);

		internal static string ProgramChange201006 => LanguageText_fr.ResourceManager.GetString("ProgramChange201006", LanguageText_fr.resourceCulture);

		internal static string ProgramChange201007 => LanguageText_fr.ResourceManager.GetString("ProgramChange201007", LanguageText_fr.resourceCulture);

		internal static string ProgramChange201008 => LanguageText_fr.ResourceManager.GetString("ProgramChange201008", LanguageText_fr.resourceCulture);

		internal static string ProgramChange201009 => LanguageText_fr.ResourceManager.GetString("ProgramChange201009", LanguageText_fr.resourceCulture);

		internal static string ProgramNumber => LanguageText_fr.ResourceManager.GetString("ProgramNumber", LanguageText_fr.resourceCulture);

		internal static string Programs => LanguageText_fr.ResourceManager.GetString("Programs", LanguageText_fr.resourceCulture);

		internal static string Quit => LanguageText_fr.ResourceManager.GetString("Quit", LanguageText_fr.resourceCulture);

		internal static string Ramp => LanguageText_fr.ResourceManager.GetString("Ramp", LanguageText_fr.resourceCulture);

		internal static string Range => LanguageText_fr.ResourceManager.GetString("Range", LanguageText_fr.resourceCulture);

		internal static string ReadyToStart => LanguageText_fr.ResourceManager.GetString("ReadyToStart", LanguageText_fr.resourceCulture);

		internal static string RecentDateTime => LanguageText_fr.ResourceManager.GetString("RecentDateTime", LanguageText_fr.resourceCulture);

		internal static string Reconnect => LanguageText_fr.ResourceManager.GetString("Reconnect", LanguageText_fr.resourceCulture);

		internal static string ReconnectToController => LanguageText_fr.ResourceManager.GetString("ReconnectToController", LanguageText_fr.resourceCulture);

		internal static string RecursiveStatMode => LanguageText_fr.ResourceManager.GetString("RecursiveStatMode", LanguageText_fr.resourceCulture);

		internal static string RedAngle => LanguageText_fr.ResourceManager.GetString("RedAngle", LanguageText_fr.resourceCulture);

		internal static string RedTorque => LanguageText_fr.ResourceManager.GetString("RedTorque", LanguageText_fr.resourceCulture);

		internal static string RedundantSensorActive => LanguageText_fr.ResourceManager.GetString("RedundantSensorActive", LanguageText_fr.resourceCulture);

		internal static string relatedTo => LanguageText_fr.ResourceManager.GetString("relatedTo", LanguageText_fr.resourceCulture);

		internal static string RelativeTorque => LanguageText_fr.ResourceManager.GetString("RelativeTorque", LanguageText_fr.resourceCulture);

		internal static string Release => LanguageText_fr.ResourceManager.GetString("Release", LanguageText_fr.resourceCulture);

		internal static string ReleaseSpeed => LanguageText_fr.ResourceManager.GetString("ReleaseSpeed", LanguageText_fr.resourceCulture);

		internal static string RelTorqueStep => LanguageText_fr.ResourceManager.GetString("RelTorqueStep", LanguageText_fr.resourceCulture);

		internal static string RemainedCurves => LanguageText_fr.ResourceManager.GetString("RemainedCurves", LanguageText_fr.resourceCulture);

		internal static string Reset => LanguageText_fr.ResourceManager.GetString("Reset", LanguageText_fr.resourceCulture);

		internal static string ResetADepth => LanguageText_fr.ResourceManager.GetString("ResetADepth", LanguageText_fr.resourceCulture);

		internal static string ResetAngle => LanguageText_fr.ResourceManager.GetString("ResetAngle", LanguageText_fr.resourceCulture);

		internal static string Result => LanguageText_fr.ResourceManager.GetString("Result", LanguageText_fr.resourceCulture);

		internal static string ResultDisplay => LanguageText_fr.ResourceManager.GetString("ResultDisplay", LanguageText_fr.resourceCulture);

		internal static string Results => LanguageText_fr.ResourceManager.GetString("Results", LanguageText_fr.resourceCulture);

		internal static string RightAngle => LanguageText_fr.ResourceManager.GetString("RightAngle", LanguageText_fr.resourceCulture);

		internal static string Robot => LanguageText_fr.ResourceManager.GetString("Robot", LanguageText_fr.resourceCulture);

		internal static string RoundsPerMinute => LanguageText_fr.ResourceManager.GetString("RoundsPerMinute", LanguageText_fr.resourceCulture);

		internal static string RpmTest => LanguageText_fr.ResourceManager.GetString("RpmTest", LanguageText_fr.resourceCulture);

		internal static string RpmUnit => LanguageText_fr.ResourceManager.GetString("RpmUnit", LanguageText_fr.resourceCulture);

		internal static string RS232PrintMode => LanguageText_fr.ResourceManager.GetString("RS232PrintMode", LanguageText_fr.resourceCulture);

		internal static string SampleSize => LanguageText_fr.ResourceManager.GetString("SampleSize", LanguageText_fr.resourceCulture);

		internal static string SampleStatistic => LanguageText_fr.ResourceManager.GetString("SampleStatistic", LanguageText_fr.resourceCulture);

		internal static string SaveCurveDataToFile => LanguageText_fr.ResourceManager.GetString("SaveCurveDataToFile", LanguageText_fr.resourceCulture);

		internal static string SaveCustBackup => LanguageText_fr.ResourceManager.GetString("SaveCustBackup", LanguageText_fr.resourceCulture);

		internal static string SaveCustBackupOnCF => LanguageText_fr.ResourceManager.GetString("SaveCustBackupOnCF", LanguageText_fr.resourceCulture);

		internal static string SaveCustBackupSecQuery => LanguageText_fr.ResourceManager.GetString("SaveCustBackupSecQuery", LanguageText_fr.resourceCulture);

		internal static string SavePasscodesOnCPU => LanguageText_fr.ResourceManager.GetString("SavePasscodesOnCPU", LanguageText_fr.resourceCulture);

		internal static string SavePProgToFile => LanguageText_fr.ResourceManager.GetString("SavePProgToFile", LanguageText_fr.resourceCulture);

		internal static string SaveProgOnCPU => LanguageText_fr.ResourceManager.GetString("SaveProgOnCPU", LanguageText_fr.resourceCulture);

		internal static string SaveProgramData => LanguageText_fr.ResourceManager.GetString("SaveProgramData", LanguageText_fr.resourceCulture);

		internal static string SaveProgramDataLocally => LanguageText_fr.ResourceManager.GetString("SaveProgramDataLocally", LanguageText_fr.resourceCulture);

		internal static string SaveSingleProgToFile => LanguageText_fr.ResourceManager.GetString("SaveSingleProgToFile", LanguageText_fr.resourceCulture);

		internal static string SaveSpindleConstOnCPU => LanguageText_fr.ResourceManager.GetString("SaveSpindleConstOnCPU", LanguageText_fr.resourceCulture);

		internal static string SaveSpindleDataLocally => LanguageText_fr.ResourceManager.GetString("SaveSpindleDataLocally", LanguageText_fr.resourceCulture);

		internal static string SaveSystemConstOnCPU => LanguageText_fr.ResourceManager.GetString("SaveSystemConstOnCPU", LanguageText_fr.resourceCulture);

		internal static string SaveToFile => LanguageText_fr.ResourceManager.GetString("SaveToFile", LanguageText_fr.resourceCulture);

		internal static string SaveVisuParam => LanguageText_fr.ResourceManager.GetString("SaveVisuParam", LanguageText_fr.resourceCulture);

		internal static string SaveWebBackupSecQuery => LanguageText_fr.ResourceManager.GetString("SaveWebBackupSecQuery", LanguageText_fr.resourceCulture);

		internal static string SaveWeberBackup => LanguageText_fr.ResourceManager.GetString("SaveWeberBackup", LanguageText_fr.resourceCulture);

		internal static string SaveWeberBackupOnCF => LanguageText_fr.ResourceManager.GetString("SaveWeberBackupOnCF", LanguageText_fr.resourceCulture);

		internal static string ScrewID => LanguageText_fr.ResourceManager.GetString("ScrewID", LanguageText_fr.resourceCulture);

		internal static string ScrewProgramFiles => LanguageText_fr.ResourceManager.GetString("ScrewProgramFiles", LanguageText_fr.resourceCulture);

		internal static string ScrewPrograms => LanguageText_fr.ResourceManager.GetString("ScrewPrograms", LanguageText_fr.resourceCulture);

		internal static string ScrewTime => LanguageText_fr.ResourceManager.GetString("ScrewTime", LanguageText_fr.resourceCulture);

		internal static string Second => LanguageText_fr.ResourceManager.GetString("Second", LanguageText_fr.resourceCulture);

		internal static string SelectAll => LanguageText_fr.ResourceManager.GetString("SelectAll", LanguageText_fr.resourceCulture);

		internal static string SelectedKind => LanguageText_fr.ResourceManager.GetString("SelectedKind", LanguageText_fr.resourceCulture);

		internal static string SelectedXAxis => LanguageText_fr.ResourceManager.GetString("SelectedXAxis", LanguageText_fr.resourceCulture);

		internal static string SelectedYAxis => LanguageText_fr.ResourceManager.GetString("SelectedYAxis", LanguageText_fr.resourceCulture);

		internal static string SelectNone => LanguageText_fr.ResourceManager.GetString("SelectNone", LanguageText_fr.resourceCulture);

		internal static string SelValidNumber => LanguageText_fr.ResourceManager.GetString("SelValidNumber", LanguageText_fr.resourceCulture);

		internal static string SendIO => LanguageText_fr.ResourceManager.GetString("SendIO", LanguageText_fr.resourceCulture);

		internal static string SendPasscodes => LanguageText_fr.ResourceManager.GetString("SendPasscodes", LanguageText_fr.resourceCulture);

		internal static string SendSpindleConstants => LanguageText_fr.ResourceManager.GetString("SendSpindleConstants", LanguageText_fr.resourceCulture);

		internal static string SendSystemConstants => LanguageText_fr.ResourceManager.GetString("SendSystemConstants", LanguageText_fr.resourceCulture);

		internal static string SensorTest => LanguageText_fr.ResourceManager.GetString("SensorTest", LanguageText_fr.resourceCulture);

		internal static string Set => LanguageText_fr.ResourceManager.GetString("Set", LanguageText_fr.resourceCulture);

		internal static string SetAnaOut => LanguageText_fr.ResourceManager.GetString("SetAnaOut", LanguageText_fr.resourceCulture);

		internal static string SetDigOut => LanguageText_fr.ResourceManager.GetString("SetDigOut", LanguageText_fr.resourceCulture);

		internal static string SetOff => LanguageText_fr.ResourceManager.GetString("SetOff", LanguageText_fr.resourceCulture);

		internal static string SetOn => LanguageText_fr.ResourceManager.GetString("SetOn", LanguageText_fr.resourceCulture);

		internal static string SetRight => LanguageText_fr.ResourceManager.GetString("SetRight", LanguageText_fr.resourceCulture);

		internal static string SetRpm => LanguageText_fr.ResourceManager.GetString("SetRpm", LanguageText_fr.resourceCulture);

		internal static string Settings => LanguageText_fr.ResourceManager.GetString("Settings", LanguageText_fr.resourceCulture);

		internal static string ShortName => LanguageText_fr.ResourceManager.GetString("ShortName", LanguageText_fr.resourceCulture);

		internal static string SignalQuit => LanguageText_fr.ResourceManager.GetString("SignalQuit", LanguageText_fr.resourceCulture);

		internal static string Spain => LanguageText_fr.ResourceManager.GetString("Spain", LanguageText_fr.resourceCulture);

		internal static string SpChange100010 => LanguageText_fr.ResourceManager.GetString("SpChange100010", LanguageText_fr.resourceCulture);

		internal static string SpChange203000 => LanguageText_fr.ResourceManager.GetString("SpChange203000", LanguageText_fr.resourceCulture);

		internal static string SpChange203001 => LanguageText_fr.ResourceManager.GetString("SpChange203001", LanguageText_fr.resourceCulture);

		internal static string SpChange203002 => LanguageText_fr.ResourceManager.GetString("SpChange203002", LanguageText_fr.resourceCulture);

		internal static string SpChange203003 => LanguageText_fr.ResourceManager.GetString("SpChange203003", LanguageText_fr.resourceCulture);

		internal static string SpChange203004 => LanguageText_fr.ResourceManager.GetString("SpChange203004", LanguageText_fr.resourceCulture);

		internal static string SpChange203005 => LanguageText_fr.ResourceManager.GetString("SpChange203005", LanguageText_fr.resourceCulture);

		internal static string SpChange203006 => LanguageText_fr.ResourceManager.GetString("SpChange203006", LanguageText_fr.resourceCulture);

		internal static string SpChange203007 => LanguageText_fr.ResourceManager.GetString("SpChange203007", LanguageText_fr.resourceCulture);

		internal static string SpChange203008 => LanguageText_fr.ResourceManager.GetString("SpChange203008", LanguageText_fr.resourceCulture);

		internal static string SpChange203009 => LanguageText_fr.ResourceManager.GetString("SpChange203009", LanguageText_fr.resourceCulture);

		internal static string SpChange203010 => LanguageText_fr.ResourceManager.GetString("SpChange203010", LanguageText_fr.resourceCulture);

		internal static string SpChange203011 => LanguageText_fr.ResourceManager.GetString("SpChange203011", LanguageText_fr.resourceCulture);

		internal static string SpChange203012 => LanguageText_fr.ResourceManager.GetString("SpChange203012", LanguageText_fr.resourceCulture);

		internal static string SpChange203013 => LanguageText_fr.ResourceManager.GetString("SpChange203013", LanguageText_fr.resourceCulture);

		internal static string SpChange203014 => LanguageText_fr.ResourceManager.GetString("SpChange203014", LanguageText_fr.resourceCulture);

		internal static string SpChange203015 => LanguageText_fr.ResourceManager.GetString("SpChange203015", LanguageText_fr.resourceCulture);

		internal static string SpChange203016 => LanguageText_fr.ResourceManager.GetString("SpChange203016", LanguageText_fr.resourceCulture);

		internal static string SpChange203017 => LanguageText_fr.ResourceManager.GetString("SpChange203017", LanguageText_fr.resourceCulture);

		internal static string SpChange203018 => LanguageText_fr.ResourceManager.GetString("SpChange203018", LanguageText_fr.resourceCulture);

		internal static string SpChange203019 => LanguageText_fr.ResourceManager.GetString("SpChange203019", LanguageText_fr.resourceCulture);

		internal static string SpChange203020 => LanguageText_fr.ResourceManager.GetString("SpChange203020", LanguageText_fr.resourceCulture);

		internal static string SpChange203021 => LanguageText_fr.ResourceManager.GetString("SpChange203021", LanguageText_fr.resourceCulture);

		internal static string SpChange203022 => LanguageText_fr.ResourceManager.GetString("SpChange203022", LanguageText_fr.resourceCulture);

		internal static string SpChange203023 => LanguageText_fr.ResourceManager.GetString("SpChange203023", LanguageText_fr.resourceCulture);

		internal static string SpChange203024 => LanguageText_fr.ResourceManager.GetString("SpChange203024", LanguageText_fr.resourceCulture);

		internal static string SpChange203025 => LanguageText_fr.ResourceManager.GetString("SpChange203025", LanguageText_fr.resourceCulture);

		internal static string SpChange203026 => LanguageText_fr.ResourceManager.GetString("SpChange203026", LanguageText_fr.resourceCulture);

		internal static string SpChange203027 => LanguageText_fr.ResourceManager.GetString("SpChange203027", LanguageText_fr.resourceCulture);

		internal static string SpChange203028 => LanguageText_fr.ResourceManager.GetString("SpChange203028", LanguageText_fr.resourceCulture);

		internal static string SpChange203029 => LanguageText_fr.ResourceManager.GetString("SpChange203029", LanguageText_fr.resourceCulture);

		internal static string SpChange203030 => LanguageText_fr.ResourceManager.GetString("SpChange203030", LanguageText_fr.resourceCulture);

		internal static string SpindleConstants => LanguageText_fr.ResourceManager.GetString("SpindleConstants", LanguageText_fr.resourceCulture);

		internal static string SpindleConstFiles => LanguageText_fr.ResourceManager.GetString("SpindleConstFiles", LanguageText_fr.resourceCulture);

		internal static string SpindlePressureScale => LanguageText_fr.ResourceManager.GetString("SpindlePressureScale", LanguageText_fr.resourceCulture);

		internal static string SpindleTorque => LanguageText_fr.ResourceManager.GetString("SpindleTorque", LanguageText_fr.resourceCulture);

		internal static string StandardDeviation => LanguageText_fr.ResourceManager.GetString("StandardDeviation", LanguageText_fr.resourceCulture);

		internal static string StartCycleSave => LanguageText_fr.ResourceManager.GetString("StartCycleSave", LanguageText_fr.resourceCulture);

		internal static string StartFrictionTest => LanguageText_fr.ResourceManager.GetString("StartFrictionTest", LanguageText_fr.resourceCulture);

		internal static string StartProgram => LanguageText_fr.ResourceManager.GetString("StartProgram", LanguageText_fr.resourceCulture);

		internal static string StartSignal => LanguageText_fr.ResourceManager.GetString("StartSignal", LanguageText_fr.resourceCulture);

		internal static string StartStepResExport => LanguageText_fr.ResourceManager.GetString("StartStepResExport", LanguageText_fr.resourceCulture);

		internal static string StartTest => LanguageText_fr.ResourceManager.GetString("StartTest", LanguageText_fr.resourceCulture);

		internal static string StatDelete204000 => LanguageText_fr.ResourceManager.GetString("StatDelete204000", LanguageText_fr.resourceCulture);

		internal static string StatDelete204001 => LanguageText_fr.ResourceManager.GetString("StatDelete204001", LanguageText_fr.resourceCulture);

		internal static string StatDelete204002 => LanguageText_fr.ResourceManager.GetString("StatDelete204002", LanguageText_fr.resourceCulture);

		internal static string StatisticCumul => LanguageText_fr.ResourceManager.GetString("StatisticCumul", LanguageText_fr.resourceCulture);

		internal static string Statistics => LanguageText_fr.ResourceManager.GetString("Statistics", LanguageText_fr.resourceCulture);

		internal static string StatisticSample => LanguageText_fr.ResourceManager.GetString("StatisticSample", LanguageText_fr.resourceCulture);

		internal static string StatisticsLastRes => LanguageText_fr.ResourceManager.GetString("StatisticsLastRes", LanguageText_fr.resourceCulture);

		internal static string Step => LanguageText_fr.ResourceManager.GetString("Step", LanguageText_fr.resourceCulture);

		internal static string StepFinish => LanguageText_fr.ResourceManager.GetString("StepFinish", LanguageText_fr.resourceCulture);

		internal static string StepKind => LanguageText_fr.ResourceManager.GetString("StepKind", LanguageText_fr.resourceCulture);

		internal static string StepKindChoice => LanguageText_fr.ResourceManager.GetString("StepKindChoice", LanguageText_fr.resourceCulture);

		internal static string StepResults => LanguageText_fr.ResourceManager.GetString("StepResults", LanguageText_fr.resourceCulture);

		internal static string Steps => LanguageText_fr.ResourceManager.GetString("Steps", LanguageText_fr.resourceCulture);

		internal static string StepTmin => LanguageText_fr.ResourceManager.GetString("StepTmin", LanguageText_fr.resourceCulture);

		internal static string StepTplus => LanguageText_fr.ResourceManager.GetString("StepTplus", LanguageText_fr.resourceCulture);

		internal static string Stop => LanguageText_fr.ResourceManager.GetString("Stop", LanguageText_fr.resourceCulture);

		internal static string StopNok => LanguageText_fr.ResourceManager.GetString("StopNok", LanguageText_fr.resourceCulture);

		internal static string StopOk => LanguageText_fr.ResourceManager.GetString("StopOk", LanguageText_fr.resourceCulture);

		internal static string StopStepResExport => LanguageText_fr.ResourceManager.GetString("StopStepResExport", LanguageText_fr.resourceCulture);

		internal static string StorageNumber => LanguageText_fr.ResourceManager.GetString("StorageNumber", LanguageText_fr.resourceCulture);

		internal static string StorageSignals => LanguageText_fr.ResourceManager.GetString("StorageSignals", LanguageText_fr.resourceCulture);

		internal static string StoreAndBack => LanguageText_fr.ResourceManager.GetString("StoreAndBack", LanguageText_fr.resourceCulture);

		internal static string SubnetMask => LanguageText_fr.ResourceManager.GetString("SubnetMask", LanguageText_fr.resourceCulture);

		internal static string SyncOut => LanguageText_fr.ResourceManager.GetString("SyncOut", LanguageText_fr.resourceCulture);

		internal static string SyncSignal => LanguageText_fr.ResourceManager.GetString("SyncSignal", LanguageText_fr.resourceCulture);

		internal static string SysChange202000 => LanguageText_fr.ResourceManager.GetString("SysChange202000", LanguageText_fr.resourceCulture);

		internal static string SysChange202001 => LanguageText_fr.ResourceManager.GetString("SysChange202001", LanguageText_fr.resourceCulture);

		internal static string SysChange202002 => LanguageText_fr.ResourceManager.GetString("SysChange202002", LanguageText_fr.resourceCulture);

		internal static string SysChange202003 => LanguageText_fr.ResourceManager.GetString("SysChange202003", LanguageText_fr.resourceCulture);

		internal static string SysChange202004 => LanguageText_fr.ResourceManager.GetString("SysChange202004", LanguageText_fr.resourceCulture);

		internal static string SysChange202005 => LanguageText_fr.ResourceManager.GetString("SysChange202005", LanguageText_fr.resourceCulture);

		internal static string SysChange202006 => LanguageText_fr.ResourceManager.GetString("SysChange202006", LanguageText_fr.resourceCulture);

		internal static string SysChange202007 => LanguageText_fr.ResourceManager.GetString("SysChange202007", LanguageText_fr.resourceCulture);

		internal static string SysChange202008 => LanguageText_fr.ResourceManager.GetString("SysChange202008", LanguageText_fr.resourceCulture);

		internal static string SysChange202009 => LanguageText_fr.ResourceManager.GetString("SysChange202009", LanguageText_fr.resourceCulture);

		internal static string SysChange202010 => LanguageText_fr.ResourceManager.GetString("SysChange202010", LanguageText_fr.resourceCulture);

		internal static string SysChange202011 => LanguageText_fr.ResourceManager.GetString("SysChange202011", LanguageText_fr.resourceCulture);

		internal static string SysChange202012 => LanguageText_fr.ResourceManager.GetString("SysChange202012", LanguageText_fr.resourceCulture);

		internal static string SysChange202013 => LanguageText_fr.ResourceManager.GetString("SysChange202013", LanguageText_fr.resourceCulture);

		internal static string SysChange202014 => LanguageText_fr.ResourceManager.GetString("SysChange202014", LanguageText_fr.resourceCulture);

		internal static string SysChange202015 => LanguageText_fr.ResourceManager.GetString("SysChange202015", LanguageText_fr.resourceCulture);

		internal static string SysChange202016 => LanguageText_fr.ResourceManager.GetString("SysChange202016", LanguageText_fr.resourceCulture);

		internal static string SysChange202017 => LanguageText_fr.ResourceManager.GetString("SysChange202017", LanguageText_fr.resourceCulture);

		internal static string SysChange202018 => LanguageText_fr.ResourceManager.GetString("SysChange202018", LanguageText_fr.resourceCulture);

		internal static string SystemConstants => LanguageText_fr.ResourceManager.GetString("SystemConstants", LanguageText_fr.resourceCulture);

		internal static string SystemID => LanguageText_fr.ResourceManager.GetString("SystemID", LanguageText_fr.resourceCulture);

		internal static string SystemOK => LanguageText_fr.ResourceManager.GetString("SystemOK", LanguageText_fr.resourceCulture);

		internal static string Target => LanguageText_fr.ResourceManager.GetString("Target", LanguageText_fr.resourceCulture);

		internal static string TargetRight => LanguageText_fr.ResourceManager.GetString("TargetRight", LanguageText_fr.resourceCulture);

		internal static string TeachSignal => LanguageText_fr.ResourceManager.GetString("TeachSignal", LanguageText_fr.resourceCulture);

		internal static string Test => LanguageText_fr.ResourceManager.GetString("Test", LanguageText_fr.resourceCulture);

		internal static string TestIO => LanguageText_fr.ResourceManager.GetString("TestIO", LanguageText_fr.resourceCulture);

		internal static string TestMFS => LanguageText_fr.ResourceManager.GetString("TestMFS", LanguageText_fr.resourceCulture);

		internal static string TestSPSIO => LanguageText_fr.ResourceManager.GetString("TestSPSIO", LanguageText_fr.resourceCulture);

		internal static string Time => LanguageText_fr.ResourceManager.GetString("Time", LanguageText_fr.resourceCulture);

		internal static string TimeDateFormat => LanguageText_fr.ResourceManager.GetString("TimeDateFormat", LanguageText_fr.resourceCulture);

		internal static string TimeSet => LanguageText_fr.ResourceManager.GetString("TimeSet", LanguageText_fr.resourceCulture);

		internal static string TimeSynchronize => LanguageText_fr.ResourceManager.GetString("TimeSynchronize", LanguageText_fr.resourceCulture);

		internal static string TM1 => LanguageText_fr.ResourceManager.GetString("TM1", LanguageText_fr.resourceCulture);

		internal static string TM2 => LanguageText_fr.ResourceManager.GetString("TM2", LanguageText_fr.resourceCulture);

		internal static string TN => LanguageText_fr.ResourceManager.GetString("TN", LanguageText_fr.resourceCulture);

		internal static string ToggleCursor => LanguageText_fr.ResourceManager.GetString("ToggleCursor", LanguageText_fr.resourceCulture);

		internal static string TopAll => LanguageText_fr.ResourceManager.GetString("TopAll", LanguageText_fr.resourceCulture);

		internal static string TopTen => LanguageText_fr.ResourceManager.GetString("TopTen", LanguageText_fr.resourceCulture);

		internal static string Torque => LanguageText_fr.ResourceManager.GetString("Torque", LanguageText_fr.resourceCulture);

		internal static string Torqueftlb => LanguageText_fr.ResourceManager.GetString("Torqueftlb", LanguageText_fr.resourceCulture);

		internal static string Torqueinlb => LanguageText_fr.ResourceManager.GetString("Torqueinlb", LanguageText_fr.resourceCulture);

		internal static string Torqueinoz => LanguageText_fr.ResourceManager.GetString("Torqueinoz", LanguageText_fr.resourceCulture);

		internal static string Torquekgcm => LanguageText_fr.ResourceManager.GetString("Torquekgcm", LanguageText_fr.resourceCulture);

		internal static string Torquekgm => LanguageText_fr.ResourceManager.GetString("Torquekgm", LanguageText_fr.resourceCulture);

		internal static string TorqueNcm => LanguageText_fr.ResourceManager.GetString("TorqueNcm", LanguageText_fr.resourceCulture);

		internal static string TorqueNm => LanguageText_fr.ResourceManager.GetString("TorqueNm", LanguageText_fr.resourceCulture);

		internal static string TorqueRedundantTime => LanguageText_fr.ResourceManager.GetString("TorqueRedundantTime", LanguageText_fr.resourceCulture);

		internal static string TorqueRedundantTolerance => LanguageText_fr.ResourceManager.GetString("TorqueRedundantTolerance", LanguageText_fr.resourceCulture);

		internal static string TorqueSensorInvers => LanguageText_fr.ResourceManager.GetString("TorqueSensorInvers", LanguageText_fr.resourceCulture);

		internal static string TorqueSensorScale => LanguageText_fr.ResourceManager.GetString("TorqueSensorScale", LanguageText_fr.resourceCulture);

		internal static string TorqueSensorTolerance => LanguageText_fr.ResourceManager.GetString("TorqueSensorTolerance", LanguageText_fr.resourceCulture);

		internal static string TorqueUnitChoose => LanguageText_fr.ResourceManager.GetString("TorqueUnitChoose", LanguageText_fr.resourceCulture);

		internal static string TreshTorque => LanguageText_fr.ResourceManager.GetString("TreshTorque", LanguageText_fr.resourceCulture);

		internal static string Type => LanguageText_fr.ResourceManager.GetString("Type", LanguageText_fr.resourceCulture);

		internal static string Unit => LanguageText_fr.ResourceManager.GetString("Unit", LanguageText_fr.resourceCulture);

		internal static string UnitBar => LanguageText_fr.ResourceManager.GetString("UnitBar", LanguageText_fr.resourceCulture);

		internal static string UpperLimit => LanguageText_fr.ResourceManager.GetString("UpperLimit", LanguageText_fr.resourceCulture);

		internal static string UsedKeyboard => LanguageText_fr.ResourceManager.GetString("UsedKeyboard", LanguageText_fr.resourceCulture);

		internal static string UsedValueNumber => LanguageText_fr.ResourceManager.GetString("UsedValueNumber", LanguageText_fr.resourceCulture);

		internal static string UseLanguageSettings => LanguageText_fr.ResourceManager.GetString("UseLanguageSettings", LanguageText_fr.resourceCulture);

		internal static string User => LanguageText_fr.ResourceManager.GetString("User", LanguageText_fr.resourceCulture);

		internal static string UserRights => LanguageText_fr.ResourceManager.GetString("UserRights", LanguageText_fr.resourceCulture);

		internal static string USTime => LanguageText_fr.ResourceManager.GetString("USTime", LanguageText_fr.resourceCulture);

		internal static string Valid => LanguageText_fr.ResourceManager.GetString("Valid", LanguageText_fr.resourceCulture);

		internal static string Value => LanguageText_fr.ResourceManager.GetString("Value", LanguageText_fr.resourceCulture);

		internal static string ValueRange => LanguageText_fr.ResourceManager.GetString("ValueRange", LanguageText_fr.resourceCulture);

		internal static string ValuesNotApplied => LanguageText_fr.ResourceManager.GetString("ValuesNotApplied", LanguageText_fr.resourceCulture);

		internal static string VersionController => LanguageText_fr.ResourceManager.GetString("VersionController", LanguageText_fr.resourceCulture);

		internal static string VersionInfo => LanguageText_fr.ResourceManager.GetString("VersionInfo", LanguageText_fr.resourceCulture);

		internal static string VersionVisu => LanguageText_fr.ResourceManager.GetString("VersionVisu", LanguageText_fr.resourceCulture);

		internal static string Visualisation => LanguageText_fr.ResourceManager.GetString("Visualisation", LanguageText_fr.resourceCulture);

		internal static string VisuParam => LanguageText_fr.ResourceManager.GetString("VisuParam", LanguageText_fr.resourceCulture);

		internal static string Voltage => LanguageText_fr.ResourceManager.GetString("Voltage", LanguageText_fr.resourceCulture);

		internal static string WaitForAck => LanguageText_fr.ResourceManager.GetString("WaitForAck", LanguageText_fr.resourceCulture);

		internal static string Warning => LanguageText_fr.ResourceManager.GetString("Warning", LanguageText_fr.resourceCulture);

		internal static string WarningMode => LanguageText_fr.ResourceManager.GetString("WarningMode", LanguageText_fr.resourceCulture);

		internal static string WarningNumber => LanguageText_fr.ResourceManager.GetString("WarningNumber", LanguageText_fr.resourceCulture);

		internal static string WasReset => LanguageText_fr.ResourceManager.GetString("WasReset", LanguageText_fr.resourceCulture);

		internal static string WasSet => LanguageText_fr.ResourceManager.GetString("WasSet", LanguageText_fr.resourceCulture);

		internal static string WeberCurveFormat => LanguageText_fr.ResourceManager.GetString("WeberCurveFormat", LanguageText_fr.resourceCulture);

		internal static string WN => LanguageText_fr.ResourceManager.GetString("WN", LanguageText_fr.resourceCulture);

		internal static string WriteLastNIOTable => LanguageText_fr.ResourceManager.GetString("WriteLastNIOTable", LanguageText_fr.resourceCulture);

		internal static string WriteLastResultsTable => LanguageText_fr.ResourceManager.GetString("WriteLastResultsTable", LanguageText_fr.resourceCulture);

		internal static string WriteLogbookData => LanguageText_fr.ResourceManager.GetString("WriteLogbookData", LanguageText_fr.resourceCulture);

		internal static string WriteLogBookTable => LanguageText_fr.ResourceManager.GetString("WriteLogBookTable", LanguageText_fr.resourceCulture);

		internal static string WriteStepResults => LanguageText_fr.ResourceManager.GetString("WriteStepResults", LanguageText_fr.resourceCulture);

		internal static string Xmax => LanguageText_fr.ResourceManager.GetString("Xmax", LanguageText_fr.resourceCulture);

		internal static string Xmin => LanguageText_fr.ResourceManager.GetString("Xmin", LanguageText_fr.resourceCulture);

		internal static string XmlExport => LanguageText_fr.ResourceManager.GetString("XmlExport", LanguageText_fr.resourceCulture);

		internal static string Yes => LanguageText_fr.ResourceManager.GetString("Yes", LanguageText_fr.resourceCulture);

		internal static string ZoomIn => LanguageText_fr.ResourceManager.GetString("ZoomIn", LanguageText_fr.resourceCulture);

		internal static string ZoomOut => LanguageText_fr.ResourceManager.GetString("ZoomOut", LanguageText_fr.resourceCulture);

		internal LanguageText_fr()
		{
		}
	}
}
