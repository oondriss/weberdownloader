using System;

namespace Visualisation
{
	[Serializable]
	public struct S_ResultData
	{
		public uint curvelength;

		public DateTime dt;

		public short ionio;

		public uint cycle;

		public uint prog;

		public string screwID;

		public float torqueScale;

		public string torqueUnit;
	}
}
