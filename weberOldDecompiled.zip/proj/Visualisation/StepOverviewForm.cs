using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Resources;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class StepOverviewForm : Form
	{
		private MainForm Main;

		private StepKindChoiceForm StepKindChoice1;

		private WSP1_VarComm.ProgStruct PD;

		private WSP1_VarComm.ProgStruct PD_save;

		private int PNum;

		private int SNum;

		private Control ActualControl;

		private int TBSelectionStart;

		private string NewText;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Button btDeleteStep;

		private Button btInsertStep;

		private Button btEditStep;

		private Panel pnProgName;

		private TextBox tBProgramName;

		private Panel pnSteps;

		private Button btStep1;

		private Button btStep2;

		private IContainer components;

		private ComboBox cBResult1;

		private ComboBox cBResult3;

		private ComboBox cBResult2;

		private Button btStep3;

		private Button btStep4;

		private Button btStep5;

		private Button btStep6;

		private Button btStep7;

		private Button btStep8;

		private Button btStep9;

		private Button btStep10;

		private Button btStep11;

		private Button btStep12;

		private Button btStep13;

		private Button btStep14;

		private Button btStep15;

		private Button btStep16;

		private Button btStep17;

		private Button btStep18;

		private Button btStep19;

		private Button btStep20;

		private Button btStep21;

		private Button btStep22;

		private Button btStep23;

		private Button btStep24;

		private Button btStep25;

		private GroupBox gBResult3;

		private GroupBox gBResult2;

		private GroupBox gBResult1;

		private NumberEdit1 nEMaxTime;

		private Label lbMaxTime;

		private Label lbUnitMaxTime;

		private Button btCancel;

		private Button bt2;

		private Panel pnProgSettings;

		private Button btOptPrgParam;

		private NumericUpDown nUDPrognum;

		private Button btStepFinish;

		private Label lbProgramName;

		private Label lbProgNumber;

		private GroupBox gBJawOpenAutomatic;

		private CheckBox chBProgramSpecific;

		private Label lbUnitJawOpenDistance;

		private NumberEdit1 nEJawOpenDistance;

		private Label lbJawOpenDistance;

		private bool bCanceled;

		private Label lb_nEJawOpenDistance;

		private Timer timerDisplayMessage;

		private bool initInProgress = true;

		private string messageText = "";

		public bool WasCanceled
		{
			get
			{
				bool result = this.bCanceled;
				this.bCanceled = false;
				return result;
			}
		}

		public StepOverviewForm(MainForm main)
		{
			this.Main = main;
			this.StepKindChoice1 = new StepKindChoiceForm(main);
			this.InitializeComponent();
			this.tBProgramName.MaxLength = 31;
			this.PNum = 1;
			this.SNum = 0;
			this.StepKindChoice1.InsertStepType = 0;
			this.ActualControl = this.btStep1;
			this.ActualControl.BackColor = SystemColors.ControlLightLight;
			this.nEMaxTime.MaxValue = 120f;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(StepOverviewForm));
			this.pnMenu = new Panel();
			this.btCancel = new Button();
			this.btDeleteStep = new Button();
			this.btHelp = new Button();
			this.btInsertStep = new Button();
			this.bt2 = new Button();
			this.btOptPrgParam = new Button();
			this.btEditStep = new Button();
			this.btBack = new Button();
			this.pnProgName = new Panel();
			this.lbProgramName = new Label();
			this.lbProgNumber = new Label();
			this.nUDPrognum = new NumericUpDown();
			this.tBProgramName = new TextBox();
			this.pnSteps = new Panel();
			this.btStep25 = new Button();
			this.btStep24 = new Button();
			this.btStep23 = new Button();
			this.btStep22 = new Button();
			this.btStep21 = new Button();
			this.btStep20 = new Button();
			this.btStep19 = new Button();
			this.btStep18 = new Button();
			this.btStep17 = new Button();
			this.btStep16 = new Button();
			this.btStep15 = new Button();
			this.btStep14 = new Button();
			this.btStep13 = new Button();
			this.btStep12 = new Button();
			this.btStep11 = new Button();
			this.btStep10 = new Button();
			this.btStep9 = new Button();
			this.btStep8 = new Button();
			this.btStep7 = new Button();
			this.btStep6 = new Button();
			this.btStep5 = new Button();
			this.btStep4 = new Button();
			this.btStep3 = new Button();
			this.btStep2 = new Button();
			this.btStep1 = new Button();
			this.cBResult3 = new ComboBox();
			this.cBResult2 = new ComboBox();
			this.cBResult1 = new ComboBox();
			this.btStepFinish = new Button();
			this.gBResult3 = new GroupBox();
			this.gBResult2 = new GroupBox();
			this.gBResult1 = new GroupBox();
			this.nEMaxTime = new NumberEdit1();
			this.lbMaxTime = new Label();
			this.lbUnitMaxTime = new Label();
			this.pnProgSettings = new Panel();
			this.gBJawOpenAutomatic = new GroupBox();
			this.lb_nEJawOpenDistance = new Label();
			this.chBProgramSpecific = new CheckBox();
			this.lbUnitJawOpenDistance = new Label();
			this.nEJawOpenDistance = new NumberEdit1();
			this.lbJawOpenDistance = new Label();
			this.timerDisplayMessage = new Timer(this.components);
			this.pnMenu.SuspendLayout();
			this.pnProgName.SuspendLayout();
			((ISupportInitialize)this.nUDPrognum).BeginInit();
			this.pnSteps.SuspendLayout();
			this.gBResult3.SuspendLayout();
			this.gBResult2.SuspendLayout();
			this.gBResult1.SuspendLayout();
			this.pnProgSettings.SuspendLayout();
			this.gBJawOpenAutomatic.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.btDeleteStep);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btInsertStep);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.btOptPrgParam);
			this.pnMenu.Controls.Add(this.btEditStep);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btCancel.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 7;
			this.btCancel.Text = "Abbruch";
			this.btCancel.Click += this.btCancel_Click;
			this.btDeleteStep.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDeleteStep.Location = new Point(3, 259);
			this.btDeleteStep.Name = "btDeleteStep";
			this.btDeleteStep.Size = new Size(74, 62);
			this.btDeleteStep.TabIndex = 4;
			this.btDeleteStep.Text = "Stufe löschen";
			this.btDeleteStep.Click += this.btDeleteStep_Click;
			this.btDeleteStep.Enter += this.Start_Input;
			this.btHelp.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btHelp.Enter += this.Start_Input;
			this.btInsertStep.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btInsertStep.Location = new Point(3, 195);
			this.btInsertStep.Name = "btInsertStep";
			this.btInsertStep.Size = new Size(74, 62);
			this.btInsertStep.TabIndex = 3;
			this.btInsertStep.Text = "Stufe einfügen";
			this.btInsertStep.Click += this.btInsertStep_Click;
			this.btInsertStep.Enter += this.Start_Input;
			this.bt2.Enabled = false;
			this.bt2.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt2.Location = new Point(3, 387);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 6;
			this.btOptPrgParam.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btOptPrgParam.Location = new Point(3, 323);
			this.btOptPrgParam.Name = "btOptPrgParam";
			this.btOptPrgParam.Size = new Size(74, 62);
			this.btOptPrgParam.TabIndex = 5;
			this.btOptPrgParam.Text = "Optioanle Programmparameter";
			this.btOptPrgParam.Click += this.btOptPrgParam_Click;
			this.btEditStep.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btEditStep.Location = new Point(3, 131);
			this.btEditStep.Name = "btEditStep";
			this.btEditStep.Size = new Size(74, 62);
			this.btEditStep.TabIndex = 2;
			this.btEditStep.Text = "Stufe bearbeiten";
			this.btEditStep.Click += this.btEditStep_Click;
			this.btEditStep.Enter += this.Start_Input;
			this.btBack.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Fertig";
			this.btBack.Click += this.btBack_Click;
			this.btBack.Enter += this.Start_Input;
			this.pnProgName.Controls.Add(this.lbProgramName);
			this.pnProgName.Controls.Add(this.lbProgNumber);
			this.pnProgName.Controls.Add(this.nUDPrognum);
			this.pnProgName.Controls.Add(this.tBProgramName);
			this.pnProgName.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnProgName.Location = new Point(0, 0);
			this.pnProgName.Name = "pnProgName";
			this.pnProgName.Size = new Size(538, 39);
			this.pnProgName.TabIndex = 1;
			this.lbProgramName.BackColor = SystemColors.Control;
			this.lbProgramName.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgramName.Location = new Point(219, 8);
			this.lbProgramName.Name = "lbProgramName";
			this.lbProgramName.Size = new Size(80, 23);
			this.lbProgramName.TabIndex = 78;
			this.lbProgramName.Text = "Name";
			this.lbProgramName.TextAlign = ContentAlignment.MiddleCenter;
			this.lbProgNumber.BackColor = SystemColors.Control;
			this.lbProgNumber.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgNumber.Location = new Point(7, 8);
			this.lbProgNumber.Name = "lbProgNumber";
			this.lbProgNumber.Size = new Size(93, 23);
			this.lbProgNumber.TabIndex = 77;
			this.lbProgNumber.Text = "Number";
			this.lbProgNumber.TextAlign = ContentAlignment.MiddleCenter;
			this.nUDPrognum.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nUDPrognum.Location = new Point(106, 8);
			this.nUDPrognum.Maximum = new decimal(new int[4]
			{
				-1,
				0,
				0,
				0
			});
			this.nUDPrognum.Name = "nUDPrognum";
			this.nUDPrognum.Size = new Size(105, 25);
			this.nUDPrognum.TabIndex = 8;
			this.nUDPrognum.Value = new decimal(new int[4]
			{
				1234567890,
				0,
				0,
				0
			});
			this.nUDPrognum.ValueChanged += this.settingsChanged;
			this.nUDPrognum.Enter += this.Start_Input;
			this.nUDPrognum.MouseDown += this.StartInput;
			this.tBProgramName.BackColor = Color.White;
			this.tBProgramName.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.tBProgramName.Location = new Point(305, 7);
			this.tBProgramName.MaxLength = 1;
			this.tBProgramName.Name = "tBProgramName";
			this.tBProgramName.ReadOnly = true;
			this.tBProgramName.Size = new Size(230, 25);
			this.tBProgramName.TabIndex = 0;
			this.tBProgramName.Text = "WWWWWWWWWWWWWWWW";
			this.tBProgramName.TextChanged += this.tBProgramName_TextChanged;
			this.tBProgramName.Enter += this.Start_Input;
			this.tBProgramName.KeyUp += this.tBProgramName_KeyUp;
			this.tBProgramName.MouseDown += this.StartInput;
			this.pnSteps.Controls.Add(this.btStep25);
			this.pnSteps.Controls.Add(this.btStep24);
			this.pnSteps.Controls.Add(this.btStep23);
			this.pnSteps.Controls.Add(this.btStep22);
			this.pnSteps.Controls.Add(this.btStep21);
			this.pnSteps.Controls.Add(this.btStep20);
			this.pnSteps.Controls.Add(this.btStep19);
			this.pnSteps.Controls.Add(this.btStep18);
			this.pnSteps.Controls.Add(this.btStep17);
			this.pnSteps.Controls.Add(this.btStep16);
			this.pnSteps.Controls.Add(this.btStep15);
			this.pnSteps.Controls.Add(this.btStep14);
			this.pnSteps.Controls.Add(this.btStep13);
			this.pnSteps.Controls.Add(this.btStep12);
			this.pnSteps.Controls.Add(this.btStep11);
			this.pnSteps.Controls.Add(this.btStep10);
			this.pnSteps.Controls.Add(this.btStep9);
			this.pnSteps.Controls.Add(this.btStep8);
			this.pnSteps.Controls.Add(this.btStep7);
			this.pnSteps.Controls.Add(this.btStep6);
			this.pnSteps.Controls.Add(this.btStep5);
			this.pnSteps.Controls.Add(this.btStep4);
			this.pnSteps.Controls.Add(this.btStep3);
			this.pnSteps.Controls.Add(this.btStep2);
			this.pnSteps.Controls.Add(this.btStep1);
			this.pnSteps.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnSteps.Location = new Point(0, 39);
			this.pnSteps.Name = "pnSteps";
			this.pnSteps.Size = new Size(538, 402);
			this.pnSteps.TabIndex = 2;
			this.btStep25.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btStep25.Image = (Image)componentResourceManager.GetObject("btStep25.Image");
			this.btStep25.Location = new Point(431, 323);
			this.btStep25.Name = "btStep25";
			this.btStep25.Size = new Size(105, 78);
			this.btStep25.TabIndex = 24;
			this.btStep25.Tag = "25";
			this.btStep25.Text = "Stufe25";
			this.btStep25.Visible = false;
			this.btStep25.Enter += this.Start_Input;
			this.btStep25.MouseDown += this.btStepXX_MouseDown;
			this.btStep24.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btStep24.Image = (Image)componentResourceManager.GetObject("btStep24.Image");
			this.btStep24.Location = new Point(324, 323);
			this.btStep24.Name = "btStep24";
			this.btStep24.Size = new Size(105, 78);
			this.btStep24.TabIndex = 23;
			this.btStep24.Tag = "24";
			this.btStep24.Text = "Stufe24";
			this.btStep24.Visible = false;
			this.btStep24.Enter += this.Start_Input;
			this.btStep24.MouseDown += this.btStepXX_MouseDown;
			this.btStep23.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btStep23.Image = (Image)componentResourceManager.GetObject("btStep23.Image");
			this.btStep23.Location = new Point(217, 323);
			this.btStep23.Name = "btStep23";
			this.btStep23.Size = new Size(105, 78);
			this.btStep23.TabIndex = 22;
			this.btStep23.Tag = "23";
			this.btStep23.Text = "Stufe23";
			this.btStep23.Visible = false;
			this.btStep23.Enter += this.Start_Input;
			this.btStep23.MouseDown += this.btStepXX_MouseDown;
			this.btStep22.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btStep22.Image = (Image)componentResourceManager.GetObject("btStep22.Image");
			this.btStep22.Location = new Point(110, 323);
			this.btStep22.Name = "btStep22";
			this.btStep22.Size = new Size(105, 78);
			this.btStep22.TabIndex = 21;
			this.btStep22.Tag = "22";
			this.btStep22.Text = "Stufe22";
			this.btStep22.Visible = false;
			this.btStep22.Enter += this.Start_Input;
			this.btStep22.MouseDown += this.btStepXX_MouseDown;
			this.btStep21.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btStep21.Image = (Image)componentResourceManager.GetObject("btStep21.Image");
			this.btStep21.Location = new Point(3, 323);
			this.btStep21.Name = "btStep21";
			this.btStep21.Size = new Size(105, 78);
			this.btStep21.TabIndex = 20;
			this.btStep21.Tag = "21";
			this.btStep21.Text = "Stufe21";
			this.btStep21.Visible = false;
			this.btStep21.Enter += this.Start_Input;
			this.btStep21.MouseDown += this.btStepXX_MouseDown;
			this.btStep20.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btStep20.Image = (Image)componentResourceManager.GetObject("btStep20.Image");
			this.btStep20.Location = new Point(431, 243);
			this.btStep20.Name = "btStep20";
			this.btStep20.Size = new Size(105, 78);
			this.btStep20.TabIndex = 19;
			this.btStep20.Tag = "20";
			this.btStep20.Text = "Stufe20";
			this.btStep20.Visible = false;
			this.btStep20.Enter += this.Start_Input;
			this.btStep20.MouseDown += this.btStepXX_MouseDown;
			this.btStep19.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btStep19.Image = (Image)componentResourceManager.GetObject("btStep19.Image");
			this.btStep19.Location = new Point(324, 243);
			this.btStep19.Name = "btStep19";
			this.btStep19.Size = new Size(105, 78);
			this.btStep19.TabIndex = 18;
			this.btStep19.Tag = "19";
			this.btStep19.Text = "Stufe19";
			this.btStep19.Visible = false;
			this.btStep19.Enter += this.Start_Input;
			this.btStep19.MouseDown += this.btStepXX_MouseDown;
			this.btStep18.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep18.Location = new Point(217, 243);
			this.btStep18.Name = "btStep18";
			this.btStep18.Size = new Size(105, 78);
			this.btStep18.TabIndex = 17;
			this.btStep18.Tag = "18";
			this.btStep18.Text = "Stufe18";
			this.btStep18.Visible = false;
			this.btStep18.Enter += this.Start_Input;
			this.btStep18.MouseDown += this.btStepXX_MouseDown;
			this.btStep17.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep17.Location = new Point(110, 243);
			this.btStep17.Name = "btStep17";
			this.btStep17.Size = new Size(105, 78);
			this.btStep17.TabIndex = 16;
			this.btStep17.Tag = "17";
			this.btStep17.Text = "Stufe17";
			this.btStep17.Visible = false;
			this.btStep17.Enter += this.Start_Input;
			this.btStep17.MouseDown += this.btStepXX_MouseDown;
			this.btStep16.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep16.Location = new Point(3, 243);
			this.btStep16.Name = "btStep16";
			this.btStep16.Size = new Size(105, 78);
			this.btStep16.TabIndex = 15;
			this.btStep16.Tag = "16";
			this.btStep16.Text = "Stufe16";
			this.btStep16.Visible = false;
			this.btStep16.Enter += this.Start_Input;
			this.btStep16.MouseDown += this.btStepXX_MouseDown;
			this.btStep15.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep15.Location = new Point(431, 163);
			this.btStep15.Name = "btStep15";
			this.btStep15.Size = new Size(105, 78);
			this.btStep15.TabIndex = 14;
			this.btStep15.Tag = "15";
			this.btStep15.Text = "Stufe15";
			this.btStep15.Visible = false;
			this.btStep15.Enter += this.Start_Input;
			this.btStep15.MouseDown += this.btStepXX_MouseDown;
			this.btStep14.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep14.Location = new Point(324, 163);
			this.btStep14.Name = "btStep14";
			this.btStep14.Size = new Size(105, 78);
			this.btStep14.TabIndex = 13;
			this.btStep14.Tag = "14";
			this.btStep14.Text = "Stufe14";
			this.btStep14.Visible = false;
			this.btStep14.Enter += this.Start_Input;
			this.btStep14.MouseDown += this.btStepXX_MouseDown;
			this.btStep13.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep13.Location = new Point(217, 163);
			this.btStep13.Name = "btStep13";
			this.btStep13.Size = new Size(105, 78);
			this.btStep13.TabIndex = 12;
			this.btStep13.Tag = "13";
			this.btStep13.Text = "Stufe13";
			this.btStep13.Visible = false;
			this.btStep13.Enter += this.Start_Input;
			this.btStep13.MouseDown += this.btStepXX_MouseDown;
			this.btStep12.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep12.Location = new Point(110, 163);
			this.btStep12.Name = "btStep12";
			this.btStep12.Size = new Size(105, 78);
			this.btStep12.TabIndex = 11;
			this.btStep12.Tag = "12";
			this.btStep12.Text = "Stufe12";
			this.btStep12.Visible = false;
			this.btStep12.Enter += this.Start_Input;
			this.btStep12.MouseDown += this.btStepXX_MouseDown;
			this.btStep11.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep11.Location = new Point(3, 163);
			this.btStep11.Name = "btStep11";
			this.btStep11.Size = new Size(105, 78);
			this.btStep11.TabIndex = 10;
			this.btStep11.Tag = "11";
			this.btStep11.Text = "Stufe11";
			this.btStep11.Visible = false;
			this.btStep11.Enter += this.Start_Input;
			this.btStep11.MouseDown += this.btStepXX_MouseDown;
			this.btStep10.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep10.Location = new Point(431, 83);
			this.btStep10.Name = "btStep10";
			this.btStep10.Size = new Size(105, 78);
			this.btStep10.TabIndex = 9;
			this.btStep10.Tag = "10";
			this.btStep10.Text = "Stufe10";
			this.btStep10.Visible = false;
			this.btStep10.Enter += this.Start_Input;
			this.btStep10.MouseDown += this.btStepXX_MouseDown;
			this.btStep9.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep9.Location = new Point(324, 83);
			this.btStep9.Name = "btStep9";
			this.btStep9.Size = new Size(105, 78);
			this.btStep9.TabIndex = 8;
			this.btStep9.Tag = "9";
			this.btStep9.Text = "Stufe9";
			this.btStep9.Visible = false;
			this.btStep9.Enter += this.Start_Input;
			this.btStep9.MouseDown += this.btStepXX_MouseDown;
			this.btStep8.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep8.Location = new Point(217, 83);
			this.btStep8.Name = "btStep8";
			this.btStep8.Size = new Size(105, 78);
			this.btStep8.TabIndex = 7;
			this.btStep8.Tag = "8";
			this.btStep8.Text = "Stufe8";
			this.btStep8.Visible = false;
			this.btStep8.Enter += this.Start_Input;
			this.btStep8.MouseDown += this.btStepXX_MouseDown;
			this.btStep7.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep7.Location = new Point(110, 83);
			this.btStep7.Name = "btStep7";
			this.btStep7.Size = new Size(105, 78);
			this.btStep7.TabIndex = 6;
			this.btStep7.Tag = "7";
			this.btStep7.Text = "Stufe7";
			this.btStep7.Visible = false;
			this.btStep7.Enter += this.Start_Input;
			this.btStep7.MouseDown += this.btStepXX_MouseDown;
			this.btStep6.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep6.Location = new Point(3, 83);
			this.btStep6.Name = "btStep6";
			this.btStep6.Size = new Size(105, 78);
			this.btStep6.TabIndex = 5;
			this.btStep6.Tag = "6";
			this.btStep6.Text = "Stufe6";
			this.btStep6.Visible = false;
			this.btStep6.Enter += this.Start_Input;
			this.btStep6.MouseDown += this.btStepXX_MouseDown;
			this.btStep5.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep5.Location = new Point(431, 3);
			this.btStep5.Name = "btStep5";
			this.btStep5.Size = new Size(105, 78);
			this.btStep5.TabIndex = 4;
			this.btStep5.Tag = "5";
			this.btStep5.Text = "Stufe5";
			this.btStep5.Visible = false;
			this.btStep5.Enter += this.Start_Input;
			this.btStep5.MouseDown += this.btStepXX_MouseDown;
			this.btStep4.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep4.Location = new Point(324, 3);
			this.btStep4.Name = "btStep4";
			this.btStep4.Size = new Size(105, 78);
			this.btStep4.TabIndex = 3;
			this.btStep4.Tag = "4";
			this.btStep4.Text = "Stufe4";
			this.btStep4.Visible = false;
			this.btStep4.Enter += this.Start_Input;
			this.btStep4.MouseDown += this.btStepXX_MouseDown;
			this.btStep3.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep3.Location = new Point(217, 3);
			this.btStep3.Name = "btStep3";
			this.btStep3.Size = new Size(105, 78);
			this.btStep3.TabIndex = 2;
			this.btStep3.Tag = "3";
			this.btStep3.Text = "Stufe3";
			this.btStep3.Visible = false;
			this.btStep3.Enter += this.Start_Input;
			this.btStep3.MouseDown += this.btStepXX_MouseDown;
			this.btStep2.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep2.Location = new Point(110, 3);
			this.btStep2.Name = "btStep2";
			this.btStep2.Size = new Size(105, 78);
			this.btStep2.TabIndex = 1;
			this.btStep2.Tag = "2";
			this.btStep2.Text = "Stufe2";
			this.btStep2.Visible = false;
			this.btStep2.Enter += this.Start_Input;
			this.btStep2.MouseDown += this.btStepXX_MouseDown;
			this.btStep1.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStep1.Location = new Point(3, 3);
			this.btStep1.Name = "btStep1";
			this.btStep1.Size = new Size(105, 78);
			this.btStep1.TabIndex = 0;
			this.btStep1.Tag = "1";
			this.btStep1.Text = "Stufe1";
			this.btStep1.Visible = false;
			this.btStep1.Enter += this.Start_Input;
			this.btStep1.MouseDown += this.btStepXX_MouseDown;
			this.cBResult3.BackColor = SystemColors.Window;
			this.cBResult3.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBResult3.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBResult3.Items.AddRange(new object[9]
			{
				"Moment",
				"MaxMoment",
				"gefilt. M",
				"Gradient",
				"Winkel",
				"Zeit",
				"anal. Tiefe",
				"Analogsignal",
				"dig. Tiefe"
			});
			this.cBResult3.Location = new Point(8, 24);
			this.cBResult3.MaxDropDownItems = 12;
			this.cBResult3.Name = "cBResult3";
			this.cBResult3.Size = new Size(146, 28);
			this.cBResult3.TabIndex = 1;
			this.cBResult3.SelectedIndexChanged += this.settingsChanged;
			this.cBResult2.BackColor = SystemColors.Window;
			this.cBResult2.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBResult2.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBResult2.Items.AddRange(new object[9]
			{
				"Moment",
				"MaxMoment",
				"gefilt. M",
				"Gradient",
				"Winkel",
				"Zeit",
				"anal. Tiefe",
				"Analogsignal",
				"dig. Tiefe"
			});
			this.cBResult2.Location = new Point(8, 24);
			this.cBResult2.MaxDropDownItems = 12;
			this.cBResult2.Name = "cBResult2";
			this.cBResult2.Size = new Size(146, 28);
			this.cBResult2.TabIndex = 1;
			this.cBResult2.SelectedIndexChanged += this.settingsChanged;
			this.cBResult1.BackColor = SystemColors.Window;
			this.cBResult1.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBResult1.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.cBResult1.Items.AddRange(new object[9]
			{
				"Moment",
				"MaxMoment",
				"gefilt. M",
				"Gradient",
				"Winkel",
				"Zeit",
				"anal. Tiefe",
				"Analogsignal",
				"dig. Tiefe"
			});
			this.cBResult1.Location = new Point(8, 24);
			this.cBResult1.MaxDropDownItems = 12;
			this.cBResult1.Name = "cBResult1";
			this.cBResult1.Size = new Size(146, 28);
			this.cBResult1.TabIndex = 1;
			this.cBResult1.SelectedIndexChanged += this.settingsChanged;
			this.btStepFinish.BackColor = SystemColors.ControlDark;
			this.btStepFinish.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btStepFinish.Location = new Point(540, 362);
			this.btStepFinish.Name = "btStepFinish";
			this.btStepFinish.Size = new Size(105, 78);
			this.btStepFinish.TabIndex = 3;
			this.btStepFinish.Tag = "26";
			this.btStepFinish.Text = "Programmende";
			this.btStepFinish.UseVisualStyleBackColor = false;
			this.btStepFinish.Visible = false;
			this.btStepFinish.Click += this.btStepFinish_Click;
			this.btStepFinish.Enter += this.Start_Input;
			this.gBResult3.Controls.Add(this.cBResult3);
			this.gBResult3.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBResult3.Location = new Point(544, 144);
			this.gBResult3.Name = "gBResult3";
			this.gBResult3.Size = new Size(160, 66);
			this.gBResult3.TabIndex = 6;
			this.gBResult3.TabStop = false;
			this.gBResult3.Text = "Ergebnis 3";
			this.gBResult2.Controls.Add(this.cBResult2);
			this.gBResult2.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBResult2.Location = new Point(544, 71);
			this.gBResult2.Name = "gBResult2";
			this.gBResult2.Size = new Size(160, 67);
			this.gBResult2.TabIndex = 5;
			this.gBResult2.TabStop = false;
			this.gBResult2.Text = "Ergebnis 2";
			this.gBResult1.Controls.Add(this.cBResult1);
			this.gBResult1.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBResult1.Location = new Point(544, 0);
			this.gBResult1.Name = "gBResult1";
			this.gBResult1.Size = new Size(160, 65);
			this.gBResult1.TabIndex = 4;
			this.gBResult1.TabStop = false;
			this.gBResult1.Text = "Ergebnis 1";
			this.nEMaxTime.BackColor = Color.White;
			this.nEMaxTime.DecimalNum = 1;
			this.nEMaxTime.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEMaxTime.ForeColor = Color.Red;
			this.nEMaxTime.Location = new Point(201, 15);
			this.nEMaxTime.MaxValue = 120f;
			this.nEMaxTime.MinValue = 0.1f;
			this.nEMaxTime.Name = "nEMaxTime";
			this.nEMaxTime.Size = new Size(64, 28);
			this.nEMaxTime.TabIndex = 3;
			this.nEMaxTime.Text = "0,0";
			this.nEMaxTime.TextAlign = HorizontalAlignment.Right;
			this.nEMaxTime.Value = 0f;
			this.nEMaxTime.TextChanged += this.settingsChanged;
			this.nEMaxTime.Enter += this.Start_Input;
			this.nEMaxTime.MouseDown += this.StartInput;
			this.lbMaxTime.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMaxTime.Location = new Point(3, 17);
			this.lbMaxTime.Name = "lbMaxTime";
			this.lbMaxTime.Size = new Size(192, 23);
			this.lbMaxTime.TabIndex = 76;
			this.lbMaxTime.Text = "Max. Schraubzeit";
			this.lbMaxTime.TextAlign = ContentAlignment.MiddleCenter;
			this.lbUnitMaxTime.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitMaxTime.Location = new Point(273, 15);
			this.lbUnitMaxTime.Name = "lbUnitMaxTime";
			this.lbUnitMaxTime.Size = new Size(42, 23);
			this.lbUnitMaxTime.TabIndex = 77;
			this.lbUnitMaxTime.Text = "s";
			this.lbUnitMaxTime.TextAlign = ContentAlignment.MiddleLeft;
			this.pnProgSettings.Controls.Add(this.nEMaxTime);
			this.pnProgSettings.Controls.Add(this.lbMaxTime);
			this.pnProgSettings.Controls.Add(this.lbUnitMaxTime);
			this.pnProgSettings.Location = new Point(385, 447);
			this.pnProgSettings.Name = "pnProgSettings";
			this.pnProgSettings.Size = new Size(321, 60);
			this.pnProgSettings.TabIndex = 7;
			this.gBJawOpenAutomatic.Controls.Add(this.lb_nEJawOpenDistance);
			this.gBJawOpenAutomatic.Controls.Add(this.chBProgramSpecific);
			this.gBJawOpenAutomatic.Controls.Add(this.lbUnitJawOpenDistance);
			this.gBJawOpenAutomatic.Controls.Add(this.nEJawOpenDistance);
			this.gBJawOpenAutomatic.Controls.Add(this.lbJawOpenDistance);
			this.gBJawOpenAutomatic.Location = new Point(3, 446);
			this.gBJawOpenAutomatic.Name = "gBJawOpenAutomatic";
			this.gBJawOpenAutomatic.Size = new Size(332, 72);
			this.gBJawOpenAutomatic.TabIndex = 8;
			this.gBJawOpenAutomatic.TabStop = false;
			this.gBJawOpenAutomatic.Text = " ";
			this.lb_nEJawOpenDistance.AutoSize = true;
			this.lb_nEJawOpenDistance.Font = new Font("Arial Unicode MS", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lb_nEJawOpenDistance.Location = new Point(211, 37);
			this.lb_nEJawOpenDistance.Name = "lb_nEJawOpenDistance";
			this.lb_nEJawOpenDistance.Size = new Size(42, 16);
			this.lb_nEJawOpenDistance.TabIndex = 73;
			this.lb_nEJawOpenDistance.Text = "label1";
			this.chBProgramSpecific.AutoSize = true;
			this.chBProgramSpecific.Location = new Point(16, 14);
			this.chBProgramSpecific.Name = "chBProgramSpecific";
			this.chBProgramSpecific.Size = new Size(122, 17);
			this.chBProgramSpecific.TabIndex = 72;
			this.chBProgramSpecific.Text = "Programm spezifisch";
			this.chBProgramSpecific.UseVisualStyleBackColor = true;
			this.chBProgramSpecific.CheckedChanged += this.chBProgramSpecific_CheckedChanged;
			this.lbUnitJawOpenDistance.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitJawOpenDistance.Location = new Point(269, 34);
			this.lbUnitJawOpenDistance.Name = "lbUnitJawOpenDistance";
			this.lbUnitJawOpenDistance.Size = new Size(56, 22);
			this.lbUnitJawOpenDistance.TabIndex = 69;
			this.lbUnitJawOpenDistance.Text = "mm";
			this.lbUnitJawOpenDistance.TextAlign = ContentAlignment.MiddleLeft;
			this.nEJawOpenDistance.BackColor = Color.White;
			this.nEJawOpenDistance.DecimalNum = 2;
			this.nEJawOpenDistance.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEJawOpenDistance.ForeColor = SystemColors.ControlText;
			this.nEJawOpenDistance.Location = new Point(164, 32);
			this.nEJawOpenDistance.MaxValue = 100f;
			this.nEJawOpenDistance.MinValue = 0f;
			this.nEJawOpenDistance.Name = "nEJawOpenDistance";
			this.nEJawOpenDistance.Size = new Size(72, 24);
			this.nEJawOpenDistance.TabIndex = 63;
			this.nEJawOpenDistance.Text = "2,00";
			this.nEJawOpenDistance.TextAlign = HorizontalAlignment.Right;
			this.nEJawOpenDistance.Value = 2f;
			this.nEJawOpenDistance.Visible = false;
			this.nEJawOpenDistance.TextChanged += this.settingsChanged;
			this.nEJawOpenDistance.Enter += this.Start_Input;
			this.nEJawOpenDistance.MouseDown += this.StartInput;
			this.lbJawOpenDistance.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbJawOpenDistance.Location = new Point(13, 34);
			this.lbJawOpenDistance.Name = "lbJawOpenDistance";
			this.lbJawOpenDistance.Size = new Size(168, 22);
			this.lbJawOpenDistance.TabIndex = 68;
			this.lbJawOpenDistance.Text = "Umschaltpunkt";
			this.lbJawOpenDistance.TextAlign = ContentAlignment.MiddleLeft;
			this.timerDisplayMessage.Tick += this.timerDisplayMessage_Tick;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.gBJawOpenAutomatic);
			base.Controls.Add(this.pnProgSettings);
			base.Controls.Add(this.gBResult1);
			base.Controls.Add(this.gBResult3);
			base.Controls.Add(this.btStepFinish);
			base.Controls.Add(this.pnSteps);
			base.Controls.Add(this.pnProgName);
			base.Controls.Add(this.pnMenu);
			base.Controls.Add(this.gBResult2);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "StepOverviewForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen/Programme/Stufen";
			base.Activated += this.StepOverviewForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.pnProgName.ResumeLayout(false);
			this.pnProgName.PerformLayout();
			((ISupportInitialize)this.nUDPrognum).EndInit();
			this.pnSteps.ResumeLayout(false);
			this.gBResult3.ResumeLayout(false);
			this.gBResult2.ResumeLayout(false);
			this.gBResult1.ResumeLayout(false);
			this.pnProgSettings.ResumeLayout(false);
			this.pnProgSettings.PerformLayout();
			this.gBJawOpenAutomatic.ResumeLayout(false);
			this.gBJawOpenAutomatic.PerformLayout();
			base.ResumeLayout(false);
		}

		public bool ShowWindow(int number)
		{
			if (number >= 1 && number < 1024)
			{
				this.Main.ResetBrowserGrantedBy();
				this.PNum = number;
				this.PD = this.Main.ProcessProgram.TempProgStruct.Num[this.PNum];
				this.PD_save = new WSP1_VarComm.ProgStruct();
				this.MenEna();
				this.SNum = 0;
				this.ActualControl = this.btStep1;
				this.InitializeValues();
				this.StepButtonShow();
				this.pnProgName.Select();
				base.Show();
				return true;
			}
			return false;
		}

		public void SetLanguageTexts()
		{
			string[] items = new string[12]
			{
				this.Main.Rm.GetString("Torque") + string.Empty,
				this.Main.Rm.GetString("MaxTorque") + string.Empty,
				this.Main.Rm.GetString("FilteredTorque") + string.Empty,
				this.Main.Rm.GetString("Gradient") + string.Empty,
				this.Main.Rm.GetString("Angle") + string.Empty,
				this.Main.Rm.GetString("Time") + string.Empty,
				this.Main.Rm.GetString("AnaDepth") + string.Empty,
				this.Main.Rm.GetString("DigitalSignal") + string.Empty,
				this.Main.Rm.GetString("DepthGrad") + string.Empty,
				this.Main.Rm.GetString("DelayTorque") + string.Empty,
				this.Main.Rm.GetString("M360Follow") + string.Empty,
				this.Main.Rm.GetString("AnaSignal") + string.Empty
			};
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MProgramOverview") + "/" + this.Main.Rm.GetString("MStepOverview");
			this.lbMaxTime.Text = this.Main.Rm.GetString("MaxScrewTime");
			this.btBack.Text = this.Main.Rm.GetString("Done");
			this.btDeleteStep.Text = this.Main.Rm.GetString("DeleteStep");
			this.btEditStep.Text = this.Main.Rm.GetString("EditStep");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btInsertStep.Text = this.Main.Rm.GetString("InsertStep");
			this.btStepFinish.Text = this.Main.Rm.GetString("StepFinish");
			this.btCancel.Text = this.Main.Rm.GetString("btCancel");
			this.btOptPrgParam.Text = this.Main.Rm.GetString("OptPrgParam");
			this.gBResult1.Text = this.Main.Rm.GetString("Result") + " 1";
			this.gBResult2.Text = this.Main.Rm.GetString("Result") + " 2";
			this.gBResult3.Text = this.Main.Rm.GetString("Result") + " 3";
			this.lbUnitMaxTime.Text = this.Main.Rm.GetString("Second");
			this.lbProgNumber.Text = this.Main.Rm.GetString("ProgramNumber");
			this.lbProgramName.Text = this.Main.Rm.GetString("Name");
			this.StepKindChoice1.SetLanguageTexts();
			this.gBJawOpenAutomatic.Text = this.Main.Rm.GetString("gBJawOpenAutomatic");
			this.chBProgramSpecific.Text = this.Main.Rm.GetString("chbProgramSpecific");
			this.lbUnitJawOpenDistance.Text = this.Main.Rm.GetString("Milimeter");
			this.lbJawOpenDistance.Text = this.Main.Rm.GetString("lbJawOpenDistance2");
			this.cBResult1.Items.Clear();
			this.cBResult2.Items.Clear();
			this.cBResult3.Items.Clear();
			this.cBResult1.Items.AddRange(items);
			this.cBResult2.Items.AddRange(items);
			this.cBResult3.Items.AddRange(items);
			this.cBResult1.SelectedIndex = 0;
			this.cBResult2.SelectedIndex = 0;
			this.cBResult3.SelectedIndex = 0;
		}

		private void MenEna()
		{
			bool enabled = false;
			bool enabled2 = false;
			bool enabled3 = false;
			if (this.Main.PassCodeLevel >= 3)
			{
				enabled3 = true;
			}
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_StepOverviewForm)
			{
				enabled2 = true;
			}
			if (this.Main.PassCodeLevel >= 1)
			{
				enabled = true;
			}
			if (this.Main.ViewOnlyMode)
			{
				enabled = false;
				enabled2 = false;
				enabled3 = false;
			}
			if (this.Main.IsOfflineVersion)
			{
				enabled = true;
				enabled2 = true;
				enabled3 = true;
			}
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_StepOverviewForm, this.Main.ViewOnlyMode);
			this.tBProgramName.Enabled = enabled2;
			this.cBResult1.Enabled = enabled2;
			this.cBResult2.Enabled = enabled2;
			this.cBResult3.Enabled = enabled2;
			this.btInsertStep.Enabled = enabled2;
			this.btDeleteStep.Enabled = enabled2;
			this.chBProgramSpecific.Enabled = enabled2;
			this.nEJawOpenDistance.Enabled = enabled2;
			this.nEMaxTime.Enabled = enabled;
			this.btBack.Enabled = enabled;
			this.gBJawOpenAutomatic.Enabled = enabled3;
			this.tBProgramName.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEJawOpenDistance.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEMaxTime.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nUDPrognum.Controls[0].Enabled = !Settings.Default.SoftKeyBoardIsUsed;
			this.nUDPrognum.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nUDPrognum.BackColor = Color.White;
			this.enableInsertDeleteButtons();
		}

		private void InitializeValues()
		{
			this.initInProgress = true;
			if (this.PD.Info.ProgNum == 0)
			{
				this.PD.Info.ProgNum = (uint)this.PNum;
			}
			this.cBResult1.SelectedIndex = this.GetResSelectedIndex(this.PD.Info.ResultParam1);
			this.cBResult2.SelectedIndex = this.GetResSelectedIndex(this.PD.Info.ResultParam2);
			this.cBResult3.SelectedIndex = this.GetResSelectedIndex(this.PD.Info.ResultParam3);
			this.nUDPrognum.Value = this.PD.Info.ProgNum;
			this.tBProgramName.Text = this.Main.CommonFunctions.UShortToString(this.PD.Info.Name);
			this.TBSelectionStart = this.tBProgramName.SelectionStart;
			this.NewText = this.tBProgramName.Text;
			if (this.PD.MaxTime == 0f)
			{
				this.nEMaxTime.Value = 15f;
			}
			else
			{
				this.nEMaxTime.Value = this.PD.MaxTime;
			}
			if ((this.PD.UseLocalJawSettings & 1) != 0)
			{
				this.chBProgramSpecific.Checked = true;
			}
			else
			{
				this.chBProgramSpecific.Checked = false;
			}
			if (this.PD.JawLocalWrittenOnce != 0)
			{
				this.nEJawOpenDistance.Value = this.PD.JawOpenDistance;
			}
			else
			{
				this.nEJawOpenDistance.Value = this.Main.VC.SpConst.JawOpenDistance;
			}
			this.showJawControls();
			this.Main.CommonFunctions.GetResFactor(this.PD.Info.ResultParam1);
			float torqueConvert = this.Main.TorqueConvert;
			this.Main.CommonFunctions.GetResFactor(this.PD.Info.ResultParam2);
			float torqueConvert2 = this.Main.TorqueConvert;
			this.Main.CommonFunctions.GetResFactor(this.PD.Info.ResultParam3);
			float torqueConvert3 = this.Main.TorqueConvert;
			this.initInProgress = false;
		}

		public void StepButtonShow()
		{
			ResourceManager resourceManager = new ResourceManager(typeof(StepOverviewForm));
			string empty = string.Empty;
			bool flag = false;
			for (int i = 0; i < this.pnSteps.Controls.Count; i++)
			{
				if (this.pnSteps.Controls[i].Tag != null && !(this.pnSteps.Controls[i].Tag.GetType() != Type.GetType("System.String")))
				{
					int num = int.Parse(this.pnSteps.Controls[i].Tag.ToString()) - 1;
					if (num < this.PD.Info.Steps)
					{
						switch (this.PD.Step[num].Type)
						{
						case 2:
							empty = " (" + this.GetSwitchingTypeName(this.PD.Step[num].Switch, num) + ")";
							break;
						case 3:
							empty = this.Main.Rm.GetString("Finalizing") + " (" + this.GetSwitchingTypeName(this.PD.Step[num].Switch, num) + ")";
							break;
						case 1:
							empty = ((this.PD.Step[num].Switch != 1030 || this.PD.Step[num].ModDigOut != 3) ? (this.Main.Rm.GetString("Organisation") + " (" + this.GetSwitchingTypeName(this.PD.Step[num].Switch, num) + ")") : (this.Main.Rm.GetString("Organisation") + " (" + this.Main.Rm.GetString("JawOpen") + ")"));
							break;
						default:
							if (!flag)
							{
								MessageBox.Show("Wrong step type in StepButtonShow() of StepOverview", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							}
							empty = "Error";
							flag = true;
							break;
						}
						this.pnSteps.Controls[i].Visible = true;
						this.pnSteps.Controls[i].Text = this.Main.Rm.GetString("Step") + " " + this.pnSteps.Controls[i].Tag.ToString() + ":\n" + empty;
						this.pnSteps.Controls[i].BackColor = SystemColors.Control;
						switch (this.PD.Step[num].IsResult1 * 100 + this.PD.Step[num].IsResult2 * 10 + this.PD.Step[num].IsResult3)
						{
						case 100:
							((Button)this.pnSteps.Controls[i]).Image = (Image)resourceManager.GetObject("btStep19.Image");
							break;
						case 10:
							((Button)this.pnSteps.Controls[i]).Image = (Image)resourceManager.GetObject("btStep20.Image");
							break;
						case 1:
							((Button)this.pnSteps.Controls[i]).Image = (Image)resourceManager.GetObject("btStep21.Image");
							break;
						case 110:
							((Button)this.pnSteps.Controls[i]).Image = (Image)resourceManager.GetObject("btStep22.Image");
							break;
						case 101:
							((Button)this.pnSteps.Controls[i]).Image = (Image)resourceManager.GetObject("btStep23.Image");
							break;
						case 11:
							((Button)this.pnSteps.Controls[i]).Image = (Image)resourceManager.GetObject("btStep24.Image");
							break;
						case 111:
							((Button)this.pnSteps.Controls[i]).Image = (Image)resourceManager.GetObject("btStep25.Image");
							break;
						default:
							((Button)this.pnSteps.Controls[i]).Image = null;
							break;
						}
					}
					else if (num == this.PD.Info.Steps)
					{
						this.pnSteps.Controls[i].Visible = true;
						this.pnSteps.Controls[i].Text = this.Main.Rm.GetString("StepFinish");
						this.pnSteps.Controls[i].BackColor = SystemColors.ControlDark;
						((Button)this.pnSteps.Controls[i]).Image = null;
					}
					else
					{
						this.pnSteps.Controls[i].Visible = false;
					}
				}
			}
			if (this.PD.Info.Steps == 25)
			{
				this.btStepFinish.Visible = true;
			}
			else
			{
				this.btStepFinish.Visible = false;
			}
			this.enableInsertDeleteButtons();
			this.ActualControl.BackColor = SystemColors.ControlLightLight;
		}

		private void enableInsertDeleteButtons()
		{
			bool flag = false;
			if (this.ActualControl.Text == this.Main.Rm.GetString("StepFinish"))
			{
				flag = true;
			}
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_StepOverviewForm)
			{
				this.btDeleteStep.Enabled = true;
				this.btInsertStep.Enabled = true;
				this.btEditStep.Enabled = true;
			}
			if (this.PD.Info.Steps >= 25)
			{
				this.btInsertStep.Enabled = false;
			}
			if (this.PD.Info.Steps == 0)
			{
				this.btDeleteStep.Enabled = false;
			}
			if (flag)
			{
				this.btDeleteStep.Enabled = false;
				this.btEditStep.Enabled = false;
			}
		}

		private void btStepXX_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.ActualControl = base.ActiveControl;
				this.SNum = int.Parse(base.ActiveControl.Tag.ToString()) - 1;
				this.StepButtonShow();
				if (this.ActualControl.Text == this.Main.Rm.GetString("StepFinish"))
				{
					this.btDeleteStep.Enabled = false;
				}
				else
				{
					this.btDeleteStep.Enabled = true;
				}
				if (e.Clicks >= 2)
				{
					if (this.SNum == this.PD.Info.Steps)
					{
						if (this.btInsertStep.Enabled)
						{
							this.btInsertStep_Click(this, EventArgs.Empty);
						}
					}
					else
					{
						this.Main.ProcessProgram.CopyProg(ref this.PD_save, this.PD);
						this.EditStep(false);
					}
				}
			}
		}

		private void btStepFinish_Click(object sender, EventArgs e)
		{
			this.btDeleteStep.Enabled = false;
			this.btEditStep.Enabled = false;
		}

		private bool EditStep(bool bNewStep)
		{
			if (this.SNum >= this.PD.Info.Steps)
			{
				return false;
			}
			this.Main.CommonFunctions.StringToUShort(ref this.PD.Info.Name, this.tBProgramName.Text, 32);
			switch (this.PD.Step[this.SNum].Type)
			{
			case 2:
				this.pnMenu.Enabled = false;
				if (!this.Main.EditDrivingStep1.ShowWindow(this.PNum, this.SNum))
				{
					this.pnMenu.Enabled = true;
				}
				break;
			case 3:
				this.pnMenu.Enabled = false;
				if (!this.Main.EditFinalizeStep1.ShowWindow(this.PNum, this.SNum))
				{
					this.pnMenu.Enabled = true;
				}
				break;
			case 1:
				this.pnMenu.Enabled = false;
				if (!this.Main.EditOrganizeStep1.ShowWindow(this.PNum, this.SNum, this.PD.Info.Steps, bNewStep))
				{
					this.pnMenu.Enabled = true;
				}
				break;
			default:
				MessageBox.Show("Wrong step type in EditStep() of StepOverview", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return true;
			}
			return true;
		}

		public bool EditNextStep()
		{
			bool flag = true;
			int sNum = this.SNum;
			this.SNum++;
			flag = this.EditStep(false);
			if (!flag)
			{
				this.SNum = sNum;
			}
			return flag;
		}

		public bool EditPreviousStep()
		{
			bool flag = true;
			int sNum = this.SNum;
			if (this.SNum != 0)
			{
				this.SNum--;
			}
			flag = this.EditStep(false);
			if (!flag)
			{
				this.SNum = sNum;
			}
			return flag;
		}

		public int CheckForDoubleProgNum(uint progNum, out string progName)
		{
			progName = "";
			int result = -1;
			int num = 0;
			while (num < 1024)
			{
				if (this.Main.ProcessProgram.TempProgStruct.Num[num].Info.ProgNum != progNum || this.PD.Info.Steps <= 0 || num == this.PNum)
				{
					num++;
					continue;
				}
				result = num;
				progName = this.Main.CommonFunctions.UShortToString(this.Main.ProcessProgram.TempProgStruct.Num[num].Info.Name);
				break;
			}
			return result;
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			string text = string.Empty;
			if (!this.nEMaxTime.IsOK)
			{
				text = text + this.lbMaxTime.Text + " OutOfRange " + this.nEMaxTime.MinValue.ToString() + " - " + this.nEMaxTime.MaxValue.ToString() + "\n";
			}
			if (this.Main.CheckParamAllowed && text != string.Empty)
			{
				MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + text, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.Main.VC.PProgXChanged.Changed[this.PNum] = 1;
				string text2;
				int num = this.CheckForDoubleProgNum((uint)this.nUDPrognum.Value, out text2);
				if (num != -1)
				{
					switch (MessageBox.Show(this.Main.Rm.GetString("MbDoubleEntryCodeFound") + num.ToString() + " (" + text2 + ")", this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question))
					{
					case DialogResult.No:
						return;
					default:
						MessageBox.Show("DialogResultError1 in btBack_Click of StepOverviewForm", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						return;
					case DialogResult.Yes:
						break;
					}
				}
				this.pnMenu.Enabled = false;
				if (this.PD.Info.Steps != 0)
				{
					this.PD.Info.ProgNum = (uint)this.nUDPrognum.Value;
				}
				this.Main.CommonFunctions.StringToUShort(ref this.PD.Info.Name, this.tBProgramName.Text, 32);
				this.PD.Info.ResultParam1 = this.GetResType(this.cBResult1.SelectedIndex);
				this.PD.Info.ResultParam2 = this.GetResType(this.cBResult2.SelectedIndex);
				this.PD.Info.ResultParam3 = this.GetResType(this.cBResult3.SelectedIndex);
				this.PD.MaxTime = this.nEMaxTime.Value;
				this.Main.CommonFunctions.GetResFactor(this.PD.Info.ResultParam1);
				float torqueConvert = this.Main.TorqueConvert;
				this.Main.CommonFunctions.GetResFactor(this.PD.Info.ResultParam2);
				float torqueConvert2 = this.Main.TorqueConvert;
				this.Main.CommonFunctions.GetResFactor(this.PD.Info.ResultParam3);
				float torqueConvert3 = this.Main.TorqueConvert;
				if (this.chBProgramSpecific.Checked)
				{
					this.PD.JawLocalWrittenOnce = 1;
					this.PD.JawOpenDistance = this.nEJawOpenDistance.Value;
					this.PD.UseLocalJawSettings |= 1;
				}
				else
				{
					byte b = 1;
					byte b2 = (byte)(~b);
					this.PD.UseLocalJawSettings &= b2;
				}
				this.PD.JawOpenDistance = this.nEJawOpenDistance.Value;
				uint progNum = this.PD.Info.ProgNum;
				if (this.Main.CommonFunctions.UShortToString(this.PD.Info.Name) != this.Main.CommonFunctions.UShortToString(this.Main.VC.PProg.Num[this.PNum].Info.Name))
				{
					this.Main.MakeLogbookEntry(201003u, 2, 0f, 0f, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.PD.Info.ResultParam1 != this.Main.VC.PProg.Num[this.PNum].Info.ResultParam1)
				{
					this.Main.MakeLogbookEntry(201200u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].Info.ResultParam1, (float)(int)this.PD.Info.ResultParam1, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.PD.Info.ResultParam2 != this.Main.VC.PProg.Num[this.PNum].Info.ResultParam2)
				{
					this.Main.MakeLogbookEntry(201201u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].Info.ResultParam2, (float)(int)this.PD.Info.ResultParam2, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.PD.Info.ResultParam3 != this.Main.VC.PProg.Num[this.PNum].Info.ResultParam3)
				{
					this.Main.MakeLogbookEntry(201202u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].Info.ResultParam3, (float)(int)this.PD.Info.ResultParam3, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].MaxTime != this.PD.MaxTime)
				{
					this.Main.MakeLogbookEntry(201206u, 2, this.Main.VC.PProg.Num[this.PNum].MaxTime, this.PD.MaxTime, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].M1FilterTime != this.PD.M1FilterTime)
				{
					this.Main.MakeLogbookEntry(201205u, 2, this.Main.VC.PProg.Num[this.PNum].M1FilterTime, this.PD.M1FilterTime, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].GradientLength != this.PD.GradientLength)
				{
					this.Main.MakeLogbookEntry(201204u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].GradientLength, (float)(int)this.PD.GradientLength, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].GradientFilter != this.PD.GradientFilter)
				{
					this.Main.MakeLogbookEntry(201203u, 2, (float)this.Main.VC.PProg.Num[this.PNum].GradientFilter, (float)this.PD.GradientFilter, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].ADepthFilterTime != this.PD.ADepthFilterTime)
				{
					this.Main.MakeLogbookEntry(201224u, 2, this.Main.VC.PProg.Num[this.PNum].ADepthFilterTime, this.PD.ADepthFilterTime, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].ADepthGradientLength != this.PD.ADepthGradientLength)
				{
					this.Main.MakeLogbookEntry(201223u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].ADepthGradientLength, (float)(int)this.PD.ADepthGradientLength, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].PressureHolder != this.PD.PressureHolder)
				{
					this.Main.MakeLogbookEntry(201225u, 2, this.Main.VC.PProg.Num[this.PNum].PressureHolder, this.PD.PressureHolder, progNum, 0, byte.MaxValue);
				}
				if (this.Main.VC.PProg.Num[this.PNum].EndSetDigOut1 != this.PD.EndSetDigOut1)
				{
					this.Main.MakeLogbookEntry(201208u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].EndSetDigOut1, (float)(int)this.PD.EndSetDigOut1, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].EndValueDigOut1 != this.PD.EndValueDigOut1)
				{
					this.Main.MakeLogbookEntry(201213u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].EndValueDigOut1, (float)(int)this.PD.EndValueDigOut1, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].EndSetDigOut2 != this.PD.EndSetDigOut2)
				{
					this.Main.MakeLogbookEntry(201209u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].EndSetDigOut2, (float)(int)this.PD.EndSetDigOut2, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].EndValueDigOut2 != this.PD.EndValueDigOut2)
				{
					this.Main.MakeLogbookEntry(201214u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].EndValueDigOut2, (float)(int)this.PD.EndValueDigOut2, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].EndSetSync1 != this.PD.EndSetSync1)
				{
					this.Main.MakeLogbookEntry(201210u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].EndSetSync1, (float)(int)this.PD.EndSetSync1, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].EndValueSync1 != this.PD.EndValueSync1)
				{
					this.Main.MakeLogbookEntry(201215u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].EndValueSync1, (float)(int)this.PD.EndValueSync1, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].EndSetSync2 != this.PD.EndSetSync2)
				{
					this.Main.MakeLogbookEntry(201211u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].EndSetSync2, (float)(int)this.PD.EndSetSync2, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].EndValueSync2 != this.PD.EndValueSync2)
				{
					this.Main.MakeLogbookEntry(201216u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].EndValueSync2, (float)(int)this.PD.EndValueSync2, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].UseLocalJawSettings != this.PD.UseLocalJawSettings)
				{
					this.Main.MakeLogbookEntry(207000u, 2, (float)(int)this.Main.VC.PProg.Num[this.PNum].UseLocalJawSettings, (float)(int)this.PD.UseLocalJawSettings, progNum, 0, byte.MaxValue, 2, this.PNum);
				}
				if (this.Main.VC.PProg.Num[this.PNum].JawOpenDepthGradMin != this.PD.JawOpenDepthGradMin)
				{
					this.Main.MakeLogbookEntry(207001u, 2, this.Main.VC.PProg.Num[this.PNum].JawOpenDepthGradMin, this.PD.JawOpenDepthGradMin, progNum, 0, 40, 2, this.PNum);
				}
				if (this.PD.UseLocalJawSettings != 0 && this.Main.VC.PProg.Num[this.PNum].JawOpenDistance != this.PD.JawOpenDistance)
				{
					this.Main.MakeLogbookEntry(207003u, 2, this.Main.VC.PProg.Num[this.PNum].JawOpenDistance, this.PD.JawOpenDistance, progNum, 0, 22, 2, this.PNum);
				}
				this.Main.ProgramOverview1.UpdateMenu();
				base.Hide();
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_1_1_Programme_bearbeiten";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_1_1_Programme_bearbeiten");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btEditStep_Click(object sender, EventArgs e)
		{
			this.Main.ProcessProgram.CopyProg(ref this.PD_save, this.PD);
			this.EditStep(false);
		}

		private void btInsertStep_Click(object sender, EventArgs e)
		{
			if (this.PD.Info.Steps < 25)
			{
				this.StepKindChoice1.ShowWindow(this.PNum, this.SNum);
				if (this.StepKindChoice1.InsertStepType != 0)
				{
					this.Main.ProcessProgram.CopyProg(ref this.PD_save, this.PD);
					for (int num = this.PD.Info.Steps; num > this.SNum; num--)
					{
						this.Main.ProcessProgram.CopyStep(ref this.PD.Step[num], this.PD.Step[num - 1]);
					}
					this.PD.Step[this.SNum] = this.Main.ProcessProgram.NewInitializedStep();
					this.PD.Step[this.SNum].Type = this.StepKindChoice1.InsertStepType;
					this.PD.Info.Steps++;
					if (this.PD.Info.Steps < 25)
					{
						this.PD.Step[this.PD.Info.Steps] = this.Main.ProcessProgram.NewInitializedStep();
					}
					for (int num = 0; num < this.PD.Info.Steps; num++)
					{
						if (this.PD.Step[num].JumpTo >= this.SNum && this.PD.Step[num].JumpTo < 255)
						{
							this.PD.Step[num].JumpTo = (byte)(this.PD.Step[num].JumpTo + 1);
						}
					}
					this.Main.FourStepOverview1.InsertedStep(this.PD, (byte)this.SNum);
					this.MenEna();
					this.StepButtonShow();
					this.Main.MakeLogbookEntry(201005u, 2, 0f, 0f, this.PD.Info.ProgNum, this.SNum, byte.MaxValue, 2, this.PNum);
					this.EditStep(true);
				}
			}
		}

		private void btDeleteStep_Click(object sender, EventArgs e)
		{
			if (this.PD.Info.Steps >= 1 && this.SNum < this.PD.Info.Steps)
			{
				for (int i = 0; i < this.PD.Info.Steps - 1; i++)
				{
					if (this.PD.Step[i].Type == 1 && this.PD.Step[i].JumpTo == (byte)this.SNum)
					{
						DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbDeleteStepIsJumpTarget"), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
						if (dialogResult != DialogResult.No)
						{
							break;
						}
						return;
					}
				}
				if (this.Main.FourStepOverview1.IsStepContainedIn4Step(this.PD, (byte)this.SNum))
				{
					DialogResult dialogResult2 = MessageBox.Show(this.Main.Rm.GetString("MbDeleteStepContainedIn4step"), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
					if (dialogResult2 == DialogResult.No)
					{
						return;
					}
				}
				this.Main.FourStepOverview1.DeletedStep(this.PD, (byte)this.SNum);
				int j;
				for (j = this.SNum; j < this.PD.Info.Steps - 1; j++)
				{
					this.Main.ProcessProgram.CopyStep(ref this.PD.Step[j], this.PD.Step[j + 1]);
				}
				this.PD.Step[j].Type = 0;
				this.PD.Info.Steps--;
				this.PD.Step[this.PD.Info.Steps] = this.Main.ProcessProgram.NewInitializedStep();
				for (j = 0; j < this.PD.Info.Steps; j++)
				{
					if (this.PD.Step[j].JumpTo >= this.SNum && this.PD.Step[j].JumpTo > 0)
					{
						this.PD.Step[j].JumpTo = (byte)(this.PD.Step[j].JumpTo - 1);
					}
				}
				this.Main.MakeLogbookEntry(201006u, 2, 0f, 0f, this.PD.Info.ProgNum, this.SNum, byte.MaxValue, 2, this.PNum);
				this.checkSync1();
				this.StepButtonShow();
			}
		}

		private void btOptPrgParam_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.PrgOptParameter1.ShowWindow(this.PNum))
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void tBProgramName_TextChanged(object sender, EventArgs e)
		{
			if (this.tBProgramName.Text != this.NewText)
			{
				this.TextCheck();
			}
			this.settingsChanged(sender, e);
		}

		private void TextCheck()
		{
			char[] trimChars = new char[1]
			{
				' '
			};
			this.tBProgramName.Text = this.tBProgramName.Text.TrimStart(trimChars);
			string text = this.tBProgramName.Text;
			for (int i = 0; i < this.tBProgramName.Text.Length; i++)
			{
				if (text[i] != '-' && text[i] != '_' && text[i] != ' ' && (!char.IsLetterOrDigit(text, i) || text[i] == 'Ö' || text[i] == 'ö' || text[i] == 'Ä' || text[i] == 'ä' || text[i] == 'Ü' || text[i] == 'ü' || text[i] == 'ß'))
				{
					this.tBProgramName.Text = this.NewText;
					this.tBProgramName.SelectionStart = this.TBSelectionStart;
					return;
				}
			}
			this.NewText = this.tBProgramName.Text;
			this.TBSelectionStart = this.tBProgramName.SelectionStart;
		}

		private void tBProgramName_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode != Keys.Left && e.KeyCode != Keys.Right)
			{
				return;
			}
			this.TBSelectionStart = this.tBProgramName.SelectionStart;
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				if (sender.GetType() == typeof(TextBox))
				{
					this.Main.KeyPad1.DisableComma();
					this.Main.KeyPad1.DisablePoint();
				}
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				if (sender.GetType() == typeof(TextBox))
				{
					this.Main.KeyPad1.DisableComma();
					this.Main.KeyPad1.DisablePoint();
				}
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private byte GetResType(int index)
		{
			switch (index)
			{
			case 0:
				return 1;
			case 1:
				return 2;
			case 2:
				return 3;
			case 3:
				return 4;
			case 4:
				return 5;
			case 5:
				return 6;
			case 6:
				return 7;
			case 7:
				return 9;
			case 8:
				return 12;
			case 9:
				return 10;
			case 10:
				return 11;
			case 11:
				return 8;
			default:
				MessageBox.Show("Wrong index in GetResType() of StepOverview", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return 1;
			}
		}

		private int GetResSelectedIndex(byte type)
		{
			switch (type)
			{
			case 0:
				return 0;
			case 1:
				return 0;
			case 2:
				return 1;
			case 3:
				return 2;
			case 4:
				return 3;
			case 5:
				return 4;
			case 6:
				return 5;
			case 7:
				return 6;
			case 9:
				return 7;
			case 12:
				return 8;
			case 10:
				return 9;
			case 11:
				return 10;
			case 8:
				return 11;
			default:
				MessageBox.Show("Wrong type in GetResSelectedIndex() of StepOverview", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return 0;
			}
		}

		private string GetSwitchingTypeName(ushort type, int stepNum)
		{
			switch (type)
			{
			case 0:
				return string.Empty;
			case 1:
				return this.Main.Rm.GetString("Torque") + ": " + (this.PD.Step[stepNum].MP * this.Main.TorqueConvert).ToString("f" + 2.ToString()) + this.Main.TorqueUnitName;
			case 3:
				return this.Main.Rm.GetString("FilteredTorque") + ": " + (this.PD.Step[stepNum].MFP * this.Main.TorqueConvert).ToString("f" + 2.ToString()) + this.Main.TorqueUnitName;
			case 2:
				return this.Main.Rm.GetString("RelativeTorque") + ": " + (this.PD.Step[stepNum].MRP * this.Main.TorqueConvert).ToString("f" + 2.ToString()) + this.Main.TorqueUnitName;
			case 11:
				return this.Main.Rm.GetString("M360Follow") + ": " + (this.PD.Step[stepNum].MRP * this.Main.TorqueConvert).ToString("f" + 4.ToString()) + this.Main.TorqueUnitName;
			case 4:
				return this.Main.Rm.GetString("Gradient") + ": " + (this.PD.Step[stepNum].MGP * this.Main.TorqueConvert).ToString("f" + 4.ToString()) + this.Main.TorqueUnitName + "/" + this.Main.Rm.GetString("Degree");
			case 5:
				return this.Main.Rm.GetString("Angle") + ": " + this.PD.Step[stepNum].WP.ToString("f" + 1.ToString()) + this.Main.Rm.GetString("Degree");
			case 6:
				return this.Main.Rm.GetString("Time") + ": " + this.PD.Step[stepNum].TP.ToString("f" + 2.ToString()) + this.Main.Rm.GetString("Second");
			case 7:
				return this.Main.Rm.GetString("AnaDepth") + ": " + this.PD.Step[stepNum].LP.ToString("f" + 1.ToString()) + this.Main.Rm.GetString("Milimeter");
			case 10:
				return this.Main.Rm.GetString("DepthGrad") + ": " + this.PD.Step[stepNum].LGP.ToString("f" + 4.ToString()) + this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second");
			case 8:
				return this.Main.Rm.GetString("AnaSignal") + ": " + this.PD.Step[stepNum].AnaP.ToString("f" + 2.ToString());
			case 9:
				return this.Main.Rm.GetString("DigitalSignal");
			case 50:
				return this.Main.Rm.GetString("Torque") + "(" + this.Main.Rm.GetString("FromAbove") + "): " + (this.PD.Step[stepNum].MP * this.Main.TorqueConvert).ToString("f" + 2.ToString()) + this.Main.TorqueUnitName;
			case 51:
				return this.Main.Rm.GetString("FilteredTorque") + "(" + this.Main.Rm.GetString("FromAbove") + "): " + (this.PD.Step[stepNum].MFP * this.Main.TorqueConvert).ToString("f" + 2.ToString()) + this.Main.TorqueUnitName;
			case 52:
				return this.Main.Rm.GetString("Gradient") + "(" + this.Main.Rm.GetString("FromAbove") + "): " + (this.PD.Step[stepNum].MGP * this.Main.TorqueConvert).ToString("f" + 4.ToString()) + this.Main.TorqueUnitName + "/" + this.Main.Rm.GetString("Degree");
			case 53:
				return this.Main.Rm.GetString("AnaDepth") + "(" + this.Main.Rm.GetString("FromAbove") + "): " + this.PD.Step[stepNum].LP.ToString("f" + 1.ToString()) + this.Main.Rm.GetString("Milimeter");
			case 55:
				return this.Main.Rm.GetString("DepthGrad") + "(" + this.Main.Rm.GetString("FromAbove") + "): " + this.PD.Step[stepNum].LGP.ToString("f" + 4.ToString()) + this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second");
			case 54:
				return this.Main.Rm.GetString("AnaSignal") + "(" + this.Main.Rm.GetString("FromAbove") + "): " + this.PD.Step[stepNum].AnaP.ToString("f" + 2.ToString());
			case 1000:
				return this.Main.Rm.GetString("JumpOkTo") + " " + this.Main.Rm.GetString("Step") + " " + (this.PD.Step[stepNum].JumpTo + 1).ToString();
			case 1001:
				return this.Main.Rm.GetString("JumpNokTo") + " " + this.Main.Rm.GetString("Step") + " " + (this.PD.Step[stepNum].JumpTo + 1).ToString();
			case 1002:
				return this.Main.Rm.GetString("JumpAlwaysTo") + " " + this.Main.Rm.GetString("Step") + " " + (this.PD.Step[stepNum].JumpTo + 1).ToString();
			case 1010:
				return this.Main.Rm.GetString("Stop");
			case 1011:
				return this.Main.Rm.GetString("StopOk");
			case 1012:
				return this.Main.Rm.GetString("StopNok");
			case 1020:
				return this.Main.Rm.GetString("ResetAngle");
			case 1030:
				return this.Main.Rm.GetString("SetDigOut");
			case 1040:
				return this.Main.Rm.GetString("ResetADepth");
			default:
				MessageBox.Show("Wrong switch type in GetSwitchingTypeName() of StepOverview", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return "Error";
			}
		}

		private void StepOverviewForm_Activated(object sender, EventArgs e)
		{
			this.lb_nEJawOpenDistance.Text = this.Main.VC.SpConst.JawOpenDistance.ToString("0.00");
			if (this.Main.EditDrivingStep1.WasCanceled || this.Main.EditFinalizeStep1.WasCanceled || this.Main.EditOrganizeStep1.WasCanceled)
			{
				this.Main.ProcessProgram.CopyProg(ref this.PD, this.PD_save);
				this.StepButtonShow();
			}
			else
			{
				this.checkSync1();
			}
			this.MenEna();
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.Main.DeleteLogEntries(2, this.PNum);
			this.bCanceled = true;
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		public void KeyArrived()
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else if (this.Main.PassCodeLevel > 0)
			{
				if (this.Main.GetExclusiveBlock1())
				{
					if (this.Main.ProcessProgram.UploadAllProgDataFromController())
					{
						this.Main.CheckParamAllowed = true;
						base.Hide();
					}
				}
				else
				{
					this.Main.CheckParamAllowed = false;
				}
			}
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void placeChBProgramSpecific()
		{
		}

		private void showJawControls()
		{
			if (!this.chBProgramSpecific.Checked)
			{
				this.lbJawOpenDistance.Enabled = false;
				this.lbUnitJawOpenDistance.Enabled = false;
				this.nEJawOpenDistance.Enabled = false;
				this.nEJawOpenDistance.Visible = false;
				this.nEJawOpenDistance.ReadOnly = true;
				this.lb_nEJawOpenDistance.Visible = true;
			}
			else
			{
				this.lbJawOpenDistance.Enabled = true;
				this.lbUnitJawOpenDistance.Enabled = true;
				this.nEJawOpenDistance.Enabled = true;
				this.nEJawOpenDistance.Visible = true;
				this.nEJawOpenDistance.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
				this.lb_nEJawOpenDistance.Visible = false;
			}
		}

		private void checkSync1()
		{
		}

		private void chBProgramSpecific_CheckedChanged(object sender, EventArgs e)
		{
			if (!this.initInProgress)
			{
				this.Main.SettingsChanged();
				this.placeChBProgramSpecific();
				this.showJawControls();
				this.checkSync1();
			}
		}

		private void timerDisplayMessage_Tick(object sender, EventArgs e)
		{
			this.timerDisplayMessage.Stop();
			if (this.messageText.Length > 0)
			{
				MessageBox.Show(this.messageText, this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.messageText = "";
			}
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.initInProgress)
			{
				this.Main.SettingsChanged();
			}
		}
	}
}
