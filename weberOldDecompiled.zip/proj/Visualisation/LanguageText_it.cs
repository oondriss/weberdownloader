using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Visualisation
{
	[DebuggerNonUserCode]
	[CompilerGenerated]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	internal class LanguageText_it
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(LanguageText_it.resourceMan, null))
				{
					ResourceManager resourceManager = LanguageText_it.resourceMan = new ResourceManager("Visualisation.LanguageText_it", typeof(LanguageText_it).Assembly);
				}
				return LanguageText_it.resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return LanguageText_it.resourceCulture;
			}
			set
			{
				LanguageText_it.resourceCulture = value;
			}
		}

		internal static string Abr_Program => LanguageText_it.ResourceManager.GetString("Abr_Program", LanguageText_it.resourceCulture);

		internal static string AbrAnaDepth => LanguageText_it.ResourceManager.GetString("AbrAnaDepth", LanguageText_it.resourceCulture);

		internal static string AbrAnaSignal => LanguageText_it.ResourceManager.GetString("AbrAnaSignal", LanguageText_it.resourceCulture);

		internal static string AbrAngle => LanguageText_it.ResourceManager.GetString("AbrAngle", LanguageText_it.resourceCulture);

		internal static string AbrDelayTorque => LanguageText_it.ResourceManager.GetString("AbrDelayTorque", LanguageText_it.resourceCulture);

		internal static string AbrDepthGrad => LanguageText_it.ResourceManager.GetString("AbrDepthGrad", LanguageText_it.resourceCulture);

		internal static string AbrFilteredTorque => LanguageText_it.ResourceManager.GetString("AbrFilteredTorque", LanguageText_it.resourceCulture);

		internal static string AbrGradient => LanguageText_it.ResourceManager.GetString("AbrGradient", LanguageText_it.resourceCulture);

		internal static string AbrM360Follow => LanguageText_it.ResourceManager.GetString("AbrM360Follow", LanguageText_it.resourceCulture);

		internal static string AbrMaxTorque => LanguageText_it.ResourceManager.GetString("AbrMaxTorque", LanguageText_it.resourceCulture);

		internal static string AbrNumber => LanguageText_it.ResourceManager.GetString("AbrNumber", LanguageText_it.resourceCulture);

		internal static string AbrTime => LanguageText_it.ResourceManager.GetString("AbrTime", LanguageText_it.resourceCulture);

		internal static string AbrTorque => LanguageText_it.ResourceManager.GetString("AbrTorque", LanguageText_it.resourceCulture);

		internal static string AccessCheck => LanguageText_it.ResourceManager.GetString("AccessCheck", LanguageText_it.resourceCulture);

		internal static string AccessRequest => LanguageText_it.ResourceManager.GetString("AccessRequest", LanguageText_it.resourceCulture);

		internal static string Actualize => LanguageText_it.ResourceManager.GetString("Actualize", LanguageText_it.resourceCulture);

		internal static string AddEntry => LanguageText_it.ResourceManager.GetString("AddEntry", LanguageText_it.resourceCulture);

		internal static string AIError => LanguageText_it.ResourceManager.GetString("AIError", LanguageText_it.resourceCulture);

		internal static string All => LanguageText_it.ResourceManager.GetString("All", LanguageText_it.resourceCulture);

		internal static string AllFiles => LanguageText_it.ResourceManager.GetString("AllFiles", LanguageText_it.resourceCulture);

		internal static string AnaDepth => LanguageText_it.ResourceManager.GetString("AnaDepth", LanguageText_it.resourceCulture);

		internal static string Analysis => LanguageText_it.ResourceManager.GetString("Analysis", LanguageText_it.resourceCulture);

		internal static string AnaOutput => LanguageText_it.ResourceManager.GetString("AnaOutput", LanguageText_it.resourceCulture);

		internal static string AnaSignal => LanguageText_it.ResourceManager.GetString("AnaSignal", LanguageText_it.resourceCulture);

		internal static string AnaSigOffset => LanguageText_it.ResourceManager.GetString("AnaSigOffset", LanguageText_it.resourceCulture);

		internal static string AnaSigScale => LanguageText_it.ResourceManager.GetString("AnaSigScale", LanguageText_it.resourceCulture);

		internal static string Angle => LanguageText_it.ResourceManager.GetString("Angle", LanguageText_it.resourceCulture);

		internal static string AngleRedundantTolerance => LanguageText_it.ResourceManager.GetString("AngleRedundantTolerance", LanguageText_it.resourceCulture);

		internal static string AngleSensorInvers => LanguageText_it.ResourceManager.GetString("AngleSensorInvers", LanguageText_it.resourceCulture);

		internal static string AngleSensorScale => LanguageText_it.ResourceManager.GetString("AngleSensorScale", LanguageText_it.resourceCulture);

		internal static string AngleTorqueSensor => LanguageText_it.ResourceManager.GetString("AngleTorqueSensor", LanguageText_it.resourceCulture);

		internal static string Apply => LanguageText_it.ResourceManager.GetString("Apply", LanguageText_it.resourceCulture);

		internal static string ApplyEntry => LanguageText_it.ResourceManager.GetString("ApplyEntry", LanguageText_it.resourceCulture);

		internal static string AutoCurveAbort => LanguageText_it.ResourceManager.GetString("AutoCurveAbort", LanguageText_it.resourceCulture);

		internal static string Automatic => LanguageText_it.ResourceManager.GetString("Automatic", LanguageText_it.resourceCulture);

		internal static string AutoMode => LanguageText_it.ResourceManager.GetString("AutoMode", LanguageText_it.resourceCulture);

		internal static string AvailableValueNumber => LanguageText_it.ResourceManager.GetString("AvailableValueNumber", LanguageText_it.resourceCulture);

		internal static string Back => LanguageText_it.ResourceManager.GetString("Back", LanguageText_it.resourceCulture);

		internal static string Backup => LanguageText_it.ResourceManager.GetString("Backup", LanguageText_it.resourceCulture);

		internal static string Backup205000 => LanguageText_it.ResourceManager.GetString("Backup205000", LanguageText_it.resourceCulture);

		internal static string Backup205001 => LanguageText_it.ResourceManager.GetString("Backup205001", LanguageText_it.resourceCulture);

		internal static string Backup205002 => LanguageText_it.ResourceManager.GetString("Backup205002", LanguageText_it.resourceCulture);

		internal static string Backup205003 => LanguageText_it.ResourceManager.GetString("Backup205003", LanguageText_it.resourceCulture);

		internal static string Battery => LanguageText_it.ResourceManager.GetString("Battery", LanguageText_it.resourceCulture);

		internal static string Baudrate => LanguageText_it.ResourceManager.GetString("Baudrate", LanguageText_it.resourceCulture);

		internal static string bt0 => LanguageText_it.ResourceManager.GetString("bt0", LanguageText_it.resourceCulture);

		internal static string bt1 => LanguageText_it.ResourceManager.GetString("bt1", LanguageText_it.resourceCulture);

		internal static string bt2 => LanguageText_it.ResourceManager.GetString("bt2", LanguageText_it.resourceCulture);

		internal static string bt3 => LanguageText_it.ResourceManager.GetString("bt3", LanguageText_it.resourceCulture);

		internal static string bt4 => LanguageText_it.ResourceManager.GetString("bt4", LanguageText_it.resourceCulture);

		internal static string bt5 => LanguageText_it.ResourceManager.GetString("bt5", LanguageText_it.resourceCulture);

		internal static string bt6 => LanguageText_it.ResourceManager.GetString("bt6", LanguageText_it.resourceCulture);

		internal static string bt7 => LanguageText_it.ResourceManager.GetString("bt7", LanguageText_it.resourceCulture);

		internal static string bt8 => LanguageText_it.ResourceManager.GetString("bt8", LanguageText_it.resourceCulture);

		internal static string bt9 => LanguageText_it.ResourceManager.GetString("bt9", LanguageText_it.resourceCulture);

		internal static string btA => LanguageText_it.ResourceManager.GetString("btA", LanguageText_it.resourceCulture);

		internal static string btApply => LanguageText_it.ResourceManager.GetString("btApply", LanguageText_it.resourceCulture);

		internal static string btB => LanguageText_it.ResourceManager.GetString("btB", LanguageText_it.resourceCulture);

		internal static string btBackspace => LanguageText_it.ResourceManager.GetString("btBackspace", LanguageText_it.resourceCulture);

		internal static string btC => LanguageText_it.ResourceManager.GetString("btC", LanguageText_it.resourceCulture);

		internal static string btCancel => LanguageText_it.ResourceManager.GetString("btCancel", LanguageText_it.resourceCulture);

		internal static string btChangeDefaultDir => LanguageText_it.ResourceManager.GetString("btChangeDefaultDir", LanguageText_it.resourceCulture);

		internal static string btD => LanguageText_it.ResourceManager.GetString("btD", LanguageText_it.resourceCulture);

		internal static string btE => LanguageText_it.ResourceManager.GetString("btE", LanguageText_it.resourceCulture);

		internal static string btErase => LanguageText_it.ResourceManager.GetString("btErase", LanguageText_it.resourceCulture);

		internal static string btF => LanguageText_it.ResourceManager.GetString("btF", LanguageText_it.resourceCulture);

		internal static string btG => LanguageText_it.ResourceManager.GetString("btG", LanguageText_it.resourceCulture);

		internal static string btH => LanguageText_it.ResourceManager.GetString("btH", LanguageText_it.resourceCulture);

		internal static string btI => LanguageText_it.ResourceManager.GetString("btI", LanguageText_it.resourceCulture);

		internal static string btJ => LanguageText_it.ResourceManager.GetString("btJ", LanguageText_it.resourceCulture);

		internal static string btK => LanguageText_it.ResourceManager.GetString("btK", LanguageText_it.resourceCulture);

		internal static string btL => LanguageText_it.ResourceManager.GetString("btL", LanguageText_it.resourceCulture);

		internal static string btLoad => LanguageText_it.ResourceManager.GetString("btLoad", LanguageText_it.resourceCulture);

		internal static string btM => LanguageText_it.ResourceManager.GetString("btM", LanguageText_it.resourceCulture);

		internal static string btMinusDown => LanguageText_it.ResourceManager.GetString("btMinusDown", LanguageText_it.resourceCulture);

		internal static string btMinusUp => LanguageText_it.ResourceManager.GetString("btMinusUp", LanguageText_it.resourceCulture);

		internal static string btN => LanguageText_it.ResourceManager.GetString("btN", LanguageText_it.resourceCulture);

		internal static string btO => LanguageText_it.ResourceManager.GetString("btO", LanguageText_it.resourceCulture);

		internal static string btP => LanguageText_it.ResourceManager.GetString("btP", LanguageText_it.resourceCulture);

		internal static string btQ => LanguageText_it.ResourceManager.GetString("btQ", LanguageText_it.resourceCulture);

		internal static string btR => LanguageText_it.ResourceManager.GetString("btR", LanguageText_it.resourceCulture);

		internal static string btRes1 => LanguageText_it.ResourceManager.GetString("btRes1", LanguageText_it.resourceCulture);

		internal static string btRes2 => LanguageText_it.ResourceManager.GetString("btRes2", LanguageText_it.resourceCulture);

		internal static string btRes3 => LanguageText_it.ResourceManager.GetString("btRes3", LanguageText_it.resourceCulture);

		internal static string btS => LanguageText_it.ResourceManager.GetString("btS", LanguageText_it.resourceCulture);

		internal static string btShift => LanguageText_it.ResourceManager.GetString("btShift", LanguageText_it.resourceCulture);

		internal static string btSpace => LanguageText_it.ResourceManager.GetString("btSpace", LanguageText_it.resourceCulture);

		internal static string btT => LanguageText_it.ResourceManager.GetString("btT", LanguageText_it.resourceCulture);

		internal static string btTeach => LanguageText_it.ResourceManager.GetString("btTeach", LanguageText_it.resourceCulture);

		internal static string btU => LanguageText_it.ResourceManager.GetString("btU", LanguageText_it.resourceCulture);

		internal static string btV => LanguageText_it.ResourceManager.GetString("btV", LanguageText_it.resourceCulture);

		internal static string btW => LanguageText_it.ResourceManager.GetString("btW", LanguageText_it.resourceCulture);

		internal static string btX => LanguageText_it.ResourceManager.GetString("btX", LanguageText_it.resourceCulture);

		internal static string btY => LanguageText_it.ResourceManager.GetString("btY", LanguageText_it.resourceCulture);

		internal static string btZ => LanguageText_it.ResourceManager.GetString("btZ", LanguageText_it.resourceCulture);

		internal static string CalculateCurves => LanguageText_it.ResourceManager.GetString("CalculateCurves", LanguageText_it.resourceCulture);

		internal static string CalDisable => LanguageText_it.ResourceManager.GetString("CalDisable", LanguageText_it.resourceCulture);

		internal static string CalibrationSignal => LanguageText_it.ResourceManager.GetString("CalibrationSignal", LanguageText_it.resourceCulture);

		internal static string Cancel => LanguageText_it.ResourceManager.GetString("Cancel", LanguageText_it.resourceCulture);

		internal static string Changed => LanguageText_it.ResourceManager.GetString("Changed", LanguageText_it.resourceCulture);

		internal static string ChangeEntry => LanguageText_it.ResourceManager.GetString("ChangeEntry", LanguageText_it.resourceCulture);

		internal static string ChangesLog => LanguageText_it.ResourceManager.GetString("ChangesLog", LanguageText_it.resourceCulture);

		internal static string chBEmtyPrograms => LanguageText_it.ResourceManager.GetString("chBEmtyPrograms", LanguageText_it.resourceCulture);

		internal static string chBProgPreview => LanguageText_it.ResourceManager.GetString("chBProgPreview", LanguageText_it.resourceCulture);

		internal static string chBUseDefaultDir => LanguageText_it.ResourceManager.GetString("chBUseDefaultDir", LanguageText_it.resourceCulture);

		internal static string CheckFrictionTestStart => LanguageText_it.ResourceManager.GetString("CheckFrictionTestStart", LanguageText_it.resourceCulture);

		internal static string CheckHandStart => LanguageText_it.ResourceManager.GetString("CheckHandStart", LanguageText_it.resourceCulture);

		internal static string CheckParameter => LanguageText_it.ResourceManager.GetString("CheckParameter", LanguageText_it.resourceCulture);

		internal static string CheckRight => LanguageText_it.ResourceManager.GetString("CheckRight", LanguageText_it.resourceCulture);

		internal static string Close => LanguageText_it.ResourceManager.GetString("Close", LanguageText_it.resourceCulture);

		internal static string ControllerName => LanguageText_it.ResourceManager.GetString("ControllerName", LanguageText_it.resourceCulture);

		internal static string ControllerTime => LanguageText_it.ResourceManager.GetString("ControllerTime", LanguageText_it.resourceCulture);

		internal static string CopyProgram => LanguageText_it.ResourceManager.GetString("CopyProgram", LanguageText_it.resourceCulture);

		internal static string CountPassMax => LanguageText_it.ResourceManager.GetString("CountPassMax", LanguageText_it.resourceCulture);

		internal static string CreatedUsers => LanguageText_it.ResourceManager.GetString("CreatedUsers", LanguageText_it.resourceCulture);

		internal static string CumulStats => LanguageText_it.ResourceManager.GetString("CumulStats", LanguageText_it.resourceCulture);

		internal static string CursorsCannotSwitch => LanguageText_it.ResourceManager.GetString("CursorsCannotSwitch", LanguageText_it.resourceCulture);

		internal static string CurveDisplay => LanguageText_it.ResourceManager.GetString("CurveDisplay", LanguageText_it.resourceCulture);

		internal static string CurveLoad => LanguageText_it.ResourceManager.GetString("CurveLoad", LanguageText_it.resourceCulture);

		internal static string CurvePrint => LanguageText_it.ResourceManager.GetString("CurvePrint", LanguageText_it.resourceCulture);

		internal static string CurveResultKind => LanguageText_it.ResourceManager.GetString("CurveResultKind", LanguageText_it.resourceCulture);

		internal static string CurveResultNumber => LanguageText_it.ResourceManager.GetString("CurveResultNumber", LanguageText_it.resourceCulture);

		internal static string CurveSave => LanguageText_it.ResourceManager.GetString("CurveSave", LanguageText_it.resourceCulture);

		internal static string CurveSelection => LanguageText_it.ResourceManager.GetString("CurveSelection", LanguageText_it.resourceCulture);

		internal static string CurvesZoomedIn => LanguageText_it.ResourceManager.GetString("CurvesZoomedIn", LanguageText_it.resourceCulture);

		internal static string CurvesZoomedOut => LanguageText_it.ResourceManager.GetString("CurvesZoomedOut", LanguageText_it.resourceCulture);

		internal static string CustomCounter => LanguageText_it.ResourceManager.GetString("CustomCounter", LanguageText_it.resourceCulture);

		internal static string Cycle => LanguageText_it.ResourceManager.GetString("Cycle", LanguageText_it.resourceCulture);

		internal static string CycleCounter => LanguageText_it.ResourceManager.GetString("CycleCounter", LanguageText_it.resourceCulture);

		internal static string CycleNumber => LanguageText_it.ResourceManager.GetString("CycleNumber", LanguageText_it.resourceCulture);

		internal static string CycleSave => LanguageText_it.ResourceManager.GetString("CycleSave", LanguageText_it.resourceCulture);

		internal static string Czech => LanguageText_it.ResourceManager.GetString("Czech", LanguageText_it.resourceCulture);

		internal static string DateTime => LanguageText_it.ResourceManager.GetString("DateTime", LanguageText_it.resourceCulture);

		internal static string DeblockController => LanguageText_it.ResourceManager.GetString("DeblockController", LanguageText_it.resourceCulture);

		internal static string DeclForSpSave => LanguageText_it.ResourceManager.GetString("DeclForSpSave", LanguageText_it.resourceCulture);

		internal static string Degree => LanguageText_it.ResourceManager.GetString("Degree", LanguageText_it.resourceCulture);

		internal static string DelayTorque => LanguageText_it.ResourceManager.GetString("DelayTorque", LanguageText_it.resourceCulture);

		internal static string DeleteCounter => LanguageText_it.ResourceManager.GetString("DeleteCounter", LanguageText_it.resourceCulture);

		internal static string DeleteCustomCounter => LanguageText_it.ResourceManager.GetString("DeleteCustomCounter", LanguageText_it.resourceCulture);

		internal static string DeleteEntry => LanguageText_it.ResourceManager.GetString("DeleteEntry", LanguageText_it.resourceCulture);

		internal static string DeleteJob => LanguageText_it.ResourceManager.GetString("DeleteJob", LanguageText_it.resourceCulture);

		internal static string DeleteLastResults => LanguageText_it.ResourceManager.GetString("DeleteLastResults", LanguageText_it.resourceCulture);

		internal static string DeleteProgram => LanguageText_it.ResourceManager.GetString("DeleteProgram", LanguageText_it.resourceCulture);

		internal static string DeleteRecursiveStat => LanguageText_it.ResourceManager.GetString("DeleteRecursiveStat", LanguageText_it.resourceCulture);

		internal static string DeleteStep => LanguageText_it.ResourceManager.GetString("DeleteStep", LanguageText_it.resourceCulture);

		internal static string DeleteValues => LanguageText_it.ResourceManager.GetString("DeleteValues", LanguageText_it.resourceCulture);

		internal static string DepthFilterTime => LanguageText_it.ResourceManager.GetString("DepthFilterTime", LanguageText_it.resourceCulture);

		internal static string DepthGrad => LanguageText_it.ResourceManager.GetString("DepthGrad", LanguageText_it.resourceCulture);

		internal static string DepthGradLength => LanguageText_it.ResourceManager.GetString("DepthGradLength", LanguageText_it.resourceCulture);

		internal static string DepthSensor => LanguageText_it.ResourceManager.GetString("DepthSensor", LanguageText_it.resourceCulture);

		internal static string DepthSensorInvers => LanguageText_it.ResourceManager.GetString("DepthSensorInvers", LanguageText_it.resourceCulture);

		internal static string DGAddress => LanguageText_it.ResourceManager.GetString("DGAddress", LanguageText_it.resourceCulture);

		internal static string DHCP => LanguageText_it.ResourceManager.GetString("DHCP", LanguageText_it.resourceCulture);

		internal static string DigitalSignal => LanguageText_it.ResourceManager.GetString("DigitalSignal", LanguageText_it.resourceCulture);

		internal static string DigitOut => LanguageText_it.ResourceManager.GetString("DigitOut", LanguageText_it.resourceCulture);

		internal static string DigSigAtEnd => LanguageText_it.ResourceManager.GetString("DigSigAtEnd", LanguageText_it.resourceCulture);

		internal static string DigSigRunning => LanguageText_it.ResourceManager.GetString("DigSigRunning", LanguageText_it.resourceCulture);

		internal static string DiscardChanges => LanguageText_it.ResourceManager.GetString("DiscardChanges", LanguageText_it.resourceCulture);

		internal static string Done => LanguageText_it.ResourceManager.GetString("Done", LanguageText_it.resourceCulture);

		internal static string DriveUnit => LanguageText_it.ResourceManager.GetString("DriveUnit", LanguageText_it.resourceCulture);

		internal static string DriveUnitInvers => LanguageText_it.ResourceManager.GetString("DriveUnitInvers", LanguageText_it.resourceCulture);

		internal static string Driving => LanguageText_it.ResourceManager.GetString("Driving", LanguageText_it.resourceCulture);

		internal static string DrivingStep => LanguageText_it.ResourceManager.GetString("DrivingStep", LanguageText_it.resourceCulture);

		internal static string EditCancel => LanguageText_it.ResourceManager.GetString("EditCancel", LanguageText_it.resourceCulture);

		internal static string EditEntry => LanguageText_it.ResourceManager.GetString("EditEntry", LanguageText_it.resourceCulture);

		internal static string EditProgram => LanguageText_it.ResourceManager.GetString("EditProgram", LanguageText_it.resourceCulture);

		internal static string EditStep => LanguageText_it.ResourceManager.GetString("EditStep", LanguageText_it.resourceCulture);

		internal static string EMGMode => LanguageText_it.ResourceManager.GetString("EMGMode", LanguageText_it.resourceCulture);

		internal static string Empty => LanguageText_it.ResourceManager.GetString("Empty", LanguageText_it.resourceCulture);

		internal static string EmptyString => LanguageText_it.ResourceManager.GetString("EmptyString", LanguageText_it.resourceCulture);

		internal static string EncError => LanguageText_it.ResourceManager.GetString("EncError", LanguageText_it.resourceCulture);

		internal static string English => LanguageText_it.ResourceManager.GetString("English", LanguageText_it.resourceCulture);

		internal static string Error1000 => LanguageText_it.ResourceManager.GetString("Error1000", LanguageText_it.resourceCulture);

		internal static string Error1001 => LanguageText_it.ResourceManager.GetString("Error1001", LanguageText_it.resourceCulture);

		internal static string Error1002 => LanguageText_it.ResourceManager.GetString("Error1002", LanguageText_it.resourceCulture);

		internal static string Error1003 => LanguageText_it.ResourceManager.GetString("Error1003", LanguageText_it.resourceCulture);

		internal static string Error1004 => LanguageText_it.ResourceManager.GetString("Error1004", LanguageText_it.resourceCulture);

		internal static string Error1005 => LanguageText_it.ResourceManager.GetString("Error1005", LanguageText_it.resourceCulture);

		internal static string Error1006 => LanguageText_it.ResourceManager.GetString("Error1006", LanguageText_it.resourceCulture);

		internal static string Error1007 => LanguageText_it.ResourceManager.GetString("Error1007", LanguageText_it.resourceCulture);

		internal static string Error1008 => LanguageText_it.ResourceManager.GetString("Error1008", LanguageText_it.resourceCulture);

		internal static string Error1009 => LanguageText_it.ResourceManager.GetString("Error1009", LanguageText_it.resourceCulture);

		internal static string Error1010 => LanguageText_it.ResourceManager.GetString("Error1010", LanguageText_it.resourceCulture);

		internal static string Error1011 => LanguageText_it.ResourceManager.GetString("Error1011", LanguageText_it.resourceCulture);

		internal static string Error1012 => LanguageText_it.ResourceManager.GetString("Error1012", LanguageText_it.resourceCulture);

		internal static string Error1013 => LanguageText_it.ResourceManager.GetString("Error1013", LanguageText_it.resourceCulture);

		internal static string Error1014 => LanguageText_it.ResourceManager.GetString("Error1014", LanguageText_it.resourceCulture);

		internal static string Error1015 => LanguageText_it.ResourceManager.GetString("Error1015", LanguageText_it.resourceCulture);

		internal static string Error1016 => LanguageText_it.ResourceManager.GetString("Error1016", LanguageText_it.resourceCulture);

		internal static string Error1017 => LanguageText_it.ResourceManager.GetString("Error1017", LanguageText_it.resourceCulture);

		internal static string Error1018 => LanguageText_it.ResourceManager.GetString("Error1018", LanguageText_it.resourceCulture);

		internal static string Error1019 => LanguageText_it.ResourceManager.GetString("Error1019", LanguageText_it.resourceCulture);

		internal static string Error1020 => LanguageText_it.ResourceManager.GetString("Error1020", LanguageText_it.resourceCulture);

		internal static string Error1021 => LanguageText_it.ResourceManager.GetString("Error1021", LanguageText_it.resourceCulture);

		internal static string Error1022 => LanguageText_it.ResourceManager.GetString("Error1022", LanguageText_it.resourceCulture);

		internal static string Error1023 => LanguageText_it.ResourceManager.GetString("Error1023", LanguageText_it.resourceCulture);

		internal static string Error1024 => LanguageText_it.ResourceManager.GetString("Error1024", LanguageText_it.resourceCulture);

		internal static string Error1025 => LanguageText_it.ResourceManager.GetString("Error1025", LanguageText_it.resourceCulture);

		internal static string Error1026 => LanguageText_it.ResourceManager.GetString("Error1026", LanguageText_it.resourceCulture);

		internal static string Error1027 => LanguageText_it.ResourceManager.GetString("Error1027", LanguageText_it.resourceCulture);

		internal static string Error1028 => LanguageText_it.ResourceManager.GetString("Error1028", LanguageText_it.resourceCulture);

		internal static string Error1029 => LanguageText_it.ResourceManager.GetString("Error1029", LanguageText_it.resourceCulture);

		internal static string Error1030 => LanguageText_it.ResourceManager.GetString("Error1030", LanguageText_it.resourceCulture);

		internal static string Error1031 => LanguageText_it.ResourceManager.GetString("Error1031", LanguageText_it.resourceCulture);

		internal static string Error1032 => LanguageText_it.ResourceManager.GetString("Error1032", LanguageText_it.resourceCulture);

		internal static string Error1033 => LanguageText_it.ResourceManager.GetString("Error1033", LanguageText_it.resourceCulture);

		internal static string Error1034 => LanguageText_it.ResourceManager.GetString("Error1034", LanguageText_it.resourceCulture);

		internal static string Error1035 => LanguageText_it.ResourceManager.GetString("Error1035", LanguageText_it.resourceCulture);

		internal static string Error1036 => LanguageText_it.ResourceManager.GetString("Error1036", LanguageText_it.resourceCulture);

		internal static string Error1037 => LanguageText_it.ResourceManager.GetString("Error1037", LanguageText_it.resourceCulture);

		internal static string Error1038 => LanguageText_it.ResourceManager.GetString("Error1038", LanguageText_it.resourceCulture);

		internal static string Error1100 => LanguageText_it.ResourceManager.GetString("Error1100", LanguageText_it.resourceCulture);

		internal static string Error1101 => LanguageText_it.ResourceManager.GetString("Error1101", LanguageText_it.resourceCulture);

		internal static string Error1102 => LanguageText_it.ResourceManager.GetString("Error1102", LanguageText_it.resourceCulture);

		internal static string Error1110 => LanguageText_it.ResourceManager.GetString("Error1110", LanguageText_it.resourceCulture);

		internal static string Error1111 => LanguageText_it.ResourceManager.GetString("Error1111", LanguageText_it.resourceCulture);

		internal static string Error1112 => LanguageText_it.ResourceManager.GetString("Error1112", LanguageText_it.resourceCulture);

		internal static string Error1113 => LanguageText_it.ResourceManager.GetString("Error1113", LanguageText_it.resourceCulture);

		internal static string Error1114 => LanguageText_it.ResourceManager.GetString("Error1114", LanguageText_it.resourceCulture);

		internal static string Error1140 => LanguageText_it.ResourceManager.GetString("Error1140", LanguageText_it.resourceCulture);

		internal static string Error1141 => LanguageText_it.ResourceManager.GetString("Error1141", LanguageText_it.resourceCulture);

		internal static string Error1150 => LanguageText_it.ResourceManager.GetString("Error1150", LanguageText_it.resourceCulture);

		internal static string Error1151 => LanguageText_it.ResourceManager.GetString("Error1151", LanguageText_it.resourceCulture);

		internal static string Error1152 => LanguageText_it.ResourceManager.GetString("Error1152", LanguageText_it.resourceCulture);

		internal static string Error1153 => LanguageText_it.ResourceManager.GetString("Error1153", LanguageText_it.resourceCulture);

		internal static string Error1160 => LanguageText_it.ResourceManager.GetString("Error1160", LanguageText_it.resourceCulture);

		internal static string Error1161 => LanguageText_it.ResourceManager.GetString("Error1161", LanguageText_it.resourceCulture);

		internal static string Error1162 => LanguageText_it.ResourceManager.GetString("Error1162", LanguageText_it.resourceCulture);

		internal static string Error1163 => LanguageText_it.ResourceManager.GetString("Error1163", LanguageText_it.resourceCulture);

		internal static string Error1200 => LanguageText_it.ResourceManager.GetString("Error1200", LanguageText_it.resourceCulture);

		internal static string Error1201 => LanguageText_it.ResourceManager.GetString("Error1201", LanguageText_it.resourceCulture);

		internal static string Error1202 => LanguageText_it.ResourceManager.GetString("Error1202", LanguageText_it.resourceCulture);

		internal static string Error1203 => LanguageText_it.ResourceManager.GetString("Error1203", LanguageText_it.resourceCulture);

		internal static string Error1301 => LanguageText_it.ResourceManager.GetString("Error1301", LanguageText_it.resourceCulture);

		internal static string Error1302 => LanguageText_it.ResourceManager.GetString("Error1302", LanguageText_it.resourceCulture);

		internal static string Error1303 => LanguageText_it.ResourceManager.GetString("Error1303", LanguageText_it.resourceCulture);

		internal static string Error1304 => LanguageText_it.ResourceManager.GetString("Error1304", LanguageText_it.resourceCulture);

		internal static string Error1305 => LanguageText_it.ResourceManager.GetString("Error1305", LanguageText_it.resourceCulture);

		internal static string Error1400 => LanguageText_it.ResourceManager.GetString("Error1400", LanguageText_it.resourceCulture);

		internal static string Error1401 => LanguageText_it.ResourceManager.GetString("Error1401", LanguageText_it.resourceCulture);

		internal static string Error1402 => LanguageText_it.ResourceManager.GetString("Error1402", LanguageText_it.resourceCulture);

		internal static string Error1403 => LanguageText_it.ResourceManager.GetString("Error1403", LanguageText_it.resourceCulture);

		internal static string Error1404 => LanguageText_it.ResourceManager.GetString("Error1404", LanguageText_it.resourceCulture);

		internal static string Error1405 => LanguageText_it.ResourceManager.GetString("Error1405", LanguageText_it.resourceCulture);

		internal static string Error1406 => LanguageText_it.ResourceManager.GetString("Error1406", LanguageText_it.resourceCulture);

		internal static string Error1407 => LanguageText_it.ResourceManager.GetString("Error1407", LanguageText_it.resourceCulture);

		internal static string Error1450 => LanguageText_it.ResourceManager.GetString("Error1450", LanguageText_it.resourceCulture);

		internal static string Error1451 => LanguageText_it.ResourceManager.GetString("Error1451", LanguageText_it.resourceCulture);

		internal static string Error1600 => LanguageText_it.ResourceManager.GetString("Error1600", LanguageText_it.resourceCulture);

		internal static string Error1601 => LanguageText_it.ResourceManager.GetString("Error1601", LanguageText_it.resourceCulture);

		internal static string Error1602 => LanguageText_it.ResourceManager.GetString("Error1602", LanguageText_it.resourceCulture);

		internal static string Error2000 => LanguageText_it.ResourceManager.GetString("Error2000", LanguageText_it.resourceCulture);

		internal static string Error2001 => LanguageText_it.ResourceManager.GetString("Error2001", LanguageText_it.resourceCulture);

		internal static string Error2002 => LanguageText_it.ResourceManager.GetString("Error2002", LanguageText_it.resourceCulture);

		internal static string Error2003 => LanguageText_it.ResourceManager.GetString("Error2003", LanguageText_it.resourceCulture);

		internal static string Error2004 => LanguageText_it.ResourceManager.GetString("Error2004", LanguageText_it.resourceCulture);

		internal static string Error2005 => LanguageText_it.ResourceManager.GetString("Error2005", LanguageText_it.resourceCulture);

		internal static string Error2006 => LanguageText_it.ResourceManager.GetString("Error2006", LanguageText_it.resourceCulture);

		internal static string Error2007 => LanguageText_it.ResourceManager.GetString("Error2007", LanguageText_it.resourceCulture);

		internal static string Error2008 => LanguageText_it.ResourceManager.GetString("Error2008", LanguageText_it.resourceCulture);

		internal static string Error2009 => LanguageText_it.ResourceManager.GetString("Error2009", LanguageText_it.resourceCulture);

		internal static string Error2010 => LanguageText_it.ResourceManager.GetString("Error2010", LanguageText_it.resourceCulture);

		internal static string Error2011 => LanguageText_it.ResourceManager.GetString("Error2011", LanguageText_it.resourceCulture);

		internal static string Error2012 => LanguageText_it.ResourceManager.GetString("Error2012", LanguageText_it.resourceCulture);

		internal static string Error2013 => LanguageText_it.ResourceManager.GetString("Error2013", LanguageText_it.resourceCulture);

		internal static string Error2014 => LanguageText_it.ResourceManager.GetString("Error2014", LanguageText_it.resourceCulture);

		internal static string Error2015 => LanguageText_it.ResourceManager.GetString("Error2015", LanguageText_it.resourceCulture);

		internal static string Error2016 => LanguageText_it.ResourceManager.GetString("Error2016", LanguageText_it.resourceCulture);

		internal static string Error2017 => LanguageText_it.ResourceManager.GetString("Error2017", LanguageText_it.resourceCulture);

		internal static string Error2018 => LanguageText_it.ResourceManager.GetString("Error2018", LanguageText_it.resourceCulture);

		internal static string Error2019 => LanguageText_it.ResourceManager.GetString("Error2019", LanguageText_it.resourceCulture);

		internal static string Error2020 => LanguageText_it.ResourceManager.GetString("Error2020", LanguageText_it.resourceCulture);

		internal static string Error2021 => LanguageText_it.ResourceManager.GetString("Error2021", LanguageText_it.resourceCulture);

		internal static string Error2022 => LanguageText_it.ResourceManager.GetString("Error2022", LanguageText_it.resourceCulture);

		internal static string Error2100 => LanguageText_it.ResourceManager.GetString("Error2100", LanguageText_it.resourceCulture);

		internal static string Error5000 => LanguageText_it.ResourceManager.GetString("Error5000", LanguageText_it.resourceCulture);

		internal static string ErrorCode => LanguageText_it.ResourceManager.GetString("ErrorCode", LanguageText_it.resourceCulture);

		internal static string ErrorLog => LanguageText_it.ResourceManager.GetString("ErrorLog", LanguageText_it.resourceCulture);

		internal static string ErrorMode => LanguageText_it.ResourceManager.GetString("ErrorMode", LanguageText_it.resourceCulture);

		internal static string ErrorNumber => LanguageText_it.ResourceManager.GetString("ErrorNumber", LanguageText_it.resourceCulture);

		internal static string ErrorQuitEMG => LanguageText_it.ResourceManager.GetString("ErrorQuitEMG", LanguageText_it.resourceCulture);

		internal static string EuropeanTime => LanguageText_it.ResourceManager.GetString("EuropeanTime", LanguageText_it.resourceCulture);

		internal static string Even => LanguageText_it.ResourceManager.GetString("Even", LanguageText_it.resourceCulture);

		internal static string Exit => LanguageText_it.ResourceManager.GetString("Exit", LanguageText_it.resourceCulture);

		internal static string Export => LanguageText_it.ResourceManager.GetString("Export", LanguageText_it.resourceCulture);

		internal static string ExportLastResults => LanguageText_it.ResourceManager.GetString("ExportLastResults", LanguageText_it.resourceCulture);

		internal static string ExportLogbook => LanguageText_it.ResourceManager.GetString("ExportLogbook", LanguageText_it.resourceCulture);

		internal static string FileOperation => LanguageText_it.ResourceManager.GetString("FileOperation", LanguageText_it.resourceCulture);

		internal static string FileOperationMenu => LanguageText_it.ResourceManager.GetString("FileOperationMenu", LanguageText_it.resourceCulture);

		internal static string FilteredTorque => LanguageText_it.ResourceManager.GetString("FilteredTorque", LanguageText_it.resourceCulture);

		internal static string Finalizing => LanguageText_it.ResourceManager.GetString("Finalizing", LanguageText_it.resourceCulture);

		internal static string FinalizingStep => LanguageText_it.ResourceManager.GetString("FinalizingStep", LanguageText_it.resourceCulture);

		internal static string ForceSignals => LanguageText_it.ResourceManager.GetString("ForceSignals", LanguageText_it.resourceCulture);

		internal static string French => LanguageText_it.ResourceManager.GetString("French", LanguageText_it.resourceCulture);

		internal static string FrictionSpeed => LanguageText_it.ResourceManager.GetString("FrictionSpeed", LanguageText_it.resourceCulture);

		internal static string FrictionTest => LanguageText_it.ResourceManager.GetString("FrictionTest", LanguageText_it.resourceCulture);

		internal static string FrictionTestEMG => LanguageText_it.ResourceManager.GetString("FrictionTestEMG", LanguageText_it.resourceCulture);

		internal static string FrictionTestStartup => LanguageText_it.ResourceManager.GetString("FrictionTestStartup", LanguageText_it.resourceCulture);

		internal static string FrictionTorque => LanguageText_it.ResourceManager.GetString("FrictionTorque", LanguageText_it.resourceCulture);

		internal static string FromAbove => LanguageText_it.ResourceManager.GetString("FromAbove", LanguageText_it.resourceCulture);

		internal static string FromAboveOverload => LanguageText_it.ResourceManager.GetString("FromAboveOverload", LanguageText_it.resourceCulture);

		internal static string gBAnaSignal => LanguageText_it.ResourceManager.GetString("gBAnaSignal", LanguageText_it.resourceCulture);

		internal static string gBDateTime => LanguageText_it.ResourceManager.GetString("gBDateTime", LanguageText_it.resourceCulture);

		internal static string gBError => LanguageText_it.ResourceManager.GetString("gBError", LanguageText_it.resourceCulture);

		internal static string gBIdentity => LanguageText_it.ResourceManager.GetString("gBIdentity", LanguageText_it.resourceCulture);

		internal static string gBIP => LanguageText_it.ResourceManager.GetString("gBIP", LanguageText_it.resourceCulture);

		internal static string gBLoadBackup => LanguageText_it.ResourceManager.GetString("gBLoadBackup", LanguageText_it.resourceCulture);

		internal static string gBPressure => LanguageText_it.ResourceManager.GetString("gBPressure", LanguageText_it.resourceCulture);

		internal static string gBRedundantSensor => LanguageText_it.ResourceManager.GetString("gBRedundantSensor", LanguageText_it.resourceCulture);

		internal static string gBResultDisplay => LanguageText_it.ResourceManager.GetString("gBResultDisplay", LanguageText_it.resourceCulture);

		internal static string gBRs232 => LanguageText_it.ResourceManager.GetString("gBRs232", LanguageText_it.resourceCulture);

		internal static string gBSaveBackup => LanguageText_it.ResourceManager.GetString("gBSaveBackup", LanguageText_it.resourceCulture);

		internal static string gBSpindle => LanguageText_it.ResourceManager.GetString("gBSpindle", LanguageText_it.resourceCulture);

		internal static string GearFactor => LanguageText_it.ResourceManager.GetString("GearFactor", LanguageText_it.resourceCulture);

		internal static string German => LanguageText_it.ResourceManager.GetString("German", LanguageText_it.resourceCulture);

		internal static string GetCurve => LanguageText_it.ResourceManager.GetString("GetCurve", LanguageText_it.resourceCulture);

		internal static string GetRpm => LanguageText_it.ResourceManager.GetString("GetRpm", LanguageText_it.resourceCulture);

		internal static string GoWithoutPassCode => LanguageText_it.ResourceManager.GetString("GoWithoutPassCode", LanguageText_it.resourceCulture);

		internal static string GradFilter => LanguageText_it.ResourceManager.GetString("GradFilter", LanguageText_it.resourceCulture);

		internal static string Gradient => LanguageText_it.ResourceManager.GetString("Gradient", LanguageText_it.resourceCulture);

		internal static string GradientLength => LanguageText_it.ResourceManager.GetString("GradientLength", LanguageText_it.resourceCulture);

		internal static string HandMode => LanguageText_it.ResourceManager.GetString("HandMode", LanguageText_it.resourceCulture);

		internal static string HandStart => LanguageText_it.ResourceManager.GetString("HandStart", LanguageText_it.resourceCulture);

		internal static string HandStartIsInitiated => LanguageText_it.ResourceManager.GetString("HandStartIsInitiated", LanguageText_it.resourceCulture);

		internal static string Help => LanguageText_it.ResourceManager.GetString("Help", LanguageText_it.resourceCulture);

		internal static string HexSwitch => LanguageText_it.ResourceManager.GetString("HexSwitch", LanguageText_it.resourceCulture);

		internal static string Hold => LanguageText_it.ResourceManager.GetString("Hold", LanguageText_it.resourceCulture);

		internal static string Holder => LanguageText_it.ResourceManager.GetString("Holder", LanguageText_it.resourceCulture);

		internal static string HolderPressureScale => LanguageText_it.ResourceManager.GetString("HolderPressureScale", LanguageText_it.resourceCulture);

		internal static string IdentServer => LanguageText_it.ResourceManager.GetString("IdentServer", LanguageText_it.resourceCulture);

		internal static string Increment => LanguageText_it.ResourceManager.GetString("Increment", LanguageText_it.resourceCulture);

		internal static string Inputs => LanguageText_it.ResourceManager.GetString("Inputs", LanguageText_it.resourceCulture);

		internal static string InsertProgram => LanguageText_it.ResourceManager.GetString("InsertProgram", LanguageText_it.resourceCulture);

		internal static string InsertStep => LanguageText_it.ResourceManager.GetString("InsertStep", LanguageText_it.resourceCulture);

		internal static string IntegratedTests => LanguageText_it.ResourceManager.GetString("IntegratedTests", LanguageText_it.resourceCulture);

		internal static string IONumber => LanguageText_it.ResourceManager.GetString("IONumber", LanguageText_it.resourceCulture);

		internal static string IOTest => LanguageText_it.ResourceManager.GetString("IOTest", LanguageText_it.resourceCulture);

		internal static string IPAddress => LanguageText_it.ResourceManager.GetString("IPAddress", LanguageText_it.resourceCulture);

		internal static string Italian => LanguageText_it.ResourceManager.GetString("Italian", LanguageText_it.resourceCulture);

		internal static string JumpAlwaysTo => LanguageText_it.ResourceManager.GetString("JumpAlwaysTo", LanguageText_it.resourceCulture);

		internal static string JumpNokTo => LanguageText_it.ResourceManager.GetString("JumpNokTo", LanguageText_it.resourceCulture);

		internal static string JumpOkTo => LanguageText_it.ResourceManager.GetString("JumpOkTo", LanguageText_it.resourceCulture);

		internal static string JumpTo => LanguageText_it.ResourceManager.GetString("JumpTo", LanguageText_it.resourceCulture);

		internal static string KeyPad => LanguageText_it.ResourceManager.GetString("KeyPad", LanguageText_it.resourceCulture);

		internal static string Kind => LanguageText_it.ResourceManager.GetString("Kind", LanguageText_it.resourceCulture);

		internal static string Language => LanguageText_it.ResourceManager.GetString("Language", LanguageText_it.resourceCulture);

		internal static string LastDoneStep => LanguageText_it.ResourceManager.GetString("LastDoneStep", LanguageText_it.resourceCulture);

		internal static string LastNIO => LanguageText_it.ResourceManager.GetString("LastNIO", LanguageText_it.resourceCulture);

		internal static string LastResults => LanguageText_it.ResourceManager.GetString("LastResults", LanguageText_it.resourceCulture);

		internal static string LeftAngle => LanguageText_it.ResourceManager.GetString("LeftAngle", LanguageText_it.resourceCulture);

		internal static string LevelAdministrator => LanguageText_it.ResourceManager.GetString("LevelAdministrator", LanguageText_it.resourceCulture);

		internal static string LevelProgramer => LanguageText_it.ResourceManager.GetString("LevelProgramer", LanguageText_it.resourceCulture);

		internal static string LevelUser => LanguageText_it.ResourceManager.GetString("LevelUser", LanguageText_it.resourceCulture);

		internal static string LivingMonitor => LanguageText_it.ResourceManager.GetString("LivingMonitor", LanguageText_it.resourceCulture);

		internal static string LivingSign => LanguageText_it.ResourceManager.GetString("LivingSign", LanguageText_it.resourceCulture);

		internal static string LoadCurveData => LanguageText_it.ResourceManager.GetString("LoadCurveData", LanguageText_it.resourceCulture);

		internal static string LoadCurveDataFromFile => LanguageText_it.ResourceManager.GetString("LoadCurveDataFromFile", LanguageText_it.resourceCulture);

		internal static string LoadCustBackup => LanguageText_it.ResourceManager.GetString("LoadCustBackup", LanguageText_it.resourceCulture);

		internal static string LoadCustBackupFromCF => LanguageText_it.ResourceManager.GetString("LoadCustBackupFromCF", LanguageText_it.resourceCulture);

		internal static string LoadCustBackupSecQuery => LanguageText_it.ResourceManager.GetString("LoadCustBackupSecQuery", LanguageText_it.resourceCulture);

		internal static string LoadCycleCount => LanguageText_it.ResourceManager.GetString("LoadCycleCount", LanguageText_it.resourceCulture);

		internal static string LoadFromFile => LanguageText_it.ResourceManager.GetString("LoadFromFile", LanguageText_it.resourceCulture);

		internal static string LoadIO => LanguageText_it.ResourceManager.GetString("LoadIO", LanguageText_it.resourceCulture);

		internal static string LoadLastNIOResults => LanguageText_it.ResourceManager.GetString("LoadLastNIOResults", LanguageText_it.resourceCulture);

		internal static string LoadLastResults => LanguageText_it.ResourceManager.GetString("LoadLastResults", LanguageText_it.resourceCulture);

		internal static string LoadLogBookData => LanguageText_it.ResourceManager.GetString("LoadLogBookData", LanguageText_it.resourceCulture);

		internal static string LoadPLCIO => LanguageText_it.ResourceManager.GetString("LoadPLCIO", LanguageText_it.resourceCulture);

		internal static string LoadPProgFromFile => LanguageText_it.ResourceManager.GetString("LoadPProgFromFile", LanguageText_it.resourceCulture);

		internal static string LoadProcessInfo => LanguageText_it.ResourceManager.GetString("LoadProcessInfo", LanguageText_it.resourceCulture);

		internal static string LoadProgramData => LanguageText_it.ResourceManager.GetString("LoadProgramData", LanguageText_it.resourceCulture);

		internal static string LoadProgramDataLocally => LanguageText_it.ResourceManager.GetString("LoadProgramDataLocally", LanguageText_it.resourceCulture);

		internal static string LoadRecursiveStat => LanguageText_it.ResourceManager.GetString("LoadRecursiveStat", LanguageText_it.resourceCulture);

		internal static string LoadResults => LanguageText_it.ResourceManager.GetString("LoadResults", LanguageText_it.resourceCulture);

		internal static string LoadSingleProgFromFile => LanguageText_it.ResourceManager.GetString("LoadSingleProgFromFile", LanguageText_it.resourceCulture);

		internal static string LoadSpindleConst => LanguageText_it.ResourceManager.GetString("LoadSpindleConst", LanguageText_it.resourceCulture);

		internal static string LoadSpindleDataLocally => LanguageText_it.ResourceManager.GetString("LoadSpindleDataLocally", LanguageText_it.resourceCulture);

		internal static string LoadSystemConst => LanguageText_it.ResourceManager.GetString("LoadSystemConst", LanguageText_it.resourceCulture);

		internal static string LoadWebBackupSecQuery => LanguageText_it.ResourceManager.GetString("LoadWebBackupSecQuery", LanguageText_it.resourceCulture);

		internal static string LoadWeberBackup => LanguageText_it.ResourceManager.GetString("LoadWeberBackup", LanguageText_it.resourceCulture);

		internal static string LoadWeberBackupFromCF => LanguageText_it.ResourceManager.GetString("LoadWeberBackupFromCF", LanguageText_it.resourceCulture);

		internal static string LocalTime => LanguageText_it.ResourceManager.GetString("LocalTime", LanguageText_it.resourceCulture);

		internal static string LogBook => LanguageText_it.ResourceManager.GetString("LogBook", LanguageText_it.resourceCulture);

		internal static string LogBookMessage100000 => LanguageText_it.ResourceManager.GetString("LogBookMessage100000", LanguageText_it.resourceCulture);

		internal static string LogBookMessage200000 => LanguageText_it.ResourceManager.GetString("LogBookMessage200000", LanguageText_it.resourceCulture);

		internal static string LogBookMessage300000 => LanguageText_it.ResourceManager.GetString("LogBookMessage300000", LanguageText_it.resourceCulture);

		internal static string LogBookMessage300001 => LanguageText_it.ResourceManager.GetString("LogBookMessage300001", LanguageText_it.resourceCulture);

		internal static string LogBookTable => LanguageText_it.ResourceManager.GetString("LogBookTable", LanguageText_it.resourceCulture);

		internal static string Login => LanguageText_it.ResourceManager.GetString("Login", LanguageText_it.resourceCulture);

		internal static string LowerLimit => LanguageText_it.ResourceManager.GetString("LowerLimit", LanguageText_it.resourceCulture);

		internal static string M1FilterTime => LanguageText_it.ResourceManager.GetString("M1FilterTime", LanguageText_it.resourceCulture);

		internal static string M360Follow => LanguageText_it.ResourceManager.GetString("M360Follow", LanguageText_it.resourceCulture);

		internal static string MachineCounter => LanguageText_it.ResourceManager.GetString("MachineCounter", LanguageText_it.resourceCulture);

		internal static string MachineVisu => LanguageText_it.ResourceManager.GetString("MachineVisu", LanguageText_it.resourceCulture);

		internal static string MakeNewEntry => LanguageText_it.ResourceManager.GetString("MakeNewEntry", LanguageText_it.resourceCulture);

		internal static string Max => LanguageText_it.ResourceManager.GetString("Max", LanguageText_it.resourceCulture);

		internal static string MaxFrictionTorque => LanguageText_it.ResourceManager.GetString("MaxFrictionTorque", LanguageText_it.resourceCulture);

		internal static string MaxRpm => LanguageText_it.ResourceManager.GetString("MaxRpm", LanguageText_it.resourceCulture);

		internal static string MaxSaveCurveNum => LanguageText_it.ResourceManager.GetString("MaxSaveCurveNum", LanguageText_it.resourceCulture);

		internal static string MaxScrewTime => LanguageText_it.ResourceManager.GetString("MaxScrewTime", LanguageText_it.resourceCulture);

		internal static string MaxTorque => LanguageText_it.ResourceManager.GetString("MaxTorque", LanguageText_it.resourceCulture);

		internal static string MbAccessByAnother => LanguageText_it.ResourceManager.GetString("MbAccessByAnother", LanguageText_it.resourceCulture);

		internal static string MbAccessNotPossible => LanguageText_it.ResourceManager.GetString("MbAccessNotPossible", LanguageText_it.resourceCulture);

		internal static string MbAccessRequestTwice => LanguageText_it.ResourceManager.GetString("MbAccessRequestTwice", LanguageText_it.resourceCulture);

		internal static string MBackup => LanguageText_it.ResourceManager.GetString("MBackup", LanguageText_it.resourceCulture);

		internal static string MbAddNoFrictionTest => LanguageText_it.ResourceManager.GetString("MbAddNoFrictionTest", LanguageText_it.resourceCulture);

		internal static string MbAddNoManual => LanguageText_it.ResourceManager.GetString("MbAddNoManual", LanguageText_it.resourceCulture);

		internal static string MbAddNoTest => LanguageText_it.ResourceManager.GetString("MbAddNoTest", LanguageText_it.resourceCulture);

		internal static string MbAddParamViewOnly => LanguageText_it.ResourceManager.GetString("MbAddParamViewOnly", LanguageText_it.resourceCulture);

		internal static string MbAutomaticIsActive1 => LanguageText_it.ResourceManager.GetString("MbAutomaticIsActive1", LanguageText_it.resourceCulture);

		internal static string MbAutomaticIsActive2 => LanguageText_it.ResourceManager.GetString("MbAutomaticIsActive2", LanguageText_it.resourceCulture);

		internal static string MbComandTimeOut => LanguageText_it.ResourceManager.GetString("MbComandTimeOut", LanguageText_it.resourceCulture);

		internal static string MbCreateDefaultPasscode => LanguageText_it.ResourceManager.GetString("MbCreateDefaultPasscode", LanguageText_it.resourceCulture);

		internal static string MbCurveLoadFailure => LanguageText_it.ResourceManager.GetString("MbCurveLoadFailure", LanguageText_it.resourceCulture);

		internal static string MbCurveSaveFailure => LanguageText_it.ResourceManager.GetString("MbCurveSaveFailure", LanguageText_it.resourceCulture);

		internal static string MbDeleteCounterFailure => LanguageText_it.ResourceManager.GetString("MbDeleteCounterFailure", LanguageText_it.resourceCulture);

		internal static string MbDeleteCustomCounter => LanguageText_it.ResourceManager.GetString("MbDeleteCustomCounter", LanguageText_it.resourceCulture);

		internal static string MbDeleteLastResFailure => LanguageText_it.ResourceManager.GetString("MbDeleteLastResFailure", LanguageText_it.resourceCulture);

		internal static string MbDeleteLastResults => LanguageText_it.ResourceManager.GetString("MbDeleteLastResults", LanguageText_it.resourceCulture);

		internal static string MbDeleteProg => LanguageText_it.ResourceManager.GetString("MbDeleteProg", LanguageText_it.resourceCulture);

		internal static string MbDeleteRecStatFailure => LanguageText_it.ResourceManager.GetString("MbDeleteRecStatFailure", LanguageText_it.resourceCulture);

		internal static string MbDeleteRecursiveStat => LanguageText_it.ResourceManager.GetString("MbDeleteRecursiveStat", LanguageText_it.resourceCulture);

		internal static string MbDeleteStatAfterProgChange => LanguageText_it.ResourceManager.GetString("MbDeleteStatAfterProgChange", LanguageText_it.resourceCulture);

		internal static string MbDoubleEntryCodeFound => LanguageText_it.ResourceManager.GetString("MbDoubleEntryCodeFound", LanguageText_it.resourceCulture);

		internal static string MbEmptyProgram => LanguageText_it.ResourceManager.GetString("MbEmptyProgram", LanguageText_it.resourceCulture);

		internal static string MbErrorQuitFailure => LanguageText_it.ResourceManager.GetString("MbErrorQuitFailure", LanguageText_it.resourceCulture);

		internal static string MbExit => LanguageText_it.ResourceManager.GetString("MbExit", LanguageText_it.resourceCulture);

		internal static string MbGotNoConnection => LanguageText_it.ResourceManager.GetString("MbGotNoConnection", LanguageText_it.resourceCulture);

		internal static string MbHandstartIsActive => LanguageText_it.ResourceManager.GetString("MbHandstartIsActive", LanguageText_it.resourceCulture);

		internal static string MbHandstartNotTwice => LanguageText_it.ResourceManager.GetString("MbHandstartNotTwice", LanguageText_it.resourceCulture);

		internal static string MbhError => LanguageText_it.ResourceManager.GetString("MbhError", LanguageText_it.resourceCulture);

		internal static string MbhHint => LanguageText_it.ResourceManager.GetString("MbhHint", LanguageText_it.resourceCulture);

		internal static string MbhNoAccess => LanguageText_it.ResourceManager.GetString("MbhNoAccess", LanguageText_it.resourceCulture);

		internal static string MbhSecurityQuery => LanguageText_it.ResourceManager.GetString("MbhSecurityQuery", LanguageText_it.resourceCulture);

		internal static string MbhViewOnlyMode => LanguageText_it.ResourceManager.GetString("MbhViewOnlyMode", LanguageText_it.resourceCulture);

		internal static string MbIPChange => LanguageText_it.ResourceManager.GetString("MbIPChange", LanguageText_it.resourceCulture);

		internal static string MbKeyLockActive => LanguageText_it.ResourceManager.GetString("MbKeyLockActive", LanguageText_it.resourceCulture);

		internal static string MbLoadCustBackupFailure => LanguageText_it.ResourceManager.GetString("MbLoadCustBackupFailure", LanguageText_it.resourceCulture);

		internal static string MbLoadWeberBackupFailure => LanguageText_it.ResourceManager.GetString("MbLoadWeberBackupFailure", LanguageText_it.resourceCulture);

		internal static string MbLocationError => LanguageText_it.ResourceManager.GetString("MbLocationError", LanguageText_it.resourceCulture);

		internal static string MbLogbookWriteFailure => LanguageText_it.ResourceManager.GetString("MbLogbookWriteFailure", LanguageText_it.resourceCulture);

		internal static string MbMaxPasscodeNum1 => LanguageText_it.ResourceManager.GetString("MbMaxPasscodeNum1", LanguageText_it.resourceCulture);

		internal static string MbMaxPasscodeNum2 => LanguageText_it.ResourceManager.GetString("MbMaxPasscodeNum2", LanguageText_it.resourceCulture);

		internal static string MbNoAccess => LanguageText_it.ResourceManager.GetString("MbNoAccess", LanguageText_it.resourceCulture);

		internal static string MbNoAccessCauseAuto => LanguageText_it.ResourceManager.GetString("MbNoAccessCauseAuto", LanguageText_it.resourceCulture);

		internal static string MbNoConnection => LanguageText_it.ResourceManager.GetString("MbNoConnection", LanguageText_it.resourceCulture);

		internal static string MbNoTestCauseAuto => LanguageText_it.ResourceManager.GetString("MbNoTestCauseAuto", LanguageText_it.resourceCulture);

		internal static string MbOfflineMode => LanguageText_it.ResourceManager.GetString("MbOfflineMode", LanguageText_it.resourceCulture);

		internal static string MbOldPProgLoad => LanguageText_it.ResourceManager.GetString("MbOldPProgLoad", LanguageText_it.resourceCulture);

		internal static string MbOldProgLoad => LanguageText_it.ResourceManager.GetString("MbOldProgLoad", LanguageText_it.resourceCulture);

		internal static string MbOverwriteProg => LanguageText_it.ResourceManager.GetString("MbOverwriteProg", LanguageText_it.resourceCulture);

		internal static string MbPasscodeFailure1 => LanguageText_it.ResourceManager.GetString("MbPasscodeFailure1", LanguageText_it.resourceCulture);

		internal static string MbPasscodeFailure2 => LanguageText_it.ResourceManager.GetString("MbPasscodeFailure2", LanguageText_it.resourceCulture);

		internal static string MbPasscodeFailure3 => LanguageText_it.ResourceManager.GetString("MbPasscodeFailure3", LanguageText_it.resourceCulture);

		internal static string MbPasscodeFailure4 => LanguageText_it.ResourceManager.GetString("MbPasscodeFailure4", LanguageText_it.resourceCulture);

		internal static string MbPProgCopyFailure => LanguageText_it.ResourceManager.GetString("MbPProgCopyFailure", LanguageText_it.resourceCulture);

		internal static string MbPProgLoadFromFileFailure => LanguageText_it.ResourceManager.GetString("MbPProgLoadFromFileFailure", LanguageText_it.resourceCulture);

		internal static string MbPProgSaveToFileFailure => LanguageText_it.ResourceManager.GetString("MbPProgSaveToFileFailure", LanguageText_it.resourceCulture);

		internal static string MbProgramCopyFailure => LanguageText_it.ResourceManager.GetString("MbProgramCopyFailure", LanguageText_it.resourceCulture);

		internal static string MbProgramEmptySaveAnyway => LanguageText_it.ResourceManager.GetString("MbProgramEmptySaveAnyway", LanguageText_it.resourceCulture);

		internal static string MbSaveCustBackupFailure => LanguageText_it.ResourceManager.GetString("MbSaveCustBackupFailure", LanguageText_it.resourceCulture);

		internal static string MbSaveDataLocally => LanguageText_it.ResourceManager.GetString("MbSaveDataLocally", LanguageText_it.resourceCulture);

		internal static string MbSavedProgramDataToFile => LanguageText_it.ResourceManager.GetString("MbSavedProgramDataToFile", LanguageText_it.resourceCulture);

		internal static string MbSavedSpindleDataToFile => LanguageText_it.ResourceManager.GetString("MbSavedSpindleDataToFile", LanguageText_it.resourceCulture);

		internal static string MbSaveNotVerifiedData => LanguageText_it.ResourceManager.GetString("MbSaveNotVerifiedData", LanguageText_it.resourceCulture);

		internal static string MbSavePasscodeFailure => LanguageText_it.ResourceManager.GetString("MbSavePasscodeFailure", LanguageText_it.resourceCulture);

		internal static string MbSaveProgFailure => LanguageText_it.ResourceManager.GetString("MbSaveProgFailure", LanguageText_it.resourceCulture);

		internal static string MbSaveProgOnCPUFailure => LanguageText_it.ResourceManager.GetString("MbSaveProgOnCPUFailure", LanguageText_it.resourceCulture);

		internal static string MbSaveSpConstFailure => LanguageText_it.ResourceManager.GetString("MbSaveSpConstFailure", LanguageText_it.resourceCulture);

		internal static string MbSaveSysConstFailure => LanguageText_it.ResourceManager.GetString("MbSaveSysConstFailure", LanguageText_it.resourceCulture);

		internal static string MbSaveWeberBackupFailure => LanguageText_it.ResourceManager.GetString("MbSaveWeberBackupFailure", LanguageText_it.resourceCulture);

		internal static string MbShortNameFailure1 => LanguageText_it.ResourceManager.GetString("MbShortNameFailure1", LanguageText_it.resourceCulture);

		internal static string MbShortNameFailure2 => LanguageText_it.ResourceManager.GetString("MbShortNameFailure2", LanguageText_it.resourceCulture);

		internal static string MbShortNameFailure3 => LanguageText_it.ResourceManager.GetString("MbShortNameFailure3", LanguageText_it.resourceCulture);

		internal static string MbSpindleCopyFailure => LanguageText_it.ResourceManager.GetString("MbSpindleCopyFailure", LanguageText_it.resourceCulture);

		internal static string MbSpindleLoadFromFileFailure => LanguageText_it.ResourceManager.GetString("MbSpindleLoadFromFileFailure", LanguageText_it.resourceCulture);

		internal static string MbSpindleSaveToFileFailure => LanguageText_it.ResourceManager.GetString("MbSpindleSaveToFileFailure", LanguageText_it.resourceCulture);

		internal static string MbStepCopyFailure => LanguageText_it.ResourceManager.GetString("MbStepCopyFailure", LanguageText_it.resourceCulture);

		internal static string MbWrongPassword => LanguageText_it.ResourceManager.GetString("MbWrongPassword", LanguageText_it.resourceCulture);

		internal static string MCheckParameter => LanguageText_it.ResourceManager.GetString("MCheckParameter", LanguageText_it.resourceCulture);

		internal static string MCurveDisplay => LanguageText_it.ResourceManager.GetString("MCurveDisplay", LanguageText_it.resourceCulture);

		internal static string MCurveSelection => LanguageText_it.ResourceManager.GetString("MCurveSelection", LanguageText_it.resourceCulture);

		internal static string MCycleCounter => LanguageText_it.ResourceManager.GetString("MCycleCounter", LanguageText_it.resourceCulture);

		internal static string MDelay => LanguageText_it.ResourceManager.GetString("MDelay", LanguageText_it.resourceCulture);

		internal static string Mean => LanguageText_it.ResourceManager.GetString("Mean", LanguageText_it.resourceCulture);

		internal static string MEditStep => LanguageText_it.ResourceManager.GetString("MEditStep", LanguageText_it.resourceCulture);

		internal static string MenuAnalysis => LanguageText_it.ResourceManager.GetString("MenuAnalysis", LanguageText_it.resourceCulture);

		internal static string MenuParameter => LanguageText_it.ResourceManager.GetString("MenuParameter", LanguageText_it.resourceCulture);

		internal static string MenuStatistics => LanguageText_it.ResourceManager.GetString("MenuStatistics", LanguageText_it.resourceCulture);

		internal static string MenuTest => LanguageText_it.ResourceManager.GetString("MenuTest", LanguageText_it.resourceCulture);

		internal static string Message => LanguageText_it.ResourceManager.GetString("Message", LanguageText_it.resourceCulture);

		internal static string MHandStart => LanguageText_it.ResourceManager.GetString("MHandStart", LanguageText_it.resourceCulture);

		internal static string Milimeter => LanguageText_it.ResourceManager.GetString("Milimeter", LanguageText_it.resourceCulture);

		internal static string Milisecond => LanguageText_it.ResourceManager.GetString("Milisecond", LanguageText_it.resourceCulture);

		internal static string Min => LanguageText_it.ResourceManager.GetString("Min", LanguageText_it.resourceCulture);

		internal static string MiniDisplay => LanguageText_it.ResourceManager.GetString("MiniDisplay", LanguageText_it.resourceCulture);

		internal static string Minimize => LanguageText_it.ResourceManager.GetString("Minimize", LanguageText_it.resourceCulture);

		internal static string MLastNIO => LanguageText_it.ResourceManager.GetString("MLastNIO", LanguageText_it.resourceCulture);

		internal static string MLogBook => LanguageText_it.ResourceManager.GetString("MLogBook", LanguageText_it.resourceCulture);

		internal static string MOptPrgParam => LanguageText_it.ResourceManager.GetString("MOptPrgParam", LanguageText_it.resourceCulture);

		internal static string Motor => LanguageText_it.ResourceManager.GetString("Motor", LanguageText_it.resourceCulture);

		internal static string MPasscodeManager => LanguageText_it.ResourceManager.GetString("MPasscodeManager", LanguageText_it.resourceCulture);

		internal static string MPrintSelection => LanguageText_it.ResourceManager.GetString("MPrintSelection", LanguageText_it.resourceCulture);

		internal static string MProgramOverview => LanguageText_it.ResourceManager.GetString("MProgramOverview", LanguageText_it.resourceCulture);

		internal static string MSpindleConstants => LanguageText_it.ResourceManager.GetString("MSpindleConstants", LanguageText_it.resourceCulture);

		internal static string MStepOverview => LanguageText_it.ResourceManager.GetString("MStepOverview", LanguageText_it.resourceCulture);

		internal static string MStepResults => LanguageText_it.ResourceManager.GetString("MStepResults", LanguageText_it.resourceCulture);

		internal static string MSystemConstants => LanguageText_it.ResourceManager.GetString("MSystemConstants", LanguageText_it.resourceCulture);

		internal static string MVisualisationParam => LanguageText_it.ResourceManager.GetString("MVisualisationParam", LanguageText_it.resourceCulture);

		internal static string Name => LanguageText_it.ResourceManager.GetString("Name", LanguageText_it.resourceCulture);

		internal static string Negative => LanguageText_it.ResourceManager.GetString("Negative", LanguageText_it.resourceCulture);

		internal static string NegOverload => LanguageText_it.ResourceManager.GetString("NegOverload", LanguageText_it.resourceCulture);

		internal static string NewEntry => LanguageText_it.ResourceManager.GetString("NewEntry", LanguageText_it.resourceCulture);

		internal static string NewValue => LanguageText_it.ResourceManager.GetString("NewValue", LanguageText_it.resourceCulture);

		internal static string Next50Curves => LanguageText_it.ResourceManager.GetString("Next50Curves", LanguageText_it.resourceCulture);

		internal static string NIO10 => LanguageText_it.ResourceManager.GetString("NIO10", LanguageText_it.resourceCulture);

		internal static string NIO10001 => LanguageText_it.ResourceManager.GetString("NIO10001", LanguageText_it.resourceCulture);

		internal static string NIO10002 => LanguageText_it.ResourceManager.GetString("NIO10002", LanguageText_it.resourceCulture);

		internal static string NIO10003 => LanguageText_it.ResourceManager.GetString("NIO10003", LanguageText_it.resourceCulture);

		internal static string NIO10004 => LanguageText_it.ResourceManager.GetString("NIO10004", LanguageText_it.resourceCulture);

		internal static string NIO11 => LanguageText_it.ResourceManager.GetString("NIO11", LanguageText_it.resourceCulture);

		internal static string NIO110 => LanguageText_it.ResourceManager.GetString("NIO110", LanguageText_it.resourceCulture);

		internal static string NIO12 => LanguageText_it.ResourceManager.GetString("NIO12", LanguageText_it.resourceCulture);

		internal static string NIO13 => LanguageText_it.ResourceManager.GetString("NIO13", LanguageText_it.resourceCulture);

		internal static string NIO30 => LanguageText_it.ResourceManager.GetString("NIO30", LanguageText_it.resourceCulture);

		internal static string NIO31 => LanguageText_it.ResourceManager.GetString("NIO31", LanguageText_it.resourceCulture);

		internal static string NIO40 => LanguageText_it.ResourceManager.GetString("NIO40", LanguageText_it.resourceCulture);

		internal static string NIO41 => LanguageText_it.ResourceManager.GetString("NIO41", LanguageText_it.resourceCulture);

		internal static string NIO50 => LanguageText_it.ResourceManager.GetString("NIO50", LanguageText_it.resourceCulture);

		internal static string NIO51 => LanguageText_it.ResourceManager.GetString("NIO51", LanguageText_it.resourceCulture);

		internal static string NIO60 => LanguageText_it.ResourceManager.GetString("NIO60", LanguageText_it.resourceCulture);

		internal static string NIO61 => LanguageText_it.ResourceManager.GetString("NIO61", LanguageText_it.resourceCulture);

		internal static string NIO70 => LanguageText_it.ResourceManager.GetString("NIO70", LanguageText_it.resourceCulture);

		internal static string NIO71 => LanguageText_it.ResourceManager.GetString("NIO71", LanguageText_it.resourceCulture);

		internal static string NIO75 => LanguageText_it.ResourceManager.GetString("NIO75", LanguageText_it.resourceCulture);

		internal static string NIO76 => LanguageText_it.ResourceManager.GetString("NIO76", LanguageText_it.resourceCulture);

		internal static string NIO80 => LanguageText_it.ResourceManager.GetString("NIO80", LanguageText_it.resourceCulture);

		internal static string NIO81 => LanguageText_it.ResourceManager.GetString("NIO81", LanguageText_it.resourceCulture);

		internal static string NIO90 => LanguageText_it.ResourceManager.GetString("NIO90", LanguageText_it.resourceCulture);

		internal static string NIO91 => LanguageText_it.ResourceManager.GetString("NIO91", LanguageText_it.resourceCulture);

		internal static string NIO92 => LanguageText_it.ResourceManager.GetString("NIO92", LanguageText_it.resourceCulture);

		internal static string NIO93 => LanguageText_it.ResourceManager.GetString("NIO93", LanguageText_it.resourceCulture);

		internal static string NIO94 => LanguageText_it.ResourceManager.GetString("NIO94", LanguageText_it.resourceCulture);

		internal static string NIO95 => LanguageText_it.ResourceManager.GetString("NIO95", LanguageText_it.resourceCulture);

		internal static string NIO96 => LanguageText_it.ResourceManager.GetString("NIO96", LanguageText_it.resourceCulture);

		internal static string NIO97 => LanguageText_it.ResourceManager.GetString("NIO97", LanguageText_it.resourceCulture);

		internal static string NIO98 => LanguageText_it.ResourceManager.GetString("NIO98", LanguageText_it.resourceCulture);

		internal static string NIO99 => LanguageText_it.ResourceManager.GetString("NIO99", LanguageText_it.resourceCulture);

		internal static string NIONumber => LanguageText_it.ResourceManager.GetString("NIONumber", LanguageText_it.resourceCulture);

		internal static string NIOReason => LanguageText_it.ResourceManager.GetString("NIOReason", LanguageText_it.resourceCulture);

		internal static string No => LanguageText_it.ResourceManager.GetString("No", LanguageText_it.resourceCulture);

		internal static string NoData => LanguageText_it.ResourceManager.GetString("NoData", LanguageText_it.resourceCulture);

		internal static string NoErrorMode => LanguageText_it.ResourceManager.GetString("NoErrorMode", LanguageText_it.resourceCulture);

		internal static string NOK => LanguageText_it.ResourceManager.GetString("NOK", LanguageText_it.resourceCulture);

		internal static string None => LanguageText_it.ResourceManager.GetString("None", LanguageText_it.resourceCulture);

		internal static string NoParity => LanguageText_it.ResourceManager.GetString("NoParity", LanguageText_it.resourceCulture);

		internal static string NoSelection => LanguageText_it.ResourceManager.GetString("NoSelection", LanguageText_it.resourceCulture);

		internal static string NoSignal => LanguageText_it.ResourceManager.GetString("NoSignal", LanguageText_it.resourceCulture);

		internal static string NotValid => LanguageText_it.ResourceManager.GetString("NotValid", LanguageText_it.resourceCulture);

		internal static string Number => LanguageText_it.ResourceManager.GetString("Number", LanguageText_it.resourceCulture);

		internal static string NumberPad => LanguageText_it.ResourceManager.GetString("NumberPad", LanguageText_it.resourceCulture);

		internal static string Odd => LanguageText_it.ResourceManager.GetString("Odd", LanguageText_it.resourceCulture);

		internal static string Off => LanguageText_it.ResourceManager.GetString("Off", LanguageText_it.resourceCulture);

		internal static string OfflineMode => LanguageText_it.ResourceManager.GetString("OfflineMode", LanguageText_it.resourceCulture);

		internal static string OffsetTeachValue => LanguageText_it.ResourceManager.GetString("OffsetTeachValue", LanguageText_it.resourceCulture);

		internal static string OffsetVoltageMax => LanguageText_it.ResourceManager.GetString("OffsetVoltageMax", LanguageText_it.resourceCulture);

		internal static string OffsetVoltageMin => LanguageText_it.ResourceManager.GetString("OffsetVoltageMin", LanguageText_it.resourceCulture);

		internal static string OfStep => LanguageText_it.ResourceManager.GetString("OfStep", LanguageText_it.resourceCulture);

		internal static string OK => LanguageText_it.ResourceManager.GetString("OK", LanguageText_it.resourceCulture);

		internal static string OKNOK => LanguageText_it.ResourceManager.GetString("OKNOK", LanguageText_it.resourceCulture);

		internal static string OldValue => LanguageText_it.ResourceManager.GetString("OldValue", LanguageText_it.resourceCulture);

		internal static string On => LanguageText_it.ResourceManager.GetString("On", LanguageText_it.resourceCulture);

		internal static string OnlineMode => LanguageText_it.ResourceManager.GetString("OnlineMode", LanguageText_it.resourceCulture);

		internal static string OnlyIO => LanguageText_it.ResourceManager.GetString("OnlyIO", LanguageText_it.resourceCulture);

		internal static string OptPrgParam => LanguageText_it.ResourceManager.GetString("OptPrgParam", LanguageText_it.resourceCulture);

		internal static string Organisation => LanguageText_it.ResourceManager.GetString("Organisation", LanguageText_it.resourceCulture);

		internal static string OrganizingStep => LanguageText_it.ResourceManager.GetString("OrganizingStep", LanguageText_it.resourceCulture);

		internal static string OutOfRange => LanguageText_it.ResourceManager.GetString("OutOfRange", LanguageText_it.resourceCulture);

		internal static string Outputs => LanguageText_it.ResourceManager.GetString("Outputs", LanguageText_it.resourceCulture);

		internal static string PaintCurve => LanguageText_it.ResourceManager.GetString("PaintCurve", LanguageText_it.resourceCulture);

		internal static string Parity => LanguageText_it.ResourceManager.GetString("Parity", LanguageText_it.resourceCulture);

		internal static string PasscodeLevel => LanguageText_it.ResourceManager.GetString("PasscodeLevel", LanguageText_it.resourceCulture);

		internal static string PasscodeManager => LanguageText_it.ResourceManager.GetString("PasscodeManager", LanguageText_it.resourceCulture);

		internal static string Password => LanguageText_it.ResourceManager.GetString("Password", LanguageText_it.resourceCulture);

		internal static string PasswordInput => LanguageText_it.ResourceManager.GetString("PasswordInput", LanguageText_it.resourceCulture);

		internal static string Percent => LanguageText_it.ResourceManager.GetString("Percent", LanguageText_it.resourceCulture);

		internal static string PLC_IO => LanguageText_it.ResourceManager.GetString("PLC_IO", LanguageText_it.resourceCulture);

		internal static string PointOfTime => LanguageText_it.ResourceManager.GetString("PointOfTime", LanguageText_it.resourceCulture);

		internal static string Positive => LanguageText_it.ResourceManager.GetString("Positive", LanguageText_it.resourceCulture);

		internal static string PosOverload => LanguageText_it.ResourceManager.GetString("PosOverload", LanguageText_it.resourceCulture);

		internal static string PowerEnabled => LanguageText_it.ResourceManager.GetString("PowerEnabled", LanguageText_it.resourceCulture);

		internal static string Pressure => LanguageText_it.ResourceManager.GetString("Pressure", LanguageText_it.resourceCulture);

		internal static string PressureSpindle => LanguageText_it.ResourceManager.GetString("PressureSpindle", LanguageText_it.resourceCulture);

		internal static string Print => LanguageText_it.ResourceManager.GetString("Print", LanguageText_it.resourceCulture);

		internal static string ProcessInputs => LanguageText_it.ResourceManager.GetString("ProcessInputs", LanguageText_it.resourceCulture);

		internal static string ProcessRunning => LanguageText_it.ResourceManager.GetString("ProcessRunning", LanguageText_it.resourceCulture);

		internal static string Program => LanguageText_it.ResourceManager.GetString("Program", LanguageText_it.resourceCulture);

		internal static string ProgramChange201000 => LanguageText_it.ResourceManager.GetString("ProgramChange201000", LanguageText_it.resourceCulture);

		internal static string ProgramChange201001 => LanguageText_it.ResourceManager.GetString("ProgramChange201001", LanguageText_it.resourceCulture);

		internal static string ProgramChange201002 => LanguageText_it.ResourceManager.GetString("ProgramChange201002", LanguageText_it.resourceCulture);

		internal static string ProgramChange201003 => LanguageText_it.ResourceManager.GetString("ProgramChange201003", LanguageText_it.resourceCulture);

		internal static string ProgramChange201004 => LanguageText_it.ResourceManager.GetString("ProgramChange201004", LanguageText_it.resourceCulture);

		internal static string ProgramChange201005 => LanguageText_it.ResourceManager.GetString("ProgramChange201005", LanguageText_it.resourceCulture);

		internal static string ProgramChange201006 => LanguageText_it.ResourceManager.GetString("ProgramChange201006", LanguageText_it.resourceCulture);

		internal static string ProgramChange201007 => LanguageText_it.ResourceManager.GetString("ProgramChange201007", LanguageText_it.resourceCulture);

		internal static string ProgramChange201008 => LanguageText_it.ResourceManager.GetString("ProgramChange201008", LanguageText_it.resourceCulture);

		internal static string ProgramChange201009 => LanguageText_it.ResourceManager.GetString("ProgramChange201009", LanguageText_it.resourceCulture);

		internal static string ProgramNumber => LanguageText_it.ResourceManager.GetString("ProgramNumber", LanguageText_it.resourceCulture);

		internal static string Programs => LanguageText_it.ResourceManager.GetString("Programs", LanguageText_it.resourceCulture);

		internal static string Quit => LanguageText_it.ResourceManager.GetString("Quit", LanguageText_it.resourceCulture);

		internal static string Ramp => LanguageText_it.ResourceManager.GetString("Ramp", LanguageText_it.resourceCulture);

		internal static string Range => LanguageText_it.ResourceManager.GetString("Range", LanguageText_it.resourceCulture);

		internal static string ReadyToStart => LanguageText_it.ResourceManager.GetString("ReadyToStart", LanguageText_it.resourceCulture);

		internal static string RecentDateTime => LanguageText_it.ResourceManager.GetString("RecentDateTime", LanguageText_it.resourceCulture);

		internal static string Reconnect => LanguageText_it.ResourceManager.GetString("Reconnect", LanguageText_it.resourceCulture);

		internal static string ReconnectToController => LanguageText_it.ResourceManager.GetString("ReconnectToController", LanguageText_it.resourceCulture);

		internal static string RecursiveStatMode => LanguageText_it.ResourceManager.GetString("RecursiveStatMode", LanguageText_it.resourceCulture);

		internal static string RedAngle => LanguageText_it.ResourceManager.GetString("RedAngle", LanguageText_it.resourceCulture);

		internal static string RedTorque => LanguageText_it.ResourceManager.GetString("RedTorque", LanguageText_it.resourceCulture);

		internal static string RedundantSensorActive => LanguageText_it.ResourceManager.GetString("RedundantSensorActive", LanguageText_it.resourceCulture);

		internal static string relatedTo => LanguageText_it.ResourceManager.GetString("relatedTo", LanguageText_it.resourceCulture);

		internal static string RelativeTorque => LanguageText_it.ResourceManager.GetString("RelativeTorque", LanguageText_it.resourceCulture);

		internal static string Release => LanguageText_it.ResourceManager.GetString("Release", LanguageText_it.resourceCulture);

		internal static string ReleaseSpeed => LanguageText_it.ResourceManager.GetString("ReleaseSpeed", LanguageText_it.resourceCulture);

		internal static string RelTorqueStep => LanguageText_it.ResourceManager.GetString("RelTorqueStep", LanguageText_it.resourceCulture);

		internal static string RemainedCurves => LanguageText_it.ResourceManager.GetString("RemainedCurves", LanguageText_it.resourceCulture);

		internal static string Reset => LanguageText_it.ResourceManager.GetString("Reset", LanguageText_it.resourceCulture);

		internal static string ResetADepth => LanguageText_it.ResourceManager.GetString("ResetADepth", LanguageText_it.resourceCulture);

		internal static string ResetAngle => LanguageText_it.ResourceManager.GetString("ResetAngle", LanguageText_it.resourceCulture);

		internal static string Result => LanguageText_it.ResourceManager.GetString("Result", LanguageText_it.resourceCulture);

		internal static string ResultDisplay => LanguageText_it.ResourceManager.GetString("ResultDisplay", LanguageText_it.resourceCulture);

		internal static string Results => LanguageText_it.ResourceManager.GetString("Results", LanguageText_it.resourceCulture);

		internal static string RightAngle => LanguageText_it.ResourceManager.GetString("RightAngle", LanguageText_it.resourceCulture);

		internal static string Robot => LanguageText_it.ResourceManager.GetString("Robot", LanguageText_it.resourceCulture);

		internal static string RoundsPerMinute => LanguageText_it.ResourceManager.GetString("RoundsPerMinute", LanguageText_it.resourceCulture);

		internal static string RpmTest => LanguageText_it.ResourceManager.GetString("RpmTest", LanguageText_it.resourceCulture);

		internal static string RpmUnit => LanguageText_it.ResourceManager.GetString("RpmUnit", LanguageText_it.resourceCulture);

		internal static string RS232PrintMode => LanguageText_it.ResourceManager.GetString("RS232PrintMode", LanguageText_it.resourceCulture);

		internal static string SampleSize => LanguageText_it.ResourceManager.GetString("SampleSize", LanguageText_it.resourceCulture);

		internal static string SampleStatistic => LanguageText_it.ResourceManager.GetString("SampleStatistic", LanguageText_it.resourceCulture);

		internal static string SaveCurveDataToFile => LanguageText_it.ResourceManager.GetString("SaveCurveDataToFile", LanguageText_it.resourceCulture);

		internal static string SaveCustBackup => LanguageText_it.ResourceManager.GetString("SaveCustBackup", LanguageText_it.resourceCulture);

		internal static string SaveCustBackupOnCF => LanguageText_it.ResourceManager.GetString("SaveCustBackupOnCF", LanguageText_it.resourceCulture);

		internal static string SaveCustBackupSecQuery => LanguageText_it.ResourceManager.GetString("SaveCustBackupSecQuery", LanguageText_it.resourceCulture);

		internal static string SavePasscodesOnCPU => LanguageText_it.ResourceManager.GetString("SavePasscodesOnCPU", LanguageText_it.resourceCulture);

		internal static string SavePProgToFile => LanguageText_it.ResourceManager.GetString("SavePProgToFile", LanguageText_it.resourceCulture);

		internal static string SaveProgOnCPU => LanguageText_it.ResourceManager.GetString("SaveProgOnCPU", LanguageText_it.resourceCulture);

		internal static string SaveProgramData => LanguageText_it.ResourceManager.GetString("SaveProgramData", LanguageText_it.resourceCulture);

		internal static string SaveProgramDataLocally => LanguageText_it.ResourceManager.GetString("SaveProgramDataLocally", LanguageText_it.resourceCulture);

		internal static string SaveSingleProgToFile => LanguageText_it.ResourceManager.GetString("SaveSingleProgToFile", LanguageText_it.resourceCulture);

		internal static string SaveSpindleConstOnCPU => LanguageText_it.ResourceManager.GetString("SaveSpindleConstOnCPU", LanguageText_it.resourceCulture);

		internal static string SaveSpindleDataLocally => LanguageText_it.ResourceManager.GetString("SaveSpindleDataLocally", LanguageText_it.resourceCulture);

		internal static string SaveSystemConstOnCPU => LanguageText_it.ResourceManager.GetString("SaveSystemConstOnCPU", LanguageText_it.resourceCulture);

		internal static string SaveToFile => LanguageText_it.ResourceManager.GetString("SaveToFile", LanguageText_it.resourceCulture);

		internal static string SaveVisuParam => LanguageText_it.ResourceManager.GetString("SaveVisuParam", LanguageText_it.resourceCulture);

		internal static string SaveWebBackupSecQuery => LanguageText_it.ResourceManager.GetString("SaveWebBackupSecQuery", LanguageText_it.resourceCulture);

		internal static string SaveWeberBackup => LanguageText_it.ResourceManager.GetString("SaveWeberBackup", LanguageText_it.resourceCulture);

		internal static string SaveWeberBackupOnCF => LanguageText_it.ResourceManager.GetString("SaveWeberBackupOnCF", LanguageText_it.resourceCulture);

		internal static string ScrewID => LanguageText_it.ResourceManager.GetString("ScrewID", LanguageText_it.resourceCulture);

		internal static string ScrewProgramFiles => LanguageText_it.ResourceManager.GetString("ScrewProgramFiles", LanguageText_it.resourceCulture);

		internal static string ScrewPrograms => LanguageText_it.ResourceManager.GetString("ScrewPrograms", LanguageText_it.resourceCulture);

		internal static string ScrewTime => LanguageText_it.ResourceManager.GetString("ScrewTime", LanguageText_it.resourceCulture);

		internal static string Second => LanguageText_it.ResourceManager.GetString("Second", LanguageText_it.resourceCulture);

		internal static string SelectAll => LanguageText_it.ResourceManager.GetString("SelectAll", LanguageText_it.resourceCulture);

		internal static string SelectedKind => LanguageText_it.ResourceManager.GetString("SelectedKind", LanguageText_it.resourceCulture);

		internal static string SelectedXAxis => LanguageText_it.ResourceManager.GetString("SelectedXAxis", LanguageText_it.resourceCulture);

		internal static string SelectedYAxis => LanguageText_it.ResourceManager.GetString("SelectedYAxis", LanguageText_it.resourceCulture);

		internal static string SelectNone => LanguageText_it.ResourceManager.GetString("SelectNone", LanguageText_it.resourceCulture);

		internal static string SelValidNumber => LanguageText_it.ResourceManager.GetString("SelValidNumber", LanguageText_it.resourceCulture);

		internal static string SendIO => LanguageText_it.ResourceManager.GetString("SendIO", LanguageText_it.resourceCulture);

		internal static string SendPasscodes => LanguageText_it.ResourceManager.GetString("SendPasscodes", LanguageText_it.resourceCulture);

		internal static string SendSpindleConstants => LanguageText_it.ResourceManager.GetString("SendSpindleConstants", LanguageText_it.resourceCulture);

		internal static string SendSystemConstants => LanguageText_it.ResourceManager.GetString("SendSystemConstants", LanguageText_it.resourceCulture);

		internal static string SensorTest => LanguageText_it.ResourceManager.GetString("SensorTest", LanguageText_it.resourceCulture);

		internal static string Set => LanguageText_it.ResourceManager.GetString("Set", LanguageText_it.resourceCulture);

		internal static string SetAnaOut => LanguageText_it.ResourceManager.GetString("SetAnaOut", LanguageText_it.resourceCulture);

		internal static string SetDigOut => LanguageText_it.ResourceManager.GetString("SetDigOut", LanguageText_it.resourceCulture);

		internal static string SetOff => LanguageText_it.ResourceManager.GetString("SetOff", LanguageText_it.resourceCulture);

		internal static string SetOn => LanguageText_it.ResourceManager.GetString("SetOn", LanguageText_it.resourceCulture);

		internal static string SetRight => LanguageText_it.ResourceManager.GetString("SetRight", LanguageText_it.resourceCulture);

		internal static string SetRpm => LanguageText_it.ResourceManager.GetString("SetRpm", LanguageText_it.resourceCulture);

		internal static string Settings => LanguageText_it.ResourceManager.GetString("Settings", LanguageText_it.resourceCulture);

		internal static string ShortName => LanguageText_it.ResourceManager.GetString("ShortName", LanguageText_it.resourceCulture);

		internal static string SignalQuit => LanguageText_it.ResourceManager.GetString("SignalQuit", LanguageText_it.resourceCulture);

		internal static string Spain => LanguageText_it.ResourceManager.GetString("Spain", LanguageText_it.resourceCulture);

		internal static string SpChange100010 => LanguageText_it.ResourceManager.GetString("SpChange100010", LanguageText_it.resourceCulture);

		internal static string SpChange203000 => LanguageText_it.ResourceManager.GetString("SpChange203000", LanguageText_it.resourceCulture);

		internal static string SpChange203001 => LanguageText_it.ResourceManager.GetString("SpChange203001", LanguageText_it.resourceCulture);

		internal static string SpChange203002 => LanguageText_it.ResourceManager.GetString("SpChange203002", LanguageText_it.resourceCulture);

		internal static string SpChange203003 => LanguageText_it.ResourceManager.GetString("SpChange203003", LanguageText_it.resourceCulture);

		internal static string SpChange203004 => LanguageText_it.ResourceManager.GetString("SpChange203004", LanguageText_it.resourceCulture);

		internal static string SpChange203005 => LanguageText_it.ResourceManager.GetString("SpChange203005", LanguageText_it.resourceCulture);

		internal static string SpChange203006 => LanguageText_it.ResourceManager.GetString("SpChange203006", LanguageText_it.resourceCulture);

		internal static string SpChange203007 => LanguageText_it.ResourceManager.GetString("SpChange203007", LanguageText_it.resourceCulture);

		internal static string SpChange203008 => LanguageText_it.ResourceManager.GetString("SpChange203008", LanguageText_it.resourceCulture);

		internal static string SpChange203009 => LanguageText_it.ResourceManager.GetString("SpChange203009", LanguageText_it.resourceCulture);

		internal static string SpChange203010 => LanguageText_it.ResourceManager.GetString("SpChange203010", LanguageText_it.resourceCulture);

		internal static string SpChange203011 => LanguageText_it.ResourceManager.GetString("SpChange203011", LanguageText_it.resourceCulture);

		internal static string SpChange203012 => LanguageText_it.ResourceManager.GetString("SpChange203012", LanguageText_it.resourceCulture);

		internal static string SpChange203013 => LanguageText_it.ResourceManager.GetString("SpChange203013", LanguageText_it.resourceCulture);

		internal static string SpChange203014 => LanguageText_it.ResourceManager.GetString("SpChange203014", LanguageText_it.resourceCulture);

		internal static string SpChange203015 => LanguageText_it.ResourceManager.GetString("SpChange203015", LanguageText_it.resourceCulture);

		internal static string SpChange203016 => LanguageText_it.ResourceManager.GetString("SpChange203016", LanguageText_it.resourceCulture);

		internal static string SpChange203017 => LanguageText_it.ResourceManager.GetString("SpChange203017", LanguageText_it.resourceCulture);

		internal static string SpChange203018 => LanguageText_it.ResourceManager.GetString("SpChange203018", LanguageText_it.resourceCulture);

		internal static string SpChange203019 => LanguageText_it.ResourceManager.GetString("SpChange203019", LanguageText_it.resourceCulture);

		internal static string SpChange203020 => LanguageText_it.ResourceManager.GetString("SpChange203020", LanguageText_it.resourceCulture);

		internal static string SpChange203021 => LanguageText_it.ResourceManager.GetString("SpChange203021", LanguageText_it.resourceCulture);

		internal static string SpChange203022 => LanguageText_it.ResourceManager.GetString("SpChange203022", LanguageText_it.resourceCulture);

		internal static string SpChange203023 => LanguageText_it.ResourceManager.GetString("SpChange203023", LanguageText_it.resourceCulture);

		internal static string SpChange203024 => LanguageText_it.ResourceManager.GetString("SpChange203024", LanguageText_it.resourceCulture);

		internal static string SpChange203025 => LanguageText_it.ResourceManager.GetString("SpChange203025", LanguageText_it.resourceCulture);

		internal static string SpChange203026 => LanguageText_it.ResourceManager.GetString("SpChange203026", LanguageText_it.resourceCulture);

		internal static string SpChange203027 => LanguageText_it.ResourceManager.GetString("SpChange203027", LanguageText_it.resourceCulture);

		internal static string SpChange203028 => LanguageText_it.ResourceManager.GetString("SpChange203028", LanguageText_it.resourceCulture);

		internal static string SpChange203029 => LanguageText_it.ResourceManager.GetString("SpChange203029", LanguageText_it.resourceCulture);

		internal static string SpChange203030 => LanguageText_it.ResourceManager.GetString("SpChange203030", LanguageText_it.resourceCulture);

		internal static string SpindleConstants => LanguageText_it.ResourceManager.GetString("SpindleConstants", LanguageText_it.resourceCulture);

		internal static string SpindleConstFiles => LanguageText_it.ResourceManager.GetString("SpindleConstFiles", LanguageText_it.resourceCulture);

		internal static string SpindlePressureScale => LanguageText_it.ResourceManager.GetString("SpindlePressureScale", LanguageText_it.resourceCulture);

		internal static string SpindleTorque => LanguageText_it.ResourceManager.GetString("SpindleTorque", LanguageText_it.resourceCulture);

		internal static string StandardDeviation => LanguageText_it.ResourceManager.GetString("StandardDeviation", LanguageText_it.resourceCulture);

		internal static string StartCycleSave => LanguageText_it.ResourceManager.GetString("StartCycleSave", LanguageText_it.resourceCulture);

		internal static string StartFrictionTest => LanguageText_it.ResourceManager.GetString("StartFrictionTest", LanguageText_it.resourceCulture);

		internal static string StartProgram => LanguageText_it.ResourceManager.GetString("StartProgram", LanguageText_it.resourceCulture);

		internal static string StartSignal => LanguageText_it.ResourceManager.GetString("StartSignal", LanguageText_it.resourceCulture);

		internal static string StartStepResExport => LanguageText_it.ResourceManager.GetString("StartStepResExport", LanguageText_it.resourceCulture);

		internal static string StartTest => LanguageText_it.ResourceManager.GetString("StartTest", LanguageText_it.resourceCulture);

		internal static string StatDelete204000 => LanguageText_it.ResourceManager.GetString("StatDelete204000", LanguageText_it.resourceCulture);

		internal static string StatDelete204001 => LanguageText_it.ResourceManager.GetString("StatDelete204001", LanguageText_it.resourceCulture);

		internal static string StatDelete204002 => LanguageText_it.ResourceManager.GetString("StatDelete204002", LanguageText_it.resourceCulture);

		internal static string StatisticCumul => LanguageText_it.ResourceManager.GetString("StatisticCumul", LanguageText_it.resourceCulture);

		internal static string Statistics => LanguageText_it.ResourceManager.GetString("Statistics", LanguageText_it.resourceCulture);

		internal static string StatisticSample => LanguageText_it.ResourceManager.GetString("StatisticSample", LanguageText_it.resourceCulture);

		internal static string StatisticsLastRes => LanguageText_it.ResourceManager.GetString("StatisticsLastRes", LanguageText_it.resourceCulture);

		internal static string Step => LanguageText_it.ResourceManager.GetString("Step", LanguageText_it.resourceCulture);

		internal static string StepFinish => LanguageText_it.ResourceManager.GetString("StepFinish", LanguageText_it.resourceCulture);

		internal static string StepKind => LanguageText_it.ResourceManager.GetString("StepKind", LanguageText_it.resourceCulture);

		internal static string StepKindChoice => LanguageText_it.ResourceManager.GetString("StepKindChoice", LanguageText_it.resourceCulture);

		internal static string StepResults => LanguageText_it.ResourceManager.GetString("StepResults", LanguageText_it.resourceCulture);

		internal static string Steps => LanguageText_it.ResourceManager.GetString("Steps", LanguageText_it.resourceCulture);

		internal static string StepTmin => LanguageText_it.ResourceManager.GetString("StepTmin", LanguageText_it.resourceCulture);

		internal static string StepTplus => LanguageText_it.ResourceManager.GetString("StepTplus", LanguageText_it.resourceCulture);

		internal static string Stop => LanguageText_it.ResourceManager.GetString("Stop", LanguageText_it.resourceCulture);

		internal static string StopNok => LanguageText_it.ResourceManager.GetString("StopNok", LanguageText_it.resourceCulture);

		internal static string StopOk => LanguageText_it.ResourceManager.GetString("StopOk", LanguageText_it.resourceCulture);

		internal static string StopStepResExport => LanguageText_it.ResourceManager.GetString("StopStepResExport", LanguageText_it.resourceCulture);

		internal static string StorageNumber => LanguageText_it.ResourceManager.GetString("StorageNumber", LanguageText_it.resourceCulture);

		internal static string StorageSignals => LanguageText_it.ResourceManager.GetString("StorageSignals", LanguageText_it.resourceCulture);

		internal static string StoreAndBack => LanguageText_it.ResourceManager.GetString("StoreAndBack", LanguageText_it.resourceCulture);

		internal static string SubnetMask => LanguageText_it.ResourceManager.GetString("SubnetMask", LanguageText_it.resourceCulture);

		internal static string SyncOut => LanguageText_it.ResourceManager.GetString("SyncOut", LanguageText_it.resourceCulture);

		internal static string SyncSignal => LanguageText_it.ResourceManager.GetString("SyncSignal", LanguageText_it.resourceCulture);

		internal static string SysChange202000 => LanguageText_it.ResourceManager.GetString("SysChange202000", LanguageText_it.resourceCulture);

		internal static string SysChange202001 => LanguageText_it.ResourceManager.GetString("SysChange202001", LanguageText_it.resourceCulture);

		internal static string SysChange202002 => LanguageText_it.ResourceManager.GetString("SysChange202002", LanguageText_it.resourceCulture);

		internal static string SysChange202003 => LanguageText_it.ResourceManager.GetString("SysChange202003", LanguageText_it.resourceCulture);

		internal static string SysChange202004 => LanguageText_it.ResourceManager.GetString("SysChange202004", LanguageText_it.resourceCulture);

		internal static string SysChange202005 => LanguageText_it.ResourceManager.GetString("SysChange202005", LanguageText_it.resourceCulture);

		internal static string SysChange202006 => LanguageText_it.ResourceManager.GetString("SysChange202006", LanguageText_it.resourceCulture);

		internal static string SysChange202007 => LanguageText_it.ResourceManager.GetString("SysChange202007", LanguageText_it.resourceCulture);

		internal static string SysChange202008 => LanguageText_it.ResourceManager.GetString("SysChange202008", LanguageText_it.resourceCulture);

		internal static string SysChange202009 => LanguageText_it.ResourceManager.GetString("SysChange202009", LanguageText_it.resourceCulture);

		internal static string SysChange202010 => LanguageText_it.ResourceManager.GetString("SysChange202010", LanguageText_it.resourceCulture);

		internal static string SysChange202011 => LanguageText_it.ResourceManager.GetString("SysChange202011", LanguageText_it.resourceCulture);

		internal static string SysChange202012 => LanguageText_it.ResourceManager.GetString("SysChange202012", LanguageText_it.resourceCulture);

		internal static string SysChange202013 => LanguageText_it.ResourceManager.GetString("SysChange202013", LanguageText_it.resourceCulture);

		internal static string SysChange202014 => LanguageText_it.ResourceManager.GetString("SysChange202014", LanguageText_it.resourceCulture);

		internal static string SysChange202015 => LanguageText_it.ResourceManager.GetString("SysChange202015", LanguageText_it.resourceCulture);

		internal static string SysChange202016 => LanguageText_it.ResourceManager.GetString("SysChange202016", LanguageText_it.resourceCulture);

		internal static string SysChange202017 => LanguageText_it.ResourceManager.GetString("SysChange202017", LanguageText_it.resourceCulture);

		internal static string SysChange202018 => LanguageText_it.ResourceManager.GetString("SysChange202018", LanguageText_it.resourceCulture);

		internal static string SystemConstants => LanguageText_it.ResourceManager.GetString("SystemConstants", LanguageText_it.resourceCulture);

		internal static string SystemID => LanguageText_it.ResourceManager.GetString("SystemID", LanguageText_it.resourceCulture);

		internal static string SystemOK => LanguageText_it.ResourceManager.GetString("SystemOK", LanguageText_it.resourceCulture);

		internal static string Target => LanguageText_it.ResourceManager.GetString("Target", LanguageText_it.resourceCulture);

		internal static string TargetRight => LanguageText_it.ResourceManager.GetString("TargetRight", LanguageText_it.resourceCulture);

		internal static string TeachSignal => LanguageText_it.ResourceManager.GetString("TeachSignal", LanguageText_it.resourceCulture);

		internal static string Test => LanguageText_it.ResourceManager.GetString("Test", LanguageText_it.resourceCulture);

		internal static string TestIO => LanguageText_it.ResourceManager.GetString("TestIO", LanguageText_it.resourceCulture);

		internal static string TestMFS => LanguageText_it.ResourceManager.GetString("TestMFS", LanguageText_it.resourceCulture);

		internal static string TestSPSIO => LanguageText_it.ResourceManager.GetString("TestSPSIO", LanguageText_it.resourceCulture);

		internal static string Time => LanguageText_it.ResourceManager.GetString("Time", LanguageText_it.resourceCulture);

		internal static string TimeDateFormat => LanguageText_it.ResourceManager.GetString("TimeDateFormat", LanguageText_it.resourceCulture);

		internal static string TimeSet => LanguageText_it.ResourceManager.GetString("TimeSet", LanguageText_it.resourceCulture);

		internal static string TimeSynchronize => LanguageText_it.ResourceManager.GetString("TimeSynchronize", LanguageText_it.resourceCulture);

		internal static string TM1 => LanguageText_it.ResourceManager.GetString("TM1", LanguageText_it.resourceCulture);

		internal static string TM2 => LanguageText_it.ResourceManager.GetString("TM2", LanguageText_it.resourceCulture);

		internal static string TN => LanguageText_it.ResourceManager.GetString("TN", LanguageText_it.resourceCulture);

		internal static string ToggleCursor => LanguageText_it.ResourceManager.GetString("ToggleCursor", LanguageText_it.resourceCulture);

		internal static string TopAll => LanguageText_it.ResourceManager.GetString("TopAll", LanguageText_it.resourceCulture);

		internal static string TopTen => LanguageText_it.ResourceManager.GetString("TopTen", LanguageText_it.resourceCulture);

		internal static string Torque => LanguageText_it.ResourceManager.GetString("Torque", LanguageText_it.resourceCulture);

		internal static string Torqueftlb => LanguageText_it.ResourceManager.GetString("Torqueftlb", LanguageText_it.resourceCulture);

		internal static string Torqueinlb => LanguageText_it.ResourceManager.GetString("Torqueinlb", LanguageText_it.resourceCulture);

		internal static string Torqueinoz => LanguageText_it.ResourceManager.GetString("Torqueinoz", LanguageText_it.resourceCulture);

		internal static string Torquekgcm => LanguageText_it.ResourceManager.GetString("Torquekgcm", LanguageText_it.resourceCulture);

		internal static string Torquekgm => LanguageText_it.ResourceManager.GetString("Torquekgm", LanguageText_it.resourceCulture);

		internal static string TorqueNcm => LanguageText_it.ResourceManager.GetString("TorqueNcm", LanguageText_it.resourceCulture);

		internal static string TorqueNm => LanguageText_it.ResourceManager.GetString("TorqueNm", LanguageText_it.resourceCulture);

		internal static string TorqueRedundantTime => LanguageText_it.ResourceManager.GetString("TorqueRedundantTime", LanguageText_it.resourceCulture);

		internal static string TorqueRedundantTolerance => LanguageText_it.ResourceManager.GetString("TorqueRedundantTolerance", LanguageText_it.resourceCulture);

		internal static string TorqueSensorInvers => LanguageText_it.ResourceManager.GetString("TorqueSensorInvers", LanguageText_it.resourceCulture);

		internal static string TorqueSensorScale => LanguageText_it.ResourceManager.GetString("TorqueSensorScale", LanguageText_it.resourceCulture);

		internal static string TorqueSensorTolerance => LanguageText_it.ResourceManager.GetString("TorqueSensorTolerance", LanguageText_it.resourceCulture);

		internal static string TorqueUnitChoose => LanguageText_it.ResourceManager.GetString("TorqueUnitChoose", LanguageText_it.resourceCulture);

		internal static string TreshTorque => LanguageText_it.ResourceManager.GetString("TreshTorque", LanguageText_it.resourceCulture);

		internal static string Type => LanguageText_it.ResourceManager.GetString("Type", LanguageText_it.resourceCulture);

		internal static string Unit => LanguageText_it.ResourceManager.GetString("Unit", LanguageText_it.resourceCulture);

		internal static string UnitBar => LanguageText_it.ResourceManager.GetString("UnitBar", LanguageText_it.resourceCulture);

		internal static string UpperLimit => LanguageText_it.ResourceManager.GetString("UpperLimit", LanguageText_it.resourceCulture);

		internal static string UsedKeyboard => LanguageText_it.ResourceManager.GetString("UsedKeyboard", LanguageText_it.resourceCulture);

		internal static string UsedValueNumber => LanguageText_it.ResourceManager.GetString("UsedValueNumber", LanguageText_it.resourceCulture);

		internal static string UseLanguageSettings => LanguageText_it.ResourceManager.GetString("UseLanguageSettings", LanguageText_it.resourceCulture);

		internal static string User => LanguageText_it.ResourceManager.GetString("User", LanguageText_it.resourceCulture);

		internal static string UserRights => LanguageText_it.ResourceManager.GetString("UserRights", LanguageText_it.resourceCulture);

		internal static string USTime => LanguageText_it.ResourceManager.GetString("USTime", LanguageText_it.resourceCulture);

		internal static string Valid => LanguageText_it.ResourceManager.GetString("Valid", LanguageText_it.resourceCulture);

		internal static string Value => LanguageText_it.ResourceManager.GetString("Value", LanguageText_it.resourceCulture);

		internal static string ValueRange => LanguageText_it.ResourceManager.GetString("ValueRange", LanguageText_it.resourceCulture);

		internal static string ValuesNotApplied => LanguageText_it.ResourceManager.GetString("ValuesNotApplied", LanguageText_it.resourceCulture);

		internal static string VersionController => LanguageText_it.ResourceManager.GetString("VersionController", LanguageText_it.resourceCulture);

		internal static string VersionInfo => LanguageText_it.ResourceManager.GetString("VersionInfo", LanguageText_it.resourceCulture);

		internal static string VersionVisu => LanguageText_it.ResourceManager.GetString("VersionVisu", LanguageText_it.resourceCulture);

		internal static string Visualisation => LanguageText_it.ResourceManager.GetString("Visualisation", LanguageText_it.resourceCulture);

		internal static string VisuParam => LanguageText_it.ResourceManager.GetString("VisuParam", LanguageText_it.resourceCulture);

		internal static string Voltage => LanguageText_it.ResourceManager.GetString("Voltage", LanguageText_it.resourceCulture);

		internal static string WaitForAck => LanguageText_it.ResourceManager.GetString("WaitForAck", LanguageText_it.resourceCulture);

		internal static string Warning => LanguageText_it.ResourceManager.GetString("Warning", LanguageText_it.resourceCulture);

		internal static string WarningMode => LanguageText_it.ResourceManager.GetString("WarningMode", LanguageText_it.resourceCulture);

		internal static string WarningNumber => LanguageText_it.ResourceManager.GetString("WarningNumber", LanguageText_it.resourceCulture);

		internal static string WasReset => LanguageText_it.ResourceManager.GetString("WasReset", LanguageText_it.resourceCulture);

		internal static string WasSet => LanguageText_it.ResourceManager.GetString("WasSet", LanguageText_it.resourceCulture);

		internal static string WeberCurveFormat => LanguageText_it.ResourceManager.GetString("WeberCurveFormat", LanguageText_it.resourceCulture);

		internal static string WN => LanguageText_it.ResourceManager.GetString("WN", LanguageText_it.resourceCulture);

		internal static string WriteLastNIOTable => LanguageText_it.ResourceManager.GetString("WriteLastNIOTable", LanguageText_it.resourceCulture);

		internal static string WriteLastResultsTable => LanguageText_it.ResourceManager.GetString("WriteLastResultsTable", LanguageText_it.resourceCulture);

		internal static string WriteLogbookData => LanguageText_it.ResourceManager.GetString("WriteLogbookData", LanguageText_it.resourceCulture);

		internal static string WriteLogBookTable => LanguageText_it.ResourceManager.GetString("WriteLogBookTable", LanguageText_it.resourceCulture);

		internal static string WriteStepResults => LanguageText_it.ResourceManager.GetString("WriteStepResults", LanguageText_it.resourceCulture);

		internal static string Xmax => LanguageText_it.ResourceManager.GetString("Xmax", LanguageText_it.resourceCulture);

		internal static string Xmin => LanguageText_it.ResourceManager.GetString("Xmin", LanguageText_it.resourceCulture);

		internal static string XmlExport => LanguageText_it.ResourceManager.GetString("XmlExport", LanguageText_it.resourceCulture);

		internal static string Yes => LanguageText_it.ResourceManager.GetString("Yes", LanguageText_it.resourceCulture);

		internal static string ZoomIn => LanguageText_it.ResourceManager.GetString("ZoomIn", LanguageText_it.resourceCulture);

		internal static string ZoomOut => LanguageText_it.ResourceManager.GetString("ZoomOut", LanguageText_it.resourceCulture);

		internal LanguageText_it()
		{
		}
	}
}
