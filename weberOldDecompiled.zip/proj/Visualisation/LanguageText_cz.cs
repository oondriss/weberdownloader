using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Visualisation
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class LanguageText_cz
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(LanguageText_cz.resourceMan, null))
				{
					ResourceManager resourceManager = LanguageText_cz.resourceMan = new ResourceManager("Visualisation.LanguageText_cz", typeof(LanguageText_cz).Assembly);
				}
				return LanguageText_cz.resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return LanguageText_cz.resourceCulture;
			}
			set
			{
				LanguageText_cz.resourceCulture = value;
			}
		}

		internal static string Abr_Program => LanguageText_cz.ResourceManager.GetString("Abr_Program", LanguageText_cz.resourceCulture);

		internal static string AbrAnaDepth => LanguageText_cz.ResourceManager.GetString("AbrAnaDepth", LanguageText_cz.resourceCulture);

		internal static string AbrAnaSignal => LanguageText_cz.ResourceManager.GetString("AbrAnaSignal", LanguageText_cz.resourceCulture);

		internal static string AbrAngle => LanguageText_cz.ResourceManager.GetString("AbrAngle", LanguageText_cz.resourceCulture);

		internal static string AbrDelayTorque => LanguageText_cz.ResourceManager.GetString("AbrDelayTorque", LanguageText_cz.resourceCulture);

		internal static string AbrDepthGrad => LanguageText_cz.ResourceManager.GetString("AbrDepthGrad", LanguageText_cz.resourceCulture);

		internal static string AbrFilteredTorque => LanguageText_cz.ResourceManager.GetString("AbrFilteredTorque", LanguageText_cz.resourceCulture);

		internal static string AbrGradient => LanguageText_cz.ResourceManager.GetString("AbrGradient", LanguageText_cz.resourceCulture);

		internal static string AbrM360Follow => LanguageText_cz.ResourceManager.GetString("AbrM360Follow", LanguageText_cz.resourceCulture);

		internal static string AbrMaxTorque => LanguageText_cz.ResourceManager.GetString("AbrMaxTorque", LanguageText_cz.resourceCulture);

		internal static string AbrNumber => LanguageText_cz.ResourceManager.GetString("AbrNumber", LanguageText_cz.resourceCulture);

		internal static string AbrTime => LanguageText_cz.ResourceManager.GetString("AbrTime", LanguageText_cz.resourceCulture);

		internal static string AbrTorque => LanguageText_cz.ResourceManager.GetString("AbrTorque", LanguageText_cz.resourceCulture);

		internal static string AccessCheck => LanguageText_cz.ResourceManager.GetString("AccessCheck", LanguageText_cz.resourceCulture);

		internal static string AccessRequest => LanguageText_cz.ResourceManager.GetString("AccessRequest", LanguageText_cz.resourceCulture);

		internal static string Actualize => LanguageText_cz.ResourceManager.GetString("Actualize", LanguageText_cz.resourceCulture);

		internal static string AddEntry => LanguageText_cz.ResourceManager.GetString("AddEntry", LanguageText_cz.resourceCulture);

		internal static string AIError => LanguageText_cz.ResourceManager.GetString("AIError", LanguageText_cz.resourceCulture);

		internal static string All => LanguageText_cz.ResourceManager.GetString("All", LanguageText_cz.resourceCulture);

		internal static string AllFiles => LanguageText_cz.ResourceManager.GetString("AllFiles", LanguageText_cz.resourceCulture);

		internal static string AnaDepth => LanguageText_cz.ResourceManager.GetString("AnaDepth", LanguageText_cz.resourceCulture);

		internal static string Analysis => LanguageText_cz.ResourceManager.GetString("Analysis", LanguageText_cz.resourceCulture);

		internal static string AnaOutput => LanguageText_cz.ResourceManager.GetString("AnaOutput", LanguageText_cz.resourceCulture);

		internal static string AnaSignal => LanguageText_cz.ResourceManager.GetString("AnaSignal", LanguageText_cz.resourceCulture);

		internal static string AnaSigOffset => LanguageText_cz.ResourceManager.GetString("AnaSigOffset", LanguageText_cz.resourceCulture);

		internal static string AnaSigScale => LanguageText_cz.ResourceManager.GetString("AnaSigScale", LanguageText_cz.resourceCulture);

		internal static string Angle => LanguageText_cz.ResourceManager.GetString("Angle", LanguageText_cz.resourceCulture);

		internal static string AngleRedundantTolerance => LanguageText_cz.ResourceManager.GetString("AngleRedundantTolerance", LanguageText_cz.resourceCulture);

		internal static string AngleSensorInvers => LanguageText_cz.ResourceManager.GetString("AngleSensorInvers", LanguageText_cz.resourceCulture);

		internal static string AngleSensorScale => LanguageText_cz.ResourceManager.GetString("AngleSensorScale", LanguageText_cz.resourceCulture);

		internal static string AngleTorqueSensor => LanguageText_cz.ResourceManager.GetString("AngleTorqueSensor", LanguageText_cz.resourceCulture);

		internal static string Apply => LanguageText_cz.ResourceManager.GetString("Apply", LanguageText_cz.resourceCulture);

		internal static string ApplyEntry => LanguageText_cz.ResourceManager.GetString("ApplyEntry", LanguageText_cz.resourceCulture);

		internal static string AutoCurveAbort => LanguageText_cz.ResourceManager.GetString("AutoCurveAbort", LanguageText_cz.resourceCulture);

		internal static string Automatic => LanguageText_cz.ResourceManager.GetString("Automatic", LanguageText_cz.resourceCulture);

		internal static string AutoMode => LanguageText_cz.ResourceManager.GetString("AutoMode", LanguageText_cz.resourceCulture);

		internal static string AvailableValueNumber => LanguageText_cz.ResourceManager.GetString("AvailableValueNumber", LanguageText_cz.resourceCulture);

		internal static string Back => LanguageText_cz.ResourceManager.GetString("Back", LanguageText_cz.resourceCulture);

		internal static string Backup => LanguageText_cz.ResourceManager.GetString("Backup", LanguageText_cz.resourceCulture);

		internal static string Backup205000 => LanguageText_cz.ResourceManager.GetString("Backup205000", LanguageText_cz.resourceCulture);

		internal static string Backup205001 => LanguageText_cz.ResourceManager.GetString("Backup205001", LanguageText_cz.resourceCulture);

		internal static string Backup205002 => LanguageText_cz.ResourceManager.GetString("Backup205002", LanguageText_cz.resourceCulture);

		internal static string Backup205003 => LanguageText_cz.ResourceManager.GetString("Backup205003", LanguageText_cz.resourceCulture);

		internal static string Battery => LanguageText_cz.ResourceManager.GetString("Battery", LanguageText_cz.resourceCulture);

		internal static string Baudrate => LanguageText_cz.ResourceManager.GetString("Baudrate", LanguageText_cz.resourceCulture);

		internal static string bt0 => LanguageText_cz.ResourceManager.GetString("bt0", LanguageText_cz.resourceCulture);

		internal static string bt1 => LanguageText_cz.ResourceManager.GetString("bt1", LanguageText_cz.resourceCulture);

		internal static string bt2 => LanguageText_cz.ResourceManager.GetString("bt2", LanguageText_cz.resourceCulture);

		internal static string bt3 => LanguageText_cz.ResourceManager.GetString("bt3", LanguageText_cz.resourceCulture);

		internal static string bt4 => LanguageText_cz.ResourceManager.GetString("bt4", LanguageText_cz.resourceCulture);

		internal static string bt5 => LanguageText_cz.ResourceManager.GetString("bt5", LanguageText_cz.resourceCulture);

		internal static string bt6 => LanguageText_cz.ResourceManager.GetString("bt6", LanguageText_cz.resourceCulture);

		internal static string bt7 => LanguageText_cz.ResourceManager.GetString("bt7", LanguageText_cz.resourceCulture);

		internal static string bt8 => LanguageText_cz.ResourceManager.GetString("bt8", LanguageText_cz.resourceCulture);

		internal static string bt9 => LanguageText_cz.ResourceManager.GetString("bt9", LanguageText_cz.resourceCulture);

		internal static string btA => LanguageText_cz.ResourceManager.GetString("btA", LanguageText_cz.resourceCulture);

		internal static string btApply => LanguageText_cz.ResourceManager.GetString("btApply", LanguageText_cz.resourceCulture);

		internal static string btB => LanguageText_cz.ResourceManager.GetString("btB", LanguageText_cz.resourceCulture);

		internal static string btBackspace => LanguageText_cz.ResourceManager.GetString("btBackspace", LanguageText_cz.resourceCulture);

		internal static string btC => LanguageText_cz.ResourceManager.GetString("btC", LanguageText_cz.resourceCulture);

		internal static string btCancel => LanguageText_cz.ResourceManager.GetString("btCancel", LanguageText_cz.resourceCulture);

		internal static string btChangeDefaultDir => LanguageText_cz.ResourceManager.GetString("btChangeDefaultDir", LanguageText_cz.resourceCulture);

		internal static string btD => LanguageText_cz.ResourceManager.GetString("btD", LanguageText_cz.resourceCulture);

		internal static string btE => LanguageText_cz.ResourceManager.GetString("btE", LanguageText_cz.resourceCulture);

		internal static string btErase => LanguageText_cz.ResourceManager.GetString("btErase", LanguageText_cz.resourceCulture);

		internal static string btF => LanguageText_cz.ResourceManager.GetString("btF", LanguageText_cz.resourceCulture);

		internal static string btG => LanguageText_cz.ResourceManager.GetString("btG", LanguageText_cz.resourceCulture);

		internal static string btH => LanguageText_cz.ResourceManager.GetString("btH", LanguageText_cz.resourceCulture);

		internal static string btI => LanguageText_cz.ResourceManager.GetString("btI", LanguageText_cz.resourceCulture);

		internal static string btJ => LanguageText_cz.ResourceManager.GetString("btJ", LanguageText_cz.resourceCulture);

		internal static string btK => LanguageText_cz.ResourceManager.GetString("btK", LanguageText_cz.resourceCulture);

		internal static string btL => LanguageText_cz.ResourceManager.GetString("btL", LanguageText_cz.resourceCulture);

		internal static string btLoad => LanguageText_cz.ResourceManager.GetString("btLoad", LanguageText_cz.resourceCulture);

		internal static string btM => LanguageText_cz.ResourceManager.GetString("btM", LanguageText_cz.resourceCulture);

		internal static string btMinusDown => LanguageText_cz.ResourceManager.GetString("btMinusDown", LanguageText_cz.resourceCulture);

		internal static string btMinusUp => LanguageText_cz.ResourceManager.GetString("btMinusUp", LanguageText_cz.resourceCulture);

		internal static string btN => LanguageText_cz.ResourceManager.GetString("btN", LanguageText_cz.resourceCulture);

		internal static string btO => LanguageText_cz.ResourceManager.GetString("btO", LanguageText_cz.resourceCulture);

		internal static string btP => LanguageText_cz.ResourceManager.GetString("btP", LanguageText_cz.resourceCulture);

		internal static string btQ => LanguageText_cz.ResourceManager.GetString("btQ", LanguageText_cz.resourceCulture);

		internal static string btR => LanguageText_cz.ResourceManager.GetString("btR", LanguageText_cz.resourceCulture);

		internal static string btRes1 => LanguageText_cz.ResourceManager.GetString("btRes1", LanguageText_cz.resourceCulture);

		internal static string btRes2 => LanguageText_cz.ResourceManager.GetString("btRes2", LanguageText_cz.resourceCulture);

		internal static string btRes3 => LanguageText_cz.ResourceManager.GetString("btRes3", LanguageText_cz.resourceCulture);

		internal static string btS => LanguageText_cz.ResourceManager.GetString("btS", LanguageText_cz.resourceCulture);

		internal static string btShift => LanguageText_cz.ResourceManager.GetString("btShift", LanguageText_cz.resourceCulture);

		internal static string btSpace => LanguageText_cz.ResourceManager.GetString("btSpace", LanguageText_cz.resourceCulture);

		internal static string btT => LanguageText_cz.ResourceManager.GetString("btT", LanguageText_cz.resourceCulture);

		internal static string btTeach => LanguageText_cz.ResourceManager.GetString("btTeach", LanguageText_cz.resourceCulture);

		internal static string btU => LanguageText_cz.ResourceManager.GetString("btU", LanguageText_cz.resourceCulture);

		internal static string btV => LanguageText_cz.ResourceManager.GetString("btV", LanguageText_cz.resourceCulture);

		internal static string btW => LanguageText_cz.ResourceManager.GetString("btW", LanguageText_cz.resourceCulture);

		internal static string btX => LanguageText_cz.ResourceManager.GetString("btX", LanguageText_cz.resourceCulture);

		internal static string btY => LanguageText_cz.ResourceManager.GetString("btY", LanguageText_cz.resourceCulture);

		internal static string btZ => LanguageText_cz.ResourceManager.GetString("btZ", LanguageText_cz.resourceCulture);

		internal static string CalculateCurves => LanguageText_cz.ResourceManager.GetString("CalculateCurves", LanguageText_cz.resourceCulture);

		internal static string CalDisable => LanguageText_cz.ResourceManager.GetString("CalDisable", LanguageText_cz.resourceCulture);

		internal static string CalibrationSignal => LanguageText_cz.ResourceManager.GetString("CalibrationSignal", LanguageText_cz.resourceCulture);

		internal static string Cancel => LanguageText_cz.ResourceManager.GetString("Cancel", LanguageText_cz.resourceCulture);

		internal static string Changed => LanguageText_cz.ResourceManager.GetString("Changed", LanguageText_cz.resourceCulture);

		internal static string ChangeEntry => LanguageText_cz.ResourceManager.GetString("ChangeEntry", LanguageText_cz.resourceCulture);

		internal static string ChangesLog => LanguageText_cz.ResourceManager.GetString("ChangesLog", LanguageText_cz.resourceCulture);

		internal static string chBEmtyPrograms => LanguageText_cz.ResourceManager.GetString("chBEmtyPrograms", LanguageText_cz.resourceCulture);

		internal static string chBProgPreview => LanguageText_cz.ResourceManager.GetString("chBProgPreview", LanguageText_cz.resourceCulture);

		internal static string chBUseDefaultDir => LanguageText_cz.ResourceManager.GetString("chBUseDefaultDir", LanguageText_cz.resourceCulture);

		internal static string CheckFrictionTestStart => LanguageText_cz.ResourceManager.GetString("CheckFrictionTestStart", LanguageText_cz.resourceCulture);

		internal static string CheckHandStart => LanguageText_cz.ResourceManager.GetString("CheckHandStart", LanguageText_cz.resourceCulture);

		internal static string CheckParameter => LanguageText_cz.ResourceManager.GetString("CheckParameter", LanguageText_cz.resourceCulture);

		internal static string CheckRight => LanguageText_cz.ResourceManager.GetString("CheckRight", LanguageText_cz.resourceCulture);

		internal static string Close => LanguageText_cz.ResourceManager.GetString("Close", LanguageText_cz.resourceCulture);

		internal static string ControllerName => LanguageText_cz.ResourceManager.GetString("ControllerName", LanguageText_cz.resourceCulture);

		internal static string ControllerTime => LanguageText_cz.ResourceManager.GetString("ControllerTime", LanguageText_cz.resourceCulture);

		internal static string CopyProgram => LanguageText_cz.ResourceManager.GetString("CopyProgram", LanguageText_cz.resourceCulture);

		internal static string CountPassMax => LanguageText_cz.ResourceManager.GetString("CountPassMax", LanguageText_cz.resourceCulture);

		internal static string CreatedUsers => LanguageText_cz.ResourceManager.GetString("CreatedUsers", LanguageText_cz.resourceCulture);

		internal static string CumulStats => LanguageText_cz.ResourceManager.GetString("CumulStats", LanguageText_cz.resourceCulture);

		internal static string CursorsCannotSwitch => LanguageText_cz.ResourceManager.GetString("CursorsCannotSwitch", LanguageText_cz.resourceCulture);

		internal static string CurveDisplay => LanguageText_cz.ResourceManager.GetString("CurveDisplay", LanguageText_cz.resourceCulture);

		internal static string CurveLoad => LanguageText_cz.ResourceManager.GetString("CurveLoad", LanguageText_cz.resourceCulture);

		internal static string CurvePrint => LanguageText_cz.ResourceManager.GetString("CurvePrint", LanguageText_cz.resourceCulture);

		internal static string CurveResultKind => LanguageText_cz.ResourceManager.GetString("CurveResultKind", LanguageText_cz.resourceCulture);

		internal static string CurveResultNumber => LanguageText_cz.ResourceManager.GetString("CurveResultNumber", LanguageText_cz.resourceCulture);

		internal static string CurveSave => LanguageText_cz.ResourceManager.GetString("CurveSave", LanguageText_cz.resourceCulture);

		internal static string CurveSelection => LanguageText_cz.ResourceManager.GetString("CurveSelection", LanguageText_cz.resourceCulture);

		internal static string CurvesZoomedIn => LanguageText_cz.ResourceManager.GetString("CurvesZoomedIn", LanguageText_cz.resourceCulture);

		internal static string CurvesZoomedOut => LanguageText_cz.ResourceManager.GetString("CurvesZoomedOut", LanguageText_cz.resourceCulture);

		internal static string CustomCounter => LanguageText_cz.ResourceManager.GetString("CustomCounter", LanguageText_cz.resourceCulture);

		internal static string Cycle => LanguageText_cz.ResourceManager.GetString("Cycle", LanguageText_cz.resourceCulture);

		internal static string CycleCounter => LanguageText_cz.ResourceManager.GetString("CycleCounter", LanguageText_cz.resourceCulture);

		internal static string CycleNumber => LanguageText_cz.ResourceManager.GetString("CycleNumber", LanguageText_cz.resourceCulture);

		internal static string CycleSave => LanguageText_cz.ResourceManager.GetString("CycleSave", LanguageText_cz.resourceCulture);

		internal static string Czech => LanguageText_cz.ResourceManager.GetString("Czech", LanguageText_cz.resourceCulture);

		internal static string DateTime => LanguageText_cz.ResourceManager.GetString("DateTime", LanguageText_cz.resourceCulture);

		internal static string DeblockController => LanguageText_cz.ResourceManager.GetString("DeblockController", LanguageText_cz.resourceCulture);

		internal static string DeclForSpSave => LanguageText_cz.ResourceManager.GetString("DeclForSpSave", LanguageText_cz.resourceCulture);

		internal static string Degree => LanguageText_cz.ResourceManager.GetString("Degree", LanguageText_cz.resourceCulture);

		internal static string DelayTorque => LanguageText_cz.ResourceManager.GetString("DelayTorque", LanguageText_cz.resourceCulture);

		internal static string DeleteCounter => LanguageText_cz.ResourceManager.GetString("DeleteCounter", LanguageText_cz.resourceCulture);

		internal static string DeleteCustomCounter => LanguageText_cz.ResourceManager.GetString("DeleteCustomCounter", LanguageText_cz.resourceCulture);

		internal static string DeleteEntry => LanguageText_cz.ResourceManager.GetString("DeleteEntry", LanguageText_cz.resourceCulture);

		internal static string DeleteJob => LanguageText_cz.ResourceManager.GetString("DeleteJob", LanguageText_cz.resourceCulture);

		internal static string DeleteLastResults => LanguageText_cz.ResourceManager.GetString("DeleteLastResults", LanguageText_cz.resourceCulture);

		internal static string DeleteProgram => LanguageText_cz.ResourceManager.GetString("DeleteProgram", LanguageText_cz.resourceCulture);

		internal static string DeleteRecursiveStat => LanguageText_cz.ResourceManager.GetString("DeleteRecursiveStat", LanguageText_cz.resourceCulture);

		internal static string DeleteStep => LanguageText_cz.ResourceManager.GetString("DeleteStep", LanguageText_cz.resourceCulture);

		internal static string DeleteValues => LanguageText_cz.ResourceManager.GetString("DeleteValues", LanguageText_cz.resourceCulture);

		internal static string DepthFilterTime => LanguageText_cz.ResourceManager.GetString("DepthFilterTime", LanguageText_cz.resourceCulture);

		internal static string DepthGrad => LanguageText_cz.ResourceManager.GetString("DepthGrad", LanguageText_cz.resourceCulture);

		internal static string DepthGradLength => LanguageText_cz.ResourceManager.GetString("DepthGradLength", LanguageText_cz.resourceCulture);

		internal static string DepthSensor => LanguageText_cz.ResourceManager.GetString("DepthSensor", LanguageText_cz.resourceCulture);

		internal static string DepthSensorInvers => LanguageText_cz.ResourceManager.GetString("DepthSensorInvers", LanguageText_cz.resourceCulture);

		internal static string DGAddress => LanguageText_cz.ResourceManager.GetString("DGAddress", LanguageText_cz.resourceCulture);

		internal static string DHCP => LanguageText_cz.ResourceManager.GetString("DHCP", LanguageText_cz.resourceCulture);

		internal static string DigitalSignal => LanguageText_cz.ResourceManager.GetString("DigitalSignal", LanguageText_cz.resourceCulture);

		internal static string DigitOut => LanguageText_cz.ResourceManager.GetString("DigitOut", LanguageText_cz.resourceCulture);

		internal static string DigSigAtEnd => LanguageText_cz.ResourceManager.GetString("DigSigAtEnd", LanguageText_cz.resourceCulture);

		internal static string DigSigRunning => LanguageText_cz.ResourceManager.GetString("DigSigRunning", LanguageText_cz.resourceCulture);

		internal static string DiscardChanges => LanguageText_cz.ResourceManager.GetString("DiscardChanges", LanguageText_cz.resourceCulture);

		internal static string Done => LanguageText_cz.ResourceManager.GetString("Done", LanguageText_cz.resourceCulture);

		internal static string DriveUnit => LanguageText_cz.ResourceManager.GetString("DriveUnit", LanguageText_cz.resourceCulture);

		internal static string DriveUnitInvers => LanguageText_cz.ResourceManager.GetString("DriveUnitInvers", LanguageText_cz.resourceCulture);

		internal static string Driving => LanguageText_cz.ResourceManager.GetString("Driving", LanguageText_cz.resourceCulture);

		internal static string DrivingStep => LanguageText_cz.ResourceManager.GetString("DrivingStep", LanguageText_cz.resourceCulture);

		internal static string EditCancel => LanguageText_cz.ResourceManager.GetString("EditCancel", LanguageText_cz.resourceCulture);

		internal static string EditEntry => LanguageText_cz.ResourceManager.GetString("EditEntry", LanguageText_cz.resourceCulture);

		internal static string EditProgram => LanguageText_cz.ResourceManager.GetString("EditProgram", LanguageText_cz.resourceCulture);

		internal static string EditStep => LanguageText_cz.ResourceManager.GetString("EditStep", LanguageText_cz.resourceCulture);

		internal static string EMGMode => LanguageText_cz.ResourceManager.GetString("EMGMode", LanguageText_cz.resourceCulture);

		internal static string Empty => LanguageText_cz.ResourceManager.GetString("Empty", LanguageText_cz.resourceCulture);

		internal static string EmptyString => LanguageText_cz.ResourceManager.GetString("EmptyString", LanguageText_cz.resourceCulture);

		internal static string EncError => LanguageText_cz.ResourceManager.GetString("EncError", LanguageText_cz.resourceCulture);

		internal static string English => LanguageText_cz.ResourceManager.GetString("English", LanguageText_cz.resourceCulture);

		internal static string Error1000 => LanguageText_cz.ResourceManager.GetString("Error1000", LanguageText_cz.resourceCulture);

		internal static string Error1001 => LanguageText_cz.ResourceManager.GetString("Error1001", LanguageText_cz.resourceCulture);

		internal static string Error1002 => LanguageText_cz.ResourceManager.GetString("Error1002", LanguageText_cz.resourceCulture);

		internal static string Error1003 => LanguageText_cz.ResourceManager.GetString("Error1003", LanguageText_cz.resourceCulture);

		internal static string Error1004 => LanguageText_cz.ResourceManager.GetString("Error1004", LanguageText_cz.resourceCulture);

		internal static string Error1005 => LanguageText_cz.ResourceManager.GetString("Error1005", LanguageText_cz.resourceCulture);

		internal static string Error1006 => LanguageText_cz.ResourceManager.GetString("Error1006", LanguageText_cz.resourceCulture);

		internal static string Error1007 => LanguageText_cz.ResourceManager.GetString("Error1007", LanguageText_cz.resourceCulture);

		internal static string Error1008 => LanguageText_cz.ResourceManager.GetString("Error1008", LanguageText_cz.resourceCulture);

		internal static string Error1009 => LanguageText_cz.ResourceManager.GetString("Error1009", LanguageText_cz.resourceCulture);

		internal static string Error1010 => LanguageText_cz.ResourceManager.GetString("Error1010", LanguageText_cz.resourceCulture);

		internal static string Error1011 => LanguageText_cz.ResourceManager.GetString("Error1011", LanguageText_cz.resourceCulture);

		internal static string Error1012 => LanguageText_cz.ResourceManager.GetString("Error1012", LanguageText_cz.resourceCulture);

		internal static string Error1013 => LanguageText_cz.ResourceManager.GetString("Error1013", LanguageText_cz.resourceCulture);

		internal static string Error1014 => LanguageText_cz.ResourceManager.GetString("Error1014", LanguageText_cz.resourceCulture);

		internal static string Error1015 => LanguageText_cz.ResourceManager.GetString("Error1015", LanguageText_cz.resourceCulture);

		internal static string Error1016 => LanguageText_cz.ResourceManager.GetString("Error1016", LanguageText_cz.resourceCulture);

		internal static string Error1017 => LanguageText_cz.ResourceManager.GetString("Error1017", LanguageText_cz.resourceCulture);

		internal static string Error1018 => LanguageText_cz.ResourceManager.GetString("Error1018", LanguageText_cz.resourceCulture);

		internal static string Error1019 => LanguageText_cz.ResourceManager.GetString("Error1019", LanguageText_cz.resourceCulture);

		internal static string Error1020 => LanguageText_cz.ResourceManager.GetString("Error1020", LanguageText_cz.resourceCulture);

		internal static string Error1021 => LanguageText_cz.ResourceManager.GetString("Error1021", LanguageText_cz.resourceCulture);

		internal static string Error1022 => LanguageText_cz.ResourceManager.GetString("Error1022", LanguageText_cz.resourceCulture);

		internal static string Error1023 => LanguageText_cz.ResourceManager.GetString("Error1023", LanguageText_cz.resourceCulture);

		internal static string Error1024 => LanguageText_cz.ResourceManager.GetString("Error1024", LanguageText_cz.resourceCulture);

		internal static string Error1025 => LanguageText_cz.ResourceManager.GetString("Error1025", LanguageText_cz.resourceCulture);

		internal static string Error1026 => LanguageText_cz.ResourceManager.GetString("Error1026", LanguageText_cz.resourceCulture);

		internal static string Error1027 => LanguageText_cz.ResourceManager.GetString("Error1027", LanguageText_cz.resourceCulture);

		internal static string Error1028 => LanguageText_cz.ResourceManager.GetString("Error1028", LanguageText_cz.resourceCulture);

		internal static string Error1029 => LanguageText_cz.ResourceManager.GetString("Error1029", LanguageText_cz.resourceCulture);

		internal static string Error1030 => LanguageText_cz.ResourceManager.GetString("Error1030", LanguageText_cz.resourceCulture);

		internal static string Error1031 => LanguageText_cz.ResourceManager.GetString("Error1031", LanguageText_cz.resourceCulture);

		internal static string Error1032 => LanguageText_cz.ResourceManager.GetString("Error1032", LanguageText_cz.resourceCulture);

		internal static string Error1033 => LanguageText_cz.ResourceManager.GetString("Error1033", LanguageText_cz.resourceCulture);

		internal static string Error1034 => LanguageText_cz.ResourceManager.GetString("Error1034", LanguageText_cz.resourceCulture);

		internal static string Error1035 => LanguageText_cz.ResourceManager.GetString("Error1035", LanguageText_cz.resourceCulture);

		internal static string Error1036 => LanguageText_cz.ResourceManager.GetString("Error1036", LanguageText_cz.resourceCulture);

		internal static string Error1037 => LanguageText_cz.ResourceManager.GetString("Error1037", LanguageText_cz.resourceCulture);

		internal static string Error1038 => LanguageText_cz.ResourceManager.GetString("Error1038", LanguageText_cz.resourceCulture);

		internal static string Error1100 => LanguageText_cz.ResourceManager.GetString("Error1100", LanguageText_cz.resourceCulture);

		internal static string Error1101 => LanguageText_cz.ResourceManager.GetString("Error1101", LanguageText_cz.resourceCulture);

		internal static string Error1102 => LanguageText_cz.ResourceManager.GetString("Error1102", LanguageText_cz.resourceCulture);

		internal static string Error1110 => LanguageText_cz.ResourceManager.GetString("Error1110", LanguageText_cz.resourceCulture);

		internal static string Error1111 => LanguageText_cz.ResourceManager.GetString("Error1111", LanguageText_cz.resourceCulture);

		internal static string Error1112 => LanguageText_cz.ResourceManager.GetString("Error1112", LanguageText_cz.resourceCulture);

		internal static string Error1113 => LanguageText_cz.ResourceManager.GetString("Error1113", LanguageText_cz.resourceCulture);

		internal static string Error1114 => LanguageText_cz.ResourceManager.GetString("Error1114", LanguageText_cz.resourceCulture);

		internal static string Error1140 => LanguageText_cz.ResourceManager.GetString("Error1140", LanguageText_cz.resourceCulture);

		internal static string Error1141 => LanguageText_cz.ResourceManager.GetString("Error1141", LanguageText_cz.resourceCulture);

		internal static string Error1150 => LanguageText_cz.ResourceManager.GetString("Error1150", LanguageText_cz.resourceCulture);

		internal static string Error1151 => LanguageText_cz.ResourceManager.GetString("Error1151", LanguageText_cz.resourceCulture);

		internal static string Error1152 => LanguageText_cz.ResourceManager.GetString("Error1152", LanguageText_cz.resourceCulture);

		internal static string Error1153 => LanguageText_cz.ResourceManager.GetString("Error1153", LanguageText_cz.resourceCulture);

		internal static string Error1160 => LanguageText_cz.ResourceManager.GetString("Error1160", LanguageText_cz.resourceCulture);

		internal static string Error1161 => LanguageText_cz.ResourceManager.GetString("Error1161", LanguageText_cz.resourceCulture);

		internal static string Error1162 => LanguageText_cz.ResourceManager.GetString("Error1162", LanguageText_cz.resourceCulture);

		internal static string Error1163 => LanguageText_cz.ResourceManager.GetString("Error1163", LanguageText_cz.resourceCulture);

		internal static string Error1200 => LanguageText_cz.ResourceManager.GetString("Error1200", LanguageText_cz.resourceCulture);

		internal static string Error1201 => LanguageText_cz.ResourceManager.GetString("Error1201", LanguageText_cz.resourceCulture);

		internal static string Error1202 => LanguageText_cz.ResourceManager.GetString("Error1202", LanguageText_cz.resourceCulture);

		internal static string Error1203 => LanguageText_cz.ResourceManager.GetString("Error1203", LanguageText_cz.resourceCulture);

		internal static string Error1301 => LanguageText_cz.ResourceManager.GetString("Error1301", LanguageText_cz.resourceCulture);

		internal static string Error1302 => LanguageText_cz.ResourceManager.GetString("Error1302", LanguageText_cz.resourceCulture);

		internal static string Error1303 => LanguageText_cz.ResourceManager.GetString("Error1303", LanguageText_cz.resourceCulture);

		internal static string Error1304 => LanguageText_cz.ResourceManager.GetString("Error1304", LanguageText_cz.resourceCulture);

		internal static string Error1305 => LanguageText_cz.ResourceManager.GetString("Error1305", LanguageText_cz.resourceCulture);

		internal static string Error1400 => LanguageText_cz.ResourceManager.GetString("Error1400", LanguageText_cz.resourceCulture);

		internal static string Error1401 => LanguageText_cz.ResourceManager.GetString("Error1401", LanguageText_cz.resourceCulture);

		internal static string Error1402 => LanguageText_cz.ResourceManager.GetString("Error1402", LanguageText_cz.resourceCulture);

		internal static string Error1403 => LanguageText_cz.ResourceManager.GetString("Error1403", LanguageText_cz.resourceCulture);

		internal static string Error1404 => LanguageText_cz.ResourceManager.GetString("Error1404", LanguageText_cz.resourceCulture);

		internal static string Error1405 => LanguageText_cz.ResourceManager.GetString("Error1405", LanguageText_cz.resourceCulture);

		internal static string Error1406 => LanguageText_cz.ResourceManager.GetString("Error1406", LanguageText_cz.resourceCulture);

		internal static string Error1407 => LanguageText_cz.ResourceManager.GetString("Error1407", LanguageText_cz.resourceCulture);

		internal static string Error1450 => LanguageText_cz.ResourceManager.GetString("Error1450", LanguageText_cz.resourceCulture);

		internal static string Error1451 => LanguageText_cz.ResourceManager.GetString("Error1451", LanguageText_cz.resourceCulture);

		internal static string Error1600 => LanguageText_cz.ResourceManager.GetString("Error1600", LanguageText_cz.resourceCulture);

		internal static string Error1601 => LanguageText_cz.ResourceManager.GetString("Error1601", LanguageText_cz.resourceCulture);

		internal static string Error1602 => LanguageText_cz.ResourceManager.GetString("Error1602", LanguageText_cz.resourceCulture);

		internal static string Error2000 => LanguageText_cz.ResourceManager.GetString("Error2000", LanguageText_cz.resourceCulture);

		internal static string Error2001 => LanguageText_cz.ResourceManager.GetString("Error2001", LanguageText_cz.resourceCulture);

		internal static string Error2002 => LanguageText_cz.ResourceManager.GetString("Error2002", LanguageText_cz.resourceCulture);

		internal static string Error2003 => LanguageText_cz.ResourceManager.GetString("Error2003", LanguageText_cz.resourceCulture);

		internal static string Error2004 => LanguageText_cz.ResourceManager.GetString("Error2004", LanguageText_cz.resourceCulture);

		internal static string Error2005 => LanguageText_cz.ResourceManager.GetString("Error2005", LanguageText_cz.resourceCulture);

		internal static string Error2006 => LanguageText_cz.ResourceManager.GetString("Error2006", LanguageText_cz.resourceCulture);

		internal static string Error2007 => LanguageText_cz.ResourceManager.GetString("Error2007", LanguageText_cz.resourceCulture);

		internal static string Error2008 => LanguageText_cz.ResourceManager.GetString("Error2008", LanguageText_cz.resourceCulture);

		internal static string Error2009 => LanguageText_cz.ResourceManager.GetString("Error2009", LanguageText_cz.resourceCulture);

		internal static string Error2010 => LanguageText_cz.ResourceManager.GetString("Error2010", LanguageText_cz.resourceCulture);

		internal static string Error2011 => LanguageText_cz.ResourceManager.GetString("Error2011", LanguageText_cz.resourceCulture);

		internal static string Error2012 => LanguageText_cz.ResourceManager.GetString("Error2012", LanguageText_cz.resourceCulture);

		internal static string Error2013 => LanguageText_cz.ResourceManager.GetString("Error2013", LanguageText_cz.resourceCulture);

		internal static string Error2014 => LanguageText_cz.ResourceManager.GetString("Error2014", LanguageText_cz.resourceCulture);

		internal static string Error2015 => LanguageText_cz.ResourceManager.GetString("Error2015", LanguageText_cz.resourceCulture);

		internal static string Error2016 => LanguageText_cz.ResourceManager.GetString("Error2016", LanguageText_cz.resourceCulture);

		internal static string Error2017 => LanguageText_cz.ResourceManager.GetString("Error2017", LanguageText_cz.resourceCulture);

		internal static string Error2018 => LanguageText_cz.ResourceManager.GetString("Error2018", LanguageText_cz.resourceCulture);

		internal static string Error2019 => LanguageText_cz.ResourceManager.GetString("Error2019", LanguageText_cz.resourceCulture);

		internal static string Error2020 => LanguageText_cz.ResourceManager.GetString("Error2020", LanguageText_cz.resourceCulture);

		internal static string Error2021 => LanguageText_cz.ResourceManager.GetString("Error2021", LanguageText_cz.resourceCulture);

		internal static string Error2022 => LanguageText_cz.ResourceManager.GetString("Error2022", LanguageText_cz.resourceCulture);

		internal static string Error2100 => LanguageText_cz.ResourceManager.GetString("Error2100", LanguageText_cz.resourceCulture);

		internal static string Error5000 => LanguageText_cz.ResourceManager.GetString("Error5000", LanguageText_cz.resourceCulture);

		internal static string ErrorCode => LanguageText_cz.ResourceManager.GetString("ErrorCode", LanguageText_cz.resourceCulture);

		internal static string ErrorLog => LanguageText_cz.ResourceManager.GetString("ErrorLog", LanguageText_cz.resourceCulture);

		internal static string ErrorMode => LanguageText_cz.ResourceManager.GetString("ErrorMode", LanguageText_cz.resourceCulture);

		internal static string ErrorNumber => LanguageText_cz.ResourceManager.GetString("ErrorNumber", LanguageText_cz.resourceCulture);

		internal static string ErrorQuitEMG => LanguageText_cz.ResourceManager.GetString("ErrorQuitEMG", LanguageText_cz.resourceCulture);

		internal static string EuropeanTime => LanguageText_cz.ResourceManager.GetString("EuropeanTime", LanguageText_cz.resourceCulture);

		internal static string Even => LanguageText_cz.ResourceManager.GetString("Even", LanguageText_cz.resourceCulture);

		internal static string Exit => LanguageText_cz.ResourceManager.GetString("Exit", LanguageText_cz.resourceCulture);

		internal static string Export => LanguageText_cz.ResourceManager.GetString("Export", LanguageText_cz.resourceCulture);

		internal static string ExportLastResults => LanguageText_cz.ResourceManager.GetString("ExportLastResults", LanguageText_cz.resourceCulture);

		internal static string ExportLogbook => LanguageText_cz.ResourceManager.GetString("ExportLogbook", LanguageText_cz.resourceCulture);

		internal static string FileOperation => LanguageText_cz.ResourceManager.GetString("FileOperation", LanguageText_cz.resourceCulture);

		internal static string FileOperationMenu => LanguageText_cz.ResourceManager.GetString("FileOperationMenu", LanguageText_cz.resourceCulture);

		internal static string FilteredTorque => LanguageText_cz.ResourceManager.GetString("FilteredTorque", LanguageText_cz.resourceCulture);

		internal static string Finalizing => LanguageText_cz.ResourceManager.GetString("Finalizing", LanguageText_cz.resourceCulture);

		internal static string FinalizingStep => LanguageText_cz.ResourceManager.GetString("FinalizingStep", LanguageText_cz.resourceCulture);

		internal static string ForceSignals => LanguageText_cz.ResourceManager.GetString("ForceSignals", LanguageText_cz.resourceCulture);

		internal static string French => LanguageText_cz.ResourceManager.GetString("French", LanguageText_cz.resourceCulture);

		internal static string FrictionSpeed => LanguageText_cz.ResourceManager.GetString("FrictionSpeed", LanguageText_cz.resourceCulture);

		internal static string FrictionTest => LanguageText_cz.ResourceManager.GetString("FrictionTest", LanguageText_cz.resourceCulture);

		internal static string FrictionTestEMG => LanguageText_cz.ResourceManager.GetString("FrictionTestEMG", LanguageText_cz.resourceCulture);

		internal static string FrictionTestStartup => LanguageText_cz.ResourceManager.GetString("FrictionTestStartup", LanguageText_cz.resourceCulture);

		internal static string FrictionTorque => LanguageText_cz.ResourceManager.GetString("FrictionTorque", LanguageText_cz.resourceCulture);

		internal static string FromAbove => LanguageText_cz.ResourceManager.GetString("FromAbove", LanguageText_cz.resourceCulture);

		internal static string FromAboveOverload => LanguageText_cz.ResourceManager.GetString("FromAboveOverload", LanguageText_cz.resourceCulture);

		internal static string gBAnaSignal => LanguageText_cz.ResourceManager.GetString("gBAnaSignal", LanguageText_cz.resourceCulture);

		internal static string gBDateTime => LanguageText_cz.ResourceManager.GetString("gBDateTime", LanguageText_cz.resourceCulture);

		internal static string gBError => LanguageText_cz.ResourceManager.GetString("gBError", LanguageText_cz.resourceCulture);

		internal static string gBIdentity => LanguageText_cz.ResourceManager.GetString("gBIdentity", LanguageText_cz.resourceCulture);

		internal static string gBIP => LanguageText_cz.ResourceManager.GetString("gBIP", LanguageText_cz.resourceCulture);

		internal static string gBLoadBackup => LanguageText_cz.ResourceManager.GetString("gBLoadBackup", LanguageText_cz.resourceCulture);

		internal static string gBPressure => LanguageText_cz.ResourceManager.GetString("gBPressure", LanguageText_cz.resourceCulture);

		internal static string gBRedundantSensor => LanguageText_cz.ResourceManager.GetString("gBRedundantSensor", LanguageText_cz.resourceCulture);

		internal static string gBResultDisplay => LanguageText_cz.ResourceManager.GetString("gBResultDisplay", LanguageText_cz.resourceCulture);

		internal static string gBRs232 => LanguageText_cz.ResourceManager.GetString("gBRs232", LanguageText_cz.resourceCulture);

		internal static string gBSaveBackup => LanguageText_cz.ResourceManager.GetString("gBSaveBackup", LanguageText_cz.resourceCulture);

		internal static string gBSpindle => LanguageText_cz.ResourceManager.GetString("gBSpindle", LanguageText_cz.resourceCulture);

		internal static string GearFactor => LanguageText_cz.ResourceManager.GetString("GearFactor", LanguageText_cz.resourceCulture);

		internal static string German => LanguageText_cz.ResourceManager.GetString("German", LanguageText_cz.resourceCulture);

		internal static string GetCurve => LanguageText_cz.ResourceManager.GetString("GetCurve", LanguageText_cz.resourceCulture);

		internal static string GetRpm => LanguageText_cz.ResourceManager.GetString("GetRpm", LanguageText_cz.resourceCulture);

		internal static string GoWithoutPassCode => LanguageText_cz.ResourceManager.GetString("GoWithoutPassCode", LanguageText_cz.resourceCulture);

		internal static string GradFilter => LanguageText_cz.ResourceManager.GetString("GradFilter", LanguageText_cz.resourceCulture);

		internal static string Gradient => LanguageText_cz.ResourceManager.GetString("Gradient", LanguageText_cz.resourceCulture);

		internal static string GradientLength => LanguageText_cz.ResourceManager.GetString("GradientLength", LanguageText_cz.resourceCulture);

		internal static string HandMode => LanguageText_cz.ResourceManager.GetString("HandMode", LanguageText_cz.resourceCulture);

		internal static string HandStart => LanguageText_cz.ResourceManager.GetString("HandStart", LanguageText_cz.resourceCulture);

		internal static string HandStartIsInitiated => LanguageText_cz.ResourceManager.GetString("HandStartIsInitiated", LanguageText_cz.resourceCulture);

		internal static string Help => LanguageText_cz.ResourceManager.GetString("Help", LanguageText_cz.resourceCulture);

		internal static string HexSwitch => LanguageText_cz.ResourceManager.GetString("HexSwitch", LanguageText_cz.resourceCulture);

		internal static string Hold => LanguageText_cz.ResourceManager.GetString("Hold", LanguageText_cz.resourceCulture);

		internal static string Holder => LanguageText_cz.ResourceManager.GetString("Holder", LanguageText_cz.resourceCulture);

		internal static string HolderPressureScale => LanguageText_cz.ResourceManager.GetString("HolderPressureScale", LanguageText_cz.resourceCulture);

		internal static string IdentServer => LanguageText_cz.ResourceManager.GetString("IdentServer", LanguageText_cz.resourceCulture);

		internal static string Increment => LanguageText_cz.ResourceManager.GetString("Increment", LanguageText_cz.resourceCulture);

		internal static string Inputs => LanguageText_cz.ResourceManager.GetString("Inputs", LanguageText_cz.resourceCulture);

		internal static string InsertProgram => LanguageText_cz.ResourceManager.GetString("InsertProgram", LanguageText_cz.resourceCulture);

		internal static string InsertStep => LanguageText_cz.ResourceManager.GetString("InsertStep", LanguageText_cz.resourceCulture);

		internal static string IntegratedTests => LanguageText_cz.ResourceManager.GetString("IntegratedTests", LanguageText_cz.resourceCulture);

		internal static string IONumber => LanguageText_cz.ResourceManager.GetString("IONumber", LanguageText_cz.resourceCulture);

		internal static string IOTest => LanguageText_cz.ResourceManager.GetString("IOTest", LanguageText_cz.resourceCulture);

		internal static string IPAddress => LanguageText_cz.ResourceManager.GetString("IPAddress", LanguageText_cz.resourceCulture);

		internal static string Italian => LanguageText_cz.ResourceManager.GetString("Italian", LanguageText_cz.resourceCulture);

		internal static string JumpAlwaysTo => LanguageText_cz.ResourceManager.GetString("JumpAlwaysTo", LanguageText_cz.resourceCulture);

		internal static string JumpNokTo => LanguageText_cz.ResourceManager.GetString("JumpNokTo", LanguageText_cz.resourceCulture);

		internal static string JumpOkTo => LanguageText_cz.ResourceManager.GetString("JumpOkTo", LanguageText_cz.resourceCulture);

		internal static string JumpTo => LanguageText_cz.ResourceManager.GetString("JumpTo", LanguageText_cz.resourceCulture);

		internal static string KeyPad => LanguageText_cz.ResourceManager.GetString("KeyPad", LanguageText_cz.resourceCulture);

		internal static string Kind => LanguageText_cz.ResourceManager.GetString("Kind", LanguageText_cz.resourceCulture);

		internal static string Language => LanguageText_cz.ResourceManager.GetString("Language", LanguageText_cz.resourceCulture);

		internal static string LastDoneStep => LanguageText_cz.ResourceManager.GetString("LastDoneStep", LanguageText_cz.resourceCulture);

		internal static string LastNIO => LanguageText_cz.ResourceManager.GetString("LastNIO", LanguageText_cz.resourceCulture);

		internal static string LastResults => LanguageText_cz.ResourceManager.GetString("LastResults", LanguageText_cz.resourceCulture);

		internal static string LeftAngle => LanguageText_cz.ResourceManager.GetString("LeftAngle", LanguageText_cz.resourceCulture);

		internal static string LevelAdministrator => LanguageText_cz.ResourceManager.GetString("LevelAdministrator", LanguageText_cz.resourceCulture);

		internal static string LevelProgramer => LanguageText_cz.ResourceManager.GetString("LevelProgramer", LanguageText_cz.resourceCulture);

		internal static string LevelUser => LanguageText_cz.ResourceManager.GetString("LevelUser", LanguageText_cz.resourceCulture);

		internal static string LivingMonitor => LanguageText_cz.ResourceManager.GetString("LivingMonitor", LanguageText_cz.resourceCulture);

		internal static string LivingSign => LanguageText_cz.ResourceManager.GetString("LivingSign", LanguageText_cz.resourceCulture);

		internal static string LoadCurveData => LanguageText_cz.ResourceManager.GetString("LoadCurveData", LanguageText_cz.resourceCulture);

		internal static string LoadCurveDataFromFile => LanguageText_cz.ResourceManager.GetString("LoadCurveDataFromFile", LanguageText_cz.resourceCulture);

		internal static string LoadCustBackup => LanguageText_cz.ResourceManager.GetString("LoadCustBackup", LanguageText_cz.resourceCulture);

		internal static string LoadCustBackupFromCF => LanguageText_cz.ResourceManager.GetString("LoadCustBackupFromCF", LanguageText_cz.resourceCulture);

		internal static string LoadCustBackupSecQuery => LanguageText_cz.ResourceManager.GetString("LoadCustBackupSecQuery", LanguageText_cz.resourceCulture);

		internal static string LoadCycleCount => LanguageText_cz.ResourceManager.GetString("LoadCycleCount", LanguageText_cz.resourceCulture);

		internal static string LoadFromFile => LanguageText_cz.ResourceManager.GetString("LoadFromFile", LanguageText_cz.resourceCulture);

		internal static string LoadIO => LanguageText_cz.ResourceManager.GetString("LoadIO", LanguageText_cz.resourceCulture);

		internal static string LoadLastNIOResults => LanguageText_cz.ResourceManager.GetString("LoadLastNIOResults", LanguageText_cz.resourceCulture);

		internal static string LoadLastResults => LanguageText_cz.ResourceManager.GetString("LoadLastResults", LanguageText_cz.resourceCulture);

		internal static string LoadLogBookData => LanguageText_cz.ResourceManager.GetString("LoadLogBookData", LanguageText_cz.resourceCulture);

		internal static string LoadPLCIO => LanguageText_cz.ResourceManager.GetString("LoadPLCIO", LanguageText_cz.resourceCulture);

		internal static string LoadPProgFromFile => LanguageText_cz.ResourceManager.GetString("LoadPProgFromFile", LanguageText_cz.resourceCulture);

		internal static string LoadProcessInfo => LanguageText_cz.ResourceManager.GetString("LoadProcessInfo", LanguageText_cz.resourceCulture);

		internal static string LoadProgramData => LanguageText_cz.ResourceManager.GetString("LoadProgramData", LanguageText_cz.resourceCulture);

		internal static string LoadProgramDataLocally => LanguageText_cz.ResourceManager.GetString("LoadProgramDataLocally", LanguageText_cz.resourceCulture);

		internal static string LoadRecursiveStat => LanguageText_cz.ResourceManager.GetString("LoadRecursiveStat", LanguageText_cz.resourceCulture);

		internal static string LoadResults => LanguageText_cz.ResourceManager.GetString("LoadResults", LanguageText_cz.resourceCulture);

		internal static string LoadSingleProgFromFile => LanguageText_cz.ResourceManager.GetString("LoadSingleProgFromFile", LanguageText_cz.resourceCulture);

		internal static string LoadSpindleConst => LanguageText_cz.ResourceManager.GetString("LoadSpindleConst", LanguageText_cz.resourceCulture);

		internal static string LoadSpindleDataLocally => LanguageText_cz.ResourceManager.GetString("LoadSpindleDataLocally", LanguageText_cz.resourceCulture);

		internal static string LoadSystemConst => LanguageText_cz.ResourceManager.GetString("LoadSystemConst", LanguageText_cz.resourceCulture);

		internal static string LoadWebBackupSecQuery => LanguageText_cz.ResourceManager.GetString("LoadWebBackupSecQuery", LanguageText_cz.resourceCulture);

		internal static string LoadWeberBackup => LanguageText_cz.ResourceManager.GetString("LoadWeberBackup", LanguageText_cz.resourceCulture);

		internal static string LoadWeberBackupFromCF => LanguageText_cz.ResourceManager.GetString("LoadWeberBackupFromCF", LanguageText_cz.resourceCulture);

		internal static string LocalTime => LanguageText_cz.ResourceManager.GetString("LocalTime", LanguageText_cz.resourceCulture);

		internal static string LogBook => LanguageText_cz.ResourceManager.GetString("LogBook", LanguageText_cz.resourceCulture);

		internal static string LogBookMessage100000 => LanguageText_cz.ResourceManager.GetString("LogBookMessage100000", LanguageText_cz.resourceCulture);

		internal static string LogBookMessage200000 => LanguageText_cz.ResourceManager.GetString("LogBookMessage200000", LanguageText_cz.resourceCulture);

		internal static string LogBookMessage300000 => LanguageText_cz.ResourceManager.GetString("LogBookMessage300000", LanguageText_cz.resourceCulture);

		internal static string LogBookMessage300001 => LanguageText_cz.ResourceManager.GetString("LogBookMessage300001", LanguageText_cz.resourceCulture);

		internal static string LogBookTable => LanguageText_cz.ResourceManager.GetString("LogBookTable", LanguageText_cz.resourceCulture);

		internal static string Login => LanguageText_cz.ResourceManager.GetString("Login", LanguageText_cz.resourceCulture);

		internal static string LowerLimit => LanguageText_cz.ResourceManager.GetString("LowerLimit", LanguageText_cz.resourceCulture);

		internal static string M1FilterTime => LanguageText_cz.ResourceManager.GetString("M1FilterTime", LanguageText_cz.resourceCulture);

		internal static string M360Follow => LanguageText_cz.ResourceManager.GetString("M360Follow", LanguageText_cz.resourceCulture);

		internal static string MachineCounter => LanguageText_cz.ResourceManager.GetString("MachineCounter", LanguageText_cz.resourceCulture);

		internal static string MachineVisu => LanguageText_cz.ResourceManager.GetString("MachineVisu", LanguageText_cz.resourceCulture);

		internal static string MakeNewEntry => LanguageText_cz.ResourceManager.GetString("MakeNewEntry", LanguageText_cz.resourceCulture);

		internal static string Max => LanguageText_cz.ResourceManager.GetString("Max", LanguageText_cz.resourceCulture);

		internal static string MaxFrictionTorque => LanguageText_cz.ResourceManager.GetString("MaxFrictionTorque", LanguageText_cz.resourceCulture);

		internal static string MaxRpm => LanguageText_cz.ResourceManager.GetString("MaxRpm", LanguageText_cz.resourceCulture);

		internal static string MaxSaveCurveNum => LanguageText_cz.ResourceManager.GetString("MaxSaveCurveNum", LanguageText_cz.resourceCulture);

		internal static string MaxScrewTime => LanguageText_cz.ResourceManager.GetString("MaxScrewTime", LanguageText_cz.resourceCulture);

		internal static string MaxTorque => LanguageText_cz.ResourceManager.GetString("MaxTorque", LanguageText_cz.resourceCulture);

		internal static string MbAccessByAnother => LanguageText_cz.ResourceManager.GetString("MbAccessByAnother", LanguageText_cz.resourceCulture);

		internal static string MbAccessNotPossible => LanguageText_cz.ResourceManager.GetString("MbAccessNotPossible", LanguageText_cz.resourceCulture);

		internal static string MbAccessRequestTwice => LanguageText_cz.ResourceManager.GetString("MbAccessRequestTwice", LanguageText_cz.resourceCulture);

		internal static string MBackup => LanguageText_cz.ResourceManager.GetString("MBackup", LanguageText_cz.resourceCulture);

		internal static string MbAddNoFrictionTest => LanguageText_cz.ResourceManager.GetString("MbAddNoFrictionTest", LanguageText_cz.resourceCulture);

		internal static string MbAddNoManual => LanguageText_cz.ResourceManager.GetString("MbAddNoManual", LanguageText_cz.resourceCulture);

		internal static string MbAddNoTest => LanguageText_cz.ResourceManager.GetString("MbAddNoTest", LanguageText_cz.resourceCulture);

		internal static string MbAddParamViewOnly => LanguageText_cz.ResourceManager.GetString("MbAddParamViewOnly", LanguageText_cz.resourceCulture);

		internal static string MbAutomaticIsActive1 => LanguageText_cz.ResourceManager.GetString("MbAutomaticIsActive1", LanguageText_cz.resourceCulture);

		internal static string MbAutomaticIsActive2 => LanguageText_cz.ResourceManager.GetString("MbAutomaticIsActive2", LanguageText_cz.resourceCulture);

		internal static string MbComandTimeOut => LanguageText_cz.ResourceManager.GetString("MbComandTimeOut", LanguageText_cz.resourceCulture);

		internal static string MbCreateDefaultPasscode => LanguageText_cz.ResourceManager.GetString("MbCreateDefaultPasscode", LanguageText_cz.resourceCulture);

		internal static string MbCurveLoadFailure => LanguageText_cz.ResourceManager.GetString("MbCurveLoadFailure", LanguageText_cz.resourceCulture);

		internal static string MbCurveSaveFailure => LanguageText_cz.ResourceManager.GetString("MbCurveSaveFailure", LanguageText_cz.resourceCulture);

		internal static string MbDeleteCounterFailure => LanguageText_cz.ResourceManager.GetString("MbDeleteCounterFailure", LanguageText_cz.resourceCulture);

		internal static string MbDeleteCustomCounter => LanguageText_cz.ResourceManager.GetString("MbDeleteCustomCounter", LanguageText_cz.resourceCulture);

		internal static string MbDeleteLastResFailure => LanguageText_cz.ResourceManager.GetString("MbDeleteLastResFailure", LanguageText_cz.resourceCulture);

		internal static string MbDeleteLastResults => LanguageText_cz.ResourceManager.GetString("MbDeleteLastResults", LanguageText_cz.resourceCulture);

		internal static string MbDeleteProg => LanguageText_cz.ResourceManager.GetString("MbDeleteProg", LanguageText_cz.resourceCulture);

		internal static string MbDeleteRecStatFailure => LanguageText_cz.ResourceManager.GetString("MbDeleteRecStatFailure", LanguageText_cz.resourceCulture);

		internal static string MbDeleteRecursiveStat => LanguageText_cz.ResourceManager.GetString("MbDeleteRecursiveStat", LanguageText_cz.resourceCulture);

		internal static string MbDeleteStatAfterProgChange => LanguageText_cz.ResourceManager.GetString("MbDeleteStatAfterProgChange", LanguageText_cz.resourceCulture);

		internal static string MbDoubleEntryCodeFound => LanguageText_cz.ResourceManager.GetString("MbDoubleEntryCodeFound", LanguageText_cz.resourceCulture);

		internal static string MbEmptyProgram => LanguageText_cz.ResourceManager.GetString("MbEmptyProgram", LanguageText_cz.resourceCulture);

		internal static string MbErrorQuitFailure => LanguageText_cz.ResourceManager.GetString("MbErrorQuitFailure", LanguageText_cz.resourceCulture);

		internal static string MbExit => LanguageText_cz.ResourceManager.GetString("MbExit", LanguageText_cz.resourceCulture);

		internal static string MbGotNoConnection => LanguageText_cz.ResourceManager.GetString("MbGotNoConnection", LanguageText_cz.resourceCulture);

		internal static string MbHandstartIsActive => LanguageText_cz.ResourceManager.GetString("MbHandstartIsActive", LanguageText_cz.resourceCulture);

		internal static string MbHandstartNotTwice => LanguageText_cz.ResourceManager.GetString("MbHandstartNotTwice", LanguageText_cz.resourceCulture);

		internal static string MbhError => LanguageText_cz.ResourceManager.GetString("MbhError", LanguageText_cz.resourceCulture);

		internal static string MbhHint => LanguageText_cz.ResourceManager.GetString("MbhHint", LanguageText_cz.resourceCulture);

		internal static string MbhNoAccess => LanguageText_cz.ResourceManager.GetString("MbhNoAccess", LanguageText_cz.resourceCulture);

		internal static string MbhSecurityQuery => LanguageText_cz.ResourceManager.GetString("MbhSecurityQuery", LanguageText_cz.resourceCulture);

		internal static string MbhViewOnlyMode => LanguageText_cz.ResourceManager.GetString("MbhViewOnlyMode", LanguageText_cz.resourceCulture);

		internal static string MbIPChange => LanguageText_cz.ResourceManager.GetString("MbIPChange", LanguageText_cz.resourceCulture);

		internal static string MbKeyLockActive => LanguageText_cz.ResourceManager.GetString("MbKeyLockActive", LanguageText_cz.resourceCulture);

		internal static string MbLoadCustBackupFailure => LanguageText_cz.ResourceManager.GetString("MbLoadCustBackupFailure", LanguageText_cz.resourceCulture);

		internal static string MbLoadWeberBackupFailure => LanguageText_cz.ResourceManager.GetString("MbLoadWeberBackupFailure", LanguageText_cz.resourceCulture);

		internal static string MbLocationError => LanguageText_cz.ResourceManager.GetString("MbLocationError", LanguageText_cz.resourceCulture);

		internal static string MbLogbookWriteFailure => LanguageText_cz.ResourceManager.GetString("MbLogbookWriteFailure", LanguageText_cz.resourceCulture);

		internal static string MbMaxPasscodeNum1 => LanguageText_cz.ResourceManager.GetString("MbMaxPasscodeNum1", LanguageText_cz.resourceCulture);

		internal static string MbMaxPasscodeNum2 => LanguageText_cz.ResourceManager.GetString("MbMaxPasscodeNum2", LanguageText_cz.resourceCulture);

		internal static string MbNoAccess => LanguageText_cz.ResourceManager.GetString("MbNoAccess", LanguageText_cz.resourceCulture);

		internal static string MbNoAccessCauseAuto => LanguageText_cz.ResourceManager.GetString("MbNoAccessCauseAuto", LanguageText_cz.resourceCulture);

		internal static string MbNoConnection => LanguageText_cz.ResourceManager.GetString("MbNoConnection", LanguageText_cz.resourceCulture);

		internal static string MbNoTestCauseAuto => LanguageText_cz.ResourceManager.GetString("MbNoTestCauseAuto", LanguageText_cz.resourceCulture);

		internal static string MbOfflineMode => LanguageText_cz.ResourceManager.GetString("MbOfflineMode", LanguageText_cz.resourceCulture);

		internal static string MbOldPProgLoad => LanguageText_cz.ResourceManager.GetString("MbOldPProgLoad", LanguageText_cz.resourceCulture);

		internal static string MbOldProgLoad => LanguageText_cz.ResourceManager.GetString("MbOldProgLoad", LanguageText_cz.resourceCulture);

		internal static string MbOverwriteProg => LanguageText_cz.ResourceManager.GetString("MbOverwriteProg", LanguageText_cz.resourceCulture);

		internal static string MbPasscodeFailure1 => LanguageText_cz.ResourceManager.GetString("MbPasscodeFailure1", LanguageText_cz.resourceCulture);

		internal static string MbPasscodeFailure2 => LanguageText_cz.ResourceManager.GetString("MbPasscodeFailure2", LanguageText_cz.resourceCulture);

		internal static string MbPasscodeFailure3 => LanguageText_cz.ResourceManager.GetString("MbPasscodeFailure3", LanguageText_cz.resourceCulture);

		internal static string MbPasscodeFailure4 => LanguageText_cz.ResourceManager.GetString("MbPasscodeFailure4", LanguageText_cz.resourceCulture);

		internal static string MbPProgCopyFailure => LanguageText_cz.ResourceManager.GetString("MbPProgCopyFailure", LanguageText_cz.resourceCulture);

		internal static string MbPProgLoadFromFileFailure => LanguageText_cz.ResourceManager.GetString("MbPProgLoadFromFileFailure", LanguageText_cz.resourceCulture);

		internal static string MbPProgSaveToFileFailure => LanguageText_cz.ResourceManager.GetString("MbPProgSaveToFileFailure", LanguageText_cz.resourceCulture);

		internal static string MbProgramCopyFailure => LanguageText_cz.ResourceManager.GetString("MbProgramCopyFailure", LanguageText_cz.resourceCulture);

		internal static string MbProgramEmptySaveAnyway => LanguageText_cz.ResourceManager.GetString("MbProgramEmptySaveAnyway", LanguageText_cz.resourceCulture);

		internal static string MbSaveCustBackupFailure => LanguageText_cz.ResourceManager.GetString("MbSaveCustBackupFailure", LanguageText_cz.resourceCulture);

		internal static string MbSaveDataLocally => LanguageText_cz.ResourceManager.GetString("MbSaveDataLocally", LanguageText_cz.resourceCulture);

		internal static string MbSavedProgramDataToFile => LanguageText_cz.ResourceManager.GetString("MbSavedProgramDataToFile", LanguageText_cz.resourceCulture);

		internal static string MbSavedSpindleDataToFile => LanguageText_cz.ResourceManager.GetString("MbSavedSpindleDataToFile", LanguageText_cz.resourceCulture);

		internal static string MbSaveNotVerifiedData => LanguageText_cz.ResourceManager.GetString("MbSaveNotVerifiedData", LanguageText_cz.resourceCulture);

		internal static string MbSavePasscodeFailure => LanguageText_cz.ResourceManager.GetString("MbSavePasscodeFailure", LanguageText_cz.resourceCulture);

		internal static string MbSaveProgFailure => LanguageText_cz.ResourceManager.GetString("MbSaveProgFailure", LanguageText_cz.resourceCulture);

		internal static string MbSaveProgOnCPUFailure => LanguageText_cz.ResourceManager.GetString("MbSaveProgOnCPUFailure", LanguageText_cz.resourceCulture);

		internal static string MbSaveSpConstFailure => LanguageText_cz.ResourceManager.GetString("MbSaveSpConstFailure", LanguageText_cz.resourceCulture);

		internal static string MbSaveSysConstFailure => LanguageText_cz.ResourceManager.GetString("MbSaveSysConstFailure", LanguageText_cz.resourceCulture);

		internal static string MbSaveWeberBackupFailure => LanguageText_cz.ResourceManager.GetString("MbSaveWeberBackupFailure", LanguageText_cz.resourceCulture);

		internal static string MbShortNameFailure1 => LanguageText_cz.ResourceManager.GetString("MbShortNameFailure1", LanguageText_cz.resourceCulture);

		internal static string MbShortNameFailure2 => LanguageText_cz.ResourceManager.GetString("MbShortNameFailure2", LanguageText_cz.resourceCulture);

		internal static string MbShortNameFailure3 => LanguageText_cz.ResourceManager.GetString("MbShortNameFailure3", LanguageText_cz.resourceCulture);

		internal static string MbSpindleCopyFailure => LanguageText_cz.ResourceManager.GetString("MbSpindleCopyFailure", LanguageText_cz.resourceCulture);

		internal static string MbSpindleLoadFromFileFailure => LanguageText_cz.ResourceManager.GetString("MbSpindleLoadFromFileFailure", LanguageText_cz.resourceCulture);

		internal static string MbSpindleSaveToFileFailure => LanguageText_cz.ResourceManager.GetString("MbSpindleSaveToFileFailure", LanguageText_cz.resourceCulture);

		internal static string MbStepCopyFailure => LanguageText_cz.ResourceManager.GetString("MbStepCopyFailure", LanguageText_cz.resourceCulture);

		internal static string MbWrongPassword => LanguageText_cz.ResourceManager.GetString("MbWrongPassword", LanguageText_cz.resourceCulture);

		internal static string MCheckParameter => LanguageText_cz.ResourceManager.GetString("MCheckParameter", LanguageText_cz.resourceCulture);

		internal static string MCurveDisplay => LanguageText_cz.ResourceManager.GetString("MCurveDisplay", LanguageText_cz.resourceCulture);

		internal static string MCurveSelection => LanguageText_cz.ResourceManager.GetString("MCurveSelection", LanguageText_cz.resourceCulture);

		internal static string MCycleCounter => LanguageText_cz.ResourceManager.GetString("MCycleCounter", LanguageText_cz.resourceCulture);

		internal static string MDelay => LanguageText_cz.ResourceManager.GetString("MDelay", LanguageText_cz.resourceCulture);

		internal static string Mean => LanguageText_cz.ResourceManager.GetString("Mean", LanguageText_cz.resourceCulture);

		internal static string MEditStep => LanguageText_cz.ResourceManager.GetString("MEditStep", LanguageText_cz.resourceCulture);

		internal static string MenuAnalysis => LanguageText_cz.ResourceManager.GetString("MenuAnalysis", LanguageText_cz.resourceCulture);

		internal static string MenuParameter => LanguageText_cz.ResourceManager.GetString("MenuParameter", LanguageText_cz.resourceCulture);

		internal static string MenuStatistics => LanguageText_cz.ResourceManager.GetString("MenuStatistics", LanguageText_cz.resourceCulture);

		internal static string MenuTest => LanguageText_cz.ResourceManager.GetString("MenuTest", LanguageText_cz.resourceCulture);

		internal static string Message => LanguageText_cz.ResourceManager.GetString("Message", LanguageText_cz.resourceCulture);

		internal static string MHandStart => LanguageText_cz.ResourceManager.GetString("MHandStart", LanguageText_cz.resourceCulture);

		internal static string Milimeter => LanguageText_cz.ResourceManager.GetString("Milimeter", LanguageText_cz.resourceCulture);

		internal static string Milisecond => LanguageText_cz.ResourceManager.GetString("Milisecond", LanguageText_cz.resourceCulture);

		internal static string Min => LanguageText_cz.ResourceManager.GetString("Min", LanguageText_cz.resourceCulture);

		internal static string MiniDisplay => LanguageText_cz.ResourceManager.GetString("MiniDisplay", LanguageText_cz.resourceCulture);

		internal static string Minimize => LanguageText_cz.ResourceManager.GetString("Minimize", LanguageText_cz.resourceCulture);

		internal static string MLastNIO => LanguageText_cz.ResourceManager.GetString("MLastNIO", LanguageText_cz.resourceCulture);

		internal static string MLogBook => LanguageText_cz.ResourceManager.GetString("MLogBook", LanguageText_cz.resourceCulture);

		internal static string MOptPrgParam => LanguageText_cz.ResourceManager.GetString("MOptPrgParam", LanguageText_cz.resourceCulture);

		internal static string Motor => LanguageText_cz.ResourceManager.GetString("Motor", LanguageText_cz.resourceCulture);

		internal static string MPasscodeManager => LanguageText_cz.ResourceManager.GetString("MPasscodeManager", LanguageText_cz.resourceCulture);

		internal static string MPrintSelection => LanguageText_cz.ResourceManager.GetString("MPrintSelection", LanguageText_cz.resourceCulture);

		internal static string MProgramOverview => LanguageText_cz.ResourceManager.GetString("MProgramOverview", LanguageText_cz.resourceCulture);

		internal static string MSpindleConstants => LanguageText_cz.ResourceManager.GetString("MSpindleConstants", LanguageText_cz.resourceCulture);

		internal static string MStepOverview => LanguageText_cz.ResourceManager.GetString("MStepOverview", LanguageText_cz.resourceCulture);

		internal static string MStepResults => LanguageText_cz.ResourceManager.GetString("MStepResults", LanguageText_cz.resourceCulture);

		internal static string MSystemConstants => LanguageText_cz.ResourceManager.GetString("MSystemConstants", LanguageText_cz.resourceCulture);

		internal static string MVisualisationParam => LanguageText_cz.ResourceManager.GetString("MVisualisationParam", LanguageText_cz.resourceCulture);

		internal static string Name => LanguageText_cz.ResourceManager.GetString("Name", LanguageText_cz.resourceCulture);

		internal static string Negative => LanguageText_cz.ResourceManager.GetString("Negative", LanguageText_cz.resourceCulture);

		internal static string NegOverload => LanguageText_cz.ResourceManager.GetString("NegOverload", LanguageText_cz.resourceCulture);

		internal static string NewEntry => LanguageText_cz.ResourceManager.GetString("NewEntry", LanguageText_cz.resourceCulture);

		internal static string NewValue => LanguageText_cz.ResourceManager.GetString("NewValue", LanguageText_cz.resourceCulture);

		internal static string Next50Curves => LanguageText_cz.ResourceManager.GetString("Next50Curves", LanguageText_cz.resourceCulture);

		internal static string NIO10 => LanguageText_cz.ResourceManager.GetString("NIO10", LanguageText_cz.resourceCulture);

		internal static string NIO10001 => LanguageText_cz.ResourceManager.GetString("NIO10001", LanguageText_cz.resourceCulture);

		internal static string NIO10002 => LanguageText_cz.ResourceManager.GetString("NIO10002", LanguageText_cz.resourceCulture);

		internal static string NIO10003 => LanguageText_cz.ResourceManager.GetString("NIO10003", LanguageText_cz.resourceCulture);

		internal static string NIO10004 => LanguageText_cz.ResourceManager.GetString("NIO10004", LanguageText_cz.resourceCulture);

		internal static string NIO11 => LanguageText_cz.ResourceManager.GetString("NIO11", LanguageText_cz.resourceCulture);

		internal static string NIO110 => LanguageText_cz.ResourceManager.GetString("NIO110", LanguageText_cz.resourceCulture);

		internal static string NIO12 => LanguageText_cz.ResourceManager.GetString("NIO12", LanguageText_cz.resourceCulture);

		internal static string NIO13 => LanguageText_cz.ResourceManager.GetString("NIO13", LanguageText_cz.resourceCulture);

		internal static string NIO30 => LanguageText_cz.ResourceManager.GetString("NIO30", LanguageText_cz.resourceCulture);

		internal static string NIO31 => LanguageText_cz.ResourceManager.GetString("NIO31", LanguageText_cz.resourceCulture);

		internal static string NIO40 => LanguageText_cz.ResourceManager.GetString("NIO40", LanguageText_cz.resourceCulture);

		internal static string NIO41 => LanguageText_cz.ResourceManager.GetString("NIO41", LanguageText_cz.resourceCulture);

		internal static string NIO50 => LanguageText_cz.ResourceManager.GetString("NIO50", LanguageText_cz.resourceCulture);

		internal static string NIO51 => LanguageText_cz.ResourceManager.GetString("NIO51", LanguageText_cz.resourceCulture);

		internal static string NIO60 => LanguageText_cz.ResourceManager.GetString("NIO60", LanguageText_cz.resourceCulture);

		internal static string NIO61 => LanguageText_cz.ResourceManager.GetString("NIO61", LanguageText_cz.resourceCulture);

		internal static string NIO70 => LanguageText_cz.ResourceManager.GetString("NIO70", LanguageText_cz.resourceCulture);

		internal static string NIO71 => LanguageText_cz.ResourceManager.GetString("NIO71", LanguageText_cz.resourceCulture);

		internal static string NIO75 => LanguageText_cz.ResourceManager.GetString("NIO75", LanguageText_cz.resourceCulture);

		internal static string NIO76 => LanguageText_cz.ResourceManager.GetString("NIO76", LanguageText_cz.resourceCulture);

		internal static string NIO80 => LanguageText_cz.ResourceManager.GetString("NIO80", LanguageText_cz.resourceCulture);

		internal static string NIO81 => LanguageText_cz.ResourceManager.GetString("NIO81", LanguageText_cz.resourceCulture);

		internal static string NIO90 => LanguageText_cz.ResourceManager.GetString("NIO90", LanguageText_cz.resourceCulture);

		internal static string NIO91 => LanguageText_cz.ResourceManager.GetString("NIO91", LanguageText_cz.resourceCulture);

		internal static string NIO92 => LanguageText_cz.ResourceManager.GetString("NIO92", LanguageText_cz.resourceCulture);

		internal static string NIO93 => LanguageText_cz.ResourceManager.GetString("NIO93", LanguageText_cz.resourceCulture);

		internal static string NIO94 => LanguageText_cz.ResourceManager.GetString("NIO94", LanguageText_cz.resourceCulture);

		internal static string NIO95 => LanguageText_cz.ResourceManager.GetString("NIO95", LanguageText_cz.resourceCulture);

		internal static string NIO96 => LanguageText_cz.ResourceManager.GetString("NIO96", LanguageText_cz.resourceCulture);

		internal static string NIO97 => LanguageText_cz.ResourceManager.GetString("NIO97", LanguageText_cz.resourceCulture);

		internal static string NIO98 => LanguageText_cz.ResourceManager.GetString("NIO98", LanguageText_cz.resourceCulture);

		internal static string NIO99 => LanguageText_cz.ResourceManager.GetString("NIO99", LanguageText_cz.resourceCulture);

		internal static string NIONumber => LanguageText_cz.ResourceManager.GetString("NIONumber", LanguageText_cz.resourceCulture);

		internal static string NIOReason => LanguageText_cz.ResourceManager.GetString("NIOReason", LanguageText_cz.resourceCulture);

		internal static string No => LanguageText_cz.ResourceManager.GetString("No", LanguageText_cz.resourceCulture);

		internal static string NoData => LanguageText_cz.ResourceManager.GetString("NoData", LanguageText_cz.resourceCulture);

		internal static string NoErrorMode => LanguageText_cz.ResourceManager.GetString("NoErrorMode", LanguageText_cz.resourceCulture);

		internal static string NOK => LanguageText_cz.ResourceManager.GetString("NOK", LanguageText_cz.resourceCulture);

		internal static string None => LanguageText_cz.ResourceManager.GetString("None", LanguageText_cz.resourceCulture);

		internal static string NoParity => LanguageText_cz.ResourceManager.GetString("NoParity", LanguageText_cz.resourceCulture);

		internal static string NoSelection => LanguageText_cz.ResourceManager.GetString("NoSelection", LanguageText_cz.resourceCulture);

		internal static string NoSignal => LanguageText_cz.ResourceManager.GetString("NoSignal", LanguageText_cz.resourceCulture);

		internal static string NotValid => LanguageText_cz.ResourceManager.GetString("NotValid", LanguageText_cz.resourceCulture);

		internal static string Number => LanguageText_cz.ResourceManager.GetString("Number", LanguageText_cz.resourceCulture);

		internal static string NumberPad => LanguageText_cz.ResourceManager.GetString("NumberPad", LanguageText_cz.resourceCulture);

		internal static string Odd => LanguageText_cz.ResourceManager.GetString("Odd", LanguageText_cz.resourceCulture);

		internal static string Off => LanguageText_cz.ResourceManager.GetString("Off", LanguageText_cz.resourceCulture);

		internal static string OfflineMode => LanguageText_cz.ResourceManager.GetString("OfflineMode", LanguageText_cz.resourceCulture);

		internal static string OffsetTeachValue => LanguageText_cz.ResourceManager.GetString("OffsetTeachValue", LanguageText_cz.resourceCulture);

		internal static string OffsetVoltageMax => LanguageText_cz.ResourceManager.GetString("OffsetVoltageMax", LanguageText_cz.resourceCulture);

		internal static string OffsetVoltageMin => LanguageText_cz.ResourceManager.GetString("OffsetVoltageMin", LanguageText_cz.resourceCulture);

		internal static string OfStep => LanguageText_cz.ResourceManager.GetString("OfStep", LanguageText_cz.resourceCulture);

		internal static string OK => LanguageText_cz.ResourceManager.GetString("OK", LanguageText_cz.resourceCulture);

		internal static string OKNOK => LanguageText_cz.ResourceManager.GetString("OKNOK", LanguageText_cz.resourceCulture);

		internal static string OldValue => LanguageText_cz.ResourceManager.GetString("OldValue", LanguageText_cz.resourceCulture);

		internal static string On => LanguageText_cz.ResourceManager.GetString("On", LanguageText_cz.resourceCulture);

		internal static string OnlineMode => LanguageText_cz.ResourceManager.GetString("OnlineMode", LanguageText_cz.resourceCulture);

		internal static string OnlyIO => LanguageText_cz.ResourceManager.GetString("OnlyIO", LanguageText_cz.resourceCulture);

		internal static string OptPrgParam => LanguageText_cz.ResourceManager.GetString("OptPrgParam", LanguageText_cz.resourceCulture);

		internal static string Organisation => LanguageText_cz.ResourceManager.GetString("Organisation", LanguageText_cz.resourceCulture);

		internal static string OrganizingStep => LanguageText_cz.ResourceManager.GetString("OrganizingStep", LanguageText_cz.resourceCulture);

		internal static string OutOfRange => LanguageText_cz.ResourceManager.GetString("OutOfRange", LanguageText_cz.resourceCulture);

		internal static string Outputs => LanguageText_cz.ResourceManager.GetString("Outputs", LanguageText_cz.resourceCulture);

		internal static string PaintCurve => LanguageText_cz.ResourceManager.GetString("PaintCurve", LanguageText_cz.resourceCulture);

		internal static string Parity => LanguageText_cz.ResourceManager.GetString("Parity", LanguageText_cz.resourceCulture);

		internal static string PasscodeLevel => LanguageText_cz.ResourceManager.GetString("PasscodeLevel", LanguageText_cz.resourceCulture);

		internal static string PasscodeManager => LanguageText_cz.ResourceManager.GetString("PasscodeManager", LanguageText_cz.resourceCulture);

		internal static string Password => LanguageText_cz.ResourceManager.GetString("Password", LanguageText_cz.resourceCulture);

		internal static string PasswordInput => LanguageText_cz.ResourceManager.GetString("PasswordInput", LanguageText_cz.resourceCulture);

		internal static string Percent => LanguageText_cz.ResourceManager.GetString("Percent", LanguageText_cz.resourceCulture);

		internal static string PLC_IO => LanguageText_cz.ResourceManager.GetString("PLC_IO", LanguageText_cz.resourceCulture);

		internal static string PointOfTime => LanguageText_cz.ResourceManager.GetString("PointOfTime", LanguageText_cz.resourceCulture);

		internal static string Positive => LanguageText_cz.ResourceManager.GetString("Positive", LanguageText_cz.resourceCulture);

		internal static string PosOverload => LanguageText_cz.ResourceManager.GetString("PosOverload", LanguageText_cz.resourceCulture);

		internal static string PowerEnabled => LanguageText_cz.ResourceManager.GetString("PowerEnabled", LanguageText_cz.resourceCulture);

		internal static string Pressure => LanguageText_cz.ResourceManager.GetString("Pressure", LanguageText_cz.resourceCulture);

		internal static string PressureSpindle => LanguageText_cz.ResourceManager.GetString("PressureSpindle", LanguageText_cz.resourceCulture);

		internal static string Print => LanguageText_cz.ResourceManager.GetString("Print", LanguageText_cz.resourceCulture);

		internal static string ProcessInputs => LanguageText_cz.ResourceManager.GetString("ProcessInputs", LanguageText_cz.resourceCulture);

		internal static string ProcessRunning => LanguageText_cz.ResourceManager.GetString("ProcessRunning", LanguageText_cz.resourceCulture);

		internal static string Program => LanguageText_cz.ResourceManager.GetString("Program", LanguageText_cz.resourceCulture);

		internal static string ProgramChange201000 => LanguageText_cz.ResourceManager.GetString("ProgramChange201000", LanguageText_cz.resourceCulture);

		internal static string ProgramChange201001 => LanguageText_cz.ResourceManager.GetString("ProgramChange201001", LanguageText_cz.resourceCulture);

		internal static string ProgramChange201002 => LanguageText_cz.ResourceManager.GetString("ProgramChange201002", LanguageText_cz.resourceCulture);

		internal static string ProgramChange201003 => LanguageText_cz.ResourceManager.GetString("ProgramChange201003", LanguageText_cz.resourceCulture);

		internal static string ProgramChange201004 => LanguageText_cz.ResourceManager.GetString("ProgramChange201004", LanguageText_cz.resourceCulture);

		internal static string ProgramChange201005 => LanguageText_cz.ResourceManager.GetString("ProgramChange201005", LanguageText_cz.resourceCulture);

		internal static string ProgramChange201006 => LanguageText_cz.ResourceManager.GetString("ProgramChange201006", LanguageText_cz.resourceCulture);

		internal static string ProgramChange201007 => LanguageText_cz.ResourceManager.GetString("ProgramChange201007", LanguageText_cz.resourceCulture);

		internal static string ProgramChange201008 => LanguageText_cz.ResourceManager.GetString("ProgramChange201008", LanguageText_cz.resourceCulture);

		internal static string ProgramChange201009 => LanguageText_cz.ResourceManager.GetString("ProgramChange201009", LanguageText_cz.resourceCulture);

		internal static string ProgramNumber => LanguageText_cz.ResourceManager.GetString("ProgramNumber", LanguageText_cz.resourceCulture);

		internal static string Programs => LanguageText_cz.ResourceManager.GetString("Programs", LanguageText_cz.resourceCulture);

		internal static string Quit => LanguageText_cz.ResourceManager.GetString("Quit", LanguageText_cz.resourceCulture);

		internal static string Ramp => LanguageText_cz.ResourceManager.GetString("Ramp", LanguageText_cz.resourceCulture);

		internal static string Range => LanguageText_cz.ResourceManager.GetString("Range", LanguageText_cz.resourceCulture);

		internal static string ReadyToStart => LanguageText_cz.ResourceManager.GetString("ReadyToStart", LanguageText_cz.resourceCulture);

		internal static string RecentDateTime => LanguageText_cz.ResourceManager.GetString("RecentDateTime", LanguageText_cz.resourceCulture);

		internal static string Reconnect => LanguageText_cz.ResourceManager.GetString("Reconnect", LanguageText_cz.resourceCulture);

		internal static string ReconnectToController => LanguageText_cz.ResourceManager.GetString("ReconnectToController", LanguageText_cz.resourceCulture);

		internal static string RecursiveStatMode => LanguageText_cz.ResourceManager.GetString("RecursiveStatMode", LanguageText_cz.resourceCulture);

		internal static string RedAngle => LanguageText_cz.ResourceManager.GetString("RedAngle", LanguageText_cz.resourceCulture);

		internal static string RedTorque => LanguageText_cz.ResourceManager.GetString("RedTorque", LanguageText_cz.resourceCulture);

		internal static string RedundantSensorActive => LanguageText_cz.ResourceManager.GetString("RedundantSensorActive", LanguageText_cz.resourceCulture);

		internal static string relatedTo => LanguageText_cz.ResourceManager.GetString("relatedTo", LanguageText_cz.resourceCulture);

		internal static string RelativeTorque => LanguageText_cz.ResourceManager.GetString("RelativeTorque", LanguageText_cz.resourceCulture);

		internal static string Release => LanguageText_cz.ResourceManager.GetString("Release", LanguageText_cz.resourceCulture);

		internal static string ReleaseSpeed => LanguageText_cz.ResourceManager.GetString("ReleaseSpeed", LanguageText_cz.resourceCulture);

		internal static string RelTorqueStep => LanguageText_cz.ResourceManager.GetString("RelTorqueStep", LanguageText_cz.resourceCulture);

		internal static string RemainedCurves => LanguageText_cz.ResourceManager.GetString("RemainedCurves", LanguageText_cz.resourceCulture);

		internal static string Reset => LanguageText_cz.ResourceManager.GetString("Reset", LanguageText_cz.resourceCulture);

		internal static string ResetADepth => LanguageText_cz.ResourceManager.GetString("ResetADepth", LanguageText_cz.resourceCulture);

		internal static string ResetAngle => LanguageText_cz.ResourceManager.GetString("ResetAngle", LanguageText_cz.resourceCulture);

		internal static string Result => LanguageText_cz.ResourceManager.GetString("Result", LanguageText_cz.resourceCulture);

		internal static string ResultDisplay => LanguageText_cz.ResourceManager.GetString("ResultDisplay", LanguageText_cz.resourceCulture);

		internal static string Results => LanguageText_cz.ResourceManager.GetString("Results", LanguageText_cz.resourceCulture);

		internal static string RightAngle => LanguageText_cz.ResourceManager.GetString("RightAngle", LanguageText_cz.resourceCulture);

		internal static string Robot => LanguageText_cz.ResourceManager.GetString("Robot", LanguageText_cz.resourceCulture);

		internal static string RoundsPerMinute => LanguageText_cz.ResourceManager.GetString("RoundsPerMinute", LanguageText_cz.resourceCulture);

		internal static string RpmTest => LanguageText_cz.ResourceManager.GetString("RpmTest", LanguageText_cz.resourceCulture);

		internal static string RpmUnit => LanguageText_cz.ResourceManager.GetString("RpmUnit", LanguageText_cz.resourceCulture);

		internal static string RS232PrintMode => LanguageText_cz.ResourceManager.GetString("RS232PrintMode", LanguageText_cz.resourceCulture);

		internal static string SampleSize => LanguageText_cz.ResourceManager.GetString("SampleSize", LanguageText_cz.resourceCulture);

		internal static string SampleStatistic => LanguageText_cz.ResourceManager.GetString("SampleStatistic", LanguageText_cz.resourceCulture);

		internal static string SaveCurveDataToFile => LanguageText_cz.ResourceManager.GetString("SaveCurveDataToFile", LanguageText_cz.resourceCulture);

		internal static string SaveCustBackup => LanguageText_cz.ResourceManager.GetString("SaveCustBackup", LanguageText_cz.resourceCulture);

		internal static string SaveCustBackupOnCF => LanguageText_cz.ResourceManager.GetString("SaveCustBackupOnCF", LanguageText_cz.resourceCulture);

		internal static string SaveCustBackupSecQuery => LanguageText_cz.ResourceManager.GetString("SaveCustBackupSecQuery", LanguageText_cz.resourceCulture);

		internal static string SavePasscodesOnCPU => LanguageText_cz.ResourceManager.GetString("SavePasscodesOnCPU", LanguageText_cz.resourceCulture);

		internal static string SavePProgToFile => LanguageText_cz.ResourceManager.GetString("SavePProgToFile", LanguageText_cz.resourceCulture);

		internal static string SaveProgOnCPU => LanguageText_cz.ResourceManager.GetString("SaveProgOnCPU", LanguageText_cz.resourceCulture);

		internal static string SaveProgramData => LanguageText_cz.ResourceManager.GetString("SaveProgramData", LanguageText_cz.resourceCulture);

		internal static string SaveProgramDataLocally => LanguageText_cz.ResourceManager.GetString("SaveProgramDataLocally", LanguageText_cz.resourceCulture);

		internal static string SaveSingleProgToFile => LanguageText_cz.ResourceManager.GetString("SaveSingleProgToFile", LanguageText_cz.resourceCulture);

		internal static string SaveSpindleConstOnCPU => LanguageText_cz.ResourceManager.GetString("SaveSpindleConstOnCPU", LanguageText_cz.resourceCulture);

		internal static string SaveSpindleDataLocally => LanguageText_cz.ResourceManager.GetString("SaveSpindleDataLocally", LanguageText_cz.resourceCulture);

		internal static string SaveSystemConstOnCPU => LanguageText_cz.ResourceManager.GetString("SaveSystemConstOnCPU", LanguageText_cz.resourceCulture);

		internal static string SaveToFile => LanguageText_cz.ResourceManager.GetString("SaveToFile", LanguageText_cz.resourceCulture);

		internal static string SaveVisuParam => LanguageText_cz.ResourceManager.GetString("SaveVisuParam", LanguageText_cz.resourceCulture);

		internal static string SaveWebBackupSecQuery => LanguageText_cz.ResourceManager.GetString("SaveWebBackupSecQuery", LanguageText_cz.resourceCulture);

		internal static string SaveWeberBackup => LanguageText_cz.ResourceManager.GetString("SaveWeberBackup", LanguageText_cz.resourceCulture);

		internal static string SaveWeberBackupOnCF => LanguageText_cz.ResourceManager.GetString("SaveWeberBackupOnCF", LanguageText_cz.resourceCulture);

		internal static string ScrewID => LanguageText_cz.ResourceManager.GetString("ScrewID", LanguageText_cz.resourceCulture);

		internal static string ScrewProgramFiles => LanguageText_cz.ResourceManager.GetString("ScrewProgramFiles", LanguageText_cz.resourceCulture);

		internal static string ScrewPrograms => LanguageText_cz.ResourceManager.GetString("ScrewPrograms", LanguageText_cz.resourceCulture);

		internal static string ScrewTime => LanguageText_cz.ResourceManager.GetString("ScrewTime", LanguageText_cz.resourceCulture);

		internal static string Second => LanguageText_cz.ResourceManager.GetString("Second", LanguageText_cz.resourceCulture);

		internal static string SelectAll => LanguageText_cz.ResourceManager.GetString("SelectAll", LanguageText_cz.resourceCulture);

		internal static string SelectedKind => LanguageText_cz.ResourceManager.GetString("SelectedKind", LanguageText_cz.resourceCulture);

		internal static string SelectedXAxis => LanguageText_cz.ResourceManager.GetString("SelectedXAxis", LanguageText_cz.resourceCulture);

		internal static string SelectedYAxis => LanguageText_cz.ResourceManager.GetString("SelectedYAxis", LanguageText_cz.resourceCulture);

		internal static string SelectNone => LanguageText_cz.ResourceManager.GetString("SelectNone", LanguageText_cz.resourceCulture);

		internal static string SelValidNumber => LanguageText_cz.ResourceManager.GetString("SelValidNumber", LanguageText_cz.resourceCulture);

		internal static string SendIO => LanguageText_cz.ResourceManager.GetString("SendIO", LanguageText_cz.resourceCulture);

		internal static string SendPasscodes => LanguageText_cz.ResourceManager.GetString("SendPasscodes", LanguageText_cz.resourceCulture);

		internal static string SendSpindleConstants => LanguageText_cz.ResourceManager.GetString("SendSpindleConstants", LanguageText_cz.resourceCulture);

		internal static string SendSystemConstants => LanguageText_cz.ResourceManager.GetString("SendSystemConstants", LanguageText_cz.resourceCulture);

		internal static string SensorTest => LanguageText_cz.ResourceManager.GetString("SensorTest", LanguageText_cz.resourceCulture);

		internal static string Set => LanguageText_cz.ResourceManager.GetString("Set", LanguageText_cz.resourceCulture);

		internal static string SetAnaOut => LanguageText_cz.ResourceManager.GetString("SetAnaOut", LanguageText_cz.resourceCulture);

		internal static string SetDigOut => LanguageText_cz.ResourceManager.GetString("SetDigOut", LanguageText_cz.resourceCulture);

		internal static string SetOff => LanguageText_cz.ResourceManager.GetString("SetOff", LanguageText_cz.resourceCulture);

		internal static string SetOn => LanguageText_cz.ResourceManager.GetString("SetOn", LanguageText_cz.resourceCulture);

		internal static string SetRight => LanguageText_cz.ResourceManager.GetString("SetRight", LanguageText_cz.resourceCulture);

		internal static string SetRpm => LanguageText_cz.ResourceManager.GetString("SetRpm", LanguageText_cz.resourceCulture);

		internal static string Settings => LanguageText_cz.ResourceManager.GetString("Settings", LanguageText_cz.resourceCulture);

		internal static string ShortName => LanguageText_cz.ResourceManager.GetString("ShortName", LanguageText_cz.resourceCulture);

		internal static string SignalQuit => LanguageText_cz.ResourceManager.GetString("SignalQuit", LanguageText_cz.resourceCulture);

		internal static string Spain => LanguageText_cz.ResourceManager.GetString("Spain", LanguageText_cz.resourceCulture);

		internal static string SpChange100010 => LanguageText_cz.ResourceManager.GetString("SpChange100010", LanguageText_cz.resourceCulture);

		internal static string SpChange203000 => LanguageText_cz.ResourceManager.GetString("SpChange203000", LanguageText_cz.resourceCulture);

		internal static string SpChange203001 => LanguageText_cz.ResourceManager.GetString("SpChange203001", LanguageText_cz.resourceCulture);

		internal static string SpChange203002 => LanguageText_cz.ResourceManager.GetString("SpChange203002", LanguageText_cz.resourceCulture);

		internal static string SpChange203003 => LanguageText_cz.ResourceManager.GetString("SpChange203003", LanguageText_cz.resourceCulture);

		internal static string SpChange203004 => LanguageText_cz.ResourceManager.GetString("SpChange203004", LanguageText_cz.resourceCulture);

		internal static string SpChange203005 => LanguageText_cz.ResourceManager.GetString("SpChange203005", LanguageText_cz.resourceCulture);

		internal static string SpChange203006 => LanguageText_cz.ResourceManager.GetString("SpChange203006", LanguageText_cz.resourceCulture);

		internal static string SpChange203007 => LanguageText_cz.ResourceManager.GetString("SpChange203007", LanguageText_cz.resourceCulture);

		internal static string SpChange203008 => LanguageText_cz.ResourceManager.GetString("SpChange203008", LanguageText_cz.resourceCulture);

		internal static string SpChange203009 => LanguageText_cz.ResourceManager.GetString("SpChange203009", LanguageText_cz.resourceCulture);

		internal static string SpChange203010 => LanguageText_cz.ResourceManager.GetString("SpChange203010", LanguageText_cz.resourceCulture);

		internal static string SpChange203011 => LanguageText_cz.ResourceManager.GetString("SpChange203011", LanguageText_cz.resourceCulture);

		internal static string SpChange203012 => LanguageText_cz.ResourceManager.GetString("SpChange203012", LanguageText_cz.resourceCulture);

		internal static string SpChange203013 => LanguageText_cz.ResourceManager.GetString("SpChange203013", LanguageText_cz.resourceCulture);

		internal static string SpChange203014 => LanguageText_cz.ResourceManager.GetString("SpChange203014", LanguageText_cz.resourceCulture);

		internal static string SpChange203015 => LanguageText_cz.ResourceManager.GetString("SpChange203015", LanguageText_cz.resourceCulture);

		internal static string SpChange203016 => LanguageText_cz.ResourceManager.GetString("SpChange203016", LanguageText_cz.resourceCulture);

		internal static string SpChange203017 => LanguageText_cz.ResourceManager.GetString("SpChange203017", LanguageText_cz.resourceCulture);

		internal static string SpChange203018 => LanguageText_cz.ResourceManager.GetString("SpChange203018", LanguageText_cz.resourceCulture);

		internal static string SpChange203019 => LanguageText_cz.ResourceManager.GetString("SpChange203019", LanguageText_cz.resourceCulture);

		internal static string SpChange203020 => LanguageText_cz.ResourceManager.GetString("SpChange203020", LanguageText_cz.resourceCulture);

		internal static string SpChange203021 => LanguageText_cz.ResourceManager.GetString("SpChange203021", LanguageText_cz.resourceCulture);

		internal static string SpChange203022 => LanguageText_cz.ResourceManager.GetString("SpChange203022", LanguageText_cz.resourceCulture);

		internal static string SpChange203023 => LanguageText_cz.ResourceManager.GetString("SpChange203023", LanguageText_cz.resourceCulture);

		internal static string SpChange203024 => LanguageText_cz.ResourceManager.GetString("SpChange203024", LanguageText_cz.resourceCulture);

		internal static string SpChange203025 => LanguageText_cz.ResourceManager.GetString("SpChange203025", LanguageText_cz.resourceCulture);

		internal static string SpChange203026 => LanguageText_cz.ResourceManager.GetString("SpChange203026", LanguageText_cz.resourceCulture);

		internal static string SpChange203027 => LanguageText_cz.ResourceManager.GetString("SpChange203027", LanguageText_cz.resourceCulture);

		internal static string SpChange203028 => LanguageText_cz.ResourceManager.GetString("SpChange203028", LanguageText_cz.resourceCulture);

		internal static string SpChange203029 => LanguageText_cz.ResourceManager.GetString("SpChange203029", LanguageText_cz.resourceCulture);

		internal static string SpChange203030 => LanguageText_cz.ResourceManager.GetString("SpChange203030", LanguageText_cz.resourceCulture);

		internal static string SpindleConstants => LanguageText_cz.ResourceManager.GetString("SpindleConstants", LanguageText_cz.resourceCulture);

		internal static string SpindleConstFiles => LanguageText_cz.ResourceManager.GetString("SpindleConstFiles", LanguageText_cz.resourceCulture);

		internal static string SpindlePressureScale => LanguageText_cz.ResourceManager.GetString("SpindlePressureScale", LanguageText_cz.resourceCulture);

		internal static string SpindleTorque => LanguageText_cz.ResourceManager.GetString("SpindleTorque", LanguageText_cz.resourceCulture);

		internal static string StandardDeviation => LanguageText_cz.ResourceManager.GetString("StandardDeviation", LanguageText_cz.resourceCulture);

		internal static string StartCycleSave => LanguageText_cz.ResourceManager.GetString("StartCycleSave", LanguageText_cz.resourceCulture);

		internal static string StartFrictionTest => LanguageText_cz.ResourceManager.GetString("StartFrictionTest", LanguageText_cz.resourceCulture);

		internal static string StartProgram => LanguageText_cz.ResourceManager.GetString("StartProgram", LanguageText_cz.resourceCulture);

		internal static string StartSignal => LanguageText_cz.ResourceManager.GetString("StartSignal", LanguageText_cz.resourceCulture);

		internal static string StartStepResExport => LanguageText_cz.ResourceManager.GetString("StartStepResExport", LanguageText_cz.resourceCulture);

		internal static string StartTest => LanguageText_cz.ResourceManager.GetString("StartTest", LanguageText_cz.resourceCulture);

		internal static string StatDelete204000 => LanguageText_cz.ResourceManager.GetString("StatDelete204000", LanguageText_cz.resourceCulture);

		internal static string StatDelete204001 => LanguageText_cz.ResourceManager.GetString("StatDelete204001", LanguageText_cz.resourceCulture);

		internal static string StatDelete204002 => LanguageText_cz.ResourceManager.GetString("StatDelete204002", LanguageText_cz.resourceCulture);

		internal static string StatisticCumul => LanguageText_cz.ResourceManager.GetString("StatisticCumul", LanguageText_cz.resourceCulture);

		internal static string Statistics => LanguageText_cz.ResourceManager.GetString("Statistics", LanguageText_cz.resourceCulture);

		internal static string StatisticSample => LanguageText_cz.ResourceManager.GetString("StatisticSample", LanguageText_cz.resourceCulture);

		internal static string StatisticsLastRes => LanguageText_cz.ResourceManager.GetString("StatisticsLastRes", LanguageText_cz.resourceCulture);

		internal static string Step => LanguageText_cz.ResourceManager.GetString("Step", LanguageText_cz.resourceCulture);

		internal static string StepFinish => LanguageText_cz.ResourceManager.GetString("StepFinish", LanguageText_cz.resourceCulture);

		internal static string StepKind => LanguageText_cz.ResourceManager.GetString("StepKind", LanguageText_cz.resourceCulture);

		internal static string StepKindChoice => LanguageText_cz.ResourceManager.GetString("StepKindChoice", LanguageText_cz.resourceCulture);

		internal static string StepResults => LanguageText_cz.ResourceManager.GetString("StepResults", LanguageText_cz.resourceCulture);

		internal static string Steps => LanguageText_cz.ResourceManager.GetString("Steps", LanguageText_cz.resourceCulture);

		internal static string StepTmin => LanguageText_cz.ResourceManager.GetString("StepTmin", LanguageText_cz.resourceCulture);

		internal static string StepTplus => LanguageText_cz.ResourceManager.GetString("StepTplus", LanguageText_cz.resourceCulture);

		internal static string Stop => LanguageText_cz.ResourceManager.GetString("Stop", LanguageText_cz.resourceCulture);

		internal static string StopNok => LanguageText_cz.ResourceManager.GetString("StopNok", LanguageText_cz.resourceCulture);

		internal static string StopOk => LanguageText_cz.ResourceManager.GetString("StopOk", LanguageText_cz.resourceCulture);

		internal static string StopStepResExport => LanguageText_cz.ResourceManager.GetString("StopStepResExport", LanguageText_cz.resourceCulture);

		internal static string StorageNumber => LanguageText_cz.ResourceManager.GetString("StorageNumber", LanguageText_cz.resourceCulture);

		internal static string StorageSignals => LanguageText_cz.ResourceManager.GetString("StorageSignals", LanguageText_cz.resourceCulture);

		internal static string StoreAndBack => LanguageText_cz.ResourceManager.GetString("StoreAndBack", LanguageText_cz.resourceCulture);

		internal static string SubnetMask => LanguageText_cz.ResourceManager.GetString("SubnetMask", LanguageText_cz.resourceCulture);

		internal static string SyncOut => LanguageText_cz.ResourceManager.GetString("SyncOut", LanguageText_cz.resourceCulture);

		internal static string SyncSignal => LanguageText_cz.ResourceManager.GetString("SyncSignal", LanguageText_cz.resourceCulture);

		internal static string SysChange202000 => LanguageText_cz.ResourceManager.GetString("SysChange202000", LanguageText_cz.resourceCulture);

		internal static string SysChange202001 => LanguageText_cz.ResourceManager.GetString("SysChange202001", LanguageText_cz.resourceCulture);

		internal static string SysChange202002 => LanguageText_cz.ResourceManager.GetString("SysChange202002", LanguageText_cz.resourceCulture);

		internal static string SysChange202003 => LanguageText_cz.ResourceManager.GetString("SysChange202003", LanguageText_cz.resourceCulture);

		internal static string SysChange202004 => LanguageText_cz.ResourceManager.GetString("SysChange202004", LanguageText_cz.resourceCulture);

		internal static string SysChange202005 => LanguageText_cz.ResourceManager.GetString("SysChange202005", LanguageText_cz.resourceCulture);

		internal static string SysChange202006 => LanguageText_cz.ResourceManager.GetString("SysChange202006", LanguageText_cz.resourceCulture);

		internal static string SysChange202007 => LanguageText_cz.ResourceManager.GetString("SysChange202007", LanguageText_cz.resourceCulture);

		internal static string SysChange202008 => LanguageText_cz.ResourceManager.GetString("SysChange202008", LanguageText_cz.resourceCulture);

		internal static string SysChange202009 => LanguageText_cz.ResourceManager.GetString("SysChange202009", LanguageText_cz.resourceCulture);

		internal static string SysChange202010 => LanguageText_cz.ResourceManager.GetString("SysChange202010", LanguageText_cz.resourceCulture);

		internal static string SysChange202011 => LanguageText_cz.ResourceManager.GetString("SysChange202011", LanguageText_cz.resourceCulture);

		internal static string SysChange202012 => LanguageText_cz.ResourceManager.GetString("SysChange202012", LanguageText_cz.resourceCulture);

		internal static string SysChange202013 => LanguageText_cz.ResourceManager.GetString("SysChange202013", LanguageText_cz.resourceCulture);

		internal static string SysChange202014 => LanguageText_cz.ResourceManager.GetString("SysChange202014", LanguageText_cz.resourceCulture);

		internal static string SysChange202015 => LanguageText_cz.ResourceManager.GetString("SysChange202015", LanguageText_cz.resourceCulture);

		internal static string SysChange202016 => LanguageText_cz.ResourceManager.GetString("SysChange202016", LanguageText_cz.resourceCulture);

		internal static string SysChange202017 => LanguageText_cz.ResourceManager.GetString("SysChange202017", LanguageText_cz.resourceCulture);

		internal static string SysChange202018 => LanguageText_cz.ResourceManager.GetString("SysChange202018", LanguageText_cz.resourceCulture);

		internal static string SystemConstants => LanguageText_cz.ResourceManager.GetString("SystemConstants", LanguageText_cz.resourceCulture);

		internal static string SystemID => LanguageText_cz.ResourceManager.GetString("SystemID", LanguageText_cz.resourceCulture);

		internal static string SystemOK => LanguageText_cz.ResourceManager.GetString("SystemOK", LanguageText_cz.resourceCulture);

		internal static string Target => LanguageText_cz.ResourceManager.GetString("Target", LanguageText_cz.resourceCulture);

		internal static string TargetRight => LanguageText_cz.ResourceManager.GetString("TargetRight", LanguageText_cz.resourceCulture);

		internal static string TeachSignal => LanguageText_cz.ResourceManager.GetString("TeachSignal", LanguageText_cz.resourceCulture);

		internal static string Test => LanguageText_cz.ResourceManager.GetString("Test", LanguageText_cz.resourceCulture);

		internal static string TestIO => LanguageText_cz.ResourceManager.GetString("TestIO", LanguageText_cz.resourceCulture);

		internal static string TestMFS => LanguageText_cz.ResourceManager.GetString("TestMFS", LanguageText_cz.resourceCulture);

		internal static string TestSPSIO => LanguageText_cz.ResourceManager.GetString("TestSPSIO", LanguageText_cz.resourceCulture);

		internal static string Time => LanguageText_cz.ResourceManager.GetString("Time", LanguageText_cz.resourceCulture);

		internal static string TimeDateFormat => LanguageText_cz.ResourceManager.GetString("TimeDateFormat", LanguageText_cz.resourceCulture);

		internal static string TimeSet => LanguageText_cz.ResourceManager.GetString("TimeSet", LanguageText_cz.resourceCulture);

		internal static string TimeSynchronize => LanguageText_cz.ResourceManager.GetString("TimeSynchronize", LanguageText_cz.resourceCulture);

		internal static string TM1 => LanguageText_cz.ResourceManager.GetString("TM1", LanguageText_cz.resourceCulture);

		internal static string TM2 => LanguageText_cz.ResourceManager.GetString("TM2", LanguageText_cz.resourceCulture);

		internal static string TN => LanguageText_cz.ResourceManager.GetString("TN", LanguageText_cz.resourceCulture);

		internal static string ToggleCursor => LanguageText_cz.ResourceManager.GetString("ToggleCursor", LanguageText_cz.resourceCulture);

		internal static string TopAll => LanguageText_cz.ResourceManager.GetString("TopAll", LanguageText_cz.resourceCulture);

		internal static string TopTen => LanguageText_cz.ResourceManager.GetString("TopTen", LanguageText_cz.resourceCulture);

		internal static string Torque => LanguageText_cz.ResourceManager.GetString("Torque", LanguageText_cz.resourceCulture);

		internal static string Torqueftlb => LanguageText_cz.ResourceManager.GetString("Torqueftlb", LanguageText_cz.resourceCulture);

		internal static string Torqueinlb => LanguageText_cz.ResourceManager.GetString("Torqueinlb", LanguageText_cz.resourceCulture);

		internal static string Torqueinoz => LanguageText_cz.ResourceManager.GetString("Torqueinoz", LanguageText_cz.resourceCulture);

		internal static string Torquekgcm => LanguageText_cz.ResourceManager.GetString("Torquekgcm", LanguageText_cz.resourceCulture);

		internal static string Torquekgm => LanguageText_cz.ResourceManager.GetString("Torquekgm", LanguageText_cz.resourceCulture);

		internal static string TorqueNcm => LanguageText_cz.ResourceManager.GetString("TorqueNcm", LanguageText_cz.resourceCulture);

		internal static string TorqueNm => LanguageText_cz.ResourceManager.GetString("TorqueNm", LanguageText_cz.resourceCulture);

		internal static string TorqueRedundantTime => LanguageText_cz.ResourceManager.GetString("TorqueRedundantTime", LanguageText_cz.resourceCulture);

		internal static string TorqueRedundantTolerance => LanguageText_cz.ResourceManager.GetString("TorqueRedundantTolerance", LanguageText_cz.resourceCulture);

		internal static string TorqueSensorInvers => LanguageText_cz.ResourceManager.GetString("TorqueSensorInvers", LanguageText_cz.resourceCulture);

		internal static string TorqueSensorScale => LanguageText_cz.ResourceManager.GetString("TorqueSensorScale", LanguageText_cz.resourceCulture);

		internal static string TorqueSensorTolerance => LanguageText_cz.ResourceManager.GetString("TorqueSensorTolerance", LanguageText_cz.resourceCulture);

		internal static string TorqueUnitChoose => LanguageText_cz.ResourceManager.GetString("TorqueUnitChoose", LanguageText_cz.resourceCulture);

		internal static string TreshTorque => LanguageText_cz.ResourceManager.GetString("TreshTorque", LanguageText_cz.resourceCulture);

		internal static string Type => LanguageText_cz.ResourceManager.GetString("Type", LanguageText_cz.resourceCulture);

		internal static string Unit => LanguageText_cz.ResourceManager.GetString("Unit", LanguageText_cz.resourceCulture);

		internal static string UnitBar => LanguageText_cz.ResourceManager.GetString("UnitBar", LanguageText_cz.resourceCulture);

		internal static string UpperLimit => LanguageText_cz.ResourceManager.GetString("UpperLimit", LanguageText_cz.resourceCulture);

		internal static string UsedKeyboard => LanguageText_cz.ResourceManager.GetString("UsedKeyboard", LanguageText_cz.resourceCulture);

		internal static string UsedValueNumber => LanguageText_cz.ResourceManager.GetString("UsedValueNumber", LanguageText_cz.resourceCulture);

		internal static string UseLanguageSettings => LanguageText_cz.ResourceManager.GetString("UseLanguageSettings", LanguageText_cz.resourceCulture);

		internal static string User => LanguageText_cz.ResourceManager.GetString("User", LanguageText_cz.resourceCulture);

		internal static string UserRights => LanguageText_cz.ResourceManager.GetString("UserRights", LanguageText_cz.resourceCulture);

		internal static string USTime => LanguageText_cz.ResourceManager.GetString("USTime", LanguageText_cz.resourceCulture);

		internal static string Valid => LanguageText_cz.ResourceManager.GetString("Valid", LanguageText_cz.resourceCulture);

		internal static string Value => LanguageText_cz.ResourceManager.GetString("Value", LanguageText_cz.resourceCulture);

		internal static string ValueRange => LanguageText_cz.ResourceManager.GetString("ValueRange", LanguageText_cz.resourceCulture);

		internal static string ValuesNotApplied => LanguageText_cz.ResourceManager.GetString("ValuesNotApplied", LanguageText_cz.resourceCulture);

		internal static string VersionController => LanguageText_cz.ResourceManager.GetString("VersionController", LanguageText_cz.resourceCulture);

		internal static string VersionInfo => LanguageText_cz.ResourceManager.GetString("VersionInfo", LanguageText_cz.resourceCulture);

		internal static string VersionVisu => LanguageText_cz.ResourceManager.GetString("VersionVisu", LanguageText_cz.resourceCulture);

		internal static string Visualisation => LanguageText_cz.ResourceManager.GetString("Visualisation", LanguageText_cz.resourceCulture);

		internal static string VisuParam => LanguageText_cz.ResourceManager.GetString("VisuParam", LanguageText_cz.resourceCulture);

		internal static string Voltage => LanguageText_cz.ResourceManager.GetString("Voltage", LanguageText_cz.resourceCulture);

		internal static string WaitForAck => LanguageText_cz.ResourceManager.GetString("WaitForAck", LanguageText_cz.resourceCulture);

		internal static string Warning => LanguageText_cz.ResourceManager.GetString("Warning", LanguageText_cz.resourceCulture);

		internal static string WarningMode => LanguageText_cz.ResourceManager.GetString("WarningMode", LanguageText_cz.resourceCulture);

		internal static string WarningNumber => LanguageText_cz.ResourceManager.GetString("WarningNumber", LanguageText_cz.resourceCulture);

		internal static string WasReset => LanguageText_cz.ResourceManager.GetString("WasReset", LanguageText_cz.resourceCulture);

		internal static string WasSet => LanguageText_cz.ResourceManager.GetString("WasSet", LanguageText_cz.resourceCulture);

		internal static string WeberCurveFormat => LanguageText_cz.ResourceManager.GetString("WeberCurveFormat", LanguageText_cz.resourceCulture);

		internal static string WN => LanguageText_cz.ResourceManager.GetString("WN", LanguageText_cz.resourceCulture);

		internal static string WriteLastNIOTable => LanguageText_cz.ResourceManager.GetString("WriteLastNIOTable", LanguageText_cz.resourceCulture);

		internal static string WriteLastResultsTable => LanguageText_cz.ResourceManager.GetString("WriteLastResultsTable", LanguageText_cz.resourceCulture);

		internal static string WriteLogbookData => LanguageText_cz.ResourceManager.GetString("WriteLogbookData", LanguageText_cz.resourceCulture);

		internal static string WriteLogBookTable => LanguageText_cz.ResourceManager.GetString("WriteLogBookTable", LanguageText_cz.resourceCulture);

		internal static string WriteStepResults => LanguageText_cz.ResourceManager.GetString("WriteStepResults", LanguageText_cz.resourceCulture);

		internal static string Xmax => LanguageText_cz.ResourceManager.GetString("Xmax", LanguageText_cz.resourceCulture);

		internal static string Xmin => LanguageText_cz.ResourceManager.GetString("Xmin", LanguageText_cz.resourceCulture);

		internal static string XmlExport => LanguageText_cz.ResourceManager.GetString("XmlExport", LanguageText_cz.resourceCulture);

		internal static string Yes => LanguageText_cz.ResourceManager.GetString("Yes", LanguageText_cz.resourceCulture);

		internal static string ZoomIn => LanguageText_cz.ResourceManager.GetString("ZoomIn", LanguageText_cz.resourceCulture);

		internal static string ZoomOut => LanguageText_cz.ResourceManager.GetString("ZoomOut", LanguageText_cz.resourceCulture);

		internal LanguageText_cz()
		{
		}
	}
}
