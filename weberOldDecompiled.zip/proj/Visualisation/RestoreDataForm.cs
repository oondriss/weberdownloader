using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Resources;
using System.Windows.Forms;

namespace Visualisation
{
	public class RestoreDataForm : Form
	{
		public const int _ABORTED = 1;

		public const int FILES_SELECTED = 2;

		private ResourceManager Rm;

		private MainForm Main;

		private FtpClass ftpClass;

		private string directoryName;

		private string stationIpAddress;

		private string stationName;

		private int result = 1;

		public FileWithAttrList FilesWithAttributes = new FileWithAttrList();

		private bool canceled;

		private string[] filePaths;

		private IContainer components;

		private Button btCancel;

		private Button btOk;

		private CheckBox chBProgramData;

		private CheckBox chBSpindleConstants;

		private CheckBox chBSystemConstants;

		private CheckBox chBMachineVisuData;

		private CheckBox chBMaintenanceData;

		private Label label1;

		private Timer timer1;

		public int Result => this.result;

		public bool Canceled => this.canceled;

		public RestoreDataForm(MainForm main, string _directoryName, string station, string stationIP)
		{
			this.InitializeComponent();
			this.Main = main;
			this.Rm = this.Main.Rm;
			this.directoryName = _directoryName;
			this.stationIpAddress = stationIP;
			this.stationName = station;
			this.Text = this.Rm.GetString("SelectFilesForRestore");
			this.label1.Text = this.Rm.GetString("StationName") + ": " + this.stationName + " " + this.stationIpAddress;
			this.btOk.Text = this.Rm.GetString("btRestore");
			this.ftpClass = new FtpClass(main);
			this.chBProgramData.Checked = false;
			this.chBSpindleConstants.Checked = false;
			this.chBSystemConstants.Checked = false;
			this.chBMachineVisuData.Checked = false;
			this.chBMaintenanceData.Checked = false;
			this.chBProgramData.Enabled = false;
			this.chBSpindleConstants.Enabled = false;
			this.chBSystemConstants.Enabled = false;
			this.chBMachineVisuData.Enabled = false;
			this.chBMaintenanceData.Enabled = false;
			this.chBProgramData.ForeColor = Color.Red;
			this.chBSpindleConstants.ForeColor = Color.Red;
			this.chBSystemConstants.ForeColor = Color.Red;
			this.chBMachineVisuData.ForeColor = Color.Red;
			this.chBMaintenanceData.ForeColor = Color.Red;
			this.chBProgramData.Text = this.Rm.GetString("ProgramData");
			this.chBSpindleConstants.Text = this.Rm.GetString("MSpindleConstants");
			this.chBSystemConstants.Text = this.Rm.GetString("MSystemConstants") + ", " + this.Rm.GetString("LogBook");
			this.chBMachineVisuData.Text = this.Rm.GetString("MachineVisuData");
			if (this.Main.PassCodeLevel >= 5)
			{
				this.chBMaintenanceData.Text = this.Rm.GetString("MaintenanceData");
			}
			else
			{
				this.chBMaintenanceData.Visible = false;
			}
		}

		private void RestoreIsiSaveDataForm_Load(object sender, EventArgs e)
		{
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			this.timer1.Stop();
			int num = 0;
			try
			{
				FtpClass ftpClass = new FtpClass(null);
				this.filePaths = Directory.GetFiles(this.directoryName);
				int num2 = 0;
				string[] array = this.filePaths;
				foreach (string text in array)
				{
					string text2 = "";
					string text3 = text;
					if (ftpClass.IsInCompleteFileList(Path.GetFileName(text3), out text2))
					{
						bool flag = false;
						switch (text2)
						{
						case "pprog":
							this.chBProgramData.Checked = true;
							this.chBProgramData.Enabled = true;
							this.chBProgramData.ForeColor = Color.Black;
							num++;
							flag = true;
							break;
						case "spindleconst":
							this.chBSpindleConstants.Checked = true;
							this.chBSpindleConstants.Enabled = true;
							this.chBSpindleConstants.ForeColor = Color.Black;
							num++;
							flag = true;
							break;
						case "sysconst":
						case "netconf.reg":
						case "logbook":
							this.chBSystemConstants.Checked = true;
							this.chBSystemConstants.Enabled = true;
							this.chBSystemConstants.ForeColor = Color.Black;
							num++;
							flag = true;
							break;
						case "plc_config":
						case "id_table":
						case "logfile.csv":
							this.chBMachineVisuData.Checked = true;
							this.chBMachineVisuData.Enabled = true;
							this.chBMachineVisuData.ForeColor = Color.Black;
							num++;
							flag = true;
							break;
						case "compo":
						case "maint":
							if (this.Main.PassCodeLevel >= 5)
							{
								this.chBMaintenanceData.Checked = true;
								this.chBMaintenanceData.Enabled = true;
								this.chBMaintenanceData.ForeColor = Color.Black;
								num++;
								flag = true;
							}
							break;
						}
						if (flag)
						{
							this.FilesWithAttributes.Add(text3, text2, true);
						}
					}
				}
				num2++;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, this.Rm.GetString("MbhError ") + this.Text);
			}
			if (num == 0)
			{
				MessageBox.Show(this.Rm.GetString("MbNoFilesFoundForBackup"), this.Rm.GetString("MbhError "));
				base.Close();
			}
		}

		private void btOk_Click(object sender, EventArgs e)
		{
			this.btOk.Enabled = false;
			this.btCancel.Enabled = false;
			this.Cursor = Cursors.WaitCursor;
			Application.DoEvents();
			if (!this.chBMachineVisuData.Checked)
			{
				this.FilesWithAttributes.Disable("plc_config");
				this.FilesWithAttributes.Disable("id_table");
				this.FilesWithAttributes.Disable("logfile.csv");
			}
			if (!this.chBMaintenanceData.Visible || !this.chBMaintenanceData.Checked)
			{
				this.FilesWithAttributes.Disable("compo");
				this.FilesWithAttributes.Disable("maint");
			}
			if (!this.chBProgramData.Checked)
			{
				this.FilesWithAttributes.Disable("pprog");
			}
			if (!this.chBSpindleConstants.Checked)
			{
				this.FilesWithAttributes.Disable("spindleconst");
			}
			if (!this.chBSystemConstants.Checked)
			{
				this.FilesWithAttributes.Disable("logbook");
				this.FilesWithAttributes.Disable("sysconst");
				this.FilesWithAttributes.Disable("netconf.reg");
			}
			if (this.chBMachineVisuData.Checked || this.chBMaintenanceData.Checked || this.chBProgramData.Checked || this.chBSpindleConstants.Checked || this.chBSystemConstants.Checked)
			{
				this.result = 2;
			}
			this.Cursor = Cursors.Default;
			base.Close();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.canceled = true;
			base.Close();
		}

		public void Cancel()
		{
			if (base.Visible)
			{
				this.result = 1;
				base.Close();
			}
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (msg.WParam.ToInt32() == 27)
			{
				this.btCancel_Click(null, null);
			}
			else if (keyData == Keys.Return && this.btOk.Enabled)
			{
				this.btOk_Click(null, null);
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}

		private void RestoreIsiSaveDataForm_Activated(object sender, EventArgs e)
		{
		}

		private void RestoreDataForm_FormClosing(object sender, FormClosingEventArgs e)
		{
		}

		private void RestoreDataForm_Shown(object sender, EventArgs e)
		{
			this.canceled = false;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			this.btCancel = new Button();
			this.btOk = new Button();
			this.chBProgramData = new CheckBox();
			this.chBSpindleConstants = new CheckBox();
			this.chBSystemConstants = new CheckBox();
			this.chBMachineVisuData = new CheckBox();
			this.chBMaintenanceData = new CheckBox();
			this.label1 = new Label();
			this.timer1 = new Timer(this.components);
			base.SuspendLayout();
			this.btCancel.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.btCancel.Location = new Point(176, 162);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(106, 25);
			this.btCancel.TabIndex = 5;
			this.btCancel.Text = "Cancel";
			this.btCancel.UseVisualStyleBackColor = true;
			this.btCancel.Click += this.btCancel_Click;
			this.btOk.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.btOk.Location = new Point(51, 162);
			this.btOk.Name = "btOk";
			this.btOk.Size = new Size(106, 25);
			this.btOk.TabIndex = 4;
			this.btOk.Text = "Restore";
			this.btOk.UseVisualStyleBackColor = true;
			this.btOk.Click += this.btOk_Click;
			this.chBProgramData.AutoSize = true;
			this.chBProgramData.Location = new Point(48, 63);
			this.chBProgramData.Name = "chBProgramData";
			this.chBProgramData.RightToLeft = RightToLeft.No;
			this.chBProgramData.Size = new Size(89, 17);
			this.chBProgramData.TabIndex = 6;
			this.chBProgramData.Text = "Program data";
			this.chBProgramData.UseVisualStyleBackColor = true;
			this.chBSpindleConstants.AutoSize = true;
			this.chBSpindleConstants.Location = new Point(48, 86);
			this.chBSpindleConstants.Name = "chBSpindleConstants";
			this.chBSpindleConstants.RightToLeft = RightToLeft.No;
			this.chBSpindleConstants.Size = new Size(110, 17);
			this.chBSpindleConstants.TabIndex = 7;
			this.chBSpindleConstants.Text = "Spindle constants";
			this.chBSpindleConstants.UseVisualStyleBackColor = true;
			this.chBSystemConstants.AutoSize = true;
			this.chBSystemConstants.Location = new Point(48, 109);
			this.chBSystemConstants.Name = "chBSystemConstants";
			this.chBSystemConstants.RightToLeft = RightToLeft.No;
			this.chBSystemConstants.Size = new Size(173, 17);
			this.chBSystemConstants.TabIndex = 8;
			this.chBSystemConstants.Text = "System constants, logging data";
			this.chBSystemConstants.UseVisualStyleBackColor = true;
			this.chBMachineVisuData.AutoSize = true;
			this.chBMachineVisuData.Location = new Point(48, 40);
			this.chBMachineVisuData.Name = "chBMachineVisuData";
			this.chBMachineVisuData.RightToLeft = RightToLeft.No;
			this.chBMachineVisuData.Size = new Size(151, 17);
			this.chBMachineVisuData.TabIndex = 9;
			this.chBMachineVisuData.Text = "Machine visualisation data";
			this.chBMachineVisuData.UseVisualStyleBackColor = true;
			this.chBMaintenanceData.AutoSize = true;
			this.chBMaintenanceData.Location = new Point(48, 132);
			this.chBMaintenanceData.Name = "chBMaintenanceData";
			this.chBMaintenanceData.RightToLeft = RightToLeft.No;
			this.chBMaintenanceData.Size = new Size(203, 17);
			this.chBMaintenanceData.TabIndex = 10;
			this.chBMaintenanceData.Text = "Maintenance data (Administrator only)";
			this.chBMaintenanceData.UseVisualStyleBackColor = true;
			this.label1.AutoSize = true;
			this.label1.Location = new Point(45, 9);
			this.label1.Name = "label1";
			this.label1.Size = new Size(35, 13);
			this.label1.TabIndex = 13;
			this.label1.Text = "label1";
			this.timer1.Enabled = true;
			this.timer1.Tick += this.timer1_Tick;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(476, 205);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.chBMaintenanceData);
			base.Controls.Add(this.chBMachineVisuData);
			base.Controls.Add(this.chBSystemConstants);
			base.Controls.Add(this.chBSpindleConstants);
			base.Controls.Add(this.chBProgramData);
			base.Controls.Add(this.btCancel);
			base.Controls.Add(this.btOk);
			base.FormBorderStyle = FormBorderStyle.FixedSingle;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "RestoreDataForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			this.Text = "RestoreIsiSaveDataForm";
			base.Activated += this.RestoreIsiSaveDataForm_Activated;
			base.FormClosing += this.RestoreDataForm_FormClosing;
			base.Load += this.RestoreIsiSaveDataForm_Load;
			base.Shown += this.RestoreDataForm_Shown;
			base.ResumeLayout(false);
			base.PerformLayout();
		}
	}
}
