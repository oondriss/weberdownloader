using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class ProgPreview : Form
	{
		private MainForm Main;

		private IContainer components;

		private DataGridView dGVSteps;

		public ProgPreview(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.dGVSteps.Columns.Add("Col1", "Stufe");
			this.dGVSteps.Columns.Add("Col2", "Stufenart");
			this.dGVSteps.Columns.Add("Col3", "Zielparameter");
			this.dGVSteps.Columns.Add("Col4", "Drehzahl");
			this.dGVSteps.Columns.Add("Col5", "Kraft");
			this.dGVSteps.Rows.Add(25);
		}

		public void SetLanguageTexts()
		{
			this.dGVSteps.Columns[0].HeaderText = this.Main.Rm.GetString("Step");
			this.dGVSteps.Columns[1].HeaderText = this.Main.Rm.GetString("StepKind");
			this.dGVSteps.Columns[2].HeaderText = this.Main.Rm.GetString("Target");
			this.dGVSteps.Columns[3].HeaderText = this.Main.Rm.GetString("RoundsPerMinute");
			this.dGVSteps.Columns[4].HeaderText = this.Main.Rm.GetString("Force");
		}

		public void UpdateMenu(WSP1_VarComm.ProgStruct prog)
		{
			string empty = string.Empty;
			this.Text = this.Main.CommonFunctions.UShortToString(prog.Info.Name) + " ";
			this.dGVSteps.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			this.dGVSteps.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			this.dGVSteps.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			this.dGVSteps.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			this.dGVSteps.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			this.dGVSteps.Rows.Clear();
			if (prog.Info.Steps > 0)
			{
				this.dGVSteps.Rows.Add(prog.Info.Steps);
			}
			for (int i = 0; i < prog.Info.Steps; i++)
			{
				this.dGVSteps.Rows[i].Cells[0].Value = i + 1;
				switch (prog.Step[i].Type)
				{
				case 2:
					empty = this.Main.Rm.GetString("Driving");
					break;
				case 3:
					empty = this.Main.Rm.GetString("Finalizing");
					break;
				case 1:
					empty = this.Main.Rm.GetString("Organisation");
					break;
				case 0:
					empty = "No Type";
					break;
				default:
					empty = "Kein Typ";
					break;
				}
				this.dGVSteps.Rows[i].Cells[1].Value = empty;
				switch (prog.Step[i].Switch)
				{
				case 1:
					empty = ": " + prog.Step[i].MP.ToString("f" + 2.ToString());
					break;
				case 3:
					empty = ": " + prog.Step[i].MFP.ToString("f" + 2.ToString());
					break;
				case 2:
					empty = ": " + prog.Step[i].MRP.ToString("f" + 2.ToString());
					break;
				case 11:
					empty = ": " + prog.Step[i].MRP.ToString("f" + 2.ToString());
					break;
				case 4:
					empty = ": " + prog.Step[i].MGP.ToString("f" + 2.ToString());
					break;
				case 5:
					empty = ": " + prog.Step[i].WP.ToString("f" + 2.ToString());
					break;
				case 6:
					empty = ": " + prog.Step[i].TP.ToString("f" + 2.ToString());
					break;
				case 7:
					empty = ": " + prog.Step[i].LP.ToString("f" + 2.ToString());
					break;
				case 10:
					empty = ": " + prog.Step[i].LGP.ToString("f" + 2.ToString());
					break;
				case 8:
					empty = ": " + prog.Step[i].AnaP.ToString("f" + 2.ToString());
					break;
				case 9:
					switch (prog.Step[i].DigP)
					{
					case 1:
						empty = ": " + this.Main.Rm.GetString("TM1") + " (" + this.Main.Rm.GetString("Positive") + ")";
						break;
					case -1:
						empty = ": " + this.Main.Rm.GetString("TM1") + " (" + this.Main.Rm.GetString("Negative") + ")";
						break;
					case 2:
						empty = ": " + this.Main.Rm.GetString("TM2") + " (" + this.Main.Rm.GetString("Positive") + ")";
						break;
					case -2:
						empty = ": " + this.Main.Rm.GetString("TM2") + " (" + this.Main.Rm.GetString("Negative") + ")";
						break;
					case 3:
						empty = ": " + this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("Positive") + ")";
						break;
					case -3:
						empty = ": " + this.Main.Rm.GetString("DigitalSignal") + " (" + this.Main.Rm.GetString("Negative") + ")";
						break;
					case 4:
						empty = ": " + this.Main.Rm.GetString("JawOpen") + " (" + this.Main.Rm.GetString("Positive") + ")";
						break;
					case -4:
						empty = ": " + this.Main.Rm.GetString("JawOpen") + " (" + this.Main.Rm.GetString("Negative") + ")";
						break;
					case 5:
						empty = ": " + this.Main.Rm.GetString("SyncSignal") + "2 (" + this.Main.Rm.GetString("Positive") + ")";
						break;
					case -5:
						empty = ": " + this.Main.Rm.GetString("SyncSignal") + "2 (" + this.Main.Rm.GetString("Negative") + ")";
						break;
					default:
						empty = string.Empty;
						break;
					}
					break;
				case 50:
					empty = ": " + prog.Step[i].MP.ToString("f" + 2.ToString());
					break;
				case 51:
					empty = ": " + prog.Step[i].MFP.ToString("f" + 2.ToString());
					break;
				case 52:
					empty = ": " + prog.Step[i].MGP.ToString("f" + 2.ToString());
					break;
				case 53:
					empty = ": " + prog.Step[i].LP.ToString("f" + 2.ToString());
					break;
				case 55:
					empty = ": " + prog.Step[i].LGP.ToString("f" + 2.ToString());
					break;
				case 54:
					empty = ": " + prog.Step[i].AnaP.ToString("f" + 2.ToString());
					break;
				case 1000:
					empty = ": " + this.Main.Rm.GetString("Step") + (prog.Step[i].JumpTo + 1).ToString();
					break;
				case 1001:
					empty = ": " + this.Main.Rm.GetString("Step") + (prog.Step[i].JumpTo + 1).ToString();
					break;
				case 1002:
					empty = ": " + this.Main.Rm.GetString("Step") + (prog.Step[i].JumpTo + 1).ToString();
					break;
				case 1010:
					empty = string.Empty;
					break;
				case 1011:
					empty = string.Empty;
					break;
				case 1012:
					empty = string.Empty;
					break;
				case 1020:
					empty = string.Empty;
					break;
				case 1030:
					switch (prog.Step[i].ModDigOut)
					{
					case 1:
						empty = ": " + this.Main.Rm.GetString("DigitOut") + "1 (" + this.Main.Rm.GetString("SetOn") + ")";
						break;
					case -1:
						empty = ": " + this.Main.Rm.GetString("DigitOut") + "1 (" + this.Main.Rm.GetString("SetOff") + ")";
						break;
					case 2:
						empty = ": " + this.Main.Rm.GetString("DigitOut") + "2 (" + this.Main.Rm.GetString("SetOn") + ")";
						break;
					case -2:
						empty = ": " + this.Main.Rm.GetString("DigitOut") + "2 (" + this.Main.Rm.GetString("SetOff") + ")";
						break;
					case 3:
						empty = ": " + this.Main.Rm.GetString("JawOpen") + " (" + this.Main.Rm.GetString("SetOn") + ")";
						break;
					case -3:
						empty = ": " + this.Main.Rm.GetString("JawOpen") + " (" + this.Main.Rm.GetString("SetOff") + ")";
						break;
					case 4:
						empty = ": " + this.Main.Rm.GetString("SyncOut") + "2 (" + this.Main.Rm.GetString("SetOn") + ")";
						break;
					case -4:
						empty = ": " + this.Main.Rm.GetString("SyncOut") + "2 (" + this.Main.Rm.GetString("SetOff") + ")";
						break;
					default:
						empty = string.Empty;
						break;
					}
					break;
				case 1040:
					empty = string.Empty;
					break;
				default:
					empty = ": Internal Error!";
					break;
				}
				this.dGVSteps.Rows[i].Cells[2].Value = this.Main.CommonFunctions.GetSwitchName(prog.Step[i].Switch) + empty + this.Main.CommonFunctions.GetSwitchUnit(prog.Step[i].Switch);
				if (prog.Step[i].Type == 2 || prog.Step[i].Type == 3)
				{
					this.dGVSteps.Rows[i].Cells[3].Value = prog.Step[i].NA.ToString("f0") + this.Main.Rm.GetString("RpmUnit");
					this.dGVSteps.Rows[i].Cells[4].Value = prog.Step[i].PressureSpindle.ToString("f" + 2) + this.Main.Rm.GetString("KiloNewton");
				}
			}
			this.dGVSteps.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			this.dGVSteps.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			this.dGVSteps.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			this.dGVSteps.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			this.dGVSteps.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
		}

		private void ProgPreview_FormClosing(object sender, FormClosingEventArgs e)
		{
			e.Cancel = true;
			this.Main.ProgramOverview1.CloseProgramPreview();
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
		}

		private void dGVSteps_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			this.dGVSteps[e.ColumnIndex, e.RowIndex].Style.BackColor = Color.White;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.dGVSteps = new DataGridView();
			((ISupportInitialize)this.dGVSteps).BeginInit();
			base.SuspendLayout();
			this.dGVSteps.AllowUserToAddRows = false;
			this.dGVSteps.AllowUserToDeleteRows = false;
			this.dGVSteps.AllowUserToResizeRows = false;
			this.dGVSteps.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dGVSteps.Location = new Point(0, 0);
			this.dGVSteps.MultiSelect = false;
			this.dGVSteps.Name = "dGVSteps";
			this.dGVSteps.ReadOnly = true;
			this.dGVSteps.RowHeadersVisible = false;
			this.dGVSteps.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			this.dGVSteps.Size = new Size(444, 522);
			this.dGVSteps.TabIndex = 2;
			this.dGVSteps.CellFormatting += this.dGVSteps_CellFormatting;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(444, 522);
			base.Controls.Add(this.dGVSteps);
			base.FormBorderStyle = FormBorderStyle.Fixed3D;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "ProgPreview";
			base.Opacity = 0.95;
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			this.Text = "ProgPreview";
			base.TopMost = true;
			base.FormClosing += this.ProgPreview_FormClosing;
			((ISupportInitialize)this.dGVSteps).EndInit();
			base.ResumeLayout(false);
		}
	}
}
