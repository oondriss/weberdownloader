using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class BackupForm : Form
	{
		private MainForm Main;

		private FileOperationForm backupFileOperation;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Button btAbortDownload;

		private Button bt5;

		private Button bt4;

		private Button bt3;

		private Button bt2;

		private Button btFileOperation;

		private GroupBox gBLoadBackup;

		private Button btLoadWeberBackup;

		private Button btLoadCustBackup;

		private GroupBox gBSaveBackup;

		private Button btSaveCustBackup;

		private Button btSaveWeberBackup;

		private OpenFileDialog openFileDialog;

		private SaveFileDialog saveFileDialog;

		private GroupBox groupBox6;

		private Label lbExplain;

		private Container components;

		private RestoreDataForm restoreForm;

		public BackupForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.backupFileOperation = new FileOperationForm(main, 3);
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btAbortDownload = new Button();
			this.bt5 = new Button();
			this.bt4 = new Button();
			this.bt3 = new Button();
			this.bt2 = new Button();
			this.btFileOperation = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.gBLoadBackup = new GroupBox();
			this.btLoadCustBackup = new Button();
			this.btLoadWeberBackup = new Button();
			this.gBSaveBackup = new GroupBox();
			this.btSaveCustBackup = new Button();
			this.btSaveWeberBackup = new Button();
			this.openFileDialog = new OpenFileDialog();
			this.saveFileDialog = new SaveFileDialog();
			this.groupBox6 = new GroupBox();
			this.lbExplain = new Label();
			this.pnMenu.SuspendLayout();
			this.gBLoadBackup.SuspendLayout();
			this.gBSaveBackup.SuspendLayout();
			this.groupBox6.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btAbortDownload);
			this.pnMenu.Controls.Add(this.bt5);
			this.pnMenu.Controls.Add(this.bt4);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.btFileOperation);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btAbortDownload.Enabled = false;
			this.btAbortDownload.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btAbortDownload.Location = new Point(3, 451);
			this.btAbortDownload.Name = "btAbortDownload";
			this.btAbortDownload.Size = new Size(74, 62);
			this.btAbortDownload.TabIndex = 7;
			this.btAbortDownload.Click += this.btAbortDownload_Click;
			this.bt5.Enabled = false;
			this.bt5.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt5.Location = new Point(3, 131);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(74, 62);
			this.bt5.TabIndex = 6;
			this.bt4.Enabled = false;
			this.bt4.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt4.Location = new Point(3, 323);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(74, 62);
			this.bt4.TabIndex = 5;
			this.bt4.Click += this.btLoadCustBackup_Click;
			this.bt3.Enabled = false;
			this.bt3.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt3.Location = new Point(3, 259);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 4;
			this.bt3.Click += this.btLoadWeberBackup_Click;
			this.bt2.Enabled = false;
			this.bt2.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt2.Location = new Point(3, 195);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 3;
			this.bt2.Click += this.btSaveCustBackup_Click;
			this.btFileOperation.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btFileOperation.Location = new Point(3, 387);
			this.btFileOperation.Name = "btFileOperation";
			this.btFileOperation.Size = new Size(74, 62);
			this.btFileOperation.TabIndex = 2;
			this.btFileOperation.Text = "Datei Funktionen";
			this.btFileOperation.Click += this.btFileOperation_Click;
			this.btHelp.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.gBLoadBackup.Controls.Add(this.btLoadCustBackup);
			this.gBLoadBackup.Controls.Add(this.btLoadWeberBackup);
			this.gBLoadBackup.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBLoadBackup.Location = new Point(3, 63);
			this.gBLoadBackup.Name = "gBLoadBackup";
			this.gBLoadBackup.Size = new Size(432, 192);
			this.gBLoadBackup.TabIndex = 1;
			this.gBLoadBackup.TabStop = false;
			this.gBLoadBackup.Text = "Backup laden";
			this.btLoadCustBackup.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btLoadCustBackup.Location = new Point(40, 32);
			this.btLoadCustBackup.Name = "btLoadCustBackup";
			this.btLoadCustBackup.Size = new Size(352, 62);
			this.btLoadCustBackup.TabIndex = 0;
			this.btLoadCustBackup.Text = "Kunden Backup laden";
			this.btLoadCustBackup.Click += this.btLoadCustBackup_Click;
			this.btLoadWeberBackup.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btLoadWeberBackup.Location = new Point(40, 112);
			this.btLoadWeberBackup.Name = "btLoadWeberBackup";
			this.btLoadWeberBackup.Size = new Size(352, 62);
			this.btLoadWeberBackup.TabIndex = 1;
			this.btLoadWeberBackup.Text = "Weber Backup laden";
			this.btLoadWeberBackup.Click += this.btLoadWeberBackup_Click;
			this.gBSaveBackup.Controls.Add(this.btSaveCustBackup);
			this.gBSaveBackup.Controls.Add(this.btSaveWeberBackup);
			this.gBSaveBackup.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBSaveBackup.Location = new Point(3, 279);
			this.gBSaveBackup.Name = "gBSaveBackup";
			this.gBSaveBackup.Size = new Size(432, 192);
			this.gBSaveBackup.TabIndex = 2;
			this.gBSaveBackup.TabStop = false;
			this.gBSaveBackup.Text = "Backup speichern";
			this.btSaveCustBackup.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btSaveCustBackup.Location = new Point(40, 32);
			this.btSaveCustBackup.Name = "btSaveCustBackup";
			this.btSaveCustBackup.Size = new Size(352, 62);
			this.btSaveCustBackup.TabIndex = 0;
			this.btSaveCustBackup.Text = "Kunden Backup speichern";
			this.btSaveCustBackup.Click += this.btSaveCustBackup_Click;
			this.btSaveWeberBackup.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btSaveWeberBackup.Location = new Point(40, 112);
			this.btSaveWeberBackup.Name = "btSaveWeberBackup";
			this.btSaveWeberBackup.Size = new Size(352, 62);
			this.btSaveWeberBackup.TabIndex = 1;
			this.btSaveWeberBackup.Text = "Weber Backup speichern";
			this.btSaveWeberBackup.Click += this.btSaveWeberBackup_Click;
			this.openFileDialog.Filter = "Spindle Constants|*.wspc|All Files|*.*";
			this.saveFileDialog.Filter = "Spindle Constants|*.wspc|All Files|*.*";
			this.groupBox6.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.groupBox6.Controls.Add(this.lbExplain);
			this.groupBox6.Location = new Point(446, 389);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new Size(260, 62);
			this.groupBox6.TabIndex = 10;
			this.groupBox6.TabStop = false;
			this.lbExplain.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.lbExplain.Location = new Point(6, 15);
			this.lbExplain.Name = "lbExplain";
			this.lbExplain.Size = new Size(239, 41);
			this.lbExplain.TabIndex = 6;
			this.lbExplain.Text = "Anzahl in der Liste:";
			this.lbExplain.TextAlign = ContentAlignment.MiddleRight;
			this.lbExplain.Click += this.btFileOperation_Click;
			this.lbExplain.MouseDown += this.lb_MouseDown;
			this.lbExplain.MouseLeave += this.lb_MouseLeave;
			this.lbExplain.MouseUp += this.lb_MouseUp;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.groupBox6);
			base.Controls.Add(this.gBSaveBackup);
			base.Controls.Add(this.gBLoadBackup);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "BackupForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen/Backup";
			base.Activated += this.BackupForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBLoadBackup.ResumeLayout(false);
			this.gBSaveBackup.ResumeLayout(false);
			this.groupBox6.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public void ShowWindow()
		{
			this.Main.StatusBarText(string.Empty);
			this.MenEna();
			base.Show();
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MBackup");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btLoadCustBackup.Text = this.Main.Rm.GetString("LoadCustBackup");
			this.btLoadWeberBackup.Text = this.Main.Rm.GetString("LoadWeberBackup");
			this.btSaveCustBackup.Text = this.Main.Rm.GetString("SaveCustBackup");
			this.btSaveWeberBackup.Text = this.Main.Rm.GetString("SaveWeberBackup");
			this.btFileOperation.Text = this.Main.Rm.GetString("FileOperation");
			this.gBLoadBackup.Text = this.Main.Rm.GetString("gBLoadBackup");
			this.gBSaveBackup.Text = this.Main.Rm.GetString("gBSaveBackup");
			this.lbExplain.Text = this.Main.Rm.GetString("DeclForBackupSave");
			this.backupFileOperation.SetLanguageTexts();
			this.openFileDialog.Filter = this.Main.Rm.GetString("SpindleConstFiles") + "|*.wspc|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.saveFileDialog.Filter = this.Main.Rm.GetString("SpindleConstFiles") + "|*.wspc|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
		}

		private void MenEna()
		{
			bool enabled = false;
			bool flag = false;
			if (this.Main.PassCodeLevel >= 5)
			{
				flag = true;
			}
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_BackupForm)
			{
				enabled = true;
			}
			this.gBLoadBackup.Visible = flag;
			this.gBSaveBackup.Visible = flag;
			this.btLoadCustBackup.Enabled = enabled;
			this.btLoadWeberBackup.Enabled = enabled;
			this.btSaveCustBackup.Enabled = enabled;
			this.btSaveWeberBackup.Enabled = flag;
			this.btFileOperation.Enabled = true;
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_BackupForm, false);
			this.Main.ResetBrowserGrantedBy();
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.Main.StatusBarText(string.Empty);
			this.Main.LoggingFinished(true);
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_4_Backupverwaltung";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_4_Backupverwaltung");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btSaveWeberBackup_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("SaveWebBackupSecQuery"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
			if (dialogResult == DialogResult.Yes)
			{
				bool enabled = this.btLoadCustBackup.Enabled;
				bool enabled2 = this.btLoadWeberBackup.Enabled;
				bool enabled3 = this.btSaveCustBackup.Enabled;
				bool enabled4 = this.btSaveWeberBackup.Enabled;
				this.btLoadCustBackup.Enabled = false;
				this.btLoadWeberBackup.Enabled = false;
				this.btSaveCustBackup.Enabled = false;
				this.btSaveWeberBackup.Enabled = false;
				Application.DoEvents();
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveWeberBackupOnCF"));
				this.pnMenu.Enabled = false;
				if (!this.Main.SaveOnController(5, true))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Main.Rm.GetString("MbSaveWeberBackupFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.Main.MakeLogbookEntry(205001u, 6, 0f, 0f, 0u, 0, byte.MaxValue);
					this.Main.WriteLogbookData(true);
				}
				this.pnMenu.Enabled = true;
				this.pnMenu.Select();
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				this.btLoadCustBackup.Enabled = enabled;
				this.btLoadWeberBackup.Enabled = enabled2;
				this.btSaveCustBackup.Enabled = enabled3;
				this.btSaveWeberBackup.Enabled = enabled4;
			}
		}

		private void btSaveCustBackup_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("SaveCustBackupSecQuery"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
			if (dialogResult == DialogResult.Yes)
			{
				bool enabled = this.btLoadCustBackup.Enabled;
				bool enabled2 = this.btLoadWeberBackup.Enabled;
				bool enabled3 = this.btSaveCustBackup.Enabled;
				bool enabled4 = this.btSaveWeberBackup.Enabled;
				this.btLoadCustBackup.Enabled = false;
				this.btLoadWeberBackup.Enabled = false;
				this.btSaveCustBackup.Enabled = false;
				this.btSaveWeberBackup.Enabled = false;
				Application.DoEvents();
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveCustBackupOnCF"));
				this.pnMenu.Enabled = false;
				if (!this.Main.SaveOnController(7, true))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Main.Rm.GetString("MbSaveCustBackupFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.Main.MakeLogbookEntry(205000u, 6, 0f, 0f, 0u, 0, byte.MaxValue);
					this.Main.WriteLogbookData(true);
				}
				this.pnMenu.Enabled = true;
				this.pnMenu.Select();
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				this.btLoadCustBackup.Enabled = enabled;
				this.btLoadWeberBackup.Enabled = enabled2;
				this.btSaveCustBackup.Enabled = enabled3;
				this.btSaveWeberBackup.Enabled = enabled4;
			}
		}

		private void btLoadWeberBackup_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("LoadWebBackupSecQuery"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
			if (dialogResult == DialogResult.Yes)
			{
				bool enabled = this.btLoadCustBackup.Enabled;
				bool enabled2 = this.btLoadWeberBackup.Enabled;
				bool enabled3 = this.btSaveCustBackup.Enabled;
				bool enabled4 = this.btSaveWeberBackup.Enabled;
				this.btLoadCustBackup.Enabled = false;
				this.btLoadWeberBackup.Enabled = false;
				this.btSaveCustBackup.Enabled = false;
				this.btSaveWeberBackup.Enabled = false;
				Application.DoEvents();
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadWeberBackupFromCF"));
				this.pnMenu.Enabled = false;
				if (!this.Main.SaveOnController(6, true))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Main.Rm.GetString("MbLoadWeberBackupFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.Main.MakeLogbookEntry(205003u, 6, 0f, 0f, 0u, 0, byte.MaxValue);
					this.Main.WriteLogbookData(true);
				}
				this.pnMenu.Enabled = true;
				this.pnMenu.Select();
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				this.btLoadCustBackup.Enabled = enabled;
				this.btLoadWeberBackup.Enabled = enabled2;
				this.btSaveCustBackup.Enabled = enabled3;
				this.btSaveWeberBackup.Enabled = enabled4;
			}
		}

		private void btLoadCustBackup_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("LoadCustBackupSecQuery"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
			if (dialogResult == DialogResult.Yes)
			{
				bool enabled = this.btLoadCustBackup.Enabled;
				bool enabled2 = this.btLoadWeberBackup.Enabled;
				bool enabled3 = this.btSaveCustBackup.Enabled;
				bool enabled4 = this.btSaveWeberBackup.Enabled;
				this.btLoadCustBackup.Enabled = false;
				this.btLoadWeberBackup.Enabled = false;
				this.btSaveCustBackup.Enabled = false;
				this.btSaveWeberBackup.Enabled = false;
				Application.DoEvents();
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadCustBackupFromCF"));
				this.pnMenu.Enabled = false;
				if (!this.Main.SaveOnController(8, true))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Main.Rm.GetString("MbLoadCustBackupFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.Main.MakeLogbookEntry(205002u, 6, 0f, 0f, 0u, 0, byte.MaxValue);
					this.Main.WriteLogbookData(true);
					this.Main.ProcessProgram.UploadAllProgDataFromController();
				}
				this.pnMenu.Enabled = true;
				this.pnMenu.Select();
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				this.btLoadCustBackup.Enabled = enabled;
				this.btLoadWeberBackup.Enabled = enabled2;
				this.btSaveCustBackup.Enabled = enabled3;
				this.btSaveWeberBackup.Enabled = enabled4;
			}
		}

		private void BackupForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void btFileOperation_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnectionToController"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				if (this.Main.PassCodeLevel == 0 || this.Main._READ_ONLY_CONTROLLER)
				{
					this.backupFileOperation.DisableLoadFunction = true;
				}
				this.backupFileOperation.ShowDialog();
				if (this.backupFileOperation.FileOperationType != 0)
				{
					this.Cursor = Cursors.WaitCursor;
					string station = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName);
					string stationIP = this.Main.MyIp.ToString();
					if (Settings.Default.FileBackupOperationDefaultUse)
					{
						this.Main.FtpProgress.DefaultDirectory = Settings.Default.FileBackupOperationDefaultDirectory;
					}
					else
					{
						FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
						folderBrowserDialog.SelectedPath = Settings.Default.FileBackupOperationDefaultDirectory;
						if (folderBrowserDialog.ShowDialog() != DialogResult.OK)
						{
							this.Cursor = Cursors.Default;
							return;
						}
						Settings.Default.FileBackupOperationDefaultDirectory = (this.Main.FtpProgress.DefaultDirectory = folderBrowserDialog.SelectedPath);
						Settings.Default.Save();
					}
					switch (this.backupFileOperation.FileOperationType)
					{
					case 1:
						this.Main.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						this.restoreForm = new RestoreDataForm(this.Main, this.Main.FtpProgress.DefaultDirectory, station, stationIP);
						this.restoreForm.ShowDialog();
						if (this.restoreForm.Result == 1)
						{
							this.Cursor = Cursors.Default;
							this.restoreForm.Dispose();
							this.restoreForm = null;
							return;
						}
						if (MessageBox.Show(this.Main.Rm.GetString("RestoreOverwritesControllerSettings"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.OK)
						{
							this.restoreForm.Dispose();
							this.restoreForm = null;
						}
						else if (!this.Main.FtpProgress.StartUploadSettings(this.restoreForm.FilesWithAttributes.GetFileList(), true))
						{
							MessageBox.Show(this.Main.Rm.GetString("MbLoadCustBackupFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
							this.restoreForm.Dispose();
							this.restoreForm = null;
						}
						else
						{
							this.enableControls(false);
							this.restoreForm.Dispose();
							this.restoreForm = null;
						}
						break;
					case 2:
						this.Main.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						if (!this.Main.FtpProgress.StartDownloadSettings("", true))
						{
							MessageBox.Show(this.Main.Rm.GetString("MbSaveCustBackupFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
							if (this.restoreForm != null)
							{
								this.restoreForm.Dispose();
								this.restoreForm = null;
							}
						}
						else
						{
							this.enableControls(false);
						}
						break;
					default:
						MessageBox.Show("Wrong FileOperationType in btFileOperation_Click() of BackupConstants", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						break;
					case 0:
						break;
					}
					this.Cursor = Cursors.Default;
				}
			}
		}

		private void btAbortDownload_Click(object sender, EventArgs e)
		{
			this.Main.FtpProgress.Abort();
		}

		private void enableControls(bool enable)
		{
			this.btBack.Enabled = enable;
			this.btFileOperation.Enabled = enable;
			this.btHelp.Enabled = enable;
			this.gBLoadBackup.Enabled = enable;
			this.gBSaveBackup.Enabled = enable;
			this.Main.HelpButton = enable;
			if (enable)
			{
				this.btAbortDownload.Enabled = false;
				this.btAbortDownload.Text = "";
			}
			else
			{
				this.btAbortDownload.Enabled = true;
				this.btAbortDownload.Text = this.Main.Rm.GetString("Cancel");
			}
		}

		public void FtpBackupFinished()
		{
			if (this.Main.FtpProgress.DownloadStatus > FtpProgressForm.DOWNLOAD_STARTED)
			{
				this.Main.MakeLogbookEntry(205004u, 6, (float)this.Main.FtpProgress.DownloadStatus, (float)this.Main.FtpProgress.DownloadStatus, 0u, 0, 18);
				this.Main.WriteLogbookData(true);
			}
			else if (this.Main.FtpProgress.DownloadStatus == FtpProgressForm.DOWNLOAD_ABORED)
			{
				this.Main.MakeLogbookEntry(205005u, 6, 0f, 0f, 0u, 0, byte.MaxValue);
				this.Main.WriteLogbookData(true);
			}
			else if (this.Main.FtpProgress.DownloadStatus == FtpProgressForm.DOWNLOAD_ERROR)
			{
				this.Main.MakeLogbookEntry(205008u, 6, 0f, 0f, 0u, 0, byte.MaxValue);
				this.Main.WriteLogbookData(true);
			}
			this.enableControls(true);
		}

		public void FtpRestoreFinished()
		{
			if (this.Main.FtpProgress.DownloadStatus > FtpProgressForm.DOWNLOAD_STARTED)
			{
				this.Main.MakeLogbookEntry(205006u, 6, (float)this.Main.FtpProgress.DownloadStatus, (float)this.Main.FtpProgress.DownloadStatus, 0u, 0, 18);
				this.Main.WriteLogbookData(true);
				this.Main.StatusBarText("Reading new settings");
				Cursor.Current = Cursors.WaitCursor;
				this.Main.SaveOnController(9, false);
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
			}
			else if (this.Main.FtpProgress.DownloadStatus == FtpProgressForm.DOWNLOAD_ABORED)
			{
				this.Main.MakeLogbookEntry(205007u, 6, 0f, 0f, 0u, 0, byte.MaxValue);
				this.Main.WriteLogbookData(true);
			}
			else if (this.Main.FtpProgress.DownloadStatus == FtpProgressForm.DOWNLOAD_ERROR)
			{
				this.Main.MakeLogbookEntry(205009u, 6, 0f, 0f, 0u, 0, byte.MaxValue);
				this.Main.WriteLogbookData(true);
			}
			this.enableControls(true);
		}

		private void SaveToFiles()
		{
		}

		public void KeyArrived()
		{
			this.MenEna();
		}

		public void KeyRemoved()
		{
			this.backupFileOperation.Cancel();
			if (this.restoreForm != null)
			{
				this.restoreForm.Cancel();
			}
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void lbExplain_Click(object sender, EventArgs e)
		{
			this.btFileOperation_Click(sender, e);
		}

		private void lb_MouseDown(object sender, MouseEventArgs e)
		{
			this.lbExplain.BackColor = SystemColors.ControlLight;
		}

		private void lb_MouseLeave(object sender, EventArgs e)
		{
			this.lbExplain.BackColor = SystemColors.Control;
		}

		private void lb_MouseUp(object sender, MouseEventArgs e)
		{
			this.lbExplain.BackColor = SystemColors.Control;
		}
	}
}
