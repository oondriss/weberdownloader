using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Visualisation
{
	public class ComponentNewEntryForm : Form
	{
		public const int _ABORTED = 1;

		public const int NEWENTRY_PERFORMED = 2;

		private IContainer components;

		private Button btCancel;

		private Button btSave;

		private TextBox tBMaintenanceText;

		private Label lbReason;

		private Label lbModuleOrPart;

		private Label lbRemainingReason;

		private ComboBox cBModuleOrPart;

		private TextBox tBSerialNumber;

		private Label lbSerialNumber;

		private NumberEdit1 nEPieceCount;

		private Label lbPieceCount;

		private Label lbRemainingSerial;

		private Label lbRemainingModule;

		private MainForm Main;

		private int result = 1;

		private string maintenanceText = "";

		private string serialNumberText = "";

		private string moduleOrPartText = "";

		private uint pieceCount;

		private byte expiryLeadsTo;

		private bool isInitializing;

		private bool textChanging;

		public string MaintenanceText
		{
			get
			{
				return this.maintenanceText;
			}
			set
			{
				this.maintenanceText = value;
			}
		}

		public int MaxlenMaintenanceText
		{
			get;
			set;
		}

		public string SerialNumberText
		{
			get
			{
				return this.serialNumberText;
			}
			set
			{
				this.serialNumberText = value;
			}
		}

		public int MaxlenSerialNumberText
		{
			get;
			set;
		}

		public string ModuleOrPartText
		{
			get
			{
				return this.moduleOrPartText;
			}
			set
			{
				this.moduleOrPartText = value;
			}
		}

		public int MaxlenModuleOrPartText
		{
			get;
			set;
		}

		public uint PieceCount
		{
			get
			{
				return this.pieceCount;
			}
			set
			{
				this.pieceCount = value;
			}
		}

		public DateTime ScheduledTime
		{
			get;
			set;
		}

		public byte ExpiryLeadsTo => this.expiryLeadsTo;

		public int Result => this.result;

		public bool NewEntry
		{
			get;
			set;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.btCancel = new Button();
			this.btSave = new Button();
			this.tBMaintenanceText = new TextBox();
			this.lbReason = new Label();
			this.lbModuleOrPart = new Label();
			this.lbRemainingReason = new Label();
			this.cBModuleOrPart = new ComboBox();
			this.tBSerialNumber = new TextBox();
			this.lbSerialNumber = new Label();
			this.nEPieceCount = new NumberEdit1();
			this.lbPieceCount = new Label();
			this.lbRemainingSerial = new Label();
			this.lbRemainingModule = new Label();
			base.SuspendLayout();
			this.btCancel.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCancel.Location = new Point(166, 298);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(112, 64);
			this.btCancel.TabIndex = 5;
			this.btCancel.Text = "Abbrechen";
			this.btCancel.Click += this.btCancel_Click;
			this.btSave.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btSave.Location = new Point(29, 298);
			this.btSave.Name = "btSave";
			this.btSave.Size = new Size(112, 64);
			this.btSave.TabIndex = 4;
			this.btSave.Text = "Speichern + Zurück";
			this.btSave.Click += this.btSave_Click;
			this.tBMaintenanceText.BackColor = Color.White;
			this.tBMaintenanceText.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.tBMaintenanceText.Location = new Point(29, 161);
			this.tBMaintenanceText.MaxLength = 200;
			this.tBMaintenanceText.Multiline = true;
			this.tBMaintenanceText.Name = "tBMaintenanceText";
			this.tBMaintenanceText.Size = new Size(355, 75);
			this.tBMaintenanceText.TabIndex = 2;
			this.tBMaintenanceText.TextChanged += this.tBMaintenanceText_TextChanged;
			this.tBMaintenanceText.Enter += this.Start_Input;
			this.tBMaintenanceText.MouseDown += this.StartInput;
			this.lbReason.AutoSize = true;
			this.lbReason.Location = new Point(26, 140);
			this.lbReason.Name = "lbReason";
			this.lbReason.Size = new Size(44, 13);
			this.lbReason.TabIndex = 9;
			this.lbReason.Text = "Reason";
			this.lbModuleOrPart.AutoSize = true;
			this.lbModuleOrPart.Location = new Point(26, 19);
			this.lbModuleOrPart.Name = "lbModuleOrPart";
			this.lbModuleOrPart.Size = new Size(76, 13);
			this.lbModuleOrPart.TabIndex = 10;
			this.lbModuleOrPart.Text = "Module or Part";
			this.lbRemainingReason.AutoSize = true;
			this.lbRemainingReason.Location = new Point(325, 140);
			this.lbRemainingReason.Name = "lbRemainingReason";
			this.lbRemainingReason.Size = new Size(57, 13);
			this.lbRemainingReason.TabIndex = 13;
			this.lbRemainingReason.Text = "Remaining";
			this.lbRemainingReason.Visible = false;
			this.cBModuleOrPart.FormattingEnabled = true;
			this.cBModuleOrPart.Location = new Point(29, 37);
			this.cBModuleOrPart.Name = "cBModuleOrPart";
			this.cBModuleOrPart.Size = new Size(355, 21);
			this.cBModuleOrPart.Sorted = true;
			this.cBModuleOrPart.TabIndex = 0;
			this.cBModuleOrPart.DropDown += this.cBModuleOrPart_DropDown;
			this.cBModuleOrPart.SelectedIndexChanged += this.cBModuleOrPart_SelectedIndexChanged;
			this.cBModuleOrPart.TextChanged += this.cBModuleOrPart_TextChanged;
			this.cBModuleOrPart.Enter += this.Start_Input;
			this.cBModuleOrPart.MouseClick += this.StartInput;
			this.tBSerialNumber.BackColor = Color.White;
			this.tBSerialNumber.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.tBSerialNumber.Location = new Point(29, 95);
			this.tBSerialNumber.MaxLength = 200;
			this.tBSerialNumber.Multiline = true;
			this.tBSerialNumber.Name = "tBSerialNumber";
			this.tBSerialNumber.Size = new Size(355, 24);
			this.tBSerialNumber.TabIndex = 1;
			this.tBSerialNumber.TextChanged += this.tBSerialNumber_TextChanged;
			this.tBSerialNumber.Enter += this.Start_Input;
			this.tBSerialNumber.MouseDown += this.StartInput;
			this.lbSerialNumber.AutoSize = true;
			this.lbSerialNumber.Location = new Point(26, 77);
			this.lbSerialNumber.Name = "lbSerialNumber";
			this.lbSerialNumber.Size = new Size(70, 13);
			this.lbSerialNumber.TabIndex = 17;
			this.lbSerialNumber.Text = "SerialNumber";
			this.nEPieceCount.BackColor = Color.White;
			this.nEPieceCount.DecimalNum = 0;
			this.nEPieceCount.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEPieceCount.ForeColor = SystemColors.ControlText;
			this.nEPieceCount.Location = new Point(174, 248);
			this.nEPieceCount.MaxValue = 1E+07f;
			this.nEPieceCount.MinValue = 0f;
			this.nEPieceCount.Name = "nEPieceCount";
			this.nEPieceCount.Size = new Size(92, 24);
			this.nEPieceCount.TabIndex = 3;
			this.nEPieceCount.Text = "0";
			this.nEPieceCount.TextAlign = HorizontalAlignment.Right;
			this.nEPieceCount.Value = 0f;
			this.nEPieceCount.TextChanged += this.nEPieceCount_TextChanged;
			this.nEPieceCount.Enter += this.Start_Input;
			this.nEPieceCount.MouseDown += this.StartInput;
			this.lbPieceCount.AutoSize = true;
			this.lbPieceCount.Location = new Point(26, 253);
			this.lbPieceCount.Name = "lbPieceCount";
			this.lbPieceCount.Size = new Size(64, 13);
			this.lbPieceCount.TabIndex = 19;
			this.lbPieceCount.Text = "Piece count";
			this.lbRemainingSerial.AutoSize = true;
			this.lbRemainingSerial.Location = new Point(325, 77);
			this.lbRemainingSerial.Name = "lbRemainingSerial";
			this.lbRemainingSerial.Size = new Size(57, 13);
			this.lbRemainingSerial.TabIndex = 20;
			this.lbRemainingSerial.Text = "Remaining";
			this.lbRemainingSerial.Visible = false;
			this.lbRemainingModule.AutoSize = true;
			this.lbRemainingModule.Location = new Point(325, 19);
			this.lbRemainingModule.Name = "lbRemainingModule";
			this.lbRemainingModule.Size = new Size(57, 13);
			this.lbRemainingModule.TabIndex = 21;
			this.lbRemainingModule.Text = "Remaining";
			this.lbRemainingModule.Visible = false;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(448, 404);
			base.Controls.Add(this.lbRemainingModule);
			base.Controls.Add(this.lbRemainingSerial);
			base.Controls.Add(this.lbPieceCount);
			base.Controls.Add(this.nEPieceCount);
			base.Controls.Add(this.lbSerialNumber);
			base.Controls.Add(this.tBSerialNumber);
			base.Controls.Add(this.cBModuleOrPart);
			base.Controls.Add(this.lbRemainingReason);
			base.Controls.Add(this.lbModuleOrPart);
			base.Controls.Add(this.lbReason);
			base.Controls.Add(this.tBMaintenanceText);
			base.Controls.Add(this.btSave);
			base.Controls.Add(this.btCancel);
			base.FormBorderStyle = FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "ComponentNewEntryForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.CenterParent;
			this.Text = "New entry";
			base.Load += this.MaintenanceNewEntryForm_Load;
			base.Shown += this.ComponentNewEntryForm_Shown;
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public void AddModules(List<string> listOfModules, bool clearList)
		{
			if (clearList)
			{
				this.cBModuleOrPart.Items.Clear();
			}
			foreach (string listOfModule in listOfModules)
			{
				this.cBModuleOrPart.Items.Add(listOfModule);
			}
		}

		public ComponentNewEntryForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
		}

		private void MaintenanceNewEntryForm_Load(object sender, EventArgs e)
		{
			this.isInitializing = true;
			this.cBModuleOrPart.MaxLength = this.MaxlenModuleOrPartText;
			this.tBSerialNumber.MaxLength = this.MaxlenSerialNumberText;
			this.tBMaintenanceText.MaxLength = this.MaxlenMaintenanceText;
			this.lbRemainingReason.Text = (this.MaxlenMaintenanceText - this.tBMaintenanceText.Text.Length).ToString();
			this.lbRemainingModule.Text = (this.MaxlenModuleOrPartText - this.cBModuleOrPart.Text.Length).ToString();
			this.lbRemainingSerial.Text = (this.MaxlenSerialNumberText - this.tBSerialNumber.Text.Length).ToString();
			if (!this.NewEntry)
			{
				this.Text = this.Main.Rm.GetString("ChangeEntry");
				this.tBMaintenanceText.Text = this.maintenanceText;
				this.tBSerialNumber.Text = this.serialNumberText;
				this.cBModuleOrPart.Text = this.moduleOrPartText;
				this.nEPieceCount.Value = (float)(double)this.pieceCount;
			}
			else
			{
				this.Text = this.Main.Rm.GetString("btNewEntrie");
				this.tBMaintenanceText.Text = (this.maintenanceText = "");
				this.tBSerialNumber.Text = (this.serialNumberText = "");
				this.cBModuleOrPart.Text = (this.moduleOrPartText = "");
				this.nEPieceCount.Value = (float)(double)(this.pieceCount = 0u);
			}
			this.btSave.Enabled = false;
			this.SetLanguageTexts();
			this.result = 1;
		}

		public void SetLanguageTexts()
		{
			this.lbReason.Text = this.Main.Rm.GetString("ReasonOfChange");
			this.lbModuleOrPart.Text = this.Main.Rm.GetString("ModuleOrPart");
			this.lbSerialNumber.Text = this.Main.Rm.GetString("SerialNumber");
			this.lbPieceCount.Text = this.Main.Rm.GetString("PieceCount");
			this.tBMaintenanceText.Tag = this.lbReason.Text;
			this.tBSerialNumber.Tag = this.lbSerialNumber.Text;
			this.nEPieceCount.Tag = this.lbPieceCount.Text;
			this.cBModuleOrPart.Tag = this.lbModuleOrPart.Text;
			this.btSave.Text = this.Main.Rm.GetString("Apply");
			this.btCancel.Text = this.Main.Rm.GetString("Cancel");
		}

		private void btSave_Click(object sender, EventArgs e)
		{
			if (this.tBMaintenanceText.Text.Length == 0 || this.tBSerialNumber.Text.Length == 0 || this.cBModuleOrPart.Text.Length == 0)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbMissingEntry"), this.Main.Rm.GetString("MComponentStatistic"));
			}
			else
			{
				string text = "";
				if (!this.nEPieceCount.IsOK)
				{
					text = this.nEPieceCount.Tag + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEPieceCount.MinValue.ToString() + " - " + this.nEPieceCount.MaxValue.ToString() + "\n";
				}
				if (this.cBModuleOrPart.Text.Length > this.MaxlenModuleOrPartText)
				{
					text = this.cBModuleOrPart.Tag + " " + this.Main.Rm.GetString("MbTextToLong") + ": " + this.cBModuleOrPart.MaxLength.ToString() + " - \n";
				}
				if (this.tBSerialNumber.Text.Length > this.MaxlenSerialNumberText)
				{
					text = this.tBSerialNumber.Tag + " " + this.Main.Rm.GetString("MbTextToLong") + ": " + this.tBSerialNumber.MaxLength.ToString() + " - \n";
				}
				if (this.tBMaintenanceText.Text.Length > this.MaxlenMaintenanceText)
				{
					text = this.tBMaintenanceText.Tag + " " + this.Main.Rm.GetString("MbTextToLong") + ": " + this.tBMaintenanceText.MaxLength.ToString() + " - \n";
				}
				if (text.Length > 0)
				{
					MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + text, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.maintenanceText = this.tBMaintenanceText.Text;
					this.serialNumberText = this.tBSerialNumber.Text;
					this.moduleOrPartText = this.cBModuleOrPart.Text;
					this.pieceCount = (uint)this.nEPieceCount.Value;
					this.result = 2;
					base.Close();
				}
			}
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.result = 1;
			base.Close();
		}

		private void Start_Input(object sender, EventArgs e)
		{
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (sender is ComboBox && e.X > this.cBModuleOrPart.Size.Width - 20)
			{
				return;
			}
			string text = "";
			if (sender is TextBox)
			{
				text = ((TextBox)sender).Tag.ToString();
			}
			else if (sender is ComboBox)
			{
				this.cBModuleOrPart.MaxLength = this.MaxlenModuleOrPartText;
				text = ((ComboBox)sender).Tag.ToString();
			}
			if (!this.isInitializing)
			{
				this.Main.TextInput(sender, text);
			}
		}

		public void Cancel()
		{
			if (base.Visible)
			{
				this.result = 1;
				base.Close();
			}
		}

		private void tBMaintenanceText_TextChanged(object sender, EventArgs e)
		{
			if (!this.textChanging)
			{
				this.textChanging = true;
				if (this.tBMaintenanceText.Text.Length > 5)
				{
					this.btSave.Enabled = true;
				}
				else
				{
					this.btSave.Enabled = false;
				}
				if (this.tBMaintenanceText.Text.Length > this.MaxlenMaintenanceText)
				{
					this.tBMaintenanceText.Text = this.tBMaintenanceText.Text.Remove(this.MaxlenMaintenanceText);
				}
				int num = this.MaxlenMaintenanceText - this.tBMaintenanceText.Text.Length;
				this.lbRemainingReason.Text = num.ToString();
				if (num <= 0)
				{
					this.lbRemainingReason.BackColor = Color.Red;
					this.lbRemainingReason.ForeColor = Color.White;
				}
				else
				{
					this.lbRemainingReason.BackColor = SystemColors.Control;
					this.lbRemainingReason.ForeColor = Color.Black;
				}
				this.btSave.Enabled = true;
				this.textChanging = false;
			}
		}

		private void ComponentNewEntryForm_Shown(object sender, EventArgs e)
		{
			this.isInitializing = false;
		}

		private void tBSerialNumber_TextChanged(object sender, EventArgs e)
		{
			int num = this.MaxlenSerialNumberText - this.tBSerialNumber.Text.Length;
			this.lbRemainingSerial.Text = num.ToString();
			if (num <= 0)
			{
				this.lbSerialNumber.BackColor = Color.Red;
				this.lbSerialNumber.ForeColor = Color.White;
			}
			else
			{
				this.lbSerialNumber.BackColor = SystemColors.Control;
				this.lbSerialNumber.ForeColor = Color.Black;
			}
			this.btSave.Enabled = true;
		}

		private void cBModuleOrPart_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.btSave.Enabled = true;
		}

		private void cBModuleOrPart_TextChanged(object sender, EventArgs e)
		{
			int num = this.MaxlenModuleOrPartText - this.cBModuleOrPart.Text.Length;
			this.lbRemainingModule.Text = num.ToString();
			if (num <= 0)
			{
				this.lbModuleOrPart.BackColor = Color.Red;
				this.lbModuleOrPart.ForeColor = Color.White;
			}
			else
			{
				this.lbModuleOrPart.BackColor = SystemColors.Control;
				this.lbModuleOrPart.ForeColor = Color.Black;
			}
			this.btSave.Enabled = true;
		}

		private void nEPieceCount_TextChanged(object sender, EventArgs e)
		{
			this.btSave.Enabled = true;
		}

		private void cBModuleOrPart_DropDown(object sender, EventArgs e)
		{
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (msg.WParam.ToInt32() == 27)
			{
				base.Close();
			}
			else if (keyData == Keys.Return && this.btSave.Enabled)
			{
				this.btSave_Click(null, null);
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}
	}
}
