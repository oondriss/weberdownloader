using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class FileOperationForm : Form
	{
		public const int FILE_OPERATION_NONE = 0;

		public const int FILE_OPERATION_LOAD = 1;

		public const int FILE_OPERATION_SAVE = 2;

		public const int MENU_FOR_SPCONST = 1;

		public const int MENU_FOR_PPROG = 2;

		public const int MENU_FOR_BACKUP = 3;

		public bool DisableLoadFunction;

		private MainForm Main;

		public int FileOperationType;

		private int kind;

		private Button btLoad;

		private Button btSave;

		private Button btCancel;

		private Label lbDeclaration;

		private GroupBox gBDefaultDir;

		private Button btCangeDefautDir;

		private CheckBox chBUseDefault;

		private Container components;

		public FileOperationForm(MainForm main, int _kind)
		{
			this.Main = main;
			this.InitializeComponent();
			this.kind = _kind;
		}

		private void FileOperationForm_Load(object sender, EventArgs e)
		{
			if (this.kind == 1)
			{
				this.btLoad.Visible = true;
				this.gBDefaultDir.Text = Settings.Default.FileOperationDefaultDirectory;
				this.chBUseDefault.Checked = Settings.Default.FileOperationDefaultUse;
			}
			else
			{
				this.btLoad.Visible = true;
				this.gBDefaultDir.Text = Settings.Default.FileBackupOperationDefaultDirectory;
				this.chBUseDefault.Checked = Settings.Default.FileBackupOperationDefaultUse;
			}
			this.menEna();
		}

		public void Cancel()
		{
			this.btLoad.Enabled = true;
			if (base.Visible)
			{
				this.FileOperationType = 0;
				this.DisableLoadFunction = false;
				base.Close();
			}
		}

		private void menEna()
		{
			if (this.kind == 1)
			{
				this.btCangeDefautDir.Enabled = Settings.Default.FileOperationDefaultUse;
				this.btLoad.Enabled = true;
			}
			else
			{
				this.btCangeDefautDir.Enabled = Settings.Default.FileBackupOperationDefaultUse;
				if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_BackupForm)
				{
					this.btLoad.Enabled = true;
				}
				else
				{
					this.btLoad.Enabled = false;
				}
			}
			if (this.DisableLoadFunction)
			{
				this.btLoad.Enabled = false;
			}
			else
			{
				this.btLoad.Enabled = true;
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.btLoad = new Button();
			this.btSave = new Button();
			this.btCancel = new Button();
			this.lbDeclaration = new Label();
			this.gBDefaultDir = new GroupBox();
			this.btCangeDefautDir = new Button();
			this.chBUseDefault = new CheckBox();
			this.gBDefaultDir.SuspendLayout();
			base.SuspendLayout();
			this.btLoad.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btLoad.Location = new Point(16, 104);
			this.btLoad.Name = "btLoad";
			this.btLoad.Size = new Size(80, 80);
			this.btLoad.TabIndex = 0;
			this.btLoad.Text = "Laden aus Datei";
			this.btLoad.Click += this.btLoad_Click;
			this.btSave.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btSave.Location = new Point(112, 104);
			this.btSave.Name = "btSave";
			this.btSave.Size = new Size(80, 80);
			this.btSave.TabIndex = 1;
			this.btSave.Text = "Speichern in Datei";
			this.btSave.Click += this.btSave_Click;
			this.btCancel.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCancel.Location = new Point(19, 319);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(176, 40);
			this.btCancel.TabIndex = 2;
			this.btCancel.Text = "Abbrechen";
			this.btCancel.Click += this.btCancel_Click;
			this.lbDeclaration.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.lbDeclaration.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDeclaration.Location = new Point(16, 16);
			this.lbDeclaration.Name = "lbDeclaration";
			this.lbDeclaration.Size = new Size(167, 80);
			this.lbDeclaration.TabIndex = 3;
			this.gBDefaultDir.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.gBDefaultDir.Controls.Add(this.btCangeDefautDir);
			this.gBDefaultDir.Controls.Add(this.chBUseDefault);
			this.gBDefaultDir.FlatStyle = FlatStyle.System;
			this.gBDefaultDir.Font = new Font("Arial Unicode MS", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.gBDefaultDir.Location = new Point(8, 190);
			this.gBDefaultDir.Name = "gBDefaultDir";
			this.gBDefaultDir.Size = new Size(214, 117);
			this.gBDefaultDir.TabIndex = 6;
			this.gBDefaultDir.TabStop = false;
			this.gBDefaultDir.Text = "groupBox1";
			this.btCangeDefautDir.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btCangeDefautDir.Location = new Point(10, 68);
			this.btCangeDefautDir.Name = "btCangeDefautDir";
			this.btCangeDefautDir.Size = new Size(176, 40);
			this.btCangeDefautDir.TabIndex = 6;
			this.btCangeDefautDir.Text = "Change default directory";
			this.btCangeDefautDir.Click += this.btCangeDefautDir_Click;
			this.chBUseDefault.AutoSize = true;
			this.chBUseDefault.Font = new Font("Arial Unicode MS", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.chBUseDefault.Location = new Point(14, 34);
			this.chBUseDefault.Name = "chBUseDefault";
			this.chBUseDefault.Size = new Size(127, 19);
			this.chBUseDefault.TabIndex = 5;
			this.chBUseDefault.Text = "Use default directory";
			this.chBUseDefault.UseVisualStyleBackColor = true;
			this.chBUseDefault.CheckedChanged += this.chBUseDefault_CheckedChanged;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(234, 384);
			base.ControlBox = false;
			base.Controls.Add(this.gBDefaultDir);
			base.Controls.Add(this.lbDeclaration);
			base.Controls.Add(this.btCancel);
			base.Controls.Add(this.btSave);
			base.Controls.Add(this.btLoad);
			this.Font = new Font("Arial Unicode MS", 16f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.MaximizeBox = false;
			this.MaximumSize = new Size(700, 400);
			base.MinimizeBox = false;
			this.MinimumSize = new Size(250, 400);
			base.Name = "FileOperationForm";
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.CenterScreen;
			base.Load += this.FileOperationForm_Load;
			this.gBDefaultDir.ResumeLayout(false);
			this.gBDefaultDir.PerformLayout();
			base.ResumeLayout(false);
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("FileOperationMenu");
			this.btCancel.Text = this.Main.Rm.GetString("Cancel");
			this.btLoad.Text = this.Main.Rm.GetString("LoadFromFile");
			this.btSave.Text = this.Main.Rm.GetString("SaveToFile");
			switch (this.kind)
			{
			case 1:
				this.lbDeclaration.Text = this.Main.Rm.GetString("DeclForSpSave");
				break;
			case 2:
				this.lbDeclaration.Text = this.Main.Rm.GetString("DeclForProgSave");
				break;
			case 3:
				this.lbDeclaration.Text = this.Main.Rm.GetString("DeclForBackupSave");
				break;
			default:
				MessageBox.Show("Unknown menu type in SetLanguageTexts() in FileOperationForm", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				break;
			}
			this.btCangeDefautDir.Text = this.Main.Rm.GetString("btChangeDefaultDir");
			this.chBUseDefault.Text = this.Main.Rm.GetString("chBUseDefaultDir");
		}

		private void btLoad_Click(object sender, EventArgs e)
		{
			this.FileOperationType = 1;
			this.DisableLoadFunction = false;
			base.Close();
		}

		private void btSave_Click(object sender, EventArgs e)
		{
			this.btLoad.Enabled = true;
			this.FileOperationType = 2;
			this.DisableLoadFunction = false;
			base.Close();
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.btLoad.Enabled = true;
			this.FileOperationType = 0;
			this.DisableLoadFunction = false;
			base.Close();
		}

		private void btCangeDefautDir_Click(object sender, EventArgs e)
		{
			FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
			if (this.kind == 1)
			{
				folderBrowserDialog.SelectedPath = Settings.Default.FileOperationDefaultDirectory;
			}
			else
			{
				folderBrowserDialog.SelectedPath = Settings.Default.FileBackupOperationDefaultDirectory;
			}
			if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
			{
				this.gBDefaultDir.Text = folderBrowserDialog.SelectedPath;
				if (this.kind == 1)
				{
					Settings.Default.FileOperationDefaultDirectory = folderBrowserDialog.SelectedPath;
				}
				else
				{
					Settings.Default.FileBackupOperationDefaultDirectory = folderBrowserDialog.SelectedPath;
				}
				Settings.Default.Save();
			}
		}

		private void chBUseDefault_CheckedChanged(object sender, EventArgs e)
		{
			if (this.kind == 1)
			{
				if (!this.chBUseDefault.Checked)
				{
					Settings.Default.FileOperationDefaultUse = false;
				}
				else
				{
					Settings.Default.FileOperationDefaultUse = true;
					if (Settings.Default.FileOperationDefaultDirectory.Length == 0)
					{
						this.btCangeDefautDir_Click(null, null);
						if (Settings.Default.FileOperationDefaultDirectory.Length == 0)
						{
							this.chBUseDefault.Checked = false;
						}
					}
				}
			}
			else if (!this.chBUseDefault.Checked)
			{
				Settings.Default.FileBackupOperationDefaultUse = false;
			}
			else
			{
				Settings.Default.FileBackupOperationDefaultUse = true;
				if (Settings.Default.FileBackupOperationDefaultDirectory.Length == 0)
				{
					this.btCangeDefautDir_Click(null, null);
					if (Settings.Default.FileBackupOperationDefaultDirectory.Length == 0)
					{
						this.chBUseDefault.Checked = false;
					}
				}
			}
			Settings.Default.Save();
			this.menEna();
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (msg.WParam.ToInt32() == 27)
			{
				this.DisableLoadFunction = false;
				base.Close();
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}
	}
}
