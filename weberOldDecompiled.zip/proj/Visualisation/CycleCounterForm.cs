using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class CycleCounterForm : Form
	{
		private MainForm Main;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Button btDelete;

		private Container components;

		private Label lbMachineCounter;

		private Label lbCustomCounter;

		private Label lbShowMachineCounter;

		private Label lbShowCustomCounter;

		private Button bt5;

		private Button bt4;

		private Button bt2;

		private GroupBox gBMachineInfo;

		private Button btBrowser;

		private Button bt1;

		public CycleCounterForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btBrowser = new Button();
			this.bt5 = new Button();
			this.bt4 = new Button();
			this.bt2 = new Button();
			this.bt1 = new Button();
			this.btDelete = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.lbMachineCounter = new Label();
			this.lbCustomCounter = new Label();
			this.lbShowMachineCounter = new Label();
			this.lbShowCustomCounter = new Label();
			this.gBMachineInfo = new GroupBox();
			this.pnMenu.SuspendLayout();
			this.gBMachineInfo.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btBrowser);
			this.pnMenu.Controls.Add(this.bt5);
			this.pnMenu.Controls.Add(this.bt4);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.bt1);
			this.pnMenu.Controls.Add(this.btDelete);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btBrowser.Enabled = false;
			this.btBrowser.Location = new Point(3, 323);
			this.btBrowser.Name = "btBrowser";
			this.btBrowser.Size = new Size(74, 62);
			this.btBrowser.TabIndex = 10;
			this.btBrowser.Click += this.btBrowser_Click;
			this.bt5.Enabled = false;
			this.bt5.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt5.Location = new Point(3, 451);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(74, 62);
			this.bt5.TabIndex = 7;
			this.bt4.Enabled = false;
			this.bt4.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt4.Location = new Point(3, 387);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(74, 62);
			this.bt4.TabIndex = 6;
			this.bt2.Enabled = false;
			this.bt2.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt2.Location = new Point(3, 259);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 4;
			this.bt1.Enabled = false;
			this.bt1.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.bt1.Location = new Point(3, 195);
			this.bt1.Name = "bt1";
			this.bt1.Size = new Size(74, 62);
			this.bt1.TabIndex = 3;
			this.btDelete.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btDelete.Location = new Point(3, 131);
			this.btDelete.Name = "btDelete";
			this.btDelete.Size = new Size(74, 62);
			this.btDelete.TabIndex = 2;
			this.btDelete.Text = "Kundenzähler löschen";
			this.btDelete.Click += this.btDelete_Click;
			this.btHelp.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.lbMachineCounter.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbMachineCounter.Location = new Point(16, 32);
			this.lbMachineCounter.Name = "lbMachineCounter";
			this.lbMachineCounter.Size = new Size(136, 24);
			this.lbMachineCounter.TabIndex = 18;
			this.lbMachineCounter.Text = "Maschinenzähler";
			this.lbMachineCounter.TextAlign = ContentAlignment.MiddleLeft;
			this.lbCustomCounter.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbCustomCounter.Location = new Point(16, 72);
			this.lbCustomCounter.Name = "lbCustomCounter";
			this.lbCustomCounter.Size = new Size(136, 24);
			this.lbCustomCounter.TabIndex = 19;
			this.lbCustomCounter.Text = "Kundenzähler";
			this.lbCustomCounter.TextAlign = ContentAlignment.MiddleLeft;
			this.lbShowMachineCounter.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowMachineCounter.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowMachineCounter.Location = new Point(176, 32);
			this.lbShowMachineCounter.Name = "lbShowMachineCounter";
			this.lbShowMachineCounter.Size = new Size(112, 24);
			this.lbShowMachineCounter.TabIndex = 0;
			this.lbShowMachineCounter.Text = "0";
			this.lbShowMachineCounter.TextAlign = ContentAlignment.MiddleRight;
			this.lbShowCustomCounter.BorderStyle = BorderStyle.Fixed3D;
			this.lbShowCustomCounter.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbShowCustomCounter.Location = new Point(176, 72);
			this.lbShowCustomCounter.Name = "lbShowCustomCounter";
			this.lbShowCustomCounter.Size = new Size(112, 24);
			this.lbShowCustomCounter.TabIndex = 1;
			this.lbShowCustomCounter.Text = "0";
			this.lbShowCustomCounter.TextAlign = ContentAlignment.MiddleRight;
			this.gBMachineInfo.Controls.Add(this.lbMachineCounter);
			this.gBMachineInfo.Controls.Add(this.lbCustomCounter);
			this.gBMachineInfo.Controls.Add(this.lbShowMachineCounter);
			this.gBMachineInfo.Controls.Add(this.lbShowCustomCounter);
			this.gBMachineInfo.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBMachineInfo.Location = new Point(24, 32);
			this.gBMachineInfo.Name = "gBMachineInfo";
			this.gBMachineInfo.Size = new Size(312, 120);
			this.gBMachineInfo.TabIndex = 1;
			this.gBMachineInfo.TabStop = false;
			this.gBMachineInfo.Text = "Maschineninformation";
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.gBMachineInfo);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "CycleCounterForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Auswertung/Statistik/Zykluszähler";
			base.Activated += this.CycleCounterForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBMachineInfo.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public bool ShowWindow()
		{
			if (!this.Main.IsOnlineMode)
			{
				this.MenEna();
				base.Show();
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.Main.ActivationBrowserGrantedBy = this;
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadCycleCount"));
			if (!this.Main.VC.ReceiveVarBlock(30))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				this.MenEna();
				base.Show();
				MessageBox.Show("Could not receive CycleCountBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.MenEna();
			this.ShowCounter();
			base.Show();
			Cursor.Current = Cursors.Default;
			this.Main.StatusBarText(string.Empty);
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuAnalysis") + "/" + this.Main.Rm.GetString("MenuStatistics") + "/" + this.Main.Rm.GetString("MCycleCounter");
			this.lbCustomCounter.Text = this.Main.Rm.GetString("CustomCounter");
			this.lbMachineCounter.Text = this.Main.Rm.GetString("MachineCounter");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btDelete.Text = this.Main.Rm.GetString("DeleteCustomCounter");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.gBMachineInfo.Text = string.Empty;
		}

		private void MenEna()
		{
			bool enabled = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_CycleCounterForm)
			{
				enabled = true;
			}
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_CycleCounterForm, false);
			this.btBrowser.Enabled = Settings.Default.IntegratedMachineVisu;
			this.btDelete.Enabled = enabled;
		}

		private void ShowCounter()
		{
			this.lbShowCustomCounter.Text = this.Main.VC.CycleCount.Customer.ToString();
			this.lbShowMachineCounter.Text = this.Main.VC.CycleCount.Machine.ToString();
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_2_3_3_Zykluszaehler";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_2_3_3_Zykluszaehler");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btDelete_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbDeleteCustomCounter"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				if (dialogResult == DialogResult.Yes)
				{
					this.pnMenu.Enabled = false;
					Cursor.Current = Cursors.WaitCursor;
					this.Main.StatusBarText(this.Main.Rm.GetString("DeleteCounter"));
					if (!this.Main.DeleteStatBlock(1))
					{
						Cursor.Current = Cursors.Default;
						this.Main.StatusBarText(string.Empty);
						MessageBox.Show(this.Main.Rm.GetString("MbDeleteCounterFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						this.Main.StatusBarText(this.Main.Rm.GetString("LoadCycleCount"));
						if (!this.Main.VC.ReceiveVarBlock(30))
						{
							Cursor.Current = Cursors.Default;
							this.Main.StatusBarText(string.Empty);
							MessageBox.Show("Could not receive CycleCountBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						else
						{
							this.Main.MakeLogbookEntry(204002u, 5, 0f, 0f, 0u, 0, byte.MaxValue);
							this.Main.WriteLogbookData(false);
							this.ShowCounter();
						}
					}
					this.Main.LoggingFinished(false);
					this.pnMenu.Enabled = true;
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
				}
			}
		}

		private void CycleCounterForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
			this.BrowserShow();
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}
	}
}
