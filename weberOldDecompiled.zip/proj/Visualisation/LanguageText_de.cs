using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Visualisation
{
	[CompilerGenerated]
	[DebuggerNonUserCode]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	internal class LanguageText_de
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(LanguageText_de.resourceMan, null))
				{
					ResourceManager resourceManager = LanguageText_de.resourceMan = new ResourceManager("Visualisation.LanguageText_de", typeof(LanguageText_de).Assembly);
				}
				return LanguageText_de.resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return LanguageText_de.resourceCulture;
			}
			set
			{
				LanguageText_de.resourceCulture = value;
			}
		}

		internal static string Abr_Program => LanguageText_de.ResourceManager.GetString("Abr_Program", LanguageText_de.resourceCulture);

		internal static string AbrAnaDepth => LanguageText_de.ResourceManager.GetString("AbrAnaDepth", LanguageText_de.resourceCulture);

		internal static string AbrAnaSignal => LanguageText_de.ResourceManager.GetString("AbrAnaSignal", LanguageText_de.resourceCulture);

		internal static string AbrAngle => LanguageText_de.ResourceManager.GetString("AbrAngle", LanguageText_de.resourceCulture);

		internal static string AbrDelayTorque => LanguageText_de.ResourceManager.GetString("AbrDelayTorque", LanguageText_de.resourceCulture);

		internal static string AbrDepthGrad => LanguageText_de.ResourceManager.GetString("AbrDepthGrad", LanguageText_de.resourceCulture);

		internal static string AbrFilteredTorque => LanguageText_de.ResourceManager.GetString("AbrFilteredTorque", LanguageText_de.resourceCulture);

		internal static string AbrGradient => LanguageText_de.ResourceManager.GetString("AbrGradient", LanguageText_de.resourceCulture);

		internal static string AbrM360Follow => LanguageText_de.ResourceManager.GetString("AbrM360Follow", LanguageText_de.resourceCulture);

		internal static string AbrMaxTorque => LanguageText_de.ResourceManager.GetString("AbrMaxTorque", LanguageText_de.resourceCulture);

		internal static string AbrNumber => LanguageText_de.ResourceManager.GetString("AbrNumber", LanguageText_de.resourceCulture);

		internal static string AbrTime => LanguageText_de.ResourceManager.GetString("AbrTime", LanguageText_de.resourceCulture);

		internal static string AbrTorque => LanguageText_de.ResourceManager.GetString("AbrTorque", LanguageText_de.resourceCulture);

		internal static string AccessCheck => LanguageText_de.ResourceManager.GetString("AccessCheck", LanguageText_de.resourceCulture);

		internal static string AccessRequest => LanguageText_de.ResourceManager.GetString("AccessRequest", LanguageText_de.resourceCulture);

		internal static string Actualize => LanguageText_de.ResourceManager.GetString("Actualize", LanguageText_de.resourceCulture);

		internal static string AddEntry => LanguageText_de.ResourceManager.GetString("AddEntry", LanguageText_de.resourceCulture);

		internal static string AIError => LanguageText_de.ResourceManager.GetString("AIError", LanguageText_de.resourceCulture);

		internal static string All => LanguageText_de.ResourceManager.GetString("All", LanguageText_de.resourceCulture);

		internal static string AllFiles => LanguageText_de.ResourceManager.GetString("AllFiles", LanguageText_de.resourceCulture);

		internal static string AnaDepth => LanguageText_de.ResourceManager.GetString("AnaDepth", LanguageText_de.resourceCulture);

		internal static string Analysis => LanguageText_de.ResourceManager.GetString("Analysis", LanguageText_de.resourceCulture);

		internal static string AnaOutput => LanguageText_de.ResourceManager.GetString("AnaOutput", LanguageText_de.resourceCulture);

		internal static string AnaSignal => LanguageText_de.ResourceManager.GetString("AnaSignal", LanguageText_de.resourceCulture);

		internal static string AnaSigOffset => LanguageText_de.ResourceManager.GetString("AnaSigOffset", LanguageText_de.resourceCulture);

		internal static string AnaSigScale => LanguageText_de.ResourceManager.GetString("AnaSigScale", LanguageText_de.resourceCulture);

		internal static string Angle => LanguageText_de.ResourceManager.GetString("Angle", LanguageText_de.resourceCulture);

		internal static string AngleRedundantTolerance => LanguageText_de.ResourceManager.GetString("AngleRedundantTolerance", LanguageText_de.resourceCulture);

		internal static string AngleSensorInvers => LanguageText_de.ResourceManager.GetString("AngleSensorInvers", LanguageText_de.resourceCulture);

		internal static string AngleSensorScale => LanguageText_de.ResourceManager.GetString("AngleSensorScale", LanguageText_de.resourceCulture);

		internal static string AngleTorqueSensor => LanguageText_de.ResourceManager.GetString("AngleTorqueSensor", LanguageText_de.resourceCulture);

		internal static string Apply => LanguageText_de.ResourceManager.GetString("Apply", LanguageText_de.resourceCulture);

		internal static string ApplyEntry => LanguageText_de.ResourceManager.GetString("ApplyEntry", LanguageText_de.resourceCulture);

		internal static string AutoCurveAbort => LanguageText_de.ResourceManager.GetString("AutoCurveAbort", LanguageText_de.resourceCulture);

		internal static string Automatic => LanguageText_de.ResourceManager.GetString("Automatic", LanguageText_de.resourceCulture);

		internal static string AutoMode => LanguageText_de.ResourceManager.GetString("AutoMode", LanguageText_de.resourceCulture);

		internal static string AvailableValueNumber => LanguageText_de.ResourceManager.GetString("AvailableValueNumber", LanguageText_de.resourceCulture);

		internal static string Back => LanguageText_de.ResourceManager.GetString("Back", LanguageText_de.resourceCulture);

		internal static string Backup => LanguageText_de.ResourceManager.GetString("Backup", LanguageText_de.resourceCulture);

		internal static string Backup205000 => LanguageText_de.ResourceManager.GetString("Backup205000", LanguageText_de.resourceCulture);

		internal static string Backup205001 => LanguageText_de.ResourceManager.GetString("Backup205001", LanguageText_de.resourceCulture);

		internal static string Backup205002 => LanguageText_de.ResourceManager.GetString("Backup205002", LanguageText_de.resourceCulture);

		internal static string Backup205003 => LanguageText_de.ResourceManager.GetString("Backup205003", LanguageText_de.resourceCulture);

		internal static string Battery => LanguageText_de.ResourceManager.GetString("Battery", LanguageText_de.resourceCulture);

		internal static string Baudrate => LanguageText_de.ResourceManager.GetString("Baudrate", LanguageText_de.resourceCulture);

		internal static string bt0 => LanguageText_de.ResourceManager.GetString("bt0", LanguageText_de.resourceCulture);

		internal static string bt1 => LanguageText_de.ResourceManager.GetString("bt1", LanguageText_de.resourceCulture);

		internal static string bt2 => LanguageText_de.ResourceManager.GetString("bt2", LanguageText_de.resourceCulture);

		internal static string bt3 => LanguageText_de.ResourceManager.GetString("bt3", LanguageText_de.resourceCulture);

		internal static string bt4 => LanguageText_de.ResourceManager.GetString("bt4", LanguageText_de.resourceCulture);

		internal static string bt5 => LanguageText_de.ResourceManager.GetString("bt5", LanguageText_de.resourceCulture);

		internal static string bt6 => LanguageText_de.ResourceManager.GetString("bt6", LanguageText_de.resourceCulture);

		internal static string bt7 => LanguageText_de.ResourceManager.GetString("bt7", LanguageText_de.resourceCulture);

		internal static string bt8 => LanguageText_de.ResourceManager.GetString("bt8", LanguageText_de.resourceCulture);

		internal static string bt9 => LanguageText_de.ResourceManager.GetString("bt9", LanguageText_de.resourceCulture);

		internal static string btA => LanguageText_de.ResourceManager.GetString("btA", LanguageText_de.resourceCulture);

		internal static string btApply => LanguageText_de.ResourceManager.GetString("btApply", LanguageText_de.resourceCulture);

		internal static string btB => LanguageText_de.ResourceManager.GetString("btB", LanguageText_de.resourceCulture);

		internal static string btBackspace => LanguageText_de.ResourceManager.GetString("btBackspace", LanguageText_de.resourceCulture);

		internal static string btC => LanguageText_de.ResourceManager.GetString("btC", LanguageText_de.resourceCulture);

		internal static string btCancel => LanguageText_de.ResourceManager.GetString("btCancel", LanguageText_de.resourceCulture);

		internal static string btChangeDefaultDir => LanguageText_de.ResourceManager.GetString("btChangeDefaultDir", LanguageText_de.resourceCulture);

		internal static string btD => LanguageText_de.ResourceManager.GetString("btD", LanguageText_de.resourceCulture);

		internal static string btE => LanguageText_de.ResourceManager.GetString("btE", LanguageText_de.resourceCulture);

		internal static string btErase => LanguageText_de.ResourceManager.GetString("btErase", LanguageText_de.resourceCulture);

		internal static string btF => LanguageText_de.ResourceManager.GetString("btF", LanguageText_de.resourceCulture);

		internal static string btG => LanguageText_de.ResourceManager.GetString("btG", LanguageText_de.resourceCulture);

		internal static string btH => LanguageText_de.ResourceManager.GetString("btH", LanguageText_de.resourceCulture);

		internal static string btI => LanguageText_de.ResourceManager.GetString("btI", LanguageText_de.resourceCulture);

		internal static string btJ => LanguageText_de.ResourceManager.GetString("btJ", LanguageText_de.resourceCulture);

		internal static string btK => LanguageText_de.ResourceManager.GetString("btK", LanguageText_de.resourceCulture);

		internal static string btL => LanguageText_de.ResourceManager.GetString("btL", LanguageText_de.resourceCulture);

		internal static string btLoad => LanguageText_de.ResourceManager.GetString("btLoad", LanguageText_de.resourceCulture);

		internal static string btM => LanguageText_de.ResourceManager.GetString("btM", LanguageText_de.resourceCulture);

		internal static string btMinusDown => LanguageText_de.ResourceManager.GetString("btMinusDown", LanguageText_de.resourceCulture);

		internal static string btMinusUp => LanguageText_de.ResourceManager.GetString("btMinusUp", LanguageText_de.resourceCulture);

		internal static string btN => LanguageText_de.ResourceManager.GetString("btN", LanguageText_de.resourceCulture);

		internal static string btO => LanguageText_de.ResourceManager.GetString("btO", LanguageText_de.resourceCulture);

		internal static string btP => LanguageText_de.ResourceManager.GetString("btP", LanguageText_de.resourceCulture);

		internal static string btQ => LanguageText_de.ResourceManager.GetString("btQ", LanguageText_de.resourceCulture);

		internal static string btR => LanguageText_de.ResourceManager.GetString("btR", LanguageText_de.resourceCulture);

		internal static string btRes1 => LanguageText_de.ResourceManager.GetString("btRes1", LanguageText_de.resourceCulture);

		internal static string btRes2 => LanguageText_de.ResourceManager.GetString("btRes2", LanguageText_de.resourceCulture);

		internal static string btRes3 => LanguageText_de.ResourceManager.GetString("btRes3", LanguageText_de.resourceCulture);

		internal static string btS => LanguageText_de.ResourceManager.GetString("btS", LanguageText_de.resourceCulture);

		internal static string btShift => LanguageText_de.ResourceManager.GetString("btShift", LanguageText_de.resourceCulture);

		internal static string btSpace => LanguageText_de.ResourceManager.GetString("btSpace", LanguageText_de.resourceCulture);

		internal static string btT => LanguageText_de.ResourceManager.GetString("btT", LanguageText_de.resourceCulture);

		internal static string btTeach => LanguageText_de.ResourceManager.GetString("btTeach", LanguageText_de.resourceCulture);

		internal static string btU => LanguageText_de.ResourceManager.GetString("btU", LanguageText_de.resourceCulture);

		internal static string btV => LanguageText_de.ResourceManager.GetString("btV", LanguageText_de.resourceCulture);

		internal static string btW => LanguageText_de.ResourceManager.GetString("btW", LanguageText_de.resourceCulture);

		internal static string btX => LanguageText_de.ResourceManager.GetString("btX", LanguageText_de.resourceCulture);

		internal static string btY => LanguageText_de.ResourceManager.GetString("btY", LanguageText_de.resourceCulture);

		internal static string btZ => LanguageText_de.ResourceManager.GetString("btZ", LanguageText_de.resourceCulture);

		internal static string CalculateCurves => LanguageText_de.ResourceManager.GetString("CalculateCurves", LanguageText_de.resourceCulture);

		internal static string CalDisable => LanguageText_de.ResourceManager.GetString("CalDisable", LanguageText_de.resourceCulture);

		internal static string CalibrationSignal => LanguageText_de.ResourceManager.GetString("CalibrationSignal", LanguageText_de.resourceCulture);

		internal static string Cancel => LanguageText_de.ResourceManager.GetString("Cancel", LanguageText_de.resourceCulture);

		internal static string Changed => LanguageText_de.ResourceManager.GetString("Changed", LanguageText_de.resourceCulture);

		internal static string ChangeEntry => LanguageText_de.ResourceManager.GetString("ChangeEntry", LanguageText_de.resourceCulture);

		internal static string ChangesLog => LanguageText_de.ResourceManager.GetString("ChangesLog", LanguageText_de.resourceCulture);

		internal static string chBEmtyPrograms => LanguageText_de.ResourceManager.GetString("chBEmtyPrograms", LanguageText_de.resourceCulture);

		internal static string chBProgPreview => LanguageText_de.ResourceManager.GetString("chBProgPreview", LanguageText_de.resourceCulture);

		internal static string chBUseDefaultDir => LanguageText_de.ResourceManager.GetString("chBUseDefaultDir", LanguageText_de.resourceCulture);

		internal static string CheckFrictionTestStart => LanguageText_de.ResourceManager.GetString("CheckFrictionTestStart", LanguageText_de.resourceCulture);

		internal static string CheckHandStart => LanguageText_de.ResourceManager.GetString("CheckHandStart", LanguageText_de.resourceCulture);

		internal static string CheckParameter => LanguageText_de.ResourceManager.GetString("CheckParameter", LanguageText_de.resourceCulture);

		internal static string CheckRight => LanguageText_de.ResourceManager.GetString("CheckRight", LanguageText_de.resourceCulture);

		internal static string Close => LanguageText_de.ResourceManager.GetString("Close", LanguageText_de.resourceCulture);

		internal static string ControllerName => LanguageText_de.ResourceManager.GetString("ControllerName", LanguageText_de.resourceCulture);

		internal static string ControllerTime => LanguageText_de.ResourceManager.GetString("ControllerTime", LanguageText_de.resourceCulture);

		internal static string CopyProgram => LanguageText_de.ResourceManager.GetString("CopyProgram", LanguageText_de.resourceCulture);

		internal static string CountPassMax => LanguageText_de.ResourceManager.GetString("CountPassMax", LanguageText_de.resourceCulture);

		internal static string CreatedUsers => LanguageText_de.ResourceManager.GetString("CreatedUsers", LanguageText_de.resourceCulture);

		internal static string CumulStats => LanguageText_de.ResourceManager.GetString("CumulStats", LanguageText_de.resourceCulture);

		internal static string CursorsCannotSwitch => LanguageText_de.ResourceManager.GetString("CursorsCannotSwitch", LanguageText_de.resourceCulture);

		internal static string CurveDisplay => LanguageText_de.ResourceManager.GetString("CurveDisplay", LanguageText_de.resourceCulture);

		internal static string CurveLoad => LanguageText_de.ResourceManager.GetString("CurveLoad", LanguageText_de.resourceCulture);

		internal static string CurvePrint => LanguageText_de.ResourceManager.GetString("CurvePrint", LanguageText_de.resourceCulture);

		internal static string CurveResultKind => LanguageText_de.ResourceManager.GetString("CurveResultKind", LanguageText_de.resourceCulture);

		internal static string CurveResultNumber => LanguageText_de.ResourceManager.GetString("CurveResultNumber", LanguageText_de.resourceCulture);

		internal static string CurveSave => LanguageText_de.ResourceManager.GetString("CurveSave", LanguageText_de.resourceCulture);

		internal static string CurveSelection => LanguageText_de.ResourceManager.GetString("CurveSelection", LanguageText_de.resourceCulture);

		internal static string CurvesZoomedIn => LanguageText_de.ResourceManager.GetString("CurvesZoomedIn", LanguageText_de.resourceCulture);

		internal static string CurvesZoomedOut => LanguageText_de.ResourceManager.GetString("CurvesZoomedOut", LanguageText_de.resourceCulture);

		internal static string CustomCounter => LanguageText_de.ResourceManager.GetString("CustomCounter", LanguageText_de.resourceCulture);

		internal static string Cycle => LanguageText_de.ResourceManager.GetString("Cycle", LanguageText_de.resourceCulture);

		internal static string CycleCounter => LanguageText_de.ResourceManager.GetString("CycleCounter", LanguageText_de.resourceCulture);

		internal static string CycleNumber => LanguageText_de.ResourceManager.GetString("CycleNumber", LanguageText_de.resourceCulture);

		internal static string CycleSave => LanguageText_de.ResourceManager.GetString("CycleSave", LanguageText_de.resourceCulture);

		internal static string Czech => LanguageText_de.ResourceManager.GetString("Czech", LanguageText_de.resourceCulture);

		internal static string DateTime => LanguageText_de.ResourceManager.GetString("DateTime", LanguageText_de.resourceCulture);

		internal static string DeblockController => LanguageText_de.ResourceManager.GetString("DeblockController", LanguageText_de.resourceCulture);

		internal static string DeclForSpSave => LanguageText_de.ResourceManager.GetString("DeclForSpSave", LanguageText_de.resourceCulture);

		internal static string Degree => LanguageText_de.ResourceManager.GetString("Degree", LanguageText_de.resourceCulture);

		internal static string DelayTorque => LanguageText_de.ResourceManager.GetString("DelayTorque", LanguageText_de.resourceCulture);

		internal static string DeleteCounter => LanguageText_de.ResourceManager.GetString("DeleteCounter", LanguageText_de.resourceCulture);

		internal static string DeleteCustomCounter => LanguageText_de.ResourceManager.GetString("DeleteCustomCounter", LanguageText_de.resourceCulture);

		internal static string DeleteEntry => LanguageText_de.ResourceManager.GetString("DeleteEntry", LanguageText_de.resourceCulture);

		internal static string DeleteJob => LanguageText_de.ResourceManager.GetString("DeleteJob", LanguageText_de.resourceCulture);

		internal static string DeleteLastResults => LanguageText_de.ResourceManager.GetString("DeleteLastResults", LanguageText_de.resourceCulture);

		internal static string DeleteProgram => LanguageText_de.ResourceManager.GetString("DeleteProgram", LanguageText_de.resourceCulture);

		internal static string DeleteRecursiveStat => LanguageText_de.ResourceManager.GetString("DeleteRecursiveStat", LanguageText_de.resourceCulture);

		internal static string DeleteStep => LanguageText_de.ResourceManager.GetString("DeleteStep", LanguageText_de.resourceCulture);

		internal static string DeleteValues => LanguageText_de.ResourceManager.GetString("DeleteValues", LanguageText_de.resourceCulture);

		internal static string DepthFilterTime => LanguageText_de.ResourceManager.GetString("DepthFilterTime", LanguageText_de.resourceCulture);

		internal static string DepthGrad => LanguageText_de.ResourceManager.GetString("DepthGrad", LanguageText_de.resourceCulture);

		internal static string DepthGradLength => LanguageText_de.ResourceManager.GetString("DepthGradLength", LanguageText_de.resourceCulture);

		internal static string DepthSensor => LanguageText_de.ResourceManager.GetString("DepthSensor", LanguageText_de.resourceCulture);

		internal static string DepthSensorInvers => LanguageText_de.ResourceManager.GetString("DepthSensorInvers", LanguageText_de.resourceCulture);

		internal static string DGAddress => LanguageText_de.ResourceManager.GetString("DGAddress", LanguageText_de.resourceCulture);

		internal static string DHCP => LanguageText_de.ResourceManager.GetString("DHCP", LanguageText_de.resourceCulture);

		internal static string DigitalSignal => LanguageText_de.ResourceManager.GetString("DigitalSignal", LanguageText_de.resourceCulture);

		internal static string DigitOut => LanguageText_de.ResourceManager.GetString("DigitOut", LanguageText_de.resourceCulture);

		internal static string DigSigAtEnd => LanguageText_de.ResourceManager.GetString("DigSigAtEnd", LanguageText_de.resourceCulture);

		internal static string DigSigRunning => LanguageText_de.ResourceManager.GetString("DigSigRunning", LanguageText_de.resourceCulture);

		internal static string DiscardChanges => LanguageText_de.ResourceManager.GetString("DiscardChanges", LanguageText_de.resourceCulture);

		internal static string Done => LanguageText_de.ResourceManager.GetString("Done", LanguageText_de.resourceCulture);

		internal static string DriveUnit => LanguageText_de.ResourceManager.GetString("DriveUnit", LanguageText_de.resourceCulture);

		internal static string DriveUnitInvers => LanguageText_de.ResourceManager.GetString("DriveUnitInvers", LanguageText_de.resourceCulture);

		internal static string Driving => LanguageText_de.ResourceManager.GetString("Driving", LanguageText_de.resourceCulture);

		internal static string DrivingStep => LanguageText_de.ResourceManager.GetString("DrivingStep", LanguageText_de.resourceCulture);

		internal static string EditCancel => LanguageText_de.ResourceManager.GetString("EditCancel", LanguageText_de.resourceCulture);

		internal static string EditEntry => LanguageText_de.ResourceManager.GetString("EditEntry", LanguageText_de.resourceCulture);

		internal static string EditProgram => LanguageText_de.ResourceManager.GetString("EditProgram", LanguageText_de.resourceCulture);

		internal static string EditStep => LanguageText_de.ResourceManager.GetString("EditStep", LanguageText_de.resourceCulture);

		internal static string EMGMode => LanguageText_de.ResourceManager.GetString("EMGMode", LanguageText_de.resourceCulture);

		internal static string Empty => LanguageText_de.ResourceManager.GetString("Empty", LanguageText_de.resourceCulture);

		internal static string EmptyString => LanguageText_de.ResourceManager.GetString("EmptyString", LanguageText_de.resourceCulture);

		internal static string EncError => LanguageText_de.ResourceManager.GetString("EncError", LanguageText_de.resourceCulture);

		internal static string English => LanguageText_de.ResourceManager.GetString("English", LanguageText_de.resourceCulture);

		internal static string Error1000 => LanguageText_de.ResourceManager.GetString("Error1000", LanguageText_de.resourceCulture);

		internal static string Error1001 => LanguageText_de.ResourceManager.GetString("Error1001", LanguageText_de.resourceCulture);

		internal static string Error1002 => LanguageText_de.ResourceManager.GetString("Error1002", LanguageText_de.resourceCulture);

		internal static string Error1003 => LanguageText_de.ResourceManager.GetString("Error1003", LanguageText_de.resourceCulture);

		internal static string Error1004 => LanguageText_de.ResourceManager.GetString("Error1004", LanguageText_de.resourceCulture);

		internal static string Error1005 => LanguageText_de.ResourceManager.GetString("Error1005", LanguageText_de.resourceCulture);

		internal static string Error1006 => LanguageText_de.ResourceManager.GetString("Error1006", LanguageText_de.resourceCulture);

		internal static string Error1007 => LanguageText_de.ResourceManager.GetString("Error1007", LanguageText_de.resourceCulture);

		internal static string Error1008 => LanguageText_de.ResourceManager.GetString("Error1008", LanguageText_de.resourceCulture);

		internal static string Error1009 => LanguageText_de.ResourceManager.GetString("Error1009", LanguageText_de.resourceCulture);

		internal static string Error1010 => LanguageText_de.ResourceManager.GetString("Error1010", LanguageText_de.resourceCulture);

		internal static string Error1011 => LanguageText_de.ResourceManager.GetString("Error1011", LanguageText_de.resourceCulture);

		internal static string Error1012 => LanguageText_de.ResourceManager.GetString("Error1012", LanguageText_de.resourceCulture);

		internal static string Error1013 => LanguageText_de.ResourceManager.GetString("Error1013", LanguageText_de.resourceCulture);

		internal static string Error1014 => LanguageText_de.ResourceManager.GetString("Error1014", LanguageText_de.resourceCulture);

		internal static string Error1015 => LanguageText_de.ResourceManager.GetString("Error1015", LanguageText_de.resourceCulture);

		internal static string Error1016 => LanguageText_de.ResourceManager.GetString("Error1016", LanguageText_de.resourceCulture);

		internal static string Error1017 => LanguageText_de.ResourceManager.GetString("Error1017", LanguageText_de.resourceCulture);

		internal static string Error1018 => LanguageText_de.ResourceManager.GetString("Error1018", LanguageText_de.resourceCulture);

		internal static string Error1019 => LanguageText_de.ResourceManager.GetString("Error1019", LanguageText_de.resourceCulture);

		internal static string Error1020 => LanguageText_de.ResourceManager.GetString("Error1020", LanguageText_de.resourceCulture);

		internal static string Error1021 => LanguageText_de.ResourceManager.GetString("Error1021", LanguageText_de.resourceCulture);

		internal static string Error1022 => LanguageText_de.ResourceManager.GetString("Error1022", LanguageText_de.resourceCulture);

		internal static string Error1023 => LanguageText_de.ResourceManager.GetString("Error1023", LanguageText_de.resourceCulture);

		internal static string Error1024 => LanguageText_de.ResourceManager.GetString("Error1024", LanguageText_de.resourceCulture);

		internal static string Error1025 => LanguageText_de.ResourceManager.GetString("Error1025", LanguageText_de.resourceCulture);

		internal static string Error1026 => LanguageText_de.ResourceManager.GetString("Error1026", LanguageText_de.resourceCulture);

		internal static string Error1027 => LanguageText_de.ResourceManager.GetString("Error1027", LanguageText_de.resourceCulture);

		internal static string Error1028 => LanguageText_de.ResourceManager.GetString("Error1028", LanguageText_de.resourceCulture);

		internal static string Error1029 => LanguageText_de.ResourceManager.GetString("Error1029", LanguageText_de.resourceCulture);

		internal static string Error1030 => LanguageText_de.ResourceManager.GetString("Error1030", LanguageText_de.resourceCulture);

		internal static string Error1031 => LanguageText_de.ResourceManager.GetString("Error1031", LanguageText_de.resourceCulture);

		internal static string Error1032 => LanguageText_de.ResourceManager.GetString("Error1032", LanguageText_de.resourceCulture);

		internal static string Error1033 => LanguageText_de.ResourceManager.GetString("Error1033", LanguageText_de.resourceCulture);

		internal static string Error1034 => LanguageText_de.ResourceManager.GetString("Error1034", LanguageText_de.resourceCulture);

		internal static string Error1035 => LanguageText_de.ResourceManager.GetString("Error1035", LanguageText_de.resourceCulture);

		internal static string Error1036 => LanguageText_de.ResourceManager.GetString("Error1036", LanguageText_de.resourceCulture);

		internal static string Error1037 => LanguageText_de.ResourceManager.GetString("Error1037", LanguageText_de.resourceCulture);

		internal static string Error1038 => LanguageText_de.ResourceManager.GetString("Error1038", LanguageText_de.resourceCulture);

		internal static string Error1100 => LanguageText_de.ResourceManager.GetString("Error1100", LanguageText_de.resourceCulture);

		internal static string Error1101 => LanguageText_de.ResourceManager.GetString("Error1101", LanguageText_de.resourceCulture);

		internal static string Error1102 => LanguageText_de.ResourceManager.GetString("Error1102", LanguageText_de.resourceCulture);

		internal static string Error1110 => LanguageText_de.ResourceManager.GetString("Error1110", LanguageText_de.resourceCulture);

		internal static string Error1111 => LanguageText_de.ResourceManager.GetString("Error1111", LanguageText_de.resourceCulture);

		internal static string Error1112 => LanguageText_de.ResourceManager.GetString("Error1112", LanguageText_de.resourceCulture);

		internal static string Error1113 => LanguageText_de.ResourceManager.GetString("Error1113", LanguageText_de.resourceCulture);

		internal static string Error1114 => LanguageText_de.ResourceManager.GetString("Error1114", LanguageText_de.resourceCulture);

		internal static string Error1140 => LanguageText_de.ResourceManager.GetString("Error1140", LanguageText_de.resourceCulture);

		internal static string Error1141 => LanguageText_de.ResourceManager.GetString("Error1141", LanguageText_de.resourceCulture);

		internal static string Error1150 => LanguageText_de.ResourceManager.GetString("Error1150", LanguageText_de.resourceCulture);

		internal static string Error1151 => LanguageText_de.ResourceManager.GetString("Error1151", LanguageText_de.resourceCulture);

		internal static string Error1152 => LanguageText_de.ResourceManager.GetString("Error1152", LanguageText_de.resourceCulture);

		internal static string Error1153 => LanguageText_de.ResourceManager.GetString("Error1153", LanguageText_de.resourceCulture);

		internal static string Error1160 => LanguageText_de.ResourceManager.GetString("Error1160", LanguageText_de.resourceCulture);

		internal static string Error1161 => LanguageText_de.ResourceManager.GetString("Error1161", LanguageText_de.resourceCulture);

		internal static string Error1162 => LanguageText_de.ResourceManager.GetString("Error1162", LanguageText_de.resourceCulture);

		internal static string Error1163 => LanguageText_de.ResourceManager.GetString("Error1163", LanguageText_de.resourceCulture);

		internal static string Error1200 => LanguageText_de.ResourceManager.GetString("Error1200", LanguageText_de.resourceCulture);

		internal static string Error1201 => LanguageText_de.ResourceManager.GetString("Error1201", LanguageText_de.resourceCulture);

		internal static string Error1202 => LanguageText_de.ResourceManager.GetString("Error1202", LanguageText_de.resourceCulture);

		internal static string Error1203 => LanguageText_de.ResourceManager.GetString("Error1203", LanguageText_de.resourceCulture);

		internal static string Error1301 => LanguageText_de.ResourceManager.GetString("Error1301", LanguageText_de.resourceCulture);

		internal static string Error1302 => LanguageText_de.ResourceManager.GetString("Error1302", LanguageText_de.resourceCulture);

		internal static string Error1303 => LanguageText_de.ResourceManager.GetString("Error1303", LanguageText_de.resourceCulture);

		internal static string Error1304 => LanguageText_de.ResourceManager.GetString("Error1304", LanguageText_de.resourceCulture);

		internal static string Error1305 => LanguageText_de.ResourceManager.GetString("Error1305", LanguageText_de.resourceCulture);

		internal static string Error1400 => LanguageText_de.ResourceManager.GetString("Error1400", LanguageText_de.resourceCulture);

		internal static string Error1401 => LanguageText_de.ResourceManager.GetString("Error1401", LanguageText_de.resourceCulture);

		internal static string Error1402 => LanguageText_de.ResourceManager.GetString("Error1402", LanguageText_de.resourceCulture);

		internal static string Error1403 => LanguageText_de.ResourceManager.GetString("Error1403", LanguageText_de.resourceCulture);

		internal static string Error1404 => LanguageText_de.ResourceManager.GetString("Error1404", LanguageText_de.resourceCulture);

		internal static string Error1405 => LanguageText_de.ResourceManager.GetString("Error1405", LanguageText_de.resourceCulture);

		internal static string Error1406 => LanguageText_de.ResourceManager.GetString("Error1406", LanguageText_de.resourceCulture);

		internal static string Error1407 => LanguageText_de.ResourceManager.GetString("Error1407", LanguageText_de.resourceCulture);

		internal static string Error1450 => LanguageText_de.ResourceManager.GetString("Error1450", LanguageText_de.resourceCulture);

		internal static string Error1451 => LanguageText_de.ResourceManager.GetString("Error1451", LanguageText_de.resourceCulture);

		internal static string Error1600 => LanguageText_de.ResourceManager.GetString("Error1600", LanguageText_de.resourceCulture);

		internal static string Error1601 => LanguageText_de.ResourceManager.GetString("Error1601", LanguageText_de.resourceCulture);

		internal static string Error1602 => LanguageText_de.ResourceManager.GetString("Error1602", LanguageText_de.resourceCulture);

		internal static string Error2000 => LanguageText_de.ResourceManager.GetString("Error2000", LanguageText_de.resourceCulture);

		internal static string Error2001 => LanguageText_de.ResourceManager.GetString("Error2001", LanguageText_de.resourceCulture);

		internal static string Error2002 => LanguageText_de.ResourceManager.GetString("Error2002", LanguageText_de.resourceCulture);

		internal static string Error2003 => LanguageText_de.ResourceManager.GetString("Error2003", LanguageText_de.resourceCulture);

		internal static string Error2004 => LanguageText_de.ResourceManager.GetString("Error2004", LanguageText_de.resourceCulture);

		internal static string Error2005 => LanguageText_de.ResourceManager.GetString("Error2005", LanguageText_de.resourceCulture);

		internal static string Error2006 => LanguageText_de.ResourceManager.GetString("Error2006", LanguageText_de.resourceCulture);

		internal static string Error2007 => LanguageText_de.ResourceManager.GetString("Error2007", LanguageText_de.resourceCulture);

		internal static string Error2008 => LanguageText_de.ResourceManager.GetString("Error2008", LanguageText_de.resourceCulture);

		internal static string Error2009 => LanguageText_de.ResourceManager.GetString("Error2009", LanguageText_de.resourceCulture);

		internal static string Error2010 => LanguageText_de.ResourceManager.GetString("Error2010", LanguageText_de.resourceCulture);

		internal static string Error2011 => LanguageText_de.ResourceManager.GetString("Error2011", LanguageText_de.resourceCulture);

		internal static string Error2012 => LanguageText_de.ResourceManager.GetString("Error2012", LanguageText_de.resourceCulture);

		internal static string Error2013 => LanguageText_de.ResourceManager.GetString("Error2013", LanguageText_de.resourceCulture);

		internal static string Error2014 => LanguageText_de.ResourceManager.GetString("Error2014", LanguageText_de.resourceCulture);

		internal static string Error2015 => LanguageText_de.ResourceManager.GetString("Error2015", LanguageText_de.resourceCulture);

		internal static string Error2016 => LanguageText_de.ResourceManager.GetString("Error2016", LanguageText_de.resourceCulture);

		internal static string Error2017 => LanguageText_de.ResourceManager.GetString("Error2017", LanguageText_de.resourceCulture);

		internal static string Error2018 => LanguageText_de.ResourceManager.GetString("Error2018", LanguageText_de.resourceCulture);

		internal static string Error2019 => LanguageText_de.ResourceManager.GetString("Error2019", LanguageText_de.resourceCulture);

		internal static string Error2020 => LanguageText_de.ResourceManager.GetString("Error2020", LanguageText_de.resourceCulture);

		internal static string Error2021 => LanguageText_de.ResourceManager.GetString("Error2021", LanguageText_de.resourceCulture);

		internal static string Error2022 => LanguageText_de.ResourceManager.GetString("Error2022", LanguageText_de.resourceCulture);

		internal static string Error2100 => LanguageText_de.ResourceManager.GetString("Error2100", LanguageText_de.resourceCulture);

		internal static string Error5000 => LanguageText_de.ResourceManager.GetString("Error5000", LanguageText_de.resourceCulture);

		internal static string ErrorCode => LanguageText_de.ResourceManager.GetString("ErrorCode", LanguageText_de.resourceCulture);

		internal static string ErrorLog => LanguageText_de.ResourceManager.GetString("ErrorLog", LanguageText_de.resourceCulture);

		internal static string ErrorMode => LanguageText_de.ResourceManager.GetString("ErrorMode", LanguageText_de.resourceCulture);

		internal static string ErrorNumber => LanguageText_de.ResourceManager.GetString("ErrorNumber", LanguageText_de.resourceCulture);

		internal static string ErrorQuitEMG => LanguageText_de.ResourceManager.GetString("ErrorQuitEMG", LanguageText_de.resourceCulture);

		internal static string EuropeanTime => LanguageText_de.ResourceManager.GetString("EuropeanTime", LanguageText_de.resourceCulture);

		internal static string Even => LanguageText_de.ResourceManager.GetString("Even", LanguageText_de.resourceCulture);

		internal static string Exit => LanguageText_de.ResourceManager.GetString("Exit", LanguageText_de.resourceCulture);

		internal static string Export => LanguageText_de.ResourceManager.GetString("Export", LanguageText_de.resourceCulture);

		internal static string ExportLastResults => LanguageText_de.ResourceManager.GetString("ExportLastResults", LanguageText_de.resourceCulture);

		internal static string ExportLogbook => LanguageText_de.ResourceManager.GetString("ExportLogbook", LanguageText_de.resourceCulture);

		internal static string FileOperation => LanguageText_de.ResourceManager.GetString("FileOperation", LanguageText_de.resourceCulture);

		internal static string FileOperationMenu => LanguageText_de.ResourceManager.GetString("FileOperationMenu", LanguageText_de.resourceCulture);

		internal static string FilteredTorque => LanguageText_de.ResourceManager.GetString("FilteredTorque", LanguageText_de.resourceCulture);

		internal static string Finalizing => LanguageText_de.ResourceManager.GetString("Finalizing", LanguageText_de.resourceCulture);

		internal static string FinalizingStep => LanguageText_de.ResourceManager.GetString("FinalizingStep", LanguageText_de.resourceCulture);

		internal static string ForceSignals => LanguageText_de.ResourceManager.GetString("ForceSignals", LanguageText_de.resourceCulture);

		internal static string French => LanguageText_de.ResourceManager.GetString("French", LanguageText_de.resourceCulture);

		internal static string FrictionSpeed => LanguageText_de.ResourceManager.GetString("FrictionSpeed", LanguageText_de.resourceCulture);

		internal static string FrictionTest => LanguageText_de.ResourceManager.GetString("FrictionTest", LanguageText_de.resourceCulture);

		internal static string FrictionTestEMG => LanguageText_de.ResourceManager.GetString("FrictionTestEMG", LanguageText_de.resourceCulture);

		internal static string FrictionTestStartup => LanguageText_de.ResourceManager.GetString("FrictionTestStartup", LanguageText_de.resourceCulture);

		internal static string FrictionTorque => LanguageText_de.ResourceManager.GetString("FrictionTorque", LanguageText_de.resourceCulture);

		internal static string FromAbove => LanguageText_de.ResourceManager.GetString("FromAbove", LanguageText_de.resourceCulture);

		internal static string FromAboveOverload => LanguageText_de.ResourceManager.GetString("FromAboveOverload", LanguageText_de.resourceCulture);

		internal static string gBAnaSignal => LanguageText_de.ResourceManager.GetString("gBAnaSignal", LanguageText_de.resourceCulture);

		internal static string gBDateTime => LanguageText_de.ResourceManager.GetString("gBDateTime", LanguageText_de.resourceCulture);

		internal static string gBError => LanguageText_de.ResourceManager.GetString("gBError", LanguageText_de.resourceCulture);

		internal static string gBIdentity => LanguageText_de.ResourceManager.GetString("gBIdentity", LanguageText_de.resourceCulture);

		internal static string gBIP => LanguageText_de.ResourceManager.GetString("gBIP", LanguageText_de.resourceCulture);

		internal static string gBLoadBackup => LanguageText_de.ResourceManager.GetString("gBLoadBackup", LanguageText_de.resourceCulture);

		internal static string gBPressure => LanguageText_de.ResourceManager.GetString("gBPressure", LanguageText_de.resourceCulture);

		internal static string gBRedundantSensor => LanguageText_de.ResourceManager.GetString("gBRedundantSensor", LanguageText_de.resourceCulture);

		internal static string gBResultDisplay => LanguageText_de.ResourceManager.GetString("gBResultDisplay", LanguageText_de.resourceCulture);

		internal static string gBRs232 => LanguageText_de.ResourceManager.GetString("gBRs232", LanguageText_de.resourceCulture);

		internal static string gBSaveBackup => LanguageText_de.ResourceManager.GetString("gBSaveBackup", LanguageText_de.resourceCulture);

		internal static string gBSpindle => LanguageText_de.ResourceManager.GetString("gBSpindle", LanguageText_de.resourceCulture);

		internal static string GearFactor => LanguageText_de.ResourceManager.GetString("GearFactor", LanguageText_de.resourceCulture);

		internal static string German => LanguageText_de.ResourceManager.GetString("German", LanguageText_de.resourceCulture);

		internal static string GetCurve => LanguageText_de.ResourceManager.GetString("GetCurve", LanguageText_de.resourceCulture);

		internal static string GetRpm => LanguageText_de.ResourceManager.GetString("GetRpm", LanguageText_de.resourceCulture);

		internal static string GoWithoutPassCode => LanguageText_de.ResourceManager.GetString("GoWithoutPassCode", LanguageText_de.resourceCulture);

		internal static string GradFilter => LanguageText_de.ResourceManager.GetString("GradFilter", LanguageText_de.resourceCulture);

		internal static string Gradient => LanguageText_de.ResourceManager.GetString("Gradient", LanguageText_de.resourceCulture);

		internal static string GradientLength => LanguageText_de.ResourceManager.GetString("GradientLength", LanguageText_de.resourceCulture);

		internal static string HandMode => LanguageText_de.ResourceManager.GetString("HandMode", LanguageText_de.resourceCulture);

		internal static string HandStart => LanguageText_de.ResourceManager.GetString("HandStart", LanguageText_de.resourceCulture);

		internal static string HandStartIsInitiated => LanguageText_de.ResourceManager.GetString("HandStartIsInitiated", LanguageText_de.resourceCulture);

		internal static string Help => LanguageText_de.ResourceManager.GetString("Help", LanguageText_de.resourceCulture);

		internal static string HexSwitch => LanguageText_de.ResourceManager.GetString("HexSwitch", LanguageText_de.resourceCulture);

		internal static string Hold => LanguageText_de.ResourceManager.GetString("Hold", LanguageText_de.resourceCulture);

		internal static string Holder => LanguageText_de.ResourceManager.GetString("Holder", LanguageText_de.resourceCulture);

		internal static string HolderPressureScale => LanguageText_de.ResourceManager.GetString("HolderPressureScale", LanguageText_de.resourceCulture);

		internal static string IdentServer => LanguageText_de.ResourceManager.GetString("IdentServer", LanguageText_de.resourceCulture);

		internal static string Increment => LanguageText_de.ResourceManager.GetString("Increment", LanguageText_de.resourceCulture);

		internal static string Inputs => LanguageText_de.ResourceManager.GetString("Inputs", LanguageText_de.resourceCulture);

		internal static string InsertProgram => LanguageText_de.ResourceManager.GetString("InsertProgram", LanguageText_de.resourceCulture);

		internal static string InsertStep => LanguageText_de.ResourceManager.GetString("InsertStep", LanguageText_de.resourceCulture);

		internal static string IntegratedTests => LanguageText_de.ResourceManager.GetString("IntegratedTests", LanguageText_de.resourceCulture);

		internal static string IONumber => LanguageText_de.ResourceManager.GetString("IONumber", LanguageText_de.resourceCulture);

		internal static string IOTest => LanguageText_de.ResourceManager.GetString("IOTest", LanguageText_de.resourceCulture);

		internal static string IPAddress => LanguageText_de.ResourceManager.GetString("IPAddress", LanguageText_de.resourceCulture);

		internal static string Italian => LanguageText_de.ResourceManager.GetString("Italian", LanguageText_de.resourceCulture);

		internal static string JumpAlwaysTo => LanguageText_de.ResourceManager.GetString("JumpAlwaysTo", LanguageText_de.resourceCulture);

		internal static string JumpNokTo => LanguageText_de.ResourceManager.GetString("JumpNokTo", LanguageText_de.resourceCulture);

		internal static string JumpOkTo => LanguageText_de.ResourceManager.GetString("JumpOkTo", LanguageText_de.resourceCulture);

		internal static string JumpTo => LanguageText_de.ResourceManager.GetString("JumpTo", LanguageText_de.resourceCulture);

		internal static string KeyPad => LanguageText_de.ResourceManager.GetString("KeyPad", LanguageText_de.resourceCulture);

		internal static string Kind => LanguageText_de.ResourceManager.GetString("Kind", LanguageText_de.resourceCulture);

		internal static string Language => LanguageText_de.ResourceManager.GetString("Language", LanguageText_de.resourceCulture);

		internal static string LastDoneStep => LanguageText_de.ResourceManager.GetString("LastDoneStep", LanguageText_de.resourceCulture);

		internal static string LastNIO => LanguageText_de.ResourceManager.GetString("LastNIO", LanguageText_de.resourceCulture);

		internal static string LastResults => LanguageText_de.ResourceManager.GetString("LastResults", LanguageText_de.resourceCulture);

		internal static string LeftAngle => LanguageText_de.ResourceManager.GetString("LeftAngle", LanguageText_de.resourceCulture);

		internal static string LevelAdministrator => LanguageText_de.ResourceManager.GetString("LevelAdministrator", LanguageText_de.resourceCulture);

		internal static string LevelProgramer => LanguageText_de.ResourceManager.GetString("LevelProgramer", LanguageText_de.resourceCulture);

		internal static string LevelUser => LanguageText_de.ResourceManager.GetString("LevelUser", LanguageText_de.resourceCulture);

		internal static string LivingMonitor => LanguageText_de.ResourceManager.GetString("LivingMonitor", LanguageText_de.resourceCulture);

		internal static string LivingSign => LanguageText_de.ResourceManager.GetString("LivingSign", LanguageText_de.resourceCulture);

		internal static string LoadCurveData => LanguageText_de.ResourceManager.GetString("LoadCurveData", LanguageText_de.resourceCulture);

		internal static string LoadCurveDataFromFile => LanguageText_de.ResourceManager.GetString("LoadCurveDataFromFile", LanguageText_de.resourceCulture);

		internal static string LoadCustBackup => LanguageText_de.ResourceManager.GetString("LoadCustBackup", LanguageText_de.resourceCulture);

		internal static string LoadCustBackupFromCF => LanguageText_de.ResourceManager.GetString("LoadCustBackupFromCF", LanguageText_de.resourceCulture);

		internal static string LoadCustBackupSecQuery => LanguageText_de.ResourceManager.GetString("LoadCustBackupSecQuery", LanguageText_de.resourceCulture);

		internal static string LoadCycleCount => LanguageText_de.ResourceManager.GetString("LoadCycleCount", LanguageText_de.resourceCulture);

		internal static string LoadFromFile => LanguageText_de.ResourceManager.GetString("LoadFromFile", LanguageText_de.resourceCulture);

		internal static string LoadIO => LanguageText_de.ResourceManager.GetString("LoadIO", LanguageText_de.resourceCulture);

		internal static string LoadLastNIOResults => LanguageText_de.ResourceManager.GetString("LoadLastNIOResults", LanguageText_de.resourceCulture);

		internal static string LoadLastResults => LanguageText_de.ResourceManager.GetString("LoadLastResults", LanguageText_de.resourceCulture);

		internal static string LoadLogBookData => LanguageText_de.ResourceManager.GetString("LoadLogBookData", LanguageText_de.resourceCulture);

		internal static string LoadPLCIO => LanguageText_de.ResourceManager.GetString("LoadPLCIO", LanguageText_de.resourceCulture);

		internal static string LoadPProgFromFile => LanguageText_de.ResourceManager.GetString("LoadPProgFromFile", LanguageText_de.resourceCulture);

		internal static string LoadProcessInfo => LanguageText_de.ResourceManager.GetString("LoadProcessInfo", LanguageText_de.resourceCulture);

		internal static string LoadProgramData => LanguageText_de.ResourceManager.GetString("LoadProgramData", LanguageText_de.resourceCulture);

		internal static string LoadProgramDataLocally => LanguageText_de.ResourceManager.GetString("LoadProgramDataLocally", LanguageText_de.resourceCulture);

		internal static string LoadRecursiveStat => LanguageText_de.ResourceManager.GetString("LoadRecursiveStat", LanguageText_de.resourceCulture);

		internal static string LoadResults => LanguageText_de.ResourceManager.GetString("LoadResults", LanguageText_de.resourceCulture);

		internal static string LoadSingleProgFromFile => LanguageText_de.ResourceManager.GetString("LoadSingleProgFromFile", LanguageText_de.resourceCulture);

		internal static string LoadSpindleConst => LanguageText_de.ResourceManager.GetString("LoadSpindleConst", LanguageText_de.resourceCulture);

		internal static string LoadSpindleDataLocally => LanguageText_de.ResourceManager.GetString("LoadSpindleDataLocally", LanguageText_de.resourceCulture);

		internal static string LoadSystemConst => LanguageText_de.ResourceManager.GetString("LoadSystemConst", LanguageText_de.resourceCulture);

		internal static string LoadWebBackupSecQuery => LanguageText_de.ResourceManager.GetString("LoadWebBackupSecQuery", LanguageText_de.resourceCulture);

		internal static string LoadWeberBackup => LanguageText_de.ResourceManager.GetString("LoadWeberBackup", LanguageText_de.resourceCulture);

		internal static string LoadWeberBackupFromCF => LanguageText_de.ResourceManager.GetString("LoadWeberBackupFromCF", LanguageText_de.resourceCulture);

		internal static string LocalTime => LanguageText_de.ResourceManager.GetString("LocalTime", LanguageText_de.resourceCulture);

		internal static string LogBook => LanguageText_de.ResourceManager.GetString("LogBook", LanguageText_de.resourceCulture);

		internal static string LogBookMessage100000 => LanguageText_de.ResourceManager.GetString("LogBookMessage100000", LanguageText_de.resourceCulture);

		internal static string LogBookMessage200000 => LanguageText_de.ResourceManager.GetString("LogBookMessage200000", LanguageText_de.resourceCulture);

		internal static string LogBookMessage300000 => LanguageText_de.ResourceManager.GetString("LogBookMessage300000", LanguageText_de.resourceCulture);

		internal static string LogBookMessage300001 => LanguageText_de.ResourceManager.GetString("LogBookMessage300001", LanguageText_de.resourceCulture);

		internal static string LogBookTable => LanguageText_de.ResourceManager.GetString("LogBookTable", LanguageText_de.resourceCulture);

		internal static string Login => LanguageText_de.ResourceManager.GetString("Login", LanguageText_de.resourceCulture);

		internal static string LowerLimit => LanguageText_de.ResourceManager.GetString("LowerLimit", LanguageText_de.resourceCulture);

		internal static string M1FilterTime => LanguageText_de.ResourceManager.GetString("M1FilterTime", LanguageText_de.resourceCulture);

		internal static string M360Follow => LanguageText_de.ResourceManager.GetString("M360Follow", LanguageText_de.resourceCulture);

		internal static string MachineCounter => LanguageText_de.ResourceManager.GetString("MachineCounter", LanguageText_de.resourceCulture);

		internal static string MachineVisu => LanguageText_de.ResourceManager.GetString("MachineVisu", LanguageText_de.resourceCulture);

		internal static string MakeNewEntry => LanguageText_de.ResourceManager.GetString("MakeNewEntry", LanguageText_de.resourceCulture);

		internal static string Max => LanguageText_de.ResourceManager.GetString("Max", LanguageText_de.resourceCulture);

		internal static string MaxFrictionTorque => LanguageText_de.ResourceManager.GetString("MaxFrictionTorque", LanguageText_de.resourceCulture);

		internal static string MaxRpm => LanguageText_de.ResourceManager.GetString("MaxRpm", LanguageText_de.resourceCulture);

		internal static string MaxSaveCurveNum => LanguageText_de.ResourceManager.GetString("MaxSaveCurveNum", LanguageText_de.resourceCulture);

		internal static string MaxScrewTime => LanguageText_de.ResourceManager.GetString("MaxScrewTime", LanguageText_de.resourceCulture);

		internal static string MaxTorque => LanguageText_de.ResourceManager.GetString("MaxTorque", LanguageText_de.resourceCulture);

		internal static string MbAccessByAnother => LanguageText_de.ResourceManager.GetString("MbAccessByAnother", LanguageText_de.resourceCulture);

		internal static string MbAccessNotPossible => LanguageText_de.ResourceManager.GetString("MbAccessNotPossible", LanguageText_de.resourceCulture);

		internal static string MbAccessRequestTwice => LanguageText_de.ResourceManager.GetString("MbAccessRequestTwice", LanguageText_de.resourceCulture);

		internal static string MBackup => LanguageText_de.ResourceManager.GetString("MBackup", LanguageText_de.resourceCulture);

		internal static string MbAddNoFrictionTest => LanguageText_de.ResourceManager.GetString("MbAddNoFrictionTest", LanguageText_de.resourceCulture);

		internal static string MbAddNoManual => LanguageText_de.ResourceManager.GetString("MbAddNoManual", LanguageText_de.resourceCulture);

		internal static string MbAddNoTest => LanguageText_de.ResourceManager.GetString("MbAddNoTest", LanguageText_de.resourceCulture);

		internal static string MbAddParamViewOnly => LanguageText_de.ResourceManager.GetString("MbAddParamViewOnly", LanguageText_de.resourceCulture);

		internal static string MbAutomaticIsActive1 => LanguageText_de.ResourceManager.GetString("MbAutomaticIsActive1", LanguageText_de.resourceCulture);

		internal static string MbAutomaticIsActive2 => LanguageText_de.ResourceManager.GetString("MbAutomaticIsActive2", LanguageText_de.resourceCulture);

		internal static string MbComandTimeOut => LanguageText_de.ResourceManager.GetString("MbComandTimeOut", LanguageText_de.resourceCulture);

		internal static string MbCreateDefaultPasscode => LanguageText_de.ResourceManager.GetString("MbCreateDefaultPasscode", LanguageText_de.resourceCulture);

		internal static string MbCurveLoadFailure => LanguageText_de.ResourceManager.GetString("MbCurveLoadFailure", LanguageText_de.resourceCulture);

		internal static string MbCurveSaveFailure => LanguageText_de.ResourceManager.GetString("MbCurveSaveFailure", LanguageText_de.resourceCulture);

		internal static string MbDeleteCounterFailure => LanguageText_de.ResourceManager.GetString("MbDeleteCounterFailure", LanguageText_de.resourceCulture);

		internal static string MbDeleteCustomCounter => LanguageText_de.ResourceManager.GetString("MbDeleteCustomCounter", LanguageText_de.resourceCulture);

		internal static string MbDeleteLastResFailure => LanguageText_de.ResourceManager.GetString("MbDeleteLastResFailure", LanguageText_de.resourceCulture);

		internal static string MbDeleteLastResults => LanguageText_de.ResourceManager.GetString("MbDeleteLastResults", LanguageText_de.resourceCulture);

		internal static string MbDeleteProg => LanguageText_de.ResourceManager.GetString("MbDeleteProg", LanguageText_de.resourceCulture);

		internal static string MbDeleteRecStatFailure => LanguageText_de.ResourceManager.GetString("MbDeleteRecStatFailure", LanguageText_de.resourceCulture);

		internal static string MbDeleteRecursiveStat => LanguageText_de.ResourceManager.GetString("MbDeleteRecursiveStat", LanguageText_de.resourceCulture);

		internal static string MbDeleteStatAfterProgChange => LanguageText_de.ResourceManager.GetString("MbDeleteStatAfterProgChange", LanguageText_de.resourceCulture);

		internal static string MbDoubleEntryCodeFound => LanguageText_de.ResourceManager.GetString("MbDoubleEntryCodeFound", LanguageText_de.resourceCulture);

		internal static string MbEmptyProgram => LanguageText_de.ResourceManager.GetString("MbEmptyProgram", LanguageText_de.resourceCulture);

		internal static string MbErrorQuitFailure => LanguageText_de.ResourceManager.GetString("MbErrorQuitFailure", LanguageText_de.resourceCulture);

		internal static string MbExit => LanguageText_de.ResourceManager.GetString("MbExit", LanguageText_de.resourceCulture);

		internal static string MbGotNoConnection => LanguageText_de.ResourceManager.GetString("MbGotNoConnection", LanguageText_de.resourceCulture);

		internal static string MbHandstartIsActive => LanguageText_de.ResourceManager.GetString("MbHandstartIsActive", LanguageText_de.resourceCulture);

		internal static string MbHandstartNotTwice => LanguageText_de.ResourceManager.GetString("MbHandstartNotTwice", LanguageText_de.resourceCulture);

		internal static string MbhError => LanguageText_de.ResourceManager.GetString("MbhError", LanguageText_de.resourceCulture);

		internal static string MbhHint => LanguageText_de.ResourceManager.GetString("MbhHint", LanguageText_de.resourceCulture);

		internal static string MbhNoAccess => LanguageText_de.ResourceManager.GetString("MbhNoAccess", LanguageText_de.resourceCulture);

		internal static string MbhSecurityQuery => LanguageText_de.ResourceManager.GetString("MbhSecurityQuery", LanguageText_de.resourceCulture);

		internal static string MbhViewOnlyMode => LanguageText_de.ResourceManager.GetString("MbhViewOnlyMode", LanguageText_de.resourceCulture);

		internal static string MbIPChange => LanguageText_de.ResourceManager.GetString("MbIPChange", LanguageText_de.resourceCulture);

		internal static string MbKeyLockActive => LanguageText_de.ResourceManager.GetString("MbKeyLockActive", LanguageText_de.resourceCulture);

		internal static string MbLoadCustBackupFailure => LanguageText_de.ResourceManager.GetString("MbLoadCustBackupFailure", LanguageText_de.resourceCulture);

		internal static string MbLoadWeberBackupFailure => LanguageText_de.ResourceManager.GetString("MbLoadWeberBackupFailure", LanguageText_de.resourceCulture);

		internal static string MbLocationError => LanguageText_de.ResourceManager.GetString("MbLocationError", LanguageText_de.resourceCulture);

		internal static string MbLogbookWriteFailure => LanguageText_de.ResourceManager.GetString("MbLogbookWriteFailure", LanguageText_de.resourceCulture);

		internal static string MbMaxPasscodeNum1 => LanguageText_de.ResourceManager.GetString("MbMaxPasscodeNum1", LanguageText_de.resourceCulture);

		internal static string MbMaxPasscodeNum2 => LanguageText_de.ResourceManager.GetString("MbMaxPasscodeNum2", LanguageText_de.resourceCulture);

		internal static string MbNoAccess => LanguageText_de.ResourceManager.GetString("MbNoAccess", LanguageText_de.resourceCulture);

		internal static string MbNoAccessCauseAuto => LanguageText_de.ResourceManager.GetString("MbNoAccessCauseAuto", LanguageText_de.resourceCulture);

		internal static string MbNoConnection => LanguageText_de.ResourceManager.GetString("MbNoConnection", LanguageText_de.resourceCulture);

		internal static string MbNoTestCauseAuto => LanguageText_de.ResourceManager.GetString("MbNoTestCauseAuto", LanguageText_de.resourceCulture);

		internal static string MbOfflineMode => LanguageText_de.ResourceManager.GetString("MbOfflineMode", LanguageText_de.resourceCulture);

		internal static string MbOldPProgLoad => LanguageText_de.ResourceManager.GetString("MbOldPProgLoad", LanguageText_de.resourceCulture);

		internal static string MbOldProgLoad => LanguageText_de.ResourceManager.GetString("MbOldProgLoad", LanguageText_de.resourceCulture);

		internal static string MbOverwriteProg => LanguageText_de.ResourceManager.GetString("MbOverwriteProg", LanguageText_de.resourceCulture);

		internal static string MbPasscodeFailure1 => LanguageText_de.ResourceManager.GetString("MbPasscodeFailure1", LanguageText_de.resourceCulture);

		internal static string MbPasscodeFailure2 => LanguageText_de.ResourceManager.GetString("MbPasscodeFailure2", LanguageText_de.resourceCulture);

		internal static string MbPasscodeFailure3 => LanguageText_de.ResourceManager.GetString("MbPasscodeFailure3", LanguageText_de.resourceCulture);

		internal static string MbPasscodeFailure4 => LanguageText_de.ResourceManager.GetString("MbPasscodeFailure4", LanguageText_de.resourceCulture);

		internal static string MbPProgCopyFailure => LanguageText_de.ResourceManager.GetString("MbPProgCopyFailure", LanguageText_de.resourceCulture);

		internal static string MbPProgLoadFromFileFailure => LanguageText_de.ResourceManager.GetString("MbPProgLoadFromFileFailure", LanguageText_de.resourceCulture);

		internal static string MbPProgSaveToFileFailure => LanguageText_de.ResourceManager.GetString("MbPProgSaveToFileFailure", LanguageText_de.resourceCulture);

		internal static string MbProgramCopyFailure => LanguageText_de.ResourceManager.GetString("MbProgramCopyFailure", LanguageText_de.resourceCulture);

		internal static string MbProgramEmptySaveAnyway => LanguageText_de.ResourceManager.GetString("MbProgramEmptySaveAnyway", LanguageText_de.resourceCulture);

		internal static string MbSaveCustBackupFailure => LanguageText_de.ResourceManager.GetString("MbSaveCustBackupFailure", LanguageText_de.resourceCulture);

		internal static string MbSaveDataLocally => LanguageText_de.ResourceManager.GetString("MbSaveDataLocally", LanguageText_de.resourceCulture);

		internal static string MbSavedProgramDataToFile => LanguageText_de.ResourceManager.GetString("MbSavedProgramDataToFile", LanguageText_de.resourceCulture);

		internal static string MbSavedSpindleDataToFile => LanguageText_de.ResourceManager.GetString("MbSavedSpindleDataToFile", LanguageText_de.resourceCulture);

		internal static string MbSaveNotVerifiedData => LanguageText_de.ResourceManager.GetString("MbSaveNotVerifiedData", LanguageText_de.resourceCulture);

		internal static string MbSavePasscodeFailure => LanguageText_de.ResourceManager.GetString("MbSavePasscodeFailure", LanguageText_de.resourceCulture);

		internal static string MbSaveProgFailure => LanguageText_de.ResourceManager.GetString("MbSaveProgFailure", LanguageText_de.resourceCulture);

		internal static string MbSaveProgOnCPUFailure => LanguageText_de.ResourceManager.GetString("MbSaveProgOnCPUFailure", LanguageText_de.resourceCulture);

		internal static string MbSaveSpConstFailure => LanguageText_de.ResourceManager.GetString("MbSaveSpConstFailure", LanguageText_de.resourceCulture);

		internal static string MbSaveSysConstFailure => LanguageText_de.ResourceManager.GetString("MbSaveSysConstFailure", LanguageText_de.resourceCulture);

		internal static string MbSaveWeberBackupFailure => LanguageText_de.ResourceManager.GetString("MbSaveWeberBackupFailure", LanguageText_de.resourceCulture);

		internal static string MbShortNameFailure1 => LanguageText_de.ResourceManager.GetString("MbShortNameFailure1", LanguageText_de.resourceCulture);

		internal static string MbShortNameFailure2 => LanguageText_de.ResourceManager.GetString("MbShortNameFailure2", LanguageText_de.resourceCulture);

		internal static string MbShortNameFailure3 => LanguageText_de.ResourceManager.GetString("MbShortNameFailure3", LanguageText_de.resourceCulture);

		internal static string MbSpindleCopyFailure => LanguageText_de.ResourceManager.GetString("MbSpindleCopyFailure", LanguageText_de.resourceCulture);

		internal static string MbSpindleLoadFromFileFailure => LanguageText_de.ResourceManager.GetString("MbSpindleLoadFromFileFailure", LanguageText_de.resourceCulture);

		internal static string MbSpindleSaveToFileFailure => LanguageText_de.ResourceManager.GetString("MbSpindleSaveToFileFailure", LanguageText_de.resourceCulture);

		internal static string MbStepCopyFailure => LanguageText_de.ResourceManager.GetString("MbStepCopyFailure", LanguageText_de.resourceCulture);

		internal static string MbWrongPassword => LanguageText_de.ResourceManager.GetString("MbWrongPassword", LanguageText_de.resourceCulture);

		internal static string MCheckParameter => LanguageText_de.ResourceManager.GetString("MCheckParameter", LanguageText_de.resourceCulture);

		internal static string MCurveDisplay => LanguageText_de.ResourceManager.GetString("MCurveDisplay", LanguageText_de.resourceCulture);

		internal static string MCurveSelection => LanguageText_de.ResourceManager.GetString("MCurveSelection", LanguageText_de.resourceCulture);

		internal static string MCycleCounter => LanguageText_de.ResourceManager.GetString("MCycleCounter", LanguageText_de.resourceCulture);

		internal static string MDelay => LanguageText_de.ResourceManager.GetString("MDelay", LanguageText_de.resourceCulture);

		internal static string Mean => LanguageText_de.ResourceManager.GetString("Mean", LanguageText_de.resourceCulture);

		internal static string MEditStep => LanguageText_de.ResourceManager.GetString("MEditStep", LanguageText_de.resourceCulture);

		internal static string MenuAnalysis => LanguageText_de.ResourceManager.GetString("MenuAnalysis", LanguageText_de.resourceCulture);

		internal static string MenuParameter => LanguageText_de.ResourceManager.GetString("MenuParameter", LanguageText_de.resourceCulture);

		internal static string MenuStatistics => LanguageText_de.ResourceManager.GetString("MenuStatistics", LanguageText_de.resourceCulture);

		internal static string MenuTest => LanguageText_de.ResourceManager.GetString("MenuTest", LanguageText_de.resourceCulture);

		internal static string Message => LanguageText_de.ResourceManager.GetString("Message", LanguageText_de.resourceCulture);

		internal static string MHandStart => LanguageText_de.ResourceManager.GetString("MHandStart", LanguageText_de.resourceCulture);

		internal static string Milimeter => LanguageText_de.ResourceManager.GetString("Milimeter", LanguageText_de.resourceCulture);

		internal static string Milisecond => LanguageText_de.ResourceManager.GetString("Milisecond", LanguageText_de.resourceCulture);

		internal static string Min => LanguageText_de.ResourceManager.GetString("Min", LanguageText_de.resourceCulture);

		internal static string MiniDisplay => LanguageText_de.ResourceManager.GetString("MiniDisplay", LanguageText_de.resourceCulture);

		internal static string Minimize => LanguageText_de.ResourceManager.GetString("Minimize", LanguageText_de.resourceCulture);

		internal static string MLastNIO => LanguageText_de.ResourceManager.GetString("MLastNIO", LanguageText_de.resourceCulture);

		internal static string MLogBook => LanguageText_de.ResourceManager.GetString("MLogBook", LanguageText_de.resourceCulture);

		internal static string MOptPrgParam => LanguageText_de.ResourceManager.GetString("MOptPrgParam", LanguageText_de.resourceCulture);

		internal static string Motor => LanguageText_de.ResourceManager.GetString("Motor", LanguageText_de.resourceCulture);

		internal static string MPasscodeManager => LanguageText_de.ResourceManager.GetString("MPasscodeManager", LanguageText_de.resourceCulture);

		internal static string MPrintSelection => LanguageText_de.ResourceManager.GetString("MPrintSelection", LanguageText_de.resourceCulture);

		internal static string MProgramOverview => LanguageText_de.ResourceManager.GetString("MProgramOverview", LanguageText_de.resourceCulture);

		internal static string MSpindleConstants => LanguageText_de.ResourceManager.GetString("MSpindleConstants", LanguageText_de.resourceCulture);

		internal static string MStepOverview => LanguageText_de.ResourceManager.GetString("MStepOverview", LanguageText_de.resourceCulture);

		internal static string MStepResults => LanguageText_de.ResourceManager.GetString("MStepResults", LanguageText_de.resourceCulture);

		internal static string MSystemConstants => LanguageText_de.ResourceManager.GetString("MSystemConstants", LanguageText_de.resourceCulture);

		internal static string MVisualisationParam => LanguageText_de.ResourceManager.GetString("MVisualisationParam", LanguageText_de.resourceCulture);

		internal static string Name => LanguageText_de.ResourceManager.GetString("Name", LanguageText_de.resourceCulture);

		internal static string Negative => LanguageText_de.ResourceManager.GetString("Negative", LanguageText_de.resourceCulture);

		internal static string NegOverload => LanguageText_de.ResourceManager.GetString("NegOverload", LanguageText_de.resourceCulture);

		internal static string NewEntry => LanguageText_de.ResourceManager.GetString("NewEntry", LanguageText_de.resourceCulture);

		internal static string NewValue => LanguageText_de.ResourceManager.GetString("NewValue", LanguageText_de.resourceCulture);

		internal static string Next50Curves => LanguageText_de.ResourceManager.GetString("Next50Curves", LanguageText_de.resourceCulture);

		internal static string NIO10 => LanguageText_de.ResourceManager.GetString("NIO10", LanguageText_de.resourceCulture);

		internal static string NIO10001 => LanguageText_de.ResourceManager.GetString("NIO10001", LanguageText_de.resourceCulture);

		internal static string NIO10002 => LanguageText_de.ResourceManager.GetString("NIO10002", LanguageText_de.resourceCulture);

		internal static string NIO10003 => LanguageText_de.ResourceManager.GetString("NIO10003", LanguageText_de.resourceCulture);

		internal static string NIO10004 => LanguageText_de.ResourceManager.GetString("NIO10004", LanguageText_de.resourceCulture);

		internal static string NIO11 => LanguageText_de.ResourceManager.GetString("NIO11", LanguageText_de.resourceCulture);

		internal static string NIO110 => LanguageText_de.ResourceManager.GetString("NIO110", LanguageText_de.resourceCulture);

		internal static string NIO12 => LanguageText_de.ResourceManager.GetString("NIO12", LanguageText_de.resourceCulture);

		internal static string NIO13 => LanguageText_de.ResourceManager.GetString("NIO13", LanguageText_de.resourceCulture);

		internal static string NIO30 => LanguageText_de.ResourceManager.GetString("NIO30", LanguageText_de.resourceCulture);

		internal static string NIO31 => LanguageText_de.ResourceManager.GetString("NIO31", LanguageText_de.resourceCulture);

		internal static string NIO40 => LanguageText_de.ResourceManager.GetString("NIO40", LanguageText_de.resourceCulture);

		internal static string NIO41 => LanguageText_de.ResourceManager.GetString("NIO41", LanguageText_de.resourceCulture);

		internal static string NIO50 => LanguageText_de.ResourceManager.GetString("NIO50", LanguageText_de.resourceCulture);

		internal static string NIO51 => LanguageText_de.ResourceManager.GetString("NIO51", LanguageText_de.resourceCulture);

		internal static string NIO60 => LanguageText_de.ResourceManager.GetString("NIO60", LanguageText_de.resourceCulture);

		internal static string NIO61 => LanguageText_de.ResourceManager.GetString("NIO61", LanguageText_de.resourceCulture);

		internal static string NIO70 => LanguageText_de.ResourceManager.GetString("NIO70", LanguageText_de.resourceCulture);

		internal static string NIO71 => LanguageText_de.ResourceManager.GetString("NIO71", LanguageText_de.resourceCulture);

		internal static string NIO75 => LanguageText_de.ResourceManager.GetString("NIO75", LanguageText_de.resourceCulture);

		internal static string NIO76 => LanguageText_de.ResourceManager.GetString("NIO76", LanguageText_de.resourceCulture);

		internal static string NIO80 => LanguageText_de.ResourceManager.GetString("NIO80", LanguageText_de.resourceCulture);

		internal static string NIO81 => LanguageText_de.ResourceManager.GetString("NIO81", LanguageText_de.resourceCulture);

		internal static string NIO90 => LanguageText_de.ResourceManager.GetString("NIO90", LanguageText_de.resourceCulture);

		internal static string NIO91 => LanguageText_de.ResourceManager.GetString("NIO91", LanguageText_de.resourceCulture);

		internal static string NIO92 => LanguageText_de.ResourceManager.GetString("NIO92", LanguageText_de.resourceCulture);

		internal static string NIO93 => LanguageText_de.ResourceManager.GetString("NIO93", LanguageText_de.resourceCulture);

		internal static string NIO94 => LanguageText_de.ResourceManager.GetString("NIO94", LanguageText_de.resourceCulture);

		internal static string NIO95 => LanguageText_de.ResourceManager.GetString("NIO95", LanguageText_de.resourceCulture);

		internal static string NIO96 => LanguageText_de.ResourceManager.GetString("NIO96", LanguageText_de.resourceCulture);

		internal static string NIO97 => LanguageText_de.ResourceManager.GetString("NIO97", LanguageText_de.resourceCulture);

		internal static string NIO98 => LanguageText_de.ResourceManager.GetString("NIO98", LanguageText_de.resourceCulture);

		internal static string NIO99 => LanguageText_de.ResourceManager.GetString("NIO99", LanguageText_de.resourceCulture);

		internal static string NIONumber => LanguageText_de.ResourceManager.GetString("NIONumber", LanguageText_de.resourceCulture);

		internal static string NIOReason => LanguageText_de.ResourceManager.GetString("NIOReason", LanguageText_de.resourceCulture);

		internal static string No => LanguageText_de.ResourceManager.GetString("No", LanguageText_de.resourceCulture);

		internal static string NoData => LanguageText_de.ResourceManager.GetString("NoData", LanguageText_de.resourceCulture);

		internal static string NoErrorMode => LanguageText_de.ResourceManager.GetString("NoErrorMode", LanguageText_de.resourceCulture);

		internal static string NOK => LanguageText_de.ResourceManager.GetString("NOK", LanguageText_de.resourceCulture);

		internal static string None => LanguageText_de.ResourceManager.GetString("None", LanguageText_de.resourceCulture);

		internal static string NoParity => LanguageText_de.ResourceManager.GetString("NoParity", LanguageText_de.resourceCulture);

		internal static string NoSelection => LanguageText_de.ResourceManager.GetString("NoSelection", LanguageText_de.resourceCulture);

		internal static string NoSignal => LanguageText_de.ResourceManager.GetString("NoSignal", LanguageText_de.resourceCulture);

		internal static string NotValid => LanguageText_de.ResourceManager.GetString("NotValid", LanguageText_de.resourceCulture);

		internal static string Number => LanguageText_de.ResourceManager.GetString("Number", LanguageText_de.resourceCulture);

		internal static string NumberPad => LanguageText_de.ResourceManager.GetString("NumberPad", LanguageText_de.resourceCulture);

		internal static string Odd => LanguageText_de.ResourceManager.GetString("Odd", LanguageText_de.resourceCulture);

		internal static string Off => LanguageText_de.ResourceManager.GetString("Off", LanguageText_de.resourceCulture);

		internal static string OfflineMode => LanguageText_de.ResourceManager.GetString("OfflineMode", LanguageText_de.resourceCulture);

		internal static string OffsetTeachValue => LanguageText_de.ResourceManager.GetString("OffsetTeachValue", LanguageText_de.resourceCulture);

		internal static string OffsetVoltageMax => LanguageText_de.ResourceManager.GetString("OffsetVoltageMax", LanguageText_de.resourceCulture);

		internal static string OffsetVoltageMin => LanguageText_de.ResourceManager.GetString("OffsetVoltageMin", LanguageText_de.resourceCulture);

		internal static string OfStep => LanguageText_de.ResourceManager.GetString("OfStep", LanguageText_de.resourceCulture);

		internal static string OK => LanguageText_de.ResourceManager.GetString("OK", LanguageText_de.resourceCulture);

		internal static string OKNOK => LanguageText_de.ResourceManager.GetString("OKNOK", LanguageText_de.resourceCulture);

		internal static string OldValue => LanguageText_de.ResourceManager.GetString("OldValue", LanguageText_de.resourceCulture);

		internal static string On => LanguageText_de.ResourceManager.GetString("On", LanguageText_de.resourceCulture);

		internal static string OnlineMode => LanguageText_de.ResourceManager.GetString("OnlineMode", LanguageText_de.resourceCulture);

		internal static string OnlyIO => LanguageText_de.ResourceManager.GetString("OnlyIO", LanguageText_de.resourceCulture);

		internal static string OptPrgParam => LanguageText_de.ResourceManager.GetString("OptPrgParam", LanguageText_de.resourceCulture);

		internal static string Organisation => LanguageText_de.ResourceManager.GetString("Organisation", LanguageText_de.resourceCulture);

		internal static string OrganizingStep => LanguageText_de.ResourceManager.GetString("OrganizingStep", LanguageText_de.resourceCulture);

		internal static string OutOfRange => LanguageText_de.ResourceManager.GetString("OutOfRange", LanguageText_de.resourceCulture);

		internal static string Outputs => LanguageText_de.ResourceManager.GetString("Outputs", LanguageText_de.resourceCulture);

		internal static string PaintCurve => LanguageText_de.ResourceManager.GetString("PaintCurve", LanguageText_de.resourceCulture);

		internal static string Parity => LanguageText_de.ResourceManager.GetString("Parity", LanguageText_de.resourceCulture);

		internal static string PasscodeLevel => LanguageText_de.ResourceManager.GetString("PasscodeLevel", LanguageText_de.resourceCulture);

		internal static string PasscodeManager => LanguageText_de.ResourceManager.GetString("PasscodeManager", LanguageText_de.resourceCulture);

		internal static string Password => LanguageText_de.ResourceManager.GetString("Password", LanguageText_de.resourceCulture);

		internal static string PasswordInput => LanguageText_de.ResourceManager.GetString("PasswordInput", LanguageText_de.resourceCulture);

		internal static string Percent => LanguageText_de.ResourceManager.GetString("Percent", LanguageText_de.resourceCulture);

		internal static string PLC_IO => LanguageText_de.ResourceManager.GetString("PLC_IO", LanguageText_de.resourceCulture);

		internal static string PointOfTime => LanguageText_de.ResourceManager.GetString("PointOfTime", LanguageText_de.resourceCulture);

		internal static string Positive => LanguageText_de.ResourceManager.GetString("Positive", LanguageText_de.resourceCulture);

		internal static string PosOverload => LanguageText_de.ResourceManager.GetString("PosOverload", LanguageText_de.resourceCulture);

		internal static string PowerEnabled => LanguageText_de.ResourceManager.GetString("PowerEnabled", LanguageText_de.resourceCulture);

		internal static string Pressure => LanguageText_de.ResourceManager.GetString("Pressure", LanguageText_de.resourceCulture);

		internal static string PressureSpindle => LanguageText_de.ResourceManager.GetString("PressureSpindle", LanguageText_de.resourceCulture);

		internal static string Print => LanguageText_de.ResourceManager.GetString("Print", LanguageText_de.resourceCulture);

		internal static string ProcessInputs => LanguageText_de.ResourceManager.GetString("ProcessInputs", LanguageText_de.resourceCulture);

		internal static string ProcessRunning => LanguageText_de.ResourceManager.GetString("ProcessRunning", LanguageText_de.resourceCulture);

		internal static string Program => LanguageText_de.ResourceManager.GetString("Program", LanguageText_de.resourceCulture);

		internal static string ProgramChange201000 => LanguageText_de.ResourceManager.GetString("ProgramChange201000", LanguageText_de.resourceCulture);

		internal static string ProgramChange201001 => LanguageText_de.ResourceManager.GetString("ProgramChange201001", LanguageText_de.resourceCulture);

		internal static string ProgramChange201002 => LanguageText_de.ResourceManager.GetString("ProgramChange201002", LanguageText_de.resourceCulture);

		internal static string ProgramChange201003 => LanguageText_de.ResourceManager.GetString("ProgramChange201003", LanguageText_de.resourceCulture);

		internal static string ProgramChange201004 => LanguageText_de.ResourceManager.GetString("ProgramChange201004", LanguageText_de.resourceCulture);

		internal static string ProgramChange201005 => LanguageText_de.ResourceManager.GetString("ProgramChange201005", LanguageText_de.resourceCulture);

		internal static string ProgramChange201006 => LanguageText_de.ResourceManager.GetString("ProgramChange201006", LanguageText_de.resourceCulture);

		internal static string ProgramChange201007 => LanguageText_de.ResourceManager.GetString("ProgramChange201007", LanguageText_de.resourceCulture);

		internal static string ProgramChange201008 => LanguageText_de.ResourceManager.GetString("ProgramChange201008", LanguageText_de.resourceCulture);

		internal static string ProgramChange201009 => LanguageText_de.ResourceManager.GetString("ProgramChange201009", LanguageText_de.resourceCulture);

		internal static string ProgramNumber => LanguageText_de.ResourceManager.GetString("ProgramNumber", LanguageText_de.resourceCulture);

		internal static string Programs => LanguageText_de.ResourceManager.GetString("Programs", LanguageText_de.resourceCulture);

		internal static string Quit => LanguageText_de.ResourceManager.GetString("Quit", LanguageText_de.resourceCulture);

		internal static string Ramp => LanguageText_de.ResourceManager.GetString("Ramp", LanguageText_de.resourceCulture);

		internal static string Range => LanguageText_de.ResourceManager.GetString("Range", LanguageText_de.resourceCulture);

		internal static string ReadyToStart => LanguageText_de.ResourceManager.GetString("ReadyToStart", LanguageText_de.resourceCulture);

		internal static string RecentDateTime => LanguageText_de.ResourceManager.GetString("RecentDateTime", LanguageText_de.resourceCulture);

		internal static string Reconnect => LanguageText_de.ResourceManager.GetString("Reconnect", LanguageText_de.resourceCulture);

		internal static string ReconnectToController => LanguageText_de.ResourceManager.GetString("ReconnectToController", LanguageText_de.resourceCulture);

		internal static string RecursiveStatMode => LanguageText_de.ResourceManager.GetString("RecursiveStatMode", LanguageText_de.resourceCulture);

		internal static string RedAngle => LanguageText_de.ResourceManager.GetString("RedAngle", LanguageText_de.resourceCulture);

		internal static string RedTorque => LanguageText_de.ResourceManager.GetString("RedTorque", LanguageText_de.resourceCulture);

		internal static string RedundantSensorActive => LanguageText_de.ResourceManager.GetString("RedundantSensorActive", LanguageText_de.resourceCulture);

		internal static string relatedTo => LanguageText_de.ResourceManager.GetString("relatedTo", LanguageText_de.resourceCulture);

		internal static string RelativeTorque => LanguageText_de.ResourceManager.GetString("RelativeTorque", LanguageText_de.resourceCulture);

		internal static string Release => LanguageText_de.ResourceManager.GetString("Release", LanguageText_de.resourceCulture);

		internal static string ReleaseSpeed => LanguageText_de.ResourceManager.GetString("ReleaseSpeed", LanguageText_de.resourceCulture);

		internal static string RelTorqueStep => LanguageText_de.ResourceManager.GetString("RelTorqueStep", LanguageText_de.resourceCulture);

		internal static string RemainedCurves => LanguageText_de.ResourceManager.GetString("RemainedCurves", LanguageText_de.resourceCulture);

		internal static string Reset => LanguageText_de.ResourceManager.GetString("Reset", LanguageText_de.resourceCulture);

		internal static string ResetADepth => LanguageText_de.ResourceManager.GetString("ResetADepth", LanguageText_de.resourceCulture);

		internal static string ResetAngle => LanguageText_de.ResourceManager.GetString("ResetAngle", LanguageText_de.resourceCulture);

		internal static string Result => LanguageText_de.ResourceManager.GetString("Result", LanguageText_de.resourceCulture);

		internal static string ResultDisplay => LanguageText_de.ResourceManager.GetString("ResultDisplay", LanguageText_de.resourceCulture);

		internal static string Results => LanguageText_de.ResourceManager.GetString("Results", LanguageText_de.resourceCulture);

		internal static string RightAngle => LanguageText_de.ResourceManager.GetString("RightAngle", LanguageText_de.resourceCulture);

		internal static string Robot => LanguageText_de.ResourceManager.GetString("Robot", LanguageText_de.resourceCulture);

		internal static string RoundsPerMinute => LanguageText_de.ResourceManager.GetString("RoundsPerMinute", LanguageText_de.resourceCulture);

		internal static string RpmTest => LanguageText_de.ResourceManager.GetString("RpmTest", LanguageText_de.resourceCulture);

		internal static string RpmUnit => LanguageText_de.ResourceManager.GetString("RpmUnit", LanguageText_de.resourceCulture);

		internal static string RS232PrintMode => LanguageText_de.ResourceManager.GetString("RS232PrintMode", LanguageText_de.resourceCulture);

		internal static string SampleSize => LanguageText_de.ResourceManager.GetString("SampleSize", LanguageText_de.resourceCulture);

		internal static string SampleStatistic => LanguageText_de.ResourceManager.GetString("SampleStatistic", LanguageText_de.resourceCulture);

		internal static string SaveCurveDataToFile => LanguageText_de.ResourceManager.GetString("SaveCurveDataToFile", LanguageText_de.resourceCulture);

		internal static string SaveCustBackup => LanguageText_de.ResourceManager.GetString("SaveCustBackup", LanguageText_de.resourceCulture);

		internal static string SaveCustBackupOnCF => LanguageText_de.ResourceManager.GetString("SaveCustBackupOnCF", LanguageText_de.resourceCulture);

		internal static string SaveCustBackupSecQuery => LanguageText_de.ResourceManager.GetString("SaveCustBackupSecQuery", LanguageText_de.resourceCulture);

		internal static string SavePasscodesOnCPU => LanguageText_de.ResourceManager.GetString("SavePasscodesOnCPU", LanguageText_de.resourceCulture);

		internal static string SavePProgToFile => LanguageText_de.ResourceManager.GetString("SavePProgToFile", LanguageText_de.resourceCulture);

		internal static string SaveProgOnCPU => LanguageText_de.ResourceManager.GetString("SaveProgOnCPU", LanguageText_de.resourceCulture);

		internal static string SaveProgramData => LanguageText_de.ResourceManager.GetString("SaveProgramData", LanguageText_de.resourceCulture);

		internal static string SaveProgramDataLocally => LanguageText_de.ResourceManager.GetString("SaveProgramDataLocally", LanguageText_de.resourceCulture);

		internal static string SaveSingleProgToFile => LanguageText_de.ResourceManager.GetString("SaveSingleProgToFile", LanguageText_de.resourceCulture);

		internal static string SaveSpindleConstOnCPU => LanguageText_de.ResourceManager.GetString("SaveSpindleConstOnCPU", LanguageText_de.resourceCulture);

		internal static string SaveSpindleDataLocally => LanguageText_de.ResourceManager.GetString("SaveSpindleDataLocally", LanguageText_de.resourceCulture);

		internal static string SaveSystemConstOnCPU => LanguageText_de.ResourceManager.GetString("SaveSystemConstOnCPU", LanguageText_de.resourceCulture);

		internal static string SaveToFile => LanguageText_de.ResourceManager.GetString("SaveToFile", LanguageText_de.resourceCulture);

		internal static string SaveVisuParam => LanguageText_de.ResourceManager.GetString("SaveVisuParam", LanguageText_de.resourceCulture);

		internal static string SaveWebBackupSecQuery => LanguageText_de.ResourceManager.GetString("SaveWebBackupSecQuery", LanguageText_de.resourceCulture);

		internal static string SaveWeberBackup => LanguageText_de.ResourceManager.GetString("SaveWeberBackup", LanguageText_de.resourceCulture);

		internal static string SaveWeberBackupOnCF => LanguageText_de.ResourceManager.GetString("SaveWeberBackupOnCF", LanguageText_de.resourceCulture);

		internal static string ScrewID => LanguageText_de.ResourceManager.GetString("ScrewID", LanguageText_de.resourceCulture);

		internal static string ScrewProgramFiles => LanguageText_de.ResourceManager.GetString("ScrewProgramFiles", LanguageText_de.resourceCulture);

		internal static string ScrewPrograms => LanguageText_de.ResourceManager.GetString("ScrewPrograms", LanguageText_de.resourceCulture);

		internal static string ScrewTime => LanguageText_de.ResourceManager.GetString("ScrewTime", LanguageText_de.resourceCulture);

		internal static string Second => LanguageText_de.ResourceManager.GetString("Second", LanguageText_de.resourceCulture);

		internal static string SelectAll => LanguageText_de.ResourceManager.GetString("SelectAll", LanguageText_de.resourceCulture);

		internal static string SelectedKind => LanguageText_de.ResourceManager.GetString("SelectedKind", LanguageText_de.resourceCulture);

		internal static string SelectedXAxis => LanguageText_de.ResourceManager.GetString("SelectedXAxis", LanguageText_de.resourceCulture);

		internal static string SelectedYAxis => LanguageText_de.ResourceManager.GetString("SelectedYAxis", LanguageText_de.resourceCulture);

		internal static string SelectNone => LanguageText_de.ResourceManager.GetString("SelectNone", LanguageText_de.resourceCulture);

		internal static string SelValidNumber => LanguageText_de.ResourceManager.GetString("SelValidNumber", LanguageText_de.resourceCulture);

		internal static string SendIO => LanguageText_de.ResourceManager.GetString("SendIO", LanguageText_de.resourceCulture);

		internal static string SendPasscodes => LanguageText_de.ResourceManager.GetString("SendPasscodes", LanguageText_de.resourceCulture);

		internal static string SendSpindleConstants => LanguageText_de.ResourceManager.GetString("SendSpindleConstants", LanguageText_de.resourceCulture);

		internal static string SendSystemConstants => LanguageText_de.ResourceManager.GetString("SendSystemConstants", LanguageText_de.resourceCulture);

		internal static string SensorTest => LanguageText_de.ResourceManager.GetString("SensorTest", LanguageText_de.resourceCulture);

		internal static string Set => LanguageText_de.ResourceManager.GetString("Set", LanguageText_de.resourceCulture);

		internal static string SetAnaOut => LanguageText_de.ResourceManager.GetString("SetAnaOut", LanguageText_de.resourceCulture);

		internal static string SetDigOut => LanguageText_de.ResourceManager.GetString("SetDigOut", LanguageText_de.resourceCulture);

		internal static string SetOff => LanguageText_de.ResourceManager.GetString("SetOff", LanguageText_de.resourceCulture);

		internal static string SetOn => LanguageText_de.ResourceManager.GetString("SetOn", LanguageText_de.resourceCulture);

		internal static string SetRight => LanguageText_de.ResourceManager.GetString("SetRight", LanguageText_de.resourceCulture);

		internal static string SetRpm => LanguageText_de.ResourceManager.GetString("SetRpm", LanguageText_de.resourceCulture);

		internal static string Settings => LanguageText_de.ResourceManager.GetString("Settings", LanguageText_de.resourceCulture);

		internal static string ShortName => LanguageText_de.ResourceManager.GetString("ShortName", LanguageText_de.resourceCulture);

		internal static string SignalQuit => LanguageText_de.ResourceManager.GetString("SignalQuit", LanguageText_de.resourceCulture);

		internal static string Spain => LanguageText_de.ResourceManager.GetString("Spain", LanguageText_de.resourceCulture);

		internal static string SpChange100010 => LanguageText_de.ResourceManager.GetString("SpChange100010", LanguageText_de.resourceCulture);

		internal static string SpChange203000 => LanguageText_de.ResourceManager.GetString("SpChange203000", LanguageText_de.resourceCulture);

		internal static string SpChange203001 => LanguageText_de.ResourceManager.GetString("SpChange203001", LanguageText_de.resourceCulture);

		internal static string SpChange203002 => LanguageText_de.ResourceManager.GetString("SpChange203002", LanguageText_de.resourceCulture);

		internal static string SpChange203003 => LanguageText_de.ResourceManager.GetString("SpChange203003", LanguageText_de.resourceCulture);

		internal static string SpChange203004 => LanguageText_de.ResourceManager.GetString("SpChange203004", LanguageText_de.resourceCulture);

		internal static string SpChange203005 => LanguageText_de.ResourceManager.GetString("SpChange203005", LanguageText_de.resourceCulture);

		internal static string SpChange203006 => LanguageText_de.ResourceManager.GetString("SpChange203006", LanguageText_de.resourceCulture);

		internal static string SpChange203007 => LanguageText_de.ResourceManager.GetString("SpChange203007", LanguageText_de.resourceCulture);

		internal static string SpChange203008 => LanguageText_de.ResourceManager.GetString("SpChange203008", LanguageText_de.resourceCulture);

		internal static string SpChange203009 => LanguageText_de.ResourceManager.GetString("SpChange203009", LanguageText_de.resourceCulture);

		internal static string SpChange203010 => LanguageText_de.ResourceManager.GetString("SpChange203010", LanguageText_de.resourceCulture);

		internal static string SpChange203011 => LanguageText_de.ResourceManager.GetString("SpChange203011", LanguageText_de.resourceCulture);

		internal static string SpChange203012 => LanguageText_de.ResourceManager.GetString("SpChange203012", LanguageText_de.resourceCulture);

		internal static string SpChange203013 => LanguageText_de.ResourceManager.GetString("SpChange203013", LanguageText_de.resourceCulture);

		internal static string SpChange203014 => LanguageText_de.ResourceManager.GetString("SpChange203014", LanguageText_de.resourceCulture);

		internal static string SpChange203015 => LanguageText_de.ResourceManager.GetString("SpChange203015", LanguageText_de.resourceCulture);

		internal static string SpChange203016 => LanguageText_de.ResourceManager.GetString("SpChange203016", LanguageText_de.resourceCulture);

		internal static string SpChange203017 => LanguageText_de.ResourceManager.GetString("SpChange203017", LanguageText_de.resourceCulture);

		internal static string SpChange203018 => LanguageText_de.ResourceManager.GetString("SpChange203018", LanguageText_de.resourceCulture);

		internal static string SpChange203019 => LanguageText_de.ResourceManager.GetString("SpChange203019", LanguageText_de.resourceCulture);

		internal static string SpChange203020 => LanguageText_de.ResourceManager.GetString("SpChange203020", LanguageText_de.resourceCulture);

		internal static string SpChange203021 => LanguageText_de.ResourceManager.GetString("SpChange203021", LanguageText_de.resourceCulture);

		internal static string SpChange203022 => LanguageText_de.ResourceManager.GetString("SpChange203022", LanguageText_de.resourceCulture);

		internal static string SpChange203023 => LanguageText_de.ResourceManager.GetString("SpChange203023", LanguageText_de.resourceCulture);

		internal static string SpChange203024 => LanguageText_de.ResourceManager.GetString("SpChange203024", LanguageText_de.resourceCulture);

		internal static string SpChange203025 => LanguageText_de.ResourceManager.GetString("SpChange203025", LanguageText_de.resourceCulture);

		internal static string SpChange203026 => LanguageText_de.ResourceManager.GetString("SpChange203026", LanguageText_de.resourceCulture);

		internal static string SpChange203027 => LanguageText_de.ResourceManager.GetString("SpChange203027", LanguageText_de.resourceCulture);

		internal static string SpChange203028 => LanguageText_de.ResourceManager.GetString("SpChange203028", LanguageText_de.resourceCulture);

		internal static string SpChange203029 => LanguageText_de.ResourceManager.GetString("SpChange203029", LanguageText_de.resourceCulture);

		internal static string SpChange203030 => LanguageText_de.ResourceManager.GetString("SpChange203030", LanguageText_de.resourceCulture);

		internal static string SpindleConstants => LanguageText_de.ResourceManager.GetString("SpindleConstants", LanguageText_de.resourceCulture);

		internal static string SpindleConstFiles => LanguageText_de.ResourceManager.GetString("SpindleConstFiles", LanguageText_de.resourceCulture);

		internal static string SpindlePressureScale => LanguageText_de.ResourceManager.GetString("SpindlePressureScale", LanguageText_de.resourceCulture);

		internal static string SpindleTorque => LanguageText_de.ResourceManager.GetString("SpindleTorque", LanguageText_de.resourceCulture);

		internal static string StandardDeviation => LanguageText_de.ResourceManager.GetString("StandardDeviation", LanguageText_de.resourceCulture);

		internal static string StartCycleSave => LanguageText_de.ResourceManager.GetString("StartCycleSave", LanguageText_de.resourceCulture);

		internal static string StartFrictionTest => LanguageText_de.ResourceManager.GetString("StartFrictionTest", LanguageText_de.resourceCulture);

		internal static string StartProgram => LanguageText_de.ResourceManager.GetString("StartProgram", LanguageText_de.resourceCulture);

		internal static string StartSignal => LanguageText_de.ResourceManager.GetString("StartSignal", LanguageText_de.resourceCulture);

		internal static string StartStepResExport => LanguageText_de.ResourceManager.GetString("StartStepResExport", LanguageText_de.resourceCulture);

		internal static string StartTest => LanguageText_de.ResourceManager.GetString("StartTest", LanguageText_de.resourceCulture);

		internal static string StatDelete204000 => LanguageText_de.ResourceManager.GetString("StatDelete204000", LanguageText_de.resourceCulture);

		internal static string StatDelete204001 => LanguageText_de.ResourceManager.GetString("StatDelete204001", LanguageText_de.resourceCulture);

		internal static string StatDelete204002 => LanguageText_de.ResourceManager.GetString("StatDelete204002", LanguageText_de.resourceCulture);

		internal static string StatisticCumul => LanguageText_de.ResourceManager.GetString("StatisticCumul", LanguageText_de.resourceCulture);

		internal static string Statistics => LanguageText_de.ResourceManager.GetString("Statistics", LanguageText_de.resourceCulture);

		internal static string StatisticSample => LanguageText_de.ResourceManager.GetString("StatisticSample", LanguageText_de.resourceCulture);

		internal static string StatisticsLastRes => LanguageText_de.ResourceManager.GetString("StatisticsLastRes", LanguageText_de.resourceCulture);

		internal static string Step => LanguageText_de.ResourceManager.GetString("Step", LanguageText_de.resourceCulture);

		internal static string StepFinish => LanguageText_de.ResourceManager.GetString("StepFinish", LanguageText_de.resourceCulture);

		internal static string StepKind => LanguageText_de.ResourceManager.GetString("StepKind", LanguageText_de.resourceCulture);

		internal static string StepKindChoice => LanguageText_de.ResourceManager.GetString("StepKindChoice", LanguageText_de.resourceCulture);

		internal static string StepResults => LanguageText_de.ResourceManager.GetString("StepResults", LanguageText_de.resourceCulture);

		internal static string Steps => LanguageText_de.ResourceManager.GetString("Steps", LanguageText_de.resourceCulture);

		internal static string StepTmin => LanguageText_de.ResourceManager.GetString("StepTmin", LanguageText_de.resourceCulture);

		internal static string StepTplus => LanguageText_de.ResourceManager.GetString("StepTplus", LanguageText_de.resourceCulture);

		internal static string Stop => LanguageText_de.ResourceManager.GetString("Stop", LanguageText_de.resourceCulture);

		internal static string StopNok => LanguageText_de.ResourceManager.GetString("StopNok", LanguageText_de.resourceCulture);

		internal static string StopOk => LanguageText_de.ResourceManager.GetString("StopOk", LanguageText_de.resourceCulture);

		internal static string StopStepResExport => LanguageText_de.ResourceManager.GetString("StopStepResExport", LanguageText_de.resourceCulture);

		internal static string StorageNumber => LanguageText_de.ResourceManager.GetString("StorageNumber", LanguageText_de.resourceCulture);

		internal static string StorageSignals => LanguageText_de.ResourceManager.GetString("StorageSignals", LanguageText_de.resourceCulture);

		internal static string StoreAndBack => LanguageText_de.ResourceManager.GetString("StoreAndBack", LanguageText_de.resourceCulture);

		internal static string SubnetMask => LanguageText_de.ResourceManager.GetString("SubnetMask", LanguageText_de.resourceCulture);

		internal static string SyncOut => LanguageText_de.ResourceManager.GetString("SyncOut", LanguageText_de.resourceCulture);

		internal static string SyncSignal => LanguageText_de.ResourceManager.GetString("SyncSignal", LanguageText_de.resourceCulture);

		internal static string SysChange202000 => LanguageText_de.ResourceManager.GetString("SysChange202000", LanguageText_de.resourceCulture);

		internal static string SysChange202001 => LanguageText_de.ResourceManager.GetString("SysChange202001", LanguageText_de.resourceCulture);

		internal static string SysChange202002 => LanguageText_de.ResourceManager.GetString("SysChange202002", LanguageText_de.resourceCulture);

		internal static string SysChange202003 => LanguageText_de.ResourceManager.GetString("SysChange202003", LanguageText_de.resourceCulture);

		internal static string SysChange202004 => LanguageText_de.ResourceManager.GetString("SysChange202004", LanguageText_de.resourceCulture);

		internal static string SysChange202005 => LanguageText_de.ResourceManager.GetString("SysChange202005", LanguageText_de.resourceCulture);

		internal static string SysChange202006 => LanguageText_de.ResourceManager.GetString("SysChange202006", LanguageText_de.resourceCulture);

		internal static string SysChange202007 => LanguageText_de.ResourceManager.GetString("SysChange202007", LanguageText_de.resourceCulture);

		internal static string SysChange202008 => LanguageText_de.ResourceManager.GetString("SysChange202008", LanguageText_de.resourceCulture);

		internal static string SysChange202009 => LanguageText_de.ResourceManager.GetString("SysChange202009", LanguageText_de.resourceCulture);

		internal static string SysChange202010 => LanguageText_de.ResourceManager.GetString("SysChange202010", LanguageText_de.resourceCulture);

		internal static string SysChange202011 => LanguageText_de.ResourceManager.GetString("SysChange202011", LanguageText_de.resourceCulture);

		internal static string SysChange202012 => LanguageText_de.ResourceManager.GetString("SysChange202012", LanguageText_de.resourceCulture);

		internal static string SysChange202013 => LanguageText_de.ResourceManager.GetString("SysChange202013", LanguageText_de.resourceCulture);

		internal static string SysChange202014 => LanguageText_de.ResourceManager.GetString("SysChange202014", LanguageText_de.resourceCulture);

		internal static string SysChange202015 => LanguageText_de.ResourceManager.GetString("SysChange202015", LanguageText_de.resourceCulture);

		internal static string SysChange202016 => LanguageText_de.ResourceManager.GetString("SysChange202016", LanguageText_de.resourceCulture);

		internal static string SysChange202017 => LanguageText_de.ResourceManager.GetString("SysChange202017", LanguageText_de.resourceCulture);

		internal static string SysChange202018 => LanguageText_de.ResourceManager.GetString("SysChange202018", LanguageText_de.resourceCulture);

		internal static string SystemConstants => LanguageText_de.ResourceManager.GetString("SystemConstants", LanguageText_de.resourceCulture);

		internal static string SystemID => LanguageText_de.ResourceManager.GetString("SystemID", LanguageText_de.resourceCulture);

		internal static string SystemOK => LanguageText_de.ResourceManager.GetString("SystemOK", LanguageText_de.resourceCulture);

		internal static string Target => LanguageText_de.ResourceManager.GetString("Target", LanguageText_de.resourceCulture);

		internal static string TargetRight => LanguageText_de.ResourceManager.GetString("TargetRight", LanguageText_de.resourceCulture);

		internal static string TeachSignal => LanguageText_de.ResourceManager.GetString("TeachSignal", LanguageText_de.resourceCulture);

		internal static string Test => LanguageText_de.ResourceManager.GetString("Test", LanguageText_de.resourceCulture);

		internal static string TestIO => LanguageText_de.ResourceManager.GetString("TestIO", LanguageText_de.resourceCulture);

		internal static string TestMFS => LanguageText_de.ResourceManager.GetString("TestMFS", LanguageText_de.resourceCulture);

		internal static string TestSPSIO => LanguageText_de.ResourceManager.GetString("TestSPSIO", LanguageText_de.resourceCulture);

		internal static string Time => LanguageText_de.ResourceManager.GetString("Time", LanguageText_de.resourceCulture);

		internal static string TimeDateFormat => LanguageText_de.ResourceManager.GetString("TimeDateFormat", LanguageText_de.resourceCulture);

		internal static string TimeSet => LanguageText_de.ResourceManager.GetString("TimeSet", LanguageText_de.resourceCulture);

		internal static string TimeSynchronize => LanguageText_de.ResourceManager.GetString("TimeSynchronize", LanguageText_de.resourceCulture);

		internal static string TM1 => LanguageText_de.ResourceManager.GetString("TM1", LanguageText_de.resourceCulture);

		internal static string TM2 => LanguageText_de.ResourceManager.GetString("TM2", LanguageText_de.resourceCulture);

		internal static string TN => LanguageText_de.ResourceManager.GetString("TN", LanguageText_de.resourceCulture);

		internal static string ToggleCursor => LanguageText_de.ResourceManager.GetString("ToggleCursor", LanguageText_de.resourceCulture);

		internal static string TopAll => LanguageText_de.ResourceManager.GetString("TopAll", LanguageText_de.resourceCulture);

		internal static string TopTen => LanguageText_de.ResourceManager.GetString("TopTen", LanguageText_de.resourceCulture);

		internal static string Torque => LanguageText_de.ResourceManager.GetString("Torque", LanguageText_de.resourceCulture);

		internal static string Torqueftlb => LanguageText_de.ResourceManager.GetString("Torqueftlb", LanguageText_de.resourceCulture);

		internal static string Torqueinlb => LanguageText_de.ResourceManager.GetString("Torqueinlb", LanguageText_de.resourceCulture);

		internal static string Torqueinoz => LanguageText_de.ResourceManager.GetString("Torqueinoz", LanguageText_de.resourceCulture);

		internal static string Torquekgcm => LanguageText_de.ResourceManager.GetString("Torquekgcm", LanguageText_de.resourceCulture);

		internal static string Torquekgm => LanguageText_de.ResourceManager.GetString("Torquekgm", LanguageText_de.resourceCulture);

		internal static string TorqueNcm => LanguageText_de.ResourceManager.GetString("TorqueNcm", LanguageText_de.resourceCulture);

		internal static string TorqueNm => LanguageText_de.ResourceManager.GetString("TorqueNm", LanguageText_de.resourceCulture);

		internal static string TorqueRedundantTime => LanguageText_de.ResourceManager.GetString("TorqueRedundantTime", LanguageText_de.resourceCulture);

		internal static string TorqueRedundantTolerance => LanguageText_de.ResourceManager.GetString("TorqueRedundantTolerance", LanguageText_de.resourceCulture);

		internal static string TorqueSensorInvers => LanguageText_de.ResourceManager.GetString("TorqueSensorInvers", LanguageText_de.resourceCulture);

		internal static string TorqueSensorScale => LanguageText_de.ResourceManager.GetString("TorqueSensorScale", LanguageText_de.resourceCulture);

		internal static string TorqueSensorTolerance => LanguageText_de.ResourceManager.GetString("TorqueSensorTolerance", LanguageText_de.resourceCulture);

		internal static string TorqueUnitChoose => LanguageText_de.ResourceManager.GetString("TorqueUnitChoose", LanguageText_de.resourceCulture);

		internal static string TreshTorque => LanguageText_de.ResourceManager.GetString("TreshTorque", LanguageText_de.resourceCulture);

		internal static string Type => LanguageText_de.ResourceManager.GetString("Type", LanguageText_de.resourceCulture);

		internal static string Unit => LanguageText_de.ResourceManager.GetString("Unit", LanguageText_de.resourceCulture);

		internal static string UnitBar => LanguageText_de.ResourceManager.GetString("UnitBar", LanguageText_de.resourceCulture);

		internal static string UpperLimit => LanguageText_de.ResourceManager.GetString("UpperLimit", LanguageText_de.resourceCulture);

		internal static string UsedKeyboard => LanguageText_de.ResourceManager.GetString("UsedKeyboard", LanguageText_de.resourceCulture);

		internal static string UsedValueNumber => LanguageText_de.ResourceManager.GetString("UsedValueNumber", LanguageText_de.resourceCulture);

		internal static string UseLanguageSettings => LanguageText_de.ResourceManager.GetString("UseLanguageSettings", LanguageText_de.resourceCulture);

		internal static string User => LanguageText_de.ResourceManager.GetString("User", LanguageText_de.resourceCulture);

		internal static string UserRights => LanguageText_de.ResourceManager.GetString("UserRights", LanguageText_de.resourceCulture);

		internal static string USTime => LanguageText_de.ResourceManager.GetString("USTime", LanguageText_de.resourceCulture);

		internal static string Valid => LanguageText_de.ResourceManager.GetString("Valid", LanguageText_de.resourceCulture);

		internal static string Value => LanguageText_de.ResourceManager.GetString("Value", LanguageText_de.resourceCulture);

		internal static string ValueRange => LanguageText_de.ResourceManager.GetString("ValueRange", LanguageText_de.resourceCulture);

		internal static string ValuesNotApplied => LanguageText_de.ResourceManager.GetString("ValuesNotApplied", LanguageText_de.resourceCulture);

		internal static string VersionController => LanguageText_de.ResourceManager.GetString("VersionController", LanguageText_de.resourceCulture);

		internal static string VersionInfo => LanguageText_de.ResourceManager.GetString("VersionInfo", LanguageText_de.resourceCulture);

		internal static string VersionVisu => LanguageText_de.ResourceManager.GetString("VersionVisu", LanguageText_de.resourceCulture);

		internal static string Visualisation => LanguageText_de.ResourceManager.GetString("Visualisation", LanguageText_de.resourceCulture);

		internal static string VisuParam => LanguageText_de.ResourceManager.GetString("VisuParam", LanguageText_de.resourceCulture);

		internal static string Voltage => LanguageText_de.ResourceManager.GetString("Voltage", LanguageText_de.resourceCulture);

		internal static string WaitForAck => LanguageText_de.ResourceManager.GetString("WaitForAck", LanguageText_de.resourceCulture);

		internal static string Warning => LanguageText_de.ResourceManager.GetString("Warning", LanguageText_de.resourceCulture);

		internal static string WarningMode => LanguageText_de.ResourceManager.GetString("WarningMode", LanguageText_de.resourceCulture);

		internal static string WarningNumber => LanguageText_de.ResourceManager.GetString("WarningNumber", LanguageText_de.resourceCulture);

		internal static string WasReset => LanguageText_de.ResourceManager.GetString("WasReset", LanguageText_de.resourceCulture);

		internal static string WasSet => LanguageText_de.ResourceManager.GetString("WasSet", LanguageText_de.resourceCulture);

		internal static string WeberCurveFormat => LanguageText_de.ResourceManager.GetString("WeberCurveFormat", LanguageText_de.resourceCulture);

		internal static string WN => LanguageText_de.ResourceManager.GetString("WN", LanguageText_de.resourceCulture);

		internal static string WriteLastNIOTable => LanguageText_de.ResourceManager.GetString("WriteLastNIOTable", LanguageText_de.resourceCulture);

		internal static string WriteLastResultsTable => LanguageText_de.ResourceManager.GetString("WriteLastResultsTable", LanguageText_de.resourceCulture);

		internal static string WriteLogbookData => LanguageText_de.ResourceManager.GetString("WriteLogbookData", LanguageText_de.resourceCulture);

		internal static string WriteLogBookTable => LanguageText_de.ResourceManager.GetString("WriteLogBookTable", LanguageText_de.resourceCulture);

		internal static string WriteStepResults => LanguageText_de.ResourceManager.GetString("WriteStepResults", LanguageText_de.resourceCulture);

		internal static string Xmax => LanguageText_de.ResourceManager.GetString("Xmax", LanguageText_de.resourceCulture);

		internal static string Xmin => LanguageText_de.ResourceManager.GetString("Xmin", LanguageText_de.resourceCulture);

		internal static string XmlExport => LanguageText_de.ResourceManager.GetString("XmlExport", LanguageText_de.resourceCulture);

		internal static string Yes => LanguageText_de.ResourceManager.GetString("Yes", LanguageText_de.resourceCulture);

		internal static string ZoomIn => LanguageText_de.ResourceManager.GetString("ZoomIn", LanguageText_de.resourceCulture);

		internal static string ZoomOut => LanguageText_de.ResourceManager.GetString("ZoomOut", LanguageText_de.resourceCulture);

		internal LanguageText_de()
		{
		}
	}
}
