using System;
using System.Windows.Forms;
using System.Xml;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class C_XMLParamOut
	{
		private MainForm Main;

		public C_XMLParamOut(MainForm main)
		{
			this.Main = main;
		}

		public bool XmlSaveParam(string filename, int spNum, bool isResult)
		{
			string empty = string.Empty;
			DateTime now = DateTime.Now;
			WSP1_VarComm.ProgStruct progStruct = isResult ? this.Main.VC.Result.Prog : this.Main.VC.PProg.Num[spNum];
			try
			{
				XmlWriter xmlWriter = XmlWriter.Create(filename);
				xmlWriter.WriteStartDocument();
				xmlWriter.WriteStartElement("ParamData");
				xmlWriter.WriteStartElement("ProgramInfo");
				xmlWriter.WriteStartElement("SaveDate");
				XmlWriter xmlWriter2 = xmlWriter;
				int num = now.Year;
				xmlWriter2.WriteElementString("Year", num.ToString());
				xmlWriter.WriteElementString("Month", now.Month.ToString());
				xmlWriter.WriteElementString("Day", now.Day.ToString());
				xmlWriter.WriteEndElement();
				xmlWriter.WriteStartElement("SaveTime");
				xmlWriter.WriteElementString("Hour", now.Hour.ToString());
				xmlWriter.WriteElementString("Minute", now.Minute.ToString());
				xmlWriter.WriteElementString("Second", now.Second.ToString());
				xmlWriter.WriteEndElement();
				xmlWriter.WriteElementString("ProgramNumber", progStruct.Info.ProgNum.ToString());
				xmlWriter.WriteElementString("ProgramName", this.Main.CommonFunctions.UShortToString(progStruct.Info.Name));
				string value;
				switch (progStruct.Info.ResultParam1)
				{
				case 1:
					value = "Torque";
					break;
				case 2:
					value = "MaximumTorque";
					break;
				case 3:
					value = "FilteredTorque";
					break;
				case 4:
					value = "TorqueGradient";
					break;
				case 5:
					value = "Angle";
					break;
				case 6:
					value = "Time";
					break;
				case 7:
					value = "AnalogDepth";
					break;
				case 9:
					value = "DigitalSignal";
					break;
				case 12:
					value = "DepthGradient";
					break;
				case 10:
					value = "DelayTorque";
					break;
				case 11:
					value = "Torque@-360°";
					break;
				case 8:
					value = "AnalogSignal";
					break;
				default:
					value = "Internal Error";
					break;
				}
				xmlWriter.WriteStartElement("Result1Settings");
				xmlWriter.WriteElementString("ResultKind", value);
				xmlWriter.WriteEndElement();
				switch (progStruct.Info.ResultParam2)
				{
				case 1:
					value = "Torque";
					break;
				case 2:
					value = "MaximumTorque";
					break;
				case 3:
					value = "FilteredTorque";
					break;
				case 4:
					value = "TorqueGradient";
					break;
				case 5:
					value = "Angle";
					break;
				case 6:
					value = "Time";
					break;
				case 7:
					value = "AnalogDepth";
					break;
				case 9:
					value = "DigitalSignal";
					break;
				case 12:
					value = "DepthGradient";
					break;
				case 10:
					value = "DelayTorque";
					break;
				case 11:
					value = "Torque@-360°";
					break;
				case 8:
					value = "AnalogSignal";
					break;
				default:
					value = "Internal Error";
					break;
				}
				xmlWriter.WriteStartElement("Result2Settings");
				xmlWriter.WriteElementString("ResultKind", value);
				xmlWriter.WriteEndElement();
				switch (progStruct.Info.ResultParam3)
				{
				case 1:
					value = "Torque";
					break;
				case 2:
					value = "MaximumTorque";
					break;
				case 3:
					value = "FilteredTorque";
					break;
				case 4:
					value = "TorqueGradient";
					break;
				case 5:
					value = "Angle";
					break;
				case 6:
					value = "Time";
					break;
				case 7:
					value = "AnalogDepth";
					break;
				case 9:
					value = "DigitalSignal";
					break;
				case 12:
					value = "DepthGradient";
					break;
				case 10:
					value = "DelayTorque";
					break;
				case 11:
					value = "Torque@-360°";
					break;
				case 8:
					value = "AnalogSignal";
					break;
				default:
					value = "Internal Error";
					break;
				}
				xmlWriter.WriteStartElement("Result3Settings");
				xmlWriter.WriteElementString("ResultKind", value);
				xmlWriter.WriteEndElement();
				xmlWriter.WriteStartElement("MaxScrewTime");
				xmlWriter.WriteElementString("Value", progStruct.MaxTime.ToString("f1"));
				xmlWriter.WriteElementString("Unit", "s");
				xmlWriter.WriteEndElement();
				xmlWriter.WriteStartElement("OptionalProgramParameters");
				xmlWriter.WriteStartElement("Torque");
				xmlWriter.WriteStartElement("FilterTimeForTorque");
				xmlWriter.WriteElementString("Value", progStruct.M1FilterTime.ToString("f0"));
				xmlWriter.WriteElementString("Unit", "ms");
				xmlWriter.WriteEndElement();
				xmlWriter.WriteStartElement("GradientLength");
				xmlWriter.WriteElementString("Value", progStruct.GradientLength.ToString());
				xmlWriter.WriteElementString("Unit", "Inc");
				xmlWriter.WriteEndElement();
				xmlWriter.WriteElementString("GradientFilterActive", progStruct.GradientFilter.ToString());
				xmlWriter.WriteEndElement();
				xmlWriter.WriteStartElement("AnalogDepth");
				xmlWriter.WriteStartElement("DepthFilterTime");
				xmlWriter.WriteElementString("Value", progStruct.ADepthFilterTime.ToString("f0"));
				xmlWriter.WriteElementString("Unit", "ms");
				xmlWriter.WriteEndElement();
				xmlWriter.WriteStartElement("GradientLength");
				xmlWriter.WriteElementString("Value", progStruct.ADepthGradientLength.ToString());
				xmlWriter.WriteElementString("Unit", "ms");
				xmlWriter.WriteEndElement();
				xmlWriter.WriteEndElement();
				xmlWriter.WriteStartElement("Holder");
				xmlWriter.WriteStartElement("Pressure");
				xmlWriter.WriteElementString("Value", progStruct.PressureHolder.ToString("f" + 2));
				xmlWriter.WriteEndElement();
				xmlWriter.WriteEndElement();
				xmlWriter.WriteStartElement("DefineSignalStateAtProgramEnd");
				xmlWriter.WriteStartElement("DigitalSignal1");
				xmlWriter.WriteElementString("Select", progStruct.EndSetDigOut1.ToString());
				xmlWriter.WriteElementString("Value", progStruct.EndValueDigOut1.ToString());
				xmlWriter.WriteEndElement();
				xmlWriter.WriteStartElement("DigitalSignal2");
				xmlWriter.WriteElementString("Select", progStruct.EndSetDigOut2.ToString());
				xmlWriter.WriteElementString("Value", progStruct.EndValueDigOut2.ToString());
				xmlWriter.WriteEndElement();
				xmlWriter.WriteStartElement("Sync1");
				xmlWriter.WriteElementString("Select", progStruct.EndSetSync1.ToString());
				xmlWriter.WriteElementString("Value", progStruct.EndValueSync1.ToString());
				xmlWriter.WriteEndElement();
				xmlWriter.WriteStartElement("Sync2");
				xmlWriter.WriteElementString("Select", progStruct.EndSetSync2.ToString());
				xmlWriter.WriteElementString("Value", progStruct.EndValueSync2.ToString());
				xmlWriter.WriteEndElement();
				xmlWriter.WriteEndElement();
				xmlWriter.WriteEndElement();
				xmlWriter.WriteEndElement();
				for (int i = 0; i < progStruct.Info.Steps; i++)
				{
					float num2;
					switch (progStruct.Step[i].Type)
					{
					case 2:
						xmlWriter.WriteStartElement("Step" + (i + 1).ToString());
						xmlWriter.WriteElementString("StepKind", "DrivingStep");
						xmlWriter.WriteStartElement("RPM");
						xmlWriter.WriteElementString("Value", progStruct.Step[i].NA.ToString("f0"));
						xmlWriter.WriteElementString("Unit", "rpm");
						xmlWriter.WriteEndElement();
						xmlWriter.WriteStartElement("RampTime");
						xmlWriter.WriteElementString("Value", progStruct.Step[i].TM.ToString("f" + 2.ToString()));
						xmlWriter.WriteElementString("Unit", "s");
						xmlWriter.WriteEndElement();
						xmlWriter.WriteStartElement("PressureCylinder");
						xmlWriter.WriteElementString("Value", progStruct.Step[i].PressureSpindle.ToString("f" + 2.ToString()));
						xmlWriter.WriteElementString("Unit", this.Main.Rm.GetString("KiloNewton"));
						xmlWriter.WriteEndElement();
						switch (progStruct.Step[i].Switch)
						{
						case 1:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "Torque");
							XmlWriter xmlWriter58 = xmlWriter;
							num2 = progStruct.Step[i].MP * this.Main.TorqueConvert;
							xmlWriter58.WriteElementString("Value", num2.ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].Tmax.ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							break;
						}
						case 3:
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "FilteredTorque");
							xmlWriter.WriteElementString("Value", (progStruct.Step[i].MFP * this.Main.TorqueConvert).ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].Tmax.ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							break;
						case 2:
						{
							string value2;
							switch (progStruct.Step[i].MRType)
							{
							case 1:
								value2 = "Torque";
								break;
							case 3:
								value2 = "FilteredTorque";
								break;
							case 2:
								value2 = "MaximumTorque";
								break;
							case 10:
								value2 = "DelayTorque";
								break;
							default:
								value2 = "Internal Error";
								break;
							}
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "RelativeTorque");
							xmlWriter.WriteElementString("Value", (progStruct.Step[i].MRP * this.Main.TorqueConvert).ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("AddedTo");
							xmlWriter.WriteElementString("Kind", value2);
							xmlWriter.WriteElementString("StepValue", (progStruct.Step[i].MRStep + 1).ToString());
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].Tmax.ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MinimumTorque");
							xmlWriter.WriteElementString("Value", (progStruct.Step[i].Mmin * this.Main.TorqueConvert).ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaximumTorque");
							xmlWriter.WriteElementString("Value", (progStruct.Step[i].Mmax * this.Main.TorqueConvert).ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							break;
						}
						case 11:
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "Torque@-360°");
							xmlWriter.WriteElementString("Value", (progStruct.Step[i].MRP * this.Main.TorqueConvert).ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].Tmax.ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MinimumTorque");
							xmlWriter.WriteElementString("Value", (progStruct.Step[i].Mmin * this.Main.TorqueConvert).ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaximumTorque");
							xmlWriter.WriteElementString("Value", (progStruct.Step[i].Mmax * this.Main.TorqueConvert).ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							break;
						case 4:
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "TorqueGradient");
							xmlWriter.WriteElementString("Value", (progStruct.Step[i].MGP * this.Main.TorqueConvert).ToString("f" + 4.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName + "/°");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].Tmax.ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							break;
						case 5:
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "Angle");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].WP.ToString("f" + 1.ToString()));
							xmlWriter.WriteElementString("Unit", "°");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("TreshTorque");
							xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.Snug.ToString());
							xmlWriter.WriteElementString("Value", (progStruct.Step[i].MS * this.Main.TorqueConvert).ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].Tmax.ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							break;
						case 6:
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "Time");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].TP.ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].Tmax.ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							break;
						case 7:
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "AnalogDepth");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].LP.ToString("f" + 1.ToString()));
							xmlWriter.WriteElementString("Unit", "mm");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].Tmax.ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							break;
						case 10:
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "DepthGrad");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].LGP.ToString("f" + 4.ToString()));
							xmlWriter.WriteElementString("Unit", "mm/s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].Tmax.ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							break;
						case 8:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "AnalogSignal");
							xmlWriter.WriteElementString("Value", progStruct.Step[i].AnaP.ToString("f" + 2.ToString()));
							xmlWriter.WriteElementString("Unit", "");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter57 = xmlWriter;
							ref float tmax16 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter57.WriteElementString("Value", tmax16.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							break;
						}
						case 9:
						{
							num = progStruct.Step[i].DigP;
							string value2;
							switch (num)
							{
							case 1:
								value2 = "Depth1(positive)";
								break;
							case -1:
								value2 = "Depth1(negative)";
								break;
							case 2:
								value2 = "Depth2(positive)";
								break;
							case -2:
								value2 = "Depth2(negative)";
								break;
							case 3:
								value2 = "DigitalSignal1(positive)";
								break;
							case -3:
								value2 = "DigitalSignal2(negative)";
								break;
							case 4:
								value2 = "Sync1(positive)";
								break;
							case -4:
								value2 = "Sync1(negative)";
								break;
							case 5:
								value2 = "Sync2(positive)";
								break;
							case -5:
								value2 = "Sync2(negative)";
								break;
							default:
								value2 = "InternalError";
								break;
							}
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "DigitalSignal");
							xmlWriter.WriteElementString("Value", value2);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter56 = xmlWriter;
							ref float tmax15 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter56.WriteElementString("Value", tmax15.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							break;
						}
						case 50:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "TorqueFromAbove");
							XmlWriter xmlWriter53 = xmlWriter;
							num2 = progStruct.Step[i].MP * this.Main.TorqueConvert;
							num = 2;
							xmlWriter53.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter54 = xmlWriter;
							ref float tmax14 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter54.WriteElementString("Value", tmax14.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaximumTorque");
							XmlWriter xmlWriter55 = xmlWriter;
							num2 = progStruct.Step[i].Mmax * this.Main.TorqueConvert;
							num = 2;
							xmlWriter55.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							break;
						}
						case 51:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "FilteredTorqueFromAbove");
							XmlWriter xmlWriter50 = xmlWriter;
							num2 = progStruct.Step[i].MFP * this.Main.TorqueConvert;
							num = 2;
							xmlWriter50.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter51 = xmlWriter;
							ref float tmax13 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter51.WriteElementString("Value", tmax13.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaximumTorque");
							XmlWriter xmlWriter52 = xmlWriter;
							num2 = progStruct.Step[i].Mmax * this.Main.TorqueConvert;
							num = 2;
							xmlWriter52.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							break;
						}
						case 52:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "TorqueGradientFromAbove");
							XmlWriter xmlWriter46 = xmlWriter;
							num2 = progStruct.Step[i].MGP * this.Main.TorqueConvert;
							num = 4;
							xmlWriter46.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName + "/°");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter47 = xmlWriter;
							ref float tmax12 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter47.WriteElementString("Value", tmax12.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MinimumTorque");
							XmlWriter xmlWriter48 = xmlWriter;
							num2 = progStruct.Step[i].Mmin * this.Main.TorqueConvert;
							num = 2;
							xmlWriter48.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaximumTorque");
							XmlWriter xmlWriter49 = xmlWriter;
							num2 = progStruct.Step[i].Mmax * this.Main.TorqueConvert;
							num = 2;
							xmlWriter49.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							break;
						}
						case 53:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "AnalogDepthFromAbove");
							XmlWriter xmlWriter44 = xmlWriter;
							ref float lP2 = ref progStruct.Step[i].LP;
							num = 1;
							xmlWriter44.WriteElementString("Value", lP2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "mm");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter45 = xmlWriter;
							ref float tmax11 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter45.WriteElementString("Value", tmax11.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							break;
						}
						case 55:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "DepthGradientFromAbove");
							XmlWriter xmlWriter42 = xmlWriter;
							ref float lGP = ref progStruct.Step[i].LGP;
							num = 4;
							xmlWriter42.WriteElementString("Value", lGP.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "mm/s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter43 = xmlWriter;
							ref float tmax10 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter43.WriteElementString("Value", tmax10.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							break;
						}
						case 54:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "AnalogSignalFromAbove");
							XmlWriter xmlWriter40 = xmlWriter;
							ref float anaP2 = ref progStruct.Step[i].AnaP;
							num = 2;
							xmlWriter40.WriteElementString("Value", anaP2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter41 = xmlWriter;
							ref float tmax9 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter41.WriteElementString("Value", tmax9.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							break;
						}
						default:
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "InternalError");
							xmlWriter.WriteElementString("Value", "");
							xmlWriter.WriteElementString("Unit", "");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							xmlWriter.WriteElementString("Value", "");
							xmlWriter.WriteElementString("Unit", "");
							xmlWriter.WriteEndElement();
							break;
						}
						xmlWriter.WriteStartElement("Analysis");
						xmlWriter.WriteElementString("Result1", progStruct.Step[i].IsResult1.ToString());
						xmlWriter.WriteElementString("Result2", progStruct.Step[i].IsResult2.ToString());
						xmlWriter.WriteElementString("Result3", progStruct.Step[i].IsResult3.ToString());
						xmlWriter.WriteEndElement();
						xmlWriter.WriteStartElement("TimeForDelayTorque");
						xmlWriter.WriteElementString("Value", progStruct.Step[i].MDelayTime.ToString("f0"));
						xmlWriter.WriteElementString("Unit", "ms");
						xmlWriter.WriteEndElement();
						break;
					case 3:
					{
						XmlWriter xmlWriter7 = xmlWriter;
						num = i + 1;
						xmlWriter7.WriteStartElement("Step" + num.ToString());
						xmlWriter.WriteElementString("StepKind", "FinalizingStep");
						xmlWriter.WriteStartElement("RPM");
						xmlWriter.WriteElementString("Value", progStruct.Step[i].NA.ToString("f0"));
						xmlWriter.WriteElementString("Unit", "rpm");
						xmlWriter.WriteEndElement();
						xmlWriter.WriteStartElement("RampTime");
						XmlWriter xmlWriter8 = xmlWriter;
						ref float tM = ref progStruct.Step[i].TM;
						num = 2;
						xmlWriter8.WriteElementString("Value", tM.ToString("f" + num.ToString()));
						xmlWriter.WriteElementString("Unit", "s");
						xmlWriter.WriteEndElement();
						xmlWriter.WriteStartElement("PressureCylinder");
						XmlWriter xmlWriter9 = xmlWriter;
						ref float pressureSpindle = ref progStruct.Step[i].PressureSpindle;
						num = 2;
						xmlWriter9.WriteElementString("Value", pressureSpindle.ToString("f" + num.ToString()));
						xmlWriter.WriteElementString("Unit", this.Main.Rm.GetString("KiloNewton"));
						xmlWriter.WriteEndElement();
						num = progStruct.Step[i].Switch;
						switch (num)
						{
						case 1:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "Torque");
							XmlWriter xmlWriter32 = xmlWriter;
							num2 = progStruct.Step[i].MP * this.Main.TorqueConvert;
							num = 2;
							xmlWriter32.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter33 = xmlWriter;
							ref float tmax7 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter33.WriteElementString("Value", tmax7.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaximumTorque");
							XmlWriter xmlWriter34 = xmlWriter;
							num2 = progStruct.Step[i].Mmax * this.Main.TorqueConvert;
							num = 2;
							xmlWriter34.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							break;
						}
						case 3:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "FilteredTorque");
							XmlWriter xmlWriter35 = xmlWriter;
							num2 = progStruct.Step[i].MP * this.Main.TorqueConvert;
							num = 2;
							xmlWriter35.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter36 = xmlWriter;
							ref float tmax8 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter36.WriteElementString("Value", tmax8.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaximumFilteredTorque");
							XmlWriter xmlWriter37 = xmlWriter;
							num2 = progStruct.Step[i].MFmax * this.Main.TorqueConvert;
							num = 2;
							xmlWriter37.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							break;
						}
						case 2:
						{
							num = progStruct.Step[i].MRType;
							string value2;
							switch (num)
							{
							case 1:
								value2 = "Torque";
								break;
							case 3:
								value2 = "FilteredTorque";
								break;
							case 2:
								value2 = "MaximumTorque";
								break;
							case 10:
								value2 = "DelayTorque";
								break;
							default:
								value2 = "Internal Error";
								break;
							}
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "RelativeTorque");
							XmlWriter xmlWriter27 = xmlWriter;
							num2 = progStruct.Step[i].MRP * this.Main.TorqueConvert;
							num = 2;
							xmlWriter27.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("AddedTo");
							xmlWriter.WriteElementString("Kind", value2);
							XmlWriter xmlWriter28 = xmlWriter;
							num = progStruct.Step[i].MRStep + 1;
							xmlWriter28.WriteElementString("StepValue", num.ToString());
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter29 = xmlWriter;
							ref float tmax6 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter29.WriteElementString("Value", tmax6.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MinimumTorque");
							XmlWriter xmlWriter30 = xmlWriter;
							num2 = progStruct.Step[i].Mmin * this.Main.TorqueConvert;
							num = 2;
							xmlWriter30.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaximumTorque");
							XmlWriter xmlWriter31 = xmlWriter;
							num2 = progStruct.Step[i].Mmax * this.Main.TorqueConvert;
							num = 2;
							xmlWriter31.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							break;
						}
						case 11:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "Torque@-360°");
							XmlWriter xmlWriter23 = xmlWriter;
							num2 = progStruct.Step[i].MRP * this.Main.TorqueConvert;
							num = 2;
							xmlWriter23.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter24 = xmlWriter;
							ref float tmax5 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter24.WriteElementString("Value", tmax5.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MinimumTorque");
							XmlWriter xmlWriter25 = xmlWriter;
							num2 = progStruct.Step[i].Mmin * this.Main.TorqueConvert;
							num = 2;
							xmlWriter25.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaximumTorque");
							XmlWriter xmlWriter26 = xmlWriter;
							num2 = progStruct.Step[i].Mmax * this.Main.TorqueConvert;
							num = 2;
							xmlWriter26.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							break;
						}
						case 4:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "TorqueGradient");
							XmlWriter xmlWriter20 = xmlWriter;
							num2 = progStruct.Step[i].MGP * this.Main.TorqueConvert;
							num = 4;
							xmlWriter20.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName + "/°");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter21 = xmlWriter;
							ref float tmax4 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter21.WriteElementString("Value", tmax4.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxTorqueGradient");
							XmlWriter xmlWriter22 = xmlWriter;
							num2 = progStruct.Step[i].MGmax * this.Main.TorqueConvert;
							num = 4;
							xmlWriter22.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName + "/°");
							xmlWriter.WriteEndElement();
							break;
						}
						case 5:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "Angle");
							XmlWriter xmlWriter16 = xmlWriter;
							ref float wP = ref progStruct.Step[i].WP;
							num = 1;
							xmlWriter16.WriteElementString("Value", wP.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "°");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("TreshTorque");
							xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.Snug.ToString());
							XmlWriter xmlWriter17 = xmlWriter;
							num2 = progStruct.Step[i].MS * this.Main.TorqueConvert;
							num = 2;
							xmlWriter17.WriteElementString("Value", num2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter18 = xmlWriter;
							ref float tmax3 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter18.WriteElementString("Value", tmax3.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxAngle");
							XmlWriter xmlWriter19 = xmlWriter;
							ref float wmax = ref progStruct.Step[i].Wmax;
							num = 1;
							xmlWriter19.WriteElementString("Value", wmax.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "°");
							xmlWriter.WriteEndElement();
							break;
						}
						case 7:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "AnalogDepth");
							XmlWriter xmlWriter13 = xmlWriter;
							ref float lP = ref progStruct.Step[i].LP;
							num = 1;
							xmlWriter13.WriteElementString("Value", lP.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "mm");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter14 = xmlWriter;
							ref float tmax2 = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter14.WriteElementString("Value", tmax2.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxAnalogDepth");
							XmlWriter xmlWriter15 = xmlWriter;
							ref float lmax = ref progStruct.Step[i].Lmax;
							num = 1;
							xmlWriter15.WriteElementString("Value", lmax.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "mm");
							xmlWriter.WriteEndElement();
							break;
						}
						case 8:
						{
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "AnalogSignal");
							XmlWriter xmlWriter10 = xmlWriter;
							ref float anaP = ref progStruct.Step[i].AnaP;
							num = 2;
							xmlWriter10.WriteElementString("Value", anaP.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							XmlWriter xmlWriter11 = xmlWriter;
							ref float tmax = ref progStruct.Step[i].Tmax;
							num = 2;
							xmlWriter11.WriteElementString("Value", tmax.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "s");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxAnalogSingal");
							XmlWriter xmlWriter12 = xmlWriter;
							ref float anaMax = ref progStruct.Step[i].AnaMax;
							num = 2;
							xmlWriter12.WriteElementString("Value", anaMax.ToString("f" + num.ToString()));
							xmlWriter.WriteElementString("Unit", "");
							xmlWriter.WriteEndElement();
							break;
						}
						default:
							xmlWriter.WriteStartElement("TargetParameter");
							xmlWriter.WriteElementString("Kind", "InternalError");
							xmlWriter.WriteElementString("Value", "");
							xmlWriter.WriteElementString("Unit", "");
							xmlWriter.WriteEndElement();
							xmlWriter.WriteStartElement("MaxStepTime");
							xmlWriter.WriteElementString("Value", "");
							xmlWriter.WriteElementString("Unit", "");
							xmlWriter.WriteEndElement();
							break;
						}
						xmlWriter.WriteStartElement("Analysis");
						xmlWriter.WriteElementString("Result1", progStruct.Step[i].IsResult1.ToString());
						xmlWriter.WriteElementString("Result2", progStruct.Step[i].IsResult2.ToString());
						xmlWriter.WriteElementString("Result3", progStruct.Step[i].IsResult3.ToString());
						xmlWriter.WriteEndElement();
						xmlWriter.WriteStartElement("DwellTime");
						XmlWriter xmlWriter38 = xmlWriter;
						ref float tN = ref progStruct.Step[i].TN;
						num = 2;
						xmlWriter38.WriteElementString("Value", tN.ToString("f" + num.ToString()));
						xmlWriter.WriteElementString("Unit", "s");
						xmlWriter.WriteEndElement();
						xmlWriter.WriteStartElement("Release");
						xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.Release.ToString());
						XmlWriter xmlWriter39 = xmlWriter;
						ref float wN = ref progStruct.Step[i].WN;
						num = 1;
						xmlWriter39.WriteElementString("Value", wN.ToString("f" + num.ToString()));
						xmlWriter.WriteElementString("Unit", "°");
						xmlWriter.WriteEndElement();
						break;
					}
					case 1:
					{
						XmlWriter xmlWriter3 = xmlWriter;
						num = i + 1;
						xmlWriter3.WriteStartElement("Step" + num.ToString());
						xmlWriter.WriteElementString("StepKind", "OrganizingStep");
						num = progStruct.Step[i].Switch;
						switch (num)
						{
						case 1000:
						{
							xmlWriter.WriteElementString("Type", "JumpOKto");
							XmlWriter xmlWriter4 = xmlWriter;
							num = progStruct.Step[i].JumpTo + 1;
							xmlWriter4.WriteElementString("Step", num.ToString());
							xmlWriter.WriteElementString("MaxRepetitionOfStep", progStruct.Step[i].CountPassMax.ToString());
							break;
						}
						case 1001:
						{
							xmlWriter.WriteElementString("Type", "JumpNOKto");
							XmlWriter xmlWriter6 = xmlWriter;
							num = progStruct.Step[i].JumpTo + 1;
							xmlWriter6.WriteElementString("Step", num.ToString());
							xmlWriter.WriteElementString("MaxRepetitionOfStep", progStruct.Step[i].CountPassMax.ToString());
							break;
						}
						case 1002:
						{
							xmlWriter.WriteElementString("Type", "JumpAlwaysto");
							XmlWriter xmlWriter5 = xmlWriter;
							num = progStruct.Step[i].JumpTo + 1;
							xmlWriter5.WriteElementString("Step", num.ToString());
							xmlWriter.WriteElementString("MaxRepetitionOfStep", progStruct.Step[i].CountPassMax.ToString());
							break;
						}
						case 1010:
							xmlWriter.WriteElementString("Type", "Stop");
							break;
						case 1011:
							xmlWriter.WriteElementString("Type", "StopOK");
							break;
						case 1012:
							xmlWriter.WriteElementString("Type", "StopNOK");
							break;
						case 1020:
							xmlWriter.WriteElementString("Type", "ResetAngle");
							xmlWriter.WriteElementString("MaxRepetitionOfStep", progStruct.Step[i].CountPassMax.ToString());
							break;
						case 1030:
						{
							xmlWriter.WriteElementString("Type", "SetDigitalSignal");
							num = progStruct.Step[i].ModDigOut;
							string value2;
							switch (num)
							{
							case 1:
								empty = "DigitalOutput1";
								value2 = "On";
								break;
							case -1:
								empty = "DigitalOutput1";
								value2 = "Off";
								break;
							case 2:
								empty = "DigitalOutput2";
								value2 = "On";
								break;
							case -2:
								empty = "DigitalOutput2";
								value2 = "Off";
								break;
							case 3:
								empty = this.Main.Rm.GetString("JawOpen");
								value2 = "On";
								break;
							case -3:
								empty = this.Main.Rm.GetString("JawOpen");
								value2 = "Off";
								break;
							case 4:
								empty = "SyncOutput2";
								value2 = "On";
								break;
							case -4:
								empty = "SyncOutput2";
								value2 = "Off";
								break;
							default:
								empty = "Internal Error";
								value2 = "";
								break;
							}
							xmlWriter.WriteElementString("DigitalSignal", empty);
							xmlWriter.WriteElementString("SetValue", value2);
							xmlWriter.WriteElementString("MaxRepetitionOfStep", progStruct.Step[i].CountPassMax.ToString());
							break;
						}
						case 1040:
							xmlWriter.WriteElementString("Type", "ResetAnalogDepth");
							xmlWriter.WriteElementString("MaxRepetitionOfStep", progStruct.Step[i].CountPassMax.ToString());
							break;
						default:
							xmlWriter.WriteElementString("Type", "InternalError");
							break;
						}
						break;
					}
					default:
						xmlWriter.WriteElementString("Type", "InternalError");
						break;
					}
					int num3;
					int num4;
					switch (progStruct.Step[i].Type)
					{
					case 2:
						num3 = 0;
						goto IL_2fc3;
					case 3:
						{
							num3 = 1;
							goto IL_2fc3;
						}
						IL_2fc3:
						switch (progStruct.Step[i].Switch)
						{
						case 1:
							num4 = 0;
							goto IL_3079;
						case 50:
							num4 = 1;
							goto IL_3079;
						case 3:
							num4 = 2;
							goto IL_3079;
						case 51:
							num4 = 3;
							goto IL_3079;
						case 2:
							num4 = 4;
							goto IL_3079;
						case 4:
							num4 = 5;
							goto IL_3079;
						case 52:
							num4 = 6;
							goto IL_3079;
						case 5:
							num4 = 7;
							goto IL_3079;
						case 6:
							num4 = 8;
							goto IL_3079;
						case 7:
							num4 = 9;
							goto IL_3079;
						case 53:
							num4 = 10;
							goto IL_3079;
						case 8:
							num4 = 11;
							goto IL_3079;
						case 54:
							num4 = 12;
							goto IL_3079;
						case 9:
							num4 = 13;
							goto IL_3079;
						case 55:
							num4 = 14;
							goto IL_3079;
						case 10:
							num4 = 15;
							goto IL_3079;
						case 11:
							{
								num4 = 16;
								goto IL_3079;
							}
							IL_3079:
							xmlWriter.WriteStartElement("MonitorParameter");
							if (this.Main.VisibleParameters.EnaT[num4, num3])
							{
								xmlWriter.WriteStartElement("MinTimeNotReached");
								xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.Time.ToString());
								XmlWriter xmlWriter59 = xmlWriter;
								ref float tmin = ref progStruct.Step[i].Tmin;
								num = 2;
								xmlWriter59.WriteElementString("MinValue", tmin.ToString("f" + num.ToString()));
								xmlWriter.WriteElementString("Unit", "s");
								xmlWriter.WriteEndElement();
							}
							if (this.Main.VisibleParameters.EnaW[num4, num3])
							{
								xmlWriter.WriteStartElement("Angle");
								xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.Angle.ToString());
								XmlWriter xmlWriter60 = xmlWriter;
								ref float wmin = ref progStruct.Step[i].Wmin;
								num = 1;
								xmlWriter60.WriteElementString("MinValue", wmin.ToString("f" + num.ToString()));
								XmlWriter xmlWriter61 = xmlWriter;
								ref float wmax2 = ref progStruct.Step[i].Wmax;
								num = 1;
								xmlWriter61.WriteElementString("MaxValue", wmax2.ToString("f" + num.ToString()));
								xmlWriter.WriteElementString("Unit", "°");
								xmlWriter.WriteStartElement("TresholdTorque");
								XmlWriter xmlWriter62 = xmlWriter;
								num2 = progStruct.Step[i].MS * this.Main.TorqueConvert;
								num = 2;
								xmlWriter62.WriteElementString("Value", num2.ToString("f" + num.ToString()));
								xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
								xmlWriter.WriteEndElement();
								xmlWriter.WriteEndElement();
							}
							if (this.Main.VisibleParameters.EnaM[num4, num3])
							{
								xmlWriter.WriteStartElement("Torque");
								xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.Torque.ToString());
								XmlWriter xmlWriter63 = xmlWriter;
								num2 = progStruct.Step[i].Mmin * this.Main.TorqueConvert;
								num = 2;
								xmlWriter63.WriteElementString("MinValue", num2.ToString("f" + num.ToString()));
								XmlWriter xmlWriter64 = xmlWriter;
								num2 = progStruct.Step[i].Mmax * this.Main.TorqueConvert;
								num = 2;
								xmlWriter64.WriteElementString("MaxValue", num2.ToString("f" + num.ToString()));
								xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
								xmlWriter.WriteEndElement();
							}
							if (this.Main.VisibleParameters.EnaMF[num4, num3])
							{
								xmlWriter.WriteStartElement("FilteredTorque");
								xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.FTorque.ToString());
								XmlWriter xmlWriter65 = xmlWriter;
								num2 = progStruct.Step[i].MFmin * this.Main.TorqueConvert;
								num = 2;
								xmlWriter65.WriteElementString("MinValue", num2.ToString("f" + num.ToString()));
								XmlWriter xmlWriter66 = xmlWriter;
								num2 = progStruct.Step[i].MFmax * this.Main.TorqueConvert;
								num = 2;
								xmlWriter66.WriteElementString("MaxValue", num2.ToString("f" + num.ToString()));
								xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName);
								xmlWriter.WriteEndElement();
							}
							if (this.Main.VisibleParameters.MGmin[num4, num3])
							{
								xmlWriter.WriteStartElement("TorqueGradientMin");
								xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.GradientMin.ToString());
								XmlWriter xmlWriter67 = xmlWriter;
								num2 = progStruct.Step[i].MFmin * this.Main.TorqueConvert;
								num = 4;
								xmlWriter67.WriteElementString("MinValue", num2.ToString("f" + num.ToString()));
								xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName + "/°");
								if (progStruct.Step[i].Enable.GradientMin == 1)
								{
									xmlWriter.WriteElementString("Checked", "AtTheEnd");
								}
								else
								{
									xmlWriter.WriteElementString("Checked", "Continuously");
								}
								xmlWriter.WriteEndElement();
							}
							if (this.Main.VisibleParameters.MGmax[num4, num3])
							{
								xmlWriter.WriteStartElement("TorqueGradientMax");
								xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.GradientMax.ToString());
								XmlWriter xmlWriter68 = xmlWriter;
								num2 = progStruct.Step[i].MFmax * this.Main.TorqueConvert;
								num = 4;
								xmlWriter68.WriteElementString("MaxValue", num2.ToString("f" + num.ToString()));
								xmlWriter.WriteElementString("Unit", this.Main.TorqueUnitName + "/°");
								if (progStruct.Step[i].Enable.GradientMax == 1)
								{
									xmlWriter.WriteElementString("Checked", "AtTheEnd");
								}
								else
								{
									xmlWriter.WriteElementString("Checked", "Continuously");
								}
								xmlWriter.WriteEndElement();
							}
							if (this.Main.VisibleParameters.EnaL[num4, num3])
							{
								xmlWriter.WriteStartElement("AnalogDepth");
								xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.ADepth.ToString());
								XmlWriter xmlWriter69 = xmlWriter;
								ref float lmin = ref progStruct.Step[i].Lmin;
								num = 1;
								xmlWriter69.WriteElementString("MinValue", lmin.ToString("f" + num.ToString()));
								XmlWriter xmlWriter70 = xmlWriter;
								ref float lmax2 = ref progStruct.Step[i].Lmax;
								num = 1;
								xmlWriter70.WriteElementString("MaxValue", lmax2.ToString("f" + num.ToString()));
								xmlWriter.WriteElementString("Unit", "mm");
								xmlWriter.WriteEndElement();
							}
							if (this.Main.VisibleParameters.LGmin[num4, num3])
							{
								xmlWriter.WriteStartElement("DepthGradientMin");
								xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.ADepthGradMin.ToString());
								XmlWriter xmlWriter71 = xmlWriter;
								ref float lGmin = ref progStruct.Step[i].LGmin;
								num = 4;
								xmlWriter71.WriteElementString("MinValue", lGmin.ToString("f" + num.ToString()));
								xmlWriter.WriteElementString("Unit", "mm/s");
								if (progStruct.Step[i].Enable.ADepthGradMin == 1)
								{
									xmlWriter.WriteElementString("Checked", "AtTheEnd");
								}
								else
								{
									xmlWriter.WriteElementString("Checked", "Continuously");
								}
								xmlWriter.WriteEndElement();
							}
							if (this.Main.VisibleParameters.LGmax[num4, num3])
							{
								xmlWriter.WriteStartElement("DepthGradientMax");
								xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.ADepthGradMax.ToString());
								XmlWriter xmlWriter72 = xmlWriter;
								ref float lGmax = ref progStruct.Step[i].LGmax;
								num = 4;
								xmlWriter72.WriteElementString("MinValue", lGmax.ToString("f" + num.ToString()));
								xmlWriter.WriteElementString("Unit", "mm/s");
								if (progStruct.Step[i].Enable.ADepthGradMax == 1)
								{
									xmlWriter.WriteElementString("Checked", "AtTheEnd");
								}
								else
								{
									xmlWriter.WriteElementString("Checked", "Continuously");
								}
								xmlWriter.WriteEndElement();
							}
							if (this.Main.VisibleParameters.EnaAS[num4, num3])
							{
								xmlWriter.WriteStartElement("AnalogSignal");
								xmlWriter.WriteElementString("Select", progStruct.Step[i].Enable.Ana.ToString());
								XmlWriter xmlWriter73 = xmlWriter;
								ref float anaMin = ref progStruct.Step[i].AnaMin;
								num = 2;
								xmlWriter73.WriteElementString("MinValue", anaMin.ToString("f" + num.ToString()));
								XmlWriter xmlWriter74 = xmlWriter;
								ref float anaMax2 = ref progStruct.Step[i].AnaMax;
								num = 2;
								xmlWriter74.WriteElementString("MaxValue", anaMax2.ToString("f" + num.ToString()));
								xmlWriter.WriteElementString("Unit", "mm");
								xmlWriter.WriteEndElement();
							}
							if (this.Main.VisibleParameters.DSmax[num4, num3])
							{
								xmlWriter.WriteStartElement("DigitalSignalCheckedContinuously");
								if (progStruct.Step[i].DigMax == 0)
								{
									xmlWriter.WriteElementString("Select", "0");
								}
								else
								{
									xmlWriter.WriteElementString("Select", "1");
								}
								switch (progStruct.Step[i].DigMax)
								{
								case 1:
									xmlWriter.WriteElementString("Signal", "Depth1");
									xmlWriter.WriteElementString("State", "Positive");
									break;
								case 2:
									xmlWriter.WriteElementString("Signal", "Depth2");
									xmlWriter.WriteElementString("State", "Positive");
									break;
								case 3:
									xmlWriter.WriteElementString("Signal", "DigitalSignal");
									xmlWriter.WriteElementString("State", "Positive");
									break;
								case 4:
									xmlWriter.WriteElementString("Signal", "Sync1");
									xmlWriter.WriteElementString("State", "Positive");
									break;
								case 5:
									xmlWriter.WriteElementString("Signal", "Sync2");
									xmlWriter.WriteElementString("State", "Positive");
									break;
								case -1:
									xmlWriter.WriteElementString("Signal", "Depth1");
									xmlWriter.WriteElementString("State", "Negative");
									break;
								case -2:
									xmlWriter.WriteElementString("Signal", "Depth2");
									xmlWriter.WriteElementString("State", "Negative");
									break;
								case -3:
									xmlWriter.WriteElementString("Signal", "DigitalSignal");
									xmlWriter.WriteElementString("State", "Negative");
									break;
								case -4:
									xmlWriter.WriteElementString("Signal", "Sync1");
									xmlWriter.WriteElementString("State", "Negative");
									break;
								case -5:
									xmlWriter.WriteElementString("Signal", "Sync2");
									xmlWriter.WriteElementString("State", "Negative");
									break;
								default:
									xmlWriter.WriteElementString("Signal", "");
									xmlWriter.WriteElementString("State", "");
									break;
								}
								xmlWriter.WriteEndElement();
							}
							if (this.Main.VisibleParameters.DSmin[num4, num3])
							{
								xmlWriter.WriteStartElement("DigitalSignalCheckedAtTheEnd");
								if (progStruct.Step[i].DigMin == 0)
								{
									xmlWriter.WriteElementString("Select", "0");
								}
								else
								{
									xmlWriter.WriteElementString("Select", "1");
								}
								switch (progStruct.Step[i].DigMin)
								{
								case 1:
									xmlWriter.WriteElementString("Signal", "Depth1");
									xmlWriter.WriteElementString("State", "Positive");
									break;
								case 2:
									xmlWriter.WriteElementString("Signal", "Depth2");
									xmlWriter.WriteElementString("State", "Positive");
									break;
								case 3:
									xmlWriter.WriteElementString("Signal", "DigitalSignal");
									xmlWriter.WriteElementString("State", "Positive");
									break;
								case 4:
									xmlWriter.WriteElementString("Signal", "Sync1");
									xmlWriter.WriteElementString("State", "Positive");
									break;
								case 5:
									xmlWriter.WriteElementString("Signal", "Sync2");
									xmlWriter.WriteElementString("State", "Positive");
									break;
								case -1:
									xmlWriter.WriteElementString("Signal", "Depth1");
									xmlWriter.WriteElementString("State", "Negative");
									break;
								case -2:
									xmlWriter.WriteElementString("Signal", "Depth2");
									xmlWriter.WriteElementString("State", "Negative");
									break;
								case -3:
									xmlWriter.WriteElementString("Signal", "DigitalSignal");
									xmlWriter.WriteElementString("State", "Negative");
									break;
								case -4:
									xmlWriter.WriteElementString("Signal", "Sync1");
									xmlWriter.WriteElementString("State", "Negative");
									break;
								case -5:
									xmlWriter.WriteElementString("Signal", "Sync2");
									xmlWriter.WriteElementString("State", "Negative");
									break;
								default:
									xmlWriter.WriteElementString("Signal", "");
									xmlWriter.WriteElementString("State", "");
									break;
								}
								xmlWriter.WriteEndElement();
							}
							xmlWriter.WriteElementString("MaxRepetitionOfStep", progStruct.Step[i].CountPassMax.ToString());
							xmlWriter.WriteEndElement();
							xmlWriter.WriteEndElement();
							break;
						}
						break;
					}
				}
				xmlWriter.WriteEndElement();
				xmlWriter.WriteEndDocument();
				xmlWriter.Flush();
				xmlWriter.Close();
				return true;
			}
			catch (Exception ex)
			{
				MessageBox.Show("Could not open file! " + ex.Message, "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
		}
	}
}
