using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class ErrorDisplayForm : Form
	{
		private MainForm Main;

		private Thread ErrorThread;

		private bool IsErrorOrWarning;

		private Button btMinimize;

		private Button btOK;

		private TextBox tBMessage;

		private TextBox tBInternalMsg;

		private Button btHelp;

		private System.Windows.Forms.Timer timerBringToFront;

		private IContainer components;

		private bool formWasVisible;

		public ErrorDisplayForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.IsErrorOrWarning = false;
			this.ErrorThread = new Thread(this.ErrorThreadFunc);
			this.ErrorThread.Start();
		}

		private void ErrorDisplayForm_Load(object sender, EventArgs e)
		{
			if (!this.Main._READ_ONLY_CONTROLLER)
			{
				this.btOK.Enabled = true;
			}
			else
			{
				this.btOK.Enabled = false;
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(ErrorDisplayForm));
			this.btMinimize = new Button();
			this.btOK = new Button();
			this.tBInternalMsg = new TextBox();
			this.tBMessage = new TextBox();
			this.btHelp = new Button();
			this.timerBringToFront = new System.Windows.Forms.Timer(this.components);
			base.SuspendLayout();
			this.btMinimize.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btMinimize.Location = new Point(143, 224);
			this.btMinimize.Name = "btMinimize";
			this.btMinimize.Size = new Size(104, 32);
			this.btMinimize.TabIndex = 0;
			this.btMinimize.Text = "Minimize";
			this.btMinimize.Click += this.btMinimize_Click;
			this.btOK.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btOK.Location = new Point(272, 224);
			this.btOK.Name = "btOK";
			this.btOK.Size = new Size(88, 32);
			this.btOK.TabIndex = 1;
			this.btOK.Text = "OK";
			this.btOK.Click += this.btOK_Click;
			this.tBInternalMsg.BackColor = SystemColors.Control;
			this.tBInternalMsg.Location = new Point(8, 144);
			this.tBInternalMsg.Multiline = true;
			this.tBInternalMsg.Name = "tBInternalMsg";
			this.tBInternalMsg.ReadOnly = true;
			this.tBInternalMsg.Size = new Size(375, 64);
			this.tBInternalMsg.TabIndex = 3;
			this.tBInternalMsg.Text = "tbInternalMsg";
			this.tBMessage.BackColor = SystemColors.Control;
			this.tBMessage.Location = new Point(8, 16);
			this.tBMessage.Multiline = true;
			this.tBMessage.Name = "tBMessage";
			this.tBMessage.ReadOnly = true;
			this.tBMessage.Size = new Size(375, 120);
			this.tBMessage.TabIndex = 4;
			this.tBMessage.Text = "Meldungsausgabe";
			this.btHelp.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.btHelp.Location = new Point(32, 224);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(88, 32);
			this.btHelp.TabIndex = 5;
			this.btHelp.Text = "Help";
			this.btHelp.Click += this.btHome_Click;
			this.timerBringToFront.Tick += this.timerBringToFront_Tick;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(394, 278);
			base.ControlBox = false;
			base.Controls.Add(this.btHelp);
			base.Controls.Add(this.tBMessage);
			base.Controls.Add(this.tBInternalMsg);
			base.Controls.Add(this.btOK);
			base.Controls.Add(this.btMinimize);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
			//base.Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.Name = "ErrorDisplayForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			this.Text = "ErrorDisplay";
			base.Activated += this.ErrorDisplayForm_Activated;
			base.Deactivate += this.ErrorDisplayForm_Deactivate;
			base.Load += this.ErrorDisplayForm_Load;
			base.LocationChanged += this.ErrorDisplayForm_LocationChanged;
			base.VisibleChanged += this.ErrorDisplayForm_VisibleChanged;
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public void SetLanguageTexts()
		{
			this.btHelp.Text = this.Main.Rm.GetString("Help");
			this.btMinimize.Text = this.Main.Rm.GetString("Minimize");
			this.btOK.Text = this.Main.Rm.GetString("Quit");
		}

		public void DestructErrorThread()
		{
			if (this.ErrorThread != null && this.ErrorThread.IsAlive)
			{
				this.ErrorThread.Abort();
			}
		}

		private void ErrorThreadFunc()
		{
			while (true)
			{
				if (this.IsErrorOrWarning)
				{
					this.IsErrorOrWarning = false;
					this.Main.Invoke(new MethodInvoker(this.DisplayError));
				}
				Thread.Sleep(100);
			}
		}

		public void SetErrorFlag()
		{
			this.IsErrorOrWarning = true;
		}

		public void MakeInvisible(bool invisible)
		{
			if (invisible)
			{
				if (base.WindowState == FormWindowState.Minimized)
				{
					this.formWasVisible = false;
				}
				else
				{
					this.formWasVisible = true;
					this.btMinimize_Click(null, EventArgs.Empty);
				}
			}
			else if (this.formWasVisible)
			{
				this.timerBringToFront.Start();
			}
		}

		private void ErrorDisplayForm_VisibleChanged(object sender, EventArgs e)
		{
			if (base.WindowState == FormWindowState.Minimized)
			{
				this.formWasVisible = false;
			}
			else
			{
				this.formWasVisible = true;
			}
		}

		private void ErrorDisplayForm_Shown(object sender, EventArgs e)
		{
		}

		private void timerBringToFront_Tick(object sender, EventArgs e)
		{
			this.timerBringToFront.Stop();
			base.WindowState = FormWindowState.Normal;
			base.BringToFront();
		}

		private void btMinimize_Click(object sender, EventArgs e)
		{
			base.WindowState = FormWindowState.Minimized;
			base.BringToFront();
			base.SendToBack();
			this.Main.ToFront();
		}

		public void Simulate()
		{
			this.btOK_Click(null, EventArgs.Empty);
		}

		private void btOK_Click(object sender, EventArgs e)
		{
			this.Main.VC.ErrorSys.Num = 0u;
			this.Main.VC.ErrorSys.Quit = 1;
			if (this.Main.IsOnlineMode)
			{
				if (!this.Main.VC.SendVarBlock(5))
				{
					MessageBox.Show("Could not send ErrorSysBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				MessageBox.Show(this.Main.Rm.GetString("MbErrorQuitFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			base.Hide();
			this.Main.MenEna();
		}

		private void DisplayError()
		{
			if (this.Main.IsOnlineMode)
			{
				if (!this.Main.VC.ReceiveVarBlock(5))
				{
					MessageBox.Show("Could not receive ErrorSysBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (this.Main.VC.ErrorSys.Num == 0)
				{
					base.Hide();
					this.Main.MenEna();
				}
				else
				{
					if (this.Main.VC.ErrorSys.Warning == 0)
					{
						this.Text = this.Main.Rm.GetString("ControllerName") + " " + this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) + " " + this.Main.Rm.GetString("ErrorNumber") + ": " + this.Main.VC.ErrorSys.Num.ToString();
					}
					else
					{
						this.Text = this.Main.Rm.GetString("ControllerName") + " " + this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) + " " + this.Main.Rm.GetString("WarningNumber") + ": " + this.Main.VC.ErrorSys.Num.ToString();
					}
					this.tBInternalMsg.Clear();
					this.tBMessage.Clear();
					this.tBInternalMsg.AppendText(this.Main.CommonFunctions.UShortToString(this.Main.VC.ErrorSys.Text) + string.Empty);
					if (this.Main.VC.ErrorSys.Warning == 0)
					{
						this.tBMessage.AppendText(this.Main.Rm.GetString("Error" + this.Main.VC.ErrorSys.Num.ToString()) + string.Empty);
					}
					else
					{
						this.tBMessage.AppendText(this.Main.Rm.GetString("Error" + this.Main.VC.ErrorSys.Num.ToString()) + string.Empty);
					}
					base.Show();
					this.Main.MenEna();
					base.Focus();
				}
			}
		}

		public void CheckMessageStatus()
		{
			if (this.Main.IsOnlineMode)
			{
				if (!this.Main.VC.ReceiveVarBlock(5))
				{
					MessageBox.Show("Could not receive ErrorSysBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (this.Main.VC.ErrorSys.Num != 0)
				{
					this.IsErrorOrWarning = true;
				}
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.ShowHelp();
			this.Main.HelpButton = false;
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap7_Meldungen";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.Main.BrowserHelp.Navigate("#Kap7_Meldungen");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
		}

		private void ErrorDisplayForm_Activated(object sender, EventArgs e)
		{
			if (base.WindowState == FormWindowState.Minimized)
			{
				this.formWasVisible = false;
			}
			else
			{
				this.formWasVisible = true;
			}
		}

		private void ErrorDisplayForm_LocationChanged(object sender, EventArgs e)
		{
			if (base.WindowState == FormWindowState.Minimized)
			{
				this.formWasVisible = false;
			}
			else
			{
				this.formWasVisible = true;
			}
		}

		private void ErrorDisplayForm_Deactivate(object sender, EventArgs e)
		{
			if (base.WindowState == FormWindowState.Minimized)
			{
				this.formWasVisible = false;
			}
			else
			{
				this.formWasVisible = true;
			}
		}
	}
}
