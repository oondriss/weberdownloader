using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class ResultDisplayForm : Form
	{
		private MainForm Main;

		private Button btAnalysis;

		private Button btParameter;

		private Button btTest;

		private Panel pnMenu;

		private Panel pnWork;

		private Button btHelp;

		private Button btReconnect;

		private Label lbIONIO;

		private Label lbResult1;

		private Label lbResult2;

		private Label lbResult3;

		private Label lbResName1;

		private Label lbResName2;

		private Label lbResName3;

		private Label lbResUnit1;

		private Label lbResUnit2;

		private Label lbResUnit3;

		private Label lbResultHeadline;

		private Label lbScrewTime;

		private Label lbNIOReason;

		private Label lbTime;

		private Label lbCycleNumber;

		private Label lbControllerName;

		private Button btExit;

		private Button btHandStart;

		private Button btShowMiniDisplay;

		private Label lbChannelName;

		private Label lbScrewID;

		private Button btBrowser;

		private Label lbAdvanceWarning3;

		private Label lbAdvanceWarning2;

		private System.Windows.Forms.Timer timerMaintenanceDisplay;

		private PictureBox pictureBox1;

		private IContainer components;

		public ResultDisplayForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.Main.VC.VARSERVEREVENT_Result += this.VSE_Result;
			this.btBrowser.Visible = Settings.Default.IntegratedMachineVisu;
			this.DoubleBuffered = true;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			this.btAnalysis = new Button();
			this.btParameter = new Button();
			this.btTest = new Button();
			this.btHelp = new Button();
			this.btReconnect = new Button();
			this.pnMenu = new Panel();
			this.btBrowser = new Button();
			this.btExit = new Button();
			this.btShowMiniDisplay = new Button();
			this.btHandStart = new Button();
			this.pnWork = new Panel();
			this.pictureBox1 = new PictureBox();
			this.lbAdvanceWarning3 = new Label();
			this.lbAdvanceWarning2 = new Label();
			this.lbScrewID = new Label();
			this.lbChannelName = new Label();
			this.lbControllerName = new Label();
			this.lbScrewTime = new Label();
			this.lbNIOReason = new Label();
			this.lbTime = new Label();
			this.lbCycleNumber = new Label();
			this.lbResultHeadline = new Label();
			this.lbResUnit3 = new Label();
			this.lbResUnit2 = new Label();
			this.lbResUnit1 = new Label();
			this.lbResName3 = new Label();
			this.lbResName2 = new Label();
			this.lbResName1 = new Label();
			this.lbResult3 = new Label();
			this.lbResult2 = new Label();
			this.lbResult1 = new Label();
			this.lbIONIO = new Label();
			this.timerMaintenanceDisplay = new System.Windows.Forms.Timer(this.components);
			this.pnMenu.SuspendLayout();
			this.pnWork.SuspendLayout();
			((ISupportInitialize)this.pictureBox1).BeginInit();
			base.SuspendLayout();
			this.btAnalysis.Location = new Point(3, 131);
			this.btAnalysis.Name = "btAnalysis";
			this.btAnalysis.Size = new Size(74, 62);
			this.btAnalysis.TabIndex = 2;
			this.btAnalysis.Text = "Auswertung";
			this.btAnalysis.Click += this.btAnalysis_Click;
			this.btParameter.Location = new Point(3, 67);
			this.btParameter.Name = "btParameter";
			this.btParameter.Size = new Size(74, 62);
			this.btParameter.TabIndex = 1;
			this.btParameter.Text = "Einstellungen";
			this.btParameter.Click += this.btParameter_Click;
			this.btTest.Location = new Point(3, 195);
			this.btTest.Name = "btTest";
			this.btTest.Size = new Size(74, 62);
			this.btTest.TabIndex = 3;
			this.btTest.Text = "Test";
			this.btTest.Click += this.btTest_Click;
			this.btHelp.Location = new Point(3, 3);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 0;
			this.btHelp.Click += this.btHome_Click;
			this.btReconnect.Location = new Point(3, 323);
			this.btReconnect.Name = "btReconnect";
			this.btReconnect.Size = new Size(74, 62);
			this.btReconnect.TabIndex = 4;
			this.btReconnect.Text = "Verbindung zur Steuerung herstellen";
			this.btReconnect.Click += this.btReconnect_Click;
			this.pnMenu.Controls.Add(this.btBrowser);
			this.pnMenu.Controls.Add(this.btExit);
			this.pnMenu.Controls.Add(this.btShowMiniDisplay);
			this.pnMenu.Controls.Add(this.btHandStart);
			this.pnMenu.Controls.Add(this.btAnalysis);
			this.pnMenu.Controls.Add(this.btReconnect);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btTest);
			this.pnMenu.Controls.Add(this.btParameter);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btBrowser.Location = new Point(3, 323);
			this.btBrowser.Name = "btBrowser";
			this.btBrowser.Size = new Size(74, 62);
			this.btBrowser.TabIndex = 8;
			this.btBrowser.Text = "Browser";
			this.btBrowser.Click += this.btBrowser_Click;
			this.btExit.Location = new Point(3, 451);
			this.btExit.Name = "btExit";
			this.btExit.Size = new Size(74, 62);
			this.btExit.TabIndex = 6;
			this.btExit.Text = "Beenden";
			this.btExit.Click += this.btExit_Click;
			this.btShowMiniDisplay.Location = new Point(3, 387);
			this.btShowMiniDisplay.Name = "btShowMiniDisplay";
			this.btShowMiniDisplay.Size = new Size(74, 62);
			this.btShowMiniDisplay.TabIndex = 5;
			this.btShowMiniDisplay.Text = "Kleine Anzeige";
			this.btShowMiniDisplay.Click += this.btShowMiniDisplay_Click;
			this.btHandStart.Location = new Point(3, 259);
			this.btHandStart.Name = "btHandStart";
			this.btHandStart.Size = new Size(74, 62);
			this.btHandStart.TabIndex = 7;
			this.btHandStart.Text = "Handstart";
			this.btHandStart.Click += this.btHandStart_Click;
			this.pnWork.Controls.Add(this.pictureBox1);
			this.pnWork.Controls.Add(this.lbAdvanceWarning3);
			this.pnWork.Controls.Add(this.lbAdvanceWarning2);
			this.pnWork.Controls.Add(this.lbScrewID);
			this.pnWork.Controls.Add(this.lbChannelName);
			this.pnWork.Controls.Add(this.lbControllerName);
			this.pnWork.Controls.Add(this.lbScrewTime);
			this.pnWork.Controls.Add(this.lbNIOReason);
			this.pnWork.Controls.Add(this.lbTime);
			this.pnWork.Controls.Add(this.lbCycleNumber);
			this.pnWork.Controls.Add(this.lbResultHeadline);
			this.pnWork.Controls.Add(this.lbResUnit3);
			this.pnWork.Controls.Add(this.lbResUnit2);
			this.pnWork.Controls.Add(this.lbResUnit1);
			this.pnWork.Controls.Add(this.lbResName3);
			this.pnWork.Controls.Add(this.lbResName2);
			this.pnWork.Controls.Add(this.lbResName1);
			this.pnWork.Controls.Add(this.lbResult3);
			this.pnWork.Controls.Add(this.lbResult2);
			this.pnWork.Controls.Add(this.lbResult1);
			this.pnWork.Controls.Add(this.lbIONIO);
			this.pnWork.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnWork.ForeColor = SystemColors.WindowText;
			this.pnWork.Location = new Point(0, 0);
			this.pnWork.Name = "pnWork";
			this.pnWork.Size = new Size(709, 522);
			this.pnWork.TabIndex = 1;
			//this.pictureBox1.Image = Resources.Weber_Logo_Large;
			this.pictureBox1.Location = new Point(520, 10);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new Size(176, 61);
			this.pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 40;
			this.pictureBox1.TabStop = false;
			this.lbAdvanceWarning3.BackColor = Color.Yellow;
			this.lbAdvanceWarning3.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbAdvanceWarning3.Location = new Point(255, 139);
			this.lbAdvanceWarning3.Name = "lbAdvanceWarning3";
			this.lbAdvanceWarning3.Size = new Size(445, 55);
			this.lbAdvanceWarning3.TabIndex = 39;
			this.lbAdvanceWarning3.Text = "Vorwarnung 3";
			this.lbAdvanceWarning3.TextAlign = ContentAlignment.MiddleCenter;
			this.lbAdvanceWarning3.Visible = false;
			this.lbAdvanceWarning3.Click += this.lbAdvanceWarningX_Click;
			this.lbAdvanceWarning2.BackColor = Color.Yellow;
			this.lbAdvanceWarning2.Font = new Font("Arial Unicode MS", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbAdvanceWarning2.Location = new Point(255, 111);
			this.lbAdvanceWarning2.Name = "lbAdvanceWarning2";
			this.lbAdvanceWarning2.Size = new Size(445, 28);
			this.lbAdvanceWarning2.TabIndex = 38;
			this.lbAdvanceWarning2.Text = "Vorwarnung 2";
			this.lbAdvanceWarning2.TextAlign = ContentAlignment.MiddleCenter;
			this.lbAdvanceWarning2.Visible = false;
			this.lbAdvanceWarning2.Click += this.lbAdvanceWarningX_Click;
			this.lbScrewID.Font = new Font("Arial Unicode MS", 18f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbScrewID.Location = new Point(16, 144);
			this.lbScrewID.Name = "lbScrewID";
			this.lbScrewID.Size = new Size(680, 32);
			this.lbScrewID.TabIndex = 36;
			this.lbScrewID.Text = "ID: Pos1";
			this.lbScrewID.TextAlign = ContentAlignment.MiddleLeft;
			this.lbChannelName.Font = new Font("Arial Unicode MS", 30f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbChannelName.Location = new Point(8, 16);
			this.lbChannelName.Name = "lbChannelName";
			this.lbChannelName.Size = new Size(506, 42);
			this.lbChannelName.TabIndex = 35;
			this.lbChannelName.Text = "Name der Steuerungseinheit";
			this.lbChannelName.TextAlign = ContentAlignment.MiddleLeft;
			this.lbControllerName.Font = new Font("Arial Unicode MS", 50f, FontStyle.Bold, GraphicsUnit.Pixel, 0);
			this.lbControllerName.Location = new Point(536, 16);
			this.lbControllerName.Name = "lbControllerName";
			this.lbControllerName.Size = new Size(160, 70);
			this.lbControllerName.TabIndex = 34;
			this.lbControllerName.Text = "C50S";
			this.lbControllerName.TextAlign = ContentAlignment.MiddleRight;
			this.lbControllerName.Visible = false;
			this.lbScrewTime.Font = new Font("Microsoft Sans Serif", 21f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbScrewTime.Location = new Point(176, 240);
			this.lbScrewTime.Name = "lbScrewTime";
			this.lbScrewTime.Size = new Size(520, 29);
			this.lbScrewTime.TabIndex = 33;
			this.lbScrewTime.Text = "Schraubzeit";
			this.lbScrewTime.TextAlign = ContentAlignment.MiddleLeft;
			this.lbNIOReason.Font = new Font("Microsoft Sans Serif", 21f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbNIOReason.Location = new Point(176, 296);
			this.lbNIOReason.Name = "lbNIOReason";
			this.lbNIOReason.Size = new Size(520, 29);
			this.lbNIOReason.TabIndex = 32;
			this.lbNIOReason.Text = "NIO Grund";
			this.lbNIOReason.TextAlign = ContentAlignment.MiddleLeft;
			this.lbTime.Font = new Font("Microsoft Sans Serif", 18f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTime.Location = new Point(320, 192);
			this.lbTime.Name = "lbTime";
			this.lbTime.Size = new Size(376, 30);
			this.lbTime.TabIndex = 31;
			this.lbTime.Text = "Zeitpunkt";
			this.lbTime.TextAlign = ContentAlignment.MiddleLeft;
			this.lbCycleNumber.Font = new Font("Microsoft Sans Serif", 18f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbCycleNumber.Location = new Point(16, 192);
			this.lbCycleNumber.Name = "lbCycleNumber";
			this.lbCycleNumber.Size = new Size(280, 32);
			this.lbCycleNumber.TabIndex = 30;
			this.lbCycleNumber.Text = "Zyklusnummer";
			this.lbCycleNumber.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResultHeadline.Font = new Font("Arial Unicode MS", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbResultHeadline.Location = new Point(16, 80);
			this.lbResultHeadline.Name = "lbResultHeadline";
			this.lbResultHeadline.Size = new Size(680, 42);
			this.lbResultHeadline.TabIndex = 14;
			this.lbResultHeadline.Text = "name";
			this.lbResultHeadline.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResUnit3.Font = new Font("Arial Unicode MS", 26f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResUnit3.Location = new Point(576, 456);
			this.lbResUnit3.Name = "lbResUnit3";
			this.lbResUnit3.Size = new Size(120, 43);
			this.lbResUnit3.TabIndex = 13;
			this.lbResUnit3.Text = "unit";
			this.lbResUnit3.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResUnit2.Font = new Font("Arial Unicode MS", 26f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResUnit2.Location = new Point(576, 400);
			this.lbResUnit2.Name = "lbResUnit2";
			this.lbResUnit2.Size = new Size(120, 43);
			this.lbResUnit2.TabIndex = 12;
			this.lbResUnit2.Text = "unit";
			this.lbResUnit2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResUnit1.Font = new Font("Arial Unicode MS", 26f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResUnit1.Location = new Point(576, 344);
			this.lbResUnit1.Name = "lbResUnit1";
			this.lbResUnit1.Size = new Size(120, 43);
			this.lbResUnit1.TabIndex = 11;
			this.lbResUnit1.Text = "unit";
			this.lbResUnit1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResName3.Font = new Font("Arial Unicode MS", 26f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResName3.Location = new Point(16, 456);
			this.lbResName3.Name = "lbResName3";
			this.lbResName3.Size = new Size(392, 43);
			this.lbResName3.TabIndex = 10;
			this.lbResName3.Text = "Ergebnis3";
			this.lbResName3.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResName2.Font = new Font("Arial Unicode MS", 26f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResName2.Location = new Point(16, 400);
			this.lbResName2.Name = "lbResName2";
			this.lbResName2.Size = new Size(392, 43);
			this.lbResName2.TabIndex = 9;
			this.lbResName2.Text = "Ergebnis2";
			this.lbResName2.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResName1.Font = new Font("Arial Unicode MS", 26f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResName1.Location = new Point(16, 344);
			this.lbResName1.Name = "lbResName1";
			this.lbResName1.Size = new Size(392, 43);
			this.lbResName1.TabIndex = 8;
			this.lbResName1.Text = "Ergebnis1";
			this.lbResName1.TextAlign = ContentAlignment.MiddleLeft;
			this.lbResult3.BackColor = SystemColors.Window;
			this.lbResult3.BorderStyle = BorderStyle.Fixed3D;
			this.lbResult3.Font = new Font("Arial Unicode MS", 26f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResult3.Location = new Point(416, 456);
			this.lbResult3.Name = "lbResult3";
			this.lbResult3.Size = new Size(152, 45);
			this.lbResult3.TabIndex = 7;
			this.lbResult3.Text = "n.v.";
			this.lbResult3.TextAlign = ContentAlignment.MiddleRight;
			this.lbResult2.BackColor = SystemColors.Window;
			this.lbResult2.BorderStyle = BorderStyle.Fixed3D;
			this.lbResult2.Font = new Font("Arial Unicode MS", 26f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResult2.Location = new Point(416, 400);
			this.lbResult2.Name = "lbResult2";
			this.lbResult2.Size = new Size(152, 45);
			this.lbResult2.TabIndex = 6;
			this.lbResult2.Text = "n.v.";
			this.lbResult2.TextAlign = ContentAlignment.MiddleRight;
			this.lbResult1.BackColor = SystemColors.Window;
			this.lbResult1.BorderStyle = BorderStyle.Fixed3D;
			this.lbResult1.Font = new Font("Arial Unicode MS", 26f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbResult1.Location = new Point(416, 344);
			this.lbResult1.Name = "lbResult1";
			this.lbResult1.Size = new Size(152, 45);
			this.lbResult1.TabIndex = 5;
			this.lbResult1.Text = "n.v.";
			this.lbResult1.TextAlign = ContentAlignment.MiddleRight;
			this.lbIONIO.BackColor = SystemColors.Window;
			this.lbIONIO.BorderStyle = BorderStyle.Fixed3D;
			this.lbIONIO.Font = new Font("Arial Unicode MS", 36f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbIONIO.Location = new Point(16, 230);
			this.lbIONIO.Name = "lbIONIO";
			this.lbIONIO.Size = new Size(154, 101);
			this.lbIONIO.TabIndex = 4;
			this.lbIONIO.Text = "NOK";
			this.lbIONIO.TextAlign = ContentAlignment.MiddleCenter;
			this.lbIONIO.Click += this.lbIONIO_Click;
			this.lbIONIO.MouseDown += this.lbIONIO_MouseDown;
			this.lbIONIO.MouseLeave += this.lbIONIO_MouseLeave;
			this.lbIONIO.MouseUp += this.lbIONIO_MouseUp;
			this.timerMaintenanceDisplay.Interval = 1000;
			this.timerMaintenanceDisplay.Tick += this.timerMaintenanceDisplay_Tick;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.pnWork);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.Name = "ResultDisplayForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Hauptmenü - Ergebnisanzeige";
			base.Activated += this.ResultDisplayForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.pnWork.ResumeLayout(false);
			((ISupportInitialize)this.pictureBox1).EndInit();
			base.ResumeLayout(false);
		}

		public void ShowWindow()
		{
			if (this.Main.IsOnlineMode && !this.Main.VC.ReceiveVarBlock(8) && !this.Main.StationAvailable())
			{
				this.Main.ControllerIsOfflineNow();
			}
			this.Main.ActivationBrowserGrantedBy = this;
			base.Show();
		}

		public void EnableMenu()
		{
			this.pnMenu.Enabled = true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("ResultDisplay");
			this.btExit.Text = this.Main.Rm.GetString("Exit");
			this.btAnalysis.Text = this.Main.Rm.GetString("Analysis");
			this.btParameter.Text = this.Main.Rm.GetString("Settings");
			this.btTest.Text = this.Main.Rm.GetString("Test");
			this.btHelp.Text = "";
			this.btHelp.Visible = false;
			this.btHandStart.Text = this.Main.Rm.GetString("HandStart");
			this.btReconnect.Text = this.Main.Rm.GetString("Reconnect");
			this.btShowMiniDisplay.Text = this.Main.Rm.GetString("MiniDisplay");
			this.btBrowser.Text = this.Main.Rm.GetString("MachineVisu");
			this.lbControllerName.Text = this.Main.Rm.GetString("ControllerName");
			this.UpdateValues();
		}

		public void MenEna()
		{
			this.btHelp.Enabled = false;
			this.btBrowser.Enabled = Settings.Default.IntegratedMachineVisu;
			this.Main.ShowCurrentUserAccessState(0, false);
			if (this.Main.IsOnlineMode)
			{
				this.btReconnect.Enabled = false;
				this.btBrowser.Enabled = true;
				if (!this.Main.Usb_Key_Access() || Settings.Default.IntegratedMachineVisu)
				{
					this.btReconnect.Visible = false;
					this.btBrowser.Visible = true;
					this.btBrowser.Enabled = true;
				}
				else
				{
					this.btReconnect.Visible = true;
					this.btBrowser.Visible = false;
				}
			}
			else
			{
				this.btBrowser.Visible = false;
				this.btReconnect.Visible = true;
				if (!this.Main.IsOfflineVersion)
				{
					this.btReconnect.Enabled = true;
					this.btBrowser.Enabled = false;
				}
				else
				{
					this.btReconnect.Enabled = false;
					this.btBrowser.Enabled = false;
				}
			}
			this.AdvanceWarningsDisplay();
			if (this.Main._READ_ONLY_CONTROLLER)
			{
				this.btBrowser.Enabled = false;
				this.btHandStart.Enabled = false;
			}
			else
			{
				this.btBrowser.Enabled = true;
				this.btHandStart.Enabled = true;
			}
		}

		public void UpdateValues()
		{
			string empty = string.Empty;
			this.lbChannelName.Text = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName);
			this.lbScrewID.Text = this.Main.Rm.GetString("ScrewID") + ": " + this.Main.CommonFunctions.ByteToString(this.Main.VC.Result.ScrewID);
			if (this.Main.VC.Result.IONIO <= 0)
			{
				this.lbResultHeadline.Text = string.Empty;
				this.lbIONIO.Text = this.Main.Rm.GetString("NotValid");
				this.lbIONIO.BackColor = Color.Yellow;
				this.lbIONIO.FlatStyle = FlatStyle.Popup;
				this.lbIONIO.BorderStyle = BorderStyle.None;
				this.lbNIOReason.Text = string.Empty;
				this.lbTime.Text = this.Main.Rm.GetString("PointOfTime") + ": " + this.Main.Rm.GetString("NotValid");
			}
			else
			{
				if (this.Main.VC.Result.Prog.Info.ProgNum == 0)
				{
					this.lbResultHeadline.Text = this.Main.Rm.GetString("FrictionTest");
				}
				else
				{
					this.lbResultHeadline.Text = this.Main.Rm.GetString("Program") + " " + this.Main.VC.Result.Prog.Info.ProgNum.ToString() + ": " + this.Main.CommonFunctions.UShortToString(this.Main.VC.Result.Prog.Info.Name);
				}
				if (this.Main.VC.Result.IONIO == 1)
				{
					this.lbIONIO.Text = " " + this.Main.Rm.GetString("OK");
					this.lbIONIO.BackColor = Color.Lime;
					this.lbIONIO.FlatStyle = FlatStyle.Popup;
					this.lbIONIO.BorderStyle = BorderStyle.None;
					this.lbNIOReason.Text = string.Empty;
				}
				else
				{
					this.lbIONIO.Text = this.Main.Rm.GetString("NOK");
					this.lbIONIO.BackColor = Color.Red;
					this.lbIONIO.FlatStyle = FlatStyle.Popup;
					this.lbIONIO.BorderStyle = BorderStyle.None;
					this.lbNIOReason.Text = this.Main.Rm.GetString("NIO" + this.Main.VC.Result.IONIO.ToString()) + "(" + this.Main.Rm.GetString("Step") + " " + (this.Main.VC.Result.LastStep + 1).ToString() + ")";
				}
				DateTime dateTime;
				try
				{
					dateTime = new DateTime(this.Main.VC.Result.Time.Year, this.Main.VC.Result.Time.Month, this.Main.VC.Result.Time.Day, this.Main.VC.Result.Time.Hour, this.Main.VC.Result.Time.Minute, this.Main.VC.Result.Time.Second);
				}
				catch
				{
					dateTime = new DateTime(1, 1, 1, 0, 0, 0);
				}
				this.lbTime.Text = this.Main.Rm.GetString("PointOfTime") + ": " + dateTime.ToString(Settings.Default.TimeSet);
			}
			if ((this.Main.VC.Result.Valid & 1) > 0)
			{
				this.lbResult1.Text = ((1f + this.Main.CommonFunctions.GetResFactor(this.Main.VC.Result.Prog.Info.ResultParam1) * (this.Main.TorqueConvert - 1f)) * this.Main.VC.Result.Res1).ToString("f" + this.Main.CommonFunctions.GetResDigits(this.Main.VC.Result.Prog.Info.ResultParam1).ToString());
			}
			else
			{
				this.lbResult1.Text = this.Main.Rm.GetString("NotValid");
			}
			if ((this.Main.VC.Result.Valid & 2) > 0)
			{
				this.lbResult2.Text = ((1f + this.Main.CommonFunctions.GetResFactor(this.Main.VC.Result.Prog.Info.ResultParam2) * (this.Main.TorqueConvert - 1f)) * this.Main.VC.Result.Res2).ToString("f" + this.Main.CommonFunctions.GetResDigits(this.Main.VC.Result.Prog.Info.ResultParam2).ToString());
			}
			else
			{
				this.lbResult2.Text = this.Main.Rm.GetString("NotValid");
			}
			if ((this.Main.VC.Result.Valid & 4) > 0)
			{
				this.lbResult3.Text = ((1f + this.Main.CommonFunctions.GetResFactor(this.Main.VC.Result.Prog.Info.ResultParam3) * (this.Main.TorqueConvert - 1f)) * this.Main.VC.Result.Res3).ToString("f" + this.Main.CommonFunctions.GetResDigits(this.Main.VC.Result.Prog.Info.ResultParam3).ToString());
			}
			else
			{
				this.lbResult3.Text = this.Main.Rm.GetString("NotValid");
			}
			if (this.Main.VC.Result.Prog.Info.ProgNum == 0)
			{
				this.lbResName1.Text = this.Main.Rm.GetString("FrictionTorque");
				this.lbResName2.Text = this.Main.Rm.GetString("RightAngle");
				this.lbResName3.Text = this.Main.Rm.GetString("LeftAngle");
			}
			else
			{
				empty = ((this.Main.VC.Result.ResultStep1 >= 0) ? (" (" + this.Main.Rm.GetString("Step") + " " + (this.Main.VC.Result.ResultStep1 + 1).ToString() + ")") : string.Empty);
				this.lbResName1.Text = this.Main.CommonFunctions.GetResName(this.Main.VC.Result.Prog.Info.ResultParam1) + empty;
				empty = ((this.Main.VC.Result.ResultStep2 >= 0) ? (" (" + this.Main.Rm.GetString("Step") + " " + (this.Main.VC.Result.ResultStep2 + 1).ToString() + ")") : string.Empty);
				this.lbResName2.Text = this.Main.CommonFunctions.GetResName(this.Main.VC.Result.Prog.Info.ResultParam2) + empty;
				empty = ((this.Main.VC.Result.ResultStep3 >= 0) ? (" (" + this.Main.Rm.GetString("Step") + " " + (this.Main.VC.Result.ResultStep3 + 1).ToString() + ")") : string.Empty);
				this.lbResName3.Text = this.Main.CommonFunctions.GetResName(this.Main.VC.Result.Prog.Info.ResultParam3) + empty;
			}
			this.lbResUnit1.Text = this.Main.CommonFunctions.GetResUnit(this.Main.VC.Result.Prog.Info.ResultParam1, this.Main.TorqueUnitName);
			this.lbResUnit2.Text = this.Main.CommonFunctions.GetResUnit(this.Main.VC.Result.Prog.Info.ResultParam2, this.Main.TorqueUnitName);
			this.lbResUnit3.Text = this.Main.CommonFunctions.GetResUnit(this.Main.VC.Result.Prog.Info.ResultParam3, this.Main.TorqueUnitName);
			this.lbCycleNumber.Text = this.Main.Rm.GetString("CycleNumber") + ": " + this.Main.VC.Result.Cycle.ToString();
			this.lbScrewTime.Text = this.Main.Rm.GetString("ScrewTime") + ": " + this.Main.VC.Result.ScrewDuration.ToString("f" + 2.ToString()) + "s";
		}

		private void VSE_Result(object sender, VARServerEventArgs e)
		{
			this.Main.Invoke(new MethodInvoker(this.ResultUpdate));
		}

		private void ResultUpdate()
		{
			if (this.Main.IsOnlineMode)
			{
				if (!this.Main.VC.ReceiveVarBlock(8))
				{
					MessageBox.Show("Could not receive ResultBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					this.UpdateValues();
					if (this.Main.ResultMiniDisplay1.Visible)
					{
						this.Main.ResultMiniDisplay1.UpdateValues();
					}
					this.Main.CurveDisplay1.SetCurveNew();
					this.Main.StepResult1.SetUpdateEnable();
					this.Main.CheckMaintenanceLabel(false);
				}
			}
		}

		public bool AdvanceWarningsDisplay()
		{
			if (!this.Main.IsOnlineMode)
			{
				this.lbAdvanceWarning2.Visible = false;
				this.lbAdvanceWarning3.Visible = false;
				return false;
			}
			string namesOfReachedCounters = this.Main.AdvanceWarning1.GetNamesOfReachedCounters();
			if (namesOfReachedCounters.Length != 0)
			{
				this.lbAdvanceWarning2.Visible = true;
				this.lbAdvanceWarning3.Visible = true;
				this.lbAdvanceWarning2.Text = this.Main.Rm.GetString("AdvanceWarningMessages");
				this.lbAdvanceWarning3.Text = namesOfReachedCounters;
				this.checkAndSetColorOfButton(false);
				return true;
			}
			namesOfReachedCounters = this.Main.AdvanceWarning1.GetNamesOfAdvancedCounters();
			if (namesOfReachedCounters.Length != 0)
			{
				this.lbAdvanceWarning2.Visible = true;
				this.lbAdvanceWarning3.Visible = true;
				this.lbAdvanceWarning2.Text = this.Main.Rm.GetString("AdvanceWarningRemainder");
				this.lbAdvanceWarning3.Text = namesOfReachedCounters;
				this.checkAndSetColorOfButton(false);
				return true;
			}
			this.lbAdvanceWarning2.Visible = false;
			this.lbAdvanceWarning3.Visible = false;
			this.checkAndSetColorOfButton(false);
			return false;
		}

		private void timerMaintenanceDisplay_Tick(object sender, EventArgs e)
		{
			this.timerMaintenanceDisplay.Stop();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btExit_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_Menuebeschreibung";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_Menuebeschreibung");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
			this.Main.ShowMachineVisu();
		}

		public void BrowserShow()
		{
			this.Main.Browser1.ShowWindow(this);
			this.Main.DisableHelpButton();
		}

		public void BtParameter_Click()
		{
			this.btParameter_Click(null, EventArgs.Empty);
		}

		private void btParameter_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.Main.UsbKeyQuery();
			if (this.Main.UsbKeyAccessCanceledByUser)
			{
				this.pnMenu.Enabled = true;
			}
			else
			{
				if (this.Main.IsOnlineMode && this.Main.StationAvailable())
				{
					if (this.Main.GetExclusiveBlock1())
					{
						int num = 0;
						if (this.Main.Usb_Key_Access())
						{
							if (this.Main.PassCodeLevel == 0)
							{
								num = 1;
							}
						}
						else
						{
							this.Main.PasswordInput1.ShowWindow(false);
							num = this.Main.PasswordInput1.AccessMode;
						}
						this.Main.DisplayCurrentUser();
						switch (num)
						{
						case 0:
							this.Main.CheckParamAllowed = true;
							break;
						case 1:
							this.Main.ExitExclusiveBlock1();
							this.Main.CheckParamAllowed = false;
							break;
						case 2:
							this.Main.ExitExclusiveBlock1();
							this.pnMenu.Enabled = true;
							return;
						default:
							this.Main.ExitExclusiveBlock1();
							MessageBox.Show("Wrong state in Function btParameter_Click!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							this.pnMenu.Enabled = true;
							return;
						}
					}
					else
					{
						this.Main.ResetPasscodeLevel();
						this.Main.CheckParamAllowed = false;
					}
				}
				else if (!this.Main.Usb_Key_Access())
				{
					if (this.Main.IsOnlineMode)
					{
						this.Main.PassCodeLevel = 4;
					}
					this.Main.CheckParamAllowed = false;
				}
				this.Main.MenuParameter1.ShowWindow();
			}
		}

		private void lbIONIO_Click(object sender, EventArgs e)
		{
		}

		private void lbAdvanceWarningX_Click(object sender, EventArgs e)
		{
			this.BtParameter_Click();
			if (this.Main.ActiveMdiChild != this.Main.ResultDisplay1)
			{
				this.Main.MenuParameter1.BtMaintenance_Click();
				this.Main.MenuMaintenance1.BtMAdvanceWarning_Click();
			}
		}

		private void lbIONIO_MouseDown(object sender, MouseEventArgs e)
		{
		}

		private void lbIONIO_MouseUp(object sender, MouseEventArgs e)
		{
		}

		private void lbIONIO_MouseLeave(object sender, EventArgs e)
		{
		}

		private void btAnalysis_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.Main.MenuAnalysis1.ShowWindow();
		}

		private void btTest_Click(object sender, EventArgs e)
		{
			bool flag = true;
			this.pnMenu.Enabled = false;
			this.Main.UsbKeyQuery();
			if (this.Main.UsbKeyAccessCanceledByUser)
			{
				this.pnMenu.Enabled = true;
			}
			else if (this.Main.IsOnlineMode)
			{
				Cursor.Current = Cursors.WaitCursor;
				bool exclusiveBlock = this.Main.GetExclusiveBlock2(true);
				this.Main.ExitExclusiveBlock2();
				Cursor.Current = Cursors.Default;
				if (!exclusiveBlock)
				{
					flag = false;
				}
				int num = 0;
				if (this.Main.Usb_Key_Access())
				{
					num = 0;
					Thread.Sleep(250);
				}
				else
				{
					this.Main.PasswordInput1.ShowWindow(true);
					num = this.Main.PasswordInput1.AccessMode;
				}
				this.Main.DisplayCurrentUser();
				switch (num)
				{
				case 2:
					this.pnMenu.Enabled = true;
					break;
				default:
					MessageBox.Show("Wrong state in Function btTest_Click!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					this.pnMenu.Enabled = true;
					break;
				case 0:
					Cursor.Current = Cursors.WaitCursor;
					if (flag)
					{
						exclusiveBlock = this.Main.GetExclusiveBlock2(true);
					}
					if (exclusiveBlock)
					{
						this.Main.MenuTest1.ShowWindow();
					}
					else if (!flag)
					{
						this.Main.MenuTest1.ResetWritePermission();
						this.Main.MenuTest1.ShowWindow();
					}
					else
					{
						this.pnMenu.Enabled = true;
					}
					Cursor.Current = Cursors.Default;
					break;
				}
			}
			else
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.pnMenu.Enabled = true;
			}
		}

		private void btRes1_Click(object sender, EventArgs e)
		{
		}

		public void Reconnect()
		{
			this.btReconnect_Click(null, EventArgs.Empty);
		}

		private void btReconnect_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.IsOnlineMode)
			{
				if (this.Main.Browser1.BrowserNavigated)
				{
					if (MessageBox.Show(this.Main.Rm.GetString("MbReconnectToController"), this.Main.Rm.GetString("MbNoConnection"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
					{
						return;
					}
					ProcessStartInfo processStartInfo = new ProcessStartInfo();
					processStartInfo.FileName = "http://" + this.Main.MyIp + "/Visualisation/Visualisation.application";
					processStartInfo.CreateNoWindow = true;
					processStartInfo.WindowStyle = ProcessWindowStyle.Minimized;
					Process.Start(processStartInfo);
					Process.GetCurrentProcess().Kill();
				}
				this.Main.StatusBarText(this.Main.Rm.GetString("ReconnectToController"));
				this.Main.StartupVarConnection();
				this.Main.LevelAssignment1.LoadWSP_ValuesToSettings(true);
				if (this.Main.LoginSuccessfulCompleted)
				{
					this.Main.SendCurrentUserDataToKernel();
					this.Main.Browser1.ResetBrowserSession();
				}
			}
			this.Main.StatusBarText(string.Empty);
			if (this.Main.IsOnlineMode)
			{
				this.Main.WeberLogoImage(2);
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadResults"));
				Cursor.Current = Cursors.WaitCursor;
				if (!this.Main.VC.ReceiveVarBlock(8))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show("Could not receive ResultBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				this.Main.Browser1.ResetBrowserNavigated();
				this.Main.Browser1.ResetBrowserSession();
			}
			else
			{
				this.Main.WeberLogoImage(1);
			}
			this.MenEna();
			this.UpdateValues();
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			this.pnMenu.Enabled = true;
		}

		private void btHandStart_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.Main.UsbKeyQuery();
			if (this.Main.UsbKeyAccessCanceledByUser)
			{
				this.pnMenu.Enabled = true;
			}
			else if (!this.Main.HandStart1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void btExit_Click(object sender, EventArgs e)
		{
			this.Main.Close();
		}

		private void btShowMiniDisplay_Click(object sender, EventArgs e)
		{
			this.Main.ResultMiniDisplay1.ShowWindow();
			this.Main.Hide();
		}

		private void ResultDisplayForm_Activated(object sender, EventArgs e)
		{
			this.checkAndSetColorOfButton(true);
			this.Main.ActivationBrowserGrantedBy = this;
			this.ShowResultDisplaForm();
		}

		private void checkAndSetColorOfButton(bool readFromWSP)
		{
			this.btParameter.ForeColor = this.Main.AdvanceWarning1.GetInfo(readFromWSP);
			if (this.btParameter.ForeColor == Color.Black)
			{
				this.btParameter.ForeColor = this.Main.Maintenance1.GetInfo(out bool _, out int num, out num, out num, readFromWSP);
			}
		}

		public void ShowResultDisplaForm()
		{
			this.MenEna();
			this.pnMenu.Enabled = true;
			this.UpdateValues();
		}

		public void KeyArrived()
		{
			this.MenEna();
		}

		public void KeyRemoved()
		{
			this.MenEna();
		}
	}
}
