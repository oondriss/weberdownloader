using System;
using System.Drawing;
using System.Windows.Forms;

namespace Visualisation
{
	public class DataGrid_Specific_Class : DataGridView
	{
		private int iSortingColumn;

		private ControlCollection controlCollection;

		private ToolTip messageToolTip;

		public DataGrid_Specific_Class(int inhibitSortingColumn, ControlCollection control)
		{
			this.iSortingColumn = inhibitSortingColumn;
			this.controlCollection = control;
			this.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
			base.DataMember = "";
			this.Font = new Font("Arial Unicode MS", 10f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.Location = new Point(0, 0);
			base.Name = "LogGrid";
			base.ReadOnly = true;
			base.RowHeadersVisible = false;
			base.Size = new Size(709, 522);
			base.TabIndex = 8;
			base.AllowUserToOrderColumns = true;
			base.AllowUserToResizeColumns = true;
			base.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			base.MouseHover += this.DataGrid_Specific_Class_MouseHover;
			base.MouseMove += this.DataGrid_Specific_Class_MouseMove;
			this.messageToolTip = new ToolTip();
			this.messageToolTip.ToolTipTitle = "Message Tooltip";
			this.messageToolTip.UseFading = true;
			this.messageToolTip.UseAnimation = true;
			this.messageToolTip.IsBalloon = false;
			this.messageToolTip.ShowAlways = true;
			this.messageToolTip.AutomaticDelay = 500;
			this.messageToolTip.AutoPopDelay = 5000;
			this.messageToolTip.InitialDelay = 500;
			this.messageToolTip.ReshowDelay = 100;
			this.controlCollection.Add(this);
		}

		private void DataGrid_Specific_Class_MouseMove(object sender, MouseEventArgs e)
		{
		}

		private void DataGrid_Specific_Class_MouseHover(object sender, EventArgs e)
		{
		}

		public void Multiline(int cellIndex)
		{
		}

		protected override void OnMouseDown(MouseEventArgs e)
		{
			new Point(e.X, e.Y);
			HitTestInfo hitTestInfo = base.HitTest(e.X, e.Y);
			if (hitTestInfo.ColumnIndex != this.iSortingColumn)
			{
				base.OnMouseDown(e);
			}
		}
	}
}
