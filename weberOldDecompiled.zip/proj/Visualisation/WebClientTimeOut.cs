using System;
using System.Net;

namespace Visualisation
{
	public class WebClientTimeOut : WebClient
	{
		public int TimeOut
		{
			get;
			set;
		}

		protected override WebRequest GetWebRequest(Uri address)
		{
			WebRequest webRequest = base.GetWebRequest(address);
			this.TimeOut = 1000;
			webRequest.Timeout = this.TimeOut;
			return webRequest;
		}
	}
}
