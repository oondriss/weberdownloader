using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class MenuMaintenanceForm : Form
	{
		private MainForm Main;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Container components;

		private Button btAdvanceWarning;

		private Button btMaintenance;

		private Button btComponents;

		private Button bt8;

		private Button bt6;

		private Button bt7;

		public MenuMaintenanceForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.bt6 = new Button();
			this.bt8 = new Button();
			this.btComponents = new Button();
			this.btAdvanceWarning = new Button();
			this.btMaintenance = new Button();
			this.bt7 = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.pnMenu.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.bt6);
			this.pnMenu.Controls.Add(this.bt8);
			this.pnMenu.Controls.Add(this.btComponents);
			this.pnMenu.Controls.Add(this.btAdvanceWarning);
			this.pnMenu.Controls.Add(this.btMaintenance);
			this.pnMenu.Controls.Add(this.bt7);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.bt6.Enabled = false;
			this.bt6.Location = new Point(3, 323);
			this.bt6.Name = "bt6";
			this.bt6.Size = new Size(74, 62);
			this.bt6.TabIndex = 5;
			this.bt8.Enabled = false;
			this.bt8.Location = new Point(3, 451);
			this.bt8.Name = "bt8";
			this.bt8.Size = new Size(74, 62);
			this.bt8.TabIndex = 7;
			this.btComponents.Location = new Point(3, 259);
			this.btComponents.Name = "btComponents";
			this.btComponents.Size = new Size(74, 62);
			this.btComponents.TabIndex = 4;
			this.btComponents.Text = "Komponen- ten- Statistik";
			this.btComponents.Click += this.btComponents_Click;
			this.btAdvanceWarning.Location = new Point(3, 131);
			this.btAdvanceWarning.Name = "btAdvanceWarning";
			this.btAdvanceWarning.Size = new Size(74, 62);
			this.btAdvanceWarning.TabIndex = 2;
			this.btAdvanceWarning.Text = "Vorwarn- werte";
			this.btAdvanceWarning.Click += this.btAdvanceWarning_Click;
			this.btMaintenance.Enabled = false;
			this.btMaintenance.Location = new Point(3, 195);
			this.btMaintenance.Name = "btMaintenance";
			this.btMaintenance.Size = new Size(74, 62);
			this.btMaintenance.TabIndex = 3;
			this.btMaintenance.Text = "---Wartungs- meldungen";
			this.btMaintenance.Click += this.btMaintenance_Click;
			this.bt7.Enabled = false;
			this.bt7.Location = new Point(3, 387);
			this.bt7.Name = "bt7";
			this.bt7.Size = new Size(74, 62);
			this.bt7.TabIndex = 6;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "MenuMaintenanceForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Auswertung/Statistik";
			base.Activated += this.MenuStatisticsForm_Activated;
			this.pnMenu.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public bool ShowWindow()
		{
			this.bt6.Enabled = Settings.Default.IntegratedMachineVisu;
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				base.Show();
				return false;
			}
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadProcessInfo"));
			if (!this.Main.VC.ReceiveVarBlock(15))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive ProcessInfoBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			Cursor.Current = Cursors.Default;
			this.btMaintenance.ForeColor = this.Main.Maintenance1.GetInfo(out bool _, out int _, out int _, out int _, true);
			this.btAdvanceWarning.ForeColor = this.Main.AdvanceWarning1.GetInfo(true);
			this.Main.StatusBarText(string.Empty);
			base.Show();
			this.btAdvanceWarning_Click(null, EventArgs.Empty);
			return true;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MenuMaintenance");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btAdvanceWarning.Text = this.Main.Rm.GetString("btAdvanceWarning");
			this.btComponents.Text = this.Main.Rm.GetString("btComponents");
			this.btMaintenance.Text = "";
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
		}

		public void Back()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_5_Untermenue_Wartung";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_5_Untermenue_Wartung");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btLastResults_Click(object sender, EventArgs e)
		{
		}

		private void btAdvanceWarning_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.AdvanceWarning1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		public void BtMAdvanceWarning_Click()
		{
			this.btAdvanceWarning_Click(null, EventArgs.Empty);
		}

		private void btMaintenance_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.Maintenance1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void btComponents_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.Component1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
		}

		private void MenuStatisticsForm_Activated(object sender, EventArgs e)
		{
			this.btMaintenance.ForeColor = this.Main.Maintenance1.GetInfo(out bool _, out int _, out int _, out int _, false);
			this.btAdvanceWarning.ForeColor = this.Main.AdvanceWarning1.GetInfo(false);
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}
	}
}
