using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class FourStepEditForm : Form
	{
		private MainForm Main;

		private WSP1_VarComm.FourProgStruct SD4;

		private int PNum;

		private int stepIndex;

		private bool IsInitializeMode;

		private Panel pnMenu;

		private Button btDiscard;

		private Button btApply;

		private Button btPrevious;

		private Button btNext;

		private Button btHelp;

		private Button btBack;

		private Container components;

		private Button bt3;

		private Label lbProgNum;

		private Label lbProgName;

		private Button btCancel;

		private CheckBox chBEnable1;

		private Label lbEnable;

		private Label lbType;

		private Label lbValue;

		private Label lbStep;

		private ComboBox cBType1;

		private NumberEdit1 nEValue1Min;

		private ComboBox cBStep1;

		private GroupBox gBTitel;

		private ComboBox cBStep7;

		private NumberEdit1 nEValue7Min;

		private ComboBox cBType7;

		private CheckBox chBEnable7;

		private ComboBox cBStep6;

		private NumberEdit1 nEValue6Min;

		private ComboBox cBType6;

		private CheckBox chBEnable6;

		private ComboBox cBStep5;

		private NumberEdit1 nEValue5Min;

		private ComboBox cBType5;

		private CheckBox chBEnable5;

		private ComboBox cBStep4;

		private NumberEdit1 nEValue4Min;

		private ComboBox cBType4;

		private CheckBox chBEnable4;

		private ComboBox cBStep3;

		private NumberEdit1 nEValue3Min;

		private ComboBox cBType3;

		private CheckBox chBEnable3;

		private ComboBox cBStep2;

		private NumberEdit1 nEValue2Min;

		private ComboBox cBType2;

		private CheckBox chBEnable2;

		private Label lbUnit7;

		private Label lbUnit6;

		private Label lbUnit5;

		private Label lbUnit4;

		private Label lbUnit3;

		private Label lbUnit2;

		private Label lbUnit1;

		private Label label5;

		private Label label6;

		private Label label7;

		private Label label4;

		private Label label3;

		private Label label2;

		private Label label1;

		private NumberEdit1 nEValue7Max;

		private NumberEdit1 nEValue6Max;

		private NumberEdit1 nEValue5Max;

		private NumberEdit1 nEValue4Max;

		private NumberEdit1 nEValue3Max;

		private NumberEdit1 nEValue2Max;

		private NumberEdit1 nEValue1Max;

		private Label label14;

		private Label label13;

		private Label label12;

		private Label label11;

		private Label label10;

		private Label label9;

		private Label label8;

		private PictureBox pictureBoxTitle;

		private bool bCanceled;

		private Font myFont = new Font("Arial Unicode MS", 11f, FontStyle.Regular);

		private int[] recentSelectedStep = new int[7];

		public bool WasCanceled
		{
			get
			{
				bool result = this.bCanceled;
				this.bCanceled = false;
				return result;
			}
		}

		public FourStepEditForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.PNum = 0;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btCancel = new Button();
			this.btDiscard = new Button();
			this.btApply = new Button();
			this.btPrevious = new Button();
			this.btNext = new Button();
			this.bt3 = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.lbProgNum = new Label();
			this.lbProgName = new Label();
			this.chBEnable1 = new CheckBox();
			this.lbEnable = new Label();
			this.lbType = new Label();
			this.lbValue = new Label();
			this.lbStep = new Label();
			this.cBType1 = new ComboBox();
			this.nEValue1Min = new NumberEdit1();
			this.cBStep1 = new ComboBox();
			this.gBTitel = new GroupBox();
			this.label14 = new Label();
			this.label13 = new Label();
			this.label12 = new Label();
			this.label11 = new Label();
			this.label10 = new Label();
			this.label9 = new Label();
			this.label8 = new Label();
			this.label5 = new Label();
			this.label6 = new Label();
			this.label7 = new Label();
			this.label4 = new Label();
			this.label3 = new Label();
			this.label2 = new Label();
			this.label1 = new Label();
			this.nEValue7Max = new NumberEdit1();
			this.nEValue6Max = new NumberEdit1();
			this.nEValue5Max = new NumberEdit1();
			this.nEValue4Max = new NumberEdit1();
			this.nEValue3Max = new NumberEdit1();
			this.nEValue2Max = new NumberEdit1();
			this.nEValue1Max = new NumberEdit1();
			this.lbUnit7 = new Label();
			this.lbUnit6 = new Label();
			this.lbUnit5 = new Label();
			this.lbUnit4 = new Label();
			this.lbUnit3 = new Label();
			this.lbUnit2 = new Label();
			this.lbUnit1 = new Label();
			this.cBStep7 = new ComboBox();
			this.nEValue7Min = new NumberEdit1();
			this.cBType7 = new ComboBox();
			this.chBEnable7 = new CheckBox();
			this.cBStep6 = new ComboBox();
			this.nEValue6Min = new NumberEdit1();
			this.cBType6 = new ComboBox();
			this.chBEnable6 = new CheckBox();
			this.cBStep5 = new ComboBox();
			this.nEValue5Min = new NumberEdit1();
			this.cBType5 = new ComboBox();
			this.chBEnable5 = new CheckBox();
			this.cBStep4 = new ComboBox();
			this.nEValue4Min = new NumberEdit1();
			this.cBType4 = new ComboBox();
			this.chBEnable4 = new CheckBox();
			this.cBStep3 = new ComboBox();
			this.nEValue3Min = new NumberEdit1();
			this.cBType3 = new ComboBox();
			this.chBEnable3 = new CheckBox();
			this.cBStep2 = new ComboBox();
			this.nEValue2Min = new NumberEdit1();
			this.cBType2 = new ComboBox();
			this.chBEnable2 = new CheckBox();
			this.pictureBoxTitle = new PictureBox();
			this.pnMenu.SuspendLayout();
			this.gBTitel.SuspendLayout();
			((ISupportInitialize)this.pictureBoxTitle).BeginInit();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.btDiscard);
			this.pnMenu.Controls.Add(this.btApply);
			this.pnMenu.Controls.Add(this.btPrevious);
			this.pnMenu.Controls.Add(this.btNext);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 7;
			this.btCancel.Text = "Abbruch";
			this.btCancel.Click += this.btCancel_Click;
			this.btDiscard.Enabled = false;
			this.btDiscard.Location = new Point(3, 387);
			this.btDiscard.Name = "btDiscard";
			this.btDiscard.Size = new Size(74, 62);
			this.btDiscard.TabIndex = 6;
			this.btApply.Enabled = false;
			this.btApply.Location = new Point(3, 323);
			this.btApply.Name = "btApply";
			this.btApply.Size = new Size(74, 62);
			this.btApply.TabIndex = 5;
			this.btPrevious.Location = new Point(3, 259);
			this.btPrevious.Name = "btPrevious";
			this.btPrevious.Size = new Size(74, 62);
			this.btPrevious.TabIndex = 4;
			this.btPrevious.Text = "Vorherige";
			this.btPrevious.Click += this.btPrevious_Click;
			this.btNext.Location = new Point(3, 195);
			this.btNext.Name = "btNext";
			this.btNext.Size = new Size(74, 62);
			this.btNext.TabIndex = 3;
			this.btNext.Text = "Nächste";
			this.btNext.Click += this.btNext_Click;
			this.bt3.Enabled = false;
			this.bt3.Location = new Point(3, 131);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 2;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btHelp.Enter += this.Start_Input;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Fertig";
			this.btBack.Click += this.btBack_Click;
			this.btBack.Enter += this.Start_Input;
			this.lbProgNum.BorderStyle = BorderStyle.Fixed3D;
			this.lbProgNum.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgNum.Location = new Point(22, 32);
			this.lbProgNum.Name = "lbProgNum";
			this.lbProgNum.Size = new Size(95, 23);
			this.lbProgNum.TabIndex = 17;
			this.lbProgNum.Text = "Prog. 1023";
			this.lbProgNum.TextAlign = ContentAlignment.MiddleLeft;
			this.lbProgName.BorderStyle = BorderStyle.Fixed3D;
			this.lbProgName.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbProgName.Location = new Point(128, 32);
			this.lbProgName.Name = "lbProgName";
			this.lbProgName.Size = new Size(248, 23);
			this.lbProgName.TabIndex = 16;
			this.lbProgName.Text = "Name";
			this.lbProgName.TextAlign = ContentAlignment.MiddleLeft;
			this.chBEnable1.AutoSize = true;
			this.chBEnable1.Location = new Point(48, 66);
			this.chBEnable1.Name = "chBEnable1";
			this.chBEnable1.Size = new Size(15, 14);
			this.chBEnable1.TabIndex = 0;
			this.chBEnable1.UseVisualStyleBackColor = true;
			this.chBEnable1.CheckedChanged += this.chBEnableX_CheckedChanged;
			this.lbEnable.AutoSize = true;
			this.lbEnable.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.lbEnable.Location = new Point(32, 32);
			this.lbEnable.Name = "lbEnable";
			this.lbEnable.Size = new Size(43, 18);
			this.lbEnable.TabIndex = 1;
			this.lbEnable.Text = "Aktiv";
			this.lbType.AutoSize = true;
			this.lbType.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.lbType.Location = new Point(115, 32);
			this.lbType.Name = "lbType";
			this.lbType.Size = new Size(33, 18);
			this.lbType.TabIndex = 2;
			this.lbType.Text = "Typ";
			this.lbValue.AutoSize = true;
			this.lbValue.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.lbValue.Location = new Point(295, 32);
			this.lbValue.Name = "lbValue";
			this.lbValue.Size = new Size(96, 18);
			this.lbValue.TabIndex = 3;
			this.lbValue.Text = "Wertebereich";
			this.lbValue.Click += this.lbValue_Click;
			this.lbValue.Enter += this.Start_Input;
			this.lbValue.MouseClick += this.StartInput;
			this.lbStep.AutoSize = true;
			this.lbStep.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.lbStep.Location = new Point(520, 32);
			this.lbStep.Name = "lbStep";
			this.lbStep.Size = new Size(160, 18);
			this.lbStep.TabIndex = 4;
			this.lbStep.Text = "Stufe in der Steuerung";
			this.cBType1.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBType1.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBType1.FormattingEnabled = true;
			this.cBType1.Location = new Point(74, 60);
			this.cBType1.Name = "cBType1";
			this.cBType1.Size = new Size(170, 26);
			this.cBType1.TabIndex = 5;
			this.cBType1.SelectedIndexChanged += this.cBTypeX_SelectedIndexChanged;
			this.nEValue1Min.BackColor = Color.White;
			this.nEValue1Min.DecimalNum = 3;
			this.nEValue1Min.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue1Min.ForeColor = SystemColors.ControlText;
			this.nEValue1Min.Location = new Point(255, 60);
			this.nEValue1Min.MaxValue = 10f;
			this.nEValue1Min.MinValue = 0f;
			this.nEValue1Min.Name = "nEValue1Min";
			this.nEValue1Min.Size = new Size(80, 28);
			this.nEValue1Min.TabIndex = 6;
			this.nEValue1Min.Text = "2,000";
			this.nEValue1Min.TextAlign = HorizontalAlignment.Right;
			this.nEValue1Min.Value = 2f;
			this.nEValue1Min.MouseClick += this.StartInput;
			this.nEValue1Min.TextChanged += this.settingsChanged;
			this.nEValue1Min.Enter += this.Start_Input;
			this.cBStep1.DrawMode = DrawMode.OwnerDrawFixed;
			this.cBStep1.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBStep1.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBStep1.FormattingEnabled = true;
			this.cBStep1.Location = new Point(515, 60);
			this.cBStep1.Name = "cBStep1";
			this.cBStep1.Size = new Size(156, 26);
			this.cBStep1.TabIndex = 7;
			this.cBStep1.DrawItem += this.cBStepX_DrawItem;
			this.cBStep1.SelectedIndexChanged += this.cBStepX_SelectedIndexChanged;
			this.gBTitel.Controls.Add(this.label14);
			this.gBTitel.Controls.Add(this.label13);
			this.gBTitel.Controls.Add(this.label12);
			this.gBTitel.Controls.Add(this.label11);
			this.gBTitel.Controls.Add(this.label10);
			this.gBTitel.Controls.Add(this.label9);
			this.gBTitel.Controls.Add(this.label8);
			this.gBTitel.Controls.Add(this.label5);
			this.gBTitel.Controls.Add(this.label6);
			this.gBTitel.Controls.Add(this.label7);
			this.gBTitel.Controls.Add(this.label4);
			this.gBTitel.Controls.Add(this.label3);
			this.gBTitel.Controls.Add(this.label2);
			this.gBTitel.Controls.Add(this.label1);
			this.gBTitel.Controls.Add(this.nEValue7Max);
			this.gBTitel.Controls.Add(this.nEValue6Max);
			this.gBTitel.Controls.Add(this.nEValue5Max);
			this.gBTitel.Controls.Add(this.nEValue4Max);
			this.gBTitel.Controls.Add(this.nEValue3Max);
			this.gBTitel.Controls.Add(this.nEValue2Max);
			this.gBTitel.Controls.Add(this.nEValue1Max);
			this.gBTitel.Controls.Add(this.lbUnit7);
			this.gBTitel.Controls.Add(this.lbUnit6);
			this.gBTitel.Controls.Add(this.lbUnit5);
			this.gBTitel.Controls.Add(this.lbUnit4);
			this.gBTitel.Controls.Add(this.lbUnit3);
			this.gBTitel.Controls.Add(this.lbUnit2);
			this.gBTitel.Controls.Add(this.lbUnit1);
			this.gBTitel.Controls.Add(this.cBStep7);
			this.gBTitel.Controls.Add(this.nEValue7Min);
			this.gBTitel.Controls.Add(this.cBType7);
			this.gBTitel.Controls.Add(this.chBEnable7);
			this.gBTitel.Controls.Add(this.cBStep6);
			this.gBTitel.Controls.Add(this.nEValue6Min);
			this.gBTitel.Controls.Add(this.cBType6);
			this.gBTitel.Controls.Add(this.chBEnable6);
			this.gBTitel.Controls.Add(this.cBStep5);
			this.gBTitel.Controls.Add(this.nEValue5Min);
			this.gBTitel.Controls.Add(this.cBType5);
			this.gBTitel.Controls.Add(this.chBEnable5);
			this.gBTitel.Controls.Add(this.cBStep4);
			this.gBTitel.Controls.Add(this.nEValue4Min);
			this.gBTitel.Controls.Add(this.cBType4);
			this.gBTitel.Controls.Add(this.chBEnable4);
			this.gBTitel.Controls.Add(this.cBStep3);
			this.gBTitel.Controls.Add(this.nEValue3Min);
			this.gBTitel.Controls.Add(this.cBType3);
			this.gBTitel.Controls.Add(this.chBEnable3);
			this.gBTitel.Controls.Add(this.cBStep2);
			this.gBTitel.Controls.Add(this.nEValue2Min);
			this.gBTitel.Controls.Add(this.cBType2);
			this.gBTitel.Controls.Add(this.chBEnable2);
			this.gBTitel.Controls.Add(this.cBStep1);
			this.gBTitel.Controls.Add(this.nEValue1Min);
			this.gBTitel.Controls.Add(this.lbStep);
			this.gBTitel.Controls.Add(this.cBType1);
			this.gBTitel.Controls.Add(this.lbValue);
			this.gBTitel.Controls.Add(this.lbType);
			this.gBTitel.Controls.Add(this.lbEnable);
			this.gBTitel.Controls.Add(this.chBEnable1);
			this.gBTitel.Font = new Font("Arial Unicode MS", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.gBTitel.Location = new Point(9, 94);
			this.gBTitel.Name = "gBTitel";
			this.gBTitel.Size = new Size(688, 416);
			this.gBTitel.TabIndex = 2;
			this.gBTitel.TabStop = false;
			this.gBTitel.Text = "Titel";
			this.label14.AutoSize = true;
			this.label14.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.label14.Location = new Point(22, 302);
			this.label14.Name = "label14";
			this.label14.Size = new Size(16, 18);
			this.label14.TabIndex = 59;
			this.label14.Text = "7";
			this.label13.AutoSize = true;
			this.label13.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.label13.Location = new Point(22, 263);
			this.label13.Name = "label13";
			this.label13.Size = new Size(16, 18);
			this.label13.TabIndex = 58;
			this.label13.Text = "6";
			this.label12.AutoSize = true;
			this.label12.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.label12.Location = new Point(22, 223);
			this.label12.Name = "label12";
			this.label12.Size = new Size(16, 18);
			this.label12.TabIndex = 57;
			this.label12.Text = "5";
			this.label11.AutoSize = true;
			this.label11.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.label11.Location = new Point(22, 184);
			this.label11.Name = "label11";
			this.label11.Size = new Size(16, 18);
			this.label11.TabIndex = 56;
			this.label11.Text = "4";
			this.label10.AutoSize = true;
			this.label10.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.label10.Location = new Point(22, 143);
			this.label10.Name = "label10";
			this.label10.Size = new Size(16, 18);
			this.label10.TabIndex = 55;
			this.label10.Text = "3";
			this.label9.AutoSize = true;
			this.label9.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.label9.Location = new Point(22, 102);
			this.label9.Name = "label9";
			this.label9.Size = new Size(16, 18);
			this.label9.TabIndex = 54;
			this.label9.Text = "2";
			this.label8.AutoSize = true;
			this.label8.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.label8.Location = new Point(22, 63);
			this.label8.Name = "label8";
			this.label8.Size = new Size(16, 18);
			this.label8.TabIndex = 53;
			this.label8.Text = "1";
			this.label5.AutoSize = true;
			this.label5.Location = new Point(338, 300);
			this.label5.Name = "label5";
			this.label5.Size = new Size(25, 21);
			this.label5.TabIndex = 52;
			this.label5.Text = "...";
			this.label6.AutoSize = true;
			this.label6.Location = new Point(338, 260);
			this.label6.Name = "label6";
			this.label6.Size = new Size(25, 21);
			this.label6.TabIndex = 51;
			this.label6.Text = "...";
			this.label7.AutoSize = true;
			this.label7.Location = new Point(338, 222);
			this.label7.Name = "label7";
			this.label7.Size = new Size(25, 21);
			this.label7.TabIndex = 50;
			this.label7.Text = "...";
			this.label4.AutoSize = true;
			this.label4.Location = new Point(338, 180);
			this.label4.Name = "label4";
			this.label4.Size = new Size(25, 21);
			this.label4.TabIndex = 49;
			this.label4.Text = "...";
			this.label3.AutoSize = true;
			this.label3.Location = new Point(338, 140);
			this.label3.Name = "label3";
			this.label3.Size = new Size(25, 21);
			this.label3.TabIndex = 48;
			this.label3.Text = "...";
			this.label2.AutoSize = true;
			this.label2.Location = new Point(338, 100);
			this.label2.Name = "label2";
			this.label2.Size = new Size(25, 21);
			this.label2.TabIndex = 47;
			this.label2.Text = "...";
			this.label1.AutoSize = true;
			this.label1.Location = new Point(338, 62);
			this.label1.Name = "label1";
			this.label1.Size = new Size(25, 21);
			this.label1.TabIndex = 46;
			this.label1.Text = "...";
			this.nEValue7Max.BackColor = Color.White;
			this.nEValue7Max.DecimalNum = 3;
			this.nEValue7Max.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue7Max.ForeColor = SystemColors.ControlText;
			this.nEValue7Max.Location = new Point(366, 300);
			this.nEValue7Max.MaxValue = 10f;
			this.nEValue7Max.MinValue = 0f;
			this.nEValue7Max.Name = "nEValue7Max";
			this.nEValue7Max.Size = new Size(80, 28);
			this.nEValue7Max.TabIndex = 45;
			this.nEValue7Max.Text = "2,000";
			this.nEValue7Max.TextAlign = HorizontalAlignment.Right;
			this.nEValue7Max.Value = 2f;
			this.nEValue7Max.MouseClick += this.StartInput;
			this.nEValue7Max.TextChanged += this.settingsChanged;
			this.nEValue7Max.Enter += this.Start_Input;
			this.nEValue6Max.BackColor = Color.White;
			this.nEValue6Max.DecimalNum = 3;
			this.nEValue6Max.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue6Max.ForeColor = SystemColors.ControlText;
			this.nEValue6Max.Location = new Point(366, 260);
			this.nEValue6Max.MaxValue = 10f;
			this.nEValue6Max.MinValue = 0f;
			this.nEValue6Max.Name = "nEValue6Max";
			this.nEValue6Max.Size = new Size(80, 28);
			this.nEValue6Max.TabIndex = 44;
			this.nEValue6Max.Text = "2,000";
			this.nEValue6Max.TextAlign = HorizontalAlignment.Right;
			this.nEValue6Max.Value = 2f;
			this.nEValue6Max.MouseClick += this.StartInput;
			this.nEValue6Max.TextChanged += this.settingsChanged;
			this.nEValue6Max.Enter += this.Start_Input;
			this.nEValue5Max.BackColor = Color.White;
			this.nEValue5Max.DecimalNum = 3;
			this.nEValue5Max.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue5Max.ForeColor = SystemColors.ControlText;
			this.nEValue5Max.Location = new Point(366, 220);
			this.nEValue5Max.MaxValue = 10f;
			this.nEValue5Max.MinValue = 0f;
			this.nEValue5Max.Name = "nEValue5Max";
			this.nEValue5Max.Size = new Size(80, 28);
			this.nEValue5Max.TabIndex = 43;
			this.nEValue5Max.Text = "2,000";
			this.nEValue5Max.TextAlign = HorizontalAlignment.Right;
			this.nEValue5Max.Value = 2f;
			this.nEValue5Max.MouseClick += this.StartInput;
			this.nEValue5Max.TextChanged += this.settingsChanged;
			this.nEValue5Max.Enter += this.Start_Input;
			this.nEValue4Max.BackColor = Color.White;
			this.nEValue4Max.DecimalNum = 3;
			this.nEValue4Max.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue4Max.ForeColor = SystemColors.ControlText;
			this.nEValue4Max.Location = new Point(366, 180);
			this.nEValue4Max.MaxValue = 10f;
			this.nEValue4Max.MinValue = 0f;
			this.nEValue4Max.Name = "nEValue4Max";
			this.nEValue4Max.Size = new Size(80, 28);
			this.nEValue4Max.TabIndex = 42;
			this.nEValue4Max.Text = "2,000";
			this.nEValue4Max.TextAlign = HorizontalAlignment.Right;
			this.nEValue4Max.Value = 2f;
			this.nEValue4Max.MouseClick += this.StartInput;
			this.nEValue4Max.TextChanged += this.settingsChanged;
			this.nEValue4Max.Enter += this.Start_Input;
			this.nEValue3Max.BackColor = Color.White;
			this.nEValue3Max.DecimalNum = 3;
			this.nEValue3Max.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue3Max.ForeColor = SystemColors.ControlText;
			this.nEValue3Max.Location = new Point(366, 140);
			this.nEValue3Max.MaxValue = 10f;
			this.nEValue3Max.MinValue = 0f;
			this.nEValue3Max.Name = "nEValue3Max";
			this.nEValue3Max.Size = new Size(80, 28);
			this.nEValue3Max.TabIndex = 41;
			this.nEValue3Max.Text = "2,000";
			this.nEValue3Max.TextAlign = HorizontalAlignment.Right;
			this.nEValue3Max.Value = 2f;
			this.nEValue3Max.MouseClick += this.StartInput;
			this.nEValue3Max.TextChanged += this.settingsChanged;
			this.nEValue3Max.Enter += this.Start_Input;
			this.nEValue2Max.BackColor = Color.White;
			this.nEValue2Max.DecimalNum = 3;
			this.nEValue2Max.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue2Max.ForeColor = SystemColors.ControlText;
			this.nEValue2Max.Location = new Point(366, 100);
			this.nEValue2Max.MaxValue = 10f;
			this.nEValue2Max.MinValue = 0f;
			this.nEValue2Max.Name = "nEValue2Max";
			this.nEValue2Max.Size = new Size(80, 28);
			this.nEValue2Max.TabIndex = 40;
			this.nEValue2Max.Text = "2,000";
			this.nEValue2Max.TextAlign = HorizontalAlignment.Right;
			this.nEValue2Max.Value = 2f;
			this.nEValue2Max.MouseClick += this.StartInput;
			this.nEValue2Max.TextChanged += this.settingsChanged;
			this.nEValue2Max.Enter += this.Start_Input;
			this.nEValue1Max.BackColor = Color.White;
			this.nEValue1Max.DecimalNum = 3;
			this.nEValue1Max.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue1Max.ForeColor = SystemColors.ControlText;
			this.nEValue1Max.Location = new Point(366, 60);
			this.nEValue1Max.MaxValue = 10f;
			this.nEValue1Max.MinValue = 0f;
			this.nEValue1Max.Name = "nEValue1Max";
			this.nEValue1Max.Size = new Size(80, 28);
			this.nEValue1Max.TabIndex = 39;
			this.nEValue1Max.Text = "2,000";
			this.nEValue1Max.TextAlign = HorizontalAlignment.Right;
			this.nEValue1Max.Value = 2f;
			this.nEValue1Max.MouseClick += this.StartInput;
			this.nEValue1Max.TextChanged += this.settingsChanged;
			this.nEValue1Max.Enter += this.Start_Input;
			this.lbUnit7.AutoSize = true;
			this.lbUnit7.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnit7.Location = new Point(456, 303);
			this.lbUnit7.Name = "lbUnit7";
			this.lbUnit7.Size = new Size(52, 21);
			this.lbUnit7.TabIndex = 38;
			this.lbUnit7.Text = "label1";
			this.lbUnit6.AutoSize = true;
			this.lbUnit6.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnit6.Location = new Point(456, 266);
			this.lbUnit6.Name = "lbUnit6";
			this.lbUnit6.Size = new Size(52, 21);
			this.lbUnit6.TabIndex = 37;
			this.lbUnit6.Text = "label1";
			this.lbUnit5.AutoSize = true;
			this.lbUnit5.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnit5.Location = new Point(456, 227);
			this.lbUnit5.Name = "lbUnit5";
			this.lbUnit5.Size = new Size(52, 21);
			this.lbUnit5.TabIndex = 36;
			this.lbUnit5.Text = "label1";
			this.lbUnit4.AutoSize = true;
			this.lbUnit4.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnit4.Location = new Point(456, 186);
			this.lbUnit4.Name = "lbUnit4";
			this.lbUnit4.Size = new Size(52, 21);
			this.lbUnit4.TabIndex = 35;
			this.lbUnit4.Text = "label1";
			this.lbUnit3.AutoSize = true;
			this.lbUnit3.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnit3.Location = new Point(456, 146);
			this.lbUnit3.Name = "lbUnit3";
			this.lbUnit3.Size = new Size(52, 21);
			this.lbUnit3.TabIndex = 34;
			this.lbUnit3.Text = "label1";
			this.lbUnit2.AutoSize = true;
			this.lbUnit2.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnit2.Location = new Point(456, 103);
			this.lbUnit2.Name = "lbUnit2";
			this.lbUnit2.Size = new Size(52, 21);
			this.lbUnit2.TabIndex = 33;
			this.lbUnit2.Text = "label1";
			this.lbUnit1.AutoSize = true;
			this.lbUnit1.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.lbUnit1.Location = new Point(456, 63);
			this.lbUnit1.Name = "lbUnit1";
			this.lbUnit1.Size = new Size(52, 21);
			this.lbUnit1.TabIndex = 32;
			this.lbUnit1.Text = "label1";
			this.cBStep7.DrawMode = DrawMode.OwnerDrawFixed;
			this.cBStep7.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBStep7.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBStep7.FormattingEnabled = true;
			this.cBStep7.Location = new Point(515, 300);
			this.cBStep7.Name = "cBStep7";
			this.cBStep7.Size = new Size(156, 26);
			this.cBStep7.TabIndex = 31;
			this.cBStep7.DrawItem += this.cBStepX_DrawItem;
			this.cBStep7.SelectedIndexChanged += this.cBStepX_SelectedIndexChanged;
			this.nEValue7Min.BackColor = Color.White;
			this.nEValue7Min.DecimalNum = 3;
			this.nEValue7Min.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue7Min.ForeColor = SystemColors.ControlText;
			this.nEValue7Min.Location = new Point(255, 300);
			this.nEValue7Min.MaxValue = 10f;
			this.nEValue7Min.MinValue = 0f;
			this.nEValue7Min.Name = "nEValue7Min";
			this.nEValue7Min.Size = new Size(80, 28);
			this.nEValue7Min.TabIndex = 30;
			this.nEValue7Min.Text = "2,000";
			this.nEValue7Min.TextAlign = HorizontalAlignment.Right;
			this.nEValue7Min.Value = 2f;
			this.nEValue7Min.MouseClick += this.StartInput;
			this.nEValue7Min.TextChanged += this.settingsChanged;
			this.nEValue7Min.Enter += this.Start_Input;
			this.cBType7.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBType7.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBType7.FormattingEnabled = true;
			this.cBType7.Location = new Point(74, 300);
			this.cBType7.Name = "cBType7";
			this.cBType7.Size = new Size(170, 26);
			this.cBType7.TabIndex = 29;
			this.cBType7.SelectedIndexChanged += this.cBTypeX_SelectedIndexChanged;
			this.chBEnable7.AutoSize = true;
			this.chBEnable7.Location = new Point(48, 306);
			this.chBEnable7.Name = "chBEnable7";
			this.chBEnable7.Size = new Size(15, 14);
			this.chBEnable7.TabIndex = 28;
			this.chBEnable7.UseVisualStyleBackColor = true;
			this.chBEnable7.CheckedChanged += this.chBEnableX_CheckedChanged;
			this.cBStep6.DrawMode = DrawMode.OwnerDrawFixed;
			this.cBStep6.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBStep6.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBStep6.FormattingEnabled = true;
			this.cBStep6.Location = new Point(515, 260);
			this.cBStep6.Name = "cBStep6";
			this.cBStep6.Size = new Size(156, 26);
			this.cBStep6.TabIndex = 27;
			this.cBStep6.DrawItem += this.cBStepX_DrawItem;
			this.cBStep6.SelectedIndexChanged += this.cBStepX_SelectedIndexChanged;
			this.nEValue6Min.BackColor = Color.White;
			this.nEValue6Min.DecimalNum = 3;
			this.nEValue6Min.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue6Min.ForeColor = SystemColors.ControlText;
			this.nEValue6Min.Location = new Point(255, 260);
			this.nEValue6Min.MaxValue = 10f;
			this.nEValue6Min.MinValue = 0f;
			this.nEValue6Min.Name = "nEValue6Min";
			this.nEValue6Min.Size = new Size(80, 28);
			this.nEValue6Min.TabIndex = 26;
			this.nEValue6Min.Text = "2,000";
			this.nEValue6Min.TextAlign = HorizontalAlignment.Right;
			this.nEValue6Min.Value = 2f;
			this.nEValue6Min.MouseClick += this.StartInput;
			this.nEValue6Min.TextChanged += this.settingsChanged;
			this.nEValue6Min.Enter += this.Start_Input;
			this.cBType6.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBType6.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBType6.FormattingEnabled = true;
			this.cBType6.Location = new Point(74, 260);
			this.cBType6.Name = "cBType6";
			this.cBType6.Size = new Size(170, 26);
			this.cBType6.TabIndex = 25;
			this.cBType6.SelectedIndexChanged += this.cBTypeX_SelectedIndexChanged;
			this.chBEnable6.AutoSize = true;
			this.chBEnable6.Location = new Point(48, 266);
			this.chBEnable6.Name = "chBEnable6";
			this.chBEnable6.Size = new Size(15, 14);
			this.chBEnable6.TabIndex = 24;
			this.chBEnable6.UseVisualStyleBackColor = true;
			this.chBEnable6.CheckedChanged += this.chBEnableX_CheckedChanged;
			this.cBStep5.DrawMode = DrawMode.OwnerDrawFixed;
			this.cBStep5.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBStep5.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBStep5.FormattingEnabled = true;
			this.cBStep5.Location = new Point(515, 220);
			this.cBStep5.Name = "cBStep5";
			this.cBStep5.Size = new Size(156, 26);
			this.cBStep5.TabIndex = 23;
			this.cBStep5.DrawItem += this.cBStepX_DrawItem;
			this.cBStep5.SelectedIndexChanged += this.cBStepX_SelectedIndexChanged;
			this.nEValue5Min.BackColor = Color.White;
			this.nEValue5Min.DecimalNum = 3;
			this.nEValue5Min.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue5Min.ForeColor = SystemColors.ControlText;
			this.nEValue5Min.Location = new Point(255, 220);
			this.nEValue5Min.MaxValue = 10f;
			this.nEValue5Min.MinValue = 0f;
			this.nEValue5Min.Name = "nEValue5Min";
			this.nEValue5Min.Size = new Size(80, 28);
			this.nEValue5Min.TabIndex = 22;
			this.nEValue5Min.Text = "2,000";
			this.nEValue5Min.TextAlign = HorizontalAlignment.Right;
			this.nEValue5Min.Value = 2f;
			this.nEValue5Min.MouseClick += this.StartInput;
			this.nEValue5Min.TextChanged += this.settingsChanged;
			this.nEValue5Min.Enter += this.Start_Input;
			this.cBType5.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBType5.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBType5.FormattingEnabled = true;
			this.cBType5.Location = new Point(74, 220);
			this.cBType5.Name = "cBType5";
			this.cBType5.Size = new Size(170, 26);
			this.cBType5.TabIndex = 21;
			this.cBType5.SelectedIndexChanged += this.cBTypeX_SelectedIndexChanged;
			this.chBEnable5.AutoSize = true;
			this.chBEnable5.Location = new Point(48, 226);
			this.chBEnable5.Name = "chBEnable5";
			this.chBEnable5.Size = new Size(15, 14);
			this.chBEnable5.TabIndex = 20;
			this.chBEnable5.UseVisualStyleBackColor = true;
			this.chBEnable5.CheckedChanged += this.chBEnableX_CheckedChanged;
			this.cBStep4.DrawMode = DrawMode.OwnerDrawFixed;
			this.cBStep4.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBStep4.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBStep4.FormattingEnabled = true;
			this.cBStep4.Location = new Point(515, 180);
			this.cBStep4.Name = "cBStep4";
			this.cBStep4.Size = new Size(156, 26);
			this.cBStep4.TabIndex = 19;
			this.cBStep4.DrawItem += this.cBStepX_DrawItem;
			this.cBStep4.SelectedIndexChanged += this.cBStepX_SelectedIndexChanged;
			this.nEValue4Min.BackColor = Color.White;
			this.nEValue4Min.DecimalNum = 3;
			this.nEValue4Min.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue4Min.ForeColor = SystemColors.ControlText;
			this.nEValue4Min.Location = new Point(255, 180);
			this.nEValue4Min.MaxValue = 10f;
			this.nEValue4Min.MinValue = 0f;
			this.nEValue4Min.Name = "nEValue4Min";
			this.nEValue4Min.Size = new Size(80, 28);
			this.nEValue4Min.TabIndex = 18;
			this.nEValue4Min.Text = "2,000";
			this.nEValue4Min.TextAlign = HorizontalAlignment.Right;
			this.nEValue4Min.Value = 2f;
			this.nEValue4Min.MouseClick += this.StartInput;
			this.nEValue4Min.TextChanged += this.settingsChanged;
			this.nEValue4Min.Enter += this.Start_Input;
			this.cBType4.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBType4.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBType4.FormattingEnabled = true;
			this.cBType4.Location = new Point(74, 180);
			this.cBType4.Name = "cBType4";
			this.cBType4.Size = new Size(170, 26);
			this.cBType4.TabIndex = 17;
			this.cBType4.SelectedIndexChanged += this.cBTypeX_SelectedIndexChanged;
			this.chBEnable4.AutoSize = true;
			this.chBEnable4.Location = new Point(48, 186);
			this.chBEnable4.Name = "chBEnable4";
			this.chBEnable4.Size = new Size(15, 14);
			this.chBEnable4.TabIndex = 16;
			this.chBEnable4.UseVisualStyleBackColor = true;
			this.chBEnable4.CheckedChanged += this.chBEnableX_CheckedChanged;
			this.cBStep3.DrawMode = DrawMode.OwnerDrawFixed;
			this.cBStep3.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBStep3.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBStep3.FormattingEnabled = true;
			this.cBStep3.Location = new Point(515, 140);
			this.cBStep3.Name = "cBStep3";
			this.cBStep3.Size = new Size(156, 26);
			this.cBStep3.TabIndex = 15;
			this.cBStep3.DrawItem += this.cBStepX_DrawItem;
			this.cBStep3.SelectedIndexChanged += this.cBStepX_SelectedIndexChanged;
			this.nEValue3Min.BackColor = Color.White;
			this.nEValue3Min.DecimalNum = 3;
			this.nEValue3Min.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue3Min.ForeColor = SystemColors.ControlText;
			this.nEValue3Min.Location = new Point(255, 140);
			this.nEValue3Min.MaxValue = 10f;
			this.nEValue3Min.MinValue = 0f;
			this.nEValue3Min.Name = "nEValue3Min";
			this.nEValue3Min.Size = new Size(80, 28);
			this.nEValue3Min.TabIndex = 14;
			this.nEValue3Min.Text = "2,000";
			this.nEValue3Min.TextAlign = HorizontalAlignment.Right;
			this.nEValue3Min.Value = 2f;
			this.nEValue3Min.MouseClick += this.StartInput;
			this.nEValue3Min.TextChanged += this.settingsChanged;
			this.nEValue3Min.Enter += this.Start_Input;
			this.cBType3.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBType3.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBType3.FormattingEnabled = true;
			this.cBType3.Location = new Point(74, 140);
			this.cBType3.Name = "cBType3";
			this.cBType3.Size = new Size(170, 26);
			this.cBType3.TabIndex = 13;
			this.cBType3.SelectedIndexChanged += this.cBTypeX_SelectedIndexChanged;
			this.chBEnable3.AutoSize = true;
			this.chBEnable3.Location = new Point(48, 146);
			this.chBEnable3.Name = "chBEnable3";
			this.chBEnable3.Size = new Size(15, 14);
			this.chBEnable3.TabIndex = 12;
			this.chBEnable3.UseVisualStyleBackColor = true;
			this.chBEnable3.CheckedChanged += this.chBEnableX_CheckedChanged;
			this.cBStep2.DrawMode = DrawMode.OwnerDrawFixed;
			this.cBStep2.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBStep2.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBStep2.FormattingEnabled = true;
			this.cBStep2.Location = new Point(515, 100);
			this.cBStep2.Name = "cBStep2";
			this.cBStep2.Size = new Size(156, 26);
			this.cBStep2.TabIndex = 11;
			this.cBStep2.DrawItem += this.cBStepX_DrawItem;
			this.cBStep2.SelectedIndexChanged += this.cBStepX_SelectedIndexChanged;
			this.nEValue2Min.BackColor = Color.White;
			this.nEValue2Min.DecimalNum = 3;
			this.nEValue2Min.Font = new Font("Arial Unicode MS", 15f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEValue2Min.ForeColor = SystemColors.ControlText;
			this.nEValue2Min.Location = new Point(255, 100);
			this.nEValue2Min.MaxValue = 10f;
			this.nEValue2Min.MinValue = 0f;
			this.nEValue2Min.Name = "nEValue2Min";
			this.nEValue2Min.Size = new Size(80, 28);
			this.nEValue2Min.TabIndex = 10;
			this.nEValue2Min.Text = "2,000";
			this.nEValue2Min.TextAlign = HorizontalAlignment.Right;
			this.nEValue2Min.Value = 2f;
			this.nEValue2Min.MouseClick += this.StartInput;
			this.nEValue2Min.TextChanged += this.settingsChanged;
			this.nEValue2Min.Enter += this.Start_Input;
			this.cBType2.DropDownStyle = ComboBoxStyle.DropDownList;
			this.cBType2.Font = new Font("Arial Unicode MS", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.cBType2.FormattingEnabled = true;
			this.cBType2.Location = new Point(74, 100);
			this.cBType2.Name = "cBType2";
			this.cBType2.Size = new Size(170, 26);
			this.cBType2.TabIndex = 9;
			this.cBType2.SelectedIndexChanged += this.cBTypeX_SelectedIndexChanged;
			this.chBEnable2.AutoSize = true;
			this.chBEnable2.Location = new Point(48, 106);
			this.chBEnable2.Name = "chBEnable2";
			this.chBEnable2.Size = new Size(15, 14);
			this.chBEnable2.TabIndex = 8;
			this.chBEnable2.UseVisualStyleBackColor = true;
			this.chBEnable2.CheckedChanged += this.chBEnableX_CheckedChanged;
			this.pictureBoxTitle.Location = new Point(472, 7);
			this.pictureBoxTitle.Name = "pictureBoxTitle";
			this.pictureBoxTitle.Size = new Size(170, 88);
			this.pictureBoxTitle.TabIndex = 20;
			this.pictureBoxTitle.TabStop = false;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.pictureBoxTitle);
			base.Controls.Add(this.lbProgNum);
			base.Controls.Add(this.lbProgName);
			base.Controls.Add(this.gBTitel);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "FourStepEditForm";
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen/Programme/Stufen/Stufe bearbeiten";
			base.Activated += this.EditFinalizeStepForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBTitel.ResumeLayout(false);
			this.gBTitel.PerformLayout();
			((ISupportInitialize)this.pictureBoxTitle).EndInit();
			base.ResumeLayout(false);
		}

		public bool ShowWindow(int progNum, string title, int fourStepNumber, WSP1_VarComm.ProgStruct PD)
		{
			if (progNum >= 1 && progNum < 1024)
			{
				this.IsInitializeMode = true;
				this.Main.ResetBrowserGrantedBy();
				this.stepIndex = fourStepNumber;
				this.IsInitializeMode = true;
				this.PNum = progNum;
				this.setTitle();
				this.SD4 = PD.FourProg;
				this.InitializeValues();
				this.MenEna();
				base.Show();
				this.IsInitializeMode = false;
				this.enableButtons();
				this.enableEditElements();
				this.IsInitializeMode = true;
				this.fillEditElements();
				this.IsInitializeMode = false;
				return true;
			}
			return false;
		}

		public void SetLanguageTexts()
		{
			string[] array = new string[8];
			string[] array2 = new string[4];
			array[0] = this.Main.Rm.GetString("Torque");
			array[1] = this.Main.Rm.GetString("FilteredTorque");
			array[2] = this.Main.Rm.GetString("RelativeTorque");
			array[3] = this.Main.Rm.GetString("M360Follow");
			array[4] = this.Main.Rm.GetString("Gradient");
			array[5] = this.Main.Rm.GetString("Angle");
			array[6] = this.Main.Rm.GetString("AnaDepth");
			array[7] = this.Main.Rm.GetString("AnaSignal");
			array2[0] = this.Main.Rm.GetString("Torque");
			array2[1] = this.Main.Rm.GetString("FilteredTorque");
			array2[2] = this.Main.Rm.GetString("MaxTorque");
			array2[3] = this.Main.Rm.GetString("DelayTorque");
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MProgramOverview") + "/" + this.Main.Rm.GetString("ProgramDisplay4Step") + "/" + this.Main.Rm.GetString("Edit4Step");
			this.btBack.Text = this.Main.Rm.GetString("Done");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btCancel.Text = this.Main.Rm.GetString("btCancel");
			this.btNext.Text = this.Main.Rm.GetString("btNext");
			this.btPrevious.Text = this.Main.Rm.GetString("btPrevious");
		}

		private void MenEna()
		{
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_FourStepEditForm, false);
		}

		private bool ApplyValues()
		{
			string text = string.Empty;
			string text2 = "";
			Dictionary<string, bool> dictionary = new Dictionary<string, bool>();
			for (int i = 0; i < 7; i++)
			{
				int num = 0;
				bool flag = true;
				switch (i)
				{
				case 0:
					num = this.cBType1.SelectedIndex;
					text2 = " (" + this.cBType1.Items[num] + ", " + this.Main.Rm.GetString("Stufe") + " " + this.cBStep1.Items[this.cBStep1.SelectedIndex] + ")";
					if (!this.chBEnable1.Checked)
					{
						flag = false;
					}
					break;
				case 1:
					num = this.cBType2.SelectedIndex;
					text2 = " (" + this.cBType2.Items[num] + ", " + this.Main.Rm.GetString("Stufe") + " " + this.cBStep2.Items[this.cBStep2.SelectedIndex] + ")";
					if (!this.chBEnable2.Checked)
					{
						flag = false;
					}
					break;
				case 2:
					num = this.cBType3.SelectedIndex;
					text2 = " (" + this.cBType3.Items[num] + ", " + this.Main.Rm.GetString("Stufe") + " " + this.cBStep3.Items[this.cBStep3.SelectedIndex] + ")";
					if (!this.chBEnable3.Checked)
					{
						flag = false;
					}
					break;
				case 3:
					num = this.cBType4.SelectedIndex;
					text2 = " (" + this.cBType4.Items[num] + ", " + this.Main.Rm.GetString("Stufe") + " " + this.cBStep4.Items[this.cBStep4.SelectedIndex] + ")";
					if (!this.chBEnable4.Checked)
					{
						flag = false;
					}
					break;
				case 4:
					num = this.cBType5.SelectedIndex;
					text2 = " (" + this.cBType5.Items[num] + ", " + this.Main.Rm.GetString("Stufe") + " " + this.cBStep5.Items[this.cBStep5.SelectedIndex] + ")";
					if (!this.chBEnable5.Checked)
					{
						flag = false;
					}
					break;
				case 5:
					num = this.cBType6.SelectedIndex;
					text2 = " (" + this.cBType6.Items[num] + ", " + this.Main.Rm.GetString("Stufe") + " " + this.cBStep6.Items[this.cBStep6.SelectedIndex] + ")";
					if (!this.chBEnable6.Checked)
					{
						flag = false;
					}
					break;
				case 6:
					num = this.cBType7.SelectedIndex;
					text2 = " (" + this.cBType7.Items[num] + ", " + this.Main.Rm.GetString("Stufe") + " " + this.cBStep7.Items[this.cBStep7.SelectedIndex] + ")";
					if (!this.chBEnable7.Checked)
					{
						flag = false;
					}
					break;
				}
				if (flag)
				{
					if (dictionary.ContainsKey(text2))
					{
						text = text + this.Main.Rm.GetString("Mb4StepDoubleTypeFound") + "\n   ";
						string text3 = text;
						text = text3 + this.Main.Rm.GetString("Mb4StepFoundWhere") + ": " + (i + 1).ToString() + text2 + "\n";
						break;
					}
					dictionary.Add(text2, true);
				}
			}
			if (this.chBEnable1.Checked && this.nEValue1Min.Value >= this.nEValue1Max.Value)
			{
				text = text + this.Main.Rm.GetString("Mb4MinMaxReversed") + " 1\n";
			}
			if (this.chBEnable2.Checked && this.nEValue2Min.Value >= this.nEValue2Max.Value)
			{
				text = text + this.Main.Rm.GetString("Mb4MinMaxReversed") + " 2\n";
			}
			if (this.chBEnable3.Checked && this.nEValue3Min.Value >= this.nEValue3Max.Value)
			{
				text = text + this.Main.Rm.GetString("Mb4MinMaxReversed") + " 3\n";
			}
			if (this.chBEnable4.Checked && this.nEValue4Min.Value >= this.nEValue4Max.Value)
			{
				text = text + this.Main.Rm.GetString("Mb4MinMaxReversed") + " 4\n";
			}
			if (this.chBEnable5.Checked && this.nEValue5Min.Value >= this.nEValue5Max.Value)
			{
				text = text + this.Main.Rm.GetString("Mb4MinMaxReversed") + " 5\n";
			}
			if (this.chBEnable6.Checked && this.nEValue6Min.Value >= this.nEValue6Max.Value)
			{
				text = text + this.Main.Rm.GetString("Mb4MinMaxReversed") + " 6\n";
			}
			if (this.chBEnable7.Checked && this.nEValue7Min.Value >= this.nEValue7Max.Value)
			{
				text = text + this.Main.Rm.GetString("Mb4MinMaxReversed") + " 7\n";
			}
			float num2;
			if (this.chBEnable1.Checked && !this.nEValue1Min.IsOK)
			{
				object obj = text;
				object[] array = new object[9]
				{
					obj,
					this.cBType1.Items[this.cBType1.SelectedIndex],
					"(1 min) ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				object[] array2 = array;
				num2 = this.nEValue1Min.MinValue;
				array2[5] = num2.ToString();
				array[6] = " - ";
				array[7] = this.nEValue1Min.MaxValue.ToString();
				array[8] = "\n";
				text = string.Concat(array);
			}
			if (this.chBEnable2.Checked && !this.nEValue2Min.IsOK)
			{
				object obj2 = text;
				text = string.Concat(obj2, this.cBType2.Items[this.cBType2.SelectedIndex], "(2 min) ", this.Main.Rm.GetString("OutOfRange"), ": ", this.nEValue2Min.MinValue.ToString(), " - ", this.nEValue2Min.MaxValue.ToString(), "\n");
			}
			if (this.chBEnable3.Checked && !this.nEValue3Min.IsOK)
			{
				object obj3 = text;
				text = string.Concat(obj3, this.cBType3.Items[this.cBType3.SelectedIndex], "(3 min) ", this.Main.Rm.GetString("OutOfRange"), ": ", this.nEValue3Min.MinValue.ToString(), " - ", this.nEValue3Min.MaxValue.ToString(), "\n");
			}
			if (this.chBEnable4.Checked && !this.nEValue4Min.IsOK)
			{
				object obj4 = text;
				text = string.Concat(obj4, this.cBType4.Items[this.cBType4.SelectedIndex], "(4 min) ", this.Main.Rm.GetString("OutOfRange"), ": ", this.nEValue4Min.MinValue.ToString(), " - ", this.nEValue4Min.MaxValue.ToString(), "\n");
			}
			if (this.chBEnable5.Checked && !this.nEValue5Min.IsOK)
			{
				object obj5 = text;
				text = string.Concat(obj5, this.cBType5.Items[this.cBType5.SelectedIndex], "(5 min) ", this.Main.Rm.GetString("OutOfRange"), ": ", this.nEValue5Min.MinValue.ToString(), " - ", this.nEValue5Min.MaxValue.ToString(), "\n");
			}
			if (this.chBEnable6.Checked && !this.nEValue6Min.IsOK)
			{
				object obj6 = text;
				text = string.Concat(obj6, this.cBType6.Items[this.cBType6.SelectedIndex], "(6 min) ", this.Main.Rm.GetString("OutOfRange"), ": ", this.nEValue6Min.MinValue.ToString(), " - ", this.nEValue6Min.MaxValue.ToString(), "\n");
			}
			if (this.chBEnable7.Checked && !this.nEValue7Min.IsOK)
			{
				object obj7 = text;
				text = string.Concat(obj7, this.cBType7.Items[this.cBType7.SelectedIndex], "(7 min) ", this.Main.Rm.GetString("OutOfRange"), ": ", this.nEValue7Min.MinValue.ToString(), " - ", this.nEValue7Min.MaxValue.ToString(), "\n");
			}
			if (this.chBEnable1.Checked && !this.nEValue1Max.IsOK)
			{
				object obj8 = text;
				text = string.Concat(obj8, this.cBType1.Items[this.cBType1.SelectedIndex], "(1 max) ", this.Main.Rm.GetString("OutOfRange"), ": ", this.nEValue1Max.MinValue.ToString(), " - ", this.nEValue1Min.MaxValue.ToString(), "\n");
			}
			if (this.chBEnable2.Checked && !this.nEValue2Max.IsOK)
			{
				object obj9 = text;
				text = string.Concat(obj9, this.cBType2.Items[this.cBType2.SelectedIndex], "(2 max) ", this.Main.Rm.GetString("OutOfRange"), ": ", this.nEValue2Max.MinValue.ToString(), " - ", this.nEValue2Min.MaxValue.ToString(), "\n");
			}
			if (this.chBEnable3.Checked && !this.nEValue3Max.IsOK)
			{
				object obj10 = text;
				text = string.Concat(obj10, this.cBType3.Items[this.cBType3.SelectedIndex], "(3 max) ", this.Main.Rm.GetString("OutOfRange"), ": ", this.nEValue3Max.MinValue.ToString(), " - ", this.nEValue3Min.MaxValue.ToString(), "\n");
			}
			if (this.chBEnable4.Checked && !this.nEValue4Max.IsOK)
			{
				object obj11 = text;
				object[] array3 = new object[9]
				{
					obj11,
					this.cBType4.Items[this.cBType4.SelectedIndex],
					"(4 max) ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				object[] array4 = array3;
				num2 = this.nEValue4Max.MinValue;
				array4[5] = num2.ToString();
				array3[6] = " - ";
				object[] array5 = array3;
				num2 = this.nEValue4Min.MaxValue;
				array5[7] = num2.ToString();
				array3[8] = "\n";
				text = string.Concat(array3);
			}
			if (this.chBEnable5.Checked && !this.nEValue5Max.IsOK)
			{
				object obj = text;
				object[] array6 = new object[9]
				{
					obj,
					this.cBType5.Items[this.cBType5.SelectedIndex],
					"(5 max) ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				object[] array7 = array6;
				num2 = this.nEValue5Max.MinValue;
				array7[5] = num2.ToString();
				array6[6] = " - ";
				object[] array8 = array6;
				num2 = this.nEValue5Min.MaxValue;
				array8[7] = num2.ToString();
				array6[8] = "\n";
				text = string.Concat(array6);
			}
			if (this.chBEnable6.Checked && !this.nEValue6Max.IsOK)
			{
				object obj = text;
				object[] array6 = new object[9]
				{
					obj,
					this.cBType6.Items[this.cBType6.SelectedIndex],
					"(6 max) ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				object[] array9 = array6;
				num2 = this.nEValue6Max.MinValue;
				array9[5] = num2.ToString();
				array6[6] = " - ";
				object[] array10 = array6;
				num2 = this.nEValue6Min.MaxValue;
				array10[7] = num2.ToString();
				array6[8] = "\n";
				text = string.Concat(array6);
			}
			if (this.chBEnable7.Checked && !this.nEValue7Max.IsOK)
			{
				object obj = text;
				object[] array6 = new object[9]
				{
					obj,
					this.cBType7.Items[this.cBType7.SelectedIndex],
					"(7 max) ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				object[] array11 = array6;
				num2 = this.nEValue7Max.MinValue;
				array11[5] = num2.ToString();
				array6[6] = " - ";
				object[] array12 = array6;
				num2 = this.nEValue7Min.MaxValue;
				array12[7] = num2.ToString();
				array6[8] = "\n";
				text = string.Concat(array6);
			}
			if (this.Main.CheckParamAllowed && text != string.Empty)
			{
				MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + text, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			string text4 = this.Main.FourStepOverview1.CheckProgramValues();
			if (text4 != null)
			{
				DialogResult dialogResult = MessageBox.Show(text4, this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
				if (dialogResult == DialogResult.Cancel)
				{
					return false;
				}
			}
			return true;
		}

		private void InitializeValues()
		{
			this.lbProgNum.Text = this.Main.Rm.GetString("Abr_Program") + " " + this.PNum.ToString();
			this.lbProgName.Text = this.Main.CommonFunctions.UShortToString(this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Info.Name);
			this.lbStep.Text = this.Main.Rm.GetString("StepOnControler");
			this.lbEnable.Text = "";
			this.lbValue.Text = this.Main.Rm.GetString("ValueRange");
			this.lbType.Text = this.Main.Rm.GetString("Kind");
		}

		private void cBTargetName_SelectedIndexChanged(object sender, EventArgs e)
		{
			bool isInitializeMode = this.IsInitializeMode;
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.storeElements();
				this.pnMenu.Enabled = false;
				this.Main.StatusBarText(string.Empty);
				base.Hide();
			}
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_1_6_2_Einrichten_Vier_Stufen";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_1_6_2_Einrichten_Vier_Stufen");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btNext_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				int fourStepCount = this.Main.FourStepOverview1.GetFourStepCount();
				if (this.stepIndex < fourStepCount)
				{
					this.storeElements();
					this.stepIndex++;
					this.setTitle();
					this.enableButtons();
					this.IsInitializeMode = true;
					this.fillEditElements();
					this.IsInitializeMode = false;
				}
			}
		}

		private void btPrevious_Click(object sender, EventArgs e)
		{
			if (this.ApplyValues())
			{
				this.Main.FourStepOverview1.GetFourStepCount();
				if (this.stepIndex != 0)
				{
					this.storeElements();
					this.stepIndex--;
					this.setTitle();
					this.enableButtons();
					this.IsInitializeMode = true;
					this.fillEditElements();
					this.IsInitializeMode = false;
				}
			}
		}

		private void setTitle()
		{
			switch (this.stepIndex)
			{
			case 0:
				this.pictureBoxTitle.Image = Resources.Find;
				break;
			case 1:
				this.pictureBoxTitle.Image = Resources.Flow;
				break;
			case 2:
				this.pictureBoxTitle.Image = Resources.Screw_;
				break;
			case 3:
				this.pictureBoxTitle.Image = Resources.Fasten_;
				break;
			}
			this.gBTitel.Text = this.Main.FourStepOverview1.GetFourStepName(this.stepIndex);
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.bCanceled = true;
			this.pnMenu.Enabled = false;
			this.Main.StatusBarText(string.Empty);
			base.Hide();
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (this.pnMenu.Enabled)
			{
				this.Main.TextInput(sender);
			}
			else
			{
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void chBxx_CheckedChanged(object sender, EventArgs e)
		{
			this.MenEna();
		}

		private void EditFinalizeStepForm_Activated(object sender, EventArgs e)
		{
			this.MenEna();
			this.bCanceled = false;
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void showTypes(ComboBox cb, int selectedIndex)
		{
			string text = "";
			cb.Items.Clear();
			int num = 0;
			do
			{
				text = this.Main.C_global.GetFourStepTypeDescription(num, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text);
				if (text == null)
				{
					break;
				}
				cb.Items.Add(text);
				num++;
			}
			while (text != null);
			cb.SelectedIndex = selectedIndex;
		}

		private void showStepNumbers(ComboBox cb, int selectedIndex, int cBIndex)
		{
			cb.Items.Clear();
			for (int i = 0; i < this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Info.Steps; i++)
			{
				string str = "";
				switch (this.Main.ProcessProgram.TempProgStruct.Num[this.PNum].Step[i].Type)
				{
				case 2:
					str = this.Main.Rm.GetString("DrivingStep");
					break;
				case 3:
					str = this.Main.Rm.GetString("FinalizingStep");
					break;
				case 1:
					str = this.Main.Rm.GetString("OrganizingStep");
					break;
				}
				cb.Items.Add((i + 1).ToString() + " " + str);
			}
			if (selectedIndex < cb.Items.Count)
			{
				cb.SelectedIndex = selectedIndex;
			}
			else
			{
				cb.SelectedIndex = 0;
			}
			this.recentSelectedStep[cBIndex] = cb.SelectedIndex;
		}

		private void cBStepX_DrawItem(object sender, DrawItemEventArgs e)
		{
			try
			{
				ComboBox comboBox = sender as ComboBox;
				if (comboBox.Items[e.Index].ToString().Contains(this.Main.Rm.GetString("OrganizingStep")))
				{
					e.Graphics.DrawString(comboBox.Items[e.Index].ToString(), this.myFont, Brushes.LightSlateGray, e.Bounds);
				}
				else
				{
					e.DrawBackground();
					e.Graphics.DrawString(comboBox.Items[e.Index].ToString(), this.myFont, Brushes.Black, e.Bounds);
					e.DrawFocusRectangle();
				}
			}
			catch (Exception)
			{
			}
		}

		private void cBStepX_SelectedIndexChanged(object sender, EventArgs e)
		{
			ComboBox comboBox = sender as ComboBox;
			int num = 0;
			if (comboBox == this.cBStep1)
			{
				num = 0;
			}
			else if (comboBox == this.cBStep2)
			{
				num = 1;
			}
			else if (comboBox == this.cBStep3)
			{
				num = 2;
			}
			else if (comboBox == this.cBStep4)
			{
				num = 3;
			}
			else if (comboBox == this.cBStep5)
			{
				num = 4;
			}
			else if (comboBox == this.cBStep6)
			{
				num = 5;
			}
			else if (comboBox == this.cBStep7)
			{
				num = 6;
			}
			if (comboBox.Items[comboBox.SelectedIndex].ToString().Contains(this.Main.Rm.GetString("OrganizingStep")))
			{
				comboBox.SelectedIndex = this.recentSelectedStep[num];
			}
			else
			{
				this.recentSelectedStep[num] = comboBox.SelectedIndex;
			}
			this.settingsChanged(sender, e);
		}

		private void setValueProperty(int index)
		{
			try
			{
				string text;
				float maxValue;
				float minValue;
				float num;
				switch (index)
				{
				case 0:
					this.Main.C_global.GetFourStepTypeDescription(this.cBType1.SelectedIndex, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text, out maxValue, out minValue, out num);
					this.lbUnit1.Text = text;
					this.nEValue1Min.MaxValue = maxValue;
					this.nEValue1Min.MinValue = minValue;
					this.nEValue1Max.MaxValue = maxValue;
					this.nEValue1Max.MinValue = minValue;
					this.nEValue1Min.DecimalNum = (int)num;
					this.nEValue1Max.DecimalNum = (int)num;
					break;
				case 1:
					this.Main.C_global.GetFourStepTypeDescription(this.cBType2.SelectedIndex, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text, out maxValue, out minValue, out num);
					this.lbUnit2.Text = text;
					this.nEValue2Min.MaxValue = maxValue;
					this.nEValue2Min.MinValue = minValue;
					this.nEValue2Max.MaxValue = maxValue;
					this.nEValue2Max.MinValue = minValue;
					this.nEValue2Min.DecimalNum = (int)num;
					this.nEValue2Max.DecimalNum = (int)num;
					break;
				case 2:
					this.Main.C_global.GetFourStepTypeDescription(this.cBType3.SelectedIndex, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text, out maxValue, out minValue, out num);
					this.lbUnit3.Text = text;
					this.nEValue3Min.MaxValue = maxValue;
					this.nEValue3Min.MinValue = minValue;
					this.nEValue3Max.MaxValue = maxValue;
					this.nEValue3Max.MinValue = minValue;
					this.nEValue3Min.DecimalNum = (int)num;
					this.nEValue3Max.DecimalNum = (int)num;
					break;
				case 3:
					this.Main.C_global.GetFourStepTypeDescription(this.cBType4.SelectedIndex, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text, out maxValue, out minValue, out num);
					this.lbUnit4.Text = text;
					this.nEValue4Min.MaxValue = maxValue;
					this.nEValue4Min.MinValue = minValue;
					this.nEValue4Max.MaxValue = maxValue;
					this.nEValue4Max.MinValue = minValue;
					this.nEValue4Min.DecimalNum = (int)num;
					this.nEValue4Max.DecimalNum = (int)num;
					break;
				case 4:
					this.Main.C_global.GetFourStepTypeDescription(this.cBType5.SelectedIndex, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text, out maxValue, out minValue, out num);
					this.lbUnit5.Text = text;
					this.nEValue5Min.MaxValue = maxValue;
					this.nEValue5Min.MinValue = minValue;
					this.nEValue5Max.MaxValue = maxValue;
					this.nEValue5Max.MinValue = minValue;
					this.nEValue5Min.DecimalNum = (int)num;
					this.nEValue5Max.DecimalNum = (int)num;
					break;
				case 5:
					this.Main.C_global.GetFourStepTypeDescription(this.cBType6.SelectedIndex, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text, out maxValue, out minValue, out num);
					this.lbUnit6.Text = text;
					this.nEValue6Min.MaxValue = maxValue;
					this.nEValue6Min.MinValue = minValue;
					this.nEValue6Max.MaxValue = maxValue;
					this.nEValue6Max.MinValue = minValue;
					this.nEValue6Min.DecimalNum = (int)num;
					this.nEValue6Max.DecimalNum = (int)num;
					break;
				case 6:
					this.Main.C_global.GetFourStepTypeDescription(this.cBType7.SelectedIndex, this.Main.VC.SpConst, this.Main.Rm, this.Main.TorqueConvert, this.Main.TorqueUnitName, out text, out maxValue, out minValue, out num);
					this.lbUnit7.Text = text;
					this.nEValue7Min.MaxValue = maxValue;
					this.nEValue7Min.MinValue = minValue;
					this.nEValue7Max.MaxValue = maxValue;
					this.nEValue7Max.MinValue = minValue;
					this.nEValue7Min.DecimalNum = (int)num;
					this.nEValue7Max.DecimalNum = (int)num;
					break;
				}
			}
			catch (Exception)
			{
			}
		}

		private void fillEditElements()
		{
			try
			{
				this.chBEnable1.Checked = (this.SD4.FourthStep[this.stepIndex].FourStepAtoms[0].StepIndex >= 128 && true);
				this.chBEnable2.Checked = (this.SD4.FourthStep[this.stepIndex].FourStepAtoms[1].StepIndex >= 128 && true);
				this.chBEnable3.Checked = (this.SD4.FourthStep[this.stepIndex].FourStepAtoms[2].StepIndex >= 128 && true);
				this.chBEnable4.Checked = (this.SD4.FourthStep[this.stepIndex].FourStepAtoms[3].StepIndex >= 128 && true);
				this.chBEnable5.Checked = (this.SD4.FourthStep[this.stepIndex].FourStepAtoms[4].StepIndex >= 128 && true);
				this.chBEnable6.Checked = (this.SD4.FourthStep[this.stepIndex].FourStepAtoms[5].StepIndex >= 128 && true);
				this.chBEnable7.Checked = (this.SD4.FourthStep[this.stepIndex].FourStepAtoms[6].StepIndex >= 128 && true);
				this.showTypes(this.cBType1, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[0].TypeOfData);
				this.showTypes(this.cBType2, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[1].TypeOfData);
				this.showTypes(this.cBType3, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[2].TypeOfData);
				this.showTypes(this.cBType4, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[3].TypeOfData);
				this.showTypes(this.cBType5, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[4].TypeOfData);
				this.showTypes(this.cBType6, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[5].TypeOfData);
				this.showTypes(this.cBType7, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[6].TypeOfData);
				this.showStepNumbers(this.cBStep1, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[0].StepIndex & 0x7F, 0);
				this.showStepNumbers(this.cBStep2, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[1].StepIndex & 0x7F, 1);
				this.showStepNumbers(this.cBStep3, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[2].StepIndex & 0x7F, 2);
				this.showStepNumbers(this.cBStep4, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[3].StepIndex & 0x7F, 3);
				this.showStepNumbers(this.cBStep5, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[4].StepIndex & 0x7F, 4);
				this.showStepNumbers(this.cBStep6, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[5].StepIndex & 0x7F, 5);
				this.showStepNumbers(this.cBStep7, this.SD4.FourthStep[this.stepIndex].FourStepAtoms[6].StepIndex & 0x7F, 6);
				this.setValueProperty(0);
				this.setValueProperty(1);
				this.setValueProperty(2);
				this.setValueProperty(3);
				this.setValueProperty(4);
				this.setValueProperty(5);
				this.setValueProperty(6);
				this.nEValue1Min.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[0].MinValue;
				this.nEValue2Min.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[1].MinValue;
				this.nEValue3Min.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[2].MinValue;
				this.nEValue4Min.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[3].MinValue;
				this.nEValue5Min.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[4].MinValue;
				this.nEValue6Min.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[5].MinValue;
				this.nEValue7Min.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[6].MinValue;
				this.nEValue1Max.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[0].MaxValue;
				this.nEValue2Max.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[1].MaxValue;
				this.nEValue3Max.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[2].MaxValue;
				this.nEValue4Max.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[3].MaxValue;
				this.nEValue5Max.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[4].MaxValue;
				this.nEValue6Max.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[5].MaxValue;
				this.nEValue7Max.Value = this.SD4.FourthStep[this.stepIndex].FourStepAtoms[6].MaxValue;
				this.enableLineElements(0, this.chBEnable1.Checked);
				this.enableLineElements(1, this.chBEnable2.Checked);
				this.enableLineElements(2, this.chBEnable3.Checked);
				this.enableLineElements(3, this.chBEnable4.Checked);
				this.enableLineElements(4, this.chBEnable5.Checked);
				this.enableLineElements(5, this.chBEnable6.Checked);
				this.enableLineElements(6, this.chBEnable7.Checked);
			}
			catch (Exception)
			{
			}
		}

		private void storeElements()
		{
			try
			{
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[0].StepIndex = (byte)this.cBStep1.SelectedIndex;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[1].StepIndex = (byte)this.cBStep2.SelectedIndex;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[2].StepIndex = (byte)this.cBStep3.SelectedIndex;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[3].StepIndex = (byte)this.cBStep4.SelectedIndex;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[4].StepIndex = (byte)this.cBStep5.SelectedIndex;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[5].StepIndex = (byte)this.cBStep6.SelectedIndex;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[6].StepIndex = (byte)this.cBStep7.SelectedIndex;
				if (this.chBEnable1.Checked)
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[0].StepIndex |= 128;
				}
				else
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[0].StepIndex &= 247;
				}
				if (this.chBEnable2.Checked)
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[1].StepIndex |= 128;
				}
				else
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[1].StepIndex &= 247;
				}
				if (this.chBEnable3.Checked)
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[2].StepIndex |= 128;
				}
				else
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[2].StepIndex &= 247;
				}
				if (this.chBEnable4.Checked)
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[3].StepIndex |= 128;
				}
				else
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[3].StepIndex &= 247;
				}
				if (this.chBEnable5.Checked)
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[4].StepIndex |= 128;
				}
				else
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[4].StepIndex &= 247;
				}
				if (this.chBEnable6.Checked)
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[5].StepIndex |= 128;
				}
				else
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[5].StepIndex &= 247;
				}
				if (this.chBEnable7.Checked)
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[6].StepIndex |= 128;
				}
				else
				{
					this.SD4.FourthStep[this.stepIndex].FourStepAtoms[6].StepIndex &= 247;
				}
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[0].MinValue = this.nEValue1Min.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[1].MinValue = this.nEValue2Min.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[2].MinValue = this.nEValue3Min.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[3].MinValue = this.nEValue4Min.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[4].MinValue = this.nEValue5Min.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[5].MinValue = this.nEValue6Min.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[6].MinValue = this.nEValue7Min.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[0].MaxValue = this.nEValue1Max.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[1].MaxValue = this.nEValue2Max.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[2].MaxValue = this.nEValue3Max.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[3].MaxValue = this.nEValue4Max.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[4].MaxValue = this.nEValue5Max.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[5].MaxValue = this.nEValue6Max.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[6].MaxValue = this.nEValue7Max.Value;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[0].TypeOfData = (byte)this.cBType1.SelectedIndex;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[1].TypeOfData = (byte)this.cBType2.SelectedIndex;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[2].TypeOfData = (byte)this.cBType3.SelectedIndex;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[3].TypeOfData = (byte)this.cBType4.SelectedIndex;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[4].TypeOfData = (byte)this.cBType5.SelectedIndex;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[5].TypeOfData = (byte)this.cBType6.SelectedIndex;
				this.SD4.FourthStep[this.stepIndex].FourStepAtoms[6].TypeOfData = (byte)this.cBType7.SelectedIndex;
			}
			catch (Exception)
			{
			}
		}

		private void enableEditElements()
		{
		}

		private void enableButtons()
		{
			this.btPrevious.Enabled = true;
			this.btNext.Enabled = true;
			int fourStepCount = this.Main.FourStepOverview1.GetFourStepCount();
			if (this.stepIndex >= fourStepCount - 1)
			{
				this.btNext.Enabled = false;
				this.btPrevious.Focus();
			}
			if (this.stepIndex == 0)
			{
				this.btPrevious.Enabled = false;
				this.btNext.Focus();
			}
		}

		private void enableLineElements(int index, bool enable)
		{
			switch (index)
			{
			case 0:
				this.cBType1.Enabled = enable;
				this.nEValue1Min.Enabled = enable;
				this.nEValue1Max.Enabled = enable;
				this.lbUnit1.Enabled = enable;
				this.cBStep1.Enabled = enable;
				break;
			case 1:
				this.cBType2.Enabled = enable;
				this.nEValue2Min.Enabled = enable;
				this.nEValue2Max.Enabled = enable;
				this.lbUnit2.Enabled = enable;
				this.cBStep2.Enabled = enable;
				break;
			case 2:
				this.cBType3.Enabled = enable;
				this.nEValue3Min.Enabled = enable;
				this.nEValue3Max.Enabled = enable;
				this.lbUnit3.Enabled = enable;
				this.cBStep3.Enabled = enable;
				break;
			case 3:
				this.cBType4.Enabled = enable;
				this.nEValue4Min.Enabled = enable;
				this.nEValue4Max.Enabled = enable;
				this.lbUnit4.Enabled = enable;
				this.cBStep4.Enabled = enable;
				break;
			case 4:
				this.cBType5.Enabled = enable;
				this.nEValue5Min.Enabled = enable;
				this.nEValue5Max.Enabled = enable;
				this.lbUnit5.Enabled = enable;
				this.cBStep5.Enabled = enable;
				break;
			case 5:
				this.cBType6.Enabled = enable;
				this.nEValue6Min.Enabled = enable;
				this.nEValue6Max.Enabled = enable;
				this.lbUnit6.Enabled = enable;
				this.cBStep6.Enabled = enable;
				break;
			case 6:
				this.cBType7.Enabled = enable;
				this.nEValue7Min.Enabled = enable;
				this.nEValue7Max.Enabled = enable;
				this.lbUnit7.Enabled = enable;
				this.cBStep7.Enabled = enable;
				break;
			}
		}

		private void chBEnable1_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void lbValue_Click(object sender, EventArgs e)
		{
		}

		public void KeyArrived()
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else if (this.Main.PassCodeLevel > 0)
			{
				if (this.Main.GetExclusiveBlock1())
				{
					if (this.Main.ProcessProgram.UploadAllProgDataFromController())
					{
						this.Main.CheckParamAllowed = true;
						base.Hide();
						this.Main.StepOverview1.Hide();
					}
				}
				else
				{
					this.Main.CheckParamAllowed = false;
				}
			}
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void cBTypeX_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				ComboBox comboBox = sender as ComboBox;
				if (comboBox == this.cBType1)
				{
					this.setValueProperty(0);
				}
				else if (comboBox == this.cBType2)
				{
					this.setValueProperty(1);
				}
				else if (comboBox == this.cBType3)
				{
					this.setValueProperty(2);
				}
				else if (comboBox == this.cBType4)
				{
					this.setValueProperty(3);
				}
				else if (comboBox == this.cBType5)
				{
					this.setValueProperty(4);
				}
				else if (comboBox == this.cBType6)
				{
					this.setValueProperty(5);
				}
				else if (comboBox == this.cBType7)
				{
					this.setValueProperty(6);
				}
			}
			catch (Exception)
			{
			}
			this.settingsChanged(sender, e);
		}

		private void chBEnableX_CheckedChanged(object sender, EventArgs e)
		{
			if (!this.IsInitializeMode)
			{
				this.Main.SettingsChanged();
				CheckBox checkBox = sender as CheckBox;
				if (checkBox == this.chBEnable1)
				{
					this.Main.FourStepOverview1.InitializeValue(this.stepIndex, 0);
					this.enableLineElements(0, checkBox.Checked);
				}
				else if (checkBox == this.chBEnable2)
				{
					this.Main.FourStepOverview1.InitializeValue(this.stepIndex, 0);
					this.enableLineElements(1, checkBox.Checked);
				}
				else if (checkBox == this.chBEnable3)
				{
					this.Main.FourStepOverview1.InitializeValue(this.stepIndex, 0);
					this.enableLineElements(2, checkBox.Checked);
				}
				else if (checkBox == this.chBEnable4)
				{
					this.Main.FourStepOverview1.InitializeValue(this.stepIndex, 0);
					this.enableLineElements(3, checkBox.Checked);
				}
				else if (checkBox == this.chBEnable5)
				{
					this.Main.FourStepOverview1.InitializeValue(this.stepIndex, 0);
					this.enableLineElements(4, checkBox.Checked);
				}
				else if (checkBox == this.chBEnable6)
				{
					this.Main.FourStepOverview1.InitializeValue(this.stepIndex, 0);
					this.enableLineElements(5, checkBox.Checked);
				}
				else if (checkBox == this.chBEnable7)
				{
					this.Main.FourStepOverview1.InitializeValue(this.stepIndex, 0);
					this.enableLineElements(6, checkBox.Checked);
				}
			}
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.IsInitializeMode)
			{
				this.Main.SettingsChanged();
			}
		}
	}
}
