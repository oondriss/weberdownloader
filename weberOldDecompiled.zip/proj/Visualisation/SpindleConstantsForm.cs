using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class SpindleConstantsForm : Form
	{
		private MainForm Main;

		private FileOperationForm SpConstFileOperation;

		private WSP1_VarComm.SpConst_Struct TempSpindleStruct;

		private Panel pnMenu;

		private Button bt2;

		private Button btHelp;

		private Button btBack;

		private Label lbFrictionTorque;

		private GroupBox gBFrictionTest;

		private NumberEdit1 nEFrictionTorque;

		private GroupBox gBDepthSensor;

		private Button btCancel;

		private NumberEdit1 nESpindleGearFactor;

		private Label lbSpindleGearFactor;

		private GroupBox gBSpindle;

		private Button bt5;

		private Button bt4;

		private Button bt3;

		private Label lbDriveUnitRpm;

		private Label lbUnitDriveUnitRpm;

		private NumberEdit1 nEDriveUnitRpm;

		private Label lbUnitFrictionSpeed;

		private Label lbUnitFrictionTorque;

		private NumberEdit1 nEFrictionSpeed;

		private Label lbFrictionSpeed;

		private CheckBox chBFrictionTestStartup;

		private CheckBox chBFrictionTestEMG;

		private CheckBox chBDriveUnitInvers;

		private CheckBox chBAngleSensorInvers;

		private CheckBox chBTorqueSensorInvers;

		private Label lbUnitAngleSensorScale;

		private NumberEdit1 nEAngleSensorScale;

		private Label lbAngleSensorScale;

		private Label lbUnitTorqueSensorScale;

		private NumberEdit1 nETorqueSensorScale;

		private Label lbTorqueSensorScale;

		private Label lbUnitDepthSensorScale;

		private NumberEdit1 nEDepthSensorScale;

		private Label lbDepthSensorScale;

		private Label lbUnitDepthSensorOffset;

		private NumberEdit1 nEDepthSensorOffset;

		private Label lbDepthSensorOffset;

		private Label lbUnitSpindleTorque;

		private NumberEdit1 nESpindleTorque;

		private Label lbSpindleTorque;

		private GroupBox gBAngleTorqueSensor;

		private GroupBox gBAnaSignal;

		private Label lbUnitAnaSigOffset;

		private Label lbAnaSigOffset;

		private NumberEdit1 nEAnaSigOffset;

		private NumberEdit1 nEAnaSigScale;

		private Label lbAnaSigScale;

		private Label lbUnitTorqueSensorTolerance;

		private NumberEdit1 nETorqueSensorTolerance;

		private Label lbTorqueSensorTolerance;

		private GroupBox gBDriveUnit;

		private CheckBox chBDepthSensorInvers;

		private Label lbReleaseSpeed;

		private NumberEdit1 nEReleaseSpeed;

		private Label lbUnitReleaseSpeed;

		private Label lbUnitAnaSigScale;

		private OpenFileDialog openFileDialog;

		private SaveFileDialog saveFileDialog;

		private Button btFileOperation;

		private NumberEdit1 nEDepthSensorOffsetMin;

		private Label lbUnitDepthSensorOffsetPreset;

		private Label lbDepthSensorOffsetPreset;

		private NumberEdit1 nEDepthSensorOffsetPreset;

		private Label lbDepthSensorOffsetMax;

		private NumberEdit1 nEDepthSensorOffsetMax;

		private Label lbDepthSensorOffsetMin;

		private Label lbUnitDepthSensorOffsetMin;

		private Label lbUnitDepthSensorOffsetMax;

		private Label lbTorqueRedundantTolerance;

		private NumberEdit1 nETorqueRedundantTolerance;

		private Label lbUnitTorqueRedundantTolerance;

		private CheckBox chBRedundantSensorActive;

		private Label lbUnitTorqueRedundantTime;

		private NumberEdit1 nETorqueRedundantTime;

		private Label lbTorqueRedundantTime;

		private Label lbAngleRedundantTolerance;

		private NumberEdit1 nEAngleRedundantTolerance;

		private Label lbUnitAngleRedundantTolerance;

		private GroupBox gBRedundantSensor;

		private GroupBox gBPressure;

		private Label lbSpindlePressureScale;

		private NumberEdit1 nESpindlePressureScale;

		private Label lbHolderPressureScale;

		private NumberEdit1 nEHolderPressureScale;

		private Label lbUnitHolderPressureScale;

		private Label lbUnitSpindlePressureScale;

		private GroupBox gBJawOpenAutomatic;

		private Label lbUnitJawOpenDepthGradMin;

		private Label lbJawOpenDepthGradMax;

		private NumberEdit1 nEJawOpenDepthGradMax;

		private Label lbUnitJawOpenDepthGradMax;

		private Label lbUnitJawOpenDistance;

		private NumberEdit1 nEJawOpenDistance;

		private Label lbJawOpenDistance;

		private Label lbJawOpenDepthGradMin;

		private NumberEdit1 nEJawOpenDepthGradMin;

		private Container components;

		private bool bInitialize;

		public SpindleConstantsForm(MainForm main)
		{
			this.Main = main;
			this.SpConstFileOperation = new FileOperationForm(this.Main, 1);
			this.TempSpindleStruct = new WSP1_VarComm.SpConst_Struct();
			this.NewInitializedSpindleStruct(ref this.TempSpindleStruct);
			this.NewInitializedSpindleStruct(ref this.Main.VC.SpConst);
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.btCancel = new Button();
			this.bt5 = new Button();
			this.bt4 = new Button();
			this.bt3 = new Button();
			this.bt2 = new Button();
			this.btFileOperation = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.lbUnitDriveUnitRpm = new Label();
			this.lbUnitFrictionSpeed = new Label();
			this.lbUnitFrictionTorque = new Label();
			this.nEDriveUnitRpm = new NumberEdit1();
			this.nEFrictionSpeed = new NumberEdit1();
			this.nEFrictionTorque = new NumberEdit1();
			this.lbDriveUnitRpm = new Label();
			this.lbFrictionTorque = new Label();
			this.lbFrictionSpeed = new Label();
			this.chBFrictionTestStartup = new CheckBox();
			this.chBFrictionTestEMG = new CheckBox();
			this.chBDriveUnitInvers = new CheckBox();
			this.chBAngleSensorInvers = new CheckBox();
			this.chBTorqueSensorInvers = new CheckBox();
			this.lbUnitAngleSensorScale = new Label();
			this.nEAngleSensorScale = new NumberEdit1();
			this.lbAngleSensorScale = new Label();
			this.lbUnitTorqueSensorScale = new Label();
			this.nETorqueSensorScale = new NumberEdit1();
			this.lbTorqueSensorScale = new Label();
			this.lbUnitDepthSensorScale = new Label();
			this.nEDepthSensorScale = new NumberEdit1();
			this.lbDepthSensorScale = new Label();
			this.lbUnitDepthSensorOffset = new Label();
			this.nEDepthSensorOffset = new NumberEdit1();
			this.lbDepthSensorOffset = new Label();
			this.nESpindleGearFactor = new NumberEdit1();
			this.lbSpindleGearFactor = new Label();
			this.lbUnitSpindleTorque = new Label();
			this.nESpindleTorque = new NumberEdit1();
			this.lbSpindleTorque = new Label();
			this.gBFrictionTest = new GroupBox();
			this.gBDepthSensor = new GroupBox();
			this.lbUnitDepthSensorOffsetMin = new Label();
			this.lbDepthSensorOffsetMin = new Label();
			this.nEDepthSensorOffsetMin = new NumberEdit1();
			this.lbUnitDepthSensorOffsetMax = new Label();
			this.lbDepthSensorOffsetMax = new Label();
			this.nEDepthSensorOffsetMax = new NumberEdit1();
			this.lbUnitDepthSensorOffsetPreset = new Label();
			this.lbDepthSensorOffsetPreset = new Label();
			this.nEDepthSensorOffsetPreset = new NumberEdit1();
			this.chBDepthSensorInvers = new CheckBox();
			this.gBAngleTorqueSensor = new GroupBox();
			this.lbUnitTorqueSensorTolerance = new Label();
			this.nETorqueSensorTolerance = new NumberEdit1();
			this.lbTorqueSensorTolerance = new Label();
			this.lbAngleRedundantTolerance = new Label();
			this.nEAngleRedundantTolerance = new NumberEdit1();
			this.lbUnitAngleRedundantTolerance = new Label();
			this.lbTorqueRedundantTolerance = new Label();
			this.nETorqueRedundantTolerance = new NumberEdit1();
			this.lbUnitTorqueRedundantTolerance = new Label();
			this.chBRedundantSensorActive = new CheckBox();
			this.lbUnitTorqueRedundantTime = new Label();
			this.nETorqueRedundantTime = new NumberEdit1();
			this.lbTorqueRedundantTime = new Label();
			this.gBAnaSignal = new GroupBox();
			this.lbUnitAnaSigScale = new Label();
			this.lbUnitAnaSigOffset = new Label();
			this.lbAnaSigOffset = new Label();
			this.nEAnaSigOffset = new NumberEdit1();
			this.nEAnaSigScale = new NumberEdit1();
			this.lbAnaSigScale = new Label();
			this.gBSpindle = new GroupBox();
			this.lbReleaseSpeed = new Label();
			this.nEReleaseSpeed = new NumberEdit1();
			this.lbUnitReleaseSpeed = new Label();
			this.gBDriveUnit = new GroupBox();
			this.openFileDialog = new OpenFileDialog();
			this.saveFileDialog = new SaveFileDialog();
			this.gBRedundantSensor = new GroupBox();
			this.gBPressure = new GroupBox();
			this.lbUnitHolderPressureScale = new Label();
			this.lbUnitSpindlePressureScale = new Label();
			this.lbHolderPressureScale = new Label();
			this.nEHolderPressureScale = new NumberEdit1();
			this.lbSpindlePressureScale = new Label();
			this.nESpindlePressureScale = new NumberEdit1();
			this.gBJawOpenAutomatic = new GroupBox();
			this.lbUnitJawOpenDepthGradMin = new Label();
			this.lbJawOpenDepthGradMax = new Label();
			this.nEJawOpenDepthGradMax = new NumberEdit1();
			this.lbUnitJawOpenDepthGradMax = new Label();
			this.lbUnitJawOpenDistance = new Label();
			this.nEJawOpenDistance = new NumberEdit1();
			this.lbJawOpenDistance = new Label();
			this.lbJawOpenDepthGradMin = new Label();
			this.nEJawOpenDepthGradMin = new NumberEdit1();
			this.pnMenu.SuspendLayout();
			this.gBFrictionTest.SuspendLayout();
			this.gBDepthSensor.SuspendLayout();
			this.gBAngleTorqueSensor.SuspendLayout();
			this.gBAnaSignal.SuspendLayout();
			this.gBSpindle.SuspendLayout();
			this.gBDriveUnit.SuspendLayout();
			this.gBRedundantSensor.SuspendLayout();
			this.gBPressure.SuspendLayout();
			this.gBJawOpenAutomatic.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.bt5);
			this.pnMenu.Controls.Add(this.bt4);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.btFileOperation);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 7;
			this.btCancel.Text = "Abbruch";
			this.btCancel.Click += this.btCancel_Click;
			this.btCancel.Enter += this.Start_Input;
			this.bt5.Enabled = false;
			this.bt5.Location = new Point(3, 131);
			this.bt5.Name = "bt5";
			this.bt5.Size = new Size(74, 62);
			this.bt5.TabIndex = 6;
			this.bt5.Enter += this.Start_Input;
			this.bt4.Enabled = false;
			this.bt4.Location = new Point(3, 323);
			this.bt4.Name = "bt4";
			this.bt4.Size = new Size(74, 62);
			this.bt4.TabIndex = 5;
			this.bt4.Enter += this.Start_Input;
			this.bt3.Enabled = false;
			this.bt3.Location = new Point(3, 259);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 4;
			this.bt3.Enter += this.Start_Input;
			this.bt2.Enabled = false;
			this.bt2.Location = new Point(3, 195);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 3;
			this.bt2.Enter += this.Start_Input;
			this.btFileOperation.Location = new Point(3, 387);
			this.btFileOperation.Name = "btFileOperation";
			this.btFileOperation.Size = new Size(74, 62);
			this.btFileOperation.TabIndex = 2;
			this.btFileOperation.Text = "Datei Funktionen";
			this.btFileOperation.Click += this.btFileOperation_Click;
			this.btFileOperation.Enter += this.Start_Input;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btHelp.Enter += this.Start_Input;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Speichern + Zurück";
			this.btBack.Click += this.btBack_Click;
			this.btBack.Enter += this.Start_Input;
			this.lbUnitDriveUnitRpm.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitDriveUnitRpm.Location = new Point(266, 24);
			this.lbUnitDriveUnitRpm.Name = "lbUnitDriveUnitRpm";
			this.lbUnitDriveUnitRpm.Size = new Size(56, 23);
			this.lbUnitDriveUnitRpm.TabIndex = 36;
			this.lbUnitDriveUnitRpm.Text = "U/min";
			this.lbUnitDriveUnitRpm.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitFrictionSpeed.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitFrictionSpeed.Location = new Point(266, 48);
			this.lbUnitFrictionSpeed.Name = "lbUnitFrictionSpeed";
			this.lbUnitFrictionSpeed.Size = new Size(56, 23);
			this.lbUnitFrictionSpeed.TabIndex = 35;
			this.lbUnitFrictionSpeed.Text = "%";
			this.lbUnitFrictionSpeed.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitFrictionTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitFrictionTorque.Location = new Point(266, 24);
			this.lbUnitFrictionTorque.Name = "lbUnitFrictionTorque";
			this.lbUnitFrictionTorque.Size = new Size(56, 23);
			this.lbUnitFrictionTorque.TabIndex = 34;
			this.lbUnitFrictionTorque.Text = "%";
			this.lbUnitFrictionTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.nEDriveUnitRpm.BackColor = Color.White;
			this.nEDriveUnitRpm.DecimalNum = 1;
			this.nEDriveUnitRpm.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDriveUnitRpm.ForeColor = SystemColors.ControlText;
			this.nEDriveUnitRpm.Location = new Point(186, 21);
			this.nEDriveUnitRpm.MaxValue = 20000f;
			this.nEDriveUnitRpm.MinValue = 0f;
			this.nEDriveUnitRpm.Name = "nEDriveUnitRpm";
			this.nEDriveUnitRpm.Size = new Size(72, 24);
			this.nEDriveUnitRpm.TabIndex = 0;
			this.nEDriveUnitRpm.Text = "0,0";
			this.nEDriveUnitRpm.TextAlign = HorizontalAlignment.Right;
			this.nEDriveUnitRpm.Value = 0f;
			this.nEDriveUnitRpm.TextChanged += this.settingsChanged;
			this.nEDriveUnitRpm.Enter += this.Start_Input;
			this.nEDriveUnitRpm.MouseDown += this.StartInput;
			this.nEFrictionSpeed.BackColor = Color.White;
			this.nEFrictionSpeed.DecimalNum = 0;
			this.nEFrictionSpeed.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFrictionSpeed.ForeColor = SystemColors.ControlText;
			this.nEFrictionSpeed.Location = new Point(186, 47);
			this.nEFrictionSpeed.MaxValue = 20f;
			this.nEFrictionSpeed.MinValue = 0f;
			this.nEFrictionSpeed.Name = "nEFrictionSpeed";
			this.nEFrictionSpeed.Size = new Size(72, 24);
			this.nEFrictionSpeed.TabIndex = 1;
			this.nEFrictionSpeed.Text = "0";
			this.nEFrictionSpeed.TextAlign = HorizontalAlignment.Right;
			this.nEFrictionSpeed.Value = 0f;
			this.nEFrictionSpeed.TextChanged += this.settingsChanged;
			this.nEFrictionSpeed.Enter += this.Start_Input;
			this.nEFrictionSpeed.MouseDown += this.StartInput;
			this.nEFrictionTorque.BackColor = Color.White;
			this.nEFrictionTorque.DecimalNum = 0;
			this.nEFrictionTorque.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEFrictionTorque.ForeColor = SystemColors.ControlText;
			this.nEFrictionTorque.Location = new Point(186, 23);
			this.nEFrictionTorque.MaxValue = 20f;
			this.nEFrictionTorque.MinValue = 0f;
			this.nEFrictionTorque.Name = "nEFrictionTorque";
			this.nEFrictionTorque.Size = new Size(72, 24);
			this.nEFrictionTorque.TabIndex = 0;
			this.nEFrictionTorque.Text = "0";
			this.nEFrictionTorque.TextAlign = HorizontalAlignment.Right;
			this.nEFrictionTorque.Value = 0f;
			this.nEFrictionTorque.TextChanged += this.settingsChanged;
			this.nEFrictionTorque.Enter += this.Start_Input;
			this.nEFrictionTorque.MouseDown += this.StartInput;
			this.lbDriveUnitRpm.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDriveUnitRpm.Location = new Point(8, 24);
			this.lbDriveUnitRpm.Name = "lbDriveUnitRpm";
			this.lbDriveUnitRpm.Size = new Size(176, 23);
			this.lbDriveUnitRpm.TabIndex = 33;
			this.lbDriveUnitRpm.Text = "Drehzahl";
			this.lbDriveUnitRpm.TextAlign = ContentAlignment.MiddleLeft;
			this.lbFrictionTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbFrictionTorque.Location = new Point(8, 24);
			this.lbFrictionTorque.Name = "lbFrictionTorque";
			this.lbFrictionTorque.Size = new Size(176, 23);
			this.lbFrictionTorque.TabIndex = 32;
			this.lbFrictionTorque.Text = "Reibmoment";
			this.lbFrictionTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.lbFrictionSpeed.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbFrictionSpeed.Location = new Point(8, 48);
			this.lbFrictionSpeed.Name = "lbFrictionSpeed";
			this.lbFrictionSpeed.Size = new Size(176, 23);
			this.lbFrictionSpeed.TabIndex = 31;
			this.lbFrictionSpeed.Text = "Reibdrehzahl";
			this.lbFrictionSpeed.TextAlign = ContentAlignment.MiddleLeft;
			this.chBFrictionTestStartup.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBFrictionTestStartup.Location = new Point(8, 72);
			this.chBFrictionTestStartup.Name = "chBFrictionTestStartup";
			this.chBFrictionTestStartup.Size = new Size(312, 24);
			this.chBFrictionTestStartup.TabIndex = 2;
			this.chBFrictionTestStartup.Text = "Reibwerttest beim Einschalten";
			this.chBFrictionTestStartup.CheckedChanged += this.settingsChanged;
			this.chBFrictionTestStartup.Enter += this.Start_Input;
			this.chBFrictionTestEMG.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBFrictionTestEMG.Location = new Point(8, 96);
			this.chBFrictionTestEMG.Name = "chBFrictionTestEMG";
			this.chBFrictionTestEMG.Size = new Size(312, 32);
			this.chBFrictionTestEMG.TabIndex = 3;
			this.chBFrictionTestEMG.Text = "Reibwerttest nach Notaus";
			this.chBFrictionTestEMG.CheckedChanged += this.settingsChanged;
			this.chBFrictionTestEMG.Enter += this.Start_Input;
			this.chBDriveUnitInvers.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBDriveUnitInvers.Location = new Point(8, 48);
			this.chBDriveUnitInvers.Name = "chBDriveUnitInvers";
			this.chBDriveUnitInvers.Size = new Size(221, 24);
			this.chBDriveUnitInvers.TabIndex = 1;
			this.chBDriveUnitInvers.Text = "Motor invers";
			this.chBDriveUnitInvers.CheckStateChanged += this.settingsChanged;
			this.chBDriveUnitInvers.Enter += this.Start_Input;
			this.chBAngleSensorInvers.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBAngleSensorInvers.Location = new Point(168, 94);
			this.chBAngleSensorInvers.Name = "chBAngleSensorInvers";
			this.chBAngleSensorInvers.Size = new Size(152, 24);
			this.chBAngleSensorInvers.TabIndex = 4;
			this.chBAngleSensorInvers.Text = "Winkel invers";
			this.chBAngleSensorInvers.CheckedChanged += this.settingsChanged;
			this.chBAngleSensorInvers.Enter += this.Start_Input;
			this.chBTorqueSensorInvers.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBTorqueSensorInvers.Location = new Point(8, 94);
			this.chBTorqueSensorInvers.Name = "chBTorqueSensorInvers";
			this.chBTorqueSensorInvers.Size = new Size(152, 24);
			this.chBTorqueSensorInvers.TabIndex = 3;
			this.chBTorqueSensorInvers.Text = "Moment invers_XXX";
			this.chBTorqueSensorInvers.CheckedChanged += this.settingsChanged;
			this.chBTorqueSensorInvers.Enter += this.Start_Input;
			this.lbUnitAngleSensorScale.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitAngleSensorScale.Location = new Point(264, 70);
			this.lbUnitAngleSensorScale.Name = "lbUnitAngleSensorScale";
			this.lbUnitAngleSensorScale.Size = new Size(56, 23);
			this.lbUnitAngleSensorScale.TabIndex = 45;
			this.lbUnitAngleSensorScale.Text = "°/Inc";
			this.lbUnitAngleSensorScale.TextAlign = ContentAlignment.MiddleLeft;
			this.nEAngleSensorScale.BackColor = Color.White;
			this.nEAngleSensorScale.DecimalNum = 2;
			this.nEAngleSensorScale.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAngleSensorScale.ForeColor = SystemColors.ControlText;
			this.nEAngleSensorScale.Location = new Point(184, 69);
			this.nEAngleSensorScale.MaxValue = 360f;
			this.nEAngleSensorScale.MinValue = 0.01f;
			this.nEAngleSensorScale.Name = "nEAngleSensorScale";
			this.nEAngleSensorScale.Size = new Size(72, 24);
			this.nEAngleSensorScale.TabIndex = 2;
			this.nEAngleSensorScale.Text = "0,25";
			this.nEAngleSensorScale.TextAlign = HorizontalAlignment.Right;
			this.nEAngleSensorScale.Value = 0.25f;
			this.nEAngleSensorScale.TextChanged += this.settingsChanged;
			this.nEAngleSensorScale.Enter += this.Start_Input;
			this.nEAngleSensorScale.MouseDown += this.StartInput;
			this.lbAngleSensorScale.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAngleSensorScale.Location = new Point(8, 70);
			this.lbAngleSensorScale.Name = "lbAngleSensorScale";
			this.lbAngleSensorScale.Size = new Size(176, 23);
			this.lbAngleSensorScale.TabIndex = 44;
			this.lbAngleSensorScale.Text = "Winkelauflösung";
			this.lbAngleSensorScale.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitTorqueSensorScale.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitTorqueSensorScale.Location = new Point(264, 22);
			this.lbUnitTorqueSensorScale.Name = "lbUnitTorqueSensorScale";
			this.lbUnitTorqueSensorScale.Size = new Size(56, 23);
			this.lbUnitTorqueSensorScale.TabIndex = 48;
			this.lbUnitTorqueSensorScale.Text = "Nm";
			this.lbUnitTorqueSensorScale.TextAlign = ContentAlignment.MiddleLeft;
			this.nETorqueSensorScale.BackColor = Color.White;
			this.nETorqueSensorScale.DecimalNum = 3;
			this.nETorqueSensorScale.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETorqueSensorScale.ForeColor = SystemColors.ControlText;
			this.nETorqueSensorScale.Location = new Point(184, 21);
			this.nETorqueSensorScale.MaxValue = 9999f;
			this.nETorqueSensorScale.MinValue = 0.01f;
			this.nETorqueSensorScale.Name = "nETorqueSensorScale";
			this.nETorqueSensorScale.Size = new Size(72, 24);
			this.nETorqueSensorScale.TabIndex = 0;
			this.nETorqueSensorScale.Text = "0,010";
			this.nETorqueSensorScale.TextAlign = HorizontalAlignment.Right;
			this.nETorqueSensorScale.Value = 0.01f;
			this.nETorqueSensorScale.TextChanged += this.settingsChanged;
			this.nETorqueSensorScale.Enter += this.Start_Input;
			this.nETorqueSensorScale.MouseDown += this.StartInput;
			this.lbTorqueSensorScale.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTorqueSensorScale.Location = new Point(8, 22);
			this.lbTorqueSensorScale.Name = "lbTorqueSensorScale";
			this.lbTorqueSensorScale.Size = new Size(176, 23);
			this.lbTorqueSensorScale.TabIndex = 47;
			this.lbTorqueSensorScale.Text = "Nennmoment";
			this.lbTorqueSensorScale.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitDepthSensorScale.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitDepthSensorScale.Location = new Point(264, 24);
			this.lbUnitDepthSensorScale.Name = "lbUnitDepthSensorScale";
			this.lbUnitDepthSensorScale.Size = new Size(56, 23);
			this.lbUnitDepthSensorScale.TabIndex = 51;
			this.lbUnitDepthSensorScale.Text = "mm/V";
			this.lbUnitDepthSensorScale.TextAlign = ContentAlignment.MiddleLeft;
			this.nEDepthSensorScale.BackColor = Color.White;
			this.nEDepthSensorScale.DecimalNum = 2;
			this.nEDepthSensorScale.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDepthSensorScale.ForeColor = SystemColors.ControlText;
			this.nEDepthSensorScale.Location = new Point(184, 23);
			this.nEDepthSensorScale.MaxValue = 99f;
			this.nEDepthSensorScale.MinValue = 0f;
			this.nEDepthSensorScale.Name = "nEDepthSensorScale";
			this.nEDepthSensorScale.Size = new Size(72, 24);
			this.nEDepthSensorScale.TabIndex = 0;
			this.nEDepthSensorScale.Text = "0,00";
			this.nEDepthSensorScale.TextAlign = HorizontalAlignment.Right;
			this.nEDepthSensorScale.Value = 0f;
			this.nEDepthSensorScale.TextChanged += this.settingsChanged;
			this.nEDepthSensorScale.Enter += this.Start_Input;
			this.nEDepthSensorScale.MouseDown += this.StartInput;
			this.lbDepthSensorScale.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDepthSensorScale.Location = new Point(8, 24);
			this.lbDepthSensorScale.Name = "lbDepthSensorScale";
			this.lbDepthSensorScale.Size = new Size(176, 23);
			this.lbDepthSensorScale.TabIndex = 50;
			this.lbDepthSensorScale.Text = "Skalierung";
			this.lbDepthSensorScale.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitDepthSensorOffset.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitDepthSensorOffset.Location = new Point(264, 48);
			this.lbUnitDepthSensorOffset.Name = "lbUnitDepthSensorOffset";
			this.lbUnitDepthSensorOffset.Size = new Size(56, 23);
			this.lbUnitDepthSensorOffset.TabIndex = 54;
			this.lbUnitDepthSensorOffset.Text = "mm";
			this.lbUnitDepthSensorOffset.TextAlign = ContentAlignment.MiddleLeft;
			this.nEDepthSensorOffset.BackColor = Color.White;
			this.nEDepthSensorOffset.DecimalNum = 2;
			this.nEDepthSensorOffset.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDepthSensorOffset.ForeColor = SystemColors.ControlText;
			this.nEDepthSensorOffset.Location = new Point(184, 47);
			this.nEDepthSensorOffset.MaxValue = 999f;
			this.nEDepthSensorOffset.MinValue = -999f;
			this.nEDepthSensorOffset.Name = "nEDepthSensorOffset";
			this.nEDepthSensorOffset.Size = new Size(72, 24);
			this.nEDepthSensorOffset.TabIndex = 1;
			this.nEDepthSensorOffset.Text = "0,00";
			this.nEDepthSensorOffset.TextAlign = HorizontalAlignment.Right;
			this.nEDepthSensorOffset.Value = 0f;
			this.nEDepthSensorOffset.TextChanged += this.settingsChanged;
			this.nEDepthSensorOffset.Enter += this.Start_Input;
			this.nEDepthSensorOffset.MouseDown += this.StartInput;
			this.lbDepthSensorOffset.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDepthSensorOffset.Location = new Point(8, 48);
			this.lbDepthSensorOffset.Name = "lbDepthSensorOffset";
			this.lbDepthSensorOffset.Size = new Size(176, 23);
			this.lbDepthSensorOffset.TabIndex = 53;
			this.lbDepthSensorOffset.Text = "Offset";
			this.lbDepthSensorOffset.TextAlign = ContentAlignment.MiddleLeft;
			this.nESpindleGearFactor.BackColor = Color.White;
			this.nESpindleGearFactor.DecimalNum = 2;
			this.nESpindleGearFactor.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nESpindleGearFactor.ForeColor = SystemColors.ControlText;
			this.nESpindleGearFactor.Location = new Point(186, 48);
			this.nESpindleGearFactor.MaxValue = 99f;
			this.nESpindleGearFactor.MinValue = 0.01f;
			this.nESpindleGearFactor.Name = "nESpindleGearFactor";
			this.nESpindleGearFactor.Size = new Size(72, 24);
			this.nESpindleGearFactor.TabIndex = 1;
			this.nESpindleGearFactor.Text = "1,00";
			this.nESpindleGearFactor.TextAlign = HorizontalAlignment.Right;
			this.nESpindleGearFactor.Value = 1f;
			this.nESpindleGearFactor.TextChanged += this.settingsChanged;
			this.nESpindleGearFactor.Enter += this.Start_Input;
			this.nESpindleGearFactor.MouseDown += this.StartInput;
			this.lbSpindleGearFactor.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbSpindleGearFactor.Location = new Point(8, 48);
			this.lbSpindleGearFactor.Name = "lbSpindleGearFactor";
			this.lbSpindleGearFactor.Size = new Size(176, 23);
			this.lbSpindleGearFactor.TabIndex = 56;
			this.lbSpindleGearFactor.Text = "Getriebefaktor";
			this.lbSpindleGearFactor.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitSpindleTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitSpindleTorque.Location = new Point(266, 24);
			this.lbUnitSpindleTorque.Name = "lbUnitSpindleTorque";
			this.lbUnitSpindleTorque.Size = new Size(56, 23);
			this.lbUnitSpindleTorque.TabIndex = 60;
			this.lbUnitSpindleTorque.Text = "Nm";
			this.lbUnitSpindleTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.nESpindleTorque.BackColor = Color.White;
			this.nESpindleTorque.DecimalNum = 1;
			this.nESpindleTorque.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nESpindleTorque.ForeColor = SystemColors.ControlText;
			this.nESpindleTorque.Location = new Point(186, 23);
			this.nESpindleTorque.MaxValue = 9999f;
			this.nESpindleTorque.MinValue = 0.1f;
			this.nESpindleTorque.Name = "nESpindleTorque";
			this.nESpindleTorque.Size = new Size(72, 24);
			this.nESpindleTorque.TabIndex = 0;
			this.nESpindleTorque.Text = "0,1";
			this.nESpindleTorque.TextAlign = HorizontalAlignment.Right;
			this.nESpindleTorque.Value = 0.1f;
			this.nESpindleTorque.TextChanged += this.settingsChanged;
			this.nESpindleTorque.Enter += this.Start_Input;
			this.nESpindleTorque.MouseDown += this.StartInput;
			this.lbSpindleTorque.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbSpindleTorque.Location = new Point(8, 24);
			this.lbSpindleTorque.Name = "lbSpindleTorque";
			this.lbSpindleTorque.Size = new Size(176, 23);
			this.lbSpindleTorque.TabIndex = 59;
			this.lbSpindleTorque.Text = "Schutzmoment";
			this.lbSpindleTorque.TextAlign = ContentAlignment.MiddleLeft;
			this.gBFrictionTest.Controls.Add(this.nEFrictionTorque);
			this.gBFrictionTest.Controls.Add(this.nEFrictionSpeed);
			this.gBFrictionTest.Controls.Add(this.lbUnitFrictionTorque);
			this.gBFrictionTest.Controls.Add(this.lbUnitFrictionSpeed);
			this.gBFrictionTest.Controls.Add(this.lbFrictionSpeed);
			this.gBFrictionTest.Controls.Add(this.lbFrictionTorque);
			this.gBFrictionTest.Controls.Add(this.chBFrictionTestStartup);
			this.gBFrictionTest.Controls.Add(this.chBFrictionTestEMG);
			this.gBFrictionTest.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBFrictionTest.Location = new Point(368, 300);
			this.gBFrictionTest.Name = "gBFrictionTest";
			this.gBFrictionTest.Size = new Size(328, 133);
			this.gBFrictionTest.TabIndex = 8;
			this.gBFrictionTest.TabStop = false;
			this.gBFrictionTest.Text = "Reibwerttest";
			this.gBDepthSensor.Controls.Add(this.lbUnitDepthSensorOffsetMin);
			this.gBDepthSensor.Controls.Add(this.lbDepthSensorOffsetMin);
			this.gBDepthSensor.Controls.Add(this.nEDepthSensorOffsetMin);
			this.gBDepthSensor.Controls.Add(this.lbUnitDepthSensorOffsetMax);
			this.gBDepthSensor.Controls.Add(this.lbDepthSensorOffsetMax);
			this.gBDepthSensor.Controls.Add(this.nEDepthSensorOffsetMax);
			this.gBDepthSensor.Controls.Add(this.lbUnitDepthSensorOffsetPreset);
			this.gBDepthSensor.Controls.Add(this.lbDepthSensorOffsetPreset);
			this.gBDepthSensor.Controls.Add(this.nEDepthSensorOffsetPreset);
			this.gBDepthSensor.Controls.Add(this.chBDepthSensorInvers);
			this.gBDepthSensor.Controls.Add(this.lbUnitDepthSensorOffset);
			this.gBDepthSensor.Controls.Add(this.lbDepthSensorOffset);
			this.gBDepthSensor.Controls.Add(this.nEDepthSensorOffset);
			this.gBDepthSensor.Controls.Add(this.lbUnitDepthSensorScale);
			this.gBDepthSensor.Controls.Add(this.nEDepthSensorScale);
			this.gBDepthSensor.Controls.Add(this.lbDepthSensorScale);
			this.gBDepthSensor.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBDepthSensor.Location = new Point(16, 248);
			this.gBDepthSensor.Name = "gBDepthSensor";
			this.gBDepthSensor.Size = new Size(328, 168);
			this.gBDepthSensor.TabIndex = 3;
			this.gBDepthSensor.TabStop = false;
			this.gBDepthSensor.Text = "Analoger Tiefensensor";
			this.lbUnitDepthSensorOffsetMin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitDepthSensorOffsetMin.Location = new Point(264, 93);
			this.lbUnitDepthSensorOffsetMin.Name = "lbUnitDepthSensorOffsetMin";
			this.lbUnitDepthSensorOffsetMin.Size = new Size(56, 23);
			this.lbUnitDepthSensorOffsetMin.TabIndex = 63;
			this.lbUnitDepthSensorOffsetMin.Text = "V";
			this.lbUnitDepthSensorOffsetMin.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDepthSensorOffsetMin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDepthSensorOffsetMin.Location = new Point(8, 93);
			this.lbDepthSensorOffsetMin.Name = "lbDepthSensorOffsetMin";
			this.lbDepthSensorOffsetMin.Size = new Size(176, 23);
			this.lbDepthSensorOffsetMin.TabIndex = 62;
			this.lbDepthSensorOffsetMin.Text = "Offsetspannung Min";
			this.lbDepthSensorOffsetMin.TextAlign = ContentAlignment.MiddleLeft;
			this.nEDepthSensorOffsetMin.AcceptsReturn = true;
			this.nEDepthSensorOffsetMin.BackColor = Color.White;
			this.nEDepthSensorOffsetMin.DecimalNum = 1;
			this.nEDepthSensorOffsetMin.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDepthSensorOffsetMin.ForeColor = SystemColors.ControlText;
			this.nEDepthSensorOffsetMin.Location = new Point(184, 92);
			this.nEDepthSensorOffsetMin.MaxValue = 10f;
			this.nEDepthSensorOffsetMin.MinValue = -10f;
			this.nEDepthSensorOffsetMin.Name = "nEDepthSensorOffsetMin";
			this.nEDepthSensorOffsetMin.Size = new Size(72, 24);
			this.nEDepthSensorOffsetMin.TabIndex = 3;
			this.nEDepthSensorOffsetMin.Text = "0,0";
			this.nEDepthSensorOffsetMin.TextAlign = HorizontalAlignment.Right;
			this.nEDepthSensorOffsetMin.Value = 0f;
			this.nEDepthSensorOffsetMin.TextChanged += this.settingsChanged;
			this.nEDepthSensorOffsetMin.Enter += this.Start_Input;
			this.nEDepthSensorOffsetMin.MouseDown += this.StartInput;
			this.lbUnitDepthSensorOffsetMax.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitDepthSensorOffsetMax.Location = new Point(264, 117);
			this.lbUnitDepthSensorOffsetMax.Name = "lbUnitDepthSensorOffsetMax";
			this.lbUnitDepthSensorOffsetMax.Size = new Size(56, 23);
			this.lbUnitDepthSensorOffsetMax.TabIndex = 60;
			this.lbUnitDepthSensorOffsetMax.Text = "V";
			this.lbUnitDepthSensorOffsetMax.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDepthSensorOffsetMax.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDepthSensorOffsetMax.Location = new Point(8, 117);
			this.lbDepthSensorOffsetMax.Name = "lbDepthSensorOffsetMax";
			this.lbDepthSensorOffsetMax.Size = new Size(176, 23);
			this.lbDepthSensorOffsetMax.TabIndex = 59;
			this.lbDepthSensorOffsetMax.Text = "Offsetspannung Max";
			this.lbDepthSensorOffsetMax.TextAlign = ContentAlignment.MiddleLeft;
			this.nEDepthSensorOffsetMax.BackColor = Color.White;
			this.nEDepthSensorOffsetMax.DecimalNum = 1;
			this.nEDepthSensorOffsetMax.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDepthSensorOffsetMax.ForeColor = SystemColors.ControlText;
			this.nEDepthSensorOffsetMax.Location = new Point(184, 116);
			this.nEDepthSensorOffsetMax.MaxValue = 10f;
			this.nEDepthSensorOffsetMax.MinValue = -10f;
			this.nEDepthSensorOffsetMax.Name = "nEDepthSensorOffsetMax";
			this.nEDepthSensorOffsetMax.Size = new Size(72, 24);
			this.nEDepthSensorOffsetMax.TabIndex = 4;
			this.nEDepthSensorOffsetMax.Text = "0,0";
			this.nEDepthSensorOffsetMax.TextAlign = HorizontalAlignment.Right;
			this.nEDepthSensorOffsetMax.Value = 0f;
			this.nEDepthSensorOffsetMax.TextChanged += this.settingsChanged;
			this.nEDepthSensorOffsetMax.Enter += this.Start_Input;
			this.nEDepthSensorOffsetMax.MouseDown += this.StartInput;
			this.lbUnitDepthSensorOffsetPreset.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitDepthSensorOffsetPreset.Location = new Point(264, 141);
			this.lbUnitDepthSensorOffsetPreset.Name = "lbUnitDepthSensorOffsetPreset";
			this.lbUnitDepthSensorOffsetPreset.Size = new Size(56, 23);
			this.lbUnitDepthSensorOffsetPreset.TabIndex = 57;
			this.lbUnitDepthSensorOffsetPreset.Text = "mm";
			this.lbUnitDepthSensorOffsetPreset.TextAlign = ContentAlignment.MiddleLeft;
			this.lbDepthSensorOffsetPreset.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbDepthSensorOffsetPreset.Location = new Point(8, 141);
			this.lbDepthSensorOffsetPreset.Name = "lbDepthSensorOffsetPreset";
			this.lbDepthSensorOffsetPreset.Size = new Size(176, 23);
			this.lbDepthSensorOffsetPreset.TabIndex = 56;
			this.lbDepthSensorOffsetPreset.Text = "Offset Teach Wert";
			this.lbDepthSensorOffsetPreset.TextAlign = ContentAlignment.MiddleLeft;
			this.nEDepthSensorOffsetPreset.BackColor = Color.White;
			this.nEDepthSensorOffsetPreset.DecimalNum = 1;
			this.nEDepthSensorOffsetPreset.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEDepthSensorOffsetPreset.ForeColor = SystemColors.ControlText;
			this.nEDepthSensorOffsetPreset.Location = new Point(184, 140);
			this.nEDepthSensorOffsetPreset.MaxValue = 999f;
			this.nEDepthSensorOffsetPreset.MinValue = -999f;
			this.nEDepthSensorOffsetPreset.Name = "nEDepthSensorOffsetPreset";
			this.nEDepthSensorOffsetPreset.Size = new Size(72, 24);
			this.nEDepthSensorOffsetPreset.TabIndex = 5;
			this.nEDepthSensorOffsetPreset.Text = "0,0";
			this.nEDepthSensorOffsetPreset.TextAlign = HorizontalAlignment.Right;
			this.nEDepthSensorOffsetPreset.Value = 0f;
			this.nEDepthSensorOffsetPreset.TextChanged += this.settingsChanged;
			this.nEDepthSensorOffsetPreset.Enter += this.Start_Input;
			this.nEDepthSensorOffsetPreset.MouseDown += this.StartInput;
			this.chBDepthSensorInvers.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBDepthSensorInvers.Location = new Point(8, 69);
			this.chBDepthSensorInvers.Name = "chBDepthSensorInvers";
			this.chBDepthSensorInvers.Size = new Size(205, 24);
			this.chBDepthSensorInvers.TabIndex = 2;
			this.chBDepthSensorInvers.Text = "Invertiert";
			this.chBDepthSensorInvers.CheckedChanged += this.settingsChanged;
			this.chBDepthSensorInvers.Enter += this.Start_Input;
			this.gBAngleTorqueSensor.Controls.Add(this.lbUnitTorqueSensorScale);
			this.gBAngleTorqueSensor.Controls.Add(this.lbTorqueSensorScale);
			this.gBAngleTorqueSensor.Controls.Add(this.nETorqueSensorScale);
			this.gBAngleTorqueSensor.Controls.Add(this.lbAngleSensorScale);
			this.gBAngleTorqueSensor.Controls.Add(this.nEAngleSensorScale);
			this.gBAngleTorqueSensor.Controls.Add(this.lbUnitAngleSensorScale);
			this.gBAngleTorqueSensor.Controls.Add(this.chBAngleSensorInvers);
			this.gBAngleTorqueSensor.Controls.Add(this.chBTorqueSensorInvers);
			this.gBAngleTorqueSensor.Controls.Add(this.lbUnitTorqueSensorTolerance);
			this.gBAngleTorqueSensor.Controls.Add(this.nETorqueSensorTolerance);
			this.gBAngleTorqueSensor.Controls.Add(this.lbTorqueSensorTolerance);
			this.gBAngleTorqueSensor.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBAngleTorqueSensor.Location = new Point(16, 8);
			this.gBAngleTorqueSensor.Name = "gBAngleTorqueSensor";
			this.gBAngleTorqueSensor.Size = new Size(328, 120);
			this.gBAngleTorqueSensor.TabIndex = 1;
			this.gBAngleTorqueSensor.TabStop = false;
			this.gBAngleTorqueSensor.Text = "Moment-/Winkelaufnehmer";
			this.lbUnitTorqueSensorTolerance.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitTorqueSensorTolerance.Location = new Point(264, 46);
			this.lbUnitTorqueSensorTolerance.Name = "lbUnitTorqueSensorTolerance";
			this.lbUnitTorqueSensorTolerance.Size = new Size(56, 23);
			this.lbUnitTorqueSensorTolerance.TabIndex = 51;
			this.lbUnitTorqueSensorTolerance.Text = "%";
			this.lbUnitTorqueSensorTolerance.TextAlign = ContentAlignment.MiddleLeft;
			this.nETorqueSensorTolerance.BackColor = Color.White;
			this.nETorqueSensorTolerance.DecimalNum = 1;
			this.nETorqueSensorTolerance.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETorqueSensorTolerance.ForeColor = SystemColors.ControlText;
			this.nETorqueSensorTolerance.Location = new Point(184, 45);
			this.nETorqueSensorTolerance.MaxValue = 5f;
			this.nETorqueSensorTolerance.MinValue = 0.1f;
			this.nETorqueSensorTolerance.Name = "nETorqueSensorTolerance";
			this.nETorqueSensorTolerance.Size = new Size(72, 24);
			this.nETorqueSensorTolerance.TabIndex = 1;
			this.nETorqueSensorTolerance.Text = "0,1";
			this.nETorqueSensorTolerance.TextAlign = HorizontalAlignment.Right;
			this.nETorqueSensorTolerance.Value = 0.1f;
			this.nETorqueSensorTolerance.TextChanged += this.settingsChanged;
			this.nETorqueSensorTolerance.Enter += this.Start_Input;
			this.nETorqueSensorTolerance.MouseDown += this.StartInput;
			this.lbTorqueSensorTolerance.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTorqueSensorTolerance.Location = new Point(8, 46);
			this.lbTorqueSensorTolerance.Name = "lbTorqueSensorTolerance";
			this.lbTorqueSensorTolerance.Size = new Size(176, 23);
			this.lbTorqueSensorTolerance.TabIndex = 50;
			this.lbTorqueSensorTolerance.Text = "Toleranz";
			this.lbTorqueSensorTolerance.TextAlign = ContentAlignment.MiddleLeft;
			this.lbAngleRedundantTolerance.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAngleRedundantTolerance.Location = new Point(8, 89);
			this.lbAngleRedundantTolerance.Name = "lbAngleRedundantTolerance";
			this.lbAngleRedundantTolerance.Size = new Size(176, 23);
			this.lbAngleRedundantTolerance.TabIndex = 61;
			this.lbAngleRedundantTolerance.Text = "Toleranz Winkel";
			this.lbAngleRedundantTolerance.TextAlign = ContentAlignment.MiddleLeft;
			this.nEAngleRedundantTolerance.BackColor = Color.White;
			this.nEAngleRedundantTolerance.DecimalNum = 0;
			this.nEAngleRedundantTolerance.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAngleRedundantTolerance.ForeColor = SystemColors.ControlText;
			this.nEAngleRedundantTolerance.Location = new Point(184, 89);
			this.nEAngleRedundantTolerance.MaxValue = 1000f;
			this.nEAngleRedundantTolerance.MinValue = 0f;
			this.nEAngleRedundantTolerance.Name = "nEAngleRedundantTolerance";
			this.nEAngleRedundantTolerance.Size = new Size(72, 24);
			this.nEAngleRedundantTolerance.TabIndex = 3;
			this.nEAngleRedundantTolerance.Text = "0";
			this.nEAngleRedundantTolerance.TextAlign = HorizontalAlignment.Right;
			this.nEAngleRedundantTolerance.Value = 0f;
			this.nEAngleRedundantTolerance.TextChanged += this.settingsChanged;
			this.nEAngleRedundantTolerance.Enter += this.Start_Input;
			this.nEAngleRedundantTolerance.MouseDown += this.StartInput;
			this.lbUnitAngleRedundantTolerance.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitAngleRedundantTolerance.Location = new Point(264, 89);
			this.lbUnitAngleRedundantTolerance.Name = "lbUnitAngleRedundantTolerance";
			this.lbUnitAngleRedundantTolerance.Size = new Size(56, 23);
			this.lbUnitAngleRedundantTolerance.TabIndex = 62;
			this.lbUnitAngleRedundantTolerance.Text = "Inc";
			this.lbUnitAngleRedundantTolerance.TextAlign = ContentAlignment.MiddleLeft;
			this.lbTorqueRedundantTolerance.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTorqueRedundantTolerance.Location = new Point(8, 65);
			this.lbTorqueRedundantTolerance.Name = "lbTorqueRedundantTolerance";
			this.lbTorqueRedundantTolerance.Size = new Size(176, 23);
			this.lbTorqueRedundantTolerance.TabIndex = 56;
			this.lbTorqueRedundantTolerance.Text = "Toleranz Moment";
			this.lbTorqueRedundantTolerance.TextAlign = ContentAlignment.MiddleLeft;
			this.nETorqueRedundantTolerance.BackColor = Color.White;
			this.nETorqueRedundantTolerance.DecimalNum = 1;
			this.nETorqueRedundantTolerance.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETorqueRedundantTolerance.ForeColor = SystemColors.ControlText;
			this.nETorqueRedundantTolerance.Location = new Point(184, 65);
			this.nETorqueRedundantTolerance.MaxValue = 10f;
			this.nETorqueRedundantTolerance.MinValue = 0f;
			this.nETorqueRedundantTolerance.Name = "nETorqueRedundantTolerance";
			this.nETorqueRedundantTolerance.Size = new Size(72, 24);
			this.nETorqueRedundantTolerance.TabIndex = 2;
			this.nETorqueRedundantTolerance.Text = "0,0";
			this.nETorqueRedundantTolerance.TextAlign = HorizontalAlignment.Right;
			this.nETorqueRedundantTolerance.Value = 0f;
			this.nETorqueRedundantTolerance.TextChanged += this.settingsChanged;
			this.nETorqueRedundantTolerance.Enter += this.Start_Input;
			this.nETorqueRedundantTolerance.MouseDown += this.StartInput;
			this.lbUnitTorqueRedundantTolerance.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitTorqueRedundantTolerance.Location = new Point(264, 65);
			this.lbUnitTorqueRedundantTolerance.Name = "lbUnitTorqueRedundantTolerance";
			this.lbUnitTorqueRedundantTolerance.Size = new Size(56, 23);
			this.lbUnitTorqueRedundantTolerance.TabIndex = 57;
			this.lbUnitTorqueRedundantTolerance.Text = "%";
			this.lbUnitTorqueRedundantTolerance.TextAlign = ContentAlignment.MiddleLeft;
			this.chBRedundantSensorActive.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.chBRedundantSensorActive.Location = new Point(8, 19);
			this.chBRedundantSensorActive.Name = "chBRedundantSensorActive";
			this.chBRedundantSensorActive.Size = new Size(177, 24);
			this.chBRedundantSensorActive.TabIndex = 0;
			this.chBRedundantSensorActive.Text = "Aktiv";
			this.chBRedundantSensorActive.CheckedChanged += this.chBRedundantSensorActive_CheckedChanged;
			this.chBRedundantSensorActive.CheckStateChanged += this.settingsChanged;
			this.lbUnitTorqueRedundantTime.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitTorqueRedundantTime.Location = new Point(264, 41);
			this.lbUnitTorqueRedundantTime.Name = "lbUnitTorqueRedundantTime";
			this.lbUnitTorqueRedundantTime.Size = new Size(56, 23);
			this.lbUnitTorqueRedundantTime.TabIndex = 59;
			this.lbUnitTorqueRedundantTime.Text = "s";
			this.lbUnitTorqueRedundantTime.TextAlign = ContentAlignment.MiddleLeft;
			this.nETorqueRedundantTime.BackColor = Color.White;
			this.nETorqueRedundantTime.DecimalNum = 2;
			this.nETorqueRedundantTime.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nETorqueRedundantTime.ForeColor = SystemColors.ControlText;
			this.nETorqueRedundantTime.Location = new Point(184, 41);
			this.nETorqueRedundantTime.MaxValue = 0.5f;
			this.nETorqueRedundantTime.MinValue = 0f;
			this.nETorqueRedundantTime.Name = "nETorqueRedundantTime";
			this.nETorqueRedundantTime.Size = new Size(72, 24);
			this.nETorqueRedundantTime.TabIndex = 1;
			this.nETorqueRedundantTime.Text = "0,00";
			this.nETorqueRedundantTime.TextAlign = HorizontalAlignment.Right;
			this.nETorqueRedundantTime.Value = 0f;
			this.nETorqueRedundantTime.TextChanged += this.settingsChanged;
			this.nETorqueRedundantTime.Enter += this.Start_Input;
			this.nETorqueRedundantTime.MouseDown += this.StartInput;
			this.lbTorqueRedundantTime.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbTorqueRedundantTime.Location = new Point(8, 41);
			this.lbTorqueRedundantTime.Name = "lbTorqueRedundantTime";
			this.lbTorqueRedundantTime.Size = new Size(176, 23);
			this.lbTorqueRedundantTime.TabIndex = 58;
			this.lbTorqueRedundantTime.Text = "Toleranzzeit Moment";
			this.lbTorqueRedundantTime.TextAlign = ContentAlignment.MiddleLeft;
			this.gBAnaSignal.Controls.Add(this.lbUnitAnaSigScale);
			this.gBAnaSignal.Controls.Add(this.lbUnitAnaSigOffset);
			this.gBAnaSignal.Controls.Add(this.lbAnaSigOffset);
			this.gBAnaSignal.Controls.Add(this.nEAnaSigOffset);
			this.gBAnaSignal.Controls.Add(this.nEAnaSigScale);
			this.gBAnaSignal.Controls.Add(this.lbAnaSigScale);
			this.gBAnaSignal.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBAnaSignal.Location = new Point(368, 439);
			this.gBAnaSignal.Name = "gBAnaSignal";
			this.gBAnaSignal.Size = new Size(328, 78);
			this.gBAnaSignal.TabIndex = 9;
			this.gBAnaSignal.TabStop = false;
			this.gBAnaSignal.Text = "Externes analoges Signal";
			this.lbUnitAnaSigScale.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitAnaSigScale.Location = new Point(266, 24);
			this.lbUnitAnaSigScale.Name = "lbUnitAnaSigScale";
			this.lbUnitAnaSigScale.Size = new Size(56, 23);
			this.lbUnitAnaSigScale.TabIndex = 55;
			this.lbUnitAnaSigScale.Text = "kN/1V";
			this.lbUnitAnaSigOffset.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitAnaSigOffset.Location = new Point(266, 48);
			this.lbUnitAnaSigOffset.Name = "lbUnitAnaSigOffset";
			this.lbUnitAnaSigOffset.Size = new Size(56, 23);
			this.lbUnitAnaSigOffset.TabIndex = 54;
			this.lbUnitAnaSigOffset.Text = "V";
			this.lbAnaSigOffset.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAnaSigOffset.Location = new Point(8, 48);
			this.lbAnaSigOffset.Name = "lbAnaSigOffset";
			this.lbAnaSigOffset.Size = new Size(176, 23);
			this.lbAnaSigOffset.TabIndex = 53;
			this.lbAnaSigOffset.Text = "Offset";
			this.lbAnaSigOffset.TextAlign = ContentAlignment.MiddleLeft;
			this.nEAnaSigOffset.BackColor = Color.White;
			this.nEAnaSigOffset.DecimalNum = 2;
			this.nEAnaSigOffset.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAnaSigOffset.ForeColor = SystemColors.ControlText;
			this.nEAnaSigOffset.Location = new Point(186, 47);
			this.nEAnaSigOffset.MaxValue = 10f;
			this.nEAnaSigOffset.MinValue = -10f;
			this.nEAnaSigOffset.Name = "nEAnaSigOffset";
			this.nEAnaSigOffset.Size = new Size(72, 24);
			this.nEAnaSigOffset.TabIndex = 1;
			this.nEAnaSigOffset.Text = "0,00";
			this.nEAnaSigOffset.TextAlign = HorizontalAlignment.Right;
			this.nEAnaSigOffset.Value = 0f;
			this.nEAnaSigOffset.TextChanged += this.settingsChanged;
			this.nEAnaSigOffset.Enter += this.Start_Input;
			this.nEAnaSigOffset.MouseDown += this.StartInput;
			this.nEAnaSigScale.BackColor = Color.White;
			this.nEAnaSigScale.DecimalNum = 2;
			this.nEAnaSigScale.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEAnaSigScale.ForeColor = SystemColors.ControlText;
			this.nEAnaSigScale.Location = new Point(186, 23);
			this.nEAnaSigScale.MaxValue = 9999f;
			this.nEAnaSigScale.MinValue = 0f;
			this.nEAnaSigScale.Name = "nEAnaSigScale";
			this.nEAnaSigScale.Size = new Size(72, 24);
			this.nEAnaSigScale.TabIndex = 0;
			this.nEAnaSigScale.Text = "0,00";
			this.nEAnaSigScale.TextAlign = HorizontalAlignment.Right;
			this.nEAnaSigScale.Value = 0f;
			this.nEAnaSigScale.TextChanged += this.settingsChanged;
			this.nEAnaSigScale.Enter += this.Start_Input;
			this.nEAnaSigScale.MouseDown += this.StartInput;
			this.lbAnaSigScale.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbAnaSigScale.Location = new Point(8, 24);
			this.lbAnaSigScale.Name = "lbAnaSigScale";
			this.lbAnaSigScale.Size = new Size(176, 23);
			this.lbAnaSigScale.TabIndex = 50;
			this.lbAnaSigScale.Text = "Skalierung";
			this.lbAnaSigScale.TextAlign = ContentAlignment.MiddleLeft;
			this.gBSpindle.Controls.Add(this.lbReleaseSpeed);
			this.gBSpindle.Controls.Add(this.nEReleaseSpeed);
			this.gBSpindle.Controls.Add(this.lbUnitReleaseSpeed);
			this.gBSpindle.Controls.Add(this.lbSpindleGearFactor);
			this.gBSpindle.Controls.Add(this.nESpindleGearFactor);
			this.gBSpindle.Controls.Add(this.lbSpindleTorque);
			this.gBSpindle.Controls.Add(this.nESpindleTorque);
			this.gBSpindle.Controls.Add(this.lbUnitSpindleTorque);
			this.gBSpindle.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBSpindle.Location = new Point(368, 174);
			this.gBSpindle.Name = "gBSpindle";
			this.gBSpindle.Size = new Size(328, 115);
			this.gBSpindle.TabIndex = 7;
			this.gBSpindle.TabStop = false;
			this.gBSpindle.Text = "Spindel";
			this.lbReleaseSpeed.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbReleaseSpeed.Location = new Point(8, 72);
			this.lbReleaseSpeed.Name = "lbReleaseSpeed";
			this.lbReleaseSpeed.Size = new Size(176, 37);
			this.lbReleaseSpeed.TabIndex = 62;
			this.lbReleaseSpeed.Text = "Entspanndrehzahl";
			this.nEReleaseSpeed.BackColor = Color.White;
			this.nEReleaseSpeed.DecimalNum = 0;
			this.nEReleaseSpeed.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEReleaseSpeed.ForeColor = SystemColors.ControlText;
			this.nEReleaseSpeed.Location = new Point(186, 71);
			this.nEReleaseSpeed.MaxValue = 1000f;
			this.nEReleaseSpeed.MinValue = 1f;
			this.nEReleaseSpeed.Name = "nEReleaseSpeed";
			this.nEReleaseSpeed.Size = new Size(72, 24);
			this.nEReleaseSpeed.TabIndex = 2;
			this.nEReleaseSpeed.Text = "1";
			this.nEReleaseSpeed.TextAlign = HorizontalAlignment.Right;
			this.nEReleaseSpeed.Value = 1f;
			this.nEReleaseSpeed.TextChanged += this.settingsChanged;
			this.nEReleaseSpeed.Enter += this.Start_Input;
			this.nEReleaseSpeed.MouseDown += this.StartInput;
			this.lbUnitReleaseSpeed.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitReleaseSpeed.Location = new Point(266, 72);
			this.lbUnitReleaseSpeed.Name = "lbUnitReleaseSpeed";
			this.lbUnitReleaseSpeed.Size = new Size(56, 23);
			this.lbUnitReleaseSpeed.TabIndex = 63;
			this.lbUnitReleaseSpeed.Text = "U/min";
			this.lbUnitReleaseSpeed.TextAlign = ContentAlignment.MiddleLeft;
			this.gBDriveUnit.Controls.Add(this.chBDriveUnitInvers);
			this.gBDriveUnit.Controls.Add(this.lbDriveUnitRpm);
			this.gBDriveUnit.Controls.Add(this.nEDriveUnitRpm);
			this.gBDriveUnit.Controls.Add(this.lbUnitDriveUnitRpm);
			this.gBDriveUnit.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBDriveUnit.Location = new Point(368, 8);
			this.gBDriveUnit.Name = "gBDriveUnit";
			this.gBDriveUnit.Size = new Size(328, 76);
			this.gBDriveUnit.TabIndex = 5;
			this.gBDriveUnit.TabStop = false;
			this.gBDriveUnit.Text = "Antriebssatz";
			this.openFileDialog.Filter = "Spindle Constants|*.wspc|All Files|*.*";
			this.saveFileDialog.Filter = "Spindle Constants|*.wspc|All Files|*.*";
			this.gBRedundantSensor.Controls.Add(this.lbUnitAngleRedundantTolerance);
			this.gBRedundantSensor.Controls.Add(this.lbTorqueRedundantTolerance);
			this.gBRedundantSensor.Controls.Add(this.nETorqueRedundantTolerance);
			this.gBRedundantSensor.Controls.Add(this.lbUnitTorqueRedundantTolerance);
			this.gBRedundantSensor.Controls.Add(this.chBRedundantSensorActive);
			this.gBRedundantSensor.Controls.Add(this.lbUnitTorqueRedundantTime);
			this.gBRedundantSensor.Controls.Add(this.nETorqueRedundantTime);
			this.gBRedundantSensor.Controls.Add(this.lbTorqueRedundantTime);
			this.gBRedundantSensor.Controls.Add(this.lbAngleRedundantTolerance);
			this.gBRedundantSensor.Controls.Add(this.nEAngleRedundantTolerance);
			this.gBRedundantSensor.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBRedundantSensor.Location = new Point(16, 129);
			this.gBRedundantSensor.Name = "gBRedundantSensor";
			this.gBRedundantSensor.Size = new Size(328, 116);
			this.gBRedundantSensor.TabIndex = 2;
			this.gBRedundantSensor.TabStop = false;
			this.gBRedundantSensor.Text = "Redundanter Moment-/Winkelaufnehmer";
			this.gBPressure.Controls.Add(this.lbUnitHolderPressureScale);
			this.gBPressure.Controls.Add(this.lbUnitSpindlePressureScale);
			this.gBPressure.Controls.Add(this.lbHolderPressureScale);
			this.gBPressure.Controls.Add(this.nEHolderPressureScale);
			this.gBPressure.Controls.Add(this.lbSpindlePressureScale);
			this.gBPressure.Controls.Add(this.nESpindlePressureScale);
			this.gBPressure.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBPressure.Location = new Point(368, 93);
			this.gBPressure.Name = "gBPressure";
			this.gBPressure.Size = new Size(328, 74);
			this.gBPressure.TabIndex = 6;
			this.gBPressure.TabStop = false;
			this.gBPressure.Text = "Niederhalterdruck";
			this.lbUnitHolderPressureScale.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitHolderPressureScale.Location = new Point(262, 43);
			this.lbUnitHolderPressureScale.Name = "lbUnitHolderPressureScale";
			this.lbUnitHolderPressureScale.Size = new Size(56, 23);
			this.lbUnitHolderPressureScale.TabIndex = 57;
			this.lbUnitHolderPressureScale.Text = "kN";
			this.lbUnitSpindlePressureScale.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitSpindlePressureScale.Location = new Point(262, 19);
			this.lbUnitSpindlePressureScale.Name = "lbUnitSpindlePressureScale";
			this.lbUnitSpindlePressureScale.Size = new Size(56, 23);
			this.lbUnitSpindlePressureScale.TabIndex = 56;
			this.lbUnitSpindlePressureScale.Text = "kN";
			this.lbHolderPressureScale.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbHolderPressureScale.Location = new Point(6, 43);
			this.lbHolderPressureScale.Name = "lbHolderPressureScale";
			this.lbHolderPressureScale.Size = new Size(176, 23);
			this.lbHolderPressureScale.TabIndex = 35;
			this.lbHolderPressureScale.Text = "Druckskalierung Niederh.";
			this.lbHolderPressureScale.TextAlign = ContentAlignment.MiddleLeft;
			this.nEHolderPressureScale.BackColor = Color.White;
			this.nEHolderPressureScale.DecimalNum = 2;
			this.nEHolderPressureScale.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEHolderPressureScale.ForeColor = SystemColors.ControlText;
			this.nEHolderPressureScale.Location = new Point(184, 43);
			this.nEHolderPressureScale.MaxValue = 10000f;
			this.nEHolderPressureScale.MinValue = 0f;
			this.nEHolderPressureScale.Name = "nEHolderPressureScale";
			this.nEHolderPressureScale.Size = new Size(72, 24);
			this.nEHolderPressureScale.TabIndex = 1;
			this.nEHolderPressureScale.Text = "0,12";
			this.nEHolderPressureScale.TextAlign = HorizontalAlignment.Right;
			this.nEHolderPressureScale.Value = 0.12f;
			this.nEHolderPressureScale.TextChanged += this.settingsChanged;
			this.nEHolderPressureScale.Enter += this.Start_Input;
			this.nEHolderPressureScale.MouseDown += this.StartInput;
			this.lbSpindlePressureScale.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbSpindlePressureScale.Location = new Point(6, 19);
			this.lbSpindlePressureScale.Name = "lbSpindlePressureScale";
			this.lbSpindlePressureScale.Size = new Size(176, 23);
			this.lbSpindlePressureScale.TabIndex = 33;
			this.lbSpindlePressureScale.Text = "Zylinderkraft bei 6 Bar";
			this.lbSpindlePressureScale.TextAlign = ContentAlignment.MiddleLeft;
			this.nESpindlePressureScale.BackColor = Color.White;
			this.nESpindlePressureScale.DecimalNum = 1;
			this.nESpindlePressureScale.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nESpindlePressureScale.ForeColor = SystemColors.ControlText;
			this.nESpindlePressureScale.Location = new Point(184, 19);
			this.nESpindlePressureScale.MaxValue = 10000f;
			this.nESpindlePressureScale.MinValue = 0f;
			this.nESpindlePressureScale.Name = "nESpindlePressureScale";
			this.nESpindlePressureScale.Size = new Size(72, 24);
			this.nESpindlePressureScale.TabIndex = 0;
			this.nESpindlePressureScale.Text = "0,0";
			this.nESpindlePressureScale.TextAlign = HorizontalAlignment.Right;
			this.nESpindlePressureScale.Value = 0f;
			this.nESpindlePressureScale.TextChanged += this.settingsChanged;
			this.nESpindlePressureScale.Enter += this.Start_Input;
			this.nESpindlePressureScale.MouseDown += this.StartInput;
			this.gBJawOpenAutomatic.Controls.Add(this.lbUnitJawOpenDepthGradMin);
			this.gBJawOpenAutomatic.Controls.Add(this.lbJawOpenDepthGradMax);
			this.gBJawOpenAutomatic.Controls.Add(this.nEJawOpenDepthGradMax);
			this.gBJawOpenAutomatic.Controls.Add(this.lbUnitJawOpenDepthGradMax);
			this.gBJawOpenAutomatic.Controls.Add(this.lbUnitJawOpenDistance);
			this.gBJawOpenAutomatic.Controls.Add(this.nEJawOpenDistance);
			this.gBJawOpenAutomatic.Controls.Add(this.lbJawOpenDistance);
			this.gBJawOpenAutomatic.Controls.Add(this.lbJawOpenDepthGradMin);
			this.gBJawOpenAutomatic.Controls.Add(this.nEJawOpenDepthGradMin);
			this.gBJawOpenAutomatic.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.gBJawOpenAutomatic.Location = new Point(16, 421);
			this.gBJawOpenAutomatic.Name = "gBJawOpenAutomatic";
			this.gBJawOpenAutomatic.Size = new Size(328, 98);
			this.gBJawOpenAutomatic.TabIndex = 4;
			this.gBJawOpenAutomatic.TabStop = false;
			this.gBJawOpenAutomatic.Text = "Automatische Klinkenöffnung";
			this.lbUnitJawOpenDepthGradMin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitJawOpenDepthGradMin.Location = new Point(264, 69);
			this.lbUnitJawOpenDepthGradMin.Name = "lbUnitJawOpenDepthGradMin";
			this.lbUnitJawOpenDepthGradMin.Size = new Size(56, 23);
			this.lbUnitJawOpenDepthGradMin.TabIndex = 62;
			this.lbUnitJawOpenDepthGradMin.Text = "mm/s";
			this.lbUnitJawOpenDepthGradMin.TextAlign = ContentAlignment.MiddleLeft;
			this.lbJawOpenDepthGradMax.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbJawOpenDepthGradMax.Location = new Point(8, 45);
			this.lbJawOpenDepthGradMax.Name = "lbJawOpenDepthGradMax";
			this.lbJawOpenDepthGradMax.Size = new Size(177, 23);
			this.lbJawOpenDepthGradMax.TabIndex = 56;
			this.lbJawOpenDepthGradMax.Text = "Maximaler Tiefengradient";
			this.lbJawOpenDepthGradMax.TextAlign = ContentAlignment.MiddleLeft;
			this.nEJawOpenDepthGradMax.BackColor = Color.White;
			this.nEJawOpenDepthGradMax.DecimalNum = 0;
			this.nEJawOpenDepthGradMax.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEJawOpenDepthGradMax.ForeColor = SystemColors.ControlText;
			this.nEJawOpenDepthGradMax.Location = new Point(184, 45);
			this.nEJawOpenDepthGradMax.MaxValue = 1000f;
			this.nEJawOpenDepthGradMax.MinValue = 0f;
			this.nEJawOpenDepthGradMax.Name = "nEJawOpenDepthGradMax";
			this.nEJawOpenDepthGradMax.Size = new Size(72, 24);
			this.nEJawOpenDepthGradMax.TabIndex = 1;
			this.nEJawOpenDepthGradMax.Text = "500";
			this.nEJawOpenDepthGradMax.TextAlign = HorizontalAlignment.Right;
			this.nEJawOpenDepthGradMax.Value = 500f;
			this.nEJawOpenDepthGradMax.TextChanged += this.settingsChanged;
			this.nEJawOpenDepthGradMax.Enter += this.Start_Input;
			this.nEJawOpenDepthGradMax.MouseDown += this.StartInput;
			this.lbUnitJawOpenDepthGradMax.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitJawOpenDepthGradMax.Location = new Point(264, 45);
			this.lbUnitJawOpenDepthGradMax.Name = "lbUnitJawOpenDepthGradMax";
			this.lbUnitJawOpenDepthGradMax.Size = new Size(56, 23);
			this.lbUnitJawOpenDepthGradMax.TabIndex = 57;
			this.lbUnitJawOpenDepthGradMax.Text = "mm/s";
			this.lbUnitJawOpenDepthGradMax.TextAlign = ContentAlignment.MiddleLeft;
			this.lbUnitJawOpenDistance.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbUnitJawOpenDistance.Location = new Point(264, 21);
			this.lbUnitJawOpenDistance.Name = "lbUnitJawOpenDistance";
			this.lbUnitJawOpenDistance.Size = new Size(56, 23);
			this.lbUnitJawOpenDistance.TabIndex = 59;
			this.lbUnitJawOpenDistance.Text = "mm";
			this.lbUnitJawOpenDistance.TextAlign = ContentAlignment.MiddleLeft;
			this.nEJawOpenDistance.BackColor = Color.White;
			this.nEJawOpenDistance.DecimalNum = 2;
			this.nEJawOpenDistance.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEJawOpenDistance.ForeColor = SystemColors.ControlText;
			this.nEJawOpenDistance.Location = new Point(184, 21);
			this.nEJawOpenDistance.MaxValue = 100f;
			this.nEJawOpenDistance.MinValue = 0f;
			this.nEJawOpenDistance.Name = "nEJawOpenDistance";
			this.nEJawOpenDistance.Size = new Size(72, 24);
			this.nEJawOpenDistance.TabIndex = 0;
			this.nEJawOpenDistance.Text = "2,00";
			this.nEJawOpenDistance.TextAlign = HorizontalAlignment.Right;
			this.nEJawOpenDistance.Value = 2f;
			this.nEJawOpenDistance.TextChanged += this.settingsChanged;
			this.nEJawOpenDistance.Enter += this.Start_Input;
			this.nEJawOpenDistance.MouseDown += this.StartInput;
			this.lbJawOpenDistance.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbJawOpenDistance.Location = new Point(8, 21);
			this.lbJawOpenDistance.Name = "lbJawOpenDistance";
			this.lbJawOpenDistance.Size = new Size(177, 23);
			this.lbJawOpenDistance.TabIndex = 58;
			this.lbJawOpenDistance.Text = "Einschraub Tiefe";
			this.lbJawOpenDistance.TextAlign = ContentAlignment.MiddleLeft;
			this.lbJawOpenDepthGradMin.Font = new Font("Arial Unicode MS", 13f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.lbJawOpenDepthGradMin.Location = new Point(8, 69);
			this.lbJawOpenDepthGradMin.Name = "lbJawOpenDepthGradMin";
			this.lbJawOpenDepthGradMin.Size = new Size(177, 23);
			this.lbJawOpenDepthGradMin.TabIndex = 61;
			this.lbJawOpenDepthGradMin.Text = "Minimaler Tiefengradient";
			this.lbJawOpenDepthGradMin.TextAlign = ContentAlignment.MiddleLeft;
			this.nEJawOpenDepthGradMin.BackColor = Color.White;
			this.nEJawOpenDepthGradMin.DecimalNum = 0;
			this.nEJawOpenDepthGradMin.Font = new Font("Arial Unicode MS", 12f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			this.nEJawOpenDepthGradMin.ForeColor = SystemColors.ControlText;
			this.nEJawOpenDepthGradMin.Location = new Point(184, 69);
			this.nEJawOpenDepthGradMin.MaxValue = 1000f;
			this.nEJawOpenDepthGradMin.MinValue = 0f;
			this.nEJawOpenDepthGradMin.Name = "nEJawOpenDepthGradMin";
			this.nEJawOpenDepthGradMin.Size = new Size(72, 24);
			this.nEJawOpenDepthGradMin.TabIndex = 2;
			this.nEJawOpenDepthGradMin.Text = "200";
			this.nEJawOpenDepthGradMin.TextAlign = HorizontalAlignment.Right;
			this.nEJawOpenDepthGradMin.Value = 200f;
			this.nEJawOpenDepthGradMin.TextChanged += this.settingsChanged;
			this.nEJawOpenDepthGradMin.Enter += this.Start_Input;
			this.nEJawOpenDepthGradMin.MouseDown += this.StartInput;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.gBJawOpenAutomatic);
			base.Controls.Add(this.gBPressure);
			base.Controls.Add(this.gBRedundantSensor);
			base.Controls.Add(this.gBDriveUnit);
			base.Controls.Add(this.gBSpindle);
			base.Controls.Add(this.gBAnaSignal);
			base.Controls.Add(this.gBAngleTorqueSensor);
			base.Controls.Add(this.gBDepthSensor);
			base.Controls.Add(this.gBFrictionTest);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "SpindleConstantsForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Einstellungen/Spindelkonstanten";
			base.Activated += this.SpindleConstantsForm_Activated;
			this.pnMenu.ResumeLayout(false);
			this.gBFrictionTest.ResumeLayout(false);
			this.gBFrictionTest.PerformLayout();
			this.gBDepthSensor.ResumeLayout(false);
			this.gBDepthSensor.PerformLayout();
			this.gBAngleTorqueSensor.ResumeLayout(false);
			this.gBAngleTorqueSensor.PerformLayout();
			this.gBAnaSignal.ResumeLayout(false);
			this.gBAnaSignal.PerformLayout();
			this.gBSpindle.ResumeLayout(false);
			this.gBSpindle.PerformLayout();
			this.gBDriveUnit.ResumeLayout(false);
			this.gBDriveUnit.PerformLayout();
			this.gBRedundantSensor.ResumeLayout(false);
			this.gBRedundantSensor.PerformLayout();
			this.gBPressure.ResumeLayout(false);
			this.gBPressure.PerformLayout();
			this.gBJawOpenAutomatic.ResumeLayout(false);
			this.gBJawOpenAutomatic.PerformLayout();
			base.ResumeLayout(false);
		}

		public bool ShowWindow()
		{
			this.Main.ResetBrowserGrantedBy();
			if (!this.LoadSpindleConstants())
			{
				return false;
			}
			this.bInitialize = true;
			base.Show();
			this.bInitialize = false;
			return true;
		}

		public bool LoadSpindleConstants()
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else
			{
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadSpindleConst"));
				if (!this.Main.VC.ReceiveVarBlock(11))
				{
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
					MessageBox.Show("Could not receive SysConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return false;
				}
				this.SetLanguageTexts();
			}
			this.CopySpindleStruct(ref this.TempSpindleStruct, this.Main.VC.SpConst);
			this.Initialize(this.TempSpindleStruct);
			return true;
		}

		private void Initialize(WSP1_VarComm.SpConst_Struct ts)
		{
			this.bInitialize = true;
			if (ts.AngleSensorInvers == 1)
			{
				this.chBAngleSensorInvers.Checked = true;
			}
			else
			{
				this.chBAngleSensorInvers.Checked = false;
			}
			if (ts.FrictionTestEMG == 1)
			{
				this.chBFrictionTestEMG.Checked = true;
			}
			else
			{
				this.chBFrictionTestEMG.Checked = false;
			}
			if (ts.FrictionTestStartup == 1)
			{
				this.chBFrictionTestStartup.Checked = true;
			}
			else
			{
				this.chBFrictionTestStartup.Checked = false;
			}
			if (ts.DriveUnitInvers == 1)
			{
				this.chBDriveUnitInvers.Checked = true;
			}
			else
			{
				this.chBDriveUnitInvers.Checked = false;
			}
			if (ts.TorqueSensorInvers == 1)
			{
				this.chBTorqueSensorInvers.Checked = true;
			}
			else
			{
				this.chBTorqueSensorInvers.Checked = false;
			}
			if (ts.DepthSensorInvers == 1)
			{
				this.chBDepthSensorInvers.Checked = true;
			}
			else
			{
				this.chBDepthSensorInvers.Checked = false;
			}
			if (ts.RedundantSensorActive == 1)
			{
				this.chBRedundantSensorActive.Checked = true;
				this.nETorqueRedundantTime.Enabled = true;
				this.nETorqueRedundantTolerance.Enabled = true;
				this.nEAngleRedundantTolerance.Enabled = true;
			}
			else
			{
				this.chBRedundantSensorActive.Checked = false;
				this.nETorqueRedundantTime.Enabled = false;
				this.nETorqueRedundantTolerance.Enabled = false;
				this.nEAngleRedundantTolerance.Enabled = false;
			}
			this.nEFrictionSpeed.Value = ts.FrictionSpeed;
			this.nEFrictionTorque.Value = ts.FrictionTorque;
			this.nEDriveUnitRpm.Value = ts.DriveUnitRpm;
			this.nESpindlePressureScale.MaxValue = 5f;
			this.nESpindlePressureScale.Value = ts.PressureScaleSpindle * 6f;
			this.nEHolderPressureScale.MaxValue = 2f;
			this.nEHolderPressureScale.Value = ts.PressureScaleHolder * 6f;
			this.nEAnaSigScale.Value = ts.AnaSigScale;
			this.nEDepthSensorScale.Value = ts.DepthSensorScale;
			this.nETorqueSensorScale.Value = ts.TorqueSensorScale;
			this.nEAnaSigOffset.Value = ts.AnaSigOffset;
			this.nEDepthSensorOffset.Value = ts.DepthSensorOffset;
			this.nEAngleSensorScale.Value = ts.AngleSensorScale;
			this.nETorqueSensorTolerance.Value = ts.TorqueSensorTolerance;
			this.nETorqueRedundantTime.Value = ts.TorqueRedundantTime;
			this.nETorqueRedundantTolerance.Value = ts.TorqueRedundantTolerance;
			this.nEAngleRedundantTolerance.Value = (float)ts.AngleRedundantTolerance;
			this.nESpindleGearFactor.Value = ts.SpindleGearFactor;
			this.nESpindleTorque.Value = ts.SpindleTorque;
			this.nEReleaseSpeed.Value = ts.ReleaseSpeed;
			this.nEDepthSensorOffsetMin.Value = ts.DepthSensorOffsetMin;
			this.nEDepthSensorOffsetMax.Value = ts.DepthSensorOffsetMax;
			this.nEDepthSensorOffsetPreset.Value = ts.DepthSensorOffsetPreset;
			this.nEJawOpenDistance.Value = ts.JawOpenDistance;
			this.nEJawOpenDepthGradMin.Value = ts.JawOpenDepthGradMin;
			this.nEJawOpenDepthGradMax.Value = ts.JawOpenDepthGradMax;
			Cursor.Current = Cursors.Default;
			this.Main.StatusBarText(string.Empty);
			this.MenEna();
			this.bInitialize = false;
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MSpindleConstants");
			this.lbAnaSigOffset.Text = this.Main.Rm.GetString("AnaSigOffset");
			this.lbAnaSigScale.Text = this.Main.Rm.GetString("AnaSigScale");
			this.lbAngleSensorScale.Text = this.Main.Rm.GetString("AngleSensorScale");
			this.lbDepthSensorOffset.Text = this.Main.Rm.GetString("AnaSigOffset");
			this.lbDepthSensorScale.Text = this.Main.Rm.GetString("AnaSigScale");
			this.lbDepthSensorOffsetMin.Text = this.Main.Rm.GetString("OffsetVoltageMin");
			this.lbDepthSensorOffsetMax.Text = this.Main.Rm.GetString("OffsetVoltageMax");
			this.lbDepthSensorOffsetPreset.Text = this.Main.Rm.GetString("OffsetTeachValue");
			this.lbDriveUnitRpm.Text = this.Main.Rm.GetString("MaxRpm");
			this.lbHolderPressureScale.Text = this.Main.Rm.GetString("HolderPressureScale");
			this.lbFrictionSpeed.Text = this.Main.Rm.GetString("FrictionSpeed");
			this.lbFrictionTorque.Text = this.Main.Rm.GetString("MaxFrictionTorque");
			this.lbReleaseSpeed.Text = this.Main.Rm.GetString("ReleaseSpeed");
			this.lbSpindleGearFactor.Text = this.Main.Rm.GetString("GearFactor");
			this.lbSpindleTorque.Text = this.Main.Rm.GetString("SpindleTorque");
			this.lbTorqueSensorScale.Text = this.Main.Rm.GetString("TorqueSensorScale");
			this.lbTorqueSensorTolerance.Text = this.Main.Rm.GetString("TorqueSensorTolerance");
			this.lbTorqueRedundantTime.Text = this.Main.Rm.GetString("TorqueRedundantTime");
			this.lbTorqueRedundantTolerance.Text = this.Main.Rm.GetString("TorqueRedundantTolerance");
			this.lbAngleRedundantTolerance.Text = this.Main.Rm.GetString("AngleRedundantTolerance");
			this.lbUnitAngleSensorScale.Text = this.Main.Rm.GetString("Degree") + "/" + this.Main.Rm.GetString("Increment");
			this.lbUnitDriveUnitRpm.Text = this.Main.Rm.GetString("RpmUnit");
			this.lbUnitReleaseSpeed.Text = this.Main.Rm.GetString("RpmUnit");
			this.gBAnaSignal.Text = this.Main.Rm.GetString("gBAnaSignal");
			this.gBAngleTorqueSensor.Text = this.Main.Rm.GetString("AngleTorqueSensor");
			this.gBDepthSensor.Text = this.Main.Rm.GetString("DepthSensor");
			this.gBDriveUnit.Text = this.Main.Rm.GetString("DriveUnit");
			this.gBPressure.Text = this.Main.Rm.GetString("gBPressure");
			this.gBFrictionTest.Text = this.Main.Rm.GetString("FrictionTest");
			this.gBSpindle.Text = this.Main.Rm.GetString("gBSpindle");
			this.gBRedundantSensor.Text = this.Main.Rm.GetString("gBRedundantSensor");
			this.btBack.Text = this.Main.Rm.GetString("StoreAndBack");
			this.btCancel.Text = this.Main.Rm.GetString("Cancel");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btFileOperation.Text = this.Main.Rm.GetString("FileOperation");
			this.chBAngleSensorInvers.Text = this.Main.Rm.GetString("AngleSensorInvers");
			this.chBDepthSensorInvers.Text = this.Main.Rm.GetString("DepthSensorInvers");
			this.chBDriveUnitInvers.Text = this.Main.Rm.GetString("DriveUnitInvers");
			this.chBFrictionTestEMG.Text = this.Main.Rm.GetString("FrictionTestEMG");
			this.chBFrictionTestStartup.Text = this.Main.Rm.GetString("FrictionTestStartup");
			this.chBTorqueSensorInvers.Text = this.Main.Rm.GetString("TorqueSensorInvers");
			this.chBRedundantSensorActive.Text = this.Main.Rm.GetString("RedundantSensorActive");
			this.lbUnitTorqueSensorTolerance.Text = this.Main.Rm.GetString("Percent");
			this.lbUnitFrictionTorque.Text = this.Main.Rm.GetString("Percent");
			this.lbUnitFrictionSpeed.Text = this.Main.Rm.GetString("Percent");
			this.lbUnitDepthSensorScale.Text = this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Voltage");
			this.lbSpindlePressureScale.Text = this.Main.Rm.GetString("CylinderPressureScale6");
			this.lbUnitSpindlePressureScale.Text = this.Main.Rm.GetString("KiloNewton");
			this.lbSpindlePressureScale.Visible = true;
			this.lbUnitSpindlePressureScale.Visible = true;
			this.nESpindlePressureScale.Visible = true;
			this.lbUnitHolderPressureScale.Text = this.Main.Rm.GetString("KiloNewton");
			this.lbUnitDepthSensorOffset.Text = this.Main.Rm.GetString("Milimeter");
			this.lbUnitAnaSigScale.Text = this.Main.Rm.GetString("KiloNewton") + "/" + this.Main.Rm.GetString("Voltage");
			this.lbUnitAnaSigOffset.Text = this.Main.Rm.GetString("Voltage");
			this.lbUnitTorqueSensorScale.Text = this.Main.Rm.GetString("TorqueNm");
			this.lbUnitTorqueRedundantTime.Text = this.Main.Rm.GetString("Second");
			this.lbUnitTorqueRedundantTolerance.Text = this.Main.Rm.GetString("Percent");
			this.lbUnitAngleRedundantTolerance.Text = this.Main.Rm.GetString("Increment");
			this.lbUnitSpindleTorque.Text = this.Main.Rm.GetString("TorqueNm");
			this.lbUnitDepthSensorOffsetMin.Text = this.Main.Rm.GetString("Voltage");
			this.lbUnitDepthSensorOffsetMax.Text = this.Main.Rm.GetString("Voltage");
			this.lbUnitDepthSensorOffsetPreset.Text = this.Main.Rm.GetString("Milimeter");
			this.gBJawOpenAutomatic.Text = this.Main.Rm.GetString("gBJawOpenAutomatic");
			this.lbUnitJawOpenDepthGradMax.Text = this.Main.Rm.GetString("MillimeterPerSec");
			this.lbUnitJawOpenDepthGradMin.Text = this.Main.Rm.GetString("MillimeterPerSec");
			this.lbUnitJawOpenDistance.Text = this.Main.Rm.GetString("Milimeter");
			this.lbJawOpenDepthGradMax.Text = this.Main.Rm.GetString("lbJawOpenDepthGradMax");
			this.lbJawOpenDepthGradMin.Text = this.Main.Rm.GetString("lbJawOpenDepthGradMin");
			this.lbJawOpenDistance.Text = this.Main.Rm.GetString("lbJawOpenDistance2");
			this.openFileDialog.Filter = this.Main.Rm.GetString("SpindleConstFiles") + "|*.wspc|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.saveFileDialog.Filter = this.Main.Rm.GetString("SpindleConstFiles") + "|*.wspc|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.SpConstFileOperation.SetLanguageTexts();
		}

		private void MenEna()
		{
			bool enabled = false;
			bool enabled2 = false;
			if (this.Main.PassCodeLevel >= 1)
			{
				enabled = true;
			}
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_SpindleConstantsForm)
			{
				enabled2 = true;
			}
			if (this.Main.ViewOnlyMode)
			{
				enabled = false;
				enabled2 = false;
			}
			if (this.Main.IsOfflineVersion)
			{
				enabled = true;
				enabled2 = true;
			}
			this.Main.ShowCurrentUserAccessState(Settings.Default.UserLevel_SpindleConstantsForm, this.Main.ViewOnlyMode);
			if (this.Main.IsOnlineMode)
			{
				this.btBack.Enabled = enabled2;
			}
			else
			{
				this.btBack.Enabled = true;
			}
			this.btFileOperation.Enabled = true;
			this.chBFrictionTestStartup.Enabled = enabled2;
			this.chBTorqueSensorInvers.Enabled = enabled2;
			this.chBAngleSensorInvers.Enabled = enabled2;
			this.chBFrictionTestEMG.Enabled = enabled2;
			this.chBDriveUnitInvers.Enabled = enabled2;
			this.chBDepthSensorInvers.Enabled = enabled2;
			this.chBRedundantSensorActive.Enabled = enabled2;
			this.nEFrictionTorque.Enabled = enabled2;
			this.nEFrictionSpeed.Enabled = enabled2;
			this.nEAngleSensorScale.Enabled = enabled2;
			this.nETorqueSensorScale.Enabled = enabled2;
			this.nEDriveUnitRpm.Enabled = enabled2;
			this.nESpindlePressureScale.Enabled = enabled2;
			this.nEHolderPressureScale.Enabled = enabled2;
			this.nEDepthSensorScale.Enabled = enabled2;
			this.nEDepthSensorOffset.Enabled = enabled2;
			this.nEAnaSigScale.Enabled = enabled2;
			this.nEAnaSigOffset.Enabled = enabled2;
			this.nETorqueSensorTolerance.Enabled = enabled2;
			this.nETorqueRedundantTime.Enabled = enabled2;
			this.nETorqueRedundantTolerance.Enabled = enabled2;
			this.nEAngleRedundantTolerance.Enabled = enabled2;
			this.nESpindleGearFactor.Enabled = enabled2;
			this.nESpindleTorque.Enabled = enabled2;
			this.nEReleaseSpeed.Enabled = enabled2;
			this.nEDepthSensorOffsetMin.Enabled = enabled2;
			this.nEDepthSensorOffsetMax.Enabled = enabled2;
			this.nEDepthSensorOffsetPreset.Enabled = enabled2;
			this.nEJawOpenDepthGradMax.Enabled = enabled2;
			this.nEJawOpenDepthGradMin.Enabled = enabled2;
			this.nEJawOpenDistance.Enabled = enabled2;
			this.gBJawOpenAutomatic.Enabled = enabled2;
			this.nEFrictionTorque.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEFrictionSpeed.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEAngleSensorScale.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nETorqueSensorScale.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDriveUnitRpm.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nESpindlePressureScale.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEHolderPressureScale.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDepthSensorScale.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDepthSensorOffset.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEAnaSigScale.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEAnaSigOffset.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nETorqueSensorTolerance.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nETorqueRedundantTime.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nETorqueRedundantTolerance.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEAngleRedundantTolerance.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nESpindleGearFactor.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nESpindleTorque.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEReleaseSpeed.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDepthSensorOffsetMin.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDepthSensorOffsetMax.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEDepthSensorOffsetPreset.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEJawOpenDistance.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEJawOpenDepthGradMin.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.nEJawOpenDepthGradMax.ReadOnly = Settings.Default.SoftKeyBoardIsUsed;
			this.chBRedundantSensorActive_CheckedChanged(null, EventArgs.Empty);
			if (this.Main._READ_ONLY_CONTROLLER)
			{
				this.btBack.Enabled = false;
			}
			else
			{
				this.btBack.Enabled = enabled;
			}
		}

		private void NewInitializedSpindleStruct(ref WSP1_VarComm.SpConst_Struct dest)
		{
			dest.AnaSigOffset = 0f;
			dest.AnaSigScale = 0f;
			dest.AngleRedundantTolerance = 0;
			dest.AngleSensorInvers = 0;
			dest.AngleSensorScale = 0f;
			dest.DepthSensorInvers = 0;
			dest.DepthSensorOffset = 0f;
			dest.DepthSensorOffsetMax = 0f;
			dest.DepthSensorOffsetMin = 0f;
			dest.DepthSensorOffsetPreset = 0f;
			dest.DepthSensorScale = 0f;
			dest.DriveUnitInvers = 0;
			dest.DriveUnitRpm = 0f;
			dest.FrictionSpeed = 0f;
			dest.FrictionTestEMG = 0;
			dest.FrictionTestStartup = 0;
			dest.FrictionTorque = 0f;
			dest.PressureScaleHolder = 0f;
			dest.PressureScaleSpindle = 0.8333333f;
			dest.RedundantSensorActive = 0;
			dest.ReleaseSpeed = 0f;
			dest.SpindleGearFactor = 1f;
			dest.SpindleTorque = 0f;
			dest.TorqueRedundantTime = 0f;
			dest.TorqueRedundantTolerance = 0f;
			dest.TorqueSensorInvers = 0;
			dest.TorqueSensorScale = 0f;
			dest.TorqueSensorTolerance = 0f;
		}

		private void CopySpindleStruct(ref WSP1_VarComm.SpConst_Struct dest, WSP1_VarComm.SpConst_Struct source)
		{
			this.Main.VC.makeCopySpConst(ref dest, source);
		}

		private void ApplyValues()
		{
			if (this.chBAngleSensorInvers.Checked)
			{
				this.TempSpindleStruct.AngleSensorInvers = 1;
			}
			else
			{
				this.TempSpindleStruct.AngleSensorInvers = 0;
			}
			if (this.chBFrictionTestEMG.Checked)
			{
				this.TempSpindleStruct.FrictionTestEMG = 1;
			}
			else
			{
				this.TempSpindleStruct.FrictionTestEMG = 0;
			}
			if (this.chBFrictionTestStartup.Checked)
			{
				this.TempSpindleStruct.FrictionTestStartup = 1;
			}
			else
			{
				this.TempSpindleStruct.FrictionTestStartup = 0;
			}
			if (this.chBDriveUnitInvers.Checked)
			{
				this.TempSpindleStruct.DriveUnitInvers = 1;
			}
			else
			{
				this.TempSpindleStruct.DriveUnitInvers = 0;
			}
			if (this.chBTorqueSensorInvers.Checked)
			{
				this.TempSpindleStruct.TorqueSensorInvers = 1;
			}
			else
			{
				this.TempSpindleStruct.TorqueSensorInvers = 0;
			}
			if (this.chBDepthSensorInvers.Checked)
			{
				this.TempSpindleStruct.DepthSensorInvers = 1;
			}
			else
			{
				this.TempSpindleStruct.DepthSensorInvers = 0;
			}
			if (this.chBRedundantSensorActive.Checked)
			{
				this.TempSpindleStruct.RedundantSensorActive = 1;
			}
			else
			{
				this.TempSpindleStruct.RedundantSensorActive = 0;
			}
			this.TempSpindleStruct.FrictionSpeed = this.nEFrictionSpeed.Value;
			this.TempSpindleStruct.FrictionTorque = this.nEFrictionTorque.Value;
			this.TempSpindleStruct.DriveUnitRpm = this.nEDriveUnitRpm.Value;
			this.TempSpindleStruct.PressureScaleHolder = this.nEHolderPressureScale.Value / 6f;
			this.TempSpindleStruct.PressureScaleSpindle = this.nESpindlePressureScale.Value / 6f;
			this.TempSpindleStruct.AnaSigScale = this.nEAnaSigScale.Value;
			this.TempSpindleStruct.DepthSensorScale = this.nEDepthSensorScale.Value;
			this.TempSpindleStruct.TorqueSensorScale = this.nETorqueSensorScale.Value;
			this.TempSpindleStruct.AnaSigOffset = this.nEAnaSigOffset.Value;
			this.TempSpindleStruct.DepthSensorOffset = this.nEDepthSensorOffset.Value;
			this.TempSpindleStruct.DepthSensorOffsetMax = this.nEDepthSensorOffsetMax.Value;
			this.TempSpindleStruct.DepthSensorOffsetMin = this.nEDepthSensorOffsetMin.Value;
			this.TempSpindleStruct.DepthSensorOffsetPreset = this.nEDepthSensorOffsetPreset.Value;
			this.TempSpindleStruct.AngleSensorScale = this.nEAngleSensorScale.Value;
			this.TempSpindleStruct.TorqueSensorTolerance = this.nETorqueSensorTolerance.Value;
			this.TempSpindleStruct.TorqueRedundantTime = this.nETorqueRedundantTime.Value;
			this.TempSpindleStruct.TorqueRedundantTolerance = this.nETorqueRedundantTolerance.Value;
			this.TempSpindleStruct.AngleRedundantTolerance = (short)this.nEAngleRedundantTolerance.Value;
			this.TempSpindleStruct.SpindleGearFactor = this.nESpindleGearFactor.Value;
			this.TempSpindleStruct.SpindleTorque = this.nESpindleTorque.Value;
			this.TempSpindleStruct.ReleaseSpeed = this.nEReleaseSpeed.Value;
			this.TempSpindleStruct.JawOpenDepthGradMax = this.nEJawOpenDepthGradMax.Value;
			this.TempSpindleStruct.JawOpenDepthGradMin = this.nEJawOpenDepthGradMin.Value;
			this.TempSpindleStruct.JawOpenDistance = this.nEJawOpenDistance.Value;
		}

		private bool VerifySpConst()
		{
			string text = string.Empty;
			float num;
			if (!this.nETorqueSensorScale.IsOK)
			{
				string[] array = new string[9]
				{
					text,
					this.lbTorqueSensorScale.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array2 = array;
				num = this.nETorqueSensorScale.MinValue;
				array2[5] = num.ToString();
				array[6] = " - ";
				array[7] = this.nETorqueSensorScale.MaxValue.ToString();
				array[8] = "\n";
				text = string.Concat(array);
			}
			if (!this.nETorqueSensorTolerance.IsOK)
			{
				text = text + this.lbTorqueSensorTolerance.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nETorqueSensorTolerance.MinValue.ToString() + " - " + this.nETorqueSensorTolerance.MaxValue.ToString() + "\n";
			}
			if (!this.nEAngleSensorScale.IsOK)
			{
				text = text + this.lbAngleSensorScale.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEAngleSensorScale.MinValue.ToString() + " - " + this.nEAngleSensorScale.MaxValue.ToString() + "\n";
			}
			if (!this.nETorqueRedundantTime.IsOK)
			{
				text = text + this.lbTorqueRedundantTime.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nETorqueRedundantTime.MinValue.ToString() + " - " + this.nETorqueRedundantTime.MaxValue.ToString() + "\n";
			}
			if (!this.nETorqueRedundantTolerance.IsOK)
			{
				text = text + this.lbTorqueRedundantTolerance.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nETorqueRedundantTolerance.MinValue.ToString() + " - " + this.nETorqueRedundantTolerance.MaxValue.ToString() + "\n";
			}
			if (!this.nEAngleRedundantTolerance.IsOK)
			{
				text = text + this.lbAngleRedundantTolerance.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEAngleRedundantTolerance.MinValue.ToString() + " - " + this.nEAngleRedundantTolerance.MaxValue.ToString() + "\n";
			}
			if (!this.nEDriveUnitRpm.IsOK)
			{
				text = text + this.lbDriveUnitRpm.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEDriveUnitRpm.MinValue.ToString() + " - " + this.nEDriveUnitRpm.MaxValue.ToString() + "\n";
			}
			if (!this.nESpindlePressureScale.IsOK)
			{
				text = text + this.lbSpindlePressureScale.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nESpindlePressureScale.MinValue.ToString() + " - " + this.nESpindlePressureScale.MaxValue.ToString() + "\n";
			}
			if (!this.nEHolderPressureScale.IsOK)
			{
				text = text + this.lbHolderPressureScale.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEHolderPressureScale.MinValue.ToString() + " - " + this.nEHolderPressureScale.MaxValue.ToString() + "\n";
			}
			if (!this.nEDepthSensorScale.IsOK)
			{
				text = text + this.lbDepthSensorScale.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEDepthSensorScale.MinValue.ToString() + " - " + this.nEDepthSensorScale.MaxValue.ToString() + "\n";
			}
			if (!this.nEDepthSensorOffset.IsOK)
			{
				text = text + this.lbDepthSensorOffset.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEDepthSensorOffset.MinValue.ToString() + " - " + this.nEDepthSensorOffset.MaxValue.ToString() + "\n";
			}
			if (!this.nEDepthSensorOffsetMin.IsOK)
			{
				text = text + this.lbDepthSensorOffsetMin.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEDepthSensorOffsetMin.MinValue.ToString() + " - " + this.nEDepthSensorOffsetMin.MaxValue.ToString() + "\n";
			}
			if (!this.nEDepthSensorOffsetMax.IsOK)
			{
				text = text + this.lbDepthSensorOffsetMax.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEDepthSensorOffsetMax.MinValue.ToString() + " - " + this.nEDepthSensorOffsetMax.MaxValue.ToString() + "\n";
			}
			if (!this.nEDepthSensorOffsetPreset.IsOK)
			{
				text = text + this.lbDepthSensorOffsetPreset.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEDepthSensorOffsetPreset.MinValue.ToString() + " - " + this.nEDepthSensorOffsetPreset.MaxValue.ToString() + "\n";
			}
			if (this.nEDepthSensorOffsetMax.Value < this.nEDepthSensorOffsetMin.Value)
			{
				text = text + this.lbDepthSensorOffsetMin.Text + " > " + this.lbDepthSensorOffsetMax.Text + "\n";
			}
			if (!this.nEAnaSigScale.IsOK)
			{
				text = text + this.lbAnaSigScale.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEAnaSigScale.MinValue.ToString() + " - " + this.nEAnaSigScale.MaxValue.ToString() + "\n";
			}
			if (!this.nEAnaSigOffset.IsOK)
			{
				text = text + this.lbAnaSigOffset.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEAnaSigOffset.MinValue.ToString() + " - " + this.nEAnaSigOffset.MaxValue.ToString() + "\n";
			}
			if (!this.nESpindleTorque.IsOK)
			{
				text = text + this.lbSpindleTorque.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nESpindleTorque.MinValue.ToString() + " - " + this.nESpindleTorque.MaxValue.ToString() + "\n";
			}
			if (!this.nESpindleGearFactor.IsOK)
			{
				text = text + this.lbSpindleGearFactor.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nESpindleGearFactor.MinValue.ToString() + " - " + this.nESpindleGearFactor.MaxValue.ToString() + "\n";
			}
			if (!this.nEReleaseSpeed.IsOK)
			{
				text = text + this.lbReleaseSpeed.Text + " " + this.Main.Rm.GetString("OutOfRange") + ": " + this.nEReleaseSpeed.MinValue.ToString() + " - " + this.nEReleaseSpeed.MaxValue.ToString() + "\n";
			}
			if (!this.nEFrictionTorque.IsOK)
			{
				string[] array3 = new string[9]
				{
					text,
					this.lbFrictionTorque.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					this.nEFrictionTorque.MinValue.ToString(),
					" - ",
					null,
					null
				};
				string[] array4 = array3;
				num = this.nEFrictionTorque.MaxValue;
				array4[7] = num.ToString();
				array3[8] = "\n";
				text = string.Concat(array3);
			}
			if (!this.nEFrictionSpeed.IsOK)
			{
				string[] array = new string[9]
				{
					text,
					this.lbFrictionSpeed.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array5 = array;
				num = this.nEFrictionSpeed.MinValue;
				array5[5] = num.ToString();
				array[6] = " - ";
				string[] array6 = array;
				num = this.nEFrictionSpeed.MaxValue;
				array6[7] = num.ToString();
				array[8] = "\n";
				text = string.Concat(array);
			}
			if (!this.nEJawOpenDepthGradMax.IsOK)
			{
				string[] array = new string[9]
				{
					text,
					this.lbJawOpenDepthGradMax.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array7 = array;
				num = this.nEJawOpenDepthGradMax.MinValue;
				array7[5] = num.ToString();
				array[6] = " - ";
				string[] array8 = array;
				num = this.nEJawOpenDepthGradMax.MaxValue;
				array8[7] = num.ToString();
				array[8] = "\n";
				text = string.Concat(array);
			}
			if (!this.nEJawOpenDepthGradMin.IsOK)
			{
				string[] array = new string[9]
				{
					text,
					this.lbJawOpenDepthGradMin.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array9 = array;
				num = this.nEJawOpenDepthGradMin.MinValue;
				array9[5] = num.ToString();
				array[6] = " - ";
				string[] array10 = array;
				num = this.nEJawOpenDepthGradMin.MaxValue;
				array10[7] = num.ToString();
				array[8] = "\n";
				text = string.Concat(array);
			}
			if (!this.nEJawOpenDistance.IsOK)
			{
				string[] array = new string[9]
				{
					text,
					this.lbJawOpenDistance.Text,
					" ",
					this.Main.Rm.GetString("OutOfRange"),
					": ",
					null,
					null,
					null,
					null
				};
				string[] array11 = array;
				num = this.nEJawOpenDistance.MinValue;
				array11[5] = num.ToString();
				array[6] = " - ";
				string[] array12 = array;
				num = this.nEJawOpenDistance.MaxValue;
				array12[7] = num.ToString();
				array[8] = "\n";
				text = string.Concat(array);
			}
			if (text != string.Empty)
			{
				MessageBox.Show(this.Main.Rm.GetString("ValuesNotApplied") + "\n" + text, this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			return true;
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				this.Main.StatusBarText(string.Empty);
				DialogResult dialogResult = MessageBox.Show(this.Main.Rm.GetString("MbSaveDataLocally"), this.Main.Rm.GetString("MbhSecurityQuery"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				this.ApplyValues();
				this.CopySpindleStruct(ref this.Main.VC.SpConst, this.TempSpindleStruct);
				switch (dialogResult)
				{
				case DialogResult.Yes:
					this.SaveSpConstToFile(null, true);
					break;
				default:
					MessageBox.Show("Wrong DialogResult in btBack_Click() of SpindleConstants", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					break;
				case DialogResult.No:
					break;
				}
				goto IL_0be1;
			}
			if (this.Main.PassCodeLevel < Settings.Default.UserLevel_SpindleConstantsForm)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoAccess"), this.Main.Rm.GetString("MbhNoAccess"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else if (this.VerifySpConst())
			{
				this.pnMenu.Enabled = false;
				Cursor.Current = Cursors.WaitCursor;
				if (this.TempSpindleStruct.TorqueSensorScale != this.nETorqueSensorScale.Value)
				{
					this.Main.MakeLogbookEntry(203000u, 4, this.TempSpindleStruct.TorqueSensorScale, this.nETorqueSensorScale.Value, 0u, 0, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque));
				}
				if (this.TempSpindleStruct.TorqueSensorTolerance != this.nETorqueSensorTolerance.Value)
				{
					this.Main.MakeLogbookEntry(203001u, 4, this.TempSpindleStruct.TorqueSensorTolerance, this.nETorqueSensorTolerance.Value, 0u, 0, 25);
				}
				if (this.TempSpindleStruct.AngleSensorScale != this.nEAngleSensorScale.Value)
				{
					this.Main.MakeLogbookEntry(203002u, 4, this.TempSpindleStruct.AngleSensorScale, this.nEAngleSensorScale.Value, 0u, 0, 28);
				}
				if (this.TempSpindleStruct.TorqueRedundantTime != this.nETorqueRedundantTime.Value)
				{
					this.Main.MakeLogbookEntry(203006u, 4, this.TempSpindleStruct.TorqueRedundantTime, this.nETorqueRedundantTime.Value, 0u, 0, 21);
				}
				if (this.TempSpindleStruct.TorqueRedundantTolerance != this.nETorqueRedundantTolerance.Value)
				{
					this.Main.MakeLogbookEntry(203007u, 4, this.TempSpindleStruct.TorqueRedundantTolerance, this.nETorqueRedundantTolerance.Value, 0u, 0, 25);
				}
				if ((float)this.TempSpindleStruct.AngleRedundantTolerance != this.nEAngleRedundantTolerance.Value)
				{
					this.Main.MakeLogbookEntry(203027u, 4, (float)this.TempSpindleStruct.AngleRedundantTolerance, this.nEAngleRedundantTolerance.Value, 0u, 0, 27);
				}
				if (this.TempSpindleStruct.DepthSensorScale != this.nEDepthSensorScale.Value)
				{
					this.Main.MakeLogbookEntry(203010u, 4, this.TempSpindleStruct.DepthSensorScale, this.nEDepthSensorScale.Value, 0u, 0, 38);
				}
				if (this.TempSpindleStruct.DepthSensorOffset != this.nEDepthSensorOffset.Value)
				{
					this.Main.MakeLogbookEntry(203011u, 4, this.TempSpindleStruct.DepthSensorOffset, this.nEDepthSensorOffset.Value, 0u, 0, 22);
				}
				if (this.TempSpindleStruct.DepthSensorOffsetMin != this.nEDepthSensorOffsetMin.Value)
				{
					this.Main.MakeLogbookEntry(203024u, 4, this.TempSpindleStruct.DepthSensorOffsetMin, this.nEDepthSensorOffsetMin.Value, 0u, 0, 24);
				}
				if (this.TempSpindleStruct.DepthSensorOffsetMax != this.nEDepthSensorOffsetMax.Value)
				{
					this.Main.MakeLogbookEntry(203025u, 4, this.TempSpindleStruct.DepthSensorOffsetMax, this.nEDepthSensorOffsetMax.Value, 0u, 0, 24);
				}
				if (this.TempSpindleStruct.DepthSensorOffsetPreset != this.nEDepthSensorOffsetPreset.Value)
				{
					this.Main.MakeLogbookEntry(203026u, 4, this.TempSpindleStruct.DepthSensorOffsetPreset, this.nEDepthSensorOffsetPreset.Value, 0u, 0, 22);
				}
				if (this.TempSpindleStruct.DriveUnitRpm != this.nEDriveUnitRpm.Value)
				{
					this.Main.MakeLogbookEntry(203008u, 4, this.TempSpindleStruct.DriveUnitRpm, this.nEDriveUnitRpm.Value, 0u, 0, 23);
				}
				if (this.TempSpindleStruct.PressureScaleSpindle * 6f != this.nESpindlePressureScale.Value)
				{
					this.Main.MakeLogbookEntry(203028u, 4, this.TempSpindleStruct.PressureScaleSpindle * 6f, this.nESpindlePressureScale.Value, 0u, 0, 17);
				}
				if (this.TempSpindleStruct.PressureScaleHolder != this.nEHolderPressureScale.Value)
				{
					this.Main.MakeLogbookEntry(203029u, 4, this.TempSpindleStruct.PressureScaleHolder, this.nEHolderPressureScale.Value, 0u, 0, 39);
				}
				if (this.TempSpindleStruct.SpindleTorque != this.nESpindleTorque.Value)
				{
					this.Main.MakeLogbookEntry(203015u, 4, this.TempSpindleStruct.SpindleTorque, this.nESpindleTorque.Value, 0u, 0, C_Global.GetCurrentLogUnitTorque(this.Main.VC.SysConst.UnitTorque));
				}
				if (this.TempSpindleStruct.SpindleGearFactor != this.nESpindleGearFactor.Value)
				{
					this.Main.MakeLogbookEntry(203016u, 4, this.TempSpindleStruct.SpindleGearFactor, this.nESpindleGearFactor.Value, 0u, 0, byte.MaxValue);
				}
				if (this.TempSpindleStruct.ReleaseSpeed != this.nEReleaseSpeed.Value)
				{
					this.Main.MakeLogbookEntry(203017u, 4, this.TempSpindleStruct.ReleaseSpeed, this.nEReleaseSpeed.Value, 0u, 0, 23);
				}
				if (this.TempSpindleStruct.FrictionTorque != this.nEFrictionTorque.Value)
				{
					this.Main.MakeLogbookEntry(203018u, 4, this.TempSpindleStruct.FrictionTorque, this.nEFrictionTorque.Value, 0u, 0, 25);
				}
				if (this.TempSpindleStruct.FrictionSpeed != this.nEFrictionSpeed.Value)
				{
					this.Main.MakeLogbookEntry(203019u, 4, this.TempSpindleStruct.FrictionSpeed, this.nEFrictionSpeed.Value, 0u, 0, 25);
				}
				if (this.TempSpindleStruct.AnaSigScale != this.nEAnaSigScale.Value)
				{
					this.Main.MakeLogbookEntry(203013u, 4, this.TempSpindleStruct.AnaSigScale, this.nEAnaSigScale.Value, 0u, 0, 39);
				}
				if (this.TempSpindleStruct.AnaSigOffset != this.nEAnaSigOffset.Value)
				{
					this.Main.MakeLogbookEntry(203014u, 4, this.TempSpindleStruct.AnaSigOffset, this.nEAnaSigOffset.Value, 0u, 0, 24);
				}
				if (this.TempSpindleStruct.JawOpenDistance != this.nEJawOpenDistance.Value)
				{
					this.Main.MakeLogbookEntry(207003u, 4, this.TempSpindleStruct.JawOpenDistance, this.nEJawOpenDistance.Value, 0u, 0, 22);
				}
				if (this.TempSpindleStruct.JawOpenDepthGradMin != this.nEJawOpenDepthGradMin.Value)
				{
					this.Main.MakeLogbookEntry(207001u, 4, this.TempSpindleStruct.JawOpenDepthGradMin, this.nEJawOpenDepthGradMin.Value, 0u, 0, 40);
				}
				if (this.TempSpindleStruct.JawOpenDepthGradMax != this.nEJawOpenDepthGradMax.Value)
				{
					this.Main.MakeLogbookEntry(207002u, 4, this.TempSpindleStruct.JawOpenDepthGradMax, this.nEJawOpenDepthGradMax.Value, 0u, 0, 40);
				}
				if (this.chBTorqueSensorInvers.Checked && this.TempSpindleStruct.TorqueSensorInvers == 0)
				{
					goto IL_07ee;
				}
				if (!this.chBTorqueSensorInvers.Checked && this.TempSpindleStruct.TorqueSensorInvers == 1)
				{
					goto IL_07ee;
				}
				goto IL_0824;
			}
			return;
			IL_08c4:
			this.Main.MakeLogbookEntry(203005u, 4, (float)(int)this.TempSpindleStruct.RedundantSensorActive, (float)(this.chBRedundantSensorActive.Checked ? 1 : 0), 0u, 0, byte.MaxValue);
			goto IL_08fa;
			IL_0be1:
			this.Main.LoggingFinished(true);
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			base.Hide();
			return;
			IL_0aa6:
			this.ApplyValues();
			this.CopySpindleStruct(ref this.Main.VC.SpConst, this.TempSpindleStruct);
			this.Main.StatusBarText(this.Main.Rm.GetString("SendSpindleConstants"));
			if (!this.Main.VC.SendVarBlock(11))
			{
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show("Could not send SpConstBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.pnMenu.Enabled = true;
				this.pnMenu.Select();
				return;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("SaveSpindleConstOnCPU"));
			if (!this.Main.SaveOnController(2, false))
			{
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show(this.Main.Rm.GetString("MbSaveSpConstFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.pnMenu.Enabled = true;
				this.pnMenu.Select();
				return;
			}
			this.Main.WriteLogbookData(true);
			goto IL_0be1;
			IL_088f:
			if (this.chBRedundantSensorActive.Checked && this.TempSpindleStruct.RedundantSensorActive == 0)
			{
				goto IL_08c4;
			}
			if (!this.chBRedundantSensorActive.Checked && this.TempSpindleStruct.RedundantSensorActive == 1)
			{
				goto IL_08c4;
			}
			goto IL_08fa;
			IL_0859:
			this.Main.MakeLogbookEntry(203004u, 4, (float)(int)this.TempSpindleStruct.AngleSensorInvers, (float)(this.chBAngleSensorInvers.Checked ? 1 : 0), 0u, 0, byte.MaxValue);
			goto IL_088f;
			IL_092f:
			this.Main.MakeLogbookEntry(203012u, 4, (float)(int)this.TempSpindleStruct.DepthSensorInvers, (float)(this.chBDepthSensorInvers.Checked ? 1 : 0), 0u, 0, byte.MaxValue);
			goto IL_0965;
			IL_0a05:
			this.Main.MakeLogbookEntry(203020u, 4, (float)(int)this.TempSpindleStruct.FrictionTestStartup, (float)(this.chBFrictionTestStartup.Checked ? 1 : 0), 0u, 0, byte.MaxValue);
			goto IL_0a3b;
			IL_09d0:
			if (this.chBFrictionTestStartup.Checked && this.TempSpindleStruct.FrictionTestStartup == 0)
			{
				goto IL_0a05;
			}
			if (!this.chBFrictionTestStartup.Checked && this.TempSpindleStruct.FrictionTestStartup == 1)
			{
				goto IL_0a05;
			}
			goto IL_0a3b;
			IL_08fa:
			if (this.chBDepthSensorInvers.Checked && this.TempSpindleStruct.DepthSensorInvers == 0)
			{
				goto IL_092f;
			}
			if (!this.chBDepthSensorInvers.Checked && this.TempSpindleStruct.DepthSensorInvers == 1)
			{
				goto IL_092f;
			}
			goto IL_0965;
			IL_099a:
			this.Main.MakeLogbookEntry(203009u, 4, (float)(int)this.TempSpindleStruct.DriveUnitInvers, (float)(this.chBDriveUnitInvers.Checked ? 1 : 0), 0u, 0, byte.MaxValue);
			goto IL_09d0;
			IL_07ee:
			this.Main.MakeLogbookEntry(203003u, 4, (float)(int)this.TempSpindleStruct.TorqueSensorInvers, (float)(this.chBTorqueSensorInvers.Checked ? 1 : 0), 0u, 0, byte.MaxValue);
			goto IL_0824;
			IL_0a70:
			this.Main.MakeLogbookEntry(203021u, 4, (float)(int)this.TempSpindleStruct.FrictionTestEMG, (float)(this.chBFrictionTestEMG.Checked ? 1 : 0), 0u, 0, byte.MaxValue);
			goto IL_0aa6;
			IL_0965:
			if (this.chBDriveUnitInvers.Checked && this.TempSpindleStruct.DriveUnitInvers == 0)
			{
				goto IL_099a;
			}
			if (!this.chBDriveUnitInvers.Checked && this.TempSpindleStruct.DriveUnitInvers == 1)
			{
				goto IL_099a;
			}
			goto IL_09d0;
			IL_0a3b:
			if (this.chBFrictionTestEMG.Checked && this.TempSpindleStruct.FrictionTestEMG == 0)
			{
				goto IL_0a70;
			}
			if (!this.chBFrictionTestEMG.Checked && this.TempSpindleStruct.FrictionTestEMG == 1)
			{
				goto IL_0a70;
			}
			goto IL_0aa6;
			IL_0824:
			if (this.chBAngleSensorInvers.Checked && this.TempSpindleStruct.AngleSensorInvers == 0)
			{
				goto IL_0859;
			}
			if (!this.chBAngleSensorInvers.Checked && this.TempSpindleStruct.AngleSensorInvers == 1)
			{
				goto IL_0859;
			}
			goto IL_088f;
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_1_2_Spindelkonstanten";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_1_2_Spindelkonstanten");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			this.Main.LoggingFinished(true);
			base.Hide();
		}

		private void btFileOperation_Click(object sender, EventArgs e)
		{
			this.SpConstFileOperation.ShowDialog();
			FileStream fileStream = null;
			BinaryFormatter binaryFormatter = null;
			switch (this.SpConstFileOperation.FileOperationType)
			{
			case 0:
				break;
			case 1:
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				if (Settings.Default.FileOperationDefaultUse)
				{
					this.openFileDialog.InitialDirectory = Settings.Default.FileOperationDefaultDirectory;
				}
				if (this.openFileDialog.ShowDialog() == DialogResult.OK)
				{
					this.Main.StatusBarText(this.Main.Rm.GetString("LoadSpindleDataLocally"));
					Cursor.Current = Cursors.WaitCursor;
					try
					{
						fileStream = new FileStream(this.openFileDialog.FileName, FileMode.OpenOrCreate);
						binaryFormatter = new BinaryFormatter();
						binaryFormatter.Binder = new myBinder();
						WSP1_VarComm.SpConst_Struct ts = (WSP1_VarComm.SpConst_Struct)binaryFormatter.Deserialize(fileStream);
						fileStream.Close();
						fileStream.Dispose();
						this.Main.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						this.Initialize(ts);
						this.Main.MakeLogbookEntry(203030u, 4, 0f, 0f, 0u, 0, byte.MaxValue);
						this.Main.SettingsChanged();
					}
					catch (Exception ex)
					{
						if (fileStream != null)
						{
							fileStream.Close();
							fileStream.Dispose();
						}
						this.Main.StatusBarText(string.Empty);
						Cursor.Current = Cursors.Default;
						MessageBox.Show(this.Main.Rm.GetString("MbSpindleLoadFromFileFailure") + ":\n" + ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				break;
			case 2:
				this.SaveSpConstToFile(null, true);
				break;
			default:
				MessageBox.Show("Wrong FileOperationType in btFileOperation_Click() of SpindleConstants", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				break;
			}
		}

		public string SaveSpConstToFile(string directory, bool showMessage)
		{
			string text = "";
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			if (!this.VerifySpConst())
			{
				return "";
			}
			this.ApplyValues();
			bool flag;
			string directoryS;
			if (directory == null)
			{
				flag = Settings.Default.FileOperationDefaultUse;
				directoryS = Settings.Default.FileOperationDefaultDirectory;
			}
			else
			{
				flag = true;
				directoryS = directory;
			}
			FileStream fileStream = null;
			try
			{
				if (!flag)
				{
					this.saveFileDialog.FileName = this.Main.Rm.GetString("SpindleConstFiles") + " V" + Assembly.GetExecutingAssembly().GetName().Version.ToString();
					if (this.saveFileDialog.ShowDialog() != DialogResult.OK)
					{
						return "";
					}
					fileStream = new FileStream(this.saveFileDialog.FileName, FileMode.Create);
				}
				else
				{
					fileStream = this.Main.ProcessProgram.GetNextFile(directoryS, this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) + "_SPINDLE_CONST_", "wspc");
				}
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveSpindleDataLocally"));
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				binaryFormatter.AssemblyFormat = FormatterAssemblyStyle.Simple;
				binaryFormatter.Serialize(fileStream, this.TempSpindleStruct);
				string name = fileStream.Name;
				fileStream.Close();
				fileStream.Dispose();
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				text = this.Main.Rm.GetString("MbSavedSpindleDataToFile") + "\n" + name;
				if (flag)
				{
					if (showMessage)
					{
						MessageBox.Show(text);
						return text;
					}
					return text;
				}
				return text;
			}
			catch (Exception ex)
			{
				if (fileStream != null)
				{
					fileStream.Close();
					fileStream.Dispose();
				}
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show(this.Main.Rm.GetString("MbSpindleSaveToFileFailure") + ":\n" + ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return text;
			}
		}

		private void Start_Input(object sender, EventArgs e)
		{
			if (!this.bInitialize)
			{
				if (this.pnMenu.Enabled)
				{
					this.Main.TextInput(sender);
				}
				else
				{
					this.Main.StatusBarText(string.Empty);
				}
			}
		}

		private void StartInput(object sender, MouseEventArgs e)
		{
			if (!this.bInitialize)
			{
				if (this.pnMenu.Enabled)
				{
					this.Main.TextInput(sender);
				}
				else
				{
					this.Main.StatusBarText(string.Empty);
				}
			}
		}

		private void SpindleConstantsForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void chBRedundantSensorActive_CheckedChanged(object sender, EventArgs e)
		{
			if (this.chBRedundantSensorActive.Checked)
			{
				this.nETorqueRedundantTime.Enabled = true;
				this.nETorqueRedundantTolerance.Enabled = true;
				this.nEAngleRedundantTolerance.Enabled = true;
			}
			else
			{
				this.nETorqueRedundantTime.Enabled = false;
				this.nETorqueRedundantTolerance.Enabled = false;
				this.nEAngleRedundantTolerance.Enabled = false;
			}
		}

		public void KeyArrived()
		{
			if (this.Main.PassCodeLevel > 0)
			{
				if (this.Main.GetExclusiveBlock1())
				{
					this.Main.CheckParamAllowed = true;
					this.LoadSpindleConstants();
					this.Main.ProcessProgram.UploadAllProgDataFromController();
					this.Main.ProcessProgram.InitializeTempProgStruct();
				}
				else
				{
					this.Main.CheckParamAllowed = false;
				}
			}
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbOfflineMode"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void settingsChanged(object sender, EventArgs e)
		{
			if (!this.bInitialize)
			{
				this.Main.SettingsChanged();
			}
		}
	}
}
