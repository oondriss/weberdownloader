using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Visualisation.Properties;

namespace Visualisation
{
	public class MenuTestForm : Form
	{
		private MainForm Main;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Button btMotorSensor;

		private Button btPLCInterface;

		private Button btIOTest;

		private Button bt3;

		private Button bt2;

		private Button btBrowser;

		private Container components;

		private bool writePermission = true;

		public bool WritePermission => this.writePermission;

		public void ResetWritePermission()
		{
			this.writePermission = false;
		}

		public MenuTestForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.pnMenu = new Panel();
			this.bt3 = new Button();
			this.bt2 = new Button();
			this.btHelp = new Button();
			this.btBrowser = new Button();
			this.btPLCInterface = new Button();
			this.btMotorSensor = new Button();
			this.btIOTest = new Button();
			this.btBack = new Button();
			this.pnMenu.SuspendLayout();
			base.SuspendLayout();
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.bt2);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBrowser);
			this.pnMenu.Controls.Add(this.btPLCInterface);
			this.pnMenu.Controls.Add(this.btMotorSensor);
			this.pnMenu.Controls.Add(this.btIOTest);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.bt3.Enabled = false;
			this.bt3.Location = new Point(3, 451);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 7;
			this.bt2.Enabled = false;
			this.bt2.Location = new Point(3, 387);
			this.bt2.Name = "bt2";
			this.bt2.Size = new Size(74, 62);
			this.bt2.TabIndex = 6;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBrowser.Enabled = false;
			this.btBrowser.Location = new Point(3, 323);
			this.btBrowser.Name = "btBrowser";
			this.btBrowser.Size = new Size(74, 62);
			this.btBrowser.TabIndex = 5;
			this.btBrowser.Click += this.btBrowser_Click;
			this.btPLCInterface.Location = new Point(3, 259);
			this.btPLCInterface.Name = "btPLCInterface";
			this.btPLCInterface.Size = new Size(74, 62);
			this.btPLCInterface.TabIndex = 4;
			this.btPLCInterface.Text = "SPS I/O";
			this.btPLCInterface.Click += this.btPLCInterface_Click;
			this.btMotorSensor.Location = new Point(3, 131);
			this.btMotorSensor.Name = "btMotorSensor";
			this.btMotorSensor.Size = new Size(74, 62);
			this.btMotorSensor.TabIndex = 2;
			this.btMotorSensor.Text = "Motor Reibwert Sensor";
			this.btMotorSensor.Click += this.btMotorSensor_Click;
			this.btIOTest.Location = new Point(3, 195);
			this.btIOTest.Name = "btIOTest";
			this.btIOTest.Size = new Size(74, 62);
			this.btIOTest.TabIndex = 3;
			this.btIOTest.Text = "I/O";
			this.btIOTest.Click += this.btIOTest_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			base.AutoScaleMode = AutoScaleMode.None;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "MenuTestForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Test";
			base.Activated += this.MenuTestForm_Activated;
			this.pnMenu.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		public void ShowWindow()
		{
			base.Show();
			this.ShowMotorSensor();
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuTest");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btIOTest.Text = this.Main.Rm.GetString("IOTest");
			this.btMotorSensor.Text = this.Main.Rm.GetString("IntegratedTests");
			this.btPLCInterface.Text = this.Main.Rm.GetString("PLC_IO");
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		private void btBrowser_Click(object sender, EventArgs e)
		{
			this.BrowserShow();
		}

		public void Back()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.writePermission = true;
			this.pnMenu.Enabled = false;
			this.Main.ExitExclusiveBlock2();
			this.Main.ResetPasscodeLevel();
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_3_Testfunktionen";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_3_Testfunktionen");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		public void ShowMotorSensor()
		{
			this.btMotorSensor_Click(null, EventArgs.Empty);
		}

		private void btMotorSensor_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.TestMotorSensor1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		public void ShowIOTest()
		{
			this.btIOTest_Click(null, EventArgs.Empty);
		}

		private void btIOTest_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.TestIO1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		public void ShowPLCInterface()
		{
			this.btPLCInterface_Click(null, EventArgs.Empty);
		}

		private void btPLCInterface_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			if (!this.Main.TestSPSIO1.ShowWindow())
			{
				this.pnMenu.Enabled = true;
			}
		}

		private void MenuTestForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.Main.ShowCurrentUserAccessState(0, false);
			this.btBack.Select();
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}
	}
}
