using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;
using Visualisation.Properties;
using WSPKurve;

namespace Visualisation
{
	public class CurveDisplayForm : Form
	{
		private const bool LEFTCURSOR = false;

		private const bool RIGHTCURSOR = true;

		private const int AUTOMTIC_CURVE_NUM = 50;

		private string errorMessage = "";

		private MainForm Main;

		public CurvePreview CurvePreview;

		private S_ResultData ResData;

		private S_ResultData TempResData;

		public C_Curve C_Curve1;

		public CurveSelectionForm CurveSelection1;

		public CurvePrintForm CurvePrint1;

		private float[,,] CurveData;

		private float[,] TempCurveData;

		private float[,] TempActualCurveData;

		private int curvesToSave;

		private int curvesToShow;

		private int KindOfCurves;

		private int CurveIndex;

		private string AutoSaveDirectory;

		private string[] CurveName;

		private string[] CurveUnit;

		private int ExportMode;

		private bool stepInfoIncluded;

		private Panel pnCurve;

		private Panel pnMenu;

		private Button btHelp;

		private Button btBack;

		private Button btGetCurve;

		private Button btCursor;

		private Button btZoomIn;

		private Button btZoomOut;

		private Button btCurveSelection;

		private Button btPrint;

		private OpenFileDialog openFileDialog;

		private SaveFileDialog saveFileDialog;

		private FolderBrowserDialog folderBrowserDialog;

		private FolderBrowserDialog fBDExport;

		private Timer timerRepaintCurve;

		private IContainer components;

		private bool doNotUpdateCurve;

		public string ErrorMessage => this.errorMessage;

		public int CurvesToSave => this.curvesToSave;

		public int CurvesRemaining => this.curvesToSave - this.CurveIndex;

		public int CurvesToShow => this.curvesToShow;

		public CurveDisplayForm(MainForm main)
		{
			this.Main = main;
			this.CurvePreview = new CurvePreview(this.Main);
			this.ResData = default(S_ResultData);
			this.TempResData = default(S_ResultData);
			this.InitializeComponent();
			this.CurveName = new string[11];
			this.CurveUnit = new string[11];
			this.CurveData = new float[12, 20000, 2];
			this.C_Curve1 = new C_Curve(this.Main, this.pnCurve, this.CurveData);
			this.C_Curve1.InitializeDisplay();
			this.C_Curve1.SetMultipleCurveMode(1);
			this.CurveSelection1 = new CurveSelectionForm(this.Main);
			this.CurvePrint1 = new CurvePrintForm(this.Main);
			this.SetCurvesToShow();
			this.curvesToSave = 0;
			this.curvesToShow = 0;
			this.KindOfCurves = 0;
			this.CurveIndex = 0;
			this.AutoSaveDirectory = string.Empty;
			this.ExportMode = 0;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.pnCurve = new System.Windows.Forms.Panel();
			this.btZoomIn = new System.Windows.Forms.Button();
			this.btCursor = new System.Windows.Forms.Button();
			this.btGetCurve = new System.Windows.Forms.Button();
			this.btCurveSelection = new System.Windows.Forms.Button();
			this.btHelp = new System.Windows.Forms.Button();
			this.btBack = new System.Windows.Forms.Button();
			this.pnMenu = new System.Windows.Forms.Panel();
			this.btPrint = new System.Windows.Forms.Button();
			this.btZoomOut = new System.Windows.Forms.Button();
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
			this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
			this.fBDExport = new System.Windows.Forms.FolderBrowserDialog();
			this.timerRepaintCurve = new System.Windows.Forms.Timer(this.components);
			this.pnMenu.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnCurve
			// 
			this.pnCurve.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pnCurve.Location = new System.Drawing.Point(0, 0);
			this.pnCurve.Name = "pnCurve";
			this.pnCurve.Size = new System.Drawing.Size(709, 522);
			this.pnCurve.TabIndex = 1;
			// 
			// btZoomIn
			// 
			this.btZoomIn.Location = new System.Drawing.Point(3, 323);
			this.btZoomIn.Name = "btZoomIn";
			this.btZoomIn.Size = new System.Drawing.Size(74, 62);
			this.btZoomIn.TabIndex = 5;
			this.btZoomIn.Text = "Einzoomen";
			// 
			// btCursor
			// 
			this.btCursor.Location = new System.Drawing.Point(3, 259);
			this.btCursor.Name = "btCursor";
			this.btCursor.Size = new System.Drawing.Size(74, 62);
			this.btCursor.TabIndex = 4;
			this.btCursor.Text = "Cursor";
			// 
			// btGetCurve
			// 
			this.btGetCurve.Location = new System.Drawing.Point(3, 195);
			this.btGetCurve.Name = "btGetCurve";
			this.btGetCurve.Size = new System.Drawing.Size(74, 62);
			this.btGetCurve.TabIndex = 3;
			this.btGetCurve.Text = "Aktualisiere Kurve";
			this.btGetCurve.Click += new System.EventHandler(this.btGetCurve_Click_1);
			// 
			// btCurveSelection
			// 
			this.btCurveSelection.Location = new System.Drawing.Point(3, 131);
			this.btCurveSelection.Name = "btCurveSelection";
			this.btCurveSelection.Size = new System.Drawing.Size(74, 62);
			this.btCurveSelection.TabIndex = 2;
			this.btCurveSelection.Text = "Kurven bearbeiten";
			// 
			// btHelp
			// 
			this.btHelp.Location = new System.Drawing.Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new System.Drawing.Size(74, 62);
			this.btHelp.TabIndex = 1;
			// 
			// btBack
			// 
			this.btBack.Location = new System.Drawing.Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new System.Drawing.Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			// 
			// pnMenu
			// 
			this.pnMenu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pnMenu.Controls.Add(this.btPrint);
			this.pnMenu.Controls.Add(this.btZoomOut);
			this.pnMenu.Controls.Add(this.btZoomIn);
			this.pnMenu.Controls.Add(this.btCursor);
			this.pnMenu.Controls.Add(this.btGetCurve);
			this.pnMenu.Controls.Add(this.btCurveSelection);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new System.Drawing.Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new System.Drawing.Size(80, 516);
			this.pnMenu.TabIndex = 0;
			// 
			// btPrint
			// 
			this.btPrint.Location = new System.Drawing.Point(3, 451);
			this.btPrint.Name = "btPrint";
			this.btPrint.Size = new System.Drawing.Size(74, 62);
			this.btPrint.TabIndex = 7;
			this.btPrint.Text = "File";
			this.btPrint.Click += new System.EventHandler(this.btPrint_Click_1);
			// 
			// btZoomOut
			// 
			this.btZoomOut.Location = new System.Drawing.Point(3, 387);
			this.btZoomOut.Name = "btZoomOut";
			this.btZoomOut.Size = new System.Drawing.Size(74, 62);
			this.btZoomOut.TabIndex = 6;
			this.btZoomOut.Text = "Auszoomen";
			// 
			// openFileDialog
			// 
			this.openFileDialog.Filter = "Curves|*.wcrv|All Files|*.*";
			// 
			// saveFileDialog
			// 
			this.saveFileDialog.Filter = "Curves|*.wcrv|All Files|*.*";
			// 
			// CurveDisplayForm
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(789, 544);
			this.ControlBox = false;
			this.Controls.Add(this.pnCurve);
			this.Controls.Add(this.pnMenu);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "CurveDisplayForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "Auswertung/Kurvenanzeige";
			this.pnMenu.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		private void enableFifoBuffer(bool enable)
		{
			if (enable)
			{
				this.CurvePreview.DirectoryName = Settings.Default.Curve_StoringFIFO_Directory;
				this.CurvePreview.UpdateCurve(0);
				this.CurvePreview.Show();
			}
			else
			{
				this.CurvePreview.Hide();
			}
		}

		private void enableCurveBuffer(bool enable)
		{
			if (enable)
			{
				this.CurvePreview.DirectoryName = Settings.Default._CurveAutoExportDefaultDirectory;
				this.CurvePreview.UpdateCurve(0);
				this.CurvePreview.Show();
			}
			else
			{
				this.CurvePreview.Hide();
			}
		}

		public void ShowWindow()
		{
			this.Main.ActivationBrowserGrantedBy = this;
			this.SetCurveNames();
			this.MenEna();
			if (this.Main.IsOnlineMode)
			{
				if (this.Main.NioCurveToShow.Length == 0)
				{
					this.GetCurve();
					this.ActualizeData();
				}
				else
				{
					this.enableFifoBuffer(false);
					this.loadCurve(this.Main.NioCurveToShow);
					this.ActualizeData();
					this.C_Curve1.StepInfoIncluded = this.stepInfoIncluded;
				}
			}
			this.Main.StatusBarText(string.Empty);
			base.Show();
		}

		private void timerRepaintCurve_Tick(object sender, EventArgs e)
		{
			this.timerRepaintCurve.Enabled = false;
			this.btZoomOut_Click(null, EventArgs.Empty);
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuAnalysis") + "/" + this.Main.Rm.GetString("MCurveDisplay");
			this.btBack.Text = this.Main.Rm.GetString("Back");
			this.btCursor.Text = this.Main.Rm.GetString("ToggleCursor");
			this.btCurveSelection.Text = this.Main.Rm.GetString("CurveSelection");
			this.btGetCurve.Text = this.Main.Rm.GetString("GetCurve");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btZoomIn.Text = this.Main.Rm.GetString("ZoomIn");
			this.btZoomOut.Text = this.Main.Rm.GetString("ZoomOut");
			this.btPrint.Text = this.Main.Rm.GetString("FileOperation");
			this.CurveSelection1.SetLanguageTexts();
			this.CurvePrint1.SetLanguageTexts();
			this.SetCurveNames();
			this.CurvePreview.SetLanguageTexts();
			this.openFileDialog.Filter = this.Main.Rm.GetString("CurveDisplay") + "|*.wcrv|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
		}

		private void MenEna()
		{
			if (this.Main.IsOnlineMode)
			{
				if (this.CurvesToShow == 0)
				{
					this.btGetCurve.Text = this.Main.Rm.GetString("GetCurve");
				}
				else
				{
					this.btGetCurve.Text = this.Main.Rm.GetString("AutoCurve") + "\n" + this.CurvesToShow.ToString();
				}
				this.btGetCurve.Enabled = true;
			}
			else
			{
				this.btGetCurve.Enabled = false;
				this.btGetCurve.Text = this.Main.Rm.GetString("GetCurve");
				this.curvesToShow = 0;
			}
		}

		private void btGetCurve_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.enableFifoBuffer(false);
				if (this.CurvesToShow == 0)
				{
					this.curvesToShow = int.Parse(Settings.Default.CurrentSaveCurveNum.ToString());
					this.MenEna();
				}
				else
				{
					this.curvesToShow = 0;
					this.MenEna();
				}
			}
		}

		private bool GetCurve()
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadCurveData"));
			Cursor.Current = Cursors.WaitCursor;
			if (!this.Main.VC.ReceiveVarBlock(20))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive CurveDefBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			if (!this.Main.VC.ReceiveVarBlock(21))
			{
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				MessageBox.Show("Could not receive CurveDataBlock!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			switch (this.Main.VC.CurveDef.UnitTorque)
			{
			case 0:
				this.TempResData.torqueScale = 1f;
				this.TempResData.torqueUnit = this.Main.Rm.GetString("TorqueNm");
				break;
			case 1:
				this.TempResData.torqueScale = 100f;
				this.TempResData.torqueUnit = this.Main.Rm.GetString("TorqueNcm");
				break;
			case 2:
				this.TempResData.torqueScale = 8.850745f;
				this.TempResData.torqueUnit = this.Main.Rm.GetString("Torqueinlb");
				break;
			case 3:
				this.TempResData.torqueScale = 0.7375621f;
				this.TempResData.torqueUnit = this.Main.Rm.GetString("Torqueftlb");
				break;
			case 4:
				this.TempResData.torqueScale = 141.6119f;
				this.TempResData.torqueUnit = this.Main.Rm.GetString("Torqueinoz");
				break;
			case 5:
				this.TempResData.torqueScale = 0.1019716f;
				this.TempResData.torqueUnit = this.Main.Rm.GetString("Torquekgm");
				break;
			case 6:
				this.TempResData.torqueScale = 10.19716f;
				this.TempResData.torqueUnit = this.Main.Rm.GetString("Torquekgcm");
				break;
			default:
				MessageBox.Show("Wrong unitTorque type in GetCurve() of CurveDisplay", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.TempResData.torqueScale = 1f;
				this.TempResData.torqueUnit = this.Main.Rm.GetString("TorqueNm");
				break;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("CalculateCurves"));
			this.TempCurveData = new float[12, this.Main.VC.CurveDef.Points];
			for (int i = 0; i < this.Main.VC.CurveDef.Points; i++)
			{
				this.TempCurveData[0, i] = (float)i;
				float[,] tempCurveData = this.TempCurveData;
				int num = i;
				float num2 = (float)this.Main.VC.CurveData.Point[i].Nset * this.Main.VC.CurveDef.SpeedSetScale;
				tempCurveData[1, num] = num2;
				float[,] tempCurveData2 = this.TempCurveData;
				int num3 = i;
				float num4 = (float)this.Main.VC.CurveData.Point[i].Nact * this.Main.VC.CurveDef.SpeedActScale;
				tempCurveData2[2, num3] = num4;
				float[,] tempCurveData3 = this.TempCurveData;
				int num5 = i;
				float num6 = this.Main.VC.CurveData.Point[i].Torque * this.TempResData.torqueScale;
				tempCurveData3[3, num5] = num6;
				float[,] tempCurveData4 = this.TempCurveData;
				int num7 = i;
				float num8 = this.Main.VC.CurveData.Point[i].FiltTorque * this.TempResData.torqueScale;
				tempCurveData4[4, num7] = num8;
				float[,] tempCurveData5 = this.TempCurveData;
				int num9 = i;
				float num10 = this.Main.VC.CurveData.Point[i].Gradient * this.TempResData.torqueScale;
				tempCurveData5[5, num9] = num10;
				float[,] tempCurveData6 = this.TempCurveData;
				int num11 = i;
				float angle = this.Main.VC.CurveData.Point[i].Angle;
				tempCurveData6[6, num11] = angle;
				float[,] tempCurveData7 = this.TempCurveData;
				int num12 = i;
				float aDepth = this.Main.VC.CurveData.Point[i].ADepth;
				tempCurveData7[7, num12] = aDepth;
				float[,] tempCurveData8 = this.TempCurveData;
				int num13 = i;
				float num14 = (float)(int)this.Main.VC.CurveData.Point[i].DDepth;
				tempCurveData8[8, num13] = num14;
				float[,] tempCurveData9 = this.TempCurveData;
				int num15 = i;
				float aDepthGrad = this.Main.VC.CurveData.Point[i].ADepthGrad;
				tempCurveData9[9, num15] = aDepthGrad;
				float[,] tempCurveData10 = this.TempCurveData;
				int num16 = i;
				float aExt = this.Main.VC.CurveData.Point[i].AExt;
				tempCurveData10[10, num16] = aExt;
				float[,] tempCurveData11 = this.TempCurveData;
				int num17 = i;
				float num18 = (float)(int)this.Main.VC.CurveData.Point[i].CurrentStep;
				tempCurveData11[11, num17] = num18;
			}
			this.TempResData.curvelength = this.Main.VC.CurveDef.Points;
			this.TempResData.cycle = this.Main.VC.Result.Cycle;
			try
			{
				this.TempResData.dt = new DateTime(this.Main.VC.Result.Time.Year, this.Main.VC.Result.Time.Month, this.Main.VC.Result.Time.Day, this.Main.VC.Result.Time.Hour, this.Main.VC.Result.Time.Minute, this.Main.VC.Result.Time.Second);
			}
			catch
			{
				this.TempResData.dt = new DateTime(1, 1, 1, 0, 0, 0);
			}
			this.TempResData.ionio = this.Main.VC.Result.IONIO;
			this.TempResData.prog = this.Main.VC.Result.Prog.Info.ProgNum;
			this.Main.CommonFunctions.RemoveTrailingBlanks(ref this.TempResData.screwID, this.Main.CommonFunctions.ByteToAlphanumericString(this.Main.VC.Result.ScrewID));
			Cursor.Current = Cursors.Default;
			this.Main.StatusBarText(string.Empty);
			return true;
		}

		public void ActualizeData()
		{
			string empty = string.Empty;
			this.stepInfoIncluded = true;
			try
			{
				if (this.TempCurveData.GetLength(0) == 11)
				{
					this.stepInfoIncluded = false;
				}
				for (int i = 0; i < this.TempResData.curvelength; i++)
				{
					float[,,] curveData = this.CurveData;
					int num = i;
					float num2 = this.TempCurveData[0, i];
					curveData[0, num, 0] = num2;
					float[,,] curveData2 = this.CurveData;
					int num3 = i;
					float num4 = this.TempCurveData[1, i];
					curveData2[1, num3, 0] = num4;
					float[,,] curveData3 = this.CurveData;
					int num5 = i;
					float num6 = this.TempCurveData[2, i];
					curveData3[2, num5, 0] = num6;
					float[,,] curveData4 = this.CurveData;
					int num7 = i;
					float num8 = this.TempCurveData[3, i];
					curveData4[3, num7, 0] = num8;
					float[,,] curveData5 = this.CurveData;
					int num9 = i;
					float num10 = this.TempCurveData[4, i];
					curveData5[4, num9, 0] = num10;
					float[,,] curveData6 = this.CurveData;
					int num11 = i;
					float num12 = this.TempCurveData[5, i];
					curveData6[5, num11, 0] = num12;
					float[,,] curveData7 = this.CurveData;
					int num13 = i;
					float num14 = this.TempCurveData[6, i];
					curveData7[6, num13, 0] = num14;
					float[,,] curveData8 = this.CurveData;
					int num15 = i;
					float num16 = this.TempCurveData[7, i];
					curveData8[7, num15, 0] = num16;
					float[,,] curveData9 = this.CurveData;
					int num17 = i;
					float num18 = this.TempCurveData[8, i];
					curveData9[8, num17, 0] = num18;
					float[,,] curveData10 = this.CurveData;
					int num19 = i;
					float num20 = this.TempCurveData[9, i];
					curveData10[9, num19, 0] = num20;
					float[,,] curveData11 = this.CurveData;
					int num21 = i;
					float num22 = this.TempCurveData[10, i];
					curveData11[10, num21, 0] = num22;
					if (this.stepInfoIncluded)
					{
						float[,,] curveData12 = this.CurveData;
						int num23 = i;
						float num24 = this.TempCurveData[11, i];
						curveData12[11, num23, 0] = num24;
					}
				}
			}
			catch
			{
			}
			for (int i = (int)this.TempResData.curvelength; i < 20000; i++)
			{
				this.CurveData[0, i, 0] = 0f;
				this.CurveData[1, i, 0] = 0f;
				this.CurveData[2, i, 0] = 0f;
				this.CurveData[3, i, 0] = 0f;
				this.CurveData[4, i, 0] = 0f;
				this.CurveData[5, i, 0] = 0f;
				this.CurveData[6, i, 0] = 0f;
				this.CurveData[7, i, 0] = 0f;
				this.CurveData[8, i, 0] = 0f;
				this.CurveData[9, i, 0] = 0f;
				this.CurveData[10, i, 0] = 0f;
				if (this.stepInfoIncluded)
				{
					this.CurveData[11, i, 0] = 0f;
				}
			}
			this.ResData.curvelength = this.TempResData.curvelength;
			this.ResData.cycle = this.TempResData.cycle;
			this.ResData.dt = this.TempResData.dt;
			this.ResData.ionio = this.TempResData.ionio;
			this.ResData.prog = this.TempResData.prog;
			this.ResData.screwID = this.TempResData.screwID;
			if (this.ResData.screwID.Length == 0)
			{
				this.ResData.screwID = "--";
			}
			this.ResData.torqueScale = this.TempResData.torqueScale;
			this.ResData.torqueUnit = this.TempResData.torqueUnit;
			this.SetCurveNames();
			this.C_Curve1.SetCurvesLength(this.ResData.curvelength);
			empty = ((this.ResData.ionio != 1) ? this.Main.Rm.GetString("NOK") : this.Main.Rm.GetString("OK"));
			this.C_Curve1.SetHeaderForPrintOut(this.Main.Rm.GetString("Abr_Program") + " " + this.ResData.prog.ToString() + "    " + this.Main.Rm.GetString("CycleNumber") + ": " + this.ResData.cycle.ToString() + "    " + this.Main.Rm.GetString("DateTime") + ": " + this.ResData.dt.ToString(Settings.Default.TimeSet) + "    " + empty + "    " + this.Main.Rm.GetString("ScrewID") + ": " + this.ResData.screwID);
			this.C_Curve1.InitializeDisplay();
			this.Text = this.Main.Rm.GetString("MenuAnalysis") + "/" + this.Main.Rm.GetString("MCurveDisplay") + ": " + this.Main.Rm.GetString("Abr_Program") + " " + this.ResData.prog.ToString() + " " + this.Main.Rm.GetString("CycleNumber") + ": " + this.ResData.cycle.ToString() + " " + this.Main.Rm.GetString("DateTime") + ": " + this.ResData.dt.ToString(Settings.Default.TimeSet) + " " + empty + " " + this.Main.Rm.GetString("ScrewID") + ": " + this.ResData.screwID;
			this.Main.SetMainText();
			if (this.TempResData.curvelength == 0)
			{
				this.btZoomIn.Enabled = false;
				this.btZoomOut.Enabled = false;
				this.btCursor.Enabled = false;
			}
			else
			{
				this.btZoomIn.Enabled = true;
				this.btZoomOut.Enabled = true;
				this.btCursor.Enabled = true;
			}
		}

		private void SetCurveNames()
		{
			this.CurveName[0] = this.Main.Rm.GetString("Time");
			this.CurveUnit[0] = this.Main.Rm.GetString("Milisecond");
			this.CurveName[1] = this.Main.Rm.GetString("SetRpm");
			this.CurveUnit[1] = this.Main.Rm.GetString("RpmUnit");
			this.CurveName[2] = this.Main.Rm.GetString("GetRpm");
			this.CurveUnit[2] = this.Main.Rm.GetString("RpmUnit");
			this.CurveName[3] = this.Main.Rm.GetString("Torque");
			this.CurveUnit[3] = this.ResData.torqueUnit;
			this.CurveName[4] = this.Main.Rm.GetString("FilteredTorque");
			this.CurveUnit[4] = this.ResData.torqueUnit;
			this.CurveName[5] = this.Main.Rm.GetString("Gradient");
			this.CurveUnit[5] = this.ResData.torqueUnit + "/" + this.Main.Rm.GetString("Degree");
			this.CurveName[6] = this.Main.Rm.GetString("Angle");
			this.CurveUnit[6] = this.Main.Rm.GetString("Degree");
			this.CurveName[7] = this.Main.Rm.GetString("AnaDepth");
			this.CurveUnit[7] = this.Main.Rm.GetString("Milimeter");
			this.CurveName[8] = this.Main.Rm.GetString("JawOpen");
			this.CurveUnit[8] = string.Empty;
			this.CurveName[9] = this.Main.Rm.GetString("DepthGrad");
			this.CurveUnit[9] = this.Main.Rm.GetString("Milimeter") + "/" + this.Main.Rm.GetString("Second");
			this.CurveName[10] = this.Main.Rm.GetString("PressureCylinder");
			this.CurveUnit[10] = this.Main.Rm.GetString("KiloNewton");
			this.C_Curve1.SetCurveNameAndUnit(this.CurveName, this.CurveUnit);
		}

		public void SetCurveNew()
		{
			bool flag = false;
			bool flag2 = false;
			if (this.CurvesToShow > 0)
			{
				this.curvesToShow--;
				this.MenEna();
				flag2 = this.GetCurve();
				flag = true;
				this.ActualizeData();
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("PaintCurve"));
				this.C_Curve1.StepInfoIncluded = this.stepInfoIncluded;
				this.C_Curve1.Repaint(false, false, false);
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
			}
			if (this.CurveIndex < this.CurvesToSave)
			{
				if (this.KindOfCurves == 0 && this.Main.VC.Result.IONIO >= 1)
				{
					goto IL_010c;
				}
				if (this.KindOfCurves == 2 && this.Main.VC.Result.IONIO > 1)
				{
					goto IL_010c;
				}
				if (this.KindOfCurves == 1 && this.Main.VC.Result.IONIO == 1)
				{
					goto IL_010c;
				}
			}
			goto IL_017f;
			IL_017f:
			if (Settings.Default.Curve_StoringToFIFO_active)
			{
				if (!flag2)
				{
					this.GetCurve();
				}
				this.Main.CurveFifo.GenerateCurve();
			}
			return;
			IL_010c:
			this.CurveIndex++;
			this.Main.MenuAnalysis1.Overview(true);
			if (!flag)
			{
				flag2 = this.GetCurve();
			}
			switch (this.ExportMode)
			{
			case 1:
				this.export(true);
				break;
			case 2:
				this.xmlExport(true);
				break;
			default:
				this.AutoSaveCurve(false);
				break;
			}
			this.CurvePrint1.MenEna(this.CurvesToSave - this.CurveIndex);
			goto IL_017f;
		}

		private void pnCurve_Paint(object sender, PaintEventArgs e)
		{
			if (!this.doNotUpdateCurve && !this.Main.Browser1.MachineVisuActive && !this.Main.BrowserHelp.HelpActive)
			{
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("PaintCurve"));
				this.C_Curve1.StepInfoIncluded = this.stepInfoIncluded;
				this.C_Curve1.Repaint(false, true, false);
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void pnCurve_MouseDown(object sender, MouseEventArgs e)
		{
			if (this.C_Curve1.Count != 0)
			{
				if (this.C_Curve1.SetCursor(e.X))
				{
					this.WriteCursorData(e.Y);
				}
				else
				{
					this.Main.StatusBarText(this.Main.Rm.GetString("CursorsCannotSwitch"));
				}
			}
		}

		private void pnCurve_MouseMove(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.pnCurve_MouseDown(sender, e);
			}
		}

		private void WriteCursorData(int y)
		{
			this.Main.StatusBarText(this.C_Curve1.GetCurveValues(y));
		}

		private void btCursor_Click(object sender, EventArgs e)
		{
			this.C_Curve1.SwapCursor();
			this.Main.StatusBarText(string.Empty);
		}

		private void btZoomIn_Click(object sender, EventArgs e)
		{
			this.enableFifoBuffer(false);
			Cursor.Current = Cursors.WaitCursor;
			this.curvesToShow = 0;
			this.MenEna();
			this.Main.StatusBarText(this.Main.Rm.GetString("CurvesZoomedIn"));
			this.C_Curve1.CurveZoom();
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
		}

		private void btZoomOut_Click(object sender, EventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;
			this.curvesToShow = 0;
			this.MenEna();
			this.Main.StatusBarText(this.Main.Rm.GetString("CurvesZoomedOut"));
			this.C_Curve1.InitializeDisplay();
			this.C_Curve1.StepInfoIncluded = this.stepInfoIncluded;
			this.C_Curve1.Repaint(false, false, false);
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			this.enableFifoBuffer(false);
			this.pnMenu.Enabled = false;
			this.curvesToShow = 0;
			this.MenEna();
			base.Hide();
			this.Main.StatusBarText(string.Empty);
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.enableFifoBuffer(false);
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btBack_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_2_1_Kurven";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_2_1_Kurven");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void btCurveSelection_Click(object sender, EventArgs e)
		{
			this.enableFifoBuffer(false);
			this.curvesToShow = 0;
			this.MenEna();
			this.CurveSelection1.ShowDialog();
			if (!this.CurveSelection1.Canceled)
			{
				this.SetCurvesToShow();
				this.C_Curve1.StepInfoIncluded = this.stepInfoIncluded;
				this.C_Curve1.Repaint(false, false, false);
			}
		}

		private void SetCurvesToShow()
		{
			this.C_Curve1.SetVectorNumXaxis(Settings.Default.SelectedXaxis);
			if (Settings.Default.Time)
			{
				this.C_Curve1.SetDisplayedYaxis(0);
			}
			else
			{
				this.C_Curve1.ResetDisplayedYaxis(0);
			}
			if (Settings.Default.SetRpm)
			{
				this.C_Curve1.SetDisplayedYaxis(1);
			}
			else
			{
				this.C_Curve1.ResetDisplayedYaxis(1);
			}
			if (Settings.Default.GetRpm)
			{
				this.C_Curve1.SetDisplayedYaxis(2);
			}
			else
			{
				this.C_Curve1.ResetDisplayedYaxis(2);
			}
			if (Settings.Default.Torque)
			{
				this.C_Curve1.SetDisplayedYaxis(3);
			}
			else
			{
				this.C_Curve1.ResetDisplayedYaxis(3);
			}
			if (Settings.Default.FilteredTorque)
			{
				this.C_Curve1.SetDisplayedYaxis(4);
			}
			else
			{
				this.C_Curve1.ResetDisplayedYaxis(4);
			}
			if (Settings.Default.TorqueGradient)
			{
				this.C_Curve1.SetDisplayedYaxis(5);
			}
			else
			{
				this.C_Curve1.ResetDisplayedYaxis(5);
			}
			if (Settings.Default.Angle)
			{
				this.C_Curve1.SetDisplayedYaxis(6);
			}
			else
			{
				this.C_Curve1.ResetDisplayedYaxis(6);
			}
			if (Settings.Default.AnalogDepth)
			{
				this.C_Curve1.SetDisplayedYaxis(7);
			}
			else
			{
				this.C_Curve1.ResetDisplayedYaxis(7);
			}
			if (Settings.Default.DigitalDepth)
			{
				this.C_Curve1.SetDisplayedYaxis(8);
			}
			else
			{
				this.C_Curve1.ResetDisplayedYaxis(8);
			}
			if (Settings.Default.DepthGradient)
			{
				this.C_Curve1.SetDisplayedYaxis(9);
			}
			else
			{
				this.C_Curve1.ResetDisplayedYaxis(9);
			}
			if (Settings.Default.AnalogSignal)
			{
				this.C_Curve1.SetDisplayedYaxis(10);
			}
			else
			{
				this.C_Curve1.ResetDisplayedYaxis(10);
			}
			this.C_Curve1.InitializeDisplay();
		}

		private void CurveDisplayForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void prepareCurveOutput()
		{
			int num = 0;
			if (this.stepInfoIncluded)
			{
				this.TempActualCurveData = new float[12, this.ResData.curvelength];
			}
			else
			{
				this.TempActualCurveData = new float[11, this.ResData.curvelength];
			}
			for (num = 0; num < this.ResData.curvelength; num++)
			{
				float[,] tempActualCurveData = this.TempActualCurveData;
				int num2 = num;
				float num3 = this.CurveData[0, num, 0];
				tempActualCurveData[0, num2] = num3;
				float[,] tempActualCurveData2 = this.TempActualCurveData;
				int num4 = num;
				float num5 = this.CurveData[1, num, 0];
				tempActualCurveData2[1, num4] = num5;
				float[,] tempActualCurveData3 = this.TempActualCurveData;
				int num6 = num;
				float num7 = this.CurveData[2, num, 0];
				tempActualCurveData3[2, num6] = num7;
				float[,] tempActualCurveData4 = this.TempActualCurveData;
				int num8 = num;
				float num9 = this.CurveData[3, num, 0];
				tempActualCurveData4[3, num8] = num9;
				float[,] tempActualCurveData5 = this.TempActualCurveData;
				int num10 = num;
				float num11 = this.CurveData[4, num, 0];
				tempActualCurveData5[4, num10] = num11;
				float[,] tempActualCurveData6 = this.TempActualCurveData;
				int num12 = num;
				float num13 = this.CurveData[5, num, 0];
				tempActualCurveData6[5, num12] = num13;
				float[,] tempActualCurveData7 = this.TempActualCurveData;
				int num14 = num;
				float num15 = this.CurveData[6, num, 0];
				tempActualCurveData7[6, num14] = num15;
				float[,] tempActualCurveData8 = this.TempActualCurveData;
				int num16 = num;
				float num17 = this.CurveData[7, num, 0];
				tempActualCurveData8[7, num16] = num17;
				float[,] tempActualCurveData9 = this.TempActualCurveData;
				int num18 = num;
				float num19 = this.CurveData[8, num, 0];
				tempActualCurveData9[8, num18] = num19;
				float[,] tempActualCurveData10 = this.TempActualCurveData;
				int num20 = num;
				float num21 = this.CurveData[9, num, 0];
				tempActualCurveData10[9, num20] = num21;
				float[,] tempActualCurveData11 = this.TempActualCurveData;
				int num22 = num;
				float num23 = this.CurveData[10, num, 0];
				tempActualCurveData11[10, num22] = num23;
				if (this.stepInfoIncluded)
				{
					float[,] tempActualCurveData12 = this.TempActualCurveData;
					int num24 = num;
					float num25 = this.CurveData[11, num, 0];
					tempActualCurveData12[11, num24] = num25;
				}
			}
		}

		private void saveCurve()
		{
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			this.saveFileDialog.Filter = this.Main.Rm.GetString("CurveDisplay") + "|*.wcrv|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			if (Settings.Default._CurveFileOperationDefaultDirectory.Length != 0)
			{
				this.saveFileDialog.InitialDirectory = Settings.Default._CurveFileOperationDefaultDirectory;
			}
			if (this.saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				Settings.Default._CurveFileOperationDefaultDirectory = this.saveFileDialog.InitialDirectory;
				Settings.Default.Save();
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveCurveDataToFile"));
				this.prepareCurveOutput();
				FileStream fileStream = null;
				try
				{
					fileStream = new FileStream(this.saveFileDialog.FileName, FileMode.Create);
					BinaryFormatter binaryFormatter = new BinaryFormatter();
					binaryFormatter.AssemblyFormat = FormatterAssemblyStyle.Simple;
					binaryFormatter.Serialize(fileStream, this.TempActualCurveData);
					binaryFormatter.Serialize(fileStream, this.ResData);
					fileStream.Close();
					fileStream.Dispose();
					Cursor.Current = Cursors.Default;
					this.Main.StatusBarText(string.Empty);
				}
				catch (Exception ex)
				{
					if (fileStream != null)
					{
						fileStream.Close();
						fileStream.Dispose();
					}
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Main.Rm.GetString("MbCurveSaveFailure") + ":\n" + ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		public void AutoSaveCurve(bool useFifoBuffer)
		{
			string text = string.Empty;
			Cursor.Current = Cursors.WaitCursor;
			this.Main.StatusBarText(this.Main.Rm.GetString("SaveCurveDataToFile"));
			if (!useFifoBuffer)
			{
				text = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.SystemID) + "_C" + this.TempResData.cycle.ToString("00000000") + "_P" + this.TempResData.prog.ToString() + "_ID" + this.TempResData.screwID;
				text = ((this.TempResData.ionio != 1) ? (text + "_NOK.wcrv") : (text + "_OK.wcrv"));
			}
			else
			{
				text = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.SystemID) + "_C" + this.TempResData.cycle.ToString("00000000") + "_P" + this.TempResData.prog.ToString() + "_ID" + this.TempResData.screwID;
				text = ((this.TempResData.ionio != 1) ? (text + "_NOK.wcrv") : (text + "_OK.wcrv"));
			}
			this.Main.CommonFunctions.RemoveTrailingBlanks(ref text, text);
			FileStream fileStream = null;
			try
			{
				fileStream = ((!useFifoBuffer) ? new FileStream(Settings.Default._CurveAutoExportDefaultDirectory + "\\" + text, FileMode.Create) : new FileStream(Settings.Default.Curve_StoringFIFO_Directory + "\\" + text, FileMode.Create));
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				binaryFormatter.AssemblyFormat = FormatterAssemblyStyle.Simple;
				binaryFormatter.Serialize(fileStream, this.TempCurveData);
				binaryFormatter.Serialize(fileStream, this.TempResData);
				fileStream.Close();
				fileStream.Dispose();
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
				this.errorMessage = "";
			}
			catch (Exception)
			{
				if (fileStream != null)
				{
					fileStream.Close();
					fileStream.Dispose();
				}
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
			}
		}

		public bool LoadCurve(string filename)
		{
			return this.loadCurve(filename);
		}

		private bool loadCurve(string filename)
		{
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			if (filename == null)
			{
				if (Settings.Default._CurveFileOperationDefaultDirectory.Length != 0)
				{
					this.openFileDialog.InitialDirectory = Settings.Default._CurveFileOperationDefaultDirectory;
				}
				if (this.openFileDialog.ShowDialog() != DialogResult.OK)
				{
					return false;
				}
				Settings.Default._CurveFileOperationDefaultDirectory = this.openFileDialog.InitialDirectory;
			}
			else
			{
				this.openFileDialog.FileName = filename;
			}
			this.Main.StatusBarText(this.Main.Rm.GetString("LoadCurveDataFromFile"));
			Cursor.Current = Cursors.WaitCursor;
			FileStream fileStream = null;
			BinaryFormatter binaryFormatter = null;
			try
			{
				fileStream = new FileStream(this.openFileDialog.FileName, FileMode.OpenOrCreate);
				binaryFormatter = new BinaryFormatter();
				binaryFormatter.Binder = new myBinder();
				this.TempCurveData = (float[,])binaryFormatter.Deserialize(fileStream);
				this.TempResData = (S_ResultData)binaryFormatter.Deserialize(fileStream);
				fileStream.Close();
				fileStream.Dispose();
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				return true;
			}
			catch (Exception ex)
			{
				if (fileStream != null)
				{
					fileStream.Close();
					fileStream.Dispose();
				}
				this.Main.StatusBarText(string.Empty);
				Cursor.Current = Cursors.Default;
				MessageBox.Show(this.Main.Rm.GetString("MbCurveEmpty") + ":\n" + ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
		}

		private void btPrint_Click(object sender, EventArgs e)
		{
			this.doNotUpdateCurve = true;
			this.enableFifoBuffer(false);
			this.CurvePrint1.ShowWindow();
			this.doNotUpdateCurve = false;
			int mode = this.CurvePrint1.GetMode();
			if (this.CurvesToShow != 0 && this.CurvesToShow != this.CurvePrint1.CurvesToStore)
			{
				this.curvesToShow = this.CurvePrint1.CurvesToStore;
				this.MenEna();
			}
			switch (mode)
			{
			case 1:
				this.C_Curve1.Print();
				break;
			case 2:
				this.prepareCurveOutput();
				this.export(false);
				break;
			case 4:
				this.prepareCurveOutput();
				this.xmlExport(false);
				break;
			case 3:
				this.saveCurve();
				break;
			case 5:
				if (Settings.Default._CurveAutoExportDefaultDirectory.Length != 0 && Directory.Exists(Settings.Default._CurveAutoExportDefaultDirectory))
				{
					goto IL_014d;
				}
				this.folderBrowserDialog.SelectedPath = Settings.Default._CurveAutoExportDefaultDirectory;
				this.folderBrowserDialog.Description = this.Main.Rm.GetString("WeberCurveFormat");
				if (this.folderBrowserDialog.ShowDialog() == DialogResult.OK)
				{
					Settings.Default._CurveAutoExportDefaultDirectory = this.folderBrowserDialog.SelectedPath;
					Settings.Default.Save();
					goto IL_014d;
				}
				break;
			case 6:
				if (Settings.Default._CurveAutoExportDefaultDirectory.Length != 0 && Directory.Exists(Settings.Default._CurveAutoExportDefaultDirectory))
				{
					goto IL_0227;
				}
				this.fBDExport.SelectedPath = Settings.Default._CurveAutoExportDefaultDirectory;
				this.fBDExport.Description = this.Main.Rm.GetString("Export");
				if (this.fBDExport.ShowDialog() == DialogResult.OK)
				{
					Settings.Default._CurveAutoExportDefaultDirectory = this.fBDExport.SelectedPath;
					Settings.Default.Save();
					goto IL_0227;
				}
				break;
			case 7:
				if (Settings.Default._CurveAutoExportDefaultDirectory.Length != 0 && Directory.Exists(Settings.Default._CurveAutoExportDefaultDirectory))
				{
					goto IL_02f5;
				}
				this.fBDExport.SelectedPath = Settings.Default._CurveAutoExportDefaultDirectory;
				this.fBDExport.Description = this.Main.Rm.GetString("XmlExport");
				if (this.fBDExport.ShowDialog() == DialogResult.OK)
				{
					Settings.Default._CurveAutoExportDefaultDirectory = this.fBDExport.SelectedPath;
					Settings.Default.Save();
					goto IL_02f5;
				}
				break;
			case 8:
				this.loadCurve(null);
				this.ActualizeData();
				this.C_Curve1.StepInfoIncluded = this.stepInfoIncluded;
				this.C_Curve1.Repaint(false, false, false);
				break;
			case 9:
				this.enableFifoBuffer(true);
				break;
			case 11:
				this.Main.CheckMaintenanceLabel(false);
				break;
			case 10:
				this.enableCurveBuffer(true);
				break;
			default:
				{
					this.Main.CheckMaintenanceLabel(false);
					break;
				}
				IL_02f5:
				this.ExportMode = 2;
				this.CurveIndex = 0;
				this.curvesToSave = this.CurvePrint1.GetResultNumber();
				this.KindOfCurves = this.CurvePrint1.GetResultKind();
				this.CurvePrint1.MenEna(this.CurvesToSave - this.CurveIndex);
				break;
				IL_014d:
				this.ExportMode = 0;
				this.CurveIndex = 0;
				this.curvesToSave = this.CurvePrint1.GetResultNumber();
				this.KindOfCurves = this.CurvePrint1.GetResultKind();
				this.CurvePrint1.MenEna(this.CurvesToSave - this.CurveIndex);
				this.Main.CheckMaintenanceLabel(false);
				break;
				IL_0227:
				this.ExportMode = 1;
				this.CurveIndex = 0;
				this.curvesToSave = this.CurvePrint1.GetResultNumber();
				this.KindOfCurves = this.CurvePrint1.GetResultKind();
				this.CurvePrint1.MenEna(this.CurvesToSave - this.CurveIndex);
				break;
			}
		}

		public void ResetCycleSaveMode()
		{
			this.CurveIndex = 0;
			this.curvesToSave = 0;
			this.CurvePrint1.MenEna(0);
			this.Main.MenuAnalysis1.Overview(true);
		}

		public bool IsAutomaticCurveModeActive()
		{
			if (this.CurveIndex < this.CurvesToSave)
			{
				return true;
			}
			return false;
		}

		public bool IsFifoCurveBufferActive()
		{
			if (Settings.Default.Curve_StoringToFIFO_active)
			{
				return true;
			}
			return false;
		}

		public void AutoModeAttributes(out int remaining, out string typeOfCurve, out string exportMode)
		{
			remaining = this.CurvesToSave - this.CurveIndex;
			switch (this.KindOfCurves)
			{
			case 0:
				typeOfCurve = this.Main.Rm.GetString("All");
				break;
			case 2:
				typeOfCurve = this.Main.Rm.GetString("OK");
				break;
			case 1:
				typeOfCurve = this.Main.Rm.GetString("NOK");
				break;
			default:
				typeOfCurve = "";
				break;
			}
			switch (this.ExportMode)
			{
			default:
				exportMode = this.Main.Rm.GetString("WeberCurveFormat");
				break;
			case 6:
				exportMode = this.Main.Rm.GetString("Export");
				break;
			case 7:
				exportMode = this.Main.Rm.GetString("XmlExport");
				break;
			}
		}

		private void export(bool isAutoSave)
		{
			string text = string.Empty;
			text = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.SystemID) + "_C" + this.TempResData.cycle.ToString("00000000") + "_P" + this.TempResData.prog.ToString() + "_ID" + this.TempResData.screwID;
			text = ((this.TempResData.ionio != 1) ? (text + "_NOK.txt") : (text + "_OK.txt"));
			this.Main.CommonFunctions.RemoveTrailingBlanks(ref text, text);
			if (isAutoSave)
			{
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveCurveDataToFile"));
				text = ((Settings.Default._CurveAutoExportDefaultDirectory.Length <= 0 || Settings.Default._CurveAutoExportDefaultDirectory.EndsWith("\\")) ? (Settings.Default._CurveAutoExportDefaultDirectory + text) : (Settings.Default._CurveAutoExportDefaultDirectory + "\\" + text));
				this.Main.CurveOut.ExportToTxt(text, this.CurveName, this.CurveUnit, this.TempCurveData, this.ResData);
				goto IL_027a;
			}
			this.saveFileDialog.Filter = this.Main.Rm.GetString("Export") + "|*.txt|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			if (Settings.Default._CurveFileOperationDefaultDirectory.Length != 0)
			{
				this.saveFileDialog.InitialDirectory = Settings.Default._CurveFileOperationDefaultDirectory;
			}
			this.saveFileDialog.FileName = text;
			if (this.saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				Settings.Default._CurveFileOperationDefaultDirectory = this.saveFileDialog.InitialDirectory;
				Settings.Default.Save();
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveCurveDataToFile"));
				this.Main.CurveOut.ExportToTxt(this.saveFileDialog.FileName, this.CurveName, this.CurveUnit, this.TempCurveData, this.ResData);
				goto IL_027a;
			}
			return;
			IL_027a:
			this.Main.StatusBarText("");
			Cursor.Current = Cursors.Default;
		}

		private void xmlExport(bool isAutoSave)
		{
			string text = string.Empty;
			text = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.SystemID) + "_C" + this.TempResData.cycle.ToString("00000000") + "_P" + this.TempResData.prog.ToString() + "_ID" + this.TempResData.screwID;
			text = ((this.TempResData.ionio != 1) ? (text + "_NOK.kxml") : (text + "_OK.kxml"));
			char[] trimChars = new char[1]
			{
				' '
			};
			text = text.TrimEnd(trimChars);
			this.Main.CommonFunctions.RemoveTrailingBlanks(ref text, text);
			if (isAutoSave)
			{
				text = ((Settings.Default._CurveAutoExportDefaultDirectory.Length <= 0 || Settings.Default._CurveAutoExportDefaultDirectory.EndsWith("\\")) ? (Settings.Default._CurveAutoExportDefaultDirectory + text) : (Settings.Default._CurveAutoExportDefaultDirectory + "\\" + text));
				this.SetCurveNames();
				this.Main.CurveOut.ExportToXml(text, this.CurveName, this.CurveUnit, this.TempCurveData, this.ResData);
				goto IL_0268;
			}
			this.saveFileDialog.Filter = this.Main.Rm.GetString("XmlExport") + "|*.kxml|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			if (Settings.Default._CurveFileOperationDefaultDirectory.Length != 0)
			{
				this.saveFileDialog.InitialDirectory = Settings.Default._CurveFileOperationDefaultDirectory;
			}
			this.saveFileDialog.FileName = text;
			if (this.saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				Settings.Default._CurveFileOperationDefaultDirectory = this.saveFileDialog.InitialDirectory;
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveCurveDataToFile"));
				this.SetCurveNames();
				this.Main.CurveOut.ExportToXml(this.saveFileDialog.FileName, this.CurveName, this.CurveUnit, this.TempCurveData, this.ResData);
				goto IL_0268;
			}
			return;
			IL_0268:
			this.Main.StatusBarText("");
			Cursor.Current = Cursors.Default;
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
			this.CurvePrint1.Cancel();
			this.CurveSelection1.Cancel();
			this.btHome_Click(null, EventArgs.Empty);
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		private void btGetCurve_Click(object sender, EventArgs e)
		{
		}

		public void TemporaryNoRepaint()
		{
			this.C_Curve1.TemporaryNoRepaint();
		}

		private void btPrint_Click_1(object sender, EventArgs e)
		{

		}

		private void btGetCurve_Click_1(object sender, EventArgs e)
		{

		}
	}
}
