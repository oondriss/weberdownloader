using System;
using System.Collections.Generic;
using System.Threading;

namespace Visualisation
{
	internal class FtpDownloadThreadClass
	{
		private MainForm Main;

		private Thread downloadThread;

		private Thread uploadThread;

		public FtpClass FtpRequest;

		public int NumberOfFilesDownloaded;

		public int NumberOfFilesUploaded;

		private DateTime startedAt = DateTime.MinValue;

		private bool downloadActive;

		private bool halt;

		private string defaultDirectory = "";

		private List<string> filenames;

		public bool DownloadActive => this.downloadActive;

		public bool Halt
		{
			get
			{
				return this.halt;
			}
			set
			{
				if (this.FtpRequest != null)
				{
					FtpClass ftpRequest = this.FtpRequest;
					bool flag2 = ftpRequest.Halt = value;
					this.halt = flag2;
				}
			}
		}

		public string CurrentlyProcessedFile => this.FtpRequest.CurrentlyProcessedFile;

		public void KillDownload()
		{
			if (this.downloadThread != null && this.downloadThread.IsAlive)
			{
				this.downloadActive = false;
				this.downloadThread.Abort();
				this.FtpRequest.Cancel();
			}
			if (this.uploadThread != null && this.uploadThread.IsAlive)
			{
				this.downloadActive = false;
				this.uploadThread.Abort();
				this.FtpRequest.Cancel();
			}
		}

		public FtpDownloadThreadClass(MainForm main)
		{
			this.Main = main;
			this.FtpRequest = new FtpClass(this.Main);
		}

		public void StartDownload(string storeToDirectory)
		{
			this.defaultDirectory = storeToDirectory;
			this.downloadActive = true;
			this.startedAt = DateTime.Now;
			this.downloadThread = new Thread(this.downloadFilesThread);
			this.downloadThread.Start();
		}

		public void StartUpload(List<string> _filenames, string storeToDirectory)
		{
			this.defaultDirectory = storeToDirectory;
			this.filenames = _filenames;
			this.downloadActive = true;
			this.startedAt = DateTime.Now;
			this.uploadThread = new Thread(this.uploadFilesThread);
			this.uploadThread.Start();
		}

		public TimeSpan ElapsedTime()
		{
			return DateTime.Now - this.startedAt;
		}

		private void downloadFilesThread()
		{
			string stationName = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName);
			string ipAddress = this.Main.MyIp.ToString();
			this.NumberOfFilesDownloaded = 0;
			this.FtpRequest.DefaultDirectory = this.defaultDirectory;
			this.NumberOfFilesDownloaded = this.FtpRequest.DownloadFilesFTP(ipAddress, stationName, true);
			this.downloadActive = false;
			this.downloadThread = null;
		}

		private void uploadFilesThread()
		{
			string stationName = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName);
			string ipAddress = this.Main.MyIp.ToString();
			this.NumberOfFilesUploaded = 0;
			this.FtpRequest.DefaultDirectory = this.defaultDirectory;
			this.NumberOfFilesUploaded = this.FtpRequest.UploadFilesToStation(this.filenames, ipAddress, stationName, true);
			this.downloadActive = false;
			this.uploadThread = null;
		}
	}
}
