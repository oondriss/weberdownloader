using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Visualisation
{
	public class CurvePreview : Form
	{
		private MainForm Main;

		private bool firstCurveDrawn;

		private string directoryName = "";

		private int currentWidth1;

		private int currentWidth2;

		private int currentWidth3;

		private bool initializing;

		private bool selectionInProgress;

		private int recentlySelectedIndex = -1;

		private IContainer components;

		private DataGridView dGVCurves;

		public string DirectoryName
		{
			get
			{
				return this.directoryName;
			}
			set
			{
				this.Main.CurveFifo.GetNewCurveInfo(value);
				this.directoryName = value;
			}
		}

		public CurvePreview(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.dGVCurves.Columns.Add("Col1", "Datei");
			this.dGVCurves.Columns.Add("Col2", "Datum");
			this.dGVCurves.Columns.Add("Col3", "Groesse");
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MCurveSelection");
			this.dGVCurves.Columns[0].HeaderText = this.Main.Rm.GetString("Files");
			this.dGVCurves.Columns[1].HeaderText = this.Main.Rm.GetString("DateTime");
			this.dGVCurves.Columns[2].HeaderText = this.Main.Rm.GetString("Size");
		}

		private void CurvePreview_FormClosing(object sender, FormClosingEventArgs e)
		{
			this.currentWidth1 = this.dGVCurves.Columns[0].Width;
			this.currentWidth2 = this.dGVCurves.Columns[1].Width;
			this.currentWidth3 = this.dGVCurves.Columns[2].Width;
			e.Cancel = true;
			base.Hide();
		}

		public void KeyArrived()
		{
		}

		public void KeyRemoved()
		{
		}

		private void dGVCurves_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			this.dGVCurves[e.ColumnIndex, e.RowIndex].Style.BackColor = Color.White;
		}

		public void UpdateCurve(int index)
		{
			this.initializing = true;
			this.dGVCurves.Rows.Clear();
			this.dGVCurves.Columns.Clear();
			this.dGVCurves.Columns.Add("Col1", "Datei");
			this.dGVCurves.Columns.Add("Col2", "Datum");
			this.dGVCurves.Columns.Add("Col2", "Groesse");
			this.dGVCurves.Columns[0].HeaderText = this.Main.Rm.GetString("Files");
			this.dGVCurves.Columns[1].HeaderText = this.Main.Rm.GetString("DateTime");
			this.dGVCurves.Columns[2].HeaderText = this.Main.Rm.GetString("Size");
			if (this.currentWidth1 != 0)
			{
				this.dGVCurves.Columns[0].Width = this.currentWidth1;
			}
			else
			{
				this.dGVCurves.Columns[0].Width = 240;
			}
			if (this.currentWidth1 != 0)
			{
				this.dGVCurves.Columns[1].Width = this.currentWidth2;
			}
			else
			{
				this.dGVCurves.Columns[1].Width = 120;
			}
			if (this.currentWidth1 != 0)
			{
				this.dGVCurves.Columns[2].Width = this.currentWidth3;
			}
			else
			{
				this.dGVCurves.Columns[2].Width = 60;
			}
			this.dGVCurves.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
			this.Main.CurveFifo.DirectoryName = this.directoryName;
			int num = 0;
			if (this.Main.CurveFifo.CurveFilesUnsorted != null)
			{
				num = this.Main.CurveFifo.CurveFilesUnsorted.Count();
			}
			if (num > 0)
			{
				this.dGVCurves.Rows.Add(num);
			}
			try
			{
				for (int i = 0; i < num; i++)
				{
					string text = this.Main.CurveFifo.CurveFilesUnsorted[i];
					FileInfo fileInfo = new FileInfo(text);
					this.dGVCurves.Rows[i].Cells[0].Value = Path.GetFileNameWithoutExtension(text);
					this.dGVCurves.Rows[i].Cells[1].Value = fileInfo.CreationTime;
					this.dGVCurves.Rows[i].Cells[2].Value = fileInfo.Length / 1024;
				}
			}
			catch (Exception)
			{
				this.dGVCurves.Rows.Clear();
				return;
			}
			if (index < this.dGVCurves.Rows.Count)
			{
				if (!this.firstCurveDrawn)
				{
					this.firstCurveDrawn = true;
				}
				else
				{
					string fileNameWithoutExtension = this.dGVCurves.Rows[0].Cells[0].Value.ToString();
					this.Main.CurveFifo.Show(this.directoryName, fileNameWithoutExtension);
				}
				this.initializing = false;
			}
		}

		private void btShow_Click(object sender, EventArgs e)
		{
			int currentIndex = this.Main.CurveFifo.CurrentIndex;
			this.Main.CurveFifo.Show(this.directoryName, this.dGVCurves.Rows[currentIndex].Cells[0].Value.ToString());
		}

		private void dGVCurves_SelectionChanged(object sender, EventArgs e)
		{
			if (this.dGVCurves.SelectedCells.Count != 0 && !this.initializing)
			{
				if (this.selectionInProgress)
				{
					this.dGVCurves.Rows[this.dGVCurves.SelectedRows[0].Index].Selected = false;
					if (this.recentlySelectedIndex >= 0)
					{
						this.dGVCurves.Rows[this.recentlySelectedIndex].Selected = false;
					}
				}
				else
				{
					this.selectionInProgress = true;
					this.recentlySelectedIndex = this.dGVCurves.SelectedRows[0].Index;
					Application.DoEvents();
					if (this.dGVCurves.SelectedRows.Count == 0)
					{
						this.selectionInProgress = false;
					}
					else
					{
						string fileNameWithoutExtension = this.dGVCurves.SelectedRows[0].Cells[0].Value.ToString();
						this.Main.CurveFifo.Show(this.directoryName, fileNameWithoutExtension);
						this.selectionInProgress = false;
					}
				}
			}
		}

		private void CurvePreview_LocationChanged(object sender, EventArgs e)
		{
			this.Main.CurveDisplay1.TemporaryNoRepaint();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.dGVCurves = new DataGridView();
			((ISupportInitialize)this.dGVCurves).BeginInit();
			base.SuspendLayout();
			this.dGVCurves.AllowUserToAddRows = false;
			this.dGVCurves.AllowUserToDeleteRows = false;
			this.dGVCurves.AllowUserToResizeRows = false;
			this.dGVCurves.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
			this.dGVCurves.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dGVCurves.Location = new Point(0, 0);
			this.dGVCurves.MultiSelect = false;
			this.dGVCurves.Name = "dGVCurves";
			this.dGVCurves.ReadOnly = true;
			this.dGVCurves.RowHeadersVisible = false;
			this.dGVCurves.RowHeadersWidth = 170;
			this.dGVCurves.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			this.dGVCurves.Size = new Size(443, 292);
			this.dGVCurves.TabIndex = 2;
			this.dGVCurves.CellFormatting += this.dGVCurves_CellFormatting;
			this.dGVCurves.SelectionChanged += this.dGVCurves_SelectionChanged;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(444, 292);
			base.Controls.Add(this.dGVCurves);
			base.FormBorderStyle = FormBorderStyle.Fixed3D;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "CurvePreview";
			base.Opacity = 0.95;
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			this.Text = "CurvePreview";
			base.TopMost = true;
			base.FormClosing += this.CurvePreview_FormClosing;
			base.LocationChanged += this.CurvePreview_LocationChanged;
			((ISupportInitialize)this.dGVCurves).EndInit();
			base.ResumeLayout(false);
		}
	}
}
