using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.Threading;
using System.Windows.Forms;
using Visualisation.Properties;
using WSP1_VARCOMM1;

namespace Visualisation
{
	public class MaintenanceForm : Form
	{
		private const int almostElapsedDays = 7;

		private const int almostElapsedCycles = 1000;

		private MainForm Main;

		private int PrintPos;

		private string[] ColumnName;

		private MaintenanceNewEntryForm maintNewForm;

		private readonly Color statusOkColor = Color.LightGreen;

		private readonly Color statusAlmostElapsedColor = Color.Yellow;

		private readonly Color statusElapsedColor = Color.Orange;

		private readonly Color statusElapsedColorForText = Color.DarkOrange;

		private Panel pnMenu;

		private Button btBack;

		private Button btDelete;

		private Button btHelp;

		private Button btNewEntry;

		private Button bt3;

		private Button btPrint;

		private PrintDocument printDocument;

		private PrintDialog printDialog;

		private Button btCancel;

		private SaveFileDialog SFD;

		private Label label1;

		private Button btEdit;

		private Container components;

		private DataGridView dGMResults;

		private List<WSP1_VarComm.MaintenanceBufferStruct> MaintenanceDataList = new List<WSP1_VarComm.MaintenanceBufferStruct>();

		private int maintenanceElapsed;

		private int maintenanceAlmostElapsed;

		private bool paintedOnce;

		private int maintenanceListCount => this.dGMResults.Rows.Count;

		public bool IsMaintenanceTimeElapsed
		{
			get
			{
				if (this.maintenanceElapsed > 0)
				{
					return true;
				}
				return false;
			}
		}

		public bool IsMaintenanceTimeNearlyElapsed
		{
			get
			{
				if (this.maintenanceAlmostElapsed > 0)
				{
					return true;
				}
				return false;
			}
		}

		public MaintenanceForm(MainForm main)
		{
			this.Main = main;
			this.InitializeComponent();
			this.maintNewForm = new MaintenanceNewEntryForm(this.Main);
			this.PrintPos = 0;
		}

		private void initDataGrid()
		{
			this.ColumnName = new string[8];
			this.ColumnName[0] = "Number";
			this.ColumnName[1] = "Date";
			this.ColumnName[2] = "ScheduledDate";
			this.ColumnName[3] = "Message";
			this.ColumnName[4] = "Reminder";
			this.ColumnName[5] = "DaysUntil";
			this.ColumnName[6] = "User";
			this.dGMResults.Columns.Clear();
			this.dGMResults.Columns.Add("Col1", this.ColumnName[0]);
			this.dGMResults.Columns.Add("Col2", this.ColumnName[1]);
			this.dGMResults.Columns.Add("Col4", this.ColumnName[2]);
			this.dGMResults.Columns.Add("Col3", this.ColumnName[3]);
			this.dGMResults.Columns.Add("Col5", this.ColumnName[4]);
			this.dGMResults.Columns.Add("Col6", this.ColumnName[5]);
			this.dGMResults.Columns.Add("Col7", this.ColumnName[6]);
			this.dGMResults.Columns[0].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[1].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[2].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[3].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[4].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[5].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[6].SortMode = DataGridViewColumnSortMode.NotSortable;
			this.dGMResults.Columns[0].Width = 25;
			this.dGMResults.Columns[1].Width = 40;
			this.dGMResults.Columns[2].Width = 220;
			this.dGMResults.Columns[2].MinimumWidth = 250;
			this.dGMResults.Columns[3].Width = 40;
			this.dGMResults.Columns[4].Width = 40;
			this.dGMResults.Columns[5].Width = 60;
			this.dGMResults.Columns[6].Width = 40;
			this.dGMResults.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[3].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[5].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[6].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.dGMResults.Columns[0].HeaderText = this.Main.Rm.GetString("Number");
			this.dGMResults.Columns[1].HeaderText = this.Main.Rm.GetString("DateTime");
			this.dGMResults.Columns[2].HeaderText = this.Main.Rm.GetString("MMaintenance");
			this.dGMResults.Columns[3].HeaderText = this.Main.Rm.GetString("NextMaintScheduled");
			this.dGMResults.Columns[4].HeaderText = this.Main.Rm.GetString("Kind");
			this.dGMResults.Columns[5].HeaderText = this.Main.Rm.GetString("DaysToNextMaint");
			this.dGMResults.Columns[6].HeaderText = this.Main.Rm.GetString("User");
		}

		private void MaintenanceForm_Load(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
			this.pnMenu = new Panel();
			this.btEdit = new Button();
			this.btPrint = new Button();
			this.btCancel = new Button();
			this.btNewEntry = new Button();
			this.bt3 = new Button();
			this.btDelete = new Button();
			this.btHelp = new Button();
			this.btBack = new Button();
			this.printDocument = new PrintDocument();
			this.printDialog = new PrintDialog();
			this.SFD = new SaveFileDialog();
			this.label1 = new Label();
			this.dGMResults = new DataGridView();
			this.pnMenu.SuspendLayout();
			((ISupportInitialize)this.dGMResults).BeginInit();
			base.SuspendLayout();
			this.pnMenu.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.pnMenu.Controls.Add(this.btEdit);
			this.pnMenu.Controls.Add(this.btPrint);
			this.pnMenu.Controls.Add(this.btCancel);
			this.pnMenu.Controls.Add(this.btNewEntry);
			this.pnMenu.Controls.Add(this.bt3);
			this.pnMenu.Controls.Add(this.btDelete);
			this.pnMenu.Controls.Add(this.btHelp);
			this.pnMenu.Controls.Add(this.btBack);
			this.pnMenu.Location = new Point(709, 0);
			this.pnMenu.Name = "pnMenu";
			this.pnMenu.Size = new Size(80, 516);
			this.pnMenu.TabIndex = 0;
			this.btEdit.Enabled = false;
			this.btEdit.Location = new Point(3, 131);
			this.btEdit.Name = "btEdit";
			this.btEdit.Size = new Size(74, 62);
			this.btEdit.TabIndex = 2;
			this.btEdit.Text = "Eintrag bearbeiten";
			this.btEdit.Click += this.btEdit_Click;
			this.btPrint.Location = new Point(3, 387);
			this.btPrint.Name = "btPrint";
			this.btPrint.Size = new Size(74, 62);
			this.btPrint.TabIndex = 6;
			this.btPrint.Text = "Print";
			this.btPrint.Click += this.btPrint_Click;
			this.btCancel.Location = new Point(3, 451);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new Size(74, 62);
			this.btCancel.TabIndex = 7;
			this.btCancel.Text = "Änderungen verwerfen";
			this.btCancel.Click += this.btCancel_Click;
			this.btNewEntry.Location = new Point(3, 195);
			this.btNewEntry.Name = "btNewEntry";
			this.btNewEntry.Size = new Size(74, 62);
			this.btNewEntry.TabIndex = 3;
			this.btNewEntry.Text = "New entry";
			this.btNewEntry.Click += this.btNewEntry_Click;
			this.bt3.Enabled = false;
			this.bt3.Location = new Point(3, 323);
			this.bt3.Name = "bt3";
			this.bt3.Size = new Size(74, 62);
			this.bt3.TabIndex = 5;
			this.btDelete.Location = new Point(3, 259);
			this.btDelete.Name = "btDelete";
			this.btDelete.Size = new Size(74, 62);
			this.btDelete.TabIndex = 4;
			this.btDelete.Text = "Eintrag löschen";
			this.btDelete.Click += this.btDelete_Click;
			//this.btHelp.Image = Resources.Home1;
			this.btHelp.Location = new Point(3, 67);
			this.btHelp.Name = "btHelp";
			this.btHelp.Size = new Size(74, 62);
			this.btHelp.TabIndex = 1;
			this.btHelp.Click += this.btHome_Click;
			this.btBack.Location = new Point(3, 3);
			this.btBack.Name = "btBack";
			this.btBack.Size = new Size(74, 62);
			this.btBack.TabIndex = 0;
			this.btBack.Text = "Zurück";
			this.btBack.Click += this.btBack_Click;
			this.printDocument.PrintPage += this.printDocument_PrintPage;
			this.printDialog.Document = this.printDocument;
			this.SFD.Filter = "Maintenance list|*.txt|All Files|*.*";
			this.label1.AutoSize = true;
			this.label1.Location = new Point(26, 242);
			this.label1.Name = "label1";
			this.label1.Size = new Size(655, 15);
			this.label1.TabIndex = 2;
			this.label1.Text = "DataGrid LogGrid will not be displayed in Editor due to introduction of derived class DataGrid_Specific_Class (DataGrid defined there!)";
			this.label1.Visible = false;
			this.dGMResults.AllowUserToAddRows = false;
			this.dGMResults.AllowUserToDeleteRows = false;
			this.dGMResults.AllowUserToResizeColumns = false;
			this.dGMResults.AllowUserToResizeRows = false;
			dataGridViewCellStyle.WrapMode = DataGridViewTriState.True;
			this.dGMResults.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle;
			this.dGMResults.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
			this.dGMResults.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
			this.dGMResults.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = SystemColors.Window;
			dataGridViewCellStyle2.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = Color.Transparent;
			dataGridViewCellStyle2.SelectionForeColor = Color.Black;
			dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
			this.dGMResults.DefaultCellStyle = dataGridViewCellStyle2;
			this.dGMResults.Location = new Point(0, 0);
			this.dGMResults.MultiSelect = false;
			this.dGMResults.Name = "dGMResults";
			this.dGMResults.ReadOnly = true;
			this.dGMResults.RowHeadersVisible = false;
			this.dGMResults.RowHeadersWidth = 10;
			dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
			this.dGMResults.RowsDefaultCellStyle = dataGridViewCellStyle3;
			this.dGMResults.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			this.dGMResults.Size = new Size(709, 522);
			this.dGMResults.TabIndex = 3;
			this.dGMResults.CellDoubleClick += this.dGMResults_CellDoubleClick;
			this.dGMResults.DataBindingComplete += this.dGMResults_DataBindingComplete;
			this.dGMResults.RowPostPaint += this.dGMResults_RowPostPaint;
			this.dGMResults.Scroll += this.dGMResults_Scroll;
			this.dGMResults.SelectionChanged += this.dGMResults_SelectionChanged;
			this.dGMResults.Sorted += this.dGMResults_Sorted;
			this.dGMResults.Paint += this.dGMResults_Paint;
			this.dGMResults.MouseDown += this.dGMResults_MouseDown;
			base.AutoScaleMode = AutoScaleMode.None;
			this.AutoSize = true;
			base.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			base.ClientSize = new Size(789, 544);
			base.ControlBox = false;
			base.Controls.Add(this.dGMResults);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.pnMenu);
			this.Font = new Font("Arial Unicode MS", 11f, FontStyle.Regular, GraphicsUnit.Pixel, 0);
			base.FormBorderStyle = FormBorderStyle.None;
			base.Name = "MaintenanceForm";
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "Wartungsmeldungen";
			base.Activated += this.LogChangesForm_Activated;
			base.Load += this.MaintenanceForm_Load;
			this.pnMenu.ResumeLayout(false);
			((ISupportInitialize)this.dGMResults).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public bool ShowWindow()
		{
			this.btEdit.Enabled = Settings.Default.IntegratedMachineVisu;
			if (!this.Main.IsOnlineMode)
			{
				this.btPrint.Enabled = false;
				this.btEdit.Enabled = false;
				this.btBack.Enabled = false;
				base.Show();
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnection"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return false;
			}
			this.MenEna();
			this.readDataFromWSP();
			this.updateMenu();
			base.Show();
			if (this.dGMResults.Rows.Count > 0)
			{
				this.dGMResults.Rows[0].Selected = false;
			}
			this.Main.StatusBarText(string.Empty);
			Cursor.Current = Cursors.Default;
			return true;
		}

		private void MenEna()
		{
			bool enabled = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_Maintenance)
			{
				enabled = true;
			}
			if (this.dGMResults.SelectedRows.Count == 0)
			{
				this.btDelete.Enabled = false;
				this.btEdit.Enabled = false;
			}
			else
			{
				this.btDelete.Enabled = enabled;
				this.btEdit.Enabled = enabled;
			}
			this.btNewEntry.Enabled = enabled;
			this.btBack.Enabled = enabled;
			this.btPrint.Enabled = true;
			if (this.Main._READ_ONLY_CONTROLLER)
			{
				this.btBack.Enabled = false;
			}
			else
			{
				this.btBack.Enabled = true;
			}
		}

		public void SetLanguageTexts()
		{
			this.Text = this.Main.Rm.GetString("MenuParameter") + "/" + this.Main.Rm.GetString("MenuMaintenance") + "/" + this.Main.Rm.GetString("MMaintenance");
			this.btBack.Text = this.Main.Rm.GetString("StoreAndBack");
			this.btHelp.Text = this.Main.Rm.GetString("btHome");
			this.btPrint.Text = this.Main.Rm.GetString("Print");
			this.btCancel.Text = this.Main.Rm.GetString("EditCancel");
			this.printDocument.DocumentName = this.Main.Rm.GetString("MMaintenance");
			this.btNewEntry.Text = this.Main.Rm.GetString("btNewEntrie");
			this.btEdit.Text = this.Main.Rm.GetString("ChangeEntry");
			this.SFD.Filter = this.Main.Rm.GetString("MaintenanceList") + "|*.txt|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.initDataGrid();
		}

		public Color GetInfo(out bool anythingOk, out int numberOfEntries, out int numberOfAlmostExceeded, out int numberOfExceeded, bool readFromWsp)
		{
			numberOfEntries = this.MaintenanceDataList.Count;
			numberOfAlmostExceeded = this.maintenanceAlmostElapsed;
			numberOfExceeded = this.maintenanceElapsed;
			anythingOk = true;
			return Color.Black;
		}

		private void updateMenu()
		{
			string empty = string.Empty;
			string text = "";
			for (int i = 0; i < this.dGMResults.Columns.Count; i++)
			{
				this.dGMResults.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			}
			this.dGMResults.Rows.Clear();
			for (int j = 0; j < this.MaintenanceDataList.Count; j++)
			{
				this.dGMResults.Rows.Add();
				this.dGMResults.Rows[j].Cells[0].Value = this.MaintenanceDataList[j].Index;
				DateTime d;
				try
				{
					d = new DateTime(this.MaintenanceDataList[j].Time.Year, this.MaintenanceDataList[j].Time.Month, this.MaintenanceDataList[j].Time.Day, this.MaintenanceDataList[j].Time.Hour, this.MaintenanceDataList[j].Time.Minute, this.MaintenanceDataList[j].Time.Second);
				}
				catch
				{
					d = new DateTime(1, 1, 1, 0, 0, 0);
				}
				text = d.ToString(Settings.Default.TimeSet);
				this.dGMResults.Rows[j].Cells[1].Value = text;
				this.dGMResults.Rows[j].Cells[2].Value = this.Main.CommonFunctions.UShortToString(this.MaintenanceDataList[j].MaintenanceText);
				try
				{
					d = new DateTime(this.MaintenanceDataList[j].ScheduledTime.Year, this.MaintenanceDataList[j].ScheduledTime.Month, this.MaintenanceDataList[j].ScheduledTime.Day, this.MaintenanceDataList[j].ScheduledTime.Hour, this.MaintenanceDataList[j].ScheduledTime.Minute, this.MaintenanceDataList[j].ScheduledTime.Second);
				}
				catch
				{
					d = new DateTime(1, 1, 1, 0, 0, 0);
				}
				string format = Settings.Default.TimeSet.Remove(Settings.Default.TimeSet.IndexOf(' '));
				text = d.ToString(format) + "\n(" + this.MaintenanceDataList[j].NextCycle.ToString() + ")";
				this.dGMResults.Rows[j].Cells[3].Value = text;
				if (this.MaintenanceDataList[j].Reminder == 3)
				{
					this.dGMResults.Rows[j].Cells[4].Value = this.Main.Rm.GetString("MaintFault");
				}
				else if (this.MaintenanceDataList[j].Reminder == 2)
				{
					this.dGMResults.Rows[j].Cells[4].Value = this.Main.Rm.GetString("MaintWarning");
				}
				else
				{
					this.dGMResults.Rows[j].Cells[4].Value = this.Main.Rm.GetString("MaintRemainder");
				}
				int days = (d - DateTime.Now).Days;
				int num = (int)(this.MaintenanceDataList[j].NextCycle - this.Main.VC.CycleCount.Machine);
				this.dGMResults.Rows[j].Cells[5].Value = days.ToString() + "\n" + num.ToString();
				if (days <= 0 || num <= 0)
				{
					this.dGMResults.Rows[j].Cells[5].Style.BackColor = this.statusElapsedColor;
				}
				else if (days > 7 && num > 1000)
				{
					this.dGMResults.Rows[j].Cells[5].Style.BackColor = this.statusOkColor;
				}
				else
				{
					this.dGMResults.Rows[j].Cells[5].Style.BackColor = this.statusAlmostElapsedColor;
				}
				this.dGMResults.Rows[j].Cells[6].Value = this.Main.CommonFunctions.UShortToString(this.MaintenanceDataList[j].userName);
			}
			for (int k = 0; k < this.dGMResults.Columns.Count; k++)
			{
				this.dGMResults.Columns[k].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			}
			foreach (DataGridViewRow selectedRow in this.dGMResults.SelectedRows)
			{
				this.dGMResults.Rows[selectedRow.Index].Selected = false;
			}
		}

		private bool importDataFromVC()
		{
			bool result = true;
			for (int i = 0; i < 32; i++)
			{
				string text = this.Main.CommonFunctions.UShortToString(this.Main.VC.MaintenanceDataBlock.MaintenanceData[i].MaintenanceText);
				if (text.Length == 0)
				{
					result = false;
				}
				else
				{
					this.Main.VC.MaintenanceDataBlock.MaintenanceData[i].NewEntry = 0;
					WSP1_VarComm.MaintenanceBufferStruct maintenanceBufferStruct = new WSP1_VarComm.MaintenanceBufferStruct();
					this.Main.VC.makeCopyMaintenanceBufferStruct(ref maintenanceBufferStruct, this.Main.VC.MaintenanceDataBlock.MaintenanceData[i]);
					this.MaintenanceDataList.Add(maintenanceBufferStruct);
					DateTime d;
					try
					{
						d = new DateTime(maintenanceBufferStruct.ScheduledTime.Year, maintenanceBufferStruct.ScheduledTime.Month, maintenanceBufferStruct.ScheduledTime.Day, maintenanceBufferStruct.ScheduledTime.Hour, maintenanceBufferStruct.ScheduledTime.Minute, maintenanceBufferStruct.ScheduledTime.Second);
					}
					catch
					{
						d = new DateTime(1, 1, 1, 0, 0, 0);
					}
					int days = (d - DateTime.Now).Days;
					int num = (int)(maintenanceBufferStruct.NextCycle - this.Main.VC.CycleCount.Machine);
					if (days <= 0 || num <= 0)
					{
						this.maintenanceElapsed++;
					}
					else if (days < 7 || num < 1000)
					{
						this.maintenanceAlmostElapsed++;
					}
				}
			}
			return result;
		}

		private void readDataFromWSP()
		{
			if (this.Main.IsOnlineMode)
			{
				this.MaintenanceDataList.Clear();
				Cursor.Current = Cursors.WaitCursor;
				this.Main.StatusBarText(this.Main.Rm.GetString("LoadMaintenanceData"));
				this.Main.VC.MaintenanceDataBlock.NextBlock = 0u;
				this.maintenanceElapsed = 0;
				this.maintenanceAlmostElapsed = 0;
				int num = 0;
				while (this.Main.VC.MaintenanceDataBlock.NextBlock != 255 && num < 10)
				{
					if (!((num != 0) ? this.Main.ReadFromController(72) : this.Main.ReadFromController(71)))
					{
						this.Main.StatusBarText(string.Empty);
						this.Main.VC.MaintenanceDataBlock.NextBlock = 255u;
					}
					else
					{
						if (!this.Main.VC.ReceiveVarBlock(70))
						{
							MessageBox.Show("Could not receive MAINTENANCE_FIRST_DATA!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						this.importDataFromVC();
						num++;
					}
				}
				Cursor.Current = Cursors.Default;
				this.Main.StatusBarText(string.Empty);
			}
		}

		private void writeDataToWSP()
		{
			int num = 0;
			uint num2 = 0u;
			this.Main.StatusBarText(this.Main.Rm.GetString("WriteMaintenanceData"));
			while (true)
			{
				if (num >= this.MaintenanceDataList.Count && num != 0)
				{
					break;
				}
				this.Main.VC.MaintenanceDataBlock.Initialize();
				this.Main.VC.MaintenanceDataBlock.BlockNum = num2;
				int i;
				for (i = 0; i < 32; i++)
				{
					if (num >= this.MaintenanceDataList.Count)
					{
						break;
					}
					this.Main.VC.makeCopyMaintenanceBufferStruct(ref this.Main.VC.MaintenanceDataBlock.MaintenanceData[i], this.MaintenanceDataList[num]);
					num++;
				}
				if (num >= this.MaintenanceDataList.Count && num % 32 != 0)
				{
					while (i % 32 != 0)
					{
						this.Main.VC.makeCopyMaintenanceBufferStruct(ref this.Main.VC.MaintenanceDataBlock.MaintenanceData[i], new WSP1_VarComm.MaintenanceBufferStruct());
						i++;
						num++;
					}
				}
				num2++;
				if (num < this.MaintenanceDataList.Count)
				{
					this.Main.VC.MaintenanceDataBlock.NextBlock = num2;
				}
				if (!this.Main.VC.SendVarBlock(70))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show("Could not send MAINTENANCEDATABLOCK!", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}
				Thread.Sleep(50);
				this.Main.StatusBarText(this.Main.Rm.GetString("SaveSystemConstOnCPU"));
				if (!this.Main.SaveOnController(70, false))
				{
					this.Main.StatusBarText(string.Empty);
					Cursor.Current = Cursors.Default;
					MessageBox.Show(this.Main.Rm.GetString("MbSaveSysConstFailure"), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					this.pnMenu.Enabled = true;
					this.pnMenu.Select();
					return;
				}
				if (num == 0)
				{
					num = 1;
				}
			}
			this.Main.StatusBarText(string.Empty);
		}

		private void btBack_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				this.pnMenu.Enabled = false;
				base.Hide();
			}
			else
			{
				this.writeDataToWSP();
				this.GetInfo(out bool _, out int num, out num, out num, true);
				this.Main.CheckMaintenanceLabel(false);
				this.pnMenu.Enabled = false;
				base.Hide();
			}
		}

		private void btCancel_Click(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = false;
			base.Hide();
		}

		private void btHome_Click(object sender, EventArgs e)
		{
			this.Main.HomeButtonClicked();
		}

		public void CancelMenu()
		{
			this.btCancel_Click(null, EventArgs.Empty);
		}

		public void ShowHelp()
		{
			if (!Settings.Default.IntegratedHelp)
			{
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (!this.Main.IsOfflineVersion)
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile + "#Kap5_2_4_Aenderungs_Liste";
				}
				else
				{
					processStartInfo.FileName = this.Main.LocalizedHelpFile;
				}
				try
				{
					Process.Start(processStartInfo);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				try
				{
					this.pnMenu.Enabled = false;
					this.Main.BrowserHelp.Navigate("#Kap5_2_4_Aenderungs_Liste");
					this.Main.BrowserHelp.ShowWindow();
				}
				catch (Exception ex2)
				{
					this.pnMenu.Enabled = true;
					MessageBox.Show(ex2.Message.ToString(), this.Main.Rm.GetString("MbhError"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		private void LogChangesForm_Activated(object sender, EventArgs e)
		{
			this.pnMenu.Enabled = true;
			this.btBack.Select();
		}

		private void btPrint_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnectionToController"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				this.prepareDocument();
				this.Main.SimplePrint.DocName = this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) + "_" + this.Main.Rm.GetString("MaintenanceList");
				this.Main.SimplePrint.Print();
			}
		}

		private void prepareDocument()
		{
			this.Main.SimplePrint.SetLeft();
			this.Main.SimplePrint.SetStyleBold();
			this.Main.SimplePrint.SetSizeXL();
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("MaintenanceList") + " (" + this.Main.CommonFunctions.UShortToString(this.Main.VC.SysConst.IdentServerName) + "):");
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.ResetStyle();
			this.Main.SimplePrint.SetSizeLarge();
			DateTime now = DateTime.Now;
			this.Main.SimplePrint.Sb.Append(this.Main.Rm.GetString("LocalTime") + ": " + now.ToString());
			this.Main.SimplePrint.SetNewLine();
			this.Main.SimplePrint.SetSizeLarge();
			for (int i = 0; i < this.dGMResults.Rows.Count; i++)
			{
				this.Main.SimplePrint.SetLeft();
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[0].Value.ToString() + ":");
				if (this.dGMResults.Rows[i].Cells[5].Style.BackColor == this.statusElapsedColor)
				{
					this.Main.SimplePrint.SetStyleBold();
					this.Main.SimplePrint.SetTab(1);
					this.Main.SimplePrint.Sb.Append("  (" + this.Main.Rm.GetString("MMaintenanceDateExeeded") + ")");
					this.Main.SimplePrint.SetNewLine();
					this.Main.SimplePrint.ResetStyle();
					this.Main.SimplePrint.SetSizeLarge();
				}
				else
				{
					this.Main.SimplePrint.SetNewLine();
				}
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[1].HeaderText);
				this.Main.SimplePrint.SetTab(5);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[1].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[2].HeaderText);
				this.Main.SimplePrint.SetTab(5);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[2].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[3].HeaderText);
				this.Main.SimplePrint.SetTab(5);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[3].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[4].HeaderText);
				this.Main.SimplePrint.SetTab(5);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[4].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[5].HeaderText);
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetTab(5);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[5].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetTab(1);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Columns[6].HeaderText);
				this.Main.SimplePrint.SetTab(5);
				this.Main.SimplePrint.Sb.Append(this.dGMResults.Rows[i].Cells[6].Value.ToString());
				this.Main.SimplePrint.SetNewLine();
				this.Main.SimplePrint.SetNewLine();
			}
		}

		private void printDocument_PrintPage(object sender, PrintPageEventArgs e)
		{
		}

		private void btNewEntry_Click(object sender, EventArgs e)
		{
			this.maintNewForm.MaxlenMaintenanceText = 100;
			this.maintNewForm.NewEntry = true;
			this.maintNewForm.CyclePlus = 10000u;
			this.maintNewForm.ShowDialog();
			if (this.maintNewForm.Result != 1)
			{
				if (!this.Main.IsOnlineMode)
				{
					MessageBox.Show(this.Main.Rm.GetString("MbNoConnectionToController"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					WSP1_VarComm.MaintenanceBufferStruct maintenanceBufferStruct = new WSP1_VarComm.MaintenanceBufferStruct();
					maintenanceBufferStruct.Index = (uint)(this.maintenanceListCount + 1);
					maintenanceBufferStruct.BlockNum = (byte)((int)maintenanceBufferStruct.Index / 32);
					string maintenanceText = this.maintNewForm.MaintenanceText;
					this.Main.CommonFunctions.StringToUShort(ref maintenanceBufferStruct.MaintenanceText, maintenanceText, maintenanceText.Length + 1);
					maintenanceBufferStruct.Reminder = this.maintNewForm.ExpiryLeadsTo;
					maintenanceBufferStruct.NextCycle = this.maintNewForm.CurrentCyclePlus;
					maintenanceBufferStruct.ScheduledTime.Year = (ushort)this.maintNewForm.ScheduledTime.Year;
					maintenanceBufferStruct.ScheduledTime.Month = (byte)this.maintNewForm.ScheduledTime.Month;
					maintenanceBufferStruct.ScheduledTime.Day = (byte)this.maintNewForm.ScheduledTime.Day;
					maintenanceBufferStruct.ScheduledTime.Hour = (byte)this.maintNewForm.ScheduledTime.Hour;
					maintenanceBufferStruct.ScheduledTime.Minute = (byte)this.maintNewForm.ScheduledTime.Minute;
					maintenanceBufferStruct.ScheduledTime.Second = (byte)this.maintNewForm.ScheduledTime.Second;
					maintenanceBufferStruct.Time.Year = (ushort)DateTime.Now.Year;
					maintenanceBufferStruct.Time.Month = (byte)DateTime.Now.Month;
					maintenanceBufferStruct.Time.Day = (byte)DateTime.Now.Day;
					maintenanceBufferStruct.Time.Hour = (byte)DateTime.Now.Hour;
					maintenanceBufferStruct.Time.Minute = (byte)DateTime.Now.Minute;
					maintenanceBufferStruct.Time.Second = (byte)DateTime.Now.Second;
					maintenanceBufferStruct.NewEntry = 1;
					this.Main.CommonFunctions.StringToUShort(ref maintenanceBufferStruct.userName, this.Main.ActualUser, this.Main.ActualUser.Length + 1);
					this.MaintenanceDataList.Add(maintenanceBufferStruct);
					this.updateMenu();
				}
			}
		}

		private void btDelete_Click(object sender, EventArgs e)
		{
			if (!this.Main.IsOnlineMode)
			{
				MessageBox.Show(this.Main.Rm.GetString("MbNoConnectionToController"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				int num = int.Parse(this.dGMResults.SelectedRows[0].Cells[0].Value.ToString());
				this.MaintenanceDataList.RemoveAt(num - 1);
				for (int i = num - 1; i < this.MaintenanceDataList.Count; i++)
				{
					this.MaintenanceDataList[i].Index = (uint)(i + 1);
				}
				this.updateMenu();
			}
		}

		private void btEdit_Click(object sender, EventArgs e)
		{
			this.editCurrentEntry();
		}

		private void editCurrentEntry()
		{
			if (this.dGMResults.SelectedRows.Count != 0)
			{
				if (!this.Main.IsOnlineMode)
				{
					MessageBox.Show(this.Main.Rm.GetString("MbNoConnectionToController"), this.Main.Rm.GetString("MbhHint"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					int num = int.Parse(this.dGMResults.SelectedRows[0].Cells[0].Value.ToString());
					this.maintNewForm.NewEntry = false;
					try
					{
						WSP1_VarComm.DateTimeStruct scheduledTime = this.MaintenanceDataList[num - 1].ScheduledTime;
						this.maintNewForm.ScheduledTime = new DateTime(scheduledTime.Year, scheduledTime.Month, scheduledTime.Day);
						this.maintNewForm.MaintenanceText = this.Main.CommonFunctions.UShortToString(this.MaintenanceDataList[num - 1].MaintenanceText);
						this.maintNewForm.CyclePlus = this.MaintenanceDataList[num - 1].NextCycle - this.Main.VC.CycleCount.Machine;
					}
					catch (Exception)
					{
					}
					this.maintNewForm.ExpiryLeadsTo = this.MaintenanceDataList[num - 1].Reminder;
					this.maintNewForm.MaxlenMaintenanceText = 100;
					this.maintNewForm.ShowDialog();
					if (this.maintNewForm.Result != 1)
					{
						this.Main.SettingsChanged();
						WSP1_VarComm.MaintenanceBufferStruct maintenanceBufferStruct = new WSP1_VarComm.MaintenanceBufferStruct();
						maintenanceBufferStruct.Index = (uint)num;
						maintenanceBufferStruct.BlockNum = (byte)((int)maintenanceBufferStruct.Index / 32);
						string maintenanceText = this.maintNewForm.MaintenanceText;
						this.Main.CommonFunctions.StringToUShort(ref maintenanceBufferStruct.MaintenanceText, maintenanceText, maintenanceText.Length + 1);
						maintenanceBufferStruct.Reminder = this.maintNewForm.ExpiryLeadsTo;
						maintenanceBufferStruct.NextCycle = this.maintNewForm.CurrentCyclePlus;
						maintenanceBufferStruct.ScheduledTime.Year = (ushort)this.maintNewForm.ScheduledTime.Year;
						maintenanceBufferStruct.ScheduledTime.Month = (byte)this.maintNewForm.ScheduledTime.Month;
						maintenanceBufferStruct.ScheduledTime.Day = (byte)this.maintNewForm.ScheduledTime.Day;
						maintenanceBufferStruct.ScheduledTime.Hour = (byte)this.maintNewForm.ScheduledTime.Hour;
						maintenanceBufferStruct.ScheduledTime.Minute = (byte)this.maintNewForm.ScheduledTime.Minute;
						maintenanceBufferStruct.ScheduledTime.Second = (byte)this.maintNewForm.ScheduledTime.Second;
						maintenanceBufferStruct.Time.Year = (ushort)DateTime.Now.Year;
						maintenanceBufferStruct.Time.Month = (byte)DateTime.Now.Month;
						maintenanceBufferStruct.Time.Day = (byte)DateTime.Now.Day;
						maintenanceBufferStruct.Time.Hour = (byte)DateTime.Now.Hour;
						maintenanceBufferStruct.Time.Minute = (byte)DateTime.Now.Minute;
						maintenanceBufferStruct.Time.Second = (byte)DateTime.Now.Second;
						maintenanceBufferStruct.NewEntry = 1;
						this.Main.CommonFunctions.StringToUShort(ref maintenanceBufferStruct.userName, this.Main.ActualUser, this.Main.ActualUser.Length + 1);
						this.MaintenanceDataList.RemoveAt(num - 1);
						this.MaintenanceDataList.Insert(num - 1, maintenanceBufferStruct);
						this.updateMenu();
					}
				}
			}
		}

		public void BrowserShow()
		{
			this.pnMenu.Enabled = false;
			base.Activate();
			this.Main.Browser1.ShowWindow(this);
		}

		public void KeyArrived()
		{
			this.MenEna();
		}

		public void KeyRemoved()
		{
			this.btHome_Click(null, EventArgs.Empty);
		}

		private void dGMResults_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_Maintenance)
			{
				this.editCurrentEntry();
			}
		}

		private void dGMResults_SelectionChanged(object sender, EventArgs e)
		{
			this.paintedOnce = false;
			if (this.Main.PassCodeLevel >= Settings.Default.UserLevel_Maintenance)
			{
				if (this.dGMResults.SelectedRows.Count == 0)
				{
					this.btDelete.Enabled = false;
					this.btEdit.Enabled = false;
				}
				else
				{
					this.btDelete.Enabled = true;
					this.btEdit.Enabled = true;
				}
			}
		}

		private void dGMResults_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
		{
			if (this.dGMResults.Rows.Count != 0 && this.dGMResults.Rows[e.RowIndex].Selected && !this.paintedOnce)
			{
				this.paintedOnce = true;
				using (Pen pen = new Pen(Color.Red))
				{
					int num = 2;
					pen.Width = (float)num;
					int num2 = e.RowBounds.Left + num / 2;
					int num3 = e.RowBounds.Top + num / 2;
					int num4 = e.RowBounds.Width - num;
					int num5 = e.RowBounds.Height - num;
					new SolidBrush(Color.White);
					e.Graphics.DrawLine(pen, num2, num3, num2 + num4, num3);
					e.Graphics.DrawLine(pen, num2, num3 + num5 - 1, num2 + num4, num3 + num5 - 1);
					pen.Dispose();
				}
			}
		}

		private void dGMResults_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
		{
		}

		private void dGMResults_Paint(object sender, PaintEventArgs e)
		{
		}

		private void dGMResults_Sorted(object sender, EventArgs e)
		{
		}

		private void dGMResults_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
		{
			if (this.dGMResults.Rows.Count > 0)
			{
				this.dGMResults.Rows[0].Selected = false;
			}
		}

		private void dGMResults_Scroll(object sender, ScrollEventArgs e)
		{
		}

		private void dGMResults_Click(object sender, EventArgs e)
		{
		}

		private void dGMResults_MouseDown(object sender, MouseEventArgs e)
		{
			if (this.dGMResults.SelectedRows.Count > 0)
			{
				this.dGMResults.Rows[this.dGMResults.SelectedRows[0].Index].Selected = false;
				Application.DoEvents();
			}
		}
	}
}
