using System;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;

namespace Program.getHardwareId
{
	public class HardwareHelperClass
	{
		public const int _MAX_CODE_CARACTERS = 9;

		public const int _VERSION_CARACTERS = 2;

		private const int _MAXCODE_NUMBER = 999999999;

		private const int _X_OF_FUNCTION_CODE = -1;

		private const int _Y_OF_FUNCTION_CODE = -2;

		private const int _S_OF_FUNCTION_CODE = -3;

		private const int _W_OF_FUNCTION_CODE = -4;

		public const int _MAX_NUMBER_OF_FEATURES = 6;

		private const int _MAX_CHARACTERS_PROCESSED = 6;

		private readonly char[] privateKeyCharacters = new char[9]
		{
			'2',
			'7',
			'3',
			'9',
			'1',
			'5',
			'2',
			'8',
			'4'
		};

		private readonly int[] primeNumberList = new int[9]
		{
			1,
			2,
			11,
			109,
			1009,
			8396,
			88007,
			1000003,
			8990011
		};

		private readonly int[] deviceCodeProcessingOrder = new int[9]
		{
			3,
			6,
			1,
			7,
			4,
			8,
			5,
			0,
			2
		};

		private readonly int[] privateCodeProcessingOrder = new int[9]
		{
			0,
			1,
			-1,
			-3,
			-4,
			-2,
			5,
			7,
			8
		};

		public string CalculateRegistrationCode(string devicePublicKeyString, string functionCodeString, string swVersionString)
		{
			if (swVersionString.Length <= 2 && int.TryParse(swVersionString, NumberStyles.HexNumber, (IFormatProvider)NumberFormatInfo.InvariantInfo, out int num))
			{
				if (devicePublicKeyString.Length != 9)
				{
					return "Public key length != " + 9;
				}
				if (devicePublicKeyString[0] == '0')
				{
					return "Public key first character not '0'";
				}
				if (!int.TryParse(devicePublicKeyString, NumberStyles.Any, (IFormatProvider)NumberFormatInfo.InvariantInfo, out num))
				{
					return "Public key contains other character(s) than digits";
				}
				int value = Convert.ToInt32(functionCodeString, 2);
				string text = "";
				string text2 = Convert.ToString(value, 8);
				switch (text2.Length)
				{
				case 0:
					text2 = "00";
					break;
				case 1:
					text = "0" + text2;
					text2 = text;
					break;
				default:
					text2 = "00";
					break;
				case 2:
					break;
				}
				char[] array = text2.ToCharArray();
				text2 = "";
				char[] array2 = array;
				foreach (char value2 in array2)
				{
					int num2 = Convert.ToInt32(Convert.ToString(value2));
					text2 += Convert.ToString(num2 + 1);
				}
				char[] array3 = devicePublicKeyString.ToCharArray();
				char[] array4 = text2.ToCharArray();
				char[] array5 = swVersionString.ToCharArray();
				int num3 = 0;
				for (int j = 0; j < 6; j++)
				{
					int num4;
					switch (this.privateCodeProcessingOrder[j])
					{
					case -1:
					{
						string s = array3[this.deviceCodeProcessingOrder[j]].ToString() + array4[0];
						num4 = int.Parse(s);
						break;
					}
					case -2:
					{
						string s = array3[this.deviceCodeProcessingOrder[j]].ToString() + array4[1];
						num4 = int.Parse(s);
						break;
					}
					case -3:
					{
						string s = array3[this.deviceCodeProcessingOrder[j]].ToString() + array5[0];
						num4 = int.Parse(s, NumberStyles.HexNumber);
						break;
					}
					case -4:
					{
						string s = array3[this.deviceCodeProcessingOrder[j]].ToString() + array5[1];
						num4 = int.Parse(s, NumberStyles.HexNumber);
						break;
					}
					default:
					{
						string s = array3[this.deviceCodeProcessingOrder[j]].ToString() + this.privateKeyCharacters[this.privateCodeProcessingOrder[j]].ToString();
						num4 = int.Parse(s);
						break;
					}
					}
					num3 += num4 * this.primeNumberList[j];
				}
				return $"{num3:d}";
			}
			return "SW Version must not exceed 2 characters (hexadecimal)";
		}

		public string GetVolumeSerialID(string driveName)
		{
			if (driveName.Length == 0)
			{
				return "";
			}
			if (driveName.Length > 1)
			{
				driveName = driveName.Remove(1);
			}
			int num = HardwareHelperClass.getVolumeSerial(driveName);
			if (num > 999999999)
			{
				num &= 0x3B9AC9FF;
			}
			if (num < 100000000)
			{
				num += 100000000;
			}
			return string.Concat(num);
		}

		public string GetSystemVolumeSerialID()
		{
			string drive = Environment.SystemDirectory.Substring(0, 1);
			int num = HardwareHelperClass.getVolumeSerial(drive);
			if (num > 999999999)
			{
				num &= 0x3B9AC9FF;
			}
			if (num < 100000000)
			{
				num += 100000000;
			}
			return string.Concat(num);
		}

		public static string intToBin(int number, int numBits)
		{
			char[] array = new char[numBits];
			int num = numBits - 1;
			for (int i = 0; i < numBits; i++)
			{
				if ((number & 1 << i) != 0)
				{
					array[num] = '1';
				}
				else
				{
					array[num] = '0';
				}
				num--;
			}
			return new string(array);
		}

		private static int getVolumeSerial(string drive)
		{
			StringBuilder stringBuilder = new StringBuilder(300);
			StringBuilder stringBuilder2 = new StringBuilder(300);
			HardwareHelperClass.GetVolumeInformation($"{drive}:\\", stringBuilder, stringBuilder.Capacity, out int value, out uint _, out uint _, stringBuilder2, stringBuilder2.Capacity);
			return Math.Abs(value);
		}

		private static ulong getDiskSize()
		{
			HardwareHelperClass.GetDiskFreeSpaceEx($"{Environment.SystemDirectory.Substring(0, 1)}:\\", out ulong _, out ulong result, out ulong _);
			return result;
		}

		[DllImport("kernel32.dll")]
		private static extern bool GetDiskFreeSpaceEx(string lpDirectoryName, out ulong lpFreeBytesAvailable, out ulong lpTotalNumberOfBytes, out ulong lpTotalNumberOfFreeBytes);

		[DllImport("Kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool GetVolumeInformation(string rootPathName, StringBuilder volumeNameBuffer, int volumeNameSize, out int volumeSerialNumber, out uint maximumComponentLength, out uint fileSystemFlags, StringBuilder fileSystemNameBuffer, int nFileSystemNameSize);
	}
}
