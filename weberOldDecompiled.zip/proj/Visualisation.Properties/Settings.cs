using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Visualisation.Properties
{
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "10.0.0.0")]
	[CompilerGenerated]
	internal sealed class Settings : ApplicationSettingsBase
	{
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

		public static Settings Default => Settings.defaultInstance;

		[DefaultSettingValue("1")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public int Language
		{
			get
			{
				return (int)((SettingsBase)this)["Language"];
			}
			set
			{
				((SettingsBase)this)["Language"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("dd'.'MM'.'yyyy HH':'mm':'ss")]
		public string TimeSet
		{
			get
			{
				return (string)((SettingsBase)this)["TimeSet"];
			}
			set
			{
				((SettingsBase)this)["TimeSet"] = value;
			}
		}

		[DefaultSettingValue("True")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public bool SoftKeyBoardIsUsed
		{
			get
			{
				return (bool)((SettingsBase)this)["SoftKeyBoardIsUsed"];
			}
			set
			{
				((SettingsBase)this)["SoftKeyBoardIsUsed"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("100")]
		[DebuggerNonUserCode]
		public float MaxSavCurveNum
		{
			get
			{
				return (float)((SettingsBase)this)["MaxSavCurveNum"];
			}
			set
			{
				((SettingsBase)this)["MaxSavCurveNum"] = value;
			}
		}

		[DefaultSettingValue("0")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public int SelectedXaxis
		{
			get
			{
				return (int)((SettingsBase)this)["SelectedXaxis"];
			}
			set
			{
				((SettingsBase)this)["SelectedXaxis"] = value;
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		[UserScopedSetting]
		public bool Time
		{
			get
			{
				return (bool)((SettingsBase)this)["Time"];
			}
			set
			{
				((SettingsBase)this)["Time"] = value;
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		[UserScopedSetting]
		public bool SetRpm
		{
			get
			{
				return (bool)((SettingsBase)this)["SetRpm"];
			}
			set
			{
				((SettingsBase)this)["SetRpm"] = value;
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		[UserScopedSetting]
		public bool GetRpm
		{
			get
			{
				return (bool)((SettingsBase)this)["GetRpm"];
			}
			set
			{
				((SettingsBase)this)["GetRpm"] = value;
			}
		}

		[DefaultSettingValue("True")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public bool Torque
		{
			get
			{
				return (bool)((SettingsBase)this)["Torque"];
			}
			set
			{
				((SettingsBase)this)["Torque"] = value;
			}
		}

		[DefaultSettingValue("False")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public bool FilteredTorque
		{
			get
			{
				return (bool)((SettingsBase)this)["FilteredTorque"];
			}
			set
			{
				((SettingsBase)this)["FilteredTorque"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("False")]
		[DebuggerNonUserCode]
		public bool TorqueGradient
		{
			get
			{
				return (bool)((SettingsBase)this)["TorqueGradient"];
			}
			set
			{
				((SettingsBase)this)["TorqueGradient"] = value;
			}
		}

		[DefaultSettingValue("False")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public bool Angle
		{
			get
			{
				return (bool)((SettingsBase)this)["Angle"];
			}
			set
			{
				((SettingsBase)this)["Angle"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("False")]
		[DebuggerNonUserCode]
		public bool AnalogDepth
		{
			get
			{
				return (bool)((SettingsBase)this)["AnalogDepth"];
			}
			set
			{
				((SettingsBase)this)["AnalogDepth"] = value;
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		[UserScopedSetting]
		public bool DigitalDepth
		{
			get
			{
				return (bool)((SettingsBase)this)["DigitalDepth"];
			}
			set
			{
				((SettingsBase)this)["DigitalDepth"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		public bool DepthGradient
		{
			get
			{
				return (bool)((SettingsBase)this)["DepthGradient"];
			}
			set
			{
				((SettingsBase)this)["DepthGradient"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("False")]
		[DebuggerNonUserCode]
		public bool AnalogSignal
		{
			get
			{
				return (bool)((SettingsBase)this)["AnalogSignal"];
			}
			set
			{
				((SettingsBase)this)["AnalogSignal"] = value;
			}
		}

		[DefaultSettingValue("True")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public bool IntegratedMachineVisu
		{
			get
			{
				return (bool)((SettingsBase)this)["IntegratedMachineVisu"];
			}
			set
			{
				((SettingsBase)this)["IntegratedMachineVisu"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("True")]
		[DebuggerNonUserCode]
		public bool IntegratedHelp
		{
			get
			{
				return (bool)((SettingsBase)this)["IntegratedHelp"];
			}
			set
			{
				((SettingsBase)this)["IntegratedHelp"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("False")]
		[DebuggerNonUserCode]
		public bool FileOperationDefaultUse
		{
			get
			{
				return (bool)((SettingsBase)this)["FileOperationDefaultUse"];
			}
			set
			{
				((SettingsBase)this)["FileOperationDefaultUse"] = value;
			}
		}

		[DefaultSettingValue("False")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public bool ProgFileOperationDefaultUse
		{
			get
			{
				return (bool)((SettingsBase)this)["ProgFileOperationDefaultUse"];
			}
			set
			{
				((SettingsBase)this)["ProgFileOperationDefaultUse"] = value;
			}
		}

		[DefaultSettingValue("")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public string FileOperationDefaultDirectory
		{
			get
			{
				return (string)((SettingsBase)this)["FileOperationDefaultDirectory"];
			}
			set
			{
				((SettingsBase)this)["FileOperationDefaultDirectory"] = value;
			}
		}

		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("")]
		public string ProgFileOperationDefaultDirectory
		{
			get
			{
				return (string)((SettingsBase)this)["ProgFileOperationDefaultDirectory"];
			}
			set
			{
				((SettingsBase)this)["ProgFileOperationDefaultDirectory"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("3")]
		[DebuggerNonUserCode]
		public int UserLevel_BackupForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_BackupForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_BackupForm"] = value;
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("2")]
		[UserScopedSetting]
		public int UserLevel_CheckParamForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_CheckParamForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_CheckParamForm"] = value;
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("3")]
		[UserScopedSetting]
		public int UserLevel_CycleCounterForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_CycleCounterForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_CycleCounterForm"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("2")]
		[DebuggerNonUserCode]
		public int UserLevel_EditSteps
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_EditSteps"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_EditSteps"] = value;
			}
		}

		[DefaultSettingValue("3")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public int UserLevel_PrgOptParameterForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_PrgOptParameterForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_PrgOptParameterForm"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("2")]
		[DebuggerNonUserCode]
		public int UserLevel_ProgramOverviewForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_ProgramOverviewForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_ProgramOverviewForm"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("3")]
		[DebuggerNonUserCode]
		public int UserLevel_SpindleConstantsForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_SpindleConstantsForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_SpindleConstantsForm"] = value;
			}
		}

		[DefaultSettingValue("1")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public int UserLevel_StatisticsLastResForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_StatisticsLastResForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_StatisticsLastResForm"] = value;
			}
		}

		[DefaultSettingValue("2")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public int UserLevel_StepOverviewForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_StepOverviewForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_StepOverviewForm"] = value;
			}
		}

		[DefaultSettingValue("3")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public int UserLevel_SystemConstantsForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_SystemConstantsForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_SystemConstantsForm"] = value;
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("4")]
		[UserScopedSetting]
		public int UserLevel_TestIOForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_TestIOForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_TestIOForm"] = value;
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("2")]
		[UserScopedSetting]
		public int UserLevel_TestMotorSensorForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_TestMotorSensorForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_TestMotorSensorForm"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("3")]
		public int UserLevel_VisualisationParamForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_VisualisationParamForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_VisualisationParamForm"] = value;
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		[UserScopedSetting]
		public string UserLevelDirectory
		{
			get
			{
				return (string)((SettingsBase)this)["UserLevelDirectory"];
			}
			set
			{
				((SettingsBase)this)["UserLevelDirectory"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("")]
		[DebuggerNonUserCode]
		public string FileBackupOperationDefaultDirectory
		{
			get
			{
				return (string)((SettingsBase)this)["FileBackupOperationDefaultDirectory"];
			}
			set
			{
				((SettingsBase)this)["FileBackupOperationDefaultDirectory"] = value;
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		[UserScopedSetting]
		public bool FileBackupOperationDefaultUse
		{
			get
			{
				return (bool)((SettingsBase)this)["FileBackupOperationDefaultUse"];
			}
			set
			{
				((SettingsBase)this)["FileBackupOperationDefaultUse"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("True")]
		[DebuggerNonUserCode]
		public bool DisplayStepsInCurves
		{
			get
			{
				return (bool)((SettingsBase)this)["DisplayStepsInCurves"];
			}
			set
			{
				((SettingsBase)this)["DisplayStepsInCurves"] = value;
			}
		}

		[DefaultSettingValue("False")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public bool FourStepConcept
		{
			get
			{
				return (bool)((SettingsBase)this)["FourStepConcept"];
			}
			set
			{
				((SettingsBase)this)["FourStepConcept"] = value;
			}
		}

		[DefaultSettingValue("3")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public int UserLevel_FourStepEditForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_FourStepEditForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_FourStepEditForm"] = value;
			}
		}

		[DefaultSettingValue("")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public string User4StepDirectory
		{
			get
			{
				return (string)((SettingsBase)this)["User4StepDirectory"];
			}
			set
			{
				((SettingsBase)this)["User4StepDirectory"] = value;
			}
		}

		[DefaultSettingValue("3")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public int UserLevel_Maintenance
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_Maintenance"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_Maintenance"] = value;
			}
		}

		[DefaultSettingValue("3")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public int UserLevel_HandStartForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_HandStartForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_HandStartForm"] = value;
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("1")]
		[UserScopedSetting]
		public int UserLevel_BrowserForm
		{
			get
			{
				return (int)((SettingsBase)this)["UserLevel_BrowserForm"];
			}
			set
			{
				((SettingsBase)this)["UserLevel_BrowserForm"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		public bool JawOpeningViaDigitalOutSync1
		{
			get
			{
				return (bool)((SettingsBase)this)["JawOpeningViaDigitalOutSync1"];
			}
			set
			{
				((SettingsBase)this)["JawOpeningViaDigitalOutSync1"] = value;
			}
		}

		[DefaultSettingValue("")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public string CurveFileOperationDefaultDirectory
		{
			get
			{
				return (string)((SettingsBase)this)["CurveFileOperationDefaultDirectory"];
			}
			set
			{
				((SettingsBase)this)["CurveFileOperationDefaultDirectory"] = value;
			}
		}

		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("")]
		public string _CurveFileOperationDefaultDirectory
		{
			get
			{
				return (string)((SettingsBase)this)["_CurveFileOperationDefaultDirectory"];
			}
			set
			{
				((SettingsBase)this)["_CurveFileOperationDefaultDirectory"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string _CurveAutoExportDefaultDirectory
		{
			get
			{
				return (string)((SettingsBase)this)["_CurveAutoExportDefaultDirectory"];
			}
			set
			{
				((SettingsBase)this)["_CurveAutoExportDefaultDirectory"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("50")]
		public float CurrentSaveCurveNum
		{
			get
			{
				return (float)((SettingsBase)this)["CurrentSaveCurveNum"];
			}
			set
			{
				((SettingsBase)this)["CurrentSaveCurveNum"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		public bool Curve_StoringToFIFO_active
		{
			get
			{
				return (bool)((SettingsBase)this)["Curve_StoringToFIFO_active"];
			}
			set
			{
				((SettingsBase)this)["Curve_StoringToFIFO_active"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("100")]
		[DebuggerNonUserCode]
		public int Curve_StoringFIFO_maxCount
		{
			get
			{
				return (int)((SettingsBase)this)["Curve_StoringFIFO_maxCount"];
			}
			set
			{
				((SettingsBase)this)["Curve_StoringFIFO_maxCount"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string Curve_StoringFIFO_Directory
		{
			get
			{
				return (string)((SettingsBase)this)["Curve_StoringFIFO_Directory"];
			}
			set
			{
				((SettingsBase)this)["Curve_StoringFIFO_Directory"] = value;
			}
		}

		[DefaultSettingValue("0")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public int CurvePrintType
		{
			get
			{
				return (int)((SettingsBase)this)["CurvePrintType"];
			}
			set
			{
				((SettingsBase)this)["CurvePrintType"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("100")]
		[DebuggerNonUserCode]
		public int Curve_StoringFIFO_SettingMaxCount
		{
			get
			{
				return (int)((SettingsBase)this)["Curve_StoringFIFO_SettingMaxCount"];
			}
			set
			{
				((SettingsBase)this)["Curve_StoringFIFO_SettingMaxCount"] = value;
			}
		}
	}
}
