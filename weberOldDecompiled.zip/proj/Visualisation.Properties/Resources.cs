using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Visualisation.Properties
{
	[CompilerGenerated]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	[DebuggerNonUserCode]
	internal class Resources
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(Resources.resourceMan, null))
				{
					ResourceManager resourceManager = Resources.resourceMan = new ResourceManager("Visualisation.Properties.Resources", typeof(Resources).Assembly);
				}
				return Resources.resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		internal static Bitmap ExitButtonDe
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("ExitButtonDe", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap ExitButtonEn
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("ExitButtonEn", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Fasten_
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("Fasten_", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Find
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("Find", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Flow
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("Flow", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Home1
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("Home1", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Screw_
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("Screw_", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Weber_Logo_Large
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("Weber_Logo_Large", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Weber_Logo_WSP1_Active
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("Weber_Logo_WSP1_Active", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Weber_Logo_WSP1_Active1
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("Weber_Logo_WSP1_Active1", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Weber_Logo_WSP1_Active2
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("Weber_Logo_WSP1_Active2", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal Resources()
		{
		}
	}
}
