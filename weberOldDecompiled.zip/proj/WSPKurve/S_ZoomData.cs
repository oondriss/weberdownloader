namespace WSPKurve
{
	public struct S_ZoomData
	{
		public float cursor1pos;

		public float cursor2pos;

		public bool isLeftCursor;

		public int pointNumber;
	}
}
