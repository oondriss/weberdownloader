using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.Timers;
using System.Windows.Forms;
using Visualisation;

namespace WSPKurve
{
	public class C_Curve
	{
		private const int LEFTMARGIN = 60;

		private const int RIGHTMARGIN = 20;

		private const int DISTBETWEENCURVES = 15;

		private const int XLABELNUMMAX = 16;

		private const int YLABELNUMMAX = 32;

		private const int MAINCURVE = 0;

		private const int PRINTMARGIN = 50;

		private const int REPAINT_TIMER_CLOCK = 600;

		private int BottomMargin;

		private Panel Sender;

		private float[,,] Curves;

		private int[] XPointsToShow;

		private uint CurvesLen;

		private float LeftPoint;

		private float RightPoint;

		private int VectorNumXaxis;

		private bool[] DisplayedYaxis;

		private S_CurveData CurvData;

		private S_ZoomData ZoomData;

		private int CurveNum;

		private PrintPageEventArgs E_Print;

		private PrintDocument printDocument;

		private PrintDialog printDialog;

		private SaveFileDialog SFD;

		private int Output_Width;

		private int Output_Height;

		private int Margin;

		private string HeaderForPrintOut;

		private System.Timers.Timer RepaintTimer;

		private System.Timers.Timer TemporaryNoRepaintTimer;

		private bool RepaintIsBlocked;

		private bool displayStepsInCurves;

		private bool stepInfoIncluded = true;

		private MainForm Main;

		public uint Count => this.CurvesLen;

		public bool DisplayStepsInCurves
		{
			set
			{
				this.displayStepsInCurves = value;
			}
		}

		public bool StepInfoIncluded
		{
			set
			{
				this.stepInfoIncluded = value;
			}
		}

		public C_Curve(MainForm main, Panel sender, float[,,] curves)
		{
			this.Main = main;
			this.Sender = sender;
			this.Curves = curves;
			this.XPointsToShow = new int[this.Curves.GetLength(1)];
			this.DisplayedYaxis = new bool[this.Curves.GetLength(0)];
			this.VectorNumXaxis = 0;
			this.CurvData.initializeCurve = true;
			this.CurveNum = 1;
			this.ZoomData.isLeftCursor = true;
			this.BottomMargin = (int)(Math.Ceiling((double)(Control.DefaultFont.GetHeight() + 3f) / 2.0) * 2.0);
			this.printDocument = new PrintDocument();
			this.printDialog = new PrintDialog();
			this.printDialog.Document = this.printDocument;
			this.printDocument.PrintPage += this.printDocument_PrintPage;
			this.printDocument.DocumentName = this.Main.Rm.GetString("CurveDisplay");
			this.SFD = new SaveFileDialog();
			this.SFD.Filter = this.printDocument.DocumentName + "|*.txt|" + this.Main.Rm.GetString("AllFiles") + "|*.*";
			this.HeaderForPrintOut = string.Empty;
			this.RepaintTimer = new System.Timers.Timer(600.0);
			this.RepaintTimer.Elapsed += this.RepaintTimer_Tick;
			this.TemporaryNoRepaintTimer = new System.Timers.Timer(200.0);
			this.TemporaryNoRepaintTimer.Elapsed += this.TemporaryNoRepaintTimer_Tick;
			this.RepaintIsBlocked = false;
		}

		public void SetMultipleCurveMode(int curveNumber)
		{
			switch (curveNumber)
			{
			default:
				this.CurveNum = curveNumber;
				break;
			}
			return;
			IL_0010:
			this.CurveNum = 1;
		}

		private string GetCurveName(int index)
		{
			try
			{
				return this.CurvData.curveName[index] + "[" + this.CurvData.curveUnit[index] + "]";
			}
			catch
			{
				return "No data";
			}
		}

		public void SetCurveNameAndUnit(string[] name, string[] unit)
		{
			this.CurvData.curveName = name;
			this.CurvData.curveUnit = unit;
		}

		public void SetHeaderForPrintOut(string header)
		{
			this.HeaderForPrintOut = header;
		}

		public void SetVectorNumXaxis(int xaxisNum)
		{
			if (xaxisNum >= 0 && xaxisNum < this.Curves.GetLength(0))
			{
				this.VectorNumXaxis = xaxisNum;
			}
			else
			{
				MessageBox.Show("Value for curve number of x axis is out of allowed range. Default value is set.", "Internal Error in C_Curve/SetVectorNumXaxis", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				this.VectorNumXaxis = 0;
			}
		}

		public void SetDisplayedYaxis(int index)
		{
			if (index >= 0 && index < this.Curves.GetLength(0))
			{
				this.DisplayedYaxis[index] = true;
			}
			else
			{
				MessageBox.Show("Value for curve number of y axis is out of allowed range.", "Internal Error in C_Curve/SetDisplayedYaxis", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		public void ResetDisplayedYaxis(int index)
		{
			if (index >= 0 && index < this.Curves.GetLength(0))
			{
				this.DisplayedYaxis[index] = false;
			}
			else
			{
				MessageBox.Show("Value for curve number of y axis is out of allowed range.", "Internal Error in C_Curve/ResetDisplayedYaxis", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		public void ResetAllDisplayedYaxis()
		{
			for (int i = 0; i < this.Curves.GetLength(0); i++)
			{
				this.DisplayedYaxis[i] = false;
			}
		}

		public void SetAllDisplayedYaxis()
		{
			for (int i = 0; i < this.Curves.GetLength(0); i++)
			{
				this.DisplayedYaxis[i] = true;
			}
			this.DisplayedYaxis[this.VectorNumXaxis] = false;
		}

		public void Repaint(bool printOnPaper, bool isSystemCall, bool showError)
		{
			if (!this.RepaintIsBlocked)
			{
				int num = 0;
				int num2 = 0;
				int num3 = -1;
				int num4 = 0;
				Font font = new Font(Control.DefaultFont.FontFamily, Control.DefaultFont.SizeInPoints);
				StringFormat stringFormat = new StringFormat();
				string empty = string.Empty;
				Graphics graphics = (!printOnPaper) ? this.Sender.CreateGraphics() : this.E_Print.Graphics;
				graphics.Clear(Color.White);
				if (printOnPaper)
				{
					this.Margin = 50;
					this.Output_Width = this.E_Print.PageBounds.Width - 2 * this.Margin;
					this.Output_Height = this.E_Print.PageBounds.Height - 2 * this.Margin;
					stringFormat.Alignment = StringAlignment.Far;
					graphics.DrawString(this.HeaderForPrintOut, font, Brushes.Black, new RectangleF((float)this.Margin, (float)this.Margin, (float)(this.E_Print.PageBounds.Width - 2 * this.Margin), font.GetHeight()), stringFormat);
				}
				else
				{
					this.Margin = 0;
					this.Output_Width = this.Sender.ClientSize.Width;
					this.Output_Height = this.Sender.ClientSize.Height;
				}
				int num5 = this.Output_Height - this.BottomMargin;
				if (this.CurvData.initializeCurve)
				{
					this.MakeXMinAndXMax();
				}
				if (showError)
				{
					graphics.DrawString(this.Main.Rm.GetString("MbCurveLoadFailure"), font, Brushes.Red, new RectangleF(20f, 20f, graphics.MeasureString(this.Main.Rm.GetString("MbCurveLoadFailure"), font).Width, font.GetHeight()), stringFormat);
					font.Dispose();
					graphics.Dispose();
				}
				else if (!this.XCurvePrepare(printOnPaper))
				{
					graphics.DrawString(this.Main.Rm.GetString("MbCurveEmpty"), font, Brushes.Red, new RectangleF(20f, 20f, graphics.MeasureString(this.Main.Rm.GetString("MbCurveEmpty"), font).Width, font.GetHeight()), stringFormat);
					font.Dispose();
					graphics.Dispose();
				}
				else
				{
					Pen pen = new Pen(Color.Gray, 1f);
					pen.DashStyle = DashStyle.Dash;
					Pen pen2 = new Pen(Color.LightGray, 1f);
					pen2.DashStyle = DashStyle.Dot;
					Pen pen3 = new Pen(Color.Green, 1f);
					pen3.DashStyle = DashStyle.DashDot;
					pen3.Width = 1f;
					for (int i = 0; i < this.DisplayedYaxis.Length; i++)
					{
						if (this.DisplayedYaxis[i])
						{
							num++;
						}
					}
					this.CurvData.yCurveNum = num;
					if (num == 0)
					{
						string text = this.Main.Rm.GetString("CurveSelection") + " = " + this.Main.Rm.GetString("None");
						graphics.DrawString(text, font, Brushes.Red, new RectangleF(20f, 20f, graphics.MeasureString(text, font).Width, font.GetHeight()), stringFormat);
						font.Dispose();
						graphics.Dispose();
					}
					else
					{
						for (int i = 0; (float)i < this.CurvData.xScaleNumber; i++)
						{
							if ((float)(this.Margin + 60) + this.CurvData.xMinScaleRange + (float)i * this.CurvData.xScaleRange < (float)(this.Output_Width + this.Margin - 20))
							{
								graphics.DrawLine(pen, (float)(this.Margin + 60) + this.CurvData.xMinScaleRange + (float)i * this.CurvData.xScaleRange, (float)(num5 + this.Margin), (float)(this.Margin + 60) + this.CurvData.xMinScaleRange + (float)i * this.CurvData.xScaleRange, (float)(15 + this.Margin));
							}
						}
						int num6 = -1;
						bool flag = false;
						Font font2 = new Font("Arial", 10f, FontStyle.Regular);
						for (num4 = 0; num4 < this.DisplayedYaxis.Length - 1; num4++)
						{
							if (this.DisplayedYaxis[num4])
							{
								if (this.displayStepsInCurves)
								{
									bool flag2 = false;
									bool flag3 = false;
									RectangleF rectangleF = RectangleF.Empty;
									RectangleF empty2 = RectangleF.Empty;
									int num7 = 0;
									int i;
									for (i = 0; i < this.CurvesLen && i != this.CurvesLen - 2; i++)
									{
										int num8 = (int)this.Curves[11, i + 1, 0];
										int num9 = this.XValueToPixel(this.Curves[this.VectorNumXaxis, i, 0]);
										int num10 = this.YValueToPixel(this.Curves[num4, i, 0]);
										if (num9 != num3 && flag2)
										{
											if (!flag3)
											{
												flag3 = true;
												graphics.DrawLine(pen2, num9 + 1, num5 * (num2 + 1) / num + this.Margin, num9 + 1, num5 * num2 / num + this.Margin + 15);
											}
											else
											{
												flag3 = false;
											}
											num3 = num9;
										}
										if (num6 != num8)
										{
											flag2 = (!flag2 && true);
											graphics.DrawLine(pen3, num9 + 1, num5 * (num2 + 1) / num + this.Margin, num9 + 1, num5 * num2 / num + this.Margin + 15);
											if (!flag && num6 != -1)
											{
												num7 = this.MeasureDisplayStringWidth(graphics, num6.ToString(), font2) + 4;
												RectangleF rect = rectangleF;
												rectangleF = new RectangleF((float)(num9 - num7 + 4), (float)(num5 * (num2 + 1) / num - 20 + this.Margin), (float)num7, font2.GetHeight());
												if (!rectangleF.IntersectsWith(rect))
												{
													graphics.DrawString((num6 + 1).ToString(), font2, Brushes.Green, rectangleF, stringFormat);
												}
												else
												{
													RectangleF layoutRectangle = new RectangleF((float)num9, (float)(num5 * (num2 + 1) / num - 35 + this.Margin), (float)num7, font2.GetHeight());
													graphics.DrawString((num6 + 1).ToString(), font2, Brushes.Green, layoutRectangle, stringFormat);
												}
											}
											num6 = num8;
										}
									}
									if (!flag)
									{
										RectangleF rectangleF2 = new RectangleF((float)(this.XValueToPixel(this.Curves[this.VectorNumXaxis, i - 1, 0]) - 20), (float)(num5 * (num2 + 1) / num - 20 + this.Margin), (float)(this.MeasureDisplayStringWidth(graphics, (num6 + 1).ToString(), font2) + 4), font2.GetHeight());
										if (!rectangleF.IntersectsWith(rectangleF2))
										{
											graphics.DrawString((num6 + 1).ToString(), font2, Brushes.Green, rectangleF2, stringFormat);
										}
										else
										{
											rectangleF2 = new RectangleF((float)(this.XValueToPixel(this.Curves[this.VectorNumXaxis, i - 1, 0]) - 20), (float)(num5 * (num2 + 1) / num - 35 + this.Margin), (float)(this.MeasureDisplayStringWidth(graphics, (num6 + 1).ToString(), font2) + 4), font2.GetHeight());
											graphics.DrawString((num6 + 1).ToString(), font2, Brushes.Green, rectangleF2, stringFormat);
										}
									}
								}
								pen.Color = Color.Black;
								pen.DashStyle = DashStyle.Solid;
								this.YCurvePrepare(num4, num, num2, printOnPaper);
								graphics.DrawLine(pen, this.Margin + 60, num5 * (num2 + 1) / num + this.Margin, 60 + this.Margin, num5 * num2 / num + this.Margin + 15);
								graphics.DrawLine(pen, (float)(this.Output_Width + this.Margin - 20), (float)(num5 * (num2 + 1) / num + this.Margin), (float)(this.Output_Width + this.Margin - 20), (float)(num5 * num2 / num + this.Margin + 15));
								graphics.DrawLine(pen, (float)(this.Margin + 60), (float)num5 / (float)num * (float)(num2 + 1) + (float)this.Margin, (float)(this.Output_Width + this.Margin - 20), (float)num5 / (float)num * (float)(num2 + 1) + (float)this.Margin);
								pen.Color = Color.Gray;
								pen.DashStyle = DashStyle.Dash;
								stringFormat.Alignment = StringAlignment.Center;
								int num11;
								if (num == num2 + 1)
								{
									num11 = -1 * (int)Math.Log10((double)this.CurvData.xScaleRangeF) + 2;
									if (num11 < 0)
									{
										num11 = 0;
									}
									for (int i = 0; (float)i < this.CurvData.xScaleNumber; i++)
									{
										empty = ((float)Math.Round((double)(this.CurvData.xMinScaleValueF + (float)(i + 1) * this.CurvData.xScaleRangeF), num11)).ToString();
										if (this.CurvData.xMinScaleRange + (float)i * this.CurvData.xScaleRange > graphics.MeasureString(empty, font).Width / 2f && (float)(60 + this.Margin) + this.CurvData.xMinScaleRange + (float)i * this.CurvData.xScaleRange + graphics.MeasureString(empty, font).Width / 2f < (float)(this.Output_Width + this.Margin) - graphics.MeasureString(this.GetCurveName(this.VectorNumXaxis), font).Width)
										{
											graphics.DrawString(empty, font, Brushes.Black, new RectangleF((float)(this.Margin + 30) + this.CurvData.xMinScaleRange + (float)i * this.CurvData.xScaleRange, (float)(num5 * (num2 + 1) / num + 2 + this.Margin), 60f, font.GetHeight()), stringFormat);
										}
									}
									stringFormat.Alignment = StringAlignment.Far;
									graphics.DrawString(this.GetCurveName(this.VectorNumXaxis), font, Brushes.Black, new RectangleF((float)(this.Output_Width + this.Margin) - graphics.MeasureString(this.GetCurveName(this.VectorNumXaxis), font).Width, (float)(num5 * (num2 + 1) / num + 2 + this.Margin), graphics.MeasureString(this.GetCurveName(this.VectorNumXaxis), font).Width, font.GetHeight()), stringFormat);
								}
								stringFormat.Alignment = StringAlignment.Near;
								graphics.DrawString(this.GetCurveName(num4), font, Brushes.Black, new RectangleF((float)(60 + this.Margin + 10), (float)(num5 * num2 / num + this.Margin + 15) - font.GetHeight() - 1f, 200f, font.GetHeight()), stringFormat);
								stringFormat.Alignment = StringAlignment.Far;
								graphics.DrawString(this.CurvData.yMinScaleValueF.ToString(), font, Brushes.Black, new RectangleF((float)this.Margin, (float)(num5 * (num2 + 1) / num) - font.GetHeight() / 2f + (float)this.Margin, 58f, font.GetHeight()), stringFormat);
								num11 = -1 * (int)Math.Log10((double)this.CurvData.yScaleRangeF) + 2;
								if (num11 < 0)
								{
									num11 = 0;
								}
								for (int i = 1; (float)i <= this.CurvData.yScaleNumber; i++)
								{
									graphics.DrawLine(pen, (float)(60 + this.Margin), (float)num5 / (float)num * (float)(num2 + 1) - (float)i * this.CurvData.yScaleRange + (float)this.Margin, (float)(this.Output_Width + this.Margin - 20), (float)num5 * (float)(num2 + 1) / (float)num - (float)i * this.CurvData.yScaleRange + (float)this.Margin);
									graphics.DrawString(((float)Math.Round((double)(this.CurvData.yMinScaleValueF + (float)i * this.CurvData.yScaleRangeF), num11)).ToString(), font, Brushes.Black, new RectangleF((float)this.Margin, (float)(num5 * (num2 + 1) / num) - font.GetHeight() / 2f - (float)i * this.CurvData.yScaleRange + (float)this.Margin, 58f, font.GetHeight()), stringFormat);
								}
								pen.DashStyle = DashStyle.Solid;
								try
								{
									for (int j = 0; j < this.CurveNum; j++)
									{
										switch (j)
										{
										case 0:
											pen.Color = Color.Blue;
											break;
										case 1:
											pen.Color = Color.Green;
											break;
										case 2:
											pen.Color = Color.Red;
											break;
										case 3:
											pen.Color = Color.Pink;
											break;
										case 4:
											pen.Color = Color.Lime;
											break;
										case 5:
											pen.Color = Color.Gray;
											break;
										case 6:
											pen.Color = Color.Gold;
											break;
										case 7:
											pen.Color = Color.Magenta;
											break;
										case 8:
											pen.Color = Color.Navy;
											break;
										case 9:
											pen.Color = Color.Black;
											break;
										default:
											pen.Color = Color.Brown;
											break;
										}
										int num9 = this.XValueToPixel(this.Curves[this.VectorNumXaxis, 0, j]);
										int num10 = this.YValueToPixel(this.Curves[num4, 0, j]);
										List<Point> list = new List<Point>();
										for (int i = 0; i < this.CurvesLen; i++)
										{
											num3 = this.XValueToPixel(this.Curves[this.VectorNumXaxis, i, j]);
											int num12 = this.YValueToPixel(this.Curves[num4, i, j]);
											if (num9 != num3 || num10 != num12)
											{
												if (num9 < this.Output_Width + this.Margin - 20 && num9 > 60 + this.Margin)
												{
													goto IL_0dd8;
												}
												if (num3 < this.Output_Width + this.Margin - 20 && num3 > 60 + this.Margin)
												{
													goto IL_0dd8;
												}
											}
											continue;
											IL_0dd8:
											list.Add(new Point(num3, num12));
											num9 = num3;
											num10 = num12;
										}
										if (list.Count > 0)
										{
											graphics.DrawLines(pen, list.ToArray());
										}
										flag = true;
									}
								}
								catch
								{
								}
								num2++;
							}
						}
						font.Dispose();
						font2.Dispose();
						pen.Dispose();
						if (this.CurvData.initializeCurve)
						{
							this.ZoomData.cursor1pos = this.LeftPoint;
							this.ZoomData.cursor2pos = this.RightPoint;
							this.CurvData.initializeCurve = false;
						}
						try
						{
							if (!printOnPaper)
							{
								if (this.ZoomData.isLeftCursor)
								{
									ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), this.Sender.ClientSize.Height)), Color.BlueViolet);
									ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), this.Sender.ClientSize.Height)), Color.Brown);
								}
								else
								{
									ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), this.Sender.ClientSize.Height)), Color.Brown);
									ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), this.Sender.ClientSize.Height)), Color.BlueViolet);
								}
							}
						}
						catch (Exception)
						{
						}
						graphics.Dispose();
						if (!isSystemCall)
						{
							this.RepaintIsBlocked = true;
							this.RepaintTimer.Start();
						}
					}
				}
			}
		}

		private int MeasureDisplayStringWidth(Graphics graphics, string text, Font font)
		{
			StringFormat stringFormat = new StringFormat();
			RectangleF layoutRect = new RectangleF(0f, 0f, 1000f, 1000f);
			CharacterRange[] measurableCharacterRanges = new CharacterRange[1]
			{
				new CharacterRange(0, text.Length)
			};
			Region[] array = new Region[1];
			stringFormat.SetMeasurableCharacterRanges(measurableCharacterRanges);
			array = graphics.MeasureCharacterRanges(text, font, layoutRect, stringFormat);
			layoutRect = array[0].GetBounds(graphics);
			return (int)(layoutRect.Right + 1f);
		}

		private void MakeXMinAndXMax()
		{
			this.CurvData.xmax = -3.40282347E+38f;
			this.CurvData.xmin = 3.40282347E+38f;
			for (int i = 0; i < this.CurveNum; i++)
			{
				for (int j = 0; j < this.CurvesLen; j++)
				{
					if (this.CurvData.xmax < this.Curves[this.VectorNumXaxis, j, i])
					{
						this.CurvData.xmax = this.Curves[this.VectorNumXaxis, j, i];
					}
					if (this.CurvData.xmin > this.Curves[this.VectorNumXaxis, j, i])
					{
						this.CurvData.xmin = this.Curves[this.VectorNumXaxis, j, i];
					}
				}
			}
			if (float.IsNaN(this.CurvData.xmax))
			{
				this.CurvData.xmax = 0f;
			}
			if (float.IsNaN(this.CurvData.xmin))
			{
				this.CurvData.xmin = 0f;
			}
			if (float.IsNegativeInfinity(this.CurvData.xmax))
			{
				this.CurvData.xmax = 0f;
			}
			if (float.IsNegativeInfinity(this.CurvData.xmin))
			{
				this.CurvData.xmin = 0f;
			}
			if (float.IsPositiveInfinity(this.CurvData.xmax))
			{
				this.CurvData.xmax = 0f;
			}
			if (float.IsPositiveInfinity(this.CurvData.xmin))
			{
				this.CurvData.xmin = 0f;
			}
			if (this.CurvData.xmax == this.CurvData.xmin)
			{
				this.CurvData.xmax = this.CurvData.xmax + 1f;
				this.CurvData.xmin = this.CurvData.xmin - 1f;
			}
			if (this.CurvData.xmax < this.CurvData.xmin)
			{
				this.CurvData.xmax = 1f;
				this.CurvData.xmin = -1f;
			}
			this.LeftPoint = this.CurvData.xmin;
			this.RightPoint = this.CurvData.xmax;
		}

		private bool XCurvePrepare(bool printOnPaper)
		{
			int num = 0;
			int num2 = (int)Math.Ceiling(16.0 * (double)(this.Sender.ClientSize.Width - 60 - 20) / 1000.0);
			if (num2 <= 0)
			{
				num2 = 1;
			}
			float num3 = 0f;
			float num4 = 1f;
			for (int i = 0; i < this.CurvesLen; i++)
			{
				if (this.Curves[this.VectorNumXaxis, i, 0] >= this.LeftPoint && this.Curves[this.VectorNumXaxis, i, 0] <= this.RightPoint)
				{
					this.XPointsToShow[num] = i;
					num++;
				}
			}
			if (num < 2)
			{
				return false;
			}
			this.ZoomData.pointNumber = num;
			float num5 = this.RightPoint;
			float num6 = this.LeftPoint;
			float num7;
			for (num7 = num5 - num6; num7 < (float)num2; num7 = num5 - num6)
			{
				num5 *= 10f;
				num6 *= 10f;
				num4 /= 10f;
			}
			while (num7 >= (float)(num2 * 10))
			{
				num5 /= 10f;
				num6 /= 10f;
				num4 *= 10f;
				num7 = num5 - num6;
			}
			if (num7 < (float)(num2 * 10) && num7 >= (float)(num2 * 5))
			{
				num3 = 10f;
			}
			if (num7 < (float)(num2 * 5) && num7 >= (float)(num2 * 2))
			{
				num3 = 5f;
			}
			if (num7 < (float)(num2 * 2) && num7 >= (float)num2)
			{
				num3 = 2f;
			}
			num5 /= num3;
			num6 /= num3;
			this.CurvData.xScaleNumber = num5 - num6;
			this.CurvData.xScaleRangeF = num3 * num4;
			this.CurvData.xoffset = num6 * num3 * num4;
			this.CurvData.xMinScaleValueF = (float)Math.Floor((double)num6) * num3 * num4;
			this.CurvData.xnorm = (float)(this.Output_Width - 80) / this.CurvData.xScaleRangeF / this.CurvData.xScaleNumber;
			this.CurvData.xScaleRange = num4 * num3 * this.CurvData.xnorm;
			this.CurvData.xMinScaleRange = this.CurvData.xScaleRange * (1f + (float)Math.Floor((double)num6) - num6);
			return true;
		}

		private bool YCurvePrepare(int actualYaxisVectorNum, int ynum, int curvenum, bool printOnPaper)
		{
			int num = (int)Math.Ceiling(32.0 * (double)(this.Sender.ClientSize.Height - ynum * 15 - this.BottomMargin) / 700.0 / (double)ynum);
			if (num <= 0)
			{
				num = 1;
			}
			float num2 = 0f;
			float num3 = 0f;
			float num4 = -1E+07f;
			float num5 = 1E+07f;
			int num6 = this.Output_Height - this.BottomMargin;
			for (int i = 0; i < this.CurveNum; i++)
			{
				int num7 = 0;
				int num8 = this.XValueToPixel(this.Curves[this.VectorNumXaxis, 0, i]);
				int num9 = this.XValueToPixel(this.Curves[this.VectorNumXaxis, 0, i]);
				int num10 = this.XValueToPixel(this.Curves[this.VectorNumXaxis, 1, i]);
				if (num8 < this.Output_Width - 20 + this.Margin && num8 > 60 + this.Margin)
				{
					goto IL_012a;
				}
				if (num9 < this.Output_Width - 20 + this.Margin && num9 > 60 + this.Margin)
				{
					goto IL_012a;
				}
				if (num10 < this.Output_Width - 20 + this.Margin && num10 > 60 + this.Margin)
				{
					goto IL_012a;
				}
				goto IL_016e;
				IL_012a:
				if (num4 < this.Curves[actualYaxisVectorNum, num7, i])
				{
					num4 = this.Curves[actualYaxisVectorNum, num7, i];
				}
				if (num5 > this.Curves[actualYaxisVectorNum, num7, i])
				{
					num5 = this.Curves[actualYaxisVectorNum, num7, i];
				}
				goto IL_016e;
				IL_035d:
				if (num4 < this.Curves[actualYaxisVectorNum, num7, i])
				{
					num4 = this.Curves[actualYaxisVectorNum, num7, i];
				}
				if (num5 > this.Curves[actualYaxisVectorNum, num7, i])
				{
					num5 = this.Curves[actualYaxisVectorNum, num7, i];
				}
				continue;
				IL_016e:
				for (num7 = 1; num7 < this.CurvesLen - 1; num7++)
				{
					num8 = this.XValueToPixel(this.Curves[this.VectorNumXaxis, num7 - 1, i]);
					num9 = this.XValueToPixel(this.Curves[this.VectorNumXaxis, num7, i]);
					num10 = this.XValueToPixel(this.Curves[this.VectorNumXaxis, num7 + 1, i]);
					if (num8 < this.Output_Width - 20 + this.Margin && num8 > 60 + this.Margin)
					{
						goto IL_0227;
					}
					if (num9 < this.Output_Width - 20 + this.Margin && num9 > 60 + this.Margin)
					{
						goto IL_0227;
					}
					if (num10 < this.Output_Width - 20 + this.Margin && num10 > 60 + this.Margin)
					{
						goto IL_0227;
					}
					continue;
					IL_0227:
					if (num4 < this.Curves[actualYaxisVectorNum, num7, i])
					{
						num4 = this.Curves[actualYaxisVectorNum, num7, i];
					}
					if (num5 > this.Curves[actualYaxisVectorNum, num7, i])
					{
						num5 = this.Curves[actualYaxisVectorNum, num7, i];
					}
				}
				num7 = (int)(this.CurvesLen - 1);
				num8 = this.XValueToPixel(this.Curves[(int)(long)checked((IntPtr)this.VectorNumXaxis), (int)(long)checked((IntPtr)unchecked((long)(this.CurvesLen - 2))), (int)(long)checked((IntPtr)i)]);
				num9 = this.XValueToPixel(this.Curves[(int)(long)checked((IntPtr)this.VectorNumXaxis), (int)(long)checked((IntPtr)unchecked((long)(this.CurvesLen - 1))), (int)(long)checked((IntPtr)i)]);
				num10 = this.XValueToPixel(this.Curves[(int)(long)checked((IntPtr)this.VectorNumXaxis), (int)(long)checked((IntPtr)unchecked((long)(this.CurvesLen - 1))), (int)(long)checked((IntPtr)i)]);
				if (num8 < this.Output_Width - 20 + this.Margin && num8 > 60 + this.Margin)
				{
					goto IL_035d;
				}
				if (num9 < this.Output_Width - 20 + this.Margin && num9 > 60 + this.Margin)
				{
					goto IL_035d;
				}
				if (num10 < this.Output_Width - 20 + this.Margin && num10 > 60 + this.Margin)
				{
					goto IL_035d;
				}
			}
			if (float.IsNaN(num4))
			{
				num4 = 0f;
			}
			if (float.IsNaN(num5))
			{
				num5 = 0f;
			}
			if (float.IsNegativeInfinity(num4))
			{
				num4 = 0f;
			}
			if (float.IsNegativeInfinity(num5))
			{
				num5 = 0f;
			}
			if (float.IsPositiveInfinity(num4))
			{
				num4 = 0f;
			}
			if (float.IsPositiveInfinity(num5))
			{
				num5 = 0f;
			}
			if (num4 == num5)
			{
				num4 += 1f;
				num5 -= 1f;
			}
			if (num4 < num5)
			{
				num4 = 1f;
				num5 = -1f;
			}
			this.CurvData.ymax = num4;
			this.CurvData.ymin = num5;
			float num11;
			for (num11 = num4 - num5; num11 < (float)num; num11 = num4 - num5)
			{
				num4 *= 10f;
				num5 *= 10f;
				num3 -= 1f;
			}
			while (num11 >= (float)(num * 10))
			{
				num4 /= 10f;
				num5 /= 10f;
				num3 += 1f;
				num11 = num4 - num5;
			}
			if (num11 < (float)(num * 10) && num11 >= (float)(num * 5))
			{
				num2 = 10f;
			}
			if (num11 < (float)(num * 5) && num11 >= (float)(num * 2))
			{
				num2 = 5f;
			}
			if (num11 < (float)(num * 2) && num11 >= (float)num)
			{
				num2 = 2f;
			}
			num4 = (float)Math.Ceiling((double)(num4 / num2));
			num5 = (float)Math.Floor((double)(num5 / num2));
			this.CurvData.yScaleNumber = num4 - num5;
			this.CurvData.yScaleRangeF = (float)((double)num2 * Math.Pow(10.0, (double)num3));
			this.CurvData.yoffset = num5 * num2 * (float)Math.Pow(10.0, (double)num3);
			this.CurvData.yMinScaleValueF = (float)((double)(num5 * num2) * Math.Pow(10.0, (double)num3));
			this.CurvData.ynorm = ((float)num6 / (float)ynum - 15f) / this.CurvData.yScaleRangeF / this.CurvData.yScaleNumber;
			this.CurvData.yScaleRange = (float)(Math.Pow(10.0, (double)num3) * (double)num2 * (double)this.CurvData.ynorm);
			this.CurvData.curveoffset = (float)num6 / (float)ynum * ((float)curvenum + 1f) + (float)this.Margin;
			return true;
		}

		private int XValueToPixel(float xvalue)
		{
			return 60 + this.Margin + (int)(0.5f + (xvalue - this.CurvData.xoffset) * this.CurvData.xnorm);
		}

		private int YValueToPixel(float yvalue)
		{
			return (int)(this.CurvData.curveoffset - (yvalue - this.CurvData.yoffset) * this.CurvData.ynorm + 0.5f);
		}

		private float XPixelToValue(int xvalue)
		{
			return ((float)xvalue - (float)(60 + this.Margin)) / this.CurvData.xnorm + this.CurvData.xoffset;
		}

		public void SetCurvesLength(uint length)
		{
			this.CurvesLen = length;
		}

		public bool CurveZoom()
		{
			float leftPoint = this.LeftPoint;
			float rightPoint = this.RightPoint;
			float num = this.RightPoint - this.LeftPoint;
			if (this.ZoomData.pointNumber <= 2)
			{
				return false;
			}
			if (num <= 0f)
			{
				return false;
			}
			this.RightPoint = leftPoint + num * (this.ZoomData.cursor2pos - leftPoint) / (rightPoint - leftPoint);
			this.LeftPoint = leftPoint + num * (this.ZoomData.cursor1pos - leftPoint) / (rightPoint - leftPoint);
			if (!this.XCurvePrepare(false))
			{
				this.LeftPoint = leftPoint;
				this.RightPoint = rightPoint;
				return false;
			}
			this.ZoomData.cursor1pos = this.LeftPoint;
			this.ZoomData.cursor2pos = this.RightPoint;
			this.Repaint(false, false, false);
			return true;
		}

		public void SwapCursor()
		{
			if (this.ZoomData.isLeftCursor)
			{
				ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), this.Sender.ClientSize.Height)), Color.BlueViolet);
				ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), this.Sender.ClientSize.Height)), Color.Brown);
				ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), this.Sender.ClientSize.Height)), Color.Brown);
				ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), this.Sender.ClientSize.Height)), Color.BlueViolet);
				this.ZoomData.isLeftCursor = false;
			}
			else
			{
				ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), this.Sender.ClientSize.Height)), Color.Brown);
				ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), this.Sender.ClientSize.Height)), Color.BlueViolet);
				ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), this.Sender.ClientSize.Height)), Color.BlueViolet);
				ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), this.Sender.ClientSize.Height)), Color.Brown);
				this.ZoomData.isLeftCursor = true;
			}
		}

		public bool SetCursor(int xpos)
		{
			if (this.CurvesLen == 0)
			{
				return false;
			}
			if (xpos < 60)
			{
				xpos = 60;
			}
			if (xpos > this.Sender.ClientSize.Width - 20)
			{
				xpos = this.Sender.ClientSize.Width - 20;
			}
			if (this.ZoomData.isLeftCursor)
			{
				if (xpos < this.XValueToPixel(this.ZoomData.cursor2pos))
				{
					ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), this.Sender.ClientSize.Height)), Color.BlueViolet);
					ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(xpos, 0)), this.Sender.PointToScreen(new Point(xpos, this.Sender.ClientSize.Height)), Color.BlueViolet);
					this.ZoomData.cursor1pos = this.XPixelToValue(xpos);
					return true;
				}
				ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor1pos), this.Sender.ClientSize.Height)), Color.BlueViolet);
				ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(xpos, 0)), this.Sender.PointToScreen(new Point(xpos, this.Sender.ClientSize.Height)), Color.BlueViolet);
				this.ZoomData.cursor1pos = this.ZoomData.cursor2pos;
				this.ZoomData.cursor2pos = this.XPixelToValue(xpos);
				this.ZoomData.isLeftCursor = false;
				return true;
			}
			if (xpos > this.XValueToPixel(this.ZoomData.cursor1pos))
			{
				ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), this.Sender.ClientSize.Height)), Color.BlueViolet);
				ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(xpos, 0)), this.Sender.PointToScreen(new Point(xpos, this.Sender.ClientSize.Height)), Color.BlueViolet);
				this.ZoomData.cursor2pos = this.XPixelToValue(xpos);
				return true;
			}
			ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), 0)), this.Sender.PointToScreen(new Point(this.XValueToPixel(this.ZoomData.cursor2pos), this.Sender.ClientSize.Height)), Color.BlueViolet);
			ControlPaint.DrawReversibleLine(this.Sender.PointToScreen(new Point(xpos, 0)), this.Sender.PointToScreen(new Point(xpos, this.Sender.ClientSize.Height)), Color.BlueViolet);
			this.ZoomData.cursor2pos = this.ZoomData.cursor1pos;
			this.ZoomData.cursor1pos = this.XPixelToValue(xpos);
			this.ZoomData.isLeftCursor = true;
			return true;
		}

		public string GetCurveValues(int y)
		{
			if (y > 0 && y <= this.Sender.ClientSize.Height - this.BottomMargin)
			{
				string empty = string.Empty;
				float num = this.RightPoint - this.LeftPoint;
				if (num <= 0f)
				{
					return empty;
				}
				float num2 = (!this.ZoomData.isLeftCursor) ? this.ZoomData.cursor2pos : this.ZoomData.cursor1pos;
				int i;
				if (num2 < this.Curves[this.VectorNumXaxis, 0, 0])
				{
					for (i = 0; i < this.CurvesLen && !(num2 > this.Curves[this.VectorNumXaxis, i, 0]); i++)
					{
					}
				}
				else
				{
					for (i = 0; i < this.CurvesLen && !(num2 < this.Curves[this.VectorNumXaxis, i, 0]); i++)
					{
					}
				}
				if (i >= this.CurvesLen)
				{
					i = (int)(this.CurvesLen - 1);
				}
				empty = this.CurvData.curveName[this.VectorNumXaxis] + ": " + ((float)Math.Round((double)this.Curves[this.VectorNumXaxis, i, 0], 3)).ToString() + this.CurvData.curveUnit[this.VectorNumXaxis] + "   ";
				int num3 = (int)Math.Ceiling((double)((float)y / ((float)(this.Sender.ClientSize.Height - this.BottomMargin) / (float)this.CurvData.yCurveNum)));
				if (num3 > this.CurvData.yCurveNum)
				{
					num3 = this.CurvData.yCurveNum;
				}
				int j;
				for (j = 0; j < this.DisplayedYaxis.Length; j++)
				{
					if (this.DisplayedYaxis[j])
					{
						num3--;
						if (num3 <= 0)
						{
							break;
						}
					}
				}
				int num4 = -1 * (int)Math.Log10((double)Math.Abs(this.Curves[j, i, 0])) + 3;
				if (num4 < 0)
				{
					num4 = 0;
				}
				return empty + this.CurvData.curveName[j] + ": " + ((float)Math.Round((double)this.Curves[j, i, 0], num4)).ToString() + this.CurvData.curveUnit[j];
			}
			return string.Empty;
		}

		public void InitializeDisplay()
		{
			this.CurvData.initializeCurve = true;
		}

		public void Print()
		{
			if (this.printDialog.ShowDialog() == DialogResult.OK)
			{
				this.printDocument.Print();
			}
		}

		private void printDocument_PrintPage(object sender, PrintPageEventArgs e)
		{
			this.E_Print = e;
			this.Repaint(true, false, false);
		}

		public void TemporaryNoRepaint()
		{
			this.TemporaryNoRepaintTimer.Stop();
			this.TemporaryNoRepaintTimer.Start();
			this.RepaintIsBlocked = true;
		}

		private void TemporaryNoRepaintTimer_Tick(object source, ElapsedEventArgs e)
		{
			if (!this.RepaintTimer.Enabled)
			{
				this.RepaintIsBlocked = false;
			}
			this.TemporaryNoRepaintTimer.Stop();
			this.Repaint(false, false, false);
		}

		private void RepaintTimer_Tick(object source, ElapsedEventArgs e)
		{
			this.RepaintIsBlocked = false;
			this.RepaintTimer.Stop();
		}
	}
}
