namespace WSPKurve
{
	public struct S_CurveData
	{
		public bool initializeCurve;

		public int yCurveNum;

		public float xmax;

		public float xmin;

		public float ymax;

		public float ymin;

		public float xnorm;

		public float ynorm;

		public float xoffset;

		public float yoffset;

		public float xScaleRangeF;

		public float yScaleRangeF;

		public float xMinScaleValueF;

		public float yMinScaleValueF;

		public float xMinScaleRange;

		public float xScaleRange;

		public float yScaleRange;

		public float xScaleNumber;

		public float yScaleNumber;

		public float curveoffset;

		public string[] curveName;

		public string[] curveUnit;
	}
}
