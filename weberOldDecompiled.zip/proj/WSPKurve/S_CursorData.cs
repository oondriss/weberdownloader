namespace WSPKurve
{
	public struct S_CursorData
	{
		public float xvalue;

		public float[] yvalues;
	}
}
